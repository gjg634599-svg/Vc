# MediaGrab Bot — Deployment Guide (v99.11.3)

## Source Version
- **Version**: v99.11.3 (patch — see the v99.11.3 section at the end; previous top block preserved below for the v99.09 supersedes chain)
- **Supersedes**: v99.11.2 — the surgical Join-All cluster-owned already-joined convergence fix (proven working in production: 24× `VC_JOIN_ALL_ALREADY_JOINED_CONVERGED breaker_recorded=false`, zero associated breaker failures). v99.11.3 fixes the remaining two production problems proven by the 2026-09-25/26 logs: the native FD/socket retention (fd 20→885 in 4.5h with joined FLAT) and the `Invalid channel object` three-strike breaker storm.

## Historical Source Version (v99.09)
- **Version**: v99.09
- **Supersedes**: v99.08 — the 2026-09-19 evening production log
  (17:33:25 → 17:50:35, v99.08 deployment verified: 52
  VC_JOIN_SUCCESS with telegram_verified=true, backend_gen>=1, zero
  "VCBackend not started" — the v99.07 backend fix CONFIRMED working)
  exposed a verification-defect cluster: verify_joined's ownership
  lookup missed the pipeline's marked-form records and fell back to a
  per-account "last rotated-to" scalar that ping-ponged between the
  two accounts (24,526 delegation lines, 25 RecursionError); an
  entity-level detect failure that exhausted the retry budget crashed
  the state machine with the invalid ENTITY_FAILED → CALL_ENDED
  transition (root: the rotate-to-resolver was silently skipped inside
  the resolver's 2-5s post-join stagger window); and the liveness
  stamper NEVER started because the v99.07 FIX-11 idempotency check
  read an undeclared module global (NameError at both boots, watchdog
  "attempt 1" spam every 60s).
  v99.09 is the verification-repair release — see the v99.09 section
  and PATCH_MANIFEST_v99.09.txt.


## ⚠ v99.09 — VERIFICATION REPAIR (read before the next Join-All)

What was broken (the exact 17:37 / 17:42-17:50 chains):

1. **RecursionError in verify_joined** — the post-join verification
   delegated between acc_918 and acc_919 forever (24,526
   `VC_VERIFY_DELEGATED` lines, 25 `RecursionError: maximum recursion
   depth exceeded`). The joins themselves SUCCEEDED (registry=joined)
   but each verify burned ~1000 frames and up to ~15s per target.
   Fixed (FIX-C): form-aware ownership lookup (raw/marked/basic — the
   same 3-form contract the rest of the function uses) + a one-hop
   delegation guard (`_v9909_delegated`, keyword-only, external
   callers unchanged).
2. **Invalid pipeline transition ENTITY_FAILED → CALL_ENDED** — an
   entity-level detect failure (CHANNEL_INVALID from a foreign-scope
   entity) that exhausted the retry budget fell through to the
   `no_active_call` branch. Fixed (FIX-B): the exhausted path exits
   via the designed ENTITY_FAILED → UNRECOVERABLE terminal and
   re-raises the ORIGINAL exception; the `no_active_call` CALL_ENDED
   verdict is preserved for genuine no-call detects.
3. **The upstream cause of (2)** — the rotate-to-resolver (v99 §3)
   was SILENTLY skipped whenever the resolver account was inside its
   2-5s post-join stagger cooldown, so the join consumed the
   resolver's entity on the WRONG client. Fixed (FIX-A): the SOFT
   cooldown is waited out (bounded ≤5.5s, marker
   `VC_PIPELINE_ROTATE_TO_RESOLVER_WAIT`); hard vetos (FloodWait) keep
   the old behaviour but are now logged
   (`VC_PIPELINE_ROTATE_TO_RESOLVER_SKIPPED reason=…`).
4. **Liveness stamper never started** — `name '_vc_loop_liveness_task'
   is not defined` at both boots, then `WATCHDOG: vc_loop_liveness was
   None — starting (attempt 1)` every 60s forever. Fixed (FIX-D): the
   module global is declared (the same convention as every other
   supervised task) and the watchdog's restarter call is guarded +
   failure-counted.
5. **Task-dump noise during Join-All** — one periodic 47-task dump at
   17:43:28 (all healthy; the v99.07 rate-limit itself worked). Fixed
   (FIX-E): the PERIODIC dump defers to the Join-All busy phase with
   the observable `TASK_DUMP_SUPPRESSED_BUSY reason=join_all_running`
   marker (SIGUSR1/on-demand dumps unaffected; threshold mechanism
   untouched).

Verified-benign in the same log (NO change): 43 VC_HASH_SCOPE_MISMATCH
(the scope gate working — every one resolved via Step-0c rotation), 40
LOCAL_MISS (honest classification of never-seen entities), the two 30s
join timeouts (pytgcalls "Telegram is having some internal server
issues. Retrying" — external; breaker x1/3, never tripped; recoverable),
zero EVENT_LOOP_LAG.

### v99.09 acceptance signatures (the next production log MUST show)

- ZERO RecursionError; each verify_joined emits at most ONE
  `VC_VERIFY_DELEGATED` line; verify durations collapse to the
  participant-query time (the 17:42-17:50 targets took up to ~15s
  each in the recursion storm).
- ZERO "VC pipeline invalid transition"; an exhausted entity-level
  detect ends as `ENTITY_FAILED → UNRECOVERABLE reason=
  detect_entity_failed` + the ORIGINAL exception class in
  VC_ATTEMPT_FINAL (exc_class=VCTransportError).
- `VC_PIPELINE_ROTATE_TO_RESOLVER_WAIT … seconds=0.x` inside
  join-stagger windows (then the rotation fires and the join lands on
  the resolver's account).
- `VC loop liveness task started (v98.07 FIX-SS).` on boot and ZERO
  `WATCHDOG: vc_loop_liveness was None` repeats.
- `TASK_DUMP_SUPPRESSED_BUSY reason=join_all_running` (DEBUG) instead
  of the periodic dump mid-Join-All.
- The v99.08 baseline HOLDS: 50+ VC_JOIN_SUCCESS with
  telegram_verified=true, backend_gen>=1, zero "VCBackend not
  started", ENTITY_CACHE_CLEARED flat_removed>0 after rotations.

### Regression signals (ship the log back if any appear)

- Any RecursionError or a VC_VERIFY_DELEGATED stream (>1 line/call).
- Any "invalid transition" of any shape.
- A rotation skip with reason=stagger_cooldown (must be impossible).
- "restarter raised NameError" from the watchdog.
- VC_JOIN_SUCCESS count dropping vs the 52-success v99.08 baseline.

## ⚠ v99.08 — LIFECYCLE REPAIR (read before the first rotation)

What was broken (the exact 12:29:29 → 12:36:29 chain): a primary
rotation purged only the SCOPED entity cache (27 entries) while the
FLAT mirrors survived (the purge compared `client:<id>` tokens against
real account ids); the old primary's still-live client was then scope-
bound to the NEW primary id, so the reconcile pass re-annotated the old
owner's entities under the new primary's scope; the join-all
classification read those poisoned entries (the scope gate matched —
the hash was foreign), every GetFullChannelRequest failed with
"Invalid channel object", and the 60s negative-backoff loop recycled
the failures until `eligible=0 excluded=27 channel_invalid=25`.

What v99.08 fixes — and the log signatures the next production run
MUST show:

1. **Flat purge reaches the mirrors (FIX-1)** — after ANY
   `PRIMARY_ROTATED`, the very next `ENTITY_CACHE_CLEARED` line must
   carry `flat_removed=<N>` with N > 0 (v99.07 always showed the flat
   purge inside `entries_removed` as 0).  REGRESSION SIGNAL:
   `flat_removed=0` after a rotation.
2. **No rotation-window misattribution (FIX-5)** — the reconcile lines
   after a rotation must NOT show `VC_HASH_SCOPE_MISMATCH` for a client
   that is still the OLD primary's live session (the false-mismatch
   storm of 12:29:31-12:29:57 is gone: the old owner's own reads hit
   its surviving access-state).  REGRESSION SIGNAL: a burst of
   `VC_HASH_SCOPE_MISMATCH entry_scope=<old_primary>
   consumer_scope=<new_primary>` on RECONCILE lines (vc_verify_target)
   — note the CLASSIFY path may still legitimately mismatch once for
   stale entries, which the Step-0c routing then resolves via
   `ENTITY_RESOLVE_ACCOUNT_SWITCH ... to_account=<old_primary>`.
3. **No poisoned re-annotation** — `ENTITY_CACHE_SCOPED
   account=<new_primary> ... source=vc_discovery` lines whose entity
   access_hash equals the OLD primary's write must NOT appear after a
   rotation.
4. **Classify recovery** — post-rotation classification resolves via
   `source=account_rotation:<old_owner>` and `VC_CLASSIFY_FAILURE ...
   Invalid channel object` does not recur after the first negative-TTL
   expiry.  REGRESSION SIGNAL: `eligible=0 ... channel_invalid=<N>`
   persisting across cycles.
5. **Sustainability hardening (FIX-6/7)** — five more service loops
   heartbeat (`vc_session_hot_reload_loop`, `auto_discovery_loop`,
   `vc_coverage_reconcile_loop`, `cluster_reconnect_loop`,
   `bot_history_loop` — watch `BOT_WORKER_*` lines); the three entity
   caches are size-bounded (`VC_ENTITY_CACHE_MAX_ENTRIES`, default
   5000) and the negative cache enforces the §28 budget
   (default 10000).

New env knobs: `VC_ENTITY_CACHE_MAX_ENTRIES` (100..200000).  No retry
limit, concurrency cap, or budget was raised.

## ⚠ v99.07 — THE 47-ITEM AUDIT-FIX RELEASE

The runtime was healthy in every systemic respect (no loop starvation,
flat task population, flat FDs, heartbeat on cadence, no reconnect
storms) — the failures were LOCALIZED and every one is fixed:

1. **VC join start-gate (FIX-1/2/3)** — the round-robin join dispatch
   now guarantees a STARTED backend: the getter adopts a started
   same-client backend's transport, the dispatch site starts an
   unstarted one (idempotent), and backend_gen >= 1 proves it in
   VC_COORDINATOR_OP_START. The expected production signature is
   `VC_JOIN_ALL_TARGET_BACKEND_STARTED` (or an adopted-transport
   selection line) and ZERO "VCBackend not started."
2. **Honest shutdown (FIX-4)** — a promptly-cancelled Join-All worker
   logs `VC_JOIN_ALL_WORKER_STOPPED_AFTER_CANCEL`, NOT a false
   `VC_JOIN_ALL_SHUTDOWN_TIMEOUT` + ORPHANED.
3. **Talkative obeys OFF (FIX-5/6)** — no 60s retry loop, no Bot API
   fallback provider calls while disabled.
4. **Calibrated diagnostics (FIX-7/8)** — no periodic TASK_DUMP in the
   31–33 steady state (threshold 40, old+new logged at startup); the
   pytgcalls filter markers state whether the interceptor is ACTIVE.
5. **Worker watchdog LIVE (FIX-11/12/13)** — eight service loops
   heartbeat; the registry is bounded; the liveness starter is
   idempotent.
6. **Correctness + hygiene (FIX-9/10, P1/P2/P3)** — db_path fallback,
   real active_vc preservation (verified on SQLite), event-loop-safe
   dashboard startup, atomic backup names, Markdown-escaped AI replies,
   a canary exit marker on disk, a never-None webhook secret, and the
   full repo namespace (79 functions).

**Regression signals** (investigate immediately): any
"VCTransportError: VCBackend not started." · backend_gen=0 on a started
backend · a canary restart without VC_CANARY_EXIT_MARKER_DETECTED · a
genuine SHUTDOWN_TIMEOUT without the STOPPED_AFTER_CANCEL distinction.

**Verification**: full regression 2,090/2,090 (work tree AND fresh
extraction of the FINAL ZIP); drivers 11/11 + 10/10 + 17/17 + 15/15 +
16/16 + 22/22; stress ALL BOUNDS HOLD (v9902/v9903/v9904); packaged-
artifact sims 7/7 (v9905) + 17/17 (v9906); static audit UNRESOLVED
critical/high: 0; stamp v99.07 regenerated via tools/stamp_build.py.

---

# MediaGrab Bot — Deployment Guide (v99.06) — historical

## Source Version
- **Version**: v99.06
- **Final ZIP SHA256**: `PLACEHOLDER_SELF_REFERENTIAL` (this DEPLOYMENT.md is
  inside the ZIP, so writing the real SHA here would change the SHA — circular.
  The canonical final SHA is recorded in worklog.md, same convention as
  v97.96–v99.01).
- **Supersedes**: v99.05 (all of RC-F1…F6 preserved; the 2026-09-09 v99.01 production log proved the multi-account era was dead on arrival — 388× CHANNEL_INVALID from the scope chameleon, discovery starvation queries_done=0, Join-All pinned to one account, no ownership gate; v99.06 is the UNIFIED THREE-FIX release — see the v99.06 section)
- **Historical supersedes**: v99.03 (all of RC-8…RC-13 preserved AND runtime-proven by
  the 2026-09-11 v99.03 production runs — RC-8 refused all 16 joins with ZERO
  RPCs, RC-9 failed honestly with reason=no_deployment_zip_found, RC-10/13
  narrated correctly; v99.04 fixes what those runs proved was still broken —
  see the v99.04 section below)

## ⚠ v99.04 — FULL VC SYSTEM MISSION (read this before your first run)

v99.04 closes the gap the 2026-09-11 v99.03 runs (06:25 + 06:27) exposed:
every v99.03 protection fired correctly, but the operator's deployment
channel transfers **.py FILES ONLY** — four consecutive partial deployments
never delivered `assets/vc_silence_600s.opus`, and no deployment ZIP ever
existed on the box (`DEPLOY_SELF_HEAL_FAILED reason=no_deployment_zip_found`
at BOTH boots). The VC transport was NEVER reached (zero RPCs paid, zero
joins attempted beyond the RC-8 refusal) — the system was correctly
protecting a broken deployment. v99.04 makes the deployment itself
self-contained and the recovery live.

### The operator runbook (v99.04, in order)

1. **Deploy the COMPLETE .py set — that is now sufficient:**
   ```bash
   # copy/sync ALL .py files, INCLUDING the new one:
   #   mediagrab_bot/asset_embedded.py   ← carries the silence asset as text
   ```
   On boot, if `assets/vc_silence_600s.opus` is missing, the bot heals it
   from the embedded copy (sha256-verified against the build stamp) and the
   identity re-verifies. Watch for:
   - `DEPLOY_SELF_HEAL asset=vc_silence_600s.opus source=embedded:asset_embedded.py sha256=e6ad24a0… bytes=226371`
   - `BUILD_IDENTITY_VERIFIED … self_healed=1`
   Extracting the FULL ZIP still works and takes priority when a ZIP with
   the stamped bytes is on disk. A corrupted/edited `asset_embedded.py` is
   REFUSED (sha256 mismatch) — identity checking is NOT weakened.
2. **Repairs now apply WITHOUT a restart:** while the boot identity is
   mismatched, a background loop re-verifies every 120s and re-attempts the
   heal (ZIP → embedded). The moment the tree matches the stamp —
   `DEPLOY_HEALTH_RECOVERED … the VC pipeline re-opens IMMEDIATELY (no
   restart)` — joins resume. Fix the files while the bot runs.
3. **The RC-8 safety net still holds for genuinely mixed .py sets:** a
   module-hash mismatch (old + new .py files mixed) disables the pipeline
   (zero-RPC refusals) until you deploy the complete matching set — the
   recovery loop then re-opens it automatically.
4. **Adding your second account (the "two accounts but showing one" fix):**
   `/cluster add <phone>` now WORKS for a phone whose session is already
   live-authorized (e.g. the global primary's own phone): the account is
   REGISTERED reusing the live client —
   `ACCOUNT_REGISTERED … source=login_live_owner_reuse` — and the reply
   shows "✅ Account added — existing session reused!". No login code is
   needed. (Previously this dead-ended on "already_connected", which led to
   deleting a healthy session file in production.)
   - `ACCOUNT_SESSION_HEALTH … cluster_accounts=N expected_cluster=N` —
     `expected_cluster` now counts REAL accounts (v99.03 printed 0 whenever
     the `__primary__` special key was present — a runtime-proven bug fixed
     in v99.04).
5. **Honest limits:** all of the above is verified offline/packaged/fresh-
   extracted. The LIVE Telegram VC transport (real join → real transport →
   real verification → `VC_JOIN_SUCCESS`) still requires a healthy live
   deployment + valid sessions; if `VC_JOIN_SUCCESS` remains 0 WITH the
   identity verified AND the asset present, capture the next diagnostic log
   — that would be the first genuine transport-layer evidence.

### What changed in v99.04 (RC-14 … RC-18)

| RC | Severity | Fix |
|----|----------|-----|
| RC-14 | CRITICAL | The stamped silence asset ships ALSO as base64 text inside `mediagrab_bot/asset_embedded.py`; the RC-9 heal tries ZIP first, then the embedded copy. sha256-vs-stamp verification preserved (a corrupted embed is refused → RC-8). `.py`-only deployments are now COMPLETE. |
| RC-15 | HIGH | `account_session_health()` skips `__`-prefixed/non-dict registry keys — the swallowed AttributeError that printed `expected_cluster=0` with 1 account loaded (reproduced exactly; the v99.03 fake-cluster tests had no `__` key). The line gains `cluster_accounts=` and loses the `}}` cosmetic. |
| RC-16 | HIGH | `/cluster add` on a live-owned UNREGISTERED phone registers the account (registry-reuse of the live client, `ROLE_BACKUP`, `imported=True`) and returns `registered:<aid>`; the handler renders a success card. Already-registered phones keep `already_connected` (now informational). |
| RC-17 | MEDIUM | `DEPLOY_HEALTH_RECOVERY_LOOP` (120s while mismatched): re-verify the full identity (version + modules + assets), re-attempt the heal, publish the verified state — joins resume WITHOUT a restart (the RC-8 gate re-reads the state per join). |
| RC-18 | LOW | The `ACCOUNT_SESSION_HEALTH` emit cosmetics (single closing brace; `cluster_accounts=` field). |

## ⚠ v99.03 — DEPLOYMENT HYGIENE (read this before your first run)

v99.03 closes the gap the 2026-09-11 production run exposed: **every v99.02
code fix worked** (asset-identity mismatch detected at boot, all 40 joins
honestly blocked, FD_CENSUS stable 18–20, zero reconnects, zero Errno 24)
— yet the operator still reported "still facing issues + two accounts but
showing one". The remaining failures were **deployment-side** (a partial
extraction with the ZIP still on disk) and **observability-side** (a dead
session file nobody could see). v99.03 makes the bot repair the first and
 narrate the second.

### The operator runbook (v99.03, in order)

1. **Extract the FULL ZIP — never just the `.py` files:**
   ```bash
   cd /home/container          # (or /root/gr — wherever the tree lives)
   unzip -o mediagrab_bot_v99.03_deployment.zip -d /home/container/
   ls -l /home/container/mediagrab_bot/assets/vc_silence_600s.opus
   # must show 226371 bytes
   ```
2. **The bot self-heals if you forget:** when the boot identity check finds
   a stamped asset missing and the deployment ZIP is still on disk (one
   level above the package, or the process cwd), v99.03 re-extracts exactly
   that asset from the ZIP after verifying its sha256 against the build
   stamp, then re-verifies the identity. Watch for:
   - `DEPLOY_SELF_HEAL asset=vc_silence_600s.opus source=<zip> sha256=…`
   - `BUILD_IDENTITY_VERIFIED … self_healed=1`
   A ZIP with WRONG content is refused (sha256 mismatch) — the bot never
   installs unverified bytes.
3. **If the ZIP is gone too, the bot fail-fasts instead of churning:**
   `VC_PIPELINE_DISABLE reason=build_identity_mismatch` — every VC join is
   refused at pipeline entry with **zero entity-resolution RPCs**, and the
   discovery/reconcile loops skip their bodies. The Bot API surface stays
   fully available so you can diagnose live: `/deploy_check`,
   `/v85accounts`, `/v85status`. (Override with
   `VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH=1`; disable the self-heal with
   `VC_DISABLE_DEPLOY_SELF_HEAL=1`.)
4. **Dead sessions — "two accounts but showing one":**
   `/v85accounts` lists EVERY `.session` file with its status:
   - `primary_global` — the global bot session (NOT a cluster account;
     `ACCOUNT_STARTUP_REPORT total=N` counts cluster accounts only —
     this is the number the v99.02 operator misread);
   - `cluster_account_id=acc_…` — registered cluster accounts;
   - `unauthorized` — DEAD (auth key revoked / login never completed):
     delete the file and re-login:
     ```bash
     # 1. stop the bot
     rm /home/container/mediagrab_bot/data/sessions/cluster_916397080450.session
     python -m mediagrab_bot.tools.login --phone +916397080450
     # 4. restart (session hot-reload imports the fresh file within 60s)
     ```
     Every `SESSION_UNAUTHORIZED` line in the log is followed by a
     `SESSION_REMEDIATION` line carrying exactly this runbook with the
     phone derived from the file name.
5. **Watch the new markers** (all INFO unless noted):
   - `ACCOUNT_SESSION_HEALTH total_files=… live=… dead=… unregistered=…
     expected_cluster=… details=[one entry per .session file]` at import
     end;
   - `ACCOUNT_HEALTH live_clients=… cluster_accounts=… dead_sessions=…
     expected_cluster=…` every 300s in the heartbeat;
   - `VC_JOIN_BLOCKED_NULL_STREAM_SUPPRESSED chat_id=… count=…` — repeated
     blocked joins for the same chat collapse to ONE WARNING + these
     5-minute summaries, and the repeats are refused BEFORE entity
     resolution (zero wasted RPCs);
   - `FD_CENSUS …` (unchanged from v99.02 — stable is good).

### What changed in v99.03 (RC-8 … RC-13)

| RC | Severity | Fix |
|----|----------|-----|
| RC-8 | CRITICAL | Fail-fast on `BUILD_IDENTITY_MISMATCH`: the VC pipeline refuses entry (zero-RPC refusal before identity resolution), discovery + reconcile cycles short-circuit, Bot API stays up; `VC_PIPELINE_DISABLE` fires once at boot + once at first refusal. |
| RC-9 | CRITICAL | Self-extract the stamped asset from the on-disk deployment ZIP on first mismatch (sha256-verified, atomic tmp+replace, 8MB bound, no path traversal); on success the identity is re-verified (`self_healed=1`). |
| RC-10 | HIGH | `ACCOUNT_SESSION_HEALTH` (one entry per `.session` file) at import end + `ACCOUNT_HEALTH` every 300s + the admin `/v85accounts` command — the "N files vs M accounts" gap is visible at a glance. |
| RC-11 | MEDIUM | `SESSION_REMEDIATION` after EVERY `SESSION_UNAUTHORIZED` with the exact `python -m mediagrab_bot.tools.login --phone +<digits>` command; the helper ships as `mediagrab_bot/tools/login.py` (guards against a running bot via the V85 PID file). |
| RC-12 | LOW | Repeated null-stream-blocked joins for the same `(chat, reason)` short-circuit at pipeline ENTRY inside a 300s window (zero RPCs, DEBUG-level); one `VC_JOIN_BLOCKED_NULL_STREAM_SUPPRESSED chat_id=… count=…` summary per expired window. |
| RC-13 | LOW | Discovery + BOTH reconcile loops skip their bodies (one DEBUG line per cycle) while the pipeline is disabled. |

### Known deployment gaps called out (NOT v99.03 code scope)

- The 2026-09-11 run had **no supervisor** (`supervisor=tini`,
  `restart_policy=manual`) — the shipped `deploy/mediagrab.service`
  (systemd, `Restart=always`) closes this; installing it is strongly
  recommended (see the INSTALL block inside the unit file).
- MTProto "RPC timed out (attempt 1/3)" at startup and entity-resolution
  misses for chats the only live account cannot see are EXPECTED while a
  second account is dead — fix the session (runbook step 4), not the code.

## Historical: v99.02 CRITICAL DEPLOYMENT REQUIREMENT — extract the FULL ZIP

The v99.01 production deployment ran with `VC_SILENCE_ASSET_MISSING` on
EVERY join (98×) because only the `.py` files were copied to
`/home/container/mediagrab_bot` — the NEW `assets/vc_silence_600s.opus`
(226,371 bytes) never landed on disk. With the asset absent every join
fell back to the null-stream transport, which is RUNTIME-PROVEN to never
register a Telegram-side participant (168 dispatches → 0 verifications →
`VC_JOIN_SUCCESS=0` for the whole session).

**Deploy by extracting the entire ZIP** (assets/ included):

```bash
cd /root/gr
unzip -o mediagrab_bot_v99.02_deployment.zip -d /tmp/v9902_stage
cp -a /tmp/v9902_stage/mediagrab_bot/. /root/gr/mediagrab_bot/
# the assets dir MUST arrive:
ls -l /root/gr/mediagrab_bot/assets/vc_silence_600s.opus   # 226371 bytes
```

v99.02 verifies this at startup: the build-identity check now hashes
stamped DATA ASSETS exactly like stamped modules. A missing asset logs
`BUILD_IDENTITY_MISMATCH … [assets/vc_silence_600s.opus: stamp=…
actual=missing]` at ERROR and the startup identity line carries
`vc_silence_asset_sha256=<hash|missing>` — a partial deployment is caught
at boot, not 6 hours later.

## What Changed in v99.02 — PRODUCTION-STABILITY FORENSIC FIXES

The v99.01 production logs (three rotations, 2026-09-09 17:55 →
2026-09-10 03:20, ~10h) exposed seven root causes. Timeline proof: the
FD exhaustion began at 23:58; ALL reconnect storms began AFTER it; the VC
verification failures existed from the FIRST minute (independent of FD
pressure).

| RC | Severity | Root cause (evidence) | Fix |
|----|----------|----------------------|-----|
| RC-1 | CRITICAL | Silence asset missing in the deployed tree (98× `VC_SILENCE_ASSET_MISSING`; the ZIP contained it) → every join null-stream → structurally 0 verifications + join churn | FIX-1a: stamped assets are runtime-hash-verified at startup (missing → `BUILD_IDENTITY_MISMATCH`); FIX-1b: the pipeline BLOCKS null-stream dispatches by default (`VC_NULL_STREAM_JOINS_DISABLED` + per-join `VC_JOIN_BLOCKED_NULL_STREAM`, honest deterministic failure; opt-in via `VC_ALLOW_NULL_STREAM_JOIN=1`) |
| RC-2 | HIGH | The targeted query returning OTHER participants (1,215× `TARGETED_EMPTY_RESULT`) never recorded the FIX-L absent-streak → stuck UNKNOWN forever | FIX-2: the no-match branch records the same streak (threshold + call_id-stability guards unchanged) → converges to `VC_PARTICIPATION_ABSENT_VIA_TARGETED_NO_MATCH` after 3 sustained negatives |
| RC-3 | CRITICAL | ~1024 FDs accumulated over ~6h → 4,811× Errno 24 → 3.2h zombie death spiral. Bot-Python paths PROVEN clean offline (300 join cycles + 1000 writes → ΔFD=0); the native join-stack is the remaining suspect | FIX-3: `FD_CENSUS total/soft/sockets/pipes/files/anon` on every 60s heartbeat + `VC_FD_GUARD_CRITICAL`/`VC_FD_GUARD_RESTART` (graceful SIGTERM restart at ≥85% on two consecutive confirmations; `VC_FD_GUARD_RESTART=0` disables) + FIX-1 kills the churn source + `LimitNOFILE=4096` in the service unit (documented operational margin, NOT the fix) |
| RC-4 | HIGH | (a) 345 reconnects / 2.3h (~19s cadence): storm exceptions classified `unknown` → short ladder forever; (b) 140 account reconnects at EXACTLY 60s: `_save()` OSError escaped before `fail_count`++ → documented 60/300/900 ladder never engaged; (c) 344 generations created, ZERO retired | FIX-4a: `classify_failure` maps "Too many open files"/"Connection to Telegram failed N time(s)"/OSError → `NETWORK_UNREACHABLE` (long ladder); FIX-4b: sustained failures (≥8) escalate to the long ladder regardless of class (still bounded ≤60s+jitter, never gives up); FIX-4c: the loop's exception handler increments `fail_count`; FIX-4d: terminal generations pruned (`MTPROTO_GEN_PRUNED`, cap 8/session) |
| RC-5 | HIGH | Reconcile verification used the cluster ROUTER's client for global-scope records (128× CHANNEL_INVALID redetect failures + scope flip-flop), and `account_id="global"` resolved through the cluster → instant no-client UNKNOWN with NO query | FIX-5a/5b: global records verify through the GLOBAL backend's OWN bound client (the v99 §3 identity chain) in BOTH `vc_verify_target` and `vc_check_telegram_participation`; a real account with no client → honest `account_client_unavailable` unknown (never the router pick) |
| RC-6 | MEDIUM | Heartbeat/snapshot failures logged at DEBUG — the operator saw nothing at INFO+ for the entire death spiral | FIX-6: `BOT_HEARTBEAT_WRITE_FAILED` raised to ERROR (rate-limited 1/5min) |
| RC-7 | LOW | Deterministic leaks: `document=open(...)` never closed (1 FD/admin export); ffprobe/ffmpeg children not killed on timeout | FIX-7a/b/c: with-block close + `proc.kill()`+reap on timeout |

**Verification**: focused v99.02 suite 44/44 (each guard FAILS on the
reintroduced bug — 12 failures observed with all fixes reverted, then
green restored); v99.00 pipeline 38/38; **full suite 1,944 passed /
0 failed** (= v99.01's 1,896 + 44 new − 4 test-count adjustments);
drivers: fastpath 16/16, v98.12 15/15, leave 11/11, entity 10/10;
fresh-extraction run identical; offline stress validation
(`tools/v9902_stress_validation.py`): FD Δ=0 across 250 gate-blocked +
40 null-stream joins + 2000 writes, generation registry bounded at 9
after 60 failed cycles, sustained-failure backoff 58–69s (vs the
production 8.5s at failures=103).

### v99.02 semantics — unchanged and honest
* `UNKNOWN` stays `UNKNOWN` when verification is inconclusive — the
  convergence fix (FIX-2) still requires THREE sustained negatives with a
  stable call_id before declaring absence.
* `VC_JOIN_SUCCESS` is emitted ONLY on `telegram_verified=true
  verify_result=present` (positive Telegram-side participant evidence).
* The null-stream gate (FIX-1) converts proven-useless churn into an
  honest deterministic failure — it NEVER fabricates success. With the
  asset properly deployed, joins use the REAL silent stream and verify
  normally.
* Account identity binding, entity/access-hash isolation, dedup
  single-flight, phantom recovery and rotation: unchanged.

### Log markers after v99.02 (monitor these)
* `BUILD_IDENTITY_VERIFIED … modules=10 assets=1` — clean deployment
  (a MISSING asset now fails this line loudly: RC-1 can never recur
  silently).
* `VC_NULL_STREAM_JOINS_DISABLED` (one-time CRITICAL) +
  `VC_JOIN_BLOCKED_NULL_STREAM` (per blocked join) — the deployment is
  missing the silence asset OR the pytgcalls build cannot construct an
  AudioStream; FIX the deployment (do not silence).
* `FD_CENSUS total=… sockets=… pipes=… files=…` on every BOT_HEARTBEAT —
  the FD budget by class; a growing `sockets` count with join activity
  confirms the native-transport leak hypothesis directly.
* `VC_FD_GUARD_CRITICAL` / `VC_FD_GUARD_RESTART` — ≥85% of the FD budget
  consumed; the second marker means a graceful self-restart was requested
  (the supervisor brings the bot back within ~10s).
* `MTPROTO_GEN_PRUNED` — the generation registry self-bounds during
  reconnect storms.
* `VC_PARTICIPATION_ABSENT_VIA_TARGETED_NO_MATCH` — sustained targeted
  negatives converged (the rejoin machinery may now engage for that chat).
* `MTPROTO_RECONNECT_BACKOFF cls=network_unreachable wait=…` — the storm
  exceptions now take the LONG ladder (was `cls=unknown` at ~16s forever).

## Historical: What Changed in v99.01 — SYNC-BOOKKEEPING + BUILD-IDENTITY FIXES

The v99.00 deployment log (bot-diagnostic.log, 2026-09-09 15:39–15:5x)
showed the pipeline working end-to-end but every unverified-join
bookkeeping step dying with **29× `TypeError: object NoneType can't be
used in 'await' expression`** (logged as `VC_PIPELINE_RECORD_UNVERIFIED
exc=TypeError…`).

**Root cause (FIX-A):** `vc_pipeline.py`'s `_record_unverified()` — and
latently `_on_verified()` — called the voicechat.py §35 evidence registry
with `await _vc_record_verify_evidence(...)`, but that function is
**synchronous** (plain `def`, returns `None`, called synchronously at all
six voicechat.py sites). Python evaluates the sync call, then awaits
`None` → TypeError. The old `except TypeError` "older signature"
fallback awaited AGAIN and re-raised the same error; the outer
except-Exception guard swallowed it — which is also why the 1,889-test
v99.00 suite stayed green (the mock harness's evidence function is sync
too; no test asserted on the swallowed DEBUG log).

**The fix:** the synchronous bookkeeping function is now called
synchronously in both `_on_verified()` and `_record_unverified()`; the
bogus await/except-TypeError workaround is removed; the outer
except-Exception guards stay (they bound genuine bookkeeping faults).

**Impact of the old bug (not cosmetic):**
* unverified joins lost their structured weak-evidence record (the
  registry `state=unknown` survived, but the §35 evidence trail was
  aborted) — 29× in that session;
* on the VERIFIED path (latent, never triggered — 0 successes in that
  session) the same TypeError would have aborted the block BEFORE
  `_vc_entity_negative_clear_for_chat()` ran, skipping the RC-C
  entity-negative hygiene right after a verified join.

**Also fixed (FIX-B) — build-identity false mismatch:** the same log's
startup line was `BUILD_IDENTITY_MISMATCH … [vc_pipeline.py: stamp=…
actual=?]` on a CLEAN deployment: v99.00 added vc_pipeline.py to the build
STAMP but not to bootstrap's startup runtime-hash map, so the §21 identity
check reported a false mismatch on every clean start (the same class as the
v98.12 FIX-ID `__init__.py` incident). bootstrap.py now hashes vc_pipeline.py
at startup like every other stamped module, and the `DEPLOYMENT_IDENTITY`
line additionally carries `vc_pipeline_sha256=<hash>`. A REAL modification
of the packaged pipeline still mismatches — the §21 guarantee is restored,
not weakened.

**Also added — durable regression guards (7 new tests):** the
sync-bookkeeping contract (4 tests: behavioural log-capture proof the
TypeError class is gone, exactly-once evidence recording, UNKNOWN-stays-
UNKNOWN, negative-cache hygiene on the verified path, source guards) + the
build-identity contract (3 tests: pipeline hashed at startup, identity line
carries the pipeline hash, and a generalized every-stamped-module-has-a-
runtime-hash audit) + a durable await-audit (every symbol awaited anywhere
in vc_pipeline.py must be `async def` in the pipeline/voicechat/mtproto
sources — the full manual audit found no other sync/async mismatch).

Verification: focused suite 38/38; v98.12/v98.13 regression 71/71 + 57/57;
drivers 16/16 + 15/15 (identity v99.01); **full suite 1,896 passed /
0 failed / 4 skipped** (= the v99.00 baseline 1,889 + the 7 new FIX-A/FIX-B
tests — no test was weakened/deleted/skipped); fresh-extraction run from
the rebuilt ZIP: identical. Every new test provably FAILS on the old code
(bugs temporarily reintroduced: FIX-A 4/4 failed, FIX-B 3/3 failed →
fixes restored: all pass).

### v99.01 semantics — unchanged and honest
* `UNKNOWN` stays `UNKNOWN` when Telegram verification is inconclusive.
* `VC_JOIN_SUCCESS` is emitted ONLY on `telegram_verified=true
  verify_result=present` (positive Telegram-side participant evidence).
* Local call-container membership is NEVER proof of participation.
* Account identity binding, entity/access-hash isolation, dedup
  single-flight, phantom recovery and rotation: unchanged.

### Open runtime question (honest, NOT claimed fixed by v99.01)
The v99.00 deployment log's 29 unverified joins ended
`verification_result=unknown` because the targeted participant query
returned truncated/empty pages (`VC_PARTICIPATION_TARGETED_EMPTY_RESULT …
complete=False reason=truncated_or_incomplete`). v99.01 repairs the
bookkeeping TypeError — it does NOT reinterpret those as success. If a
future deployment still reports UNKNOWN verification, that is the
honest state; investigate the participant-query page completeness
against live Telegram (needs live credentials — external to this
artifact).

### Log markers after v99.01
`VC_PIPELINE_RECORD_UNVERIFIED exc=TypeError: object NoneType can't be
used in 'await' expression` must no longer appear (29× in the v99.00 log).
The marker `VC_PIPELINE_RECORD_UNVERIFIED` itself remains as the guard for
GENUINE bookkeeping faults (e.g., registry write failures) and should be
monitored. At startup, `BUILD_IDENTITY_VERIFIED … modules=10` is now the
expected state on a CLEAN deployment (the v99.00 log's false
`BUILD_IDENTITY_MISMATCH [vc_pipeline.py … actual=?]` is fixed — FIX-B);
if it still says MISMATCH, the deployed tree was genuinely modified after
packaging. All other v99.00 markers unchanged (`VC_ATTEMPT_FINAL`,
`VC_JOIN_UNVERIFIED`, `VC_PIPELINE_STATE`, …).

## Historical: What Changed in v99.00 (superseded by v99.01, preserved)

v98.13 stopped REPORTING local-container joins as success (honest), but the
bot still could not reliably JOIN: 33/33 transport-accepted joins had ZERO
Telegram-side participants (complete 84–100-participant scans proved
absence), 99× targeted-empty verification results, 46× "Invalid channel
object" cross-account poisonings, and no recovery at the join boundary.

**This is a REDESIGN, not a patch.** A new canonical module
`mediagrab_bot/vc_pipeline.py` is now the single authoritative VC join
lifecycle. EVERY entry point — manual `/join`, Join-All (primary +
distributed), Discovery auto-join, watcher, deferred drain, retries and
recovery — funnels through `run_vc_join()` (invoked from
`PyTgCallsBackend.join()`, so no caller can bypass it):

* **RC-A — the transport itself was defective**: `play(chat_id, None)`
  (null-stream) fills the LOCAL container but never registers a
  Telegram-side participant. Joins now dispatch with a REAL silent
  `AudioStream` over the bundled `mediagrab_bot/assets/vc_silence_600s.opus`
  (600s, loop=best-effort); the null-stream is only the alternating
  fallback during bounded phantom-join recovery.
* **RC-B — verification identity**: a `VCAccountIdentity` per attempt (the
  EXACT bound client, user_id from THAT client's `get_me`, backend, entity
  scope). The router-pick/global-user-id fallbacks that queried the WRONG
  account are removed. Rotation swaps the identity ATOMICALLY.
* **RC-C — cross-account entity poisoning** ("Invalid channel object"):
  scope-annotated flat cache mirror, stable scope-token cache keys,
  foreign-hash replay guard, and on CHANNEL_INVALID: evict → fresh
  resolve on the SAME account without the poisoned hash → rebuild
  InputPeer → bounded retry.
* **RC-D — phantom-join recovery**: transport accepted + Telegram-absent
  now triggers the full protocol (stop stale local call → release state →
  refresh entity → alternate transport strategy → bounded backoff →
  account rotation when appropriate → honest terminal state).
* **Formal state machine** with validated transitions:
  `DISCOVERED → RESOLVING → RESOLVED → JOINING → TRANSPORT_ACCEPTED →
  TELEGRAM_VERIFYING → JOINED_CONFIRMED` (+ failure states). The local
  calls container can NEVER transition directly to JOINED_CONFIRMED.
* **§18 KB-FASTPATH preserved**: callers providing (call_id, access_hash)
  — every production caller — pay ZERO extra RPCs on the critical path;
  attempts ≥ 2 re-detect fresh on the joining account.
* **Per-(account, chat) single-flight**: concurrent duplicate joins
  coalesce into ONE JoinGroupCallRequest.
* **Observability**: every attempt emits `VC_ATTEMPT_FINAL` with the full
  field set (access-hash FINGERPRINT only — raw hashes/session strings/
  API hashes/bot tokens are never logged).
* **Dead code removed**: the v98.13 join-local gate + coalescing-lock
  layer (superseded; tombstoned) — nothing outside the pipeline can run
  a join-time verification path.

Verification results: **1,889 tests passed / 0 failed / 4 skipped**;
drivers 16/16 (fastpath) + 15/15 (v98.12); pristine v98.13's 55
pre-existing failures all resolved. See `PATCH_MANIFEST_v99.00.txt` for
the complete root-cause/fix/test accounting.

### Operation notes
* Env knobs (defaults): `VC_JOIN_PIPELINE_MAX_ATTEMPTS=3`,
  `VC_JOIN_PIPELINE_MAX_ACCOUNTS=2`, `VC_JOIN_ENTITY_RETRIES=2`,
  `VC_JOIN_TG_VERIFY_ATTEMPTS=3`, `VC_JOIN_TG_VERIFY_BACKOFF_BASE=1.0`,
  `VC_JOIN_TG_VERIFY_BUDGET=12`, `VC_JOIN_DC_MAX_RETRIES=2`,
  `VC_JOIN_DC_BACKOFF_BASE=2.0`, `VC_JOIN_RECOVERY_BACKOFF_BASE=2.0`,
  `VC_MULTI_JOIN_TIMEOUT=30`, `VC_SILENCE_ASSET` (override path).
* New log markers to monitor: `VC_PIPELINE_STATE`,
  `VC_PIPELINE_CALL_IDENTITY_FASTPATH`, `VC_PIPELINE_STALE_CONTAINER`,
  `VC_PIPELINE_PHANTOM_RECOVERY`, `VC_PIPELINE_ACCOUNT_ROTATED`,
  `VC_PIPELINE_COALESCED`, `VC_PIPELINE_TRANSPORT_RETRY`,
  `VC_SILENCE_STREAM_READY`, `VC_IDENTITY_RESOLVED`, and the per-attempt
  summary `VC_ATTEMPT_FINAL`.
* Success now means: `VC_JOIN_SUCCESS … telegram_verified=true
  verify_result=present` — the account is in the Telegram-side
  participant list. `VC_JOIN_UNVERIFIED` is the honest unknown (state
  preserved for the reconcile scan). The silence asset must ship with
  the deployment (stamped; absence degrades to verify-only null-stream).

## Historical: What Changed in v98.13 (superseded by v99.00, preserved)
See PATCH_MANIFEST_v98.13.txt — the join-time Telegram-side participant
verification gate, typed `VCJoinUnverifiedError`, Interdc backoff,
per-(account, chat) dedup, and the pytgcalls==2.3.3 pin. All preserved
by the v99.00 pipeline (the gate/dedup wrappers themselves were removed
as dead code — their contracts live in vc_pipeline.py).

## Historical: What Changed in v98.00 (superseded, preserved for reference)

## Source Version (v98.00 — historical)
- **Version**: v98.00
- **Supersedes**: v97.99 (backend-connected ID-form mismatch fix — preserved)

## What Changed in v98.00 (historical)
24/7 production VC reliability fix for a REAL production incident that
PERSISTED through v97.95/v97.96/v97.97/v97.98/v97.99: "After the bot
successfully joins multiple active Telegram Voice Chats, it later
automatically leaves some/all active Voice Chats without the operator
requesting a leave. When the bot subsequently attempts to join those Voice
Chats again, it may incorrectly believe it is already connected, skip the
actual join operation, or otherwise fail to rejoin."

**CRITICAL: this release INVALIDATES the v97.99 conclusion.** The v97.99
release claimed "the bot NEVER actually left — STATE CORRUPTION from a
false-negative ID-form mismatch." The v97.99 production runtime
(bot-diagnostic (14).log) proves the bot DID actually leave: a
`GetChannelsRequest` API error in `vc_verify_target` (voicechat.py:5917-5994)
was misclassified as "confirmed absent", which triggered the reconcile LEFT
path → v97.98 FIX-A `_vc_cleanup_stale_backend_call` → `backend._leave_target()`
— **actively killing the REAL PyTgCalls container object based on a transient
API error**. This violated the v97.95 invariant "UNKNOWN never destructive".

Runtime-PROVEN root cause (bot-diagnostic (14).log):
- 129 VC_JOIN_SUCCESS events (bot joined 129 VCs over 04:29–04:46)
- PyTgCalls container grew to 16 chats, then **shrank to 6** (10 chats lost)
- **47 VC_STALE_JOINED_RECORD events** for chats whose `get_entity` FAILED
  with "Invalid channel object (caused by GetChannelsRequest)" →
  misclassified as `VC_PARTICIPATION_CALL_ENDED` → `CONFIRMED_ABSENT` → LEFT →
  `backend._leave_target()`.
- The 6 survivors had `get_entity` SUCCEED → `vc_detect_active_call` found
  the call → `vc_check_telegram_participation` returned UNKNOWN (truncated) →
  preserved as joined (UNKNOWN invariant held correctly).
- Example: chat 1393246704: 04:29:29 VC_JOIN_SUCCESS (call_id
  -5983949028815838058) → 04:51:08 VC_PARTICIPATION_REDETECT_FAILED
  (GetChannelsRequest error) → 04:51:08 VC_PARTICIPATION_CALL_ENDED
  (misclassified) → CONFIRMED_ABSENT → LEFT → backend._leave_target().

**Plus a NEW v97.99 error:** `UnboundLocalError: cannot access local variable
'gid' where it is not associated with a value` at voicechat.py:9999
(`_vc_join_all_active_worker`). Root cause: a v97.81 FloodWait-deferred log
statement (voicechat.py:~8677) referenced `gid` BEFORE it was assigned by
`gid = g["group_id"]` (16 lines below). When global FloodWait was active on
the FIRST loop iteration, `gid` was unbound. Latent since v97.81; triggered
under v97.99's sustained FloodWait conditions (19 FloodWait events in log 14).

### Fixes (with regression tests in tests/test_v98_00_runtime_fixes.py — 41 tests):

- **FIX-E (PRIMARY, RUNTIME-PROVEN)** voicechat.py:5917-6086
  (`vc_verify_target`): distinguish the THREE `fresh_info is None` cases.
  Track `_redetect_error` explicitly. Only **Case C** (vc_detect_active_call
  returned None — genuine absence after GetFullChannelRequest succeeded) may
  mark `tg_state="absent"` / retire the call_id / set cooldowns. **Case A**
  (client is None) and **Case B** (redetect raised an exception:
  GetChannelsRequest error, VCTransportError, etc.) set
  `tg_state="unknown"` and do NOT retire the call_id — the next reconcile
  cycle retries. This ensures a redetect failure NEVER causes a real VC leave
  (v97.95 "UNKNOWN never destructive" invariant — now actually enforced).
  Genuine absence (Case C) is still fully handled (no weakening of real-
  disconnect detection).
- **FIX-F (HIGH, RUNTIME-PROVEN)** voicechat.py:8744-8812
  (`_vc_join_all_active_worker`): move `gid = g["group_id"]` (and the dedup
  check) to IMMEDIATELY after the cancellation check, BEFORE the FloodWait
  branch that references `gid` in the `VC_TARGET_FLOODWAIT_DEFERRED` log.
  Eliminates the `UnboundLocalError`. Minimal — no behavior change for the
  non-FloodWait path.
- **VERSION BUMPS**: __init__.py v97.99→v98.00, bootstrap.py v97.99→v98.00.

### Preserved (all prior fixes intact, zero behavioral regression):
- v97.99 FIX-C (backend_connected marked-form check) + FIX-D (stale_joined_record
  cleanup wiring) — preserved verbatim
- v97.98 FIX-A (reconcile LEFT container cleanup) + FIX-B (join pre-check
  registry=="left" safety net) — preserved verbatim
- v97.95 record_evidence_absent + mark_unknown wiring — preserved
- v97.96 MTProto cascade fix (per-account lock + forcibly_cancel) — preserved
- v97.97 lifecycle cleanup (remove_account/set_disabled) — preserved
- v97.84/v97.85 backend_connected gate + stale_joined_record detection — preserved

### Proof classification:
- **SOURCE-PROVEN**: FIX-E + FIX-F verified in voicechat.py source
- **TEST-PROVEN**: 41/41 v98.00 regression tests pass; 872/908 full suite pass
  (36 failures are ALL version-assertion tests v97.92-v97.99 — EXPECTED on
  every version bump, same pattern as v97.96/v97.97/v97.98/v97.99)
- **RUNTIME-PROVEN**: root cause verified from bot-diagnostic (14).log
  (47 false-absent cascades, container 16→6, UnboundLocalError at 05:08:28
  and 05:09:05)
- **SOAK-PROVEN**: NO (v97.99 runtime was ~1h23m; v98.00 not yet deployed)
- **24/7-PROVEN**: NO (honest — requires 2-24h real Telegram VC soak test)

---

## Historical: What Changed in v97.99 (superseded by v98.00, preserved for reference)
24/7 production VC reliability fix for a REAL production incident that
PERSISTED through v97.95/v97.96/v97.97/v97.98: "After the bot successfully
joins multiple active Telegram Voice Chats, it later automatically leaves
some/all active Voice Chats without the operator requesting a leave. When
the bot subsequently attempts to join those Voice Chats again, it may
incorrectly believe it is already connected, skip the actual join operation,
or otherwise fail to rejoin."

The v97.98 fix addressed stale PyTgCalls call-container objects, but the
v97.98 production runtime (bot-diagnostic (13).log) revealed a DEEPER root
cause: an ID-FORM MISMATCH in the Join All worker's `_backend_connected`
check (voicechat.py:8788). The check tested only the RAW positive chat ID
(`gid` and `abs(gid)`, redundant for positive `gid`), MISSING the MARKED
form (`-1000000000000 - gid`) that PyTgCalls 2.3.3 stores in its calls
container. For EVERY channel/supergroup, this produced a FALSE NEGATIVE —
`backend_connected=False` even when the container genuinely held the object.
This triggered: false `VC_STALE_JOINED_RECORD` → registry corrupted to
"unknown" + coordinator→UNKNOWN → next join() found the real (NOT stale)
container object via the correct marked-form check →
`VC_JOIN_SKIP_ALREADY_CONNECTED` → bot's state said "not in VC" while the
container object persisted.

**NOTE (v98.00): the v97.99 conclusion "the bot NEVER actually left — STATE
CORRUPTION" is INVALIDATED by bot-diagnostic (14).log. v97.99 correctly
fixed the ID-form mismatch (FIX-C preserved in v98.00), but the v97.99
runtime revealed a DEEPER root cause (redetect-failure misclassified as
absent — see v98.00 FIX-E above).**

Runtime-PROVEN root cause (bot-diagnostic (13).log, chat 2054748259):
03:08:46 VC_JOIN_SUCCESS (marked -1002054748259 stored in container) →
03:17:25 VC_STALE_JOINED_RECORD backend_connected=false (worker checked raw
2054748259 — MISS) → 03:19:29 VC_JOIN_SKIP_ALREADY_CONNECTED (join checked
marked — HIT). 4 chats hit this: 2054748259, 2144563093, 3902917470, 4373897587.

### Fixes (with regression tests in tests/test_v97_99_runtime_fixes.py — 34 tests):

- **FIX-C (PRIMARY, RUNTIME-PROVEN)** voicechat.py:8788: extend the
  `_backend_connected` check to test ALL THREE ID forms (raw, abs, marked).
  Mirrors the join() pre-check (voicechat.py:2995: chat_id + raw_id) and
  _vc_cleanup_stale_backend_call (voicechat.py:5577: _marked + _raw). With
  this fix, the worker correctly detects already_joined for channels and
  does NOT fire false stale detection. The state corruption that caused the
  "automatic leave" + "skip the actual join" is eliminated.
- **FIX-D (DEFENSE-IN-DEPTH)** voicechat.py:~8895: wire
  `_vc_cleanup_stale_backend_call` into the `stale_joined_record` block,
  mirroring the v97.98 FIX-A pattern for the reconcile LEFT block.
- **OBSERVABILITY**: enhance the `VC_STALE_JOINED_RECORD` log to include
  `checked_ids={raw, abs, marked}` + `container_size` + `container_sample`.
- **VERSION BUMPS**: __init__.py v97.98→v97.99, bootstrap.py v97.98→v97.99.

### Preserved (all prior fixes intact, zero behavioral regression):
- v97.98 FIX-A (reconcile LEFT container cleanup) + FIX-B (join pre-check
  registry=="left" safety net) — preserved verbatim
- v97.95 record_evidence_absent + mark_unknown wiring — preserved
- v97.96 MTProto cascade fix (per-account lock + forcibly_cancel) — preserved
- v97.97 lifecycle cleanup (remove_account/set_disabled) — preserved
- v97.84/v97.85 backend_connected gate + stale_joined_record detection — preserved

---

## Historical: What Changed in v97.98 (superseded by v97.99, preserved for reference)
24/7 production VC reliability fix for a REAL production incident reported
against v97.97: "Bot joins a Telegram Voice Chat; after some time it is no
longer actually participating; internal state may still say JOINED; Join All
skips/reuses it." The v97.95 ``record_evidence_absent`` wiring repaired the
coordinator (JOINED→LEFT) on passive-leave detection, but did NOT remove the
stale call object from the PyTgCalls ``calls`` container. PyTgCalls 2.3.3
fires no reliable stream-end callback on passive removal, so the stale object
(with the OLD call_id) persisted. The next join()'s container pre-check found
it and emitted VC_JOIN_SKIP_ALREADY_CONNECTED, skipping the real join and
re-registering the STALE call_id — flipping the coordinator LEFT→JOINED again
with the bot NOT actually in the VC. This DEFEATED the v97.95 fix.

Runtime-PROVEN root cause (bot-diagnostic (12).log, chat 1922822605):
00:26:41 absent confirmed → LEFT (container NOT cleaned) → 00:35:54
container-skip → re-registered stale call_id → coordinator LEFT→JOINED →
00:42:48 absent confirmed AGAIN (stale_state=joined). 16-minute stale window.

### v97.98 Fixes (with regression tests in tests/test_v97_98_runtime_fixes.py — 22 tests):

- **NEW HELPER** (voicechat.py:~5507): ``_vc_cleanup_stale_backend_call``
  removes a stale call object from the PyTgCalls calls container. Mirrors
  ``vc_leave_target``'s backend call pattern (``backend._leave_target``).
  Best-effort; handles both marked and raw chat_id forms. New markers:
  VC_BACKEND_STALE_CALL_CLEANUP_START / CLEANED / CLEANUP_FAILED.

- **FIX-A (PRIMARY, voicechat.py:~6242)**: in ``vc_reconcile_participations``
  cls=="LEFT" block (POSITIVE_ABSENT evidence), AFTER the v97.95
  ``record_evidence_absent``, call ``_vc_cleanup_stale_backend_call`` to
  remove the stale container object at the detection site. This is the ROOT
  fix — ensures the container reflects reality so the next join() does not
  trip on a stale object.

- **FIX-B (SAFETY NET, voicechat.py:~2996)**: the join() container pre-check
  now consults the participation registry BEFORE skipping. If registry
  state=="left" (proven absent), the container object is stale → clean it +
  fall through to the real join (do NOT skip). Only a registry state that
  has NOT been proven absent ("joined"/"unknown") may justify a skip.
  INVARIANT (v97.98): LOCAL OBJECT EXISTS is NEVER treated as equivalent
  to TELEGRAM PARTICIPATION CONFIRMED. New marker:
  VC_JOIN_CONTAINER_STALE_DETECTED.

### Source hashes (v97.98):
| File              | v97.97 → v97.98               | Status     |
|-------------------|------------------------------|------------|
| voicechat.py      | 8692ef87e5a429b4 → f77f9b53432ba81e | CHANGED (FIX-A + FIX-B + helper) |
| utils_real.py     | 8c77e419a8ca848a             | UNCHANGED  |
| config.py         | eb29f9c24d4be5a7             | UNCHANGED  |
| mtproto.py        | ceafebbca42cfd6a             | UNCHANGED (v97.96/v97.97 preserved) |
| bootstrap.py      | 1afac7af69e79d65 → 2e194743122fbe2d | CHANGED (version bump) |
| handlers.py       | 66e97763b171577f             | UNCHANGED  |
| join_all_worker.py| 9b4a104fd078ffce             | UNCHANGED  |
| __init__.py       | 3fc50405120fba6a → ca935df2ff7a2e54 | CHANGED (version bump) |
| vc_state_coordinator.py | 15ede1637f0317fa         | UNCHANGED  |

### Deployment integrity (RESOLVED — carried over from v97.95/v97.96/v97.97):
The v97.93 utils_real_sha256 mismatch is RESOLVED at runtime (v97.94–v97.97
boots show utils_real_sha256=8c77e419a8ca848a matching the ZIP). v97.98 does
NOT modify utils_real.py. Operator must verify post-deploy runtime shows
utils_real_sha256=8c77e419a8ca848a.

See PATCH_MANIFEST_v97.98.txt for the full forensic report.

## What Changed in v97.97
Full codebase lifecycle hardening pass. Implements the v97.97 items
deferred by the v97.96 audit's REMAINING RISKS section (Section H items 1
and 2) plus a packaging fix. The v97.95 VC fix and the v97.96 SQLite fix
are PRESERVED VERBATIM (voicechat.py unchanged; mtproto.py changes are
ADDITIVE — the 4 FIX-1 sites, FIX-2 fail_count, FIX-3 disconnect_account,
and FIX-4 per-account lock are all unchanged).

### Fixes (with regression tests in tests/test_v97_97_runtime_fixes.py — 20 tests):

- **FIX-1 (MEDIUM, BUG-5)**: `_cleanup_client_async` helper for sync entry
  points. `remove_account` (mtproto.py:600) and `set_disabled` (mtproto.py:649)
  previously used fire-and-forget `supervised_create_task(client.disconnect())`
  (the v97.44 fix). That was a LATENT LEAK: no `_forcibly_cancel_telethon_tasks`
  (so the 6 Telethon bg tasks could survive a drain timeout) and no
  `_release_client_session` (so the session-ownership registry retained a
  stale owner, blocking the next `connect_account` with
  SESSION_OWNERSHIP_CONFLICT). The new helper applies the SAME v97.96 BUG-1
  pattern (forcibly_cancel → disconnect → drain → release_session) used by
  `connect_account` (4 paths) and `disconnect_account` (BUG-3). Includes
  the global-`_mtproto_client` guard (v97.9).

- **FIX-2 (LOW, BUG-6)**: orphan detector excludes known-live global client.
  `_log_orphaned_telethon_tasks` previously flagged the global
  `_mtproto_client`'s legitimately-alive 6 bg tasks as "orphans" when a
  CLUSTER client was disconnected (e.g., at shutdown, when PRIMARY is
  intentionally left running). Runtime evidence: bot-diagnostic (9).log
  17:37:08 — `MTPROTO_ORPHAN_TELETHON_TASKS_DETECTED count=6` but 0
  reconnects occurred; the 6 tasks were PRIMARY's global client tasks. The
  detector now excludes tasks belonging to the known-live global client via
  snapshot-ID match + `cr_frame.f_locals["self"] is _mtproto_client` check.
  Observability-only — no behavior change.

- **FIX-3 (packaging)**: exclude `__pycache__/*.pyc` from deployment ZIP.
  The v97.96 ZIP contained 42 `.cpython-312.pyc` files (~1.4MB bloat) but
  runtime is Python 3.13.5 (cp313). Python ignores cp312 .pyc and
  regenerates cp313 on import — no correctness impact, but violates the
  forensic packaging rule. The v97.97 ZIP has 0 .pyc files, size ~1MB
  (restored to pre-v97.96 packaging cleanliness).

### Source hashes (v97.97):
| File              | v97.96 → v97.97               | Status     |
|-------------------|------------------------------|------------|
| voicechat.py      | 8692ef87e5a429b4             | UNCHANGED  |
| utils_real.py     | 8c77e419a8ca848a             | UNCHANGED  |
| config.py         | eb29f9c24d4be5a7             | UNCHANGED  |
| mtproto.py        | 366d5070d962bb59 → ceafebbca42cfd6a | CHANGED (BUG-5 + BUG-6) |
| bootstrap.py      | ff1710b651562191 → 1afac7af69e79d65 | CHANGED (version bump) |
| handlers.py       | 66e97763b171577f             | UNCHANGED  |
| join_all_worker.py| 9b4a104fd078ffce             | UNCHANGED  |
| __init__.py       | d51553f4617f8ea2 → 3fc50405120fba6a | CHANGED (version bump) |
| vc_state_coordinator.py | 15ede1637f0317fa         | UNCHANGED  |

### Deployment integrity (RESOLVED — carried over from v97.95/v97.96):
The v97.93 utils_real_sha256 mismatch is RESOLVED at runtime (v97.94/v97.95/
v97.96 boots show utils_real_sha256=8c77e419a8ca848a matching the ZIP).
v97.97 does NOT modify utils_real.py. Operator must verify post-deploy
runtime shows utils_real_sha256=8c77e419a8ca848a.

See PATCH_MANIFEST_v97.97.txt for the full forensic report.

## What Changed in v97.96
Forensic fix for a SEPARATE secondary-account cascade discovered in v97.95
runtime (bot-diagnostic (8).log + bot (9).log). The v97.95 VC stale-coordinator
fix is RUNTIME-PROVEN working in production (chat 1922822605: 15:07:31 absence
confirmed → 15:38:19 rejoin succeeds with op_gen=2, NO already_joined skip).
This v97.96 release fixes the NEW cascade and is fully ADDITIVE — the v97.95
fix is preserved verbatim.

### Runtime evidence (RUNTIME-PROVEN, bot (9).log + bot-diagnostic (8).log):
The SECONDARY account acc_919006065076 entered a persistent `sqlite_locked`
loop every ~74 seconds for over 1 hour (14:58:03 → 15:56:37+):
```
ACCOUNT_CONNECT_FAILED account_id=acc_919006065076 reason=sqlite_locked
  path=.../cluster_919006065076.session
  exc=OperationalError: database is locked — another process holds the write lock
```
This caused JOIN_ALL_BREAKER to open on TimeoutError x3 ("join timeout after
30s") at 15:39:24, 15:42:22, 15:50:33, 15:53:33 and EVENT_LOOP_LAG_CRITICAL
(10-28s lag).

### Root cause (SOURCE-PROVEN + RUNTIME-PROVEN):
In `connect_account` (mtproto.py:999), the "else: client exists but not
connected" branch (mtproto.py:1094-1122 in v97.95) only called
`_release_client_session` + `self._clients.pop`, but did NOT call
`existing_client.disconnect()` and did NOT `_forcibly_cancel_telethon_tasks`.
The existing client's 6 Telethon background tasks survived, holding the SQLite
write lock. Every subsequent `connect_account` created a NEW TelegramClient
that failed with `OperationalError: database is locked`. The
client_identity CHANGED each iteration (103877824 → 105996704 → 489760883760
→ ...) proving a NEW TelegramClient is created each time while the ORIGINAL
client 103877824 stays alive holding the write lock.

### Amplifier (SOURCE-PROVEN + RUNTIME-PROVEN):
`_classify_connect_exception` (mtproto.py:1411) called
`update_status(STATUS_CONNECTION_FAILED)` on the sqlite_locked path but
NEVER incremented `fail_count`. `_cluster_reconnect_loop` (bootstrap.py:927)
reads `fail_count` to determine backoff (60→300→900s). With fail_count stuck
at 0, the loop retried every 60s forever (runtime: ACCOUNT_RECONNECT_START
fail_count=0 logged on EVERY iteration), amplifying the leaked-tasks cascade.

### Fixes (with regression tests in tests/test_v97_96_runtime_fixes.py — 25 tests):

- **FIX-1 (CRITICAL, BUG-1)**: forcibly cancel old client bg tasks in
  connect_account. 4 paths now call `_forcibly_cancel_telethon_tasks` BEFORE
  `_release_client_session` + `disconnect()`:
  - get_me-failed path (label=cluster_reconnect_getme_fail)
  - else-not-connected path (label=cluster_reconnect_stale) — THE core fix
  - outer-except path (label=cluster_reconnect_except)
  - new-client failure path (label=cluster_connect_failed)
  Reuses the EXISTING `_forcibly_cancel_telethon_tasks` function
  (mtproto.py:5194, v97.79) that is already used by
  `_telethon_drain_and_reconnect_raw` (the safe_reconnect path). CLIENT-SPECIFIC.

- **FIX-2 (MEDIUM, BUG-2)**: increment `fail_count` in
  `_classify_connect_exception` on the 3 STATUS_CONNECTION_FAILED paths
  (sqlite_locked, connection_failed, generic) + reset `fail_count=0` on the
  4 connect success paths. Floodwait and session_revoked do NOT increment
  (they have their own backoff via floodwait_until / require manual
  re-import). Adds `ACCOUNT_SQLITE_LOCKED_BACKOFF` log marker showing
  next_backoff value.

- **FIX-3 (LOW, BUG-3)**: `_forcibly_cancel_telethon_tasks` in
  `disconnect_account` BEFORE `client.disconnect()`. Plugs a latent leak
  where the disconnected-drain future could time out and leave bg tasks alive.

- **FIX-4 (defensive, BUG-4)**: per-account `asyncio.Lock` single-flight
  for `connect_account`. Refactored `connect_account` into a public wrapper
  that acquires the lock + dispatches to `_connect_account_inner`. Prevents
  concurrent callers (manual /reconnect + _cluster_reconnect_loop) from
  creating 2 TelegramClients on the same session file.

### Logging improvements (Phase 8):
- **ACCOUNT_SQLITE_LOCKED_BACKOFF** (account_id, phone, fail_count,
  next_backoff) — logged on every sqlite_locked failure so operators can
  see the next retry delay without re-deriving it from fail_count.
- **ACCOUNT_FORCED_CANCEL_ERROR** — defensive log if _forcibly_cancel raises
  (should never fire, but logs if it does).
- v97.95 markers preserved: VC_LEAVE_CLEANUP_START/COMPLETE,
  VC_STALE_STATE_DETECTED, VC_JOIN_ALL_COORD_SKIP, record_evidence_absent
  / mark_unknown wiring (3 sites in voicechat.py — regression-tested in
  test_v97_96 Section F).

### Deployment integrity (RESOLVED — carried over from v97.95):
The v97.93 utils_real_sha256 mismatch is RESOLVED at runtime (v97.94/v97.95
boots show utils_real_sha256=8c77e419a8ca848a matching the ZIP). v97.96
does NOT modify utils_real.py. Operator must verify post-deploy runtime
shows utils_real_sha256=8c77e419a8ca848a.

### Source hashes (v97.96):
| File              | v97.95 → v97.96       | Status     |
|-------------------|----------------------|------------|
| voicechat.py      | 8692ef87e5a429b4     | UNCHANGED  |
| utils_real.py     | 8c77e419a8ca848a     | UNCHANGED  |
| config.py         | eb29f9c24d4be5a7     | UNCHANGED  |
| mtproto.py        | a2b8cc109cee28c1 → 366d5070d962bb59 | CHANGED |
| bootstrap.py      | a73b395c91cd60d4 → ff1710b651562191 | CHANGED |
| handlers.py       | 66e97763b171577f     | UNCHANGED  |
| join_all_worker.py| 9b4a104fd078ffce     | UNCHANGED  |
| __init__.py       | 9443a2e29c610c4d → d51553f4617f8ea2 | CHANGED |

## What Changed in v97.95
Independent forensic audit of v97.94 runtime logs (bot-diagnostic (7).log +
bot (8).log), triggered by a user-reported production bug: **after BOTH
userbot accounts passively leave a Voice Chat, the next Join attempt is
permanently skipped with reason=already_joined instead of recovering and
rejoining**. See PATCH_MANIFEST_v97.95.txt for the full forensic report.

This is a RUNTIME-PROVEN + SOURCE-PROVEN fix. The v97.94 audit investigated
a DIFFERENT bug (IndexError/log-level/_progress/shutdown-order) and did not
cover the VC state machine. The v97.94 runtime (bot-diagnostic (7).log,
4h across 3 boots) exhibits this bug on v97.94 itself — the v97.94 fixes
did not address this failure mode.

### Fix (with regression tests in tests/test_v97_95_runtime_fixes.py):
- **FIX-VC-1 (voicechat.py:6070/6135/8596)**: VC leave/rejoin permanent
  skip — the VCChatCoordinator (the AUTHORITATIVE state for the
  already_joined skip decision) was NEVER updated on passive VC leave.
  Three detection sites (participation reconcile positive-absence,
  v97.85 stale-joined-record repair, reconcile-timeout) updated ONLY the
  participation registry, leaving the coordinator stuck at JOINED. The
  next Join All attempt was permanently skipped with reason=already_joined.
  The fix wires the 3 sites to the coordinator's idempotent
  `record_evidence_absent()` (→ LEFT) and `mark_unknown()` (→ UNKNOWN)
  methods. Both are safe: record_evidence_absent no-ops on IDLE/LEFT/FAILED/
  CANCELLED; mark_unknown never downgrades LEFT→UNKNOWN (per §19).

  Runtime evidence: chat_id=1922822605 skipped at 10:59:06 (boot #2) and
  12:18:50 (boot #3) after passive leave, despite the participation
  registry correctly showing LEFT/unknown.

### Logging improvements (observability-only, no behavior change):
- **VC_STALE_STATE_DETECTED** — fires at the 3 fix sites when a stale
  JOINED/ACTIVE/VERIFYING state is detected and repaired. Lets the
  operator see EXACTLY when the bug would have occurred and confirm the fix
  fired.
- **VC_LEAVE_CLEANUP_START / VC_LEAVE_CLEANUP_COMPLETE** — bracket the
  manual leave path so the operator can distinguish explicit leave (cleanup
  runs) from PASSIVE leave (no cleanup — the bug fixed by
  record_evidence_absent wiring).

### Deployment integrity (RESOLVED at runtime):
The v97.93 utils_real_sha256 mismatch (runtime=85bcf20b27afbee9 vs
ZIP=8c77e419a8ca848a) is **RESOLVED** — the v97.94 runtime (boots #2 and
#3 in bot-diagnostic (7).log) shows utils_real_sha256=8c77e419a8ca848a,
matching the ZIP. The operator redeployed v97.94 cleanly. v97.95 does NOT
modify utils_real.py. The operator should verify the post-v97.95-deploy
runtime continues to show utils_real_sha256=8c77e419a8ca848a.

## What Changed in v97.94
Independent forensic audit of v97.93 runtime logs (bot-diagnostic (6).log +
bot (7).log). Four SOURCE-PROVEN / RUNTIME-PROVEN bugs fixed + two
observability instrumentations added. See PATCH_MANIFEST_v97.94.txt for
the full forensic report.

Fixes (each with regression tests in tests/test_v97_94_runtime_fixes.py):
- **FIX-1 (voicechat.py:18904)**: `_vc_handle_vc_command` IndexError on
  all-slash messages ("/", "//") — `text.lstrip("/").lower().split()[0]`
  failed when lstrip yielded "". RUNTIME-PROVEN: 3 occurrences in the
  v97.93 runtime log.
- **FIX-2 (voicechat.py:6816)**: inner per-handler exception logger
  promoted from DEBUG to WARNING (the v97.74 promotion only applied to
  the OUTER worker exception). The 3 IndexError events from FIX-1 were
  invisible at INFO+ production logging until this fix.
- **FIX-3 (mtproto.py:6335)**: removed duplicate `_progress` definition
  that shadowed the supervised version (orphan tasks, lost exceptions).
- **FIX-4 (bootstrap.py:1729)**: reordered TaskSupervisor.cancel_all()
  to run BEFORE close_db() (was inverted — DB-after-close race).

Instrumentations (observability-only, no behavior change):
- **INSTRUMENT-1 (mtproto.py health loop)**: MTPROTO_GEN_RETIRING_STUCK
  — logs when generations are stuck in RETIRING (retire_generation is
  dead code; the leak was invisible).
- **INSTRUMENT-2 (mtproto.py mtproto_stop)**: MTPROTO_STOP_RECONNECT_IN_FLIGHT
  — logs if a reconnect is in-flight at shutdown time (stop/reconnect race
  has no RW lock; this proves it if it occurs).

**IMPORTANT — DEPLOYMENT INTEGRITY**: The v97.93 runtime had
utils_real_sha256=85bcf20b27afbee9, but BOTH the v97.92 and v97.93 ZIPs
have utils_real_sha256=8c77e419a8ca848a. Someone modified utils_real.py on
the production server post-deploy. v97.94 does NOT modify utils_real.py.
The operator must:
1. Determine what the server-side utils_real.py modification was.
2. Either commit it to the source tree or revert the server to the ZIP
   version, then redeploy v97.94.

All v97.30-v97.94 fixes are preserved:
- v97.30: FloodWait auto-resume / RW lock
- v97.31: GatedClientProxy / per-cluster locks
- v97.32: Shutdown drain
- v97.33: Raw TelegramClient for PyTgCalls
- v97.34: Bun architecture / async dashboard startup
- v97.35: Entity-error classification
- v97.36: PyTgCalls chat representation
- v97.37: access_hash support
- v97.38: Multi-account authoritative entity recheck
- v97.92: Resolver-account PyTgCalls backend rotation
- v97.93: Cluster client health monitoring + orphaned task observability
- v97.94: vc_command IndexError guard + handler-exception log level +
  duplicate _progress removal + shutdown ordering fix
- v97.95: VC leave/rejoin permanent-skip fix (coordinator state update on
  passive leave) + VC_STALE_STATE_DETECTED / VC_LEAVE_CLEANUP_* logging

---

## Prerequisites

### System Packages (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install -y build-essential gcc g++ cmake make pkg-config \
    git curl wget ffmpeg libffi-dev libssl-dev python3-dev
```

### Python 3.11
The PyTgCalls native wheels require Python 3.11.x (cp311).

```bash
# Using uv (recommended)
curl -LsSf https://astral.sh/uv/install.sh | sh
uv python install 3.11

# Or using pyenv
pyenv install 3.11.15
```

### Bun (for dashboard-live, optional)
```bash
curl -fsSL https://bun.sh/install | bash
```

---

## Installation

### 1. Create the virtual environment
```bash
uv venv /opt/mediagrab-venv --python 3.11
# or: python3.11 -m venv /opt/mediagrab-venv
```

### 2. Install the validated VC dependency stack
```bash
uv pip install --python /opt/mediagrab-venv/bin/python --prerelease=allow \
    "pytgcalls==3.0.0.dev24" \
    "tgcalls==3.0.0.dev6" \
    "ntgcalls==2.2.5"
```

### 3. Install the remaining dependencies
```bash
uv pip install --python /opt/mediagrab-venv/bin/python \
    "telethon>=1.34.0" \
    "python-telegram-bot==21.6" \
    "google-genai>=0.3.0" \
    "httpx>=0.27.0" \
    "aiosqlite>=0.20.0" \
    "python-dotenv>=1.0.0" \
    "Pillow>=10.0.0" \
    "qrcode>=7.4" \
    "aiofiles>=23.2.0" \
    "cryptg>=0.4.0"
```

### 4. Verify the native stack loads
```bash
/opt/mediagrab-venv/bin/python -c "
import pytgcalls, tgcalls, ntgcalls
print('pytgcalls', pytgcalls.__version__)
print('ntgcalls', ntgcalls.__version__)
from google import genai
print('google.genai OK')
import cryptg
print('cryptg OK')
"
```

### 5. Configure the bot
```bash
cd /opt/mediagrab
cp .env.example .env
# Edit .env with your production credentials
nano .env
```

### 6. Generate fresh Telegram sessions
```bash
# The bot creates sessions on first startup. Log in interactively:
/opt/mediagrab-venv/bin/python -m mediagrab_bot
# Follow the prompts to authorize your Telegram account(s).
```

**IMPORTANT**: Generate sessions ONLY on the production server. Do NOT copy
session files from another server — Telegram invalidates sessions used from
multiple IPs (AuthKeyDuplicatedError).

---

## Optional Components

### Dashboard-Live (WebSocket monitoring service)
The dashboard-live is a **separate Bun/Node.js application** that is NOT bundled
with this source. The bot's source code includes the spawning infrastructure
(`handlers.py:2352-2379`, `bootstrap.py:926-932`) which expects the service at:
```
mini-services/dashboard-live/
```
If this directory does not exist, the bot logs a non-fatal warning
(`DASHBOARD_LIVE_SPAWN_FAILED — dir not found`) and continues normally.

To enable dashboard-live, create the `mini-services/dashboard-live/` directory
with a Bun-based WebSocket server on port 3003. The bot will auto-spawn it.

### Local Bot API Server (removes 20MB download ceiling)
The bot supports a self-hosted Telegram Bot API server. To enable:
1. Build `telegram-bot-api` from https://github.com/tdlib/telegram-bot-api
2. Start it on `127.0.0.1:8081`
3. Set in `.env`:
   ```
   LOCAL_BOT_API_ENABLED=true
   LOCAL_BOT_API_URL=http://127.0.0.1:8081
   ```

If disabled, the bot uses the cloud Bot API (api.telegram.org).

---

## Running the Bot
```bash
cd /opt/mediagrab
/opt/mediagrab-venv/bin/python -m mediagrab_bot
```

## Shutdown
Send SIGTERM or SIGINT. The bot performs graceful shutdown:
- Stops all background workers (watchdog, reconcile, cleanup, etc.)
- Disconnects MTProto/Telethon
- Stops PyTgCalls backend
- Closes the database
- 0 remaining tasks on clean exit

**Never use `os._exit()` or `SIGKILL` on a running bot with active Telethon
connections** — this leaves ghost connections that invalidate sessions.

---

## Security Notes
- The deployment artifact contains NO real credentials.
- The `.env.example` has placeholder values only.
- No Telegram session files are included.
- No API keys, bot tokens, or API hashes are in the source.
- Generate all credentials fresh on the production server.
- If any API keys were exposed during testing, rotate/revoke them before production use.

---

## 24/7 Supervision (v98.08 FIX-XX) — MANDATORY for production

The v98.07 soak proved the canary works (wedge detected → dump written →
exit(86) at 17:23:43) but the bot stayed DOWN until a human restarted it.
v98.08 ships a systemd supervisor; install it on the production host:

```bash
cd /root/gr                      # the extraction target (WorkingDirectory)
bash deploy/install_supervisor.sh
```

The installer runs these steps explicitly (v98.09: documented verbatim —
do NOT assume systemd is installed/active; verify each step):

```bash
# 1) Prerequisites: verify systemd is PID 1 and the unit file is present.
ps -p 1 -o comm=                 # must print: systemd
ls -l /root/gr/deploy/mediagrab.service

# 2) Install the unit into systemd and reload the manager.
sudo cp /root/gr/deploy/mediagrab.service /etc/systemd/system/mediagrab.service
sudo systemctl daemon-reload

# 3) ENABLE (start at boot) and START (run now).
sudo systemctl enable mediagrab
sudo systemctl start mediagrab

# 4) Verify supervision is ACTIVE.
systemctl is-enabled mediagrab    # → enabled
systemctl is-active mediagrab     # → active
systemctl status mediagrab        # → MainPID=…; journal tail
```

If `ps -p 1 -o comm=` does not print `systemd` (container/WSL1/minimal
VPS), the unit cannot supervise the bot — use the provided fallback
(`Restart=always` wrapper or a cron `@reboot` watchdog) and state so in
the operations log. The 2026-09-01 incident log shows
`BOT_SUPERVISOR_DETECTED supervisor=none restart_policy=manual` on every
restart — each canary exit(86) left the bot DOWN until a human noticed.

What you get:
- `Restart=always`, `RestartSec=10`, `StartLimitIntervalSec=0` — any exit
  (canary 86, crash, clean 0) restarts within ~10s.
- Exit-code contract: **86 = VC_HEARTBEAT_CANARY_TRIGGERED** (hard event-loop
  wedge — the dump `vc_canary_dump_<pid>.txt` is retained next to
  `bot-diagnostic.log` and logged as `VC_HEARTBEAT_CANARY_DUMP_WRITTEN`);
  0 = clean.
- Boot logs `STARTUP_RECOVERY prev_pid=… uptime_prev=… supervisor=systemd`
  and `BOT_SUPERVISOR_DETECTED` — downtime is measurable from the log.
- SIGUSR1 thread dump: `kill -USR1 $(systemctl show -p MainPID --value mediagrab)`.
- Journal forensics: `journalctl -u mediagrab | grep 'status=86'`.

Without this unit, the bot logs
`BOT_SUPERVISOR_DETECTED supervisor=none restart_policy=manual — bot is NOT
supervised` at every boot. Do not run 24/7 production un-supervised.

Optional canary webhook (JSON POST, bounded 10s):
```
Environment=VC_CANARY_NOTIFY_WEBHOOK=https://your/hook
```


## ⚠⚠ v99.05 — THE FINAL REBUILD (READ FIRST)

v99.05 is not a patch release. The 2026-09-12 v99.04 production log
(bot-diagnostic (2).log) was the first run that reached the VC transport
layer, and it proved the exact opposite of what every previous report
assumed:

- **The joins were REAL.** For all 3 attempted chats × 3 attempts, the
  targeted `ids=[self]` participant query returned a NON-EMPTY participant
  list — the account WAS a Telegram-side participant Telegram-side each
  time.
- **The verifier was BLIND.** Telethon's `GroupCallParticipant` identifies
  the participant via `peer` (PeerUser/PeerChannel/PeerChat) — it has NO
  `user_id` attribute. Every matching site read `getattr(p, "user_id")`,
  which is always `None`: presence was UNDETECTABLE since v98.01. That is
  why `VC_PARTICIPATION_PRESENT` never appeared in ANY production log.
- **The bot destroyed its own working joins 9 times.** The blind "no
  matching participant" was streak-escalated to "authoritative absence";
  the phantom recovery issued `leave_call` and cleaned up a REAL join,
  three times per chat, then reported `VCTransportError: PROVEN absence`.

### What v99.05 changes (the six confirmed root causes)

| RC | Root cause (2026-09-12 evidence) | The fix |
|----|----------------------------------|---------|
| F1 | Blind participant matching (`user_id` vs `peer`) | Peer-based matcher at ALL sites + `is_self` |
| F2 | Foreign-result → absent streak escalation | Removed: foreign answers are UNKNOWN forever; only the EMPTY direct answer converges (FIX-L streak) |
| F3 | Absent path re-registered `state=joined` + "join PRESERVED" (phantom bookkeeping) | The pipeline is the single writer; cleanup logs `VC_JOIN_CLEANUP_REASON` |
| F4 | GroupcallInvalid mapped to ABSENT; id-only "identity refresh" | STALE_CALL verdict + evidence flag; (id, access_hash) PAIR comparison; verify-time identity hygiene (re-detect → adopt → re-verify) |
| F5 | `__primary__` string values; dual-role file invisible in cluster counts | Dict schema; distinct-account counting with `roles=primary,cluster` |
| F6 | No attempt correlation; success without evidence | `attempt_id` on every stage event; `VC_JOIN_SUCCESS` carries verification_method / participant_identity / verification_timestamp / rpc_result |

### What the NEXT production log must show (the acceptance signatures)

1. `VC_ATTEMPT_START attempt_id=…` → … → `VC_ATTEMPT_FINAL attempt_id=…`
   (one correlation id per join attempt, all stage events carry it).
2. `VC_PARTICIPATION_PRESENT … participant=[peer=PeerUser(<your_id>) …]`
   — presence is now VISIBLE (this line has never fired in production
   before v99.05).
3. On a real successful join: `VC_JOIN_SUCCESS … telegram_verified=true
   verify_result=present attempt_id=… verification_method=
   telegram_participant_query participant_identity=peer=PeerUser(…)`
   with Telegram-side evidence.
4. If a call rotates mid-join: `VC_CALL_IDENTITY_CHANGED …` (only when
   the (id, access_hash) PAIR actually changed — no more old==new
   "refreshed" noise) followed by a re-verify with the current pair.
5. Honest failures only: `VC_JOIN_UNVERIFIED` when Telegram is
   inconclusive (non-destructive), `VC_JOIN_CLEANUP_REASON
   reason=telegram_absent` only when Telegram's direct answer for your
   exact account id was a sustained negative against the CURRENT call.

### Deployment (unchanged from v99.04 — the .py set is self-contained)

The complete `.py` file set is sufficient: `asset_embedded.py` carries the
silence asset (sha256-verified against the build stamp on every boot;
self-heal re-extracts it if the binary asset is missing). Extract the
full ZIP when possible — the RC-9 ZIP heal path still works when one
exists.

### Session / account notes (v99.05)

- `accounts.json`'s `__primary__` entry is now `{"account_id": "…"}`
  (the legacy bare-string form is migrated transparently on read).
- `/v85accounts` (and the heartbeat `ACCOUNT_SESSION_HEALTH` line) now
  count DISTINCT registered accounts: a session file that is both the
  global primary AND a registered cluster account shows
  `roles=primary,cluster` and counts ONCE (`cluster_accounts=1
  expected_cluster=1`); with a second real account:
  `cluster_accounts=2 expected_cluster=2`.
- `/cluster add <phone>`: a live-authorized session for that phone is
  REGISTERED (client reuse) instead of dead-ending at
  "already_connected"; the OTP flow persists + registers new accounts.

### Honest limits (unchanged)

The live Telegram VC transport (real join → real group-call RPC → real
transport → real verification → VC_JOIN_SUCCESS) is verified by tests
against REAL-shape Telethon objects and the full pipeline harness — but
the sandbox has no live Telegram credentials/network, so the LIVE
acceptance (`VC_JOIN_SUCCESS > 0` with real Telegram evidence) can only
be proven by the next production run. If the signatures above do not
appear in that log, ship the log back — the correlation ids make every
attempt reconstructable without guessing.

---

## ⚠⚠ v99.06 — THE UNIFIED THREE-FIX RELEASE (READ FIRST)

v99.06 fixes the three root causes that made the MULTI-ACCOUNT era dead
on arrival (the 2026-09-09 v99.01 production log, 23,888 lines — every
fix is log-evidence + source-verified; see PATCH_MANIFEST_v99.06.txt):

1. **The scope chameleon (388× CHANNEL_INVALID)** — the scope token
   `"global"` always meant "whatever the current primary is". After a
   rotation the NEW primary consumed the OLD primary's access hashes →
   "Invalid channel object" ×388, and the rotation purge reached ZERO
   entries (`ENTITY_CACHE_CLEARED … entries_removed=0`).
   **v99.06**: every cache key / scope token / ownership comparison
   binds to the CURRENT primary's REAL account id
   (`get_primary_account_id()`); rotation purges the old owner's
   entries pre-swap; a stored "global" entry is translated before
   routing and NEVER consumed by a rotated-in primary.
2. **Discovery starvation (queries_done=0)** — one shared 90s wall cap
   consumed by the primary; every additional account ran ZERO queries.
   **v99.06**: every eligible account runs its OWN budget concurrently
   (`VC_DISCOVERY_PARALLEL_ACCOUNTS=true`,
   `VC_DISCOVERY_PER_ACCOUNT_CAP=90`).
3. **Join-All pinning + no ownership gate** — every target pinned to
   the first healthy account; nothing prevented two accounts from
   joining the same group. **v99.06**: round-robin distribution across
   eligible accounts (`VC_JOIN_DISTRIBUTION=round_robin`) + a HARD
   one-group-one-account gate in `run_vc_join`
   (`VC_JOIN_ONE_GROUP_ONE_ACCOUNT=true`): a second account is refused
   BEFORE any entity-resolution RPC (zero wasted RPCs), and registry
   ownership transfers only from a terminal non-joined state.

### The v99.06 log signatures (what the next production run MUST show)

- On boot with ≥2 registered accounts, discovery cycles:
  `VC_DISCOVERY_PARALLEL_LAUNCHED accounts=N …` then per account
  `VC_DISCOVERY_ACCOUNT_START account=acc_… queries_planned=… cap=90s`
  and `VC_DISCOVERY_ACCOUNT_DONE account=acc_… queries_done>0` for
  **EVERY** account (the v99.01 signature `queries_done=0` is the
  regression signal), closing with `VC_DISCOVERY_PARALLEL_CYCLE
  accounts=N duration_s=…` (duration ≈ max, not sum).
- Join-All: `VC_JOIN_ALL_DISTRIBUTION_ENABLED eligible=N
  accounts=acc_…,acc_…` and per target
  `VC_JOIN_ALL_TARGET_ACCOUNT_SELECTED chat_id=… account=acc_…`;
  the `VC_JOIN_DISTRIBUTION` summary now shows MULTIPLE accounts with
  `confirmed>0`.
- The invariant firing: `VC_GROUP_OWNER_RESOLVED chat_id=… owner=acc_…
  source=registry|active_backend`, and on any second-account attempt
  `VC_JOIN_SKIPPED_ALREADY_OWNED chat_id=… owner=acc_… requester=acc_…`
  followed by the `VCTransportError … one-group-one-account invariant`
  transport error (this is the gate WORKING, not a failure).
- Every primary rotation: `ENTITY_CACHE_CLEARED account=acc_…
  entries_removed>0` (the acceptance proof the purge reaches the
  entries — `entries_removed=0` is the regression signal). The FIRST
  rotation after upgrading from a pre-v99.06 tree also logs
  `VC_SCOPE_ALIAS_MIGRATION removed_scoped=N removed_flat=N` (one-time
  legacy chameleon purge).
- If an operator disables the invariant:
  `VC_INVARIANT_DISABLED one_group_one_account=false …` at boot
  (WARNING).

### Session / account notes (v99.06)

- `accounts.json` schema unchanged from v99.05 (`__primary__` is the
  `{"account_id": …}` dict).
- The registry now enforces exactly ONE owning account per chat:
  a verified join by a different account is refused
  (`VC_REGISTRY_OWNER_REFUSED`) until the current owner reaches
  `left`/`unrecoverable`.

### Honest limits (v99.06, unchanged in kind)

Same as v99.05: the full pipeline, the three fixes, and the ownership
gate are verified by 2,108 automated tests (incl. the unified suite's
REAL `set_primary_id()` rotations) and the packaged-artifact production
reproducer sim — but this sandbox has no live Telegram credentials, so
the LIVE acceptance (`VC_JOIN_SUCCESS > 0` with real Telegram evidence
on MULTIPLE accounts) can only be proven by the next production run.
If the signatures above do not appear in that log, ship it back — the
correlation ids + ownership markers make every attempt reconstructable
without guessing.

## v99.10 — Stability Repair (2026-09-20)

### What this release fixes (from the 2026-09-20 production log)

The v99.09 run joined and Telegram-VERIFIED up to 64 VCs across two
accounts (63× VC_JOIN_SUCCESS, 127× VC_PARTICIPATION_PRESENT, 0
unverified) — but the process was **OOM-SIGKILLed twice mid-join**
(11:24:16 after 866s, 11:36:46 after 741s, zero Python traceback), and
after each restart the bot sat **dead idle** (interrupted Join-All
never auto-resumed; auto-discovery admin-disabled; coverage active=0
until a human re-triggered). The "account automatically leaves the VC
while running" symptom was the process death killing every joined
transport simultaneously.

Root causes (full evidence in PATCH_MANIFEST_v99.10.txt):

1. **Resource exhaustion under sustained REAL-stream joins.** Each
   joined VC holds a native ntgcalls media pipeline (~4 UDP sockets +
   threads + SRTP/jitter buffers). At ~60 concurrent joined VCs the
   container ceiling was hit: `[Errno 11] Resource temporarily
   unavailable` ×41 during joins (EAGAIN from native thread/socket
   allocation under memory pressure — NOT fd exhaustion, the census
   was 409/1024), classified as `transient_dc` → retry-hammered 3× in
   6s → TRANSPORT_FAILED + breaker failures → kernel OOM kill.
2. **`is_connected` mutual-recursion** (45× RecursionError on the
   calls_container reader) — the same scalar-pointer ping-pong class
   v99.09 FIX-C killed in verify_joined.
3. **Post-restart dead idle** — interrupted runs never auto-resumed.
4. **Terminal mislabel** — an admin stop reported the stale
   `circuit_breaker_floodwait` cancel reason.
5. **Registry misattribution** — the worker's confirm path wrote a
   duplicate raw-form record under the scalar-pointer account.

### The v99.10 behaviour

- **Resource guard** (env-tunable): `VC_GUARD_MAX_RSS_MB=900`,
  `VC_GUARD_MAX_THREADS=350`, `VC_GUARD_MAX_JOINED=48`,
  `VC_GUARD_FD_RATIO=0.80`. New joins DEFER before dispatch when the
  process is near exhaustion; errno-11/ENOMEM/EMFILE failures classify
  as `resource_pressure` (no retry, no breaker record); the Join-All
  worker WAITS for pressure to clear (10s poll, 600s cap per cycle)
  and keeps its checkpoint — the run survives instead of being
  OOM-killed.
- **MEM_CENSUS** on every heartbeat: `rss_mb`, `threads`, `fd`,
  `joined_transports` — the exhausted resource is now directly
  observable.
- **Auto-resume**: an interrupted (non-admin-stopped) run resumes
  automatically ~75s after boot (`VC_JOIN_ALL_AUTO_RESUME`;
  `VC_JOIN_ALL_AUTO_RESUME=0` disables).
- No recursion, honest terminals (`admin_stop_requested`), one
  registry record per chat with the TRUE owner.

### Acceptance signatures (v99.10)

- `MEM_CENSUS rss_mb=… threads=… fd=…/… joined_transports=…` on every
  `BOT_HEARTBEAT` line.
- Zero `RecursionError` in the whole log.
- Under sustained Join-All: `VC_RESOURCE_PRESSURE …` +
  `VC_JOIN_ALL_RESOURCE_PRESSURE_WAIT …` and
  `deferred_resource_pressure` counts in `VC_JOIN_ALL_PROGRESS` — the
  worker alive, no SIGKILL, no mid-run banner restarts.
- After an unexpected restart: `VC_JOIN_ALL_AUTO_RESUME run_id=…
  result=resumed` within ~90s of boot (unless the run was admin
  stopped: `VC_JOIN_ALL_AUTO_RESUME_SKIPPED … user_stopped=True`).
- Admin stops report `cancel_reason=admin_stop_requested`.
- The v99.09 verification baseline holds: `VC_JOIN_SUCCESS …
  telegram_verified=true` and `VC_PARTICIPATION_PRESENT` on the same
  scale; zero `VC_JOIN_UNVERIFIED`.

### Regression signals

- Any `RecursionError`; `transient_dc` on an `[Errno 11]` line; a
  breaker OPEN caused by a resource-pressure failure;
  `VC_JOIN_ALL_AUTO_RESUME` after an admin stop; VC_JOIN_SUCCESS
  dropping under healthy resources (guard too tight — raise
  `VC_GUARD_MAX_RSS_MB`/`VC_GUARD_MAX_JOINED` for the container).

### One-line admin actions (not defects)

- Enable auto-discovery if continuous background discovery is wanted:
  Admin Panel → enable (or `VC_DISCOVERY_ENABLED=true`) — the
  2026-09-20 log showed `AUTO_DISCOVERY_SKIP reason=effective_disabled
  source=db` (admin-disabled, honest).
- Tune the guard to the container: raise `VC_GUARD_MAX_RSS_MB` /
  `VC_GUARD_MAX_JOINED` for larger containers (defaults keep a 1-2GB
  container alive; the 2026-09-20 death was at ~60 joined VCs).

### Honest limits (v99.10)

Same as v99.09 in kind: 2,194 automated tests GREEN (incl. 43 new
stability-repair tests: the recursion shapes terminated, the errno-11
defer semantics, the guard thresholds, the auto-resume lifecycle, the
sustained-pressure stability run) + static audit UNRESOLVED
critical/high: 0 — but this sandbox has no live Telegram credentials.
The decisive LIVE evidence is the next production run: no SIGKILL
restart banners mid-join, MEM_CENSUS visible, the auto-resume marker
after any restart, and the join-success baseline holding under the
guard's defers.

## v99.11 — Resource-Safety & VC-Persistence Release (2026-09-22)

### What this release fixes (from the 2026-09-21 production logs)

The v99.10 run survived to 47 joined transports and was then
OOM-SIGKILLed — the guard ceiling (48) sat exactly at the observed
crash boundary. For 2.5 hours before the death the operator was
BLIND: zero `BOT_HEARTBEAT` lines (a format-string bug made Python
logging silently drop every record). After restart, SQLite locked
itself for 38 minutes (WAL checkpoint on the shared connection), and
verification burned 2704 requests on "Channel is private" chats while
1480 UNKNOWN verdicts could — on weak evidence — trigger REAL
Telegram leaves of healthy transports.

Root causes (full evidence in PATCH_MANIFEST_v99.11.txt): RC-1 guard
at the crash boundary with no headroom/in-flight/cgroup awareness;
RC-2 heartbeat format-string; RC-3 removed Telethon `get_contacts()`;
RC-4 SQLite self-lock + retention dead-column + dangling txn +
participation-persistence dead code; RC-5 unintended automatic leaves
on weak evidence; RC-6 crash-loop unprotected; RC-7 fragile
checkpoints.

### The v99.11 behaviour

- **Resource admission at the REAL allocation point**
  (`PyTgCallsBackend._transport_dispatch`): request → snapshot
  (cgroup/fd/threads/joined, 10s cache) → admission
  (`current + cost×(in-flight+1) + headroom < boundary`) → bounded
  semaphore (`VC_MAX_CONCURRENT_JOINS=2`) → native allocation. EVERY
  join path passes it. Denied → the NEW join is DEFERRED
  (`VCResourcePressureError`); ACTIVE transports are NEVER touched.
- **Leave policy** (`vc_leave_policy.py`): every leave is reason-coded
  and authorized at a single chokepoint. Deliberate reasons (user,
  admin, shutdown, tour, explicit stop) always pass;
  validated-automatic reasons (reconcile-confirmed-absent,
  stale-container-verified-absent) REQUIRE evidence and are DENIED
  during the Join-All leave-block; `RESOURCE_EMERGENCY` is opt-in only.
  A successfully joined VC stays ACTIVE until an explicit, validated
  leave — uncertainty NEVER destroys a transport.
- **Heartbeat repaired**: `BOT_HEARTBEAT` every 60s with
  `pid uptime rss_mb threads fd joined_transports join_queue
  active_joins memory_limit_mb resource_headroom_mb` (+ MEM_CENSUS +
  FD_CENSUS). Per-metric degrade-to-unknown; telemetry failure can
  never kill the beat.
- **Verification states**: INACCESSIBLE (private/not-member) is its
  own preserve-class verdict with per-chat recheck backoff
  (default 1h) — no repeated identical requests, no leave. UNKNOWN
  never leaves. Stale call identities are re-detected, not left.
- **SQLite**: WAL checkpoints run on a DEDICATED connection with
  bounded retries; `busy_timeout=5000`, `wal_autocheckpoint=1000`,
  serialized writes; the retention sweep uses the real column and
  always closes its transaction.
- **Crash-loop protection**: startup recovery resumes BOTH crash
  signatures (fresh + previously-marked-stopped — the once-only
  dead-idle fix); ≥3 resume attempts within 1h trip the guard — no
  auto-resume, high-severity `VC_JOIN_ALL_CRASH_GUARD`, admission
  factor 0.5; below the tripwire, exponential backoff (75s×2ⁿ, cap
  900s) + admission reduction (0.75ⁿ, floor 0.25). Successful targets
  and ACTIVE VCs are always preserved across resumes.
- **Durable checkpoints**: pid, resume_attempts, resource snapshot,
  last_successful/failed target per save; serialized writers.

### Acceptance signatures (v99.11)

- `VC_RESOURCE_SNAPSHOT …` (≤1 per 30s) and `VC_TRANSPORT_ALLOCATING /
  ACTIVE / FAILED / RELEASED` lifecycle lines around every native join.
- Under sustained Join-All past ~40 joined:
  `VC_JOIN_ADMISSION_DENIED …` (or `VCResourcePressureError … NEW join
  deferred; ACTIVE transports preserved`) + `deferred_resource_pressure`
  counts — the worker alive, NO SIGKILL, joined plateau at the ceiling.
- `BOT_HEARTBEAT pid=… uptime=…s rss_mb=… threads=… fd=…/…
  joined_transports=… join_queue=… active_joins=… memory_limit_mb=…
  resource_headroom_mb=…` every 60s.
- Zero unintended `VC_LEAVE_REQUESTED` without an explicit
  `reason=USER_REQUESTED|ADMIN_REQUESTED|…`; any denied leave logs
  `VC_LEAVE_DENIED_UNAUTHORIZED … cause=…`.
- `VC_VERIFY_INACCESSIBLE …` once per private chat per recheck window
  (default 1h) instead of every cycle; `WAL_CHECKPOINT_OK busy=0`
  (or `WAL_CHECKPOINT_BUSY … retries=…` as non-error observability);
  after an unexpected restart: `VC_JOIN_ALL_AUTO_RESUME …
  result=resumed` for BOTH crash signatures, and after repeated
  deaths: `VC_JOIN_ALL_CRASH_GUARD …` with no auto-resume.

### Regression signals

- Any `RecursionError` (v99.10 baseline); a SIGKILL restart banner
  mid-join; a heartbeat gap > 120s; `VC_LEAVE_REQUESTED` without a
  reason code; `STALE_CALL_CLEANUP_OWNER` on registry=UNKNOWN;
  "database is locked" on the WAL checkpoint path; an auto-resume
  after ≥3 crash-loop resumes within the window (the tripwire must
  hold); `VC_JOIN_SUCCESS` dropping under healthy resources (raise
  `VC_MAX_JOINED` for the container).

### Honest limits (v99.11)

2,302 automated tests GREEN (2194 v99.10 baseline + 108 new across six
suites: resource guard, leave policy / post-join persistence, heartbeat,
entity contacts, SQLite WAL, crash loop) + static audit UNRESOLVED
critical/high: 0. This sandbox has no live Telegram credentials — the
decisive LIVE evidence is the next production run: a sustained Join-All
that DEFERS at the admission boundary instead of dying, heartbeats
visible all the way through, and every leave accounted for by an
explicit reason.


## v99.11.1 — Targeted Production Remediation (2026-09-25)

A PATCH release: the smallest robust changes that eliminate three
production failures the v99.11 test suite could not catch, identified
from the 2026-09-22/23 production diagnostic logs. No architecture
changes; every v99.11 safety guarantee preserved and
regression-tested. Full evidence and root causes:
`PATCH_MANIFEST_v99.11.1.txt`.

### What this release fixes

1. **`_v9805_snap_reason` UnboundLocalError** (51× in production,
   `VC_SNAPSHOT_STALE_RECOVERY_ERROR`): the stale-container recovery
   state machine in `_vc_join_all_active_worker` assigned the reason
   only for registry states {left, unknown, recovery_pending} while
   the recovery call was reachable for ANY other state — discovery
   targets ("not_registered") crashed it every cycle. Now a
   **total-function state machine**: the reason is derived from the
   validated state (always bound, explicit `else ""` arm); the
   recovery call runs ONLY for validated `left` (evidence-gated,
   unchanged); unknown / recovery_pending remain PRESERVE (v99.11 P0);
   any unexpected state hits the new explicit
   `VC_SNAPSHOT_STALE_UNEXPECTED_STATE` preserve branch — no crash, no
   destructive recovery, target stays re-join-eligible.
2. **Join-All already-joined race** (64 errors → 98 breaker events,
   breaker storm): a snapshot/dispatch race made the v99.06
   one-group-one-account gate raise `VCTransportError: Chat <id> is
   already joined by account <account>` at the join boundary; the
   worker counted it as a transport failure → x3 opened the breaker →
   half-open probes re-hit the same conflicts. Now the exception is
   **classified with ownership evidence** (the new
   `_v9911_classify_already_joined_exc`): same account → idempotent
   convergence (`VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONVERGED`:
   result=already_joined, registry→joined, breaker count UNCHANGED,
   no retry, no duplicate transport); different/unknown owner → the
   existing conflict semantics retained
   (`VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONFLICT`) — the invariant is
   never weakened into a false same-account success.
3. **FD/socket lifecycle** (open_fds 881/1024, sockets 853, joined
   FLAT at 39, memory healthy — drift to `VC_FD_GUARD_RESTART`):
   * the admission model now uses the MEASURED per-join FD cost
     (8 = measured ≈7 sockets/transport + 1 margin; env
     `VC_JOIN_FD_COST`) instead of the assumed 5, and counts
     `joined = max(ownership map, lifecycle-tracker ACTIVE)` — a
     container transport without an ownership entry is no longer
     invisible to admission; NEW joins defer BEFORE the 0.85 emergency
     region (0.80 boundary, unchanged);
   * NEW per-operation FD instrumentation `VC_FD_OP_DELTA` at the
     eight lifecycle boundaries (join dispatch before/after/failed,
     leave before/after, failed-join cleanup, Join-All pause/resume,
     stale-container recovery, crash-restart recovery) — the next
     production log attributes any growth to the owning operation
     directly;
   * NEW heartbeat drift detector `VC_FD_DRIFT_SUSPECTED` (WARNING):
     FD growth WITHOUT transport growth (the measured production
     signature: +5-7 sockets/min, flat joined, flat task census —
     in-process native WebRTC sockets), plus the transport leak sweep
     on EVERY beat (v99.11 ran it only at join time).
     Observability ONLY: no destructive leave, no new restarts; the
     v99.02 FD guard remains the last-resort backstop.

### The v99.11.1 guarantees (unchanged)

- Resource admission BEFORE native allocation (`VC_MAX_JOINED=40`,
  `VC_MAX_CONCURRENT_JOINS=2`); pressure defers the NEW join, never
  touches ACTIVE transports, never records a breaker failure.
- Leave policy chokepoint: UNKNOWN / RECOVERY_PENDING never leave.
- Heartbeat census (BOT_HEARTBEAT / MEM_CENSUS / FD_CENSUS), the
  contacts ladder, SQLite WAL/checkpoint fixes, crash-loop protection
  and checkpoint durability — all untouched and regression-tested.

### Acceptance signatures (v99.11.1)

- ZERO `UnboundLocalError`; for container-present targets with no
  registry record: `VC_SNAPSHOT_STALE_UNEXPECTED_STATE` (preserve) —
  and the target stays re-join-eligible (no recovery loop).
- Same-account already-joined races: `VC_JOIN_ALL_TARGET_
  ALREADY_JOINED_CONVERGED` with the breaker count UNCHANGED and
  `JOIN_ALL_BREAKER` remaining CLOSED; different-owner conflicts keep
  the failure semantics (`..._CONFLICT` marker).
- `VC_FD_OP_DELTA` markers on every join/leave/cleanup/recovery
  operation; `VC_FD_DRIFT_SUSPECTED` if (and only if) FDs grow without
  transport growth; the FD curve stays flat for a sustained
  post-join window (the regression harness proves the
  acquisition↔release pairing).

### Regression signals (ship the log back if any appear)

- Any `UnboundLocalError` anywhere.
- A same-account already-joined race that still records a breaker
  failure or retries the target.
- Sustained `VC_FD_DRIFT_SUSPECTED` with flat `VC_TRANSPORT_RESOURCE_
  LEAK_SUSPECTED`-free logs (pinpoint with `VC_FD_OP_DELTA`).

## v99.11.2 — Surgical Join-All Convergence Remediation (2026-09-25)

A PATCH release over v99.11.1: ONE production-path convergence bug.
Full evidence and root cause: `PATCH_MANIFEST_v99.11.2.txt`.

### What this release fixes

**The Join-All cluster-owned already-joined convergence defect**
(proven by the 2026-09-25 `bot-diagnostic (3).log`: 20×
`VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONFLICT` with
`owner=acc_919006065076` / `dispatch_account=acc_918335829278` — BOTH
the bot's OWN accounts per the same heartbeat census
(`acc_918335829278:J=19/F=19 acc_919006065076:J=18/F=1`) — each
counted as `reason=transport_error`, incrementing the breaker
(`JOIN_ALL_BREAKER failure recorded: VCTransportError x1/3` → 3×
CLOSED→OPEN) and failing the coordinator
(`VC_COORDINATOR_OP_FAILED op=join recoverable=True`), with the same
chats re-dispatched every cycle (12:03:37 → 12:23:58 → 12:36:09)).

Root cause: the v99.11.1 classifier `_v9911_classify_already_joined_exc`
DID run and DID parse the owner — its convergence condition
(`owner == the per-target dispatch account`) is too narrow for a
multi-account cluster, where the Join-All requester is the BOT (the
account pool the cursor-rotation selector dispatches on behalf of).
The dominant production condition — chat owned by bot account A,
cursor dispatched bot account B — classified as "different/unknown
owner" → conflict semantics → transport failure → breaker →
coordinator failure → re-dispatch (the production loop).

The v99.11.2 fix (at the SAME semantic boundary — the worker's
`except VCTransportError` handler, BEFORE any failure accounting):

- **owner == the dispatch account** → idempotent success (v99.11.1,
  preserved);
- **owner = another OWN cluster account** (verified against the
  authoritative cluster registry `get_userbot_cluster()`
  `.list_accounts()` — the same pool the selector draws from, the
  same `_vc_effective_account_id` normalization as the v99.06 gate)
  → **IDEMPOTENT SUCCESS**: `result_state=already_joined`, registry
  synced to joined UNDER THE OWNER (ownership NEVER reassigned — the
  dispatching account never joins; the v99.06 one-group-one-account
  gate preserved, zero RPCs, no duplicate transport), breaker count
  UNCHANGED (no `record_failure` at ANY layer), no per-account
  failure accounting, no retry, the coordinator completes JOINED;
- **owner foreign to the registry / unparseable / membership
  unverifiable** → the existing conflict semantics RETAINED
  (`VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONFLICT`,
  `breaker_recorded=true` — a genuine conflict still counts).

A genuine unrelated `VCTransportError` still increments the breaker
(the over-broad-fix guard — regression-tested as CONV-GENUINE-
TRANSPORT).

### The v99.11.1 guarantees (all preserved, regression-tested)

- FD/socket lifecycle: `VC_FD_OP_DELTA`, `VC_FD_DRIFT_SUSPECTED`,
  `VC_JOIN_FD_COST`, the measured admission model — untouched (the
  2026-09-25 log shows them healthy: no drift markers, FD usage
  stabilized and declined).
- Snapshot recovery: the total-function `_v9805_snap_reason` state
  machine — untouched (the 2026-09-25 log shows
  `VC_SNAPSHOT_STALE_RECOVERY_ERROR` count = 0).
- The v99.11.1 same-account convergence, the resource admission
  guards, the leave-policy chokepoint, the heartbeat census, the
  crash-loop protection — all untouched.

### Acceptance signatures (v99.11.2)

- The expected production signature for the previously-failing
  events:
  `VC_JOIN_ALL_ALREADY_JOINED_CONVERGED chat_id=<id>
  requester_account=<dispatch> owner_account=<owner>
  owner_scope=own_cluster_account
  source=join_all_worker:vctransport_error breaker_recorded=false`
  with NO subsequent
  `JOIN_ALL_BREAKER failure recorded` for that event and the
  coordinator completing `VC_COORDINATOR_OP_COMPLETE ... success=True
  new_state=joined`.
- Same-account races keep the v99.11.1 detail marker
  (`VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONVERGED`) plus the unified
  `VC_JOIN_ALL_ALREADY_JOINED_CONVERGED ... owner_scope=same_account`
  signature.
- Different/unknown owners: `VC_JOIN_ALL_TARGET_ALREADY_JOINED_
  CONFLICT ... breaker_recorded=true` (the conflict semantics —
  breaker may record per existing policy).
- Genuine transport failures (e.g. FloodWait) still record breaker
  failures exactly as before.

### Regression signals (ship the log back if any appear)

- An already-joined event with `owner_scope=own_cluster_account`
  (or same-account) that STILL records a breaker failure or retries
  the target next run.
- A foreign/unparseable owner that became an idempotent success
  (the conflict protection weakened).
- A genuine transport failure (no already-joined signature) that
  stopped incrementing the breaker (the over-broad fix).
- Any v99.11.1 regression signal (UnboundLocalError, FD drift,
  snapshot recovery errors).
\n

## v99.11.3 — Native Resource Lifecycle + Invalid-Channel Remediation (2026-09-26)

A PATCH release over v99.11.2: TWO production problems + preserved
already-joined convergence (untouched — proven working).  Full evidence
and root cause: `PATCH_MANIFEST_v99.11.3.txt`.

### Problem 1 — native FD/socket retention (the leak, not the detection)

The 2026-09-25/26 logs prove the v99.11.1 drift detector was correct
but the leak persisted: process 1 fd 20→885/1024 with joined FLAT
41-43 from 17:30 (+2-4 sockets/min for 3h23m, guard restart at 20:54);
process 2 fd 20→376 with joined FLAT 18-21 (growth onset exactly at
23:47 when the tracked chats' group calls rotated).  Per-minute
event-correlation: EVERY candidate marker negatively correlated;
threads flat; no client creation; growth is SOCKETS ONLY.

Root cause (proven by the controlled native experiment with REAL
ntgcalls — `tests/_v9913_native_lifecycle_driver.py`): each
`create_call`-without-stop retains 2 UDP + 2-6 TCP sockets
indefinitely (GC does not release them; only an explicit stop does).
The production leak = native call objects never deterministically
stopped:
  1. failed joins — the pipeline's transport-dispatch exception path
     had NO native release (every "Invalid channel object"/FloodWait/
     timeout failure orphaned the partially-created native call);
  2. stale/dead transports — the verified-absent release was DENIED
     during Join-All runs (`cause=blocked_during_join_all`; the
     2026-09-25 17:09:55-17:10:29 sequence left 8 transports stuck in
     STOPPING for 3.5h, 360× RESOURCE_LEAK_SUSPECTED, their native
     objects retained — one such chat's leave later released 36
     sockets);
  3. no attribution — the census could not say which sockets/objects.

### What this release fixes (FIX 1)

- **Deterministic native release on every exception exit path**: the
  pipeline's transport-dispatch exception handler now routes the
  partially-created native call through the authorized
  `FAILED_JOIN_CLEANUP` release (the same reason the other failed-join
  paths already use — never an ACTIVE transport).
- **Leave-policy carve-out**: `STALE_CONTAINER_VERIFIED_ABSENT` /
  `RECONCILE_CONFIRMED_ABSENT` releases (WITH positive evidence) stay
  authorized during the Join-All leave-block — a verified-dead object
  is not a live Join-All target; the blanket block was RETAINING dead
  transports.
- **Bookkeeping completion**: every `_vc_cleanup_stale_backend_call`
  exit path finalizes the transport-lifecycle record (RELEASED) when
  the container is verified absent — no more stuck-STOPPING records.
- **Drift attribution + bounded remediation**: when
  `VC_FD_DRIFT_SUSPECTED` fires, the new `VC_FD_DRIFT_ATTRIBUTION`
  census attributes sockets (TCP/UDP/state) and classifies every
  container member (tracked_active / stale_in_container /
  registry_managed / ORPHAN); the bounded pass releases PROVEN-dead
  objects only (orphans, terminal-tracker leftovers, stuck records) —
  ACTIVE healthy transports are never touched.
- **Settled-phase instrumentation**: `VC_FD_OP_DELTA phase=settled`
  30-60s after every join/leave/cleanup (the post-settle measurement
  the v99.11.1 protocol defined but never emitted).

### Problem 2 — the `Invalid channel object` three-strike breaker storm

2026-09-25 17:13:26-17:13:50: three chats (2708391022 / 2064111110 /
1710416743) failed with the DETERMINISTIC entity rejection within 20s
→ 3× `JOIN_ALL_BREAKER failure recorded` → CLOSED→OPEN — the whole
fleet blocked for a per-TARGET condition.  Root chain: discovery
served each entity from acc_919006065076's SCOPED cache; the rotation
to that scope owner was SKIPPED (`floodwait_parked`); the join then
consumed the FOREIGN-SCOPE access_hash on acc_918335829278 → Telegram
rejected every JoinGroupCallRequest.  The same chats re-entered every
subsequent run (18:50 / 19:00 / 19:10 / 20:57).

### What this release fixes (FIX 2)

- **Foreign-scope entity drop**: when the scope-owner rotation is
  skipped, the foreign-scope entity + caller-provided hash are DROPPED
  (`VC_PIPELINE_FOREIGN_SCOPE_ENTITY_DROPPED`) and the resolver
  re-resolves FRESH on the joining account — the join never dispatches
  with a hash the account cannot use.
- **Entity-invalid classification**: the deterministic rejections
  (`Invalid channel object` / ChannelInvalidError / resolve
  exhaustion) join the v97.35 target-specific class
  (`reason=entity_unresolvable`): NO breaker failure, no account
  failure accounting, no account rotation.
- **Sticky entity-invalid cooldown**: the target enters the EXISTING
  discovery dead-letter architecture (reason prefix `entity_invalid`,
  `VC_ENTITY_INVALID_COOLDOWN`, default 1800s) and subsequent Join-All
  runs skip it pre-dispatch (`VC_JOIN_ALL_TARGET_SKIP_ENTITY_
  COOLDOWN`) until the window expires — no repeated redispatch.

### FIX 3 — snapshot unexpected-state noise (measured, NO change)

The 2026-09-25/26 logs show `VC_SNAPSHOT_STALE_UNEXPECTED_STATE` at 36
events over 10.5h (≤2 per chat, joined=14 / not_registered=22) — NOT a
reprocessing loop, no measurable contribution to either problem.  Per
the task rule (modify only on contribution evidence) the preserve
semantics are unchanged; the measurement is asserted in
`tests/test_v99_11_3_preserved.py`.

### PRESERVED (regression-guarded)

- The v99.11.2 already-joined convergence (24× production
  `VC_JOIN_ALL_ALREADY_JOINED_CONVERGED breaker_recorded=false`,
  zero breaker failures — untouched; the v99.11.1/v99.11.2 drivers
  re-verified green).
- UNKNOWN / RECOVERY_PENDING remain no-leave; the leave policy's
  evidence requirement is unchanged (validated reasons without
  evidence are still denied).
- Admission/guard thresholds unchanged (VC_JOIN_FD_COST=8,
  VC_MAX_JOINED, drift thresholds — no limits moved to mask the leak).
- FD detection observability unchanged (`VC_FD_DRIFT_SUSPECTED` fires
  exactly as before — v99.11.3 adds attribution AFTER a positive
  drift, never suppresses detection).

### Post-deployment acceptance signatures

FD (the leak closing):
- `VC_FD_OP_DELTA op=native_join_dispatch ... phase=after` followed by
  `phase=settled` with `delta_sockets` ≈ the after-delta (no growth
  after settling);
- `VC_TRANSPORT_RELEASED_BOOKKEEPING ... reason=container_verified_
  absent` (the stuck-STOPPING class is gone);
- `VC_FD_DRIFT_ATTRIBUTION ... orphans=0` on steady-state drift
  evaluations (or orphans dropping to 0 after
  `VC_FD_DRIFT_REMEDIATION_APPLIED`);
- with joined_transports=N flat, fd/socket counts must NOT rise
  monotonically; repeated `VC_FD_DRIFT_SUSPECTED` with flat transports
  remains an acceptance FAILURE.

Invalid entities:
- `VC_JOIN_ALL_TARGET_FAILURE reason=entity_unresolvable` (NOT
  transport_error) + `VC_JOIN_ALL_ENTITY_INVALID_COOLDOWN_SET`;
- subsequent runs log `VC_JOIN_ALL_TARGET_SKIP_ENTITY_COOLDOWN` for
  the dead-lettered targets;
- NO three-strike breaker OPEN from identical `Invalid channel
  object` rejections; genuine transport failures still record breaker
  failures.

Already joined (preserved, working):
- `VC_JOIN_ALL_ALREADY_JOINED_CONVERGED ... breaker_recorded=false`
  with no subsequent breaker failure for that event.

### Regression signals (ship the log back if any appear)

- fd/socket growth while joined_transports stays flat (the drift
  attribution census will name the owning objects — ship it).
- `VC_TRANSPORT_RESOURCE_LEAK_SUSPECTED` for the SAME chat recurring
  past one remediation cycle.
- Any `Invalid channel object` failure recorded as
  `reason=transport_error` (the classification must be
  entity_unresolvable).
- A breaker OPEN whose `open_reason` contains "Invalid channel
  object".
- Any regression of the already-joined signatures (a converged event
  followed by a breaker failure).
