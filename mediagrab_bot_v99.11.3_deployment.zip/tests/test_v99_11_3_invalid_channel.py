"""v99.11.3 FIX-2 — INVALID-CHANNEL / ENTITY-INVALID SUITE.

PRODUCTION EVIDENCE (bot-diagnostic.log (2).2, 2026-09-25
17:13:26-17:13:50 + the redispatch loop):
  * three DISTINCT chats (2708391022 / 2064111110 / 1710416743, basic
    positive ids) failed with the DETERMINISTIC entity rejection
    ``VCTransportError: Telegram RPC error: Invalid channel object``
    within 20 seconds;
  * the root chain: discovery resolved each entity from
    acc_919006065076's SCOPED cache (CACHE_HIT, rpcs=0) → the
    pipeline's rotation to that scope owner was SKIPPED
    (VC_PIPELINE_ROTATE_TO_RESOLVER_SKIPPED reason=floodwait_parked) →
    the join dispatched on acc_918335829278 with the FOREIGN-SCOPE
    access_hash → Telegram rejected every JoinGroupCallRequest;
  * the worker classified the failures reason=transport_error → 3×
    JOIN_ALL_BREAKER failure recorded → CLOSED→OPEN (x3) — the whole
    fleet blocked for a deterministic per-TARGET condition;
  * the same three chats re-entered EVERY subsequent Join-All run
    (18:50 / 19:00 / 19:10 / 20:57) and re-failed identically — no
    sticky cooldown, no dead-letter.

THE v99.11.3 FIX UNDER TEST (three seams, exact production boundaries):
  1. worker classification: the deterministic entity-invalid RPC
     rejections ("Invalid channel object" / ChannelInvalidError /
     the pipeline's resolve-exhaustion "Cannot resolve chat …") join
     the v97.35 entity-error class → reason=entity_unresolvable
     (target-specific, breaker NOT opened, no account-failure
     accounting, no account rotation);
  2. sticky cooldown: the target enters the EXISTING discovery
     dead-letter architecture (_vc_discovery_mark_dead, reason prefix
     entity_invalid, VC_ENTITY_INVALID_COOLDOWN, default 1800s
     clamped 60..604800) + the worker's pre-dispatch gate
     (VC_JOIN_ALL_TARGET_SKIP_ENTITY_COOLDOWN) skips it until the
     window expires — no repeated redispatch;
  3. pipeline foreign-scope drop: when the scope-owner rotation is
     skipped, the FOREIGN-SCOPE entity + caller-provided hash are
     DROPPED (VC_PIPELINE_FOREIGN_SCOPE_ENTITY_DROPPED) and the
     resolver re-resolves FRESH on the joining account — the join
     never dispatches with a hash the account cannot use.

PRESERVED guarantees asserted here: genuine transient transport
failures still reach the breaker (test 13); arbitrary Telegram errors
are NOT classified entity-invalid (only the strong-evidence
deterministic set); the already-joined convergence is untouched.
"""

from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

_ROOT = str(Path(__file__).resolve().parents[1])
_VC = os.path.join(_ROOT, "mediagrab_bot", "voicechat.py")
_VP = os.path.join(_ROOT, "mediagrab_bot", "vc_pipeline.py")
_CF = os.path.join(_ROOT, "mediagrab_bot", "config.py")
_DRV = os.path.join(_ROOT, "tests", "_v9913_invalid_channel_driver.py")
_DRV_CONV = os.path.join(
    _ROOT, "tests", "_v9912_convergence_driver.py")
_DRV_RACE = os.path.join(_ROOT, "tests", "_v9911_1_race_driver.py")


def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


class TestWorkerClassificationContract(unittest.TestCase):
    """§A — the worker's entity-error match set covers the production
    rejections (and ONLY those — no over-broad classification)."""

    def _match_block(self) -> str:
        src = _read(_VC)
        start = src.index("_is_entity_error = (")
        end = src.index(")", src.index('"cannot resolve chat"'))
        return src[start:end]

    def test_a1_production_rejections_matched(self):
        block = self._match_block()
        for needle in (
                '"invalid channel object"',
                '"channelinvalid"',
                '"cannot resolve chat"'):
            self.assertIn(needle, block)

    def test_a2_case_insensitive_matching(self):
        """The production error carries mixed case ("Invalid channel
        object") — matched via the lowercased copy."""
        src = _read(_VC)
        self.assertIn("_exc_str_lower = str(_exc_str", src)
        self.assertIn("in _exc_str_lower", src)

    def test_a3_cooldown_marking_wired(self):
        src = _read(_VC)
        self.assertIn("VC_JOIN_ALL_ENTITY_INVALID_COOLDOWN_SET", src)
        self.assertIn("_vc_discovery_mark_dead(", src)
        self.assertIn("vc_entity_invalid_cooldown", src)
        # bounded, existing dead-letter architecture reused
        self.assertIn("cooldown_seconds=max(60, _v9913_ei_cd)", src)

    def test_a4_pre_dispatch_gate_wired(self):
        src = _read(_VC)
        self.assertIn("VC_JOIN_ALL_TARGET_SKIP_ENTITY_COOLDOWN", src)
        # ONLY the entity_invalid reason prefix gates (dead-cooldown
        # semantics untouched)
        self.assertIn('startswith(\n                        "entity_invalid")',
                      src)
        self.assertIn('"entity_cooldown"', src)

    def test_a5_config_exists_and_bounded(self):
        src = _read(_CF)
        self.assertIn("vc_entity_invalid_cooldown", src)
        self.assertIn("VC_ENTITY_INVALID_COOLDOWN", src)
        self.assertIn("_clamp_int(\"vc_entity_invalid_cooldown\"", src)

    def test_a6_pipeline_foreign_scope_drop_wired(self):
        src = _read(_VP)
        self.assertIn("VC_PIPELINE_FOREIGN_SCOPE_ENTITY_DROPPED", src)
        self.assertIn("entity = None", src)
        self.assertIn('entity_source = "foreign_scope_dropped"', src)
        # the caller-provided hash is dropped with the entity (it
        # belongs to the foreign scope too)
        self.assertIn("access_hash = 0", src)

    def test_a7_no_breaker_contact_for_entity_class(self):
        """The entity-error branch precedes the transport_error branch
        and records NO breaker failure (the v97.35 contract extended,
        not replaced)."""
        src = _read(_VC)
        entity_idx = src.index("reason=entity_unresolvable")
        transport_idx = src.index(
            "VC_JOIN_ALL_TARGET_FAILURE chat_id=%s reason=transport_error")
        self.assertLess(entity_idx, transport_idx)
        # the entity branch explicitly documents no-breaker
        self.assertIn("breaker NOT opened", src)


class TestClassificationUnit(unittest.TestCase):
    """§B — unit semantics of the extended match set."""

    def _worker_entity_match(self, exc_text: str) -> bool:
        """Evaluate the worker's match expression against exc_text by
        exec-ing the exact production expression (source-faithful)."""
        src = _read(_VC)
        start = src.index("_exc_str_lower = str(_exc_str")
        end = src.index(")\n", src.index('"cannot resolve chat"'))
        block = src[start:end]
        # the block's first line starts mid-line (no leading indent)
        # while the rest carries the source indent — normalize by
        # stripping the common 24-space indent from every line AFTER
        # the first, then exec.
        lines = block.splitlines()
        norm = [lines[0]] + [
            (ln[24:] if ln.startswith(" " * 24) else ln) for ln in lines[1:]]
        norm.append(")")  # the extraction cut the tuple's closing paren
        ns = {"_exc_str": exc_text}
        exec("\n".join(norm), ns)  # noqa: S102 — source-faithful
        return bool(ns["_is_entity_error"])

    def test_b1_production_error_texts(self):
        for text in (
            "VCTransportError: Telegram RPC error: Invalid channel "
            "object. Make sure to pass the right types",
            "ChannelInvalidError: Invalid channel object.",
            "Cannot resolve chat -1002708391022 for account acc_A "
            "after 2 scoped attempts"):
            self.assertTrue(self._worker_entity_match(text), text)

    def test_b2_genuine_transport_errors_not_matched(self):
        for text in (
            "PyTgCalls join failed: connection reset by peer",
            "Telegram RPC error: A wait of 74 seconds is required",
            "TimeoutError while dispatching",
            "connection to DC 2 lost"):
            self.assertFalse(self._worker_entity_match(text), text)

    def test_b3_v9735_legacy_set_preserved(self):
        for text in (
            "Could not find the input entity for PeerChannel",
            "Please include access_hash",
            "cannot resolve input entity"):
            self.assertTrue(self._worker_entity_match(text), text)


class TestInvalidChannelDriver(unittest.TestCase):
    """§C — the REAL-worker driver (matrix cases 11-13): the exact
    production storm converges to the entity-invalid semantics."""

    def test_c1_driver_all_cases_pass(self):
        import subprocess
        proc = subprocess.run(
            [sys.executable, _DRV],
            capture_output=True, text=True, timeout=300.0)
        self.assertEqual(proc.returncode, 0,
                         f"driver failed:\n{proc.stdout[-2000:]}"
                         f"\n{proc.stderr[-2000:]}")
        self.assertIn("SUMMARY: 5/5 cases passed", proc.stdout)
        # 11 — invalid entity never repeatedly redispatched (the
        # cooldown case)
        self.assertIn("CASE INV-COOLDOWN: PASS", proc.stdout)
        # 12 — invalid entity does not open the transport breaker
        self.assertIn("failures={}", proc.stdout)
        # 13 — genuine transport failure still opens breaker
        self.assertIn("CASE INV-GENUINE: PASS", proc.stdout)


class TestBreakerIsolation(unittest.TestCase):
    """Matrix 12/13 isolation — the breaker accounting split between
    entity-invalid (no breaker) and genuine transport (breaker)."""

    def test_d1_entity_invalid_class_not_breaker_counted(self):
        """The production storm text NEVER enters the breaker path:
        simulate the worker's classification decision for the exact
        production error and assert the entity branch is selected."""
        # the branch order in the source decides; assert the
        # classification outcome
        self.assertTrue(
            self._worker_entity_match_public(
                "Telegram RPC error: Invalid channel object."))

    def _worker_entity_match_public(self, text: str) -> bool:
        src = _read(_VC)
        start = src.index("_exc_str_lower = str(_exc_str")
        end = src.index(")\n", src.index('"cannot resolve chat"'))
        block = src[start:end]
        lines = block.splitlines()
        norm = [lines[0]] + [
            (ln[24:] if ln.startswith(" " * 24) else ln) for ln in lines[1:]]
        norm.append(")")
        ns = {"_exc_str": text}
        exec("\n".join(norm), ns)  # noqa: S102
        return bool(ns["_is_entity_error"])


class TestPreservedAlreadyJoined(unittest.TestCase):
    """The PRESERVE contract: the already-joined convergence subsystem
    (v99.11.2) is untouched by v99.11.3."""

    def test_e1_convergence_driver_still_green(self):
        import subprocess
        proc = subprocess.run(
            [sys.executable, _DRV_CONV],
            capture_output=True, text=True, timeout=300.0)
        self.assertEqual(proc.returncode, 0,
                         f"v99.11.2 convergence driver regressed:\n"
                         f"{proc.stdout[-2000:]}")
        self.assertIn("SUMMARY: 9/9 cases passed", proc.stdout)

    def test_e2_v9911_1_race_driver_still_green(self):
        import subprocess
        proc = subprocess.run(
            [sys.executable, _DRV_RACE],
            capture_output=True, text=True, timeout=300.0)
        self.assertEqual(proc.returncode, 0,
                         f"v99.11.1 race driver regressed:\n"
                         f"{proc.stdout[-2000:]}")
        self.assertIn("SUMMARY: 3/3 cases passed", proc.stdout)


if __name__ == "__main__":
    unittest.main()
