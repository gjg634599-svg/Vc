"""Regression tests for v98.00 forensic upgrade — 24/7 VC reliability.

These tests verify the RUNTIME-PROVEN + SOURCE-PROVEN defects fixed in v98.00:

  BUG-VC-REDETECT-FAILURE-MISCLASSIFIED-AS-ABSENT (CRITICAL,
  RUNTIME-PROVEN + SOURCE-PROVEN):
    The v97.99 release fixed the ID-form mismatch in the Join All worker's
    ``_backend_connected`` check, and that fix is PRESERVED verbatim in
    v98.00. However, the v97.99 production runtime
    (bot-diagnostic (14).log) revealed a DEEPER root cause that v97.99 did
    NOT address: the participation reconcile path in ``vc_verify_target``
    (voicechat.py:5917-5994) treated ALL ``fresh_info is None`` cases as
    "VC ended → telegram_participation=absent". But ``fresh_info`` is None
    in THREE distinct situations:

      Case A: ``client is None`` — no client available to verify with.
      Case B: an exception during ``client.get_entity`` (which internally
              calls GetChannelsRequest) OR during ``vc_detect_active_call``
              (which raises VCTransportError for ChannelPrivateError /
              ChatAdminRequiredError / ChatIdInvalidError / FloodWaitError /
              RPCError).
      Case C: ``vc_detect_active_call`` RETURNED None — GetFullChannelRequest
              succeeded and ``full_chat.call`` was None. This is the ONLY
              case that is POSITIVE evidence the VC genuinely has no active
              call.

    Cases A and B are NOT positive absence evidence — they are UNKNOWN (we
    could not determine participation). Treating them as "absent" VIOLATED
    the v97.95 invariant "UNKNOWN never destructive" and caused the bot to
    ACTIVELY LEAVE real, still-connected VCs:

      - ``tg_state="absent"`` flowed into ``vc_reconcile_participations``
        (voicechat.py:6310) which set ``cls="LEFT"`` →
        ``VC_PARTICIPATION_CONFIRMED_ABSENT`` →
        ``record_evidence_absent`` (coordinator JOINED→LEFT) →
        v97.98 FIX-A ``_vc_cleanup_stale_backend_call`` →
        ``backend._leave_target()`` — actively killing the REAL PyTgCalls
        container object based on a transient API error.

    Runtime evidence (bot-diagnostic (14).log, v97.99):
      chat 1393246704:
        04:29:29 VC_JOIN_SUCCESS call_id=-5983949028815838058
        04:51:08 VC_PARTICIPATION_REDETECT_FAILED exc="Invalid channel
                object... (caused by GetChannelsRequest)"
        04:51:08 VC_PARTICIPATION_CALL_ENDED (MISCLASSIFIED as ended)
        04:51:08 VC_PARTICIPATION_CONFIRMED_ABSENT
        04:51:08 VC_STALE_STATE_DETECTED joined→LEFT
        04:51:08 VC_BACKEND_STALE_CALL_CLEANUP → backend._leave_target()
      The same false-absent cascade hit 47 chats whose GetChannelsRequest
      failed; the PyTgCalls container shrank 16 → 6 (the 6 survivors had
      get_entity SUCCEED → vc_detect_active_call found the call →
      vc_check_telegram_participation returned UNKNOWN truncated →
      preserved as joined — UNKNOWN invariant held correctly).

    The previous v97.99 conclusion ("the bot NEVER actually left — STATE
    CORRUPTION from a false stale detection") is INVALIDATED by this
    runtime evidence: the bot DID actually leave, because a
    GetChannelsRequest API error was misclassified as confirmed absence.

  BUG-VC-JOIN-ALL-GID-UNBOUNDLOCALERROR (HIGH, RUNTIME-PROVEN +
  SOURCE-PROVEN):
    The v97.81 FloodWait-deferred log statement (voicechat.py:~8674-8677)
    referenced ``gid`` BEFORE it was assigned by ``gid = g["group_id"]``
    (which was ~16 lines below). When global FloodWait was active on the
    FIRST iteration of the ``async for g`` loop, ``gid`` had never been
    assigned in any prior iteration → ``UnboundLocalError: cannot access
    local variable 'gid' where it is not associated with a value``.

    Runtime evidence (bot-diagnostic (14).log, v97.99):
      05:08:28 VC_JOIN_ALL_WORKER_EXCEPTION: cannot access local variable
              'gid'... (traceback: voicechat.py line 8677, in
              _vc_join_all_active_worker, ``gid,``)
      05:09:05 (same error, second Join All run)

    The bug was latent since v97.81 but never triggered until v97.99 ran
    under sustained FloodWait conditions (19 FloodWait events in log 14).
    v97.99's FIX-C/FIX-D did NOT cause this — they merely ran in an
    environment with more FloodWait pressure than v97.81-v97.98 ever hit.

  v98.00 FIX (minimal, targeted, deterministic — preserves all v97.30-v97.99):
    FIX-E (PRIMARY, RUNTIME-PROVEN root cause): distinguish the three
      ``fresh_info is None`` cases in ``vc_verify_target``. Track
      ``_redetect_error`` explicitly. Only Case C (vc_detect_active_call
      returned None — genuine absence) may mark "absent" / retire the
      call_id / set cooldowns. Cases A (no client) and B (redetect raised)
      set ``tg_state="unknown"`` and do NOT retire the call_id, so the next
      reconcile cycle retries — if the failure was transient, recovery
      happens automatically; if the bot was genuinely kicked, eventually
      vc_detect_active_call returns None (Case C) and the existing
      retirement logic fires. No UNKNOWN is ever converted to a
      destructive LEFT.
    FIX-F (HIGH, RUNTIME-PROVEN): move ``gid = g["group_id"]`` (and the
      dedup check) to IMMEDIATELY after the cancellation check in
      ``_vc_join_all_active_worker``, BEFORE the FloodWait branch that
      references ``gid``. Minimal, deterministic — no behavior change for
      the non-FloodWait path.

  INVARIANT (v98.00): a redetect failure (GetChannelsRequest error,
  VCTransportError, any exception during get_entity or
  vc_detect_active_call) MUST NEVER cause a real VC leave. UNKNOWN is
  NEVER destructive. Only positive absence evidence (vc_detect_active_call
  returning None after a successful GetFullChannelRequest) may retire a
  call_id and trigger the LEFT/cleanup path.

  All v97.30-v97.99 fixes are PRESERVED VERBATIM. voicechat.py is the ONLY
  source file modified (plus version bumps in __init__.py + bootstrap.py);
  changes are ADDITIVE (new Case A/B branches + gid reordering + version
  bumps); no existing behavior weakened.
"""

from __future__ import annotations

import hashlib
import os
import unittest

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG_ROOT = os.path.dirname(_HERE)
_VOICECHAT = os.path.join(_PKG_ROOT, "mediagrab_bot", "voicechat.py")
_INIT = os.path.join(_PKG_ROOT, "mediagrab_bot", "__init__.py")
_BOOTSTRAP = os.path.join(_PKG_ROOT, "mediagrab_bot", "bootstrap.py")


def _read_voicechat() -> str:
    with open(_VOICECHAT, "r", encoding="utf-8") as f:
        return f.read()


def _read_init() -> str:
    with open(_INIT, "r", encoding="utf-8") as f:
        return f.read()


def _read_bootstrap() -> str:
    with open(_BOOTSTRAP, "r", encoding="utf-8") as f:
        return f.read()


def _sha256(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


# ---------------------------------------------------------------------------
# Section A — FIX-E: redetect-failure misclassified as absent (root cause)
# ---------------------------------------------------------------------------


class TestVC800FixERedetectFailureNotAbsent(unittest.TestCase):
    """FIX-E: distinguish redetect-failure (UNKNOWN) from genuine-absent."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_fix_e_marker_present(self):
        """The v98.00 FIX-E comment block is present."""
        self.assertIn("v98.00 FIX-E", self.src)
        self.assertIn(
            "BUG-VC-REDETECT-FAILURE-MISCLASSIFIED-AS-ABSENT", self.src
        )

    def test_redetect_error_flag_tracked(self):
        """FIX-E tracks ``_redetect_error`` explicitly (set in except)."""
        self.assertIn("_redetect_error = None", self.src)
        self.assertIn("_redetect_error = exc", self.src)

    def test_case_a_no_client_preserves_unknown(self):
        """Case A (client is None) → tg_state='unknown', not absent."""
        # The Case A branch must exist and must NOT retire the call_id.
        self.assertIn("v98.00 FIX-E Case A", self.src)
        self.assertIn("reason=no_client", self.src)
        # Case A must NOT call vc_registry_update with telegram_participation=absent
        # — verify the Case A branch sets tg_state = "unknown"
        case_a_idx = self.src.find("v98.00 FIX-E Case A")
        case_b_idx = self.src.find("v98.00 FIX-E Case B")
        self.assertGreater(case_b_idx, case_a_idx, "Case A must precede Case B")
        case_a_block = self.src[case_a_idx:case_b_idx]
        self.assertIn('tg_state = "unknown"', case_a_block)
        self.assertNotIn("telegram_participation=absent", case_a_block)
        self.assertNotIn("active_vc = 0", case_a_block)

    def test_case_b_redetect_exception_preserves_unknown(self):
        """Case B (redetect raised) → tg_state='unknown', not absent."""
        self.assertIn("v98.00 FIX-E Case B", self.src)
        self.assertIn("reason=redetect_failed", self.src)
        case_b_idx = self.src.find("v98.00 FIX-E Case B")
        case_c_idx = self.src.find("v98.00 FIX-E Case C")
        self.assertGreater(case_c_idx, case_b_idx, "Case B must precede Case C")
        case_b_block = self.src[case_b_idx:case_c_idx]
        self.assertIn('tg_state = "unknown"', case_b_block)
        # Case B must NOT retire the call_id or mark absent
        self.assertNotIn("telegram_participation=absent", case_b_block)
        self.assertNotIn("active_vc = 0", case_b_block)
        self.assertNotIn("_vc_target_cooldowns", case_b_block)

    def test_case_c_genuine_absence_still_retires(self):
        """Case C (vc_detect_active_call returned None) → still marks absent
        and retires the call_id (existing behavior preserved)."""
        self.assertIn("v98.00 FIX-E Case C", self.src)
        case_c_idx = self.src.find("v98.00 FIX-E Case C")
        case_c_block = self.src[case_c_idx:]
        # Case C must preserve the retirement behavior
        self.assertIn('tg_state = "absent"', case_c_block)
        self.assertIn("telegram_participation=absent", case_c_block)
        self.assertIn("active_vc = 0", case_c_block)
        self.assertIn("_vc_target_cooldowns", case_c_block)
        self.assertIn("_vc_reconcile_cooldowns", case_c_block)

    def test_three_branches_distinguish_none_cause(self):
        """The three branches use if/elif/elif to distinguish the None cause."""
        # fresh_info is not None → active VC path
        self.assertIn("if fresh_info is not None:", self.src)
        # Case A
        self.assertIn("elif client is None:", self.src)
        # Case B
        self.assertIn("elif _redetect_error is not None:", self.src)
        # Case C (else)
        self.assertRegex(self.src, r"else:\s*\n\s*# v98\.00 FIX-E Case C")

    def test_unknown_invariant_documented(self):
        """FIX-E documents the UNKNOWN-never-destructive invariant."""
        self.assertIn(
            "redetect failure MUST NEVER cause a real VC leave", self.src
        )
        self.assertIn("UNKNOWN never destructive", self.src)

    def test_runtime_evidence_documented(self):
        """FIX-E references the bot-diagnostic (14).log runtime evidence."""
        self.assertIn("bot-diagnostic (14).log", self.src)
        self.assertIn("1393246704", self.src)
        self.assertIn("5983949028815838058", self.src)

    def test_old_misclassified_call_ended_replaced(self):
        """The old comment 'no active VC detected. The old call_id is stale'
        is replaced with the Case C-specific comment."""
        # The old comment claimed "no active VC detected" as the ONLY cause.
        # The new Case C comment clarifies it's only for genuine absence.
        self.assertIn("genuine absence", self.src)
        # The old misleading comment must NOT be the only explanation
        self.assertNotIn(
            "no active VC detected.  The old call_id is stale\n            # (the VC ended).  Retire it — don't hammer it again.  Mark the",
            self.src,
        )


# ---------------------------------------------------------------------------
# Section B — FIX-F: gid UnboundLocalError (gid assigned before FloodWait log)
# ---------------------------------------------------------------------------


class TestVC800FixFGidUnboundLocalError(unittest.TestCase):
    """FIX-F: gid assigned before the FloodWait-deferred log that references it."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_fix_f_marker_present(self):
        """The v98.00 FIX-F comment block is present."""
        self.assertIn("v98.00 FIX-F", self.src)
        self.assertIn(
            "BUG-VC-JOIN-ALL-GID-UNBOUNDLOCALERROR", self.src
        )

    def test_gid_assigned_before_floodwait_log(self):
        """``gid = g["group_id"]`` appears BEFORE the
        ``VC_TARGET_FLOODWAIT_DEFERRED`` log that references ``gid``."""
        gid_assign_idx = self.src.find("gid = g[\"group_id\"]")
        floodwait_log_idx = self.src.find("VC_TARGET_FLOODWAIT_DEFERRED")
        self.assertGreater(
            gid_assign_idx, 0, "gid = g['group_id'] assignment must exist"
        )
        self.assertGreater(
            floodwait_log_idx, 0, "FloodWait deferred log must exist"
        )
        self.assertLess(
            gid_assign_idx,
            floodwait_log_idx,
            "gid must be assigned BEFORE the FloodWait log references it",
        )

    def test_dedup_check_before_floodwait_log(self):
        """The dedup check (seen_gids) also runs before the FloodWait log."""
        seen_add_idx = self.src.find("seen_gids.add(gid)")
        floodwait_log_idx = self.src.find("VC_TARGET_FLOODWAIT_DEFERRED")
        self.assertGreater(seen_add_idx, 0)
        self.assertLess(
            seen_add_idx,
            floodwait_log_idx,
            "seen_gids.add(gid) must run before the FloodWait log",
        )

    def test_no_duplicate_gid_assignment_in_loop(self):
        """There must NOT be a second ``gid = g["group_id"]`` after the
        FloodWait block (the old buggy location). The assignment is now
        unique within the discovery loop."""
        # Count occurrences of the exact assignment
        count = self.src.count("gid = g[\"group_id\"]")
        # There are multiple loops in the file (discovery, etc.) so >1 is OK,
        # but the specific discovery-loop pattern should not be duplicated.
        # Verify the Fix-F comment appears exactly once.
        self.assertEqual(self.src.count("v98.00 FIX-F"), 2)

    def test_floodwait_log_references_fix_f(self):
        """The FloodWait log string references v98.00 FIX-F."""
        # Find the FloodWait log call
        idx = self.src.find("VC_TARGET_FLOODWAIT_DEFERRED")
        # Read the surrounding 400 chars
        block = self.src[idx:idx + 400]
        self.assertIn("v98.00 FIX-F", block)

    def test_runtime_evidence_documented(self):
        """FIX-F documents the UnboundLocalError runtime evidence."""
        self.assertIn("VC_JOIN_ALL_WORKER_EXCEPTION", self.src)
        self.assertIn("cannot access", self.src)
        self.assertIn("local variable 'gid'", self.src)


# ---------------------------------------------------------------------------
# Section C — Version bumps (v97.99 → v98.00)
# ---------------------------------------------------------------------------


class TestVC800VersionBumps(unittest.TestCase):
    """v98.00 version bumps in __init__.py and bootstrap.py."""

    def test_init_version_is_v98_00(self):
        src = _read_init()
        self.assertIn('__bot_version__ = "v99.11.3"', src)
        self.assertNotIn('__bot_version__ = "v98.13"', src)

    def test_bootstrap_deployment_identity_is_v98_00(self):
        # v99 test maintenance (v98.12 correction): the identity derives
        # from the package version — assert the derivation site instead
        # of a frozen literal.
        src = _read_bootstrap()
        self.assertIn("version={_v9812_pkg_version}", src)
        self.assertNotIn("version=v98.13", src)

    def test_no_stale_v97_99_in_version_files(self):
        init_src = _read_init()
        boot_src = _read_bootstrap()
        self.assertNotIn("v97.99", init_src)
        self.assertNotIn("v97.99", boot_src)


# ---------------------------------------------------------------------------
# Section D — v97.99 regression (FIX-C + FIX-D preserved)
# ---------------------------------------------------------------------------


class TestVC800V9799RegressionPreserved(unittest.TestCase):
    """v97.99 FIX-C (marked-form check) + FIX-D (stale cleanup) preserved."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_fix_c_marked_form_check_preserved(self):
        """v97.99 FIX-C: ``_backend_connected`` still tests all 3 ID forms."""
        self.assertIn("_marked_gid = -1000000000000 - gid", self.src)
        self.assertIn("or _marked_gid in _resolved_ids", self.src)

    def test_fix_c_comment_preserved(self):
        self.assertIn("v97.99 FIX-C", self.src)

    def test_fix_d_stale_cleanup_wiring_preserved(self):
        """v97.99 FIX-D: _vc_cleanup_stale_backend_call wired into
        stale_joined_record block."""
        self.assertIn("v97.99 FIX-D", self.src)
        self.assertIn(
            'reason="stale_joined_record:backend_disconnected"', self.src
        )

    def test_fix_d_preserves_v97_98_fix_a_pattern(self):
        """v97.99 FIX-D mirrors v97.98 FIX-A pattern."""
        self.assertIn("v97.98 FIX-A", self.src)


# ---------------------------------------------------------------------------
# Section E — v97.98 regression (FIX-A + FIX-B preserved)
# ---------------------------------------------------------------------------


class TestVC800V9798RegressionPreserved(unittest.TestCase):
    """v97.98 FIX-A (reconcile LEFT cleanup) + FIX-B (join pre-check) preserved."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_fix_a_reconcile_left_cleanup_preserved(self):
        """v97.98 FIX-A: _vc_cleanup_stale_backend_call wired into reconcile
        LEFT block with reason='participation_reconcile_absent'."""
        self.assertIn("v97.98 FIX-A", self.src)
        self.assertIn('reason="participation_reconcile_absent"', self.src)

    def test_fix_b_join_pre_check_registry_left_preserved(self):
        """v97.98 FIX-B: join() pre-check consults registry; if state=='left',
        clean + fall through to real join."""
        self.assertIn("v97.98 FIX-B", self.src)


# ---------------------------------------------------------------------------
# Section F — Structural integrity (py_compile + hash changed)
# ---------------------------------------------------------------------------


class TestVC800StructuralIntegrity(unittest.TestCase):
    """py_compile passes and the voicechat.py hash changed from v97.99."""

    V97_99_VOICECHAT_SHA256 = (
        "fa3e0bb4bb0dfb459b9a849b467ee5ff8f90e1a6e0127d23da99078f2a347119"
    )

    def test_voicechat_py_compiles(self):
        import py_compile
        py_compile.compile(_VOICECHAT, doraise=True)

    def test_init_py_compiles(self):
        import py_compile
        py_compile.compile(_INIT, doraise=True)

    def test_bootstrap_py_compiles(self):
        import py_compile
        py_compile.compile(_BOOTSTRAP, doraise=True)

    def test_voicechat_hash_changed_from_v97_99(self):
        """The v98.00 voicechat.py hash must differ from the v97.99 hash."""
        new_hash = _sha256(_VOICECHAT)
        self.assertNotEqual(
            new_hash,
            self.V97_99_VOICECHAT_SHA256,
            "voicechat.py must have changed from v97.99",
        )

    def test_voicechat_hash_is_deterministic(self):
        """Reading the file twice yields the same hash (no flakiness)."""
        self.assertEqual(_sha256(_VOICECHAT), _sha256(_VOICECHAT))


# ---------------------------------------------------------------------------
# Section G — Runtime evidence correlation (fix matches log 14)
# ---------------------------------------------------------------------------


class TestVC800RuntimeEvidenceCorrelation(unittest.TestCase):
    """The v98.00 fix correlates with the bot-diagnostic (14).log evidence."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_fix_references_bot_diagnostic_14(self):
        """FIX-E references bot-diagnostic (14).log (the new evidence)."""
        self.assertIn("bot-diagnostic (14).log", self.src)

    def test_fix_documents_container_shrinkage(self):
        """FIX-E documents the container 16 → 6 shrinkage observed in log 14."""
        self.assertIn("16 → 6", self.src)

    def test_fix_documents_47_stale_records(self):
        """FIX-E documents the 47 false-stale records observed in log 14."""
        self.assertIn("47 chats", self.src)

    def test_fix_documents_active_leave_chain(self):
        """FIX-E documents the active-leave chain:
        tg_state=absent → cls=LEFT → record_evidence_absent →
        _vc_cleanup_stale_backend_call → backend._leave_target()."""
        self.assertIn("backend._leave_target()", self.src)
        self.assertIn("VC_PARTICIPATION_CONFIRMED_ABSENT", self.src)
        self.assertIn("record_evidence_absent", self.src)

    def test_fix_invalidates_v97_99_conclusion(self):
        """FIX-E documents that the v97.99 conclusion
        ('bot NEVER actually left — STATE CORRUPTION') is INVALIDATED."""
        # The FIX-E comment block explains the bot ACTIVELY left
        self.assertIn("ACTIVELY LEAVE", self.src)
        self.assertIn("real, still-connected VCs", self.src)

    def test_fix_e_case_c_preserves_genuine_absence_handling(self):
        """Case C still handles genuine absence correctly — the fix does NOT
        weaken real-disconnect detection (only false-absent detection)."""
        case_c_idx = self.src.find("v98.00 FIX-E Case C")
        case_c_block = self.src[case_c_idx:case_c_idx + 800]
        self.assertIn("genuine absence", case_c_block)
        self.assertIn("vc_detect_active_call returned None", case_c_block)

    def test_gid_fix_documents_v97_81_origin(self):
        """FIX-F documents that the bug originated in v97.81 (latent until
        v97.99's FloodWait conditions)."""
        self.assertIn("v97.81", self.src)
        self.assertIn("latent since v97.81", self.src)


# ---------------------------------------------------------------------------
# Section H — Unknown-invariant preservation (UNKNOWN never destructive)
# ---------------------------------------------------------------------------


class TestVC800UnknownInvariantPreserved(unittest.TestCase):
    """The v97.95 'UNKNOWN never destructive' invariant is now ACTUALLY
    enforced for the redetect-failure path (it was violated in v97.99)."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_reconcile_left_block_still_requires_positive_absence(self):
        """The reconcile LEFT block at voicechat.py:6310 still requires
        ``tg == "absent" and not lt`` — i.e., positive absence evidence.
        FIX-E ensures that 'absent' is now ONLY set for Case C (genuine
        absence), not for redetect failures."""
        self.assertIn('elif tg == "absent" and not lt:', self.src)
        self.assertIn("VC_PARTICIPATION_CONFIRMED_ABSENT", self.src)

    def test_reconcile_cooldown_guard_preserved(self):
        """The ``ver.get("skipped") == "reconcile_cooldown"`` guard is
        preserved (v97.95 protection)."""
        self.assertIn(
            'ver.get("skipped") == "reconcile_cooldown"', self.src
        )

    def test_unknown_branch_preserves_state(self):
        """The ``elif cls == "UNKNOWN"`` branch still does NOT downgrade
        state (preserve previous state)."""
        self.assertIn('elif cls == "UNKNOWN":', self.src)
        # The branch body must say "do not downgrade" or "preserve"
        uk_idx = self.src.find('elif cls == "UNKNOWN":')
        block = self.src[uk_idx:uk_idx + 200]
        self.assertTrue(
            "do not downgrade" in block or "Preserve" in block,
            "UNKNOWN branch must preserve state (not downgrade)",
        )

    def test_locally_tracked_unconfirmed_preserves_joined(self):
        """The ``LOCALLY_TRACKED_UNCONFIRMED`` path (tg=unknown, joined)
        still preserves joined state (the path the 6 survivors took)."""
        self.assertIn("LOCALLY_TRACKED_UNCONFIRMED", self.src)
        self.assertIn(
            "VC_RECONCILE_DEFERRED_UNKNOWN", self.src
        )

    def test_fix_e_does_not_weaken_real_absence_detection(self):
        """FIX-E does NOT change the Case C retirement logic — genuine
        absence (vc_detect_active_call returns None) is still fully handled."""
        case_c_idx = self.src.find("v98.00 FIX-E Case C")
        # Read through to the end of the retirement block (the block spans
        # the comment + logger + vc_registry_update + db update + tg_state +
        # cooldowns — needs a generous window).
        # v99 test maintenance: 2400 -> 3400 — the v98.01 FIX-G
        # transport_dead-clear insertion sits inside the Case C block;
        # the CONTRACT (genuine absence retirement) is unchanged.
        block = self.src[case_c_idx:case_c_idx + 3400]
        self.assertIn("tg_state = \"absent\"", block)
        self.assertIn("_vc_target_cooldowns", block)
        self.assertIn("_vc_reconcile_cooldowns", block)
        self.assertIn("active_vc = 0", block)


if __name__ == "__main__":
    unittest.main(verbosity=2)
