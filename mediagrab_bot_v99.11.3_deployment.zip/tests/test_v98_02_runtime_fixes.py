"""Regression tests for v98.02 forensic upgrade — production hardening
based on bot-diagnostic (15).log runtime evidence.

These tests verify the SOURCE-PROVEN + RUNTIME-CORRELATED defects fixed in
v98.02, addressing the production-soak failures revealed by the v98.01
diagnostic log (bot-diagnostic (15).log):

  FIX-L (ISSUE 1+3 v2 — false-ABSENT prevention, RUNTIME-CORRELATED):
    The v98.01 FIX-I targeted query ``GetGroupParticipantsRequest(call=
    call_input, ids=[my_id])`` returning EMPTY was treated as "authoritative
    absence" → destructive cleanup via ``_vc_cleanup_stale_backend_call``.
    bot-diagnostic (15).log 11:45:18-11:45:34 showed 5 chats destructively
    cleaned up (2054748259, 2144563093, 3902917470, 1741660162, 1993596337)
    — all triggered by a single targeted-empty each, all during a Telethon
    reconnect storm. The live calls (joined 17min earlier) were destroyed
    and NEVER rejoined.

    FIX-L: a single targeted-empty is now UNKNOWN (non-destructive). Only
    after _VC_TARGETED_ABSENT_THRESHOLD (3) consecutive targeted-empties
    over >=90s+ AND call_id stability across the streak do we declare
    "absent" — authoritative after repeated negative answers, while
    remaining non-destructive for single transient empties.

  FIX-M (ISSUE 2 v2 — verify_joined corroboration ID-form fix,
  RUNTIME-CORRELATED):
    The v98.01 verify_joined tried vc_registry_get(chat_id) with ONLY the
    raw form. ALL corroboration attempts produced
    strength=container_only_no_call_id — meaning real_call_id OR
    real_access_hash was falsy. The registry often lacks access_hash
    (vc_registry_register only stores it if truthy).

    FIX-M: try the registry by BOTH raw and marked forms; try the entity
    cache (mtproto._vc_entity_cache) for access_hash; allow best-effort
    corroboration with call_id alone when access_hash is 0.

  FIX-N (ISSUE 4 — retire stuck RETIRING generations, RUNTIME-CORRELATED):
    BUG-A5-4 confirmed in production: 4 generations stuck in RETIRING state
    forever (946531b955b8, ffb9f35d6867, 5db77573ab94, 281eb5731a3b).
    MTPROTO_GEN_RETIRING_STUCK warnings fired every 30s. retire_generation()
    was defined but NEVER CALLED.

    FIX-N: wire retire_generation() in request_reconnect after the new gen
    is created (mtproto_generation.py:600-663) + periodic sweep in
    _mtproto_health_loop for gens stuck >300s.

  FIX-O (ISSUE 5 — post-MTProto-reconnect VC recovery, RUNTIME-CORRELATED):
    bot-diagnostic (15).log showed 6 reconnects in 5 minutes
    (11:40:15-11:45:43) with NO active rejoin of targets skipped during
    the outage. By the time the reconcile loop's next cycle ran (60s
    later), 5 chats had been falsely declared ABSENT.

    FIX-O: fire-and-forget vc_reconcile_participations() immediately after
    MTPROTO_RECONNECT_SUCCESS (mtproto.py:5777-5818).

  FIX-P (ISSUE 6 — asyncio exception handler improvement,
  RUNTIME-CORRELATED):
    ASYNCIO_UNHANDLED_EXCEPTION at 11:40:06: IncompleteReadError
    "0 bytes read on a total of 8 expected bytes" — future:236160
    exception never retrieved.

    FIX-P: retrieve future.exception() in the handler to mark it as handled
    (prevents "Future exception was never retrieved" duplicate warning on GC).

  FIX-Q (BUG-A5-5b — set gen.client=_mtproto_client in _reconnect_fn):
    request_reconnect at mtproto_generation.py:594 calls
    create_generation(session_path=..., account_id=...) but does NOT pass
    client=_mtproto_client. So gen.client=None. Then retire_generation's
    verify_terminated gate (line 346) is silently SKIPPED.

    FIX-Q: set gen.client = _mtproto_client in _reconnect_fn.

  FIX-R (BUG-A5-5a — asyncio.get_event_loop() → get_running_loop()):
    asyncio.get_event_loop() is deprecated since Python 3.10.

  FIX-S (BUG-A5-5f — short-circuit fix at voicechat.py:8088):
    `if ok and client.is_connected()` short-circuits when inner reconnect
    completed just past the 30s timeout → wrongly marks account
    STATUS_CONNECTION_FAILED.

    FIX-S: check client.is_connected() INDEPENDENTLY of ok.
"""

from __future__ import annotations

import os
import unittest

_AUDIT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_BOT_DIR = os.path.join(_AUDIT_DIR, "mediagrab_bot")


def _read(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:  # noqa: BLE001
        return ""


def _read_voicechat() -> str:
    return _read(os.path.join(_BOT_DIR, "voicechat.py"))


def _read_mtproto() -> str:
    return _read(os.path.join(_BOT_DIR, "mtproto.py"))


def _read_mtproto_generation() -> str:
    return _read(os.path.join(_BOT_DIR, "mtproto_generation.py"))


def _read_utils_real() -> str:
    return _read(os.path.join(_BOT_DIR, "utils_real.py"))


def _read_init() -> str:
    return _read(os.path.join(_BOT_DIR, "__init__.py"))


def _read_bootstrap() -> str:
    return _read(os.path.join(_BOT_DIR, "bootstrap.py"))


# ============================================================================
# FIX-L: false-ABSENT prevention (targeted query empty → UNKNOWN by default)
# ============================================================================

class TestVC802FixLStreakTracking(unittest.TestCase):
    """FIX-L: _vc_targeted_absent_streak dict + threshold + reset helpers."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_streak_dict_declared(self):
        self.assertIn("_vc_targeted_absent_streak", self.src,
                      "FIX-L must declare the streak tracking dict")

    def test_threshold_constant_set(self):
        self.assertIn("_VC_TARGETED_ABSENT_THRESHOLD", self.src)
        # Must be 3 (3 consecutive empties before declaring absent).
        self.assertIn("= 3", self.src)

    def test_stale_seconds_constant_set(self):
        self.assertIn("_VC_TARGETED_ABSENT_STALE_SECONDS", self.src)

    def test_record_function_defined(self):
        self.assertIn("def _vc_targeted_absent_streak_record(", self.src)

    def test_reset_function_defined(self):
        self.assertIn("def _vc_targeted_absent_streak_reset(", self.src)

    def test_record_resets_on_call_id_change(self):
        # Streak must reset when call_id changes (call re-forked).
        self.assertIn("Call ID changed", self.src)
        self.assertIn("_prev_call_id", self.src)

    def test_record_resets_on_stale_streak(self):
        self.assertIn("Streak stale", self.src)


class TestVC802FixLTargetedEmptyIsUnknown(unittest.TestCase):
    """FIX-L: single/double targeted-empty returns 'unknown', NOT 'absent'."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_streak_record_called_on_empty(self):
        # The empty-result handler must call _vc_targeted_absent_streak_record.
        self.assertIn("_vc_targeted_absent_streak_record(", self.src)

    def test_threshold_gate_before_absent(self):
        # Must gate absent behind streak >= threshold AND call_id stable.
        self.assertIn("_streak_count >= _VC_TARGETED_ABSENT_THRESHOLD", self.src)
        self.assertIn("_call_id_stable", self.src)

    def test_single_empty_returns_unknown(self):
        # Must return "unknown" for single/double targeted-empty.
        # Find the streak logic block.
        idx = self.src.find("_streak_count >= _VC_TARGETED_ABSENT_THRESHOLD")
        self.assertGreater(idx, 0, "FIX-L threshold gate must exist")
        # After the threshold block, the unknown path must exist.
        after = self.src[idx:idx + 4000]
        self.assertIn("return \"unknown\"", after,
                      "FIX-L: single/double targeted-empty must return 'unknown'")

    def test_streak_log_warning_emitted(self):
        # Must log VC_PARTICIPATION_TARGETED_EMPTY_STREAK for observability.
        self.assertIn("VC_PARTICIPATION_TARGETED_EMPTY_STREAK", self.src)
        # FIX-L must document that single/double targeted-empty is NOT
        # destructive. The string may be split across concatenated string
        # literals, so check for "NOT " and "destructive" separately.
        self.assertIn("NOT ", self.src)
        self.assertIn("destructive", self.src)

    def test_streak_reset_on_declared_absent(self):
        # After declaring absent (streak >= threshold), must clear the streak.
        idx = self.src.find("VC_PARTICIPATION_ABSENT_VIA_TARGETED")
        self.assertGreater(idx, 0)
        after = self.src[idx:idx + 2000]
        self.assertIn("_vc_targeted_absent_streak_reset(chat_id)", after,
                      "FIX-L: streak must be cleared after declaring absent")


class TestVC802FixLStreakResets(unittest.TestCase):
    """FIX-L: streak resets on present/join/transport_dead clear."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_streak_reset_on_targeted_present(self):
        # The TARGETED-present branch must reset the streak. Find the
        # `if _found_self:` block (the targeted-present branch) and verify
        # the reset call appears within 800 chars AFTER it (before the
        # return "present").
        idx = self.src.find("if _found_self:")
        self.assertGreater(idx, 0,
                           "FIX-L: must have an `if _found_self:` targeted-present branch")
        block = self.src[idx:idx + 800]
        self.assertIn("_vc_targeted_absent_streak_reset(chat_id)", block,
                      "FIX-L: targeted-present branch must reset the streak")

    def test_streak_reset_on_join_success(self):
        # The VC_JOIN_SUCCESS path must reset the streak.
        idx = self.src.find("VC_JOIN_SUCCESS chat_id=")
        self.assertGreater(idx, 0)
        # v98.06 note: window widened 800→2500 — the FIX-LL session
        # join-success insertion (raw+marked id recording) sits between
        # the streak-reset block and the VC_JOIN_SUCCESS log line.
        # v98.13 test maintenance: 2500 → 6000 — the v98.13 §GATE
        # (join-time Telegram verification) sits between them; the
        # CONTRACT (streak reset on join success) is unchanged.
        before = self.src[max(0, idx - 6000):idx]
        self.assertIn("_vc_targeted_absent_streak_reset", before,
                      "FIX-L: join success must reset the streak")

    def test_streak_reset_on_transport_dead_clear(self):
        # _vc_clear_transport_dead must reset the streak.
        idx = self.src.find("def _vc_clear_transport_dead(")
        self.assertGreater(idx, 0)
        after = self.src[idx:idx + 600]
        self.assertIn("_vc_targeted_absent_streak_reset", after,
                      "FIX-L: _vc_clear_transport_dead must reset the streak")


# ============================================================================
# FIX-M: verify_joined corroboration ID-form fix
# ============================================================================

class TestVC802FixMRegistryBothForms(unittest.TestCase):
    """FIX-M: verify_joined tries the registry by BOTH raw and marked forms."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_marked_form_computation(self):
        self.assertIn("_marked_form", self.src)
        self.assertIn("-1000000000000 - _chat_id_int", self.src)

    def test_raw_form_computation(self):
        self.assertIn("_raw_form", self.src)
        self.assertIn("abs(_chat_id_int) % 1000000000000", self.src)

    def test_registry_lookup_marked_form(self):
        # verify_joined must try vc_registry_get(_marked_form) when raw fails.
        self.assertIn("vc_registry_get(_marked_form)", self.src)

    def test_registry_lookup_raw_form(self):
        # verify_joined must try vc_registry_get(_raw_form) when marked fails.
        self.assertIn("vc_registry_get(_raw_form)", self.src)

    def test_entity_cache_fallback_for_access_hash(self):
        # If access_hash is still 0, try the entity cache.
        self.assertIn("_vc_entity_cache", self.src)
        self.assertIn("_cached_ah = _cache_entry.get(\"access_hash\")", self.src)


class TestVC802FixMCorroborationWithCallIdOnly(unittest.TestCase):
    """FIX-M: _vc_telegram_call_still_valid allows call_id alone (access_hash=0)."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_no_longer_requires_access_hash(self):
        # The old guard `if not call_id or call_id == 0 or not access_hash:`
        # must be replaced with `if not call_id or call_id == 0:` in the
        # FUNCTION BODY. The comment may still reference the old guard.
        # Find the _vc_telegram_call_still_valid function body and check
        # the actual guard line.
        idx = self.src.find("def _vc_telegram_call_still_valid(")
        self.assertGreater(idx, 0,
                           "_vc_telegram_call_still_valid must exist")
        func_body = self.src[idx:idx + 3000]
        # The actual guard (not in a comment) must not require access_hash.
        # Look for the guard line that's NOT in a comment.
        lines = func_body.split("\n")
        guard_lines = [ln for ln in lines
                       if "if not call_id" in ln and "return None" not in ln
                       and "#" not in ln.split("if not call_id")[0]]
        self.assertGreater(len(guard_lines), 0,
                           "FIX-M: _vc_telegram_call_still_valid must have a guard")
        for ln in guard_lines:
            self.assertNotIn("or not access_hash", ln,
                              "FIX-M: guard must not require access_hash")

    def test_ah_for_query_computation(self):
        self.assertIn("_ah_for_query = int(access_hash) if access_hash else 0", self.src)

    def test_call_input_uses_ah_for_query(self):
        self.assertIn("InputGroupCall(id=int(call_id), access_hash=_ah_for_query)", self.src)


# ============================================================================
# FIX-N: retire stuck RETIRING generations
# ============================================================================

class TestVC802FixNRetireInRequestReconnect(unittest.TestCase):
    """FIX-N: retire_generation() wired in ReconnectCoordinator.request_reconnect."""

    def setUp(self):
        self.src = _read_mtproto_generation()

    def test_retire_sweep_after_create_generation(self):
        # After create_generation, must sweep old RETIRING gens.
        idx = self.src.find("Create the new generation (marks old RETIRING)")
        self.assertGreater(idx, 0)
        after = self.src[idx:idx + 4000]
        self.assertIn("retire_generation", after,
                      "FIX-N: request_reconnect must call retire_generation after creating new gen")

    def test_retire_skips_new_gen(self):
        # Must exclude the just-created new gen from the sweep.
        self.assertIn("if _g is gen:", self.src)
        self.assertIn("continue  # the new gen we just created", self.src)

    def test_retired_log_emitted(self):
        self.assertIn("MTPROTO_GEN_RETIRED", self.src)

    def test_poisoned_log_emitted(self):
        self.assertIn("MTPROTO_GEN_RETIRE_POISONED", self.src)

    def test_retire_uses_verify_terminated_true(self):
        # Must pass verify_terminated=True to retire_generation.
        self.assertIn("verify_terminated=True", self.src)


class TestVC802FixNPeriodicSweepInHealthLoop(unittest.TestCase):
    """FIX-N: periodic sweep in _mtproto_health_loop retires gens stuck >300s."""

    def setUp(self):
        self.src = _read_mtproto()

    def test_sweep_threshold_300s(self):
        self.assertIn("_age > 300.0", self.src,
                      "FIX-N: periodic sweep must retire gens stuck >300s")

    def test_sweep_retire_call(self):
        self.assertIn("await mgr.retire_generation(", self.src)

    def test_sweep_counters(self):
        self.assertIn("_sweep_retired", self.src)
        self.assertIn("_sweep_poisoned", self.src)

    def test_sweep_log_emitted(self):
        self.assertIn("MTPROTO_GEN_RETIRE_SWEEP", self.src)


# ============================================================================
# FIX-O: post-MTProto-reconnect VC recovery
# ============================================================================

class TestVC802FixOPostReconnectReconcile(unittest.TestCase):
    """FIX-O: fire-and-forget vc_reconcile_participations() after reconnect."""

    def setUp(self):
        self.src = _read_mtproto()

    def test_trigger_after_reconnect_success(self):
        # After MTPROTO_RECONNECT_SUCCESS, must trigger reconcile.
        idx = self.src.find("MTPROTO_RECONNECT_SUCCESS key=primary")
        self.assertGreater(idx, 0)
        after = self.src[idx:idx + 4000]
        self.assertIn("vc_reconcile_participations", after,
                      "FIX-O: must trigger vc_reconcile_participations after reconnect success")

    def test_uses_supervised_create_task(self):
        self.assertIn("supervised_create_task(", self.src)
        self.assertIn("post_reconnect_vc_reconcile", self.src)

    def test_trigger_log_emitted(self):
        self.assertIn("MTPROTO_POST_RECONNECT_VC_RECONCILE_TRIGGERED", self.src)


# ============================================================================
# FIX-P: asyncio exception handler retrieves future.exception()
# ============================================================================

class TestVC802FixPAsyncioHandlerRetrievesException(unittest.TestCase):
    """FIX-P: _asyncio_exception_handler retrieves future.exception()."""

    def setUp(self):
        self.src = _read_utils_real()

    def test_retrieves_exception_for_critical_path(self):
        # The CRITICAL path must call future.exception().
        idx = self.src.find("ASYNCIO_UNHANDLED_EXCEPTION")
        self.assertGreater(idx, 0)
        after = self.src[idx:idx + 2000]
        self.assertIn("future.exception()", after,
                      "FIX-P: handler must retrieve future.exception() for CRITICAL path")

    def test_retrieves_exception_for_suppressed_path(self):
        # The suppressed (network error) path must also retrieve.
        idx = self.src.find("ASYNCIO_NETWORK_ERROR")
        self.assertGreater(idx, 0)
        after = self.src[idx:idx + 1000]
        self.assertIn("future.exception()", after,
                      "FIX-P: handler must retrieve future.exception() for suppressed path")

    def test_checks_future_not_cancelled(self):
        self.assertIn("not future.cancelled()", self.src,
                      "FIX-P: must check future not cancelled before calling exception()")


# ============================================================================
# FIX-Q: gen.client = _mtproto_client in _reconnect_fn
# ============================================================================

class TestVC802FixQGenClientAssignment(unittest.TestCase):
    """FIX-Q: _reconnect_fn sets gen.client = _mtproto_client."""

    def setUp(self):
        self.src = _read_mtproto()

    def test_gen_client_assignment(self):
        self.assertIn("gen.client = _mtproto_client", self.src,
                      "FIX-Q: _reconnect_fn must set gen.client = _mtproto_client")

    def test_snapshot_called(self):
        # Must snapshot bg tasks so retire_generation can verify.
        self.assertIn("_snapshot_telethon_bg_tasks(_mtproto_client", self.src)


# ============================================================================
# FIX-R: asyncio.get_event_loop() → get_running_loop()
# ============================================================================

class TestVC802FixRGetRunningLoop(unittest.TestCase):
    """FIX-R: asyncio.get_event_loop() replaced with get_running_loop()."""

    def setUp(self):
        self.src = _read_mtproto_generation()

    def test_uses_get_running_loop(self):
        self.assertIn("asyncio.get_running_loop().create_future()", self.src,
                      "FIX-R: must use asyncio.get_running_loop() instead of get_event_loop()")

    def test_does_not_use_deprecated_get_event_loop_for_future(self):
        # The specific deprecated call for future creation must be gone.
        self.assertNotIn("asyncio.get_event_loop().create_future()", self.src,
                          "FIX-R: asyncio.get_event_loop().create_future() must be removed")


# ============================================================================
# FIX-S: short-circuit fix at voicechat.py:8088
# ============================================================================

class TestVC802FixSShortCircuitFix(unittest.TestCase):
    """FIX-S: if ok and client.is_connected() doesn't wrongly mark CONNECTION_FAILED."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_timeout_but_connected_path(self):
        self.assertIn("VC_JOIN_ALL_RECONNECT_TIMEOUT_BUT_CONNECTED", self.src,
                      "FIX-S: must handle timeout-but-connected case")
        self.assertIn("marking HEALTHY", self.src)

    def test_marks_healthy_when_connected_despite_timeout(self):
        # The new path must call cluster.update_status(account_id, STATUS_HEALTHY).
        idx = self.src.find("VC_JOIN_ALL_RECONNECT_TIMEOUT_BUT_CONNECTED")
        self.assertGreater(idx, 0)
        after = self.src[idx:idx + 1500]
        self.assertIn("cluster.update_status(account_id, STATUS_HEALTHY)", after,
                      "FIX-S: must mark HEALTHY when client is connected despite timeout")


# ============================================================================
# Version bumps
# ============================================================================

class TestVC802VersionBumps(unittest.TestCase):
    """v98.02 version declared in __init__.py and bootstrap.py."""

    def setUp(self):
        self.init_src = _read_init()
        self.bs_src = _read_bootstrap()

    def test_init_bot_version_v9802(self):
        self.assertIn('__bot_version__ = "v99.11.3"', self.init_src,
                      "__init__.py must declare __bot_version__ = 'v98.02'")

    def test_bootstrap_deployment_identity_v9802(self):
        self.assertIn("version={_v9812_pkg_version}", self.bs_src,  # v99: derivation site
                      "bootstrap.py DEPLOYMENT_IDENTITY must derive from the package version")


# ============================================================================
# v98.01 regression preserved
# ============================================================================

class TestVC802V9801RegressionPreserved(unittest.TestCase):
    """v98.01 fixes (FIX-G/H/I/J/K) must still be present in v98.02."""

    def setUp(self):
        self.vc = _read_voicechat()
        self.bs = _read_bootstrap()

    def test_fix_g_lifecycle_callback_registration_preserved(self):
        self.assertIn("_vc_register_lifecycle_callbacks", self.vc)
        self.assertIn("VC_PYTGCALLS_NO_LIFECYCLE_CALLBACKS", self.vc)

    def test_fix_h_corroboration_preserved(self):
        self.assertIn("_vc_telegram_call_still_valid", self.vc)
        self.assertIn("_vc_corroboration_cache", self.vc)
        self.assertIn("VC_JOIN_EVIDENCE", self.vc)

    def test_fix_i_targeted_query_preserved(self):
        self.assertIn("GetGroupParticipantsRequest", self.vc)
        self.assertIn("VC_PARTICIPATION_ABSENT_VIA_TARGETED", self.vc)

    def test_fix_j_account_aware_cleanup_preserved(self):
        self.assertIn("VC_BACKEND_STALE_CALL_CLEANUP_OWNER", self.vc)
        self.assertIn("_vc_active_join_backends_by_chat", self.vc)

    def test_fix_k_reconnect_loop_status_coverage_preserved(self):
        self.assertIn("ACCOUNT_RECONNECT_FLOODWAIT_EXPIRED", self.bs)
        self.assertIn("ACCOUNT_RECONNECT_DISCONNECTED", self.bs)


# ============================================================================
# v98.00 FIX-C/D/E/F preserved
# ============================================================================

class TestVC802V9800FixesPreserved(unittest.TestCase):
    """v98.00 FIX-C/D/E/F must remain in v98.02."""

    def setUp(self):
        self.vc = _read_voicechat()

    def test_fix_e_redetect_unknown_preserved(self):
        # FIX-E: redetect errors remain UNKNOWN/non-destructive.
        self.assertIn("FIX-E", self.vc)
        self.assertIn("redetect_failed", self.vc)

    def test_fix_f_gid_initialization_preserved(self):
        # FIX-F: 'gid' initialization + FloodWait crash fix.
        self.assertIn("gid", self.vc)


# ============================================================================
# Structural integrity — py_compile all modules
# ============================================================================

class TestVC802StructuralIntegrity(unittest.TestCase):
    """All mediagrab_bot modules must py_compile cleanly."""

    def test_all_modules_compile(self):
        import py_compile
        import tempfile
        modules_to_check = [
            "voicechat.py", "mtproto.py", "mtproto_generation.py",
            "utils_real.py", "bootstrap.py", "__init__.py",
            "config.py", "handlers.py", "join_all_worker.py",
            "vc_state_coordinator.py", "database.py", "db_layer.py",
        ]
        failures = []
        for mod in modules_to_check:
            path = os.path.join(_BOT_DIR, mod)
            if not os.path.exists(path):
                continue
            try:
                with tempfile.NamedTemporaryFile(suffix=".pyc", delete=False) as f:
                    pass
                py_compile.compile(path, cfile=f.name, doraise=True)
                os.unlink(f.name)
            except py_compile.PyCompileError as exc:
                failures.append(f"{mod}: {exc}")
        self.assertEqual(failures, [], f"py_compile failures: {failures}")


# ============================================================================
# Invariant preservation — UNKNOWN never destructive
# ============================================================================

class TestVC802InvariantPreservation(unittest.TestCase):
    """UNKNOWN must NEVER trigger destructive cleanup."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_targeted_empty_does_not_return_absent_immediately(self):
        # The single targeted-empty path must return "unknown", not "absent".
        idx = self.src.find("VC_PARTICIPATION_TARGETED_EMPTY_STREAK")
        self.assertGreater(idx, 0)
        # After the streak log, must return "unknown".
        after = self.src[idx:idx + 1500]
        self.assertIn("return \"unknown\"", after,
                      "FIX-L INVARIANT: single targeted-empty must return 'unknown' (non-destructive)")

    def test_absent_only_after_threshold(self):
        # The "absent" return must come AFTER the threshold gate.
        idx = self.src.find("_streak_count >= _VC_TARGETED_ABSENT_THRESHOLD")
        self.assertGreater(idx, 0)
        after = self.src[idx:idx + 3000]
        self.assertIn("return \"absent\"", after,
                      "FIX-L: 'absent' must only return after threshold met")


# ============================================================================
# Runtime evidence correlation — bot-diagnostic (15).log markers
# ============================================================================

class TestVC802RuntimeEvidenceCorrelation(unittest.TestCase):
    """v98.02 fixes must correlate with bot-diagnostic (15).log evidence."""

    def setUp(self):
        self.vc = _read_voicechat()
        self.mt = _read_mtproto()
        self.mg = _read_mtproto_generation()
        self.ur = _read_utils_real()

    def test_fix_l_correlates_with_5_absent_events(self):
        # bot-diagnostic (15).log showed 5 VC_PARTICIPATION_ABSENT_VIA_TARGETED
        # events. FIX-L must reference these as runtime correlation.
        self.assertIn("2054748259", self.vc)
        self.assertIn("2144563093", self.vc)
        self.assertIn("3902917470", self.vc)
        self.assertIn("1741660162", self.vc)
        self.assertIn("1993596337", self.vc)

    def test_fix_n_correlates_with_4_retiring_stuck_gens(self):
        # bot-diagnostic (15).log showed 4 RETIRING_STUCK gens.
        self.assertIn("946531b955b8", self.mg)
        self.assertIn("ffb9f35d6867", self.mg)
        self.assertIn("5db77573ab94", self.mg)
        self.assertIn("281eb5731a3b", self.mg)

    def test_fix_o_correlates_with_6_reconnects(self):
        # bot-diagnostic (15).log showed 6 reconnects in 5 minutes.
        self.assertIn("6 reconnects in 5 minutes", self.mt)

    def test_fix_p_correlates_with_future_236160(self):
        # bot-diagnostic (15).log showed future:236160 IncompleteReadError.
        self.assertIn("future:236160", self.ur)


# ============================================================================
# Honest scope markers — what v98.02 does NOT claim to fix
# ============================================================================

class TestVC802HonestScopeMarkers(unittest.TestCase):
    """v98.02 must honestly document what it does NOT fix."""

    def setUp(self):
        self.mt = _read_mtproto()
        self.vc = _read_voicechat()

    def test_fix_l_does_not_break_stuck_unknown_loop(self):
        # FIX-L must document that it preserves the "break stuck UNKNOWN loop"
        # goal via the threshold.
        self.assertIn("break \"stuck UNKNOWN forever\" loop", self.vc)

    def test_fix_o_does_not_claim_active_rejoin(self):
        # FIX-O triggers reconcile (passive refresh), NOT active rejoin.
        # Active rejoin happens in the next reconcile cycle.
        self.assertIn("fire-and-forget", self.mt)
        self.assertIn("vc_reconcile_participations", self.mt)


if __name__ == "__main__":
    unittest.main(verbosity=2)
