"""v99.09 — THE VERIFICATION-REPAIR SUITE (2026-09-19 evening production log).

Production evidence (bot-diagnostic.log (1).1, v99.08 build, 17:33:25 →
17:50:35 — the work tree's 9 module hashes match DEPLOYMENT_IDENTITY
exactly, so every signature below is reproducible in THIS source):

  FIX-C  24,526x ``VC_VERIFY_DELEGATED chat_id=<raw> to account=…``
         ping-ponging acc_918335829278 ↔ acc_919006065076 and 25x
         ``RecursionError: maximum recursion depth exceeded`` (17:42:06 →
         17:50:03). Root cause: verify_joined's ownership lookup used ONLY
         the caller's chat-id form while every pipeline join records the
         owner under the MARKED form — the per-chat dict ALWAYS missed for
         Join-All's raw-form callers and the scalar fallback
         (``self._active_join_backend`` — each account's "my last join
         rotated to THAT one" pointer) delegated A→B→A→B… mutual recursion.
  FIX-B  17:37:20 ``DISTRIBUTED_JOIN_ERROR … RuntimeError: VC pipeline
         invalid transition ENTITY_FAILED → CALL_ENDED (…,
         reason='no_active_call')`` for chat -1001861200510. Root cause:
         an entity-level detect failure (CHANNEL_INVALID — foreign-scope
         entity consumed on the wrong client) that exhausted the retry
         budget fell through to the ``no_active_call`` CALL_ENDED branch.
  FIX-A  the same 17:37:16-20 kill chain STARTED one step earlier: the
         rotate-to-resolver (v99 §3 — "the join must use the resolver's
         account") was SILENTLY SKIPPED because the resolver account was
         inside its 2-5s post-join stagger cooldown — a SOFT cooldown the
         rotation gate treated as a hard one. The join then consumed
         acc_919's entity on acc_918's client → the CHANNEL_INVALID storm.
  FIX-D  ``VC loop liveness start failed (non-fatal): name
         '_vc_loop_liveness_task' is not defined`` at BOTH process boots +
         ``WATCHDOG: vc_loop_liveness was None — starting (attempt 1)``
         every 60s for the whole run (18x). Root cause: the v99.07 FIX-11
         idempotency check READ a module global that was never declared —
         and the watchdog's unguarded restarter() call re-raised the same
         NameError each pass, which also skipped the failure counter
         (hence "attempt 1" ad infinitum).
  FIX-E  TASK_DUMP [47 tasks] at 17:43:28 — mid-Join-All, all healthy,
         rate-limit itself working (one dump in the run). The periodic
         dump now defers to the Join-All busy phase with an observable
         marker (on-demand SIGUSR1/faulthandler dumps unaffected).

Verified-benign in the same log (NO code change — pinned here so a future
regression of these signatures is caught):
  * VC_HASH_SCOPE_MISMATCH (43x) — the v98.07 FIX-QQ scope gate doing its
    job: every one was followed by a successful Step-0c account_rotation
    resolution (0-1 RPCs).
  * ENTITY_RESOLVE_FAILED class=LOCAL_MISS (40x) — the honest v98.11 S4
    classification for entities the account never saw (stale 11-day-old
    knowledge-cache targets); rotation then runs.
  * The two 30s join timeouts (17:43:34 / 17:50:35) — both directly
    preceded by ``pytgcalls: Telegram is having some internal server
    issues. Retrying 2 of 3`` (external); the breaker counted x1/3 and
    never tripped. NOT a consequence of the recursion (those targets
    never reached verify).
  * 52x VC_JOIN_SUCCESS with backend_gen>=1 + adopted transports (the
    v99.07 backend fix working — must be preserved).

Method: the REAL voicechat.py against a fake telethon stack (sections A),
the REAL vc_pipeline.py through the v99.00 harness (sections B/C), AST
extraction + exec sandbox for bootstrap (section D), and source contracts
(sections E/F).
"""

from __future__ import annotations

import asyncio
import ast
import importlib.util
import logging
import os
import re
import sys
import tempfile
import textwrap
import time
import types
import unittest
from pathlib import Path
from typing import Any

_SRC = Path(__file__).resolve().parent.parent / "mediagrab_bot"

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(_SRC))
import test_v99_00_vc_pipeline as T  # noqa: E402
from test_v99_00_vc_pipeline import FakeBackend, FakeClient, FakeChannelEntity  # noqa: E402

_VW_TEXT = (_SRC / "voicechat.py").read_text(encoding="utf-8")
_PIPE_TEXT = (_SRC / "vc_pipeline.py").read_text(encoding="utf-8")
_BOOT_TEXT = (_SRC / "bootstrap.py").read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Real-module loader (the proven v99.08 mechanism, self-contained)
# ---------------------------------------------------------------------------

_MODS: dict = {}


def _load_real():
    """Import the REAL voicechat.py against a fake telethon stack."""
    if "vw" in _MODS:
        return _MODS["vw"]

    T._install_fake_telethon()

    class _FakeReq:
        def __init__(self, **kw):
            self.__dict__.update(kw)

    phone_mod = types.ModuleType("telethon.tl.functions.phone")
    phone_mod.GetGroupCallRequest = type("GetGroupCallRequest", (_FakeReq,), {})
    phone_mod.GetGroupParticipantsRequest = type(
        "GetGroupParticipantsRequest", (_FakeReq,), {})
    contacts_mod = types.ModuleType("telethon.tl.functions.contacts")
    contacts_mod.SearchRequest = type("SearchRequest", (_FakeReq,), {})
    channels_mod = types.ModuleType("telethon.tl.functions.channels")
    channels_mod.GetFullChannelRequest = type(
        "GetFullChannelRequest", (_FakeReq,), {})
    messages_mod = types.ModuleType("telethon.tl.functions.messages")
    messages_mod.GetFullChatRequest = type(
        "GetFullChatRequest", (_FakeReq,), {})
    sys.modules.setdefault("telethon.tl.functions",
                           types.ModuleType("telethon.tl.functions"))
    sys.modules["telethon.tl.functions.phone"] = phone_mod
    sys.modules["telethon.tl.functions.contacts"] = contacts_mod
    sys.modules["telethon.tl.functions.channels"] = channels_mod
    sys.modules["telethon.tl.functions.messages"] = messages_mod

    types_mod = sys.modules["telethon.tl.types"]
    types_mod.InputGroupCall = type("InputGroupCall", (_FakeReq,), {})
    types_mod.InputPeerChannel = type("InputPeerChannel", (_FakeReq,), {})
    types_mod.InputPeerChat = type("InputPeerChat", (_FakeReq,), {})
    types_mod.InputPeerUser = type("InputPeerUser", (_FakeReq,), {})
    types_mod.Channel = getattr(types_mod, "Channel",
                                type("Channel", (_FakeReq,), {}))

    errors_mod = sys.modules["telethon.errors"]
    for _ename in ("ChannelInvalidError", "ChannelPrivateError",
                   "ChatAdminRequiredError", "ChatIdInvalidError",
                   "UsernameInvalidError", "PeerIdInvalidError",
                   "RPCError"):
        if not hasattr(errors_mod, _ename):
            setattr(errors_mod, _ename,
                    type(_ename, (Exception,), {}))

    ptg = types.ModuleType("pytgcalls")
    ptg.__version__ = "2.3.3-fake"
    sys.modules.setdefault("pytgcalls", ptg)
    for sub in ("pytgcalls.types", "pytgcalls.types.input_stream",
                "pytgcalls.mtypes", "pytgcalls.helpers"):
        sys.modules.setdefault(sub, types.ModuleType(sub))

    _MODS["purged"] = {
        k: v for k, v in sys.modules.items()
        if k == "mediagrab_bot" or k.startswith("mediagrab_bot.")
    }
    for k in list(_MODS["purged"]):
        del sys.modules[k]
    pkg = types.ModuleType("mediagrab_bot")
    pkg.__path__ = [str(_SRC)]
    sys.modules["mediagrab_bot"] = pkg
    for name in ("config", "db_layer", "mtproto", "voicechat"):
        spec = importlib.util.spec_from_file_location(
            f"mediagrab_bot.{name}", str(_SRC / f"{name}.py"))
        mod = importlib.util.module_from_spec(spec)
        sys.modules[f"mediagrab_bot.{name}"] = mod
        spec.loader.exec_module(mod)
    _MODS["vw"] = sys.modules["mediagrab_bot.voicechat"]
    return _MODS["vw"]


def tearDownModule():
    purged = _MODS.pop("purged", None)
    _MODS.pop("vw", None)
    if purged:
        for k in [k for k in sys.modules
                  if k == "mediagrab_bot" or k.startswith("mediagrab_bot.")]:
            if k not in purged:
                del sys.modules[k]
        sys.modules.update(purged)


def _marked(raw: int) -> int:
    return -1000000000000 - raw


_ACC_A = "acc_918335829278"     # the production pair
_ACC_B = "acc_919006065076"


# ===========================================================================
# SECTION A — FIX-C: verify_joined delegation (REAL voicechat module)
# ===========================================================================

class _VerifyBase(unittest.TestCase):
    """Two REAL PyTgCallsBackend instances + recording is_connected stubs."""

    def setUp(self):
        self.vw = _load_real()
        # accounts.json redirect (never the work tree)
        self._tmp = tempfile.TemporaryDirectory()
        self._acct_bak = os.environ.get("MG_ACCOUNTS_PATH")
        os.environ["MG_ACCOUNTS_PATH"] = os.path.join(self._tmp.name,
                                                      "accounts.json")
        # clean module state
        self.vw._vc_active_join_backends_by_chat.clear()
        # registry: no records (the UNKNOWN evidence path)
        self._reg_bak = getattr(self.vw, "vc_registry_get", None)

        async def _no_rec(chat_id):
            return None
        self.vw.vc_registry_get = _no_rec

        self.a = self.vw.PyTgCallsBackend(_ACC_A)
        self.b = self.vw.PyTgCallsBackend(_ACC_B)
        self.calls: dict[str, list] = {"a": [], "b": []}

        def _mk_stub(tag):
            backend_tag = tag

            async def _is_connected(chat_id=None):
                self.calls[backend_tag].append(chat_id)
                return None      # container unreadable → UNKNOWN
            return _is_connected
        self.a.is_connected = _mk_stub("a")
        self.b.is_connected = _mk_stub("b")

    def tearDown(self):
        if self._reg_bak is not None:
            self.vw.vc_registry_get = self._reg_bak
        if self._acct_bak is None:
            os.environ.pop("MG_ACCOUNTS_PATH", None)
        else:
            os.environ["MG_ACCOUNTS_PATH"] = self._acct_bak
        self._tmp.cleanup()
        self.vw._vc_active_join_backends_by_chat.clear()


class TestV9909VerifyDelegation(_VerifyBase):
    """FIX-C: the 2026-09-19 17:42-17:50 ping-pong is structurally dead."""

    def test_a1_production_pingpong_no_recursion(self):
        """THE production shape: mutual scalar pointers, empty ownership
        dict, raw-form caller. v99.08 recursed to the interpreter cap;
        v99.09 delegates exactly ONE hop and returns UNKNOWN."""
        async def run():
            self.a._active_join_backend = self.b
            self.b._active_join_backend = self.a
            with self.assertLogs("mediagrab", level="DEBUG") as lg:
                res = await self.a.verify_joined(1941982944)
            delegated = [l for l in lg.output if "VC_VERIFY_DELEGATED" in l]
            self.assertEqual(len(delegated), 1,
                             "exactly one delegation hop — the guard must "
                             "cap the chain: %r" % (delegated,))
            self.assertIn(_ACC_B, delegated[0])
            # the DELEGATED backend did the local evidence work; the
            # original backend did not (it delegated before any evidence).
            self.assertEqual(self.calls["b"], [1941982944])
            self.assertEqual(self.calls["a"], [])
            # UNKNOWN is the honest non-destructive verdict here
            self.assertIsNone(res)
        asyncio.run(run())

    def test_a2_marked_form_dict_hit_delegates(self):
        """Ownership recorded under the MARKED form (the pipeline's JOINING
        bookkeeping), caller passes the RAW Join-All form — the dict lookup
        must now HIT (v99.08 always missed)."""
        async def run():
            self.vw._vc_active_join_backends_by_chat[_marked(1941982944)] = self.b
            with self.assertLogs("mediagrab", level="DEBUG") as lg:
                res = await self.a.verify_joined(1941982944)
            delegated = [l for l in lg.output if "VC_VERIFY_DELEGATED" in l]
            self.assertEqual(len(delegated), 1)
            self.assertEqual(self.calls["b"], [1941982944])
            self.assertEqual(self.calls["a"], [])
            self.assertIsNone(res)
        asyncio.run(run())

    def test_a3_marked_form_caller_delegates(self):
        """The marked-form caller (manual /join path) also finds the owner
        (marked-form dict hit, direct)."""
        async def run():
            self.vw._vc_active_join_backends_by_chat[-1001941982944] = self.b
            res = await self.a.verify_joined(-1001941982944)
            self.assertEqual(self.calls["b"], [-1001941982944])
            self.assertEqual(self.calls["a"], [])
            self.assertIsNone(res)
        asyncio.run(run())

    def test_a4_self_owned_no_delegation(self):
        """Dict hit == self → verify locally, ZERO delegation lines."""
        async def run():
            self.vw._vc_active_join_backends_by_chat[_marked(1941982944)] = self.a
            with self.assertLogs("mediagrab", level="DEBUG") as lg:
                res = await self.a.verify_joined(1941982944)
            delegated = [l for l in lg.output if "VC_VERIFY_DELEGATED" in l]
            self.assertEqual(delegated, [])
            self.assertEqual(self.calls["a"], [1941982944])
            self.assertEqual(self.calls["b"], [])
            self.assertIsNone(res)
        asyncio.run(run())

    def test_a5_owner_backend_local_evidence_preserved(self):
        """A PRESENT container on the delegated owner still short-circuits
        to the owner's own evidence path (the v97.42 delegation SEMANTICS
        are preserved — the fix only killed the loop)."""
        async def run():
            self.vw._vc_active_join_backends_by_chat[_marked(555)] = self.b

            async def _b_present(chat_id=None):
                self.calls["b"].append(chat_id)
                return True

            async def _a_never(chat_id=None):
                self.calls["a"].append(chat_id)
                raise AssertionError("A must not be consulted")
            self.b.is_connected = _b_present
            self.a.is_connected = _a_never
            # registry says joined → container True is corroborated by the
            # join-time gate path... with no call identity the honest
            # verdict is still UNKNOWN-or-True family; the KEY contract:
            # the OWNER's evidence ran, no exception, no recursion.
            res = await self.a.verify_joined(555)
            self.assertEqual(self.calls["b"], [555])
            self.assertIn(res, (True, None))
        asyncio.run(run())

    def test_a6_signature_backward_compatible(self):
        """All existing call sites pass a positional chat_id only — the
        guard parameter is keyword-only with a default (zero call-site
        churn, verified via inspect)."""
        import inspect
        sig = inspect.signature(self.vw.PyTgCallsBackend.verify_joined)
        p = sig.parameters
        self.assertIn("chat_id", p)
        self.assertEqual(p["chat_id"].kind,
                         inspect.Parameter.POSITIONAL_OR_KEYWORD)
        self.assertIn("_v9909_delegated", p)
        self.assertEqual(p["_v9909_delegated"].kind,
                         inspect.Parameter.KEYWORD_ONLY)
        self.assertIs(p["_v9909_delegated"].default, False)


# ===========================================================================
# SECTION B — FIX-B: entity-detect exhaustion (REAL vc_pipeline, harness)
# ===========================================================================

class TestV9909DetectEntityExhaustion(T.PipelineTestBase):
    """FIX-B: ENTITY_FAILED → CALL_ENDED is structurally unreachable from
    the exhausted entity-detect path; the ORIGINAL exception survives."""

    def _raising_detect(self, message="ChannelInvalidError: Invalid channel "
                          "object (foreign scope)"):
        h = self.h

        async def _detect(client, entity):
            h.detect_calls.append((client, getattr(entity, "id", 0)))
            raise h.VCTransportError(message)
        return _detect

    def test_b1_exhausted_entity_detect_no_invalid_transition(self):
        """THE 17:37:20 shape: entity-level detect failure on EVERY
        attempt (max_attempts=2). v99.08 crashed with ``RuntimeError: VC
        pipeline invalid transition ENTITY_FAILED → CALL_ENDED``; v99.09
        re-raises the ORIGINAL VCTransportError."""
        async def run():
            self.h.fake_voicechat.vc_detect_active_call = \
                self._raising_detect()
            with self.assertRaises(self.h.VCTransportError) as cm:
                await self._join(chat=-1001861200510, call_id=0,
                                 access_hash=0)
            msg = str(cm.exception)
            self.assertIn("Invalid channel object", msg)
            self.assertNotIn("invalid transition", msg)
            self.assertNotIn("No active voice chat", msg)
            # both attempts paid the detect (the retry ladder is intact)
            self.assertEqual(len(self.h.detect_calls), 2)
            # verification never ran (the join died in detection)
            self.assertEqual(self.h.verify_calls, [])
            # the stale-ownership cleanup path fired for the failed join
            self.assertNotIn(
                -1001861200510,
                self.h.fake_voicechat._vc_active_join_backends_by_chat)
        asyncio.run(run())

    def test_b2_entity_detect_retry_then_success(self):
        """Attempt 1 detect fails entity-level → evict + ENTITY_FAILED →
        attempt 2 detects fresh → join verifies present. FIX-B must NOT
        change the recovery ladder."""
        async def run():
            h = self.h
            seq = {"n": 0}

            async def _detect(client, entity):
                h.detect_calls.append((client, getattr(entity, "id", 0)))
                seq["n"] += 1
                if seq["n"] == 1:
                    raise h.VCTransportError(
                        "ChannelInvalidError: Invalid channel object")
                return {"call_id": -42, "access_hash": 999, "members": 5}
            h.fake_voicechat.vc_detect_active_call = _detect
            h.verify_sequence = ["present"]
            out = await self._join(chat=-1001861200510, call_id=0,
                                   access_hash=0)
            self.assertEqual(out.verdict, "joined")
            self.assertEqual(len(h.detect_calls), 2)
        asyncio.run(run())

    def test_b3_genuine_no_active_call_still_call_ended(self):
        """A detect that returns None (GetFullChannel → call is None) keeps
        the DESIGNED CALL_ENDED verdict — FIX-B must not swallow it."""
        async def run():
            h = self.h
            h.detect_result = False        # harness: models call is None
            with self.assertRaises(h.VCTransportError) as cm:
                await self._join(chat=-1001234567890, call_id=0,
                                 access_hash=0)
            self.assertIn("No active voice chat", str(cm.exception))
        asyncio.run(run())


# ===========================================================================
# SECTION C — FIX-A: rotate-to-resolver stagger (REAL vc_pipeline, harness)
# ===========================================================================

class TestV9909RotateToResolver(T.PipelineTestBase):
    """FIX-A: the SOFT stagger cooldown no longer silently disables the
    scope-correct rotation; hard skips are now observable."""

    def _setup_rotation_world(self):
        self.h.cluster.add("acc_B", 222, FakeClient(222, "acc_B"))
        self._backend_b = FakeBackend(
            "acc_B", self.h.cluster.get_client("acc_B"))

        async def resolver(client, chat_ref, chat_id=0, access_hash=0):
            name = getattr(client, "name", "")
            if name in ("global", "acc_A"):
                return {"ok": True,
                        "entity": FakeChannelEntity(1861200510, 77),
                        "source": f"account_rotation:acc_B"}
            return {"ok": True, "entity": FakeChannelEntity(1861200510, 88),
                    "source": "fresh"}
        self.h.fake_mtproto.resolve_vc_entity = resolver

        def get_backend(account_id=""):
            if account_id == "acc_B":
                return self._backend_b
            return self.backend
        self.h.fake_voicechat.vc_get_backend = get_backend

    def test_c1_stagger_cooldown_waits_then_rotates(self):
        """THE 17:37:16 shape: resolver acc_B inside its 2-5s post-join
        stagger. v99.08 silently skipped the rotation (the join then
        consumed acc_B's entity on the wrong client); v99.09 waits out the
        (bounded) soft cooldown and rotates."""
        async def run():
            self._setup_rotation_world()
            self.h.fake_voicechat._vc_join_account_eligible = \
                lambda aid, **kw: (False, "stagger_cooldown")
            _until = time.monotonic() + 0.05
            self.h.fake_voicechat._vc_join_account_stats = \
                lambda aid: {"cooldown_until": _until}
            self.h.verify_sequence = ["present"]
            with self.assertLogs("mediagrab", level="INFO") as lg:
                out = await self._join(chat=-1001861200510)
            waits = [l for l in lg.output
                     if "VC_PIPELINE_ROTATE_TO_RESOLVER_WAIT" in l]
            self.assertEqual(len(waits), 1,
                             "the stagger wait must be observable: %r" % waits)
            self.assertIn("acc_B", waits[0])
            rots = [l for l in lg.output
                    if "VC_PIPELINE_ROTATE_TO_RESOLVER chat" in l]
            self.assertEqual(len(rots), 1)
            # the join ACTUALLY ran on the resolver's account
            self.assertEqual(out.account, "acc_B")
            self.assertEqual(out.tg_user_id, 222)
            chat, call_id, account, client_name = self.h.verify_calls[-1]
            self.assertEqual(account, "acc_B")
            self.assertEqual(client_name, "acc_B")
        asyncio.run(run())

    def test_c2_floodwait_parked_skip_is_observable(self):
        """A HARD skip (FloodWait-parked resolver) is LOGGED (the
        silent skip was why the 17:37 CHANNEL_INVALID storm had no
        upstream explanation).

        v99.11.3 (documented correction): the join no longer PROCEEDS
        on the original account after the skip — it consumed the
        FOREIGN-SCOPE entity/hash, which Telegram structurally rejects
        (the 2026-09-25 17:13:26-50 production storm: 3 chats, every
        JoinGroupCallRequest failed with the deterministic "Invalid
        channel object", 3× breaker failure, CLOSED→OPEN).  The
        v99.11.3 foreign-scope drop releases the entity and re-resolves
        fresh; with the scope owner still parked the join defers with
        a RECOVERABLE entity failure (the worker classifies it
        entity-invalid: no breaker, sticky cooldown) — never a
        guaranteed-fail dispatch."""
        async def run():
            self._setup_rotation_world()
            self.h.fake_voicechat._vc_join_account_eligible = \
                lambda aid, **kw: (False, "floodwait_parked")
            self.h.verify_sequence = ["present"]
            out_err = None
            with self.assertLogs("mediagrab", level="INFO") as lg:
                try:
                    out = await self._join(chat=-1001861200510)
                except Exception as exc:  # noqa: BLE001
                    out_err = exc
                    out = None
            skips = [l for l in lg.output
                     if "VC_PIPELINE_ROTATE_TO_RESOLVER_SKIPPED" in l]
            self.assertGreaterEqual(len(skips), 1)
            self.assertIn("floodwait_parked", skips[0])
            rots = [l for l in lg.output
                    if "VC_PIPELINE_ROTATE_TO_RESOLVER chat" in l]
            self.assertEqual(rots, [])
            # v99.11.3: the foreign-scope entity is DROPPED (never
            # consumed) — the drop marker is the new observable
            drops = [l for l in lg.output
                     if "VC_PIPELINE_FOREIGN_SCOPE_ENTITY_DROPPED" in l]
            self.assertGreaterEqual(len(drops), 1)
            self.assertIn("acc_B", drops[0])
            # the join DEFERS with the recoverable entity failure (the
            # worker's entity-invalid classification path) — the
            # deterministic foreign-hash dispatch never happened
            self.assertIsNotNone(out_err)
            self.assertIn("Cannot resolve chat", str(out_err))
            self.assertIn("foreign_scope_dropped", str(out_err))
            if out is not None:
                self.assertEqual(out.account, "global")
        asyncio.run(run())

    def test_c3_eligible_rotation_unchanged(self):
        """The no-cooldown rotation keeps its exact v99 §3 behaviour
        (regression guard for the FIX-A edit touching the same block)."""
        async def run():
            self._setup_rotation_world()
            self.h.verify_sequence = ["present"]
            with self.assertLogs("mediagrab", level="INFO") as lg:
                out = await self._join(chat=-1001861200510)
            rots = [l for l in lg.output
                    if "VC_PIPELINE_ROTATE_TO_RESOLVER chat" in l]
            self.assertEqual(len(rots), 1)
            waits = [l for l in lg.output
                     if "VC_PIPELINE_ROTATE_TO_RESOLVER_WAIT" in l]
            self.assertEqual(waits, [])
            self.assertEqual(out.account, "acc_B")
        asyncio.run(run())


# ===========================================================================
# SECTION D — FIX-D: bootstrap liveness lifecycle (AST extraction sandbox)
# ===========================================================================

def _extract_bootstrap_liveness():
    """Pull the REAL module-level binding + the two liveness functions out
    of bootstrap.py and exec them in a sandbox. If the declaration is ever
    removed from the module, the sandbox will not contain the binding and
    the functional tests will fail with the SAME NameError production had.
    """
    tree = ast.parse(_BOOT_TEXT)
    pieces = []
    found_assign = False
    for node in tree.body:
        if isinstance(node, ast.AnnAssign) and \
                isinstance(node.target, ast.Name) and \
                node.target.id == "_vc_loop_liveness_task":
            pieces.append(ast.get_source_segment(_BOOT_TEXT, node))
            found_assign = True
        elif isinstance(node, ast.FunctionDef) and node.name in (
                "_watchdog_get_vc_loop_liveness", "_vc_loop_liveness_start"):
            pieces.append(ast.get_source_segment(_BOOT_TEXT, node))
    assert found_assign, \
        "bootstrap.py lost the module-level _vc_loop_liveness_task " \
        "declaration (v99.09 FIX-D regression)"
    ns: dict[str, Any] = {"asyncio": asyncio}
    created: list = []

    def _fake_supervised_create_task(coro, name=None):
        t = asyncio.get_event_loop_policy().new_event_loop() \
            if False else None
        # a minimal awaitable stand-in that supports .done()
        class _FakeTask:
            def __init__(self, coro):
                self._coro = coro
                self._done = False
                created.append(self)
                coro.close()      # never actually run in the sandbox

            def done(self):
                return self._done

            def mark_done(self):
                self._done = True
        return _FakeTask(coro)
    ns["supervised_create_task"] = _fake_supervised_create_task

    async def _liveness_stub():
        return None
    ns["_vc_loop_liveness_loop"] = _liveness_stub
    exec(compile(textwrap.dedent("\n\n".join(pieces)), "<extract>", "exec"),
         ns)
    return ns, created


class TestV9909LivenessLifecycle(unittest.TestCase):
    """FIX-D: the liveness starter is genuinely idempotent AND startable —
    the v99.07 FIX-11 semantics now actually hold."""

    def test_d1_first_start_binds_without_nameerror(self):
        """THE production failure: ``name '_vc_loop_liveness_task' is not
        defined`` on the very first call."""
        ns, created = _extract_bootstrap_liveness()
        try:
            ns["_vc_loop_liveness_start"]()
        except NameError as exc:
            self.fail(f"FIX-D regression — the starter still raises: {exc}")
        self.assertEqual(len(created), 1)
        self.assertIsNotNone(ns["_vc_loop_liveness_task"])

    def test_d2_idempotent_while_alive(self):
        """A second start while the task is live does NOT spawn a
        duplicate (the v99.07 FIX-11 contract, now reachable)."""
        ns, created = _extract_bootstrap_liveness()
        ns["_vc_loop_liveness_start"]()
        ns["_vc_loop_liveness_start"]()
        self.assertEqual(len(created), 1)

    def test_d3_dead_task_replaced(self):
        """A done task is replaced on the next start (watchdog restart
        path)."""
        ns, created = _extract_bootstrap_liveness()
        ns["_vc_loop_liveness_start"]()
        created[0].mark_done()
        ns["_vc_loop_liveness_start"]()
        self.assertEqual(len(created), 2)

    def test_d4_watchdog_getter_sees_the_binding(self):
        """The watchdog getter resolves the SAME object the starter bound
        (the getter always used globals().get — it saw None forever)."""
        ns, created = _extract_bootstrap_liveness()
        self.assertIsNone(ns["_watchdog_get_vc_loop_liveness"]())
        ns["_vc_loop_liveness_start"]()
        self.assertIs(ns["_watchdog_get_vc_loop_liveness"](), created[0])

    def test_d5_watchdog_restarter_is_guarded(self):
        """Source contract: the watchdog's restarter() call is wrapped in
        try/except with the failure counter incremented (the unguarded
        call aborted the pass and kept the counter at 0 — "attempt 1"
        forever in production)."""
        m = re.search(
            r'WATCHDOG: %s was None — starting \(attempt %d\)",\s*\n'
            r'\s*name, failures \+ 1\)\s*\n'
            r'\s*_watchdog_last_restart\[name\] = time\.monotonic\(\)\s*\n'
            r'(.*?)\n\s*continue',
            _BOOT_TEXT, re.S)
        self.assertIsNotNone(m, "watchdog restart block not found")
        block = m.group(1)
        self.assertIn("try:", block)
        self.assertIn("restarter()", block)
        self.assertIn("_watchdog_failure_counts[name] = failures + 1", block)
        self.assertIn("except Exception", block)


# ===========================================================================
# SECTION E — FIX-E: task-dump busy-phase suppression (source contracts)
# ===========================================================================

class TestV9909TaskDumpSuppression(unittest.TestCase):

    def test_e1_suppression_block_present(self):
        """TASK_DUMP_SUPPRESSED_BUSY is emitted (DEBUG) instead of the
        periodic dump while Join-All runs; the threshold branch keeps
        calling _dump_running_tasks otherwise."""
        self.assertIn("TASK_DUMP_SUPPRESSED_BUSY", _BOOT_TEXT)
        self.assertIn("reason=join_all_running", _BOOT_TEXT)
        # the else-branch still dumps
        m = re.search(
            r'if _v9909_join_all_running:\s*\n(.*?)\n\s*else:\s*\n'
            r'\s*_dump_running_tasks\(reason="periodic_high_task_count"\)',
            _BOOT_TEXT, re.S)
        self.assertIsNotNone(m, "suppression else-branch not found")
        self.assertIn("logger.debug", m.group(1))

    def test_e2_threshold_mechanism_untouched(self):
        """The v99.07 FIX-7 threshold knob itself is NOT weakened (40
        default, env override, one-dump-per-tick rate limit)."""
        self.assertIn("_TASK_DUMP_PERIODIC_THRESHOLD_DEFAULT = 40",
                      _BOOT_TEXT)
        self.assertIn("TASK_DUMP_PERIODIC_THRESHOLD", _BOOT_TEXT)
        # exactly ONE periodic dump call site remains
        self.assertEqual(
            _BOOT_TEXT.count('_dump_running_tasks(reason="periodic_high_'
                             "task_count\")"),
            1)

    def test_e3_join_all_flag_source(self):
        """The suppression reads the REAL voicechat module's
        _vc_join_all_running (the same flag the watchdog uses)."""
        m = re.search(
            r'import mediagrab_bot\.voicechat as _v9909_vc_mod\s*\n'
            r'\s*_v9909_join_all_running = bool\(\s*\n'
            r'\s*getattr\(_v9909_vc_mod, "_vc_join_all_running", False\)\)',
            _BOOT_TEXT)
        self.assertIsNotNone(m)


# ===========================================================================
# SECTION F — verified-benign signatures + preserved behaviour contracts
# ===========================================================================

class TestV9909PreservedContracts(unittest.TestCase):
    """The v99.08-run features that were WORKING and must not regress."""

    def test_f1_delegation_marker_unchanged(self):
        """VC_VERIFY_DELEGATED keeps its exact production wording (marker
        preservation contract — only the loop around it changed)."""
        self.assertIn(
            '"VC_VERIFY_DELEGATED chat_id=%s to account=%s '
            '(rotated backend)",',
            _VW_TEXT)

    def test_f2_no_call_ended_claims_from_entity_failure(self):
        """The exhausted entity-detect path can no longer reach the
        CALL_ENDED branch (the branch stays for genuine no-call detects)."""
        # the FIX-B block sits between the ENTITY_FAILED transition and a
        # bare re-raise
        self.assertIn('sm.transition(VCJoinState.UNRECOVERABLE,\n'
                      '                                      "detect_entity_'
                      'failed")', _PIPE_TEXT)
        # and the no_active_call branch is UNCHANGED below it
        self.assertIn(
            'sm.transition(VCJoinState.CALL_ENDED, "no_active_call")',
            _PIPE_TEXT)

    def test_f3_breaker_and_backoff_not_weakened(self):
        """The join-all breaker threshold/wording untouched (source
        contract against accidental edits in the same file)."""
        # vc_pipeline has no breaker; join_all_worker.py does — pin its
        # failure-count line
        jaw = (Path(__file__).resolve().parent.parent /
               "mediagrab_bot" / "join_all_worker.py").read_text(
                   encoding="utf-8")
        self.assertIn("JOIN_ALL_BREAKER", jaw)

    def test_f4_pipeline_transition_table_unchanged(self):
        """ENTITY_FAILED's allowed successors stay exactly RESOLVING +
        UNRECOVERABLE (FIX-B routes through UNRECOVERABLE — the table
        itself is NOT edited)."""
        m = re.search(
            r'VCJoinState\.ENTITY_FAILED: \{\s*\n'
            r'\s*VCJoinState\.RESOLVING, VCJoinState\.UNRECOVERABLE,\s*\n'
            r'\s*\},', _PIPE_TEXT)
        self.assertIsNotNone(m)

    def test_f5_liveness_marker_and_canary_untouched(self):
        """The v98.07 FIX-SS canary + liveness markers keep their wording
        (only the binding bug changed)."""
        self.assertIn("VC_HEARTBEAT_CANARY_STARTED", _BOOT_TEXT)
        self.assertIn("vc_loop_liveness", _BOOT_TEXT)


if __name__ == "__main__":
    unittest.main(verbosity=2)
