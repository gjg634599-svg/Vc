"""v99.11.3 FIX-2 — Invalid-channel breaker-storm driver.

Runs the REAL production ``_vc_join_all_active_worker`` (full module body)
via the proven v98.10 fastpath harness (fake Telethon RPC surface, fake
PyTgCalls 2.3.3 semantics, REAL join_all_worker circuit breaker + REAL
vc_state_coordinator + REAL state machines), reproducing THE EXACT
PRODUCTION STORM from bot-diagnostic.log (2).2 (2026-09-25
17:13:26-17:13:50):

    VC_JOIN_ALL_TARGET_START index=32/40 chat_id=2708391022
    VC_JOIN_ALL_TARGET_ACCOUNT_SELECTED account=acc_918335829278
    VC_PIPELINE_CALL_IDENTITY_FASTPATH ... using the caller-provided
        identity          ← the caller-provided (cross-scope) hash
    VC_JOIN_ALL_TARGET_FAILURE chat_id=2708391022 reason=transport_error
        exc=VCTransportError: Telegram RPC error: Invalid channel object
    ... 17:13:35 chat 2064111110 ... 17:13:50 chat 1710416743 ...
    JOIN_ALL_BREAKER CLOSED → OPEN (VCTransportError x3 (threshold=3))
    → the whole fleet blocked for a DETERMINISTIC entity mismatch
    → the same 3 chats redispatched at 18:50 / 19:00 / 19:10 / 20:57

Root cause (proven in the log chain): the entity cache held the three
chats under acc_919006065076's scope; the pipeline's rotation to that
scope owner was SKIPPED (floodwait_parked); the join then consumed the
FOREIGN-SCOPE access_hash on acc_918335829278 → Telegram rejected every
JoinGroupCallRequest with the deterministic "Invalid channel object".

The v99.11.3 seams under test (the exact production boundaries):

    Join-All target → dispatch → backend.join raises the exact
        production VCTransportError ("Invalid channel object")
        → the REAL worker's except-VCTransportError handler
        → v99.11.3 entity-invalid classification (reason=entity_-
          unresolvable, breaker NOT opened)
        → v99.11.3 sticky entity-invalid cooldown (dead-letter)
        → next run: pre-dispatch cooldown gate skips the target

Cases:
    INV-STORM         — the EXACT production storm: 3 chats fail with
                        "Invalid channel object".  Expected: classified
                        entity_unresolvable (target-specific), breaker
                        failures UNCHANGED + CLOSED (no x3 → no OPEN),
                        cooldown marked per chat, no native transport.
    INV-COOLDOWN      — the second run (the production redispatch loop
                        18:50/19:00/19:10): targets inside their
                        entity-invalid cooldown are SKIPPED pre-dispatch
                        (no RPC, no native allocation, breaker untouched).
    INV-NATIVE        — the storm never created a native transport for
                        the invalid targets (api_log + container empty).
    INV-GENUINE       — an unrelated GENUINE transport failure still
                        records the breaker failure (the over-broad-fix
                        guard: entity-invalid classification must not
                        swallow real transport errors).
    INV-SCOPE-DROP    — the pipeline-level fix: a foreign-scope entity
        (source=account_rotation:X with X floodwait-parked) is DROPPED
        before consumption — the join re-resolves FRESH on the joining
        account and NEVER dispatches with the foreign hash.

Exit code = number of failed cases; each case prints
``CASE <id>: PASS|FAIL — detail``.
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys
import types

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import _v9810_fastpath_driver as FP  # noqa: E402

MARKED = FP.MARKED_BASE
# The three PRODUCTION chat ids from the 2026-09-25 17:13 storm
# (bot-diagnostic.log (2).2 lines ~17:13:26-17:13:50).
RAW_I1 = 2708391022
RAW_I2 = 2064111110
RAW_I3 = 1710416743

# The EXACT production exception text (17:13:30).
PROD_INVALID_CHANNEL = (
    "Telegram RPC error: Invalid channel object. Make sure to pass the "
    "right types, for instance making sure the user id refers to a user."
)


def _prod_invalid_error(vc):
    return vc.VCTransportError(PROD_INVALID_CHANNEL)


def _genuine_transport_error(vc, marked: int):
    return vc.VCTransportError(
        f"PyTgCalls join failed: connection reset by peer "
        f"(caused by JoinGroupCallRequest chat={marked})")


def _patch_join_raises(vc, w, error_fn):
    """Replace every backend's join with the production failure boundary
    (the worker seam — the same seam the v99.11.2 driver patches)."""
    def _patch(backend):
        async def _raise_join(chat_id, call_id=0, access_hash=0,
                              muted=True, **kw):
            raise error_fn()
        backend.join = _raise_join

    for b in (w.global_b, w.a_b, w.b_b):
        _patch(b)


def _record_cooldown_calls(vc, calls: list):
    """Patch the discovery dead-letter writer with a recorder (the
    harness DB no-ops SQL — the CONTRACT under test is the call:
    (gid, reason prefix, cooldown seconds >= 60)).  Returns the restore
    callable (module-global patches persist across cases — the harness
    reset only rebuilds the backends, NOT the module globals)."""
    orig = vc._vc_discovery_mark_dead

    async def _rec(gid, reason, cooldown_seconds=None):
        calls.append((int(gid), str(reason or ""),
                      int(cooldown_seconds or 0)))
    vc._vc_discovery_mark_dead = _rec

    def _restore():
        vc._vc_discovery_mark_dead = orig
    return _restore


def _patch_cooldown_read(vc, states: dict):
    """Patch the cooldown READ with per-chat states; returns restore."""
    orig = vc._vc_discovery_is_target_on_cooldown

    async def _cd(gid, *a, **k):
        want = states.get(int(gid))
        if want is not None:
            return want
        return False, ""
    vc._vc_discovery_is_target_on_cooldown = _cd

    def _restore():
        vc._vc_discovery_is_target_on_cooldown = orig
    return _restore


def _seed_invalid_targets(vc):
    """The three production storm targets: registry=unknown, eligible."""
    for raw in (RAW_I1, RAW_I2, RAW_I3):
        FP.seed_group(raw, title=f"INV-{raw}", call_id=-991001, call_ah=811)
        rec = vc.VCParticipationState(
            chat_id=raw, state="unknown", request_accepted=False,
            intentional=True, locally_tracked=False, account_id="")
        vc._vc_participations[raw] = rec


async def case_storm(vc):
    """INV-STORM — the exact production 3-chat storm: entity-invalid
    classification + NO breaker + cooldown marked + no native."""
    w = await FP.reset_world(vc)
    _seed_invalid_targets(vc)
    vc._vc_join_all_state["run_id"] = "inv_storm"
    breaker_before = dict(vc._vc_join_all_breaker._failures)

    cd_calls: list = []
    _restore_cd = _record_cooldown_calls(vc, cd_calls)
    _patch_join_raises(vc, w, lambda: _prod_invalid_error(vc))
    try:
        terminal = await FP.run_worker(vc)
    finally:
        _restore_cd()
    breaker = vc._vc_join_all_breaker
    failures = dict(breaker._failures)
    breaker_state = breaker.state.value
    results = vc._vc_join_all_state["results"]
    failed_states = {r: results.get(r, {}).get("state") for r in
                     (RAW_I1, RAW_I2, RAW_I3)}
    cd_marked = sorted(c for c, _r, _s in cd_calls)
    cd_reasons_ok = all(
        r.lower().startswith("entity_invalid")
        for _c, r, _s in cd_calls)
    cd_seconds_ok = all(s >= 60 for _c, _r, s in cd_calls)
    native_ran = any(
        b._pytgcalls.api_log for b in (w.global_b, w.a_b, w.b_b))
    container_entries = [
        k for b in (w.global_b, w.a_b, w.b_b)
        for k in b._pytgcalls.calls
        if k in (MARKED - RAW_I1, RAW_I1, MARKED - RAW_I2, RAW_I2,
                 MARKED - RAW_I3, RAW_I3)
    ]
    ok = (
        terminal in ("completed",)
        and all(s == "failed" for s in failed_states.values())
        and failures == breaker_before == {}
        and breaker_state == "closed"
        and sorted(cd_marked) == sorted([RAW_I1, RAW_I2, RAW_I3])
        and cd_reasons_ok
        and cd_seconds_ok
        and not native_ran
        and not container_entries
    )
    detail = (f"terminal={terminal} states={failed_states} "
              f"failures={failures} breaker={breaker_state} "
              f"cooldown={cd_marked} reasons_ok={cd_reasons_ok} "
              f"native_ran={native_ran} container={container_entries}")
    return ok, detail


async def case_cooldown(vc):
    """INV-COOLDOWN — the second run: pre-dispatch cooldown gate skips
    the dead-lettered targets (no RPC, no native, breaker untouched)."""
    w = await FP.reset_world(vc)
    _seed_invalid_targets(vc)
    vc._vc_join_all_state["run_id"] = "inv_cooldown"

    # The cooldown gate reads the (DB-backed) cooldown state — the
    # harness DB is a no-op, so the READ is patched to the post-storm
    # state (reason prefix entity_invalid — ONLY that prefix gates).
    _restore_cd = _patch_cooldown_read(vc, {
        RAW_I1: (True, "entity_invalid: Invalid channel object"),
        RAW_I2: (True, "entity_invalid: Invalid channel object"),
        RAW_I3: (True, "entity_invalid: Invalid channel object"),
    })

    dispatched: list = []

    def _patch(backend):
        async def _never_join(chat_id, call_id=0, access_hash=0,
                              muted=True, **kw):
            dispatched.append(chat_id)
            raise vc.VCTransportError("must not be reached")
        backend.join = _never_join

    for b in (w.global_b, w.a_b, w.b_b):
        _patch(b)

    try:
        terminal = await FP.run_worker(vc)
    finally:
        _restore_cd()

    results = vc._vc_join_all_state["results"]
    progress = vc._vc_join_all_state["progress"]
    cd_states = {r: results.get(r, {}).get("state") for r in
                 (RAW_I1, RAW_I2, RAW_I3)}
    breaker = vc._vc_join_all_breaker
    ok = (
        terminal in ("completed",)
        and all(s == "entity_cooldown" for s in cd_states.values())
        and progress.get("entity_cooldown", 0) == 3
        and not dispatched
        and dict(breaker._failures) == {}
        and breaker.state.value == "closed"
        and not any(b._pytgcalls.api_log
                    for b in (w.global_b, w.a_b, w.b_b))
    )
    detail = (f"terminal={terminal} states={cd_states} "
              f"progress_ec={progress.get('entity_cooldown')} "
              f"dispatched={dispatched} "
              f"breaker={breaker.state.value}")
    return ok, detail


async def case_native(vc):
    """INV-NATIVE — the storm never dispatches a NATIVE transport for
    the invalid targets: the FakePyTgCalls api_log (the native dispatch
    record) stays empty for the three chats, the calls containers gain
    no entry, and the transport-lifecycle tracker records no transport
    for them (no orphaned native object can exist)."""
    w = await FP.reset_world(vc)
    _seed_invalid_targets(vc)
    vc._vc_join_all_state["run_id"] = "inv_native"

    _patch_join_raises(vc, w, lambda: _prod_invalid_error(vc))
    terminal = await FP.run_worker(vc)

    api_log = [api for b in (w.global_b, w.a_b, w.b_b)
               for api in b._pytgcalls.api_log]
    container_entries = [
        k for b in (w.global_b, w.a_b, w.b_b)
        for k in b._pytgcalls.calls
        if k in (MARKED - RAW_I1, RAW_I1, MARKED - RAW_I2, RAW_I2,
                 MARKED - RAW_I3, RAW_I3)
    ]
    try:
        from mediagrab_bot.vc_resources import transport_lifecycle as _tl
        trk = {cid for cid in _tl.records()
               if abs(int(cid)) % 1000000000000 in
               (RAW_I1, RAW_I2, RAW_I3)}
    except Exception:  # noqa: BLE001
        trk = set()
    ok = (
        terminal in ("completed",)
        and not api_log
        and not container_entries
        and not trk
    )
    detail = (f"terminal={terminal} api_log={api_log} "
              f"container={container_entries} tracker={trk}")
    return ok, detail


async def case_genuine(vc):
    """INV-GENUINE — an unrelated genuine transport failure still
    records the breaker failure (over-broad-fix guard)."""
    w = await FP.reset_world(vc)
    FP.seed_group(FP.RAW, title="INV-GENUINE", call_id=-992001, call_ah=822)
    rec = vc.VCParticipationState(
        chat_id=FP.RAW, state="unknown", request_accepted=False,
        intentional=True, locally_tracked=False, account_id="")
    vc._vc_participations[FP.RAW] = rec
    vc._vc_join_all_state["run_id"] = "inv_genuine"
    breaker_before = dict(vc._vc_join_all_breaker._failures)

    cd_calls: list = []
    _restore_cd = _record_cooldown_calls(vc, cd_calls)
    _patch_join_raises(vc, w, lambda: _genuine_transport_error(
        vc, MARKED - FP.RAW))
    try:
        terminal = await FP.run_worker(vc)
    finally:
        _restore_cd()

    breaker = vc._vc_join_all_breaker
    failures = dict(breaker._failures)
    result = vc._vc_join_all_state["results"].get(FP.RAW, {})
    ok = (
        terminal in ("completed",)
        and result.get("state") == "failed"
        and len(failures) >= 1
        and len(failures) >= len(breaker_before)
        and not cd_marked_invalid(cd_calls)
    )
    detail = (f"terminal={terminal} result={result.get('state')} "
              f"failures={failures} cooldown={cd_calls}")
    return ok, detail


def cd_marked_invalid(calls: list) -> bool:
    """Did any GENUINE failure wrongly land in the entity-invalid
    dead-letter? (the classification must not be over-broad)."""
    return any(str(r or "").lower().startswith("entity_invalid")
               for _c, r, _s in calls)


async def case_scope_drop(vc):
    """INV-SCOPE-DROP — the pipeline-level fix: the resolver returns a
    FOREIGN-SCOPE entity (source=account_rotation:acc_B) while acc_B is
    FloodWait-parked → v99.11.3 DROPS the foreign entity + hash and
    re-resolves fresh on the joining account; the join then proceeds
    with a valid current-scope identity (native dispatch happened; the
    registry converges; the breaker stays closed)."""
    w = await FP.reset_world(vc)
    FP.seed_group(FP.RAW, title="INV-SCOPE-DROP", call_id=-993001,
                  call_ah=833)
    rec = vc.VCParticipationState(
        chat_id=FP.RAW, state="unknown", request_accepted=False,
        intentional=True, locally_tracked=False, account_id="")
    vc._vc_participations[FP.RAW] = rec
    vc._vc_join_all_state["run_id"] = "inv_scope_drop"

    # Park acc_B (the scope owner) — the production floodwait_parked
    # state that made v99.09's rotation skip.
    vc._vc_join_account_park_floodwait("acc_B", 30.0)

    # Patch the resolver: the FIRST resolve returns the foreign-scope
    # rotation source (the production shape); every later resolve
    # returns the plain current-scope cache entity.
    import mediagrab_bot.mtproto as fake_mtproto  # the FP stub module
    calls_seen: list = []
    orig_resolve = fake_mtproto.resolve_vc_entity

    async def _scoped_resolve(client, chat_ref, chat_id=0, access_hash=0):
        calls_seen.append((access_hash, str(getattr(client, "_scope", ""))))
        if len(calls_seen) == 1:
            ent = FP.SCENARIO.entities.get(FP.RAW)
            return {"ok": True, "entity": ent,
                    "source": "account_rotation:acc_B",
                    "scope": "acc_B", "error": ""}
        return await orig_resolve(client, chat_ref, chat_id=chat_id,
                                  access_hash=0)
    fake_mtproto.resolve_vc_entity = _scoped_resolve

    # REAL pipeline join (no backend.join patch): the worker →
    # VCBackend.join → run_vc_join → resolve → rotation-skip → DROP →
    # fresh resolve → detect → transport dispatch (FakePyTgCalls).
    try:
        for b in (w.global_b, w.a_b, w.b_b):
            if hasattr(b, "join") and getattr(b, "join", None) is not None:
                # restore the REAL delegation if a prior case patched it
                try:
                    del b.join
                except AttributeError:
                    pass
        terminal = await FP.run_worker(vc)
    finally:
        fake_mtproto.resolve_vc_entity = orig_resolve

    results = vc._vc_join_all_state["results"]
    result = results.get(FP.RAW, {})
    registry_rec = await vc.vc_registry_get(FP.RAW)
    native_ran = any(
        any(api[0] == "join_group_call" for api in b._pytgcalls.api_log)
        for b in (w.global_b, w.a_b, w.b_b))
    breaker = vc._vc_join_all_breaker
    re_resolved = len(calls_seen) >= 2
    foreign_hash_never_reused_after_drop = (
        len(calls_seen) < 2 or calls_seen[1][0] in (0, 111))
    ok = (
        terminal in ("completed",)
        and re_resolved
        and foreign_hash_never_reused_after_drop
        and native_ran
        and result.get("state") in ("joined_confirmed",
                                    "joined_unverified", "failed",
                                    "confirmation_unknown")
        and dict(breaker._failures) == {}
        and breaker.state.value == "closed"
    )
    # The critical assertion: the join eventually dispatched with a
    # FRESH identity (re-resolve happened) — the exact scope-drop
    # contract; joined state is environment-dependent (the FP verify
    # path), but the pipeline must never consume the foreign hash.
    ok = ok and re_resolved
    detail = (f"terminal={terminal} result={result.get('state')} "
              f"resolve_calls={calls_seen} native={native_ran} "
              f"registry={getattr(registry_rec, 'state', None)} "
              f"breaker={breaker.state.value}")
    return ok, detail


CASES = [
    ("INV-STORM", case_storm),
    ("INV-COOLDOWN", case_cooldown),
    ("INV-NATIVE", case_native),
    ("INV-GENUINE", case_genuine),
    ("INV-SCOPE-DROP", case_scope_drop),
]


def main() -> int:
    logging.getLogger("mediagrab").addHandler(logging.NullHandler())
    async def _run():
        vc = FP.import_voicechat()
        failed = 0
        for case_id, fn in CASES:
            try:
                ok, detail = await fn(vc)
            except Exception as exc:  # noqa: BLE001
                ok, detail = False, f"EXC {type(exc).__name__}: {exc}"
            status = "PASS" if ok else "FAIL"
            print(f"CASE {case_id}: {status} — {detail}")
            if not ok:
                failed += 1
        return failed

    failed = asyncio.run(_run())
    print(f"SUMMARY: {len(CASES) - failed}/{len(CASES)} cases passed")
    return failed


if __name__ == "__main__":
    sys.exit(main())
