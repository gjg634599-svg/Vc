"""v97.92 — Full reliability/performance/security audit fixes.

This version captures the output of a fresh independent deep audit of the
MediaGrab Bot. The previous v97.91 deployment's runtime log
(bot-diagnostic (4).log) showed a cascade:

  12:37:37 FloodWait 162s (systemic) → breaker OPEN globally
       → Join All stalls in WAITING_FOR_BREAKER for 162s+
       → registry accumulates stale "joined" records (no physical backend)
  13:10:04 BOTH MTProto recv_loops see [Errno 103] Software caused connection abort
  13:10:05 "Automatic reconnection failed 0 time(s)" x2 (both clients)
  13:11:05 EVENT_LOOP_LAG_HIGH 5.62s
  13:11:05 MTProto watchdog triggered safe reconnect (61s after disconnect!)
  13:11:08 drain fails with [Errno 103] (connection already gone)
  13:13:12 [Errno 104] Connection reset by peer
  13:13:32 MTPROTO_RECONNECT_ERROR exc=TimeoutError (connect timed out 15s)
  13:14:32, 13:16:48 watchdog retries — all drain/reconnect paths fail

v97.92 addresses the runtime-proven cascade root causes + source-proven
concurrency bugs surfaced by the audit:

  F1.  Watchdog: reduce poll from 60s → 10s + use fire-and-forget
       single-flight _mtproto_trigger_reconnect() instead of await.
  F2.  Health loop: trigger reconnect on disconnect (was: only log).
       Interval reduced from 120s → 30s.
  F3.  Suppress noisy loggers: aiosqlite, apscheduler, telegram, asyncio
       (the diagnostic log was 60% aiosqlite DEBUG spam).
  F4.  Asyncio exception handler: capture context.get("future") so
       Telethon socket recv futures get a useful task name (was: "?").
  F5.  v97.89 prewrap: add weakref.WeakSet as PRIMARY idempotency store
       (id() can be recycled by CPython GC → false "already wrapped" skip).
  F6.  _vc_reconnect_account: use _telethon_drain_and_reconnect_raw
       (was: bare disconnect+connect with no drain/snapshot/forced-cancel).
  F7.  Leave-block: allow leave when breaker has been OPEN > 30s
       (was: blocked for entire 162s FloodWait stall).
  F8.  Shutdown ordering: preserve the MTProto reconnect task until
       AFTER vc_leave_all_tracked + backend.stop() complete
       (was: blanket _active_tasks sweep cancelled it BEFORE leave RPCs).
  F9.  Orphaned asyncio.create_task callsites → supervised_create_task
       (3 sites in handlers.py: witai_test, witai_voice_check, disc_unified_search).
  F10. Admin MTProto handlers: bound with asyncio.wait_for (start=60s,
       stop=30s, restart=90s) — was: unbounded, could freeze the bot.
  F11. PID file: atomic write via tempfile + os.replace; verify
       /proc/<pid>/cmdline contains "mediagrab_bot" to detect PID reuse.
  F12. Deployment identity: add mtproto_sha256, bootstrap_sha256,
       handlers_sha256, join_all_worker_sha256 (was: only 3 hashes).
  F13. Distinguish reconciler log markers: VC_COVERAGE_RECONCILE_*
       (VCCoverageManager, 60s) vs VC_MOD_RECONCILE_* (module loop, 300s).
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_UTILS = os.path.join(_BASE, "mediagrab_bot", "utils_real.py")
_BOOTSTRAP = os.path.join(_BASE, "mediagrab_bot", "bootstrap.py")
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_HANDLERS = os.path.join(_BASE, "mediagrab_bot", "handlers.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


def _read(path):
    with open(path) as f:
        return f.read()


# =========================================================================
# F1: Watchdog — 10s poll + fire-and-forget trigger
# =========================================================================

class TestWatchdogFastDetection(unittest.TestCase):
    """F1: watchdog must poll every 10s + use fire-and-forget trigger."""

    def test_watchdog_interval_reduced(self):
        src = _read(_MTPROTO)
        idx = src.find("async def _mtproto_watchdog_loop")
        body = src[idx:idx + 4600]
        # v98.12 TEST-MECHANISM CORRECTION (documented): the literal
        # "asyncio.sleep(10)" became the v98.12 §11 adaptive cadence
        # (`_v9812_wd_interval = 30.0 if streak >= 6 else 10.0` — first
        # detection stays 10s; sustained-outage polling widens to 30s). The
        # INVARIANT this test guards (fast first detection, NEVER 60s) is
        # unchanged — the `else 10.0` arm IS the 10s poll.
        self.assertIn("else 10.0", body,
                      "watchdog must poll every 10s (was 60s)")
        self.assertNotIn("asyncio.sleep(60)", body,
                         "watchdog must NOT use 60s sleep anymore")

    def test_watchdog_uses_trigger_reconnect(self):
        src = _read(_MTPROTO)
        idx = src.find("async def _mtproto_watchdog_loop")
        body = src[idx:idx + 4000]
        self.assertIn("_mtproto_trigger_reconnect()", body,
                      "watchdog must use fire-and-forget _mtproto_trigger_reconnect()")

    def test_no_asyncio_shield_in_watchdog(self):
        """F1: no asyncio.shield() — the v97.73/v97.77 tests forbid it."""
        src = _read(_MTPROTO)
        idx = src.find("async def _mtproto_watchdog_loop")
        body = src[idx:idx + 4000]
        self.assertNotIn("asyncio.shield(", body)


# =========================================================================
# F2: Health loop — triggers reconnect, 30s interval
# =========================================================================

class TestHealthLoopTriggersReconnect(unittest.TestCase):
    """F2: health loop must trigger reconnect, not just log."""

    def test_health_loop_interval_reduced(self):
        src = _read(_MTPROTO)
        idx = src.find("async def _mtproto_health_loop")
        body = src[idx:idx + 3000]
        self.assertIn("asyncio.sleep(30)", body,
                      "health loop must poll every 30s (was 120s)")
        self.assertNotIn("asyncio.sleep(120)", body,
                         "health loop must NOT use 120s sleep anymore")

    def test_health_loop_triggers_reconnect(self):
        src = _read(_MTPROTO)
        idx = src.find("async def _mtproto_health_loop")
        body = src[idx:idx + 3000]
        self.assertIn("_mtproto_trigger_reconnect()", body,
                      "health loop must call _mtproto_trigger_reconnect() on disconnect")
        self.assertIn("MTPROTO_HEALTH_DISCONNECT_DETECTED", body)


# =========================================================================
# F3: Noisy logger suppression
# =========================================================================

class TestNoisyLoggersSuppressed(unittest.TestCase):
    """F3: aiosqlite, apscheduler, telegram, asyncio must be WARNING-level."""

    def test_aiosqlite_suppressed(self):
        src = _read(_UTILS)
        self.assertIn('"aiosqlite"', src,
                      "aiosqlite logger must be in the noisy-suppression list")

    def test_apscheduler_suppressed(self):
        src = _read(_UTILS)
        self.assertIn('"apscheduler"', src)

    def test_telegram_suppressed(self):
        src = _read(_UTILS)
        self.assertIn('"telegram"', src)

    def test_asyncio_suppressed(self):
        src = _read(_UTILS)
        self.assertIn('"asyncio"', src)


# =========================================================================
# F4: Asyncio exception handler captures future context
# =========================================================================

class TestAsyncioExceptionHandlerFutureContext(unittest.TestCase):
    """F4: asyncio exception handler must capture context.get('future')."""

    def test_future_context_captured(self):
        src = _read(_UTILS)
        self.assertIn('context.get("future")', src,
                      "asyncio exception handler must capture future context")


# =========================================================================
# F5: v97.89 prewrap — WeakSet as primary idempotency store
# =========================================================================

class TestPrewrapWeakSet(unittest.TestCase):
    """F5: prewrap must use weakref.WeakSet as the primary idempotency store."""

    def test_weakset_used(self):
        src = _read(_VOICECHAT)
        self.assertIn("weakref", src,
                      "prewrap must import + use weakref")
        self.assertIn("WeakSet", src,
                      "prewrap must use WeakSet for auto-eviction on GC")

    def test_id_based_check_preserved_for_compat(self):
        """The id-based check is preserved for backward-compat with v97.89 tests."""
        src = _read(_VOICECHAT)
        idx = src.find("def _prewrap_client_event_handlers")
        body = src[idx:idx + 3000]
        self.assertIn("if client_id in _PREWRAPPED_CLIENTS", body,
                      "id-based check preserved for v97.89 test backward-compat")

    def test_stale_id_pruning(self):
        """v97.92: stale id (from GC'd client) must be pruned, not skipped."""
        src = _read(_VOICECHAT)
        self.assertIn("PYTGCALLS_PREWRAP_STALE_ID_PRUNE", src,
                      "stale id pruning must be logged")


# =========================================================================
# F6: _vc_reconnect_account uses proper drain+reconnect
# =========================================================================

class TestVcReconnectAccountProperDrain(unittest.TestCase):
    """F6: _vc_reconnect_account must use _telethon_drain_and_reconnect_raw."""

    def test_uses_drain_and_reconnect_raw(self):
        src = _read(_VOICECHAT)
        idx = src.find("async def _vc_reconnect_account")
        body = src[idx:idx + 4000]
        self.assertIn("_telethon_drain_and_reconnect_raw", body,
                      "_vc_reconnect_account must use _telethon_drain_and_reconnect_raw")
        self.assertNotIn("await asyncio.wait_for(client.disconnect(), timeout=10)", body,
                         "must NOT use bare disconnect+connect anymore")
        self.assertNotIn("await asyncio.wait_for(client.connect(), timeout=15)", body,
                         "must NOT use bare disconnect+connect anymore")

    def test_bounded_timeout(self):
        src = _read(_VOICECHAT)
        idx = src.find("async def _vc_reconnect_account")
        # v98.12 TEST-MECHANISM CORRECTION (documented): window 4000 -> 6500 —
        # the v98.12 §14 single-flight gate (+ its docstring) sits above the
        # bounded wait_for; the INVARIANT (30s bound) is unchanged.
        body = src[idx:idx + 6500]
        self.assertIn("timeout=30", body,
                      "reconnect must be bounded by 30s (10s drain + 15s connect + 5s margin)")


# =========================================================================
# F7: Leave-block allows escape when breaker is stuck > 30s
# =========================================================================

class TestLeaveBlockBreakerStuckEscape(unittest.TestCase):
    """F7: leave-block must allow leave when breaker has been open > 30s."""

    def test_breaker_stuck_check_present(self):
        src = _read(_VOICECHAT)
        idx = src.find("def _vc_is_leave_blocked_during_join_all")
        body = src[idx:idx + 3000]
        self.assertIn("VC_LEAVE_ALLOWED_BREAKER_STUCK", body,
                      "leave-block must log VC_LEAVE_ALLOWED_BREAKER_STUCK when bypassing")

    def test_uses_breaker_seconds_since_opened(self):
        src = _read(_VOICECHAT)
        idx = src.find("def _vc_is_leave_blocked_during_join_all")
        body = src[idx:idx + 3000]
        self.assertIn("seconds_since_opened", body,
                      "leave-block must check breaker.seconds_since_opened")

    def test_30s_threshold(self):
        src = _read(_VOICECHAT)
        idx = src.find("def _vc_is_leave_blocked_during_join_all")
        body = src[idx:idx + 3000]
        self.assertIn("30.0", body,
                      "leave-block must use 30s as the breaker-stuck threshold")


# =========================================================================
# F8: Shutdown ordering — preserve MTProto reconnect task
# =========================================================================

class TestShutdownOrderingPreservesReconnect(unittest.TestCase):
    """F8: shutdown must preserve the MTProto reconnect task until AFTER leave RPCs."""

    def test_preserve_prefix_list_present(self):
        src = _read(_BOOTSTRAP)
        self.assertIn("_SHUTDOWN_PRESERVE_PREFIXES", src,
                      "shutdown must have a preserve-prefixes list")
        self.assertIn("mtproto_safe_reconnect", src,
                      "mtproto_safe_reconnect must be in the preserve list")

    def test_post_mtproto_stop_sweep(self):
        src = _read(_BOOTSTRAP)
        # The post-MTProto-stop sweep must exist (clears _active_tasks AFTER
        # vc_leave_all_tracked + backend.stop() + mtproto_stop()).
        idx = src.find("v97.92: NOW do the blanket sweep")
        self.assertGreater(idx, 0,
                           "post-MTProto-stop blanket sweep must be documented")


# =========================================================================
# F9: Orphaned asyncio.create_task → supervised_create_task
# =========================================================================

class TestOrphanedCreateTaskFixed(unittest.TestCase):
    """F9: the 3 orphaned asyncio.create_task callsites in handlers.py must be supervised."""

    def test_witai_test_connection_supervised(self):
        src = _read(_HANDLERS)
        # Find the witai_test_connection callsite — must use supervised_create_task
        idx = src.find("_witai_test_connection(update, context)")
        # Look 200 chars BEFORE the callsite for the supervisor
        context = src[max(0, idx - 200):idx + 100]
        self.assertIn("supervised_create_task", context,
                      "_witai_test_connection must use supervised_create_task")

    def test_witai_voice_check_handler_supervised(self):
        src = _read(_HANDLERS)
        idx = src.find("_witai_voice_check_handler(update, context)")
        context = src[max(0, idx - 200):idx + 100]
        self.assertIn("supervised_create_task", context,
                      "_witai_voice_check_handler must use supervised_create_task")

    def test_disc_unified_search_flow_supervised(self):
        src = _read(_HANDLERS)
        idx = src.find("_disc_unified_search_flow(update, context, text)")
        context = src[max(0, idx - 200):idx + 100]
        self.assertIn("supervised_create_task", context,
                      "_disc_unified_search_flow must use supervised_create_task")


# =========================================================================
# F10: Admin MTProto handlers — bounded with asyncio.wait_for
# =========================================================================

class TestAdminMtprotoHandlersBounded(unittest.TestCase):
    """F10: admin MTProto start/stop/restart must be bounded."""

    def test_start_bounded(self):
        src = _read(_HANDLERS)
        idx = src.find("async def mtproto__start(")
        body = src[idx:idx + 1500]
        self.assertIn("asyncio.wait_for(mtproto_manager.start()", body)
        self.assertIn("timeout=60", body)

    def test_stop_bounded(self):
        src = _read(_HANDLERS)
        idx = src.find("async def mtproto__stop(")
        body = src[idx:idx + 1500]
        self.assertIn("asyncio.wait_for(mtproto_manager.stop()", body)
        self.assertIn("timeout=30", body)

    def test_restart_bounded(self):
        src = _read(_HANDLERS)
        idx = src.find("async def mtproto__restart(")
        body = src[idx:idx + 1500]
        self.assertIn("asyncio.wait_for(mtproto_manager.restart()", body)
        self.assertIn("timeout=90", body)


# =========================================================================
# F11: PID file — atomic write + PID reuse detection
# =========================================================================

class TestPidFileAtomicCreation(unittest.TestCase):
    """F11: PID file must be created atomically + detect PID reuse."""

    def test_atomic_write_via_tempfile(self):
        src = _read(_BOOTSTRAP)
        self.assertIn("mkstemp", src,
                      "PID file must be created via tempfile.mkstemp (atomic)")
        self.assertIn("os.replace", src,
                      "PID file must be replaced via os.replace (atomic)")

    def test_pid_reuse_detection(self):
        src = _read(_BOOTSTRAP)
        self.assertIn("/proc/", src,
                      "PID reuse detection must check /proc/<pid>/cmdline")
        self.assertIn("mediagrab_bot", src,
                      "cmdline must contain 'mediagrab_bot' for PID reuse check")
        self.assertIn("V85_PID_REUSE_DETECTED", src,
                      "PID reuse must be logged with V85_PID_REUSE_DETECTED marker")


# =========================================================================
# F12: Deployment identity — extended source hashes
# =========================================================================

class TestDeploymentIdentityExtendedHashes(unittest.TestCase):
    """F12: DEPLOYMENT_IDENTITY must include hashes for all critical modules."""

    def test_mtproto_hash_present(self):
        src = _read(_BOOTSTRAP)
        self.assertIn("mtproto_sha256", src,
                      "DEPLOYMENT_IDENTITY must include mtproto_sha256")

    def test_bootstrap_hash_present(self):
        src = _read(_BOOTSTRAP)
        self.assertIn("bootstrap_sha256", src,
                      "DEPLOYMENT_IDENTITY must include bootstrap_sha256")

    def test_handlers_hash_present(self):
        src = _read(_BOOTSTRAP)
        self.assertIn("handlers_sha256", src,
                      "DEPLOYMENT_IDENTITY must include handlers_sha256")

    def test_join_all_worker_hash_present(self):
        src = _read(_BOOTSTRAP)
        self.assertIn("join_all_worker_sha256", src,
                      "DEPLOYMENT_IDENTITY must include join_all_worker_sha256")


# =========================================================================
# F13: Distinguished reconciler log markers
# =========================================================================

class TestReconcilerMarkersDistinguished(unittest.TestCase):
    """F13: VCCoverageManager + module reconciler must use distinct markers."""

    def test_coverage_manager_markers(self):
        src = _read(_VOICECHAT)
        idx = src.find("async def _reconcile_loop(self)")
        body = src[idx:idx + 3000]
        self.assertIn("VC_COVERAGE_RECONCILE_LOOP_STARTED", body)
        self.assertIn("VC_COVERAGE_RECONCILE_START", body)

    def test_module_loop_markers(self):
        src = _read(_VOICECHAT)
        # v99.07 (documented correction): window 3000 -> 3400 — the FIX-12
        # worker-heartbeat block at the loop head shifted the markers down.
        idx = src.find("async def _vc_reconcile_loop()")
        body = src[idx:idx + 3800]
        self.assertIn("VC_MOD_RECONCILE_LOOP_STARTED", body)
        self.assertIn("VC_MOD_RECONCILE_SKIP", body)


# =========================================================================
# Version bump
# =========================================================================

class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_92(self):
        src = _read(_INIT)
        # v97.93 update: bumped from v97.92 to v97.93 (audit-driven source fix).
        self.assertIn('__bot_version__ = "v99.11.3"', src)

    def test_deployment_identity_version(self):
        src = _read(_BOOTSTRAP)
        # v97.93 update: DEPLOYMENT_IDENTITY line bumped to v97.93.
        self.assertIn("version={_v9812_pkg_version}", src)  # v99: derivation site


# =========================================================================
# Preserved v97.91 fixes (must NOT regress)
# =========================================================================

class TestPreservedV97_91Fixes(unittest.TestCase):
    """Verify the v97.91 fixes are still present (no regression)."""

    def test_pytgcalls_logger_suppressed(self):
        src = _read(_UTILS)
        self.assertIn('logging.getLogger("pytgcalls").setLevel(logging.WARNING)', src)

    def test_pytgcalls_stop_guarded(self):
        src = _read(_VOICECHAT)
        self.assertIn("getattr(self._pytgcalls, \"stop\", None)", src)

    def test_setup_logging_called_in_main(self):
        src = _read(_BOOTSTRAP)
        idx = src.find("def main() -> None:")
        body = src[idx:idx + 1000]
        self.assertIn("setup_logging()", body)

    def test_prewrite_before_construction(self):
        src = _read(_VOICECHAT)
        self.assertIn("_prewrap_client_event_handlers", src)

    def test_backend_preservation(self):
        src = _read(_VOICECHAT)
        self.assertIn("VC_BACKEND_PRESERVED", src)

    def test_stale_joined_record(self):
        src = _read(_VOICECHAT)
        self.assertIn("VC_STALE_JOINED_RECORD", src)

    def test_forced_cancel(self):
        src = _read(_MTPROTO)
        self.assertIn("_mediagrab_bg_tasks", src)


if __name__ == "__main__":
    unittest.main()
