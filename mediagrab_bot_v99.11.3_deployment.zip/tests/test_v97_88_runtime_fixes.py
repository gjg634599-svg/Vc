"""
v97.88 — DEPLOYMENT IDENTITY + DIAGNOSTIC LOGGING REBUILD.

Changes:
  1. DEPLOYMENT_IDENTITY at startup — version, source SHA256 fingerprints,
     Python version, pytgcalls/telethon versions, PID, CWD. This PROVES which
     source is actually deployed — no more guessing from line numbers.
  2. DIAGNOSTIC_BOOT — emitted at the ABSOLUTE earliest point, before any file
     operations. Reports raw .env value, parsed value, PID, CWD, Python path.
  3. DIAGNOSTIC_PATH — reports configured path, absolute path, parent directory
     existence/writability BEFORE attempting file creation.
  4. DIAGNOSTIC_FILE_CREATE_RESULT — reports success/failure with exception+errno.
  5. DIAGNOSTIC_FALLBACK — if the configured path fails, creates
     /tmp/mediagrab_diagnostic_<pid>.log as a guaranteed fallback.
  6. All OSError exceptions are printed to stderr — NEVER silently swallowed.

  Plus all v97.80-v97.87 fixes preserved:
  - PyTgCalls filter (no idempotency guard, already-filtered check)
  - Backend preservation (vc_reset_backend preserves active backends)
  - Stale joined record detection
  - FloodWait DEFER (not EXCLUDE)
  - Stale checkpoint fix
  - is_open property access
  - Leave block during Join All
  - VC_TARGET_STATE_TRANSITION logging
  - Forced-cancel client-specific
  - MTProto reconnect instrumentation
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_UTILS = os.path.join(_BASE, "mediagrab_bot", "utils_real.py")
_BOOTSTRAP = os.path.join(_BASE, "mediagrab_bot", "bootstrap.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


class TestDeploymentIdentity(unittest.TestCase):
    """v97.88: DEPLOYMENT_IDENTITY at startup."""

    def test_deployment_identity_emitted(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn("DEPLOYMENT_IDENTITY", src)
        self.assertIn("voicechat_sha256=", src)
        self.assertIn("utils_real_sha256=", src)
        self.assertIn("python_executable=", src)
        self.assertIn("pytgcalls_version=", src)
        self.assertIn("pid=", src)
        self.assertIn("cwd=", src)

    def test_source_fingerprints_calculated(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn("hashlib", src)
        self.assertIn("sha256", src)


class TestDiagnosticLogging(unittest.TestCase):
    """v97.88: complete diagnostic logging rebuild."""

    def test_diagnostic_boot_emitted(self):
        with open(_UTILS) as f:
            src = f.read()
        self.assertIn("DIAGNOSTIC_BOOT", src)
        self.assertIn("raw_env=", src)
        self.assertIn("parsed=", src)

    def test_diagnostic_path_reported(self):
        with open(_UTILS) as f:
            src = f.read()
        self.assertIn("DIAGNOSTIC_PATH", src)
        self.assertIn("configured_path=", src)
        self.assertIn("absolute_path=", src)
        self.assertIn("parent_exists=", src)
        self.assertIn("parent_writable=", src)

    def test_file_create_result_reported(self):
        with open(_UTILS) as f:
            src = f.read()
        self.assertIn("DIAGNOSTIC_FILE_CREATE_RESULT", src)
        self.assertIn("success=", src)

    def test_fallback_file_created(self):
        with open(_UTILS) as f:
            src = f.read()
        self.assertIn("DIAGNOSTIC_FALLBACK_FILE_CREATED", src)
        self.assertIn("/tmp/mediagrab_diagnostic_", src)

    def test_no_silent_oserror_swallow(self):
        with open(_UTILS) as f:
            src = f.read()
        # Find the diagnostic section
        idx = src.find("_diag_log_path = None")
        self.assertGreater(idx, 0)
        block = src[idx:idx + 3000]
        self.assertNotIn("except OSError:\n            pass", block)
        self.assertNotIn("except OSError:\n        pass", block)

    def test_env_parsed_directly(self):
        """v97.88: .env is parsed directly, not through _env_bool."""
        with open(_UTILS) as f:
            src = f.read()
        self.assertIn('_raw_env = _os.environ.get("DIAGNOSTIC_LOGGING", "")', src)
        self.assertIn('_parsed_env = _raw_env.strip().lower() in ("1", "true", "yes", "on")', src)

    def test_diagnostic_initialized_with_pid(self):
        with open(_UTILS) as f:
            src = f.read()
        self.assertIn("DIAGNOSTIC_LOGGING_INITIALIZED", src)
        self.assertIn("pid=", src)

    def test_handler_flushed(self):
        with open(_UTILS) as f:
            src = f.read()
        self.assertIn("diag_handler.flush()", src)


class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_92(self):
        with open(_INIT) as f:
            src = f.read()
        self.assertIn('__bot_version__ = "v99.11.3"', src)


class TestPreservedFixes(unittest.TestCase):
    """Verify all prior fixes preserved."""

    def test_pytgcalls_filter_no_idempotency_guard(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _wrap_pytgcalls_update_filter")
        body = src[idx:idx + 800]
        self.assertNotIn("if client_id in _PYTGCALLS_WRAPPED_CLIENTS", body)

    def test_already_filtered_check(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn('_cb_name == "_filtered_update_handler"', src)

    def test_backend_preservation(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_BACKEND_PRESERVED", src)
        self.assertIn("preserve_connections", src)

    def test_backend_stop_instrumentation(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_BACKEND_STOP_REQUEST", src)

    def test_stale_joined_record(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_STALE_JOINED_RECORD", src)

    def test_is_open_property(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("VC_TRACKING_SNAPSHOT")
        block = src[idx:idx + 1200]
        self.assertIn("_vc_join_all_breaker.is_open ", block)

    def test_floodwait_defer(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_TARGET_FLOODWAIT_DEFERRED", src)

    def test_leave_block(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_LEAVE_BLOCKED_DURING_JOIN_ALL", src)

    def test_forced_cancel(self):
        mtproto = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
        with open(mtproto) as f:
            src = f.read()
        self.assertIn("_mediagrab_bg_tasks", src)

    def test_reconnect_instrumentation(self):
        mtproto = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
        with open(mtproto) as f:
            src = f.read()
        self.assertIn("MTPROTO_RECONNECT_BEGIN", src)


class TestDiagnosticEnvParsing(unittest.TestCase):
    """Test .env parsing for DIAGNOSTIC_LOGGING."""

    def test_true_parsed(self):
        raw = "true"
        result = raw.strip().lower() in ("1", "true", "yes", "on")
        self.assertTrue(result)

    def test_TRUE_parsed(self):
        raw = "TRUE"
        result = raw.strip().lower() in ("1", "true", "yes", "on")
        self.assertTrue(result)

    def test_1_parsed(self):
        raw = "1"
        result = raw.strip().lower() in ("1", "true", "yes", "on")
        self.assertTrue(result)

    def test_yes_parsed(self):
        raw = "yes"
        result = raw.strip().lower() in ("1", "true", "yes", "on")
        self.assertTrue(result)

    def test_empty_not_parsed(self):
        raw = ""
        result = bool(raw) and raw.strip().lower() in ("1", "true", "yes", "on")
        self.assertFalse(result)

    def test_false_not_parsed(self):
        raw = "false"
        result = raw.strip().lower() in ("1", "true", "yes", "on")
        self.assertFalse(result)


if __name__ == "__main__":
    unittest.main()
