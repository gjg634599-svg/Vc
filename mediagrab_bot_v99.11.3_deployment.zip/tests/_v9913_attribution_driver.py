"""v99.11.3 FIX-1 — bookkeeping completion + attribution-pass driver.

Runs the REAL production seams via the proven v98.10 fastpath harness
(IN A SUBPROCESS — the harness stubs telethon/telegram/mtproto module
surfaces, so the pytest suites assert on this driver's output instead
of importing the harness in-process; the v99.11.2 convention).

The seams under test (the exact production boundaries):

    BOOK-ABSENT  — the 2026-09-25 stuck-STOPPING class: tracker says
                   STOPPING, the calls container does NOT hold the
                   chat (verified absent) → the cleanup's early exit
                   now finalizes the record to RELEASED (the 8-chat /
                   360× leak-suspect-noise repair).
    BOOK-DENIED  — the EXACT 17:09:55 production sequence: the
                   container held the object at cleanup START, the
                   leave was DENIED, the object vanished by re-check
                   time → RELEASED (not stuck STOPPING).
    BOOK-SUCCESS — the authorized release: object present, verified
                   dead, released via the policy → RELEASED + the
                   container entry gone.
    PASS-ORPHAN  — the drift attribution pass: an ORPHAN native object
                   (container, no tracker record, registry NOT joined)
                   is classified orphan and RELEASED through the
                   authorized cleanup (bounded remediation).
    PASS-ACTIVE  — a HEALTHY ACTIVE transport (container + tracker
                   ACTIVE + registry joined) is NEVER touched by the
                   remediation pass.
    PASS-RATE    — the pass is rate-limited (60s) and single-flight.

Exit code = number of failed cases.
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys
import types

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import _v9810_fastpath_driver as FP  # noqa: E402


async def case_book_absent(vc):
    w = await FP.reset_world(vc)
    from mediagrab_bot import vc_resources as _vr
    _vr.transport_lifecycle.mark_stopping(
        FP.RAW, reason="stale_joined_record:backend_disconnected")
    before = _vr.transport_lifecycle.get_state(FP.RAW)
    out = await vc._vc_cleanup_stale_backend_call(
        int(FP.RAW), reason="stale_joined_record",
        reason_code="STALE_CONTAINER_VERIFIED_ABSENT",
        evidence="test: verified absent")
    after = _vr.transport_lifecycle.get_state(FP.RAW)
    ok = before == "STOPPING" and after == "RELEASED" and out is True
    detail = f"before={before} after={after} out={out}"
    return ok, detail


async def case_book_denied(vc):
    w = await FP.reset_world(vc)
    from mediagrab_bot import vc_resources as _vr
    marked = FP.MARKED_BASE - FP.RAW
    w.global_b._pytgcalls.calls[marked] = types.SimpleNamespace(
        chat_id=marked)
    _vr.transport_lifecycle.mark_stopping(
        marked, reason="stale_joined_record:backend_disconnected")
    _res_calls = [0]
    _orig = vc.vc_resolve_calls_container

    async def _vanishing(account_id: str = ""):
        _res_calls[0] += 1
        if _res_calls[0] <= 1:
            return w.global_b._pytgcalls.calls
        return {}
    vc.vc_resolve_calls_container = _vanishing
    try:
        out = await vc._vc_cleanup_stale_backend_call(
            int(marked), reason="stale_joined_record",
            reason_code="", evidence="")
        state = _vr.transport_lifecycle.get_state(marked)
    finally:
        vc.vc_resolve_calls_container = _orig
    ok = state == "RELEASED"
    detail = f"state={state} out={out}"
    return ok, detail


async def case_book_success(vc):
    w = await FP.reset_world(vc)
    from mediagrab_bot import vc_resources as _vr
    marked = FP.MARKED_BASE - FP.RAW
    w.global_b._pytgcalls.calls[marked] = types.SimpleNamespace(
        chat_id=marked)
    _vr.transport_lifecycle.mark_stopping(marked, reason="test")
    out = await vc._vc_cleanup_stale_backend_call(
        int(marked), reason="stale_joined_record",
        reason_code="STALE_CONTAINER_VERIFIED_ABSENT",
        evidence="test: object present, verified dead")
    state = _vr.transport_lifecycle.get_state(marked)
    in_container = marked in w.global_b._pytgcalls.calls
    ok = out is True and state == "RELEASED" and not in_container
    detail = f"out={out} state={state} in_container={in_container}"
    return ok, detail


async def case_pass_orphan(vc):
    w = await FP.reset_world(vc)
    # isolate the tracker (prior cases leave terminal records that
    # classify as stale_in_container instead of orphan)
    from mediagrab_bot import vc_resources as _vro
    _vro.transport_lifecycle._records.clear()
    marked = FP.MARKED_BASE - FP.RAW
    w.global_b._pytgcalls.calls[marked] = types.SimpleNamespace(
        chat_id=marked)
    released: list = []

    async def _leave_target(chat_id):
        released.append(chat_id)
        w.global_b._pytgcalls.calls.pop(marked, None)
        return "left"
    w.global_b._leave_target = _leave_target
    vc._v9913_last_attribution_ts = 0.0
    out = await vc.vc_fd_drift_attribution_pass(
        remediate=True, max_remediations=4)
    still = marked in w.global_b._pytgcalls.calls
    ok = out.get("orphans") == [FP.RAW] and len(released) == 1 \
        and not still
    detail = (f"orphans={out.get('orphans')} released={released} "
              f"still={still}")
    return ok, detail


async def case_pass_active(vc):
    w = await FP.reset_world(vc)
    from mediagrab_bot import vc_resources as _vr
    raw = FP.RAW
    marked = FP.MARKED_BASE - raw
    w.global_b._pytgcalls.calls[marked] = types.SimpleNamespace(
        chat_id=marked)
    _vr.transport_lifecycle.mark_allocating(marked, "acc_A")
    _vr.transport_lifecycle.mark_active(marked, "dispatch_ok")
    w.join_on(w.global_b, raw)
    touched: list = []

    async def _leave_target(chat_id):
        touched.append(chat_id)
        return "left"
    w.global_b._leave_target = _leave_target
    vc._v9913_last_attribution_ts = 0.0
    out = await vc.vc_fd_drift_attribution_pass(
        remediate=True, max_remediations=4)
    still = marked in w.global_b._pytgcalls.calls
    ok = touched == [] and still and out.get("tracked_active") == [raw]
    detail = (f"touched={touched} still={still} "
              f"tracked_active={out.get('tracked_active')}")
    return ok, detail


async def case_pass_rate(vc):
    await FP.reset_world(vc)
    vc._v9913_last_attribution_ts = 0.0
    out1 = await vc.vc_fd_drift_attribution_pass()
    out2 = await vc.vc_fd_drift_attribution_pass()
    vc._v9913_last_attribution_ts = 0.0
    vc._v9913_attribution_pass_running = True
    out3 = await vc.vc_fd_drift_attribution_pass()
    vc._v9913_attribution_pass_running = False
    ok = "container_count" in out1 and out2 == {} and out3 == {}
    detail = (f"first={sorted(out1.keys())[:4]} second_empty={out2 == {}} "
              f"singleflight_empty={out3 == {}}")
    return ok, detail


CASES = [
    ("BOOK-ABSENT", case_book_absent),
    ("BOOK-DENIED", case_book_denied),
    ("BOOK-SUCCESS", case_book_success),
    ("PASS-ORPHAN", case_pass_orphan),
    ("PASS-ACTIVE", case_pass_active),
    ("PASS-RATE", case_pass_rate),
]


def main() -> int:
    logging.getLogger("mediagrab").addHandler(logging.NullHandler())
    async def _run():
        vc = FP.import_voicechat()
        failed = 0
        for case_id, fn in CASES:
            try:
                ok, detail = await fn(vc)
            except Exception as exc:  # noqa: BLE001
                ok, detail = False, f"EXC {type(exc).__name__}: {exc}"
            status = "PASS" if ok else "FAIL"
            print(f"CASE {case_id}: {status} — {detail}")
            if not ok:
                failed += 1
        return failed

    failed = asyncio.run(_run())
    print(f"SUMMARY: {len(CASES) - failed}/{len(CASES)} cases passed")
    return failed


if __name__ == "__main__":
    sys.exit(main())
