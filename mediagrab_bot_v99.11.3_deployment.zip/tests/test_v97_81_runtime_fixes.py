"""
v97.81 RUNTIME-DRIVEN FORENSIC FIX tests.

Root causes fixed in v97.81 (driven by REAL production runtime log — note 51):

  RC1 (SOURCE-PROVEN): Discovery EXCLUDED VCs during FloodWait — the v97.80 code
      did `excluded_count += 1; continue` which DROPPED the VC from discovery
      entirely → user sees "only 4 VCs". v97.81 FIX: DEFER instead of EXCLUDE.
      The VC stays in the snapshot; the join phase defers via the breaker.

  RC2 (SOURCE-PROVEN): Stale checkpoint auto-resume — manual Join All button
      click auto-resumed from `terminal_status='stopped'` checkpoint, reusing
      OLD targets (only 4) and skipping discovery. v97.81 FIX: manual Join All
      (no explicit resume_run_id) only resumes from `''` (truly incomplete),
      NOT from `'stopped'` (interrupted by bot restart).

  RC3 (SOURCE-PROVEN): _vc_leave_unlocked (tour auto-leave path) bypassed
      VC_AUTOMATIC_LEAVE instrumentation — the v97.80 audit incorrectly
      concluded "no auto-leave occurred" because the tour's auto-leave
      (stay_seconds=300, reason="Auto") wasn't logged. v97.81 FIX: added
      VC_AUTOMATIC_LEAVE logging to _vc_leave_unlocked with caller context.

  RC4 (SOURCE-PROVEN): No per-VC tracking / run IDs — the runtime log couldn't
      attribute VCs to specific Join All runs. v97.81 FIX: added run_id
      generation + VC_TRACKING_SNAPSHOT with discovered/eligible/excluded/
      dead_lettered/floodwait_deferred counts.
"""
import asyncio
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


class TestRC1FloodWaitDeferNotExclude(unittest.TestCase):
    """RC1: discovery must DEFER VCs during FloodWait, not EXCLUDE them."""

    def test_no_floodwait_exclude_continue(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        # Find the discovery loop's floodwait check (the one with VC_TARGET_FLOODWAIT_DEFERRED)
        idx = src.find("VC_TARGET_FLOODWAIT_DEFERRED")
        self.assertGreater(idx, 0, "VC_TARGET_FLOODWAIT_DEFERRED not found")
        # Get a generous window before the DEFERRED log to find the floodwait check
        window = src[max(0, idx - 1000):idx + 200]
        self.assertIn("if vc_is_global_floodwait_active():", window,
                      "floodwait check must be near the DEFERRED log")
        self.assertIn("VC_TARGET_FLOODWAIT_DEFERRED", window)
        self.assertIn("floodwait_deferred", window)
        # The floodwait branch must NOT have `continue` — check the lines between
        # the `if vc_is_global_floodwait_active():` and the next `try:` (end of branch)
        if_idx = window.find("if vc_is_global_floodwait_active():")
        try_idx = window.find("try:", if_idx)
        if try_idx > 0:
            branch = window[if_idx:try_idx]
        else:
            branch = window[if_idx:]
        for line in branch.split("\n"):
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith('logger'):
                continue
            if "floodwait_deferred" in stripped or "VC_TARGET_FLOODWAIT_DEFERRED" in stripped:
                continue
            # The floodwait branch must NOT have `continue` (which would exclude)
            self.assertNotIn("continue", stripped,
                             "floodwait branch must not continue (exclude): %s" % stripped)

    def test_floodwait_deferred_counter_added(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("floodwait_deferred", src)


class TestRC2NoStaleCheckpointAutoResume(unittest.TestCase):
    """RC2: manual Join All must NOT auto-resume from 'stopped' checkpoint."""

    def test_resumable_statuses_check_explicit_resume(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_is_explicit_resume = bool(resume_run_id)", src)
        self.assertIn('_resumable_statuses = ("", None) if not _is_explicit_resume', src)

    def test_stopped_not_resumable_on_manual(self):
        """Manual Join All (no resume_run_id) must NOT resume from 'stopped'."""
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("_resumable_statuses")
        self.assertGreater(idx, 0)
        block = src[idx:idx + 300]
        # When NOT explicit resume, only '' and None are resumable (not 'stopped')
        self.assertIn('("", None) if not _is_explicit_resume', block)


class TestRC3LeaveInstrumentationOnUnlocked(unittest.TestCase):
    """RC3: _vc_leave_unlocked must log VC_AUTOMATIC_LEAVE."""

    def test_vc_automatic_leave_in_leave_unlocked(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("async def _vc_leave_unlocked(")
        self.assertGreater(idx, 0)
        body = src[idx:idx + 2000]
        self.assertIn("VC_AUTOMATIC_LEAVE", body)
        self.assertIn("caller=", body)
        self.assertIn("reason=", body)

    def test_vc_automatic_leave_in_leave_target(self):
        """v97.80's instrumentation on vc_leave_target is preserved (v97.83 renamed to VC_LEAVE_REQUEST)."""
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("async def vc_leave_target(")
        self.assertGreater(idx, 0)
        body = src[idx:idx + 3000]
        self.assertIn("VC_LEAVE_REQUEST", body)
        self.assertIn("caller=", body)
        # v97.83: _vc_leave_unlocked still has VC_AUTOMATIC_LEAVE
        idx2 = src.find("async def _vc_leave_unlocked(")
        body2 = src[idx2:idx2 + 3000]
        self.assertIn("VC_AUTOMATIC_LEAVE", body2)


class TestRC4PerVCTrackingAndRunIds(unittest.TestCase):
    """RC4: per-VC tracking + run IDs."""

    def test_run_id_generated(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _vc_join_all_reset_state")
        body = src[idx:idx + 500]
        self.assertIn("run_id", body)

    def test_vc_tracking_snapshot_logged(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_TRACKING_SNAPSHOT", src)
        self.assertIn("discovered=", src)
        self.assertIn("eligible=", src)
        self.assertIn("excluded=", src)
        self.assertIn("dead_lettered=", src)
        self.assertIn("floodwait_deferred=", src)
        self.assertIn("breaker_open=", src)
        self.assertIn("mtproto_connected=", src)


class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_92(self):
        with open(_INIT) as f:
            src = f.read()
        self.assertIn('__bot_version__ = "v99.11.3"', src)


# ---------------------------------------------------------------------------
# BEHAVIORAL TESTS — FloodWait DEFER + idempotent cycles
# ---------------------------------------------------------------------------

class TestFloodWaitDeferBehavioral(unittest.TestCase):
    """Prove that FloodWait DEFER keeps VCs in the eligible set."""

    def test_floodwait_does_not_exclude_from_discovery(self):
        """Simulate the discovery loop: FloodWait active → VC still discovered."""
        global_floodwait_active = True
        discovered_vcs = [1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008]
        excluded = []
        deferred = []
        eligible = []

        for gid in discovered_vcs:
            if global_floodwait_active:
                # v97.81: DEFER (not EXCLUDE)
                deferred.append(gid)
                # Do NOT continue — VC stays in the pipeline
            eligible.append(gid)

        # All VCs must be eligible (not excluded)
        self.assertEqual(len(eligible), 8)
        self.assertEqual(len(deferred), 8)
        self.assertEqual(len(excluded), 0)

    def test_no_floodwait_all_eligible(self):
        """Without FloodWait, all VCs are eligible."""
        global_floodwait_active = False
        discovered_vcs = [1001, 1002, 1003, 1004, 1005]
        eligible = [v for v in discovered_vcs if True]  # no exclusion
        self.assertEqual(len(eligible), 5)


class TestStaleCheckpointBehavioral(unittest.TestCase):
    """Prove that manual Join All doesn't auto-resume from 'stopped'."""

    def test_manual_join_all_ignores_stopped_checkpoint(self):
        """Simulate the checkpoint resume decision."""
        resume_run_id = ""  # manual button click (no explicit resume)
        checkpoint_status = "stopped"
        _is_explicit_resume = bool(resume_run_id)
        _resumable_statuses = ("", None) if not _is_explicit_resume else ("", "stopped", None)
        should_resume = checkpoint_status in _resumable_statuses
        self.assertFalse(should_resume,
                         "manual Join All must NOT resume from 'stopped' checkpoint")

    def test_explicit_resume_accepts_stopped(self):
        """Startup recovery (explicit resume_run_id) CAN resume from 'stopped'."""
        resume_run_id = "R12345"  # explicit resume
        checkpoint_status = "stopped"
        _is_explicit_resume = bool(resume_run_id)
        _resumable_statuses = ("", None) if not _is_explicit_resume else ("", "stopped", None)
        should_resume = checkpoint_status in _resumable_statuses
        self.assertTrue(should_resume,
                        "explicit resume CAN resume from 'stopped'")


class TestLeaveInstrumentationBehavioral(unittest.TestCase):
    """Prove the leave instrumentation captures caller context."""

    def test_caller_detection(self):
        """Simulate the caller-detection logic from _vc_leave_unlocked."""
        import inspect

        async def _vc_tour_loop():
            # Simulate calling _vc_leave_unlocked
            frame = inspect.currentframe().f_back if inspect.currentframe() else None
            caller = frame.f_code.co_name if frame else "?"
            return caller

        async def driver():
            return await _vc_tour_loop()

        result = asyncio.new_event_loop().run_until_complete(driver())
        self.assertEqual(result, "driver")  # the caller of _vc_tour_loop


class TestIdempotentCycles(unittest.TestCase):
    """Join All / Leave All cycles remain idempotent (v97.78-v97.80 preserved)."""

    class _FakeState:
        def __init__(self):
            self.entity_fail_counts = {}
            self.target_cooldowns = {}
            self.no_active_call_cooldowns = {}
            self.reconcile_cooldowns = {}
            self.global_floodwait_until = 0.0
            self.breaker_open = False
            self.worker_alive = False
            self.FAIL_THRESHOLD = 3

        def is_dead_lettered(self, chat_id):
            return self.entity_fail_counts.get(chat_id, 0) >= self.FAIL_THRESHOLD

        def record_failure(self, chat_id):
            c = self.entity_fail_counts.get(chat_id, 0) + 1
            self.entity_fail_counts[chat_id] = c

        def reset_target_state(self, include_global_floodwait=False):
            cleared = len(self.entity_fail_counts)
            self.entity_fail_counts.clear()
            self.target_cooldowns.clear()
            self.no_active_call_cooldowns.clear()
            self.reconcile_cooldowns.clear()
            if include_global_floodwait:
                self.global_floodwait_until = 0.0
            self.breaker_open = False
            self.worker_alive = False
            return cleared

    def test_join_all_leave_all_5_cycles(self):
        state = self._FakeState()
        vcs = list(range(1001, 1011))
        for cycle in range(5):
            eligible = [v for v in vcs if not state.is_dead_lettered(v)]
            self.assertEqual(len(eligible), 10, f"cycle {cycle}")
            for v in vcs:
                state.record_failure(v)
            state.reset_target_state(include_global_floodwait=True)
        self.assertEqual(len(state.entity_fail_counts), 0)

    def test_floodwait_does_not_dead_letter(self):
        state = self._FakeState()
        self.assertFalse(state.is_dead_lettered(4001))

    def test_dead_letter_cleared_on_leave_all(self):
        state = self._FakeState()
        for v in range(2000, 2010):
            for _ in range(3):
                state.record_failure(v)
        cleared = state.reset_target_state(include_global_floodwait=True)
        self.assertEqual(cleared, 10)
        self.assertEqual(len(state.entity_fail_counts), 0)

    def test_one_dead_letter_no_suppression(self):
        state = self._FakeState()
        for _ in range(3):
            state.record_failure(6001)
        vcs = [6001, 6002, 6003, 6004, 6005]
        eligible = [v for v in vcs if not state.is_dead_lettered(v)]
        self.assertEqual(len(eligible), 4)


class TestForcedCancelPreserved(unittest.TestCase):
    """v97.79 client-specific forced-cancel preserved."""

    def test_forced_cancel_uses_snapshot(self):
        mtproto_path = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
        with open(mtproto_path) as f:
            src = f.read()
        idx = src.find("async def _forcibly_cancel_telethon_tasks(")
        self.assertGreater(idx, 0)
        body = src[idx:idx + 3000]
        self.assertIn("_mediagrab_bg_tasks", body)
        self.assertIn("v97.79_client_specific_retirement", body)


class TestPyTgCallsFilterPreserved(unittest.TestCase):
    """v97.80 PyTgCalls filter (correct API) preserved."""

    def test_filter_uses_correct_api(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _wrap_pytgcalls_update_filter(")
        body = src[idx:idx + 3000]
        self.assertIn("list_event_handlers", body)
        self.assertIn("remove_event_handler", body)
        self.assertIn("add_event_handler", body)

    def test_filter_called_after_start(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        start_idx = src.find("await self._pytgcalls.start()")
        self.assertGreater(start_idx, 0)
        filter_idx = src.find("_wrap_pytgcalls_update_filter(self._mtproto)", start_idx)
        self.assertGreater(filter_idx, 0)


if __name__ == "__main__":
    unittest.main()
