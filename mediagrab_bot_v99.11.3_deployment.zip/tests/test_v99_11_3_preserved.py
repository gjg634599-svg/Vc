"""v99.11.3 — PRESERVED-BEHAVIOR SUITE (the task matrix 14-20).

Asserts that the v99.11.3 remediation did NOT regress any protected
subsystem (the task's PRESERVE list):

  14. same-account already-joined still converges (v99.11.2 — breaker
      unchanged, registry synced to joined under the owner);
  15. different-account already-joined remains conflict (foreign
      owner → failure accounting + breaker);
  16. unknown owner remains conservative (unparseable owner →
      conflict, never guessed);
  17. UNKNOWN remains no-leave (the v99.11 P0 preserve class);
  18. RECOVERY_PENDING remains no-leave;
  19. heartbeat remains valid (the census + drift detector + sweep
      wiring unchanged in shape);
  20. SQLite tests remain green (the WAL suite still collected and
      passing — asserted by suite presence + a live run of its key
      cases).

FIX 3 measurement (documented, no change): the 2026-09-25/26 logs show
VC_SNAPSHOT_STALE_UNEXPECTED_STATE at 36 events total, ≤2 per chat
(~40 min apart), states joined=14 / not_registered=22 — NOT a repeated
reprocessing loop, no measurable contribution to the FD or
invalid-entity problems.  The task's rule ("only modify if the
evidence demonstrates contribution") → NO modification; the evidence
is asserted here as a contract so the decision is auditable.
"""

from __future__ import annotations

import os
import subprocess
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

_ROOT = str(Path(__file__).resolve().parents[1])
_VC = os.path.join(_ROOT, "mediagrab_bot", "voicechat.py")
_VR = os.path.join(_ROOT, "mediagrab_bot", "vc_resources.py")
_HD = os.path.join(_ROOT, "mediagrab_bot", "handlers.py")
_DRV_CONV = os.path.join(_ROOT, "tests", "_v9912_convergence_driver.py")
_DRV_RACE = os.path.join(_ROOT, "tests", "_v9911_1_race_driver.py")


def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


class TestAlreadyJoinedPreserved(unittest.TestCase):
    """Matrix 14-16 — the v99.11.2 convergence contract, re-verified
    end-to-end through the REAL-worker drivers (same seam as
    production: the worker's except-VCTransportError boundary)."""

    def test_a1_same_account_and_cluster_owned_converge(self):
        """14 — same-account AND cluster-owned already-joined converge
        idempotently; the breaker records nothing (the 9/9 driver
        includes CONV-SAME-ACCOUNT + CONV-CLUSTER-OWNED + CONV-STORM +
        CONV-WRAPPED)."""
        proc = subprocess.run(
            [sys.executable, _DRV_CONV],
            capture_output=True, text=True, timeout=300.0)
        self.assertEqual(proc.returncode, 0,
                         f"convergence driver regressed:\n"
                         f"{proc.stdout[-2000:]}")
        self.assertIn("SUMMARY: 9/9 cases passed", proc.stdout)

    def test_a2_different_account_conflict_preserved(self):
        """15 — a FOREIGN owner keeps the conflict semantics (failure
        accounting + breaker + RECOVERING) — the driver's
        CONV-DIFF-ACCOUNT case (included in the 9/9)."""
        proc = subprocess.run(
            [sys.executable, _DRV_CONV],
            capture_output=True, text=True, timeout=300.0)
        self.assertIn("CASE CONV-DIFF-ACCOUNT: PASS", proc.stdout)

    def test_a3_unknown_owner_conservative_preserved(self):
        """16 — the unparseable owner stays conservative (CONV-UNKNOWN-
        OWNER in the 9/9)."""
        proc = subprocess.run(
            [sys.executable, _DRV_CONV],
            capture_output=True, text=True, timeout=300.0)
        self.assertIn("CASE CONV-UNKNOWN-OWNER: PASS", proc.stdout)

    def test_a4_v9911_1_race_matrix_still_green(self):
        """The v99.11.1 race driver (same-account idempotent /
        different-account conflict / storm-stays-CLOSED) — unchanged."""
        proc = subprocess.run(
            [sys.executable, _DRV_RACE],
            capture_output=True, text=True, timeout=300.0)
        self.assertEqual(proc.returncode, 0,
                         f"race driver regressed:\n{proc.stdout[-2000:]}")
        self.assertIn("SUMMARY: 3/3 cases passed", proc.stdout)


class TestNoLeavePreserves(unittest.TestCase):
    """Matrix 17-18 — UNKNOWN / RECOVERY_PENDING remain no-leave (the
    v99.11 P0 preserve class).  v99.11.3's new authorized reasons
    (STALE_CONTAINER_VERIFIED_ABSENT / RECONCILE_CONFIRMED_ABSENT)
    must NOT extend the destructive surface to UNKNOWN-state targets:
    only positive evidence of death/absence authorizes a release."""

    def test_b1_unknown_no_leave_preserved(self):
        src = _read(_VC)
        # the v99.11.1 snap_reason preserve branches are intact
        for marker in (
                "VC_SNAPSHOT_STALE_UNEXPECTED_STATE",
                "PRESERVING",
                "no recovery",
                "no leave"):
            self.assertIn(marker, src)

    def test_b2_recovery_pending_no_leave(self):
        src = _read(_VC)
        self.assertIn("recovery_pending", src)
        # the v99.11.1 suite still guards the semantics
        self.assertTrue(os.path.exists(os.path.join(
            _ROOT, "tests", "test_v99_11_1_snap_reason.py")))

    def test_b3_new_reasons_still_require_positive_evidence(self):
        """The v99.11.3 carve-out does not weaken the evidence
        requirement: an UNKNOWN-state leave attempt with a validated
        reason but NO evidence is still denied."""
        sys.path.insert(0, _ROOT)
        from mediagrab_bot import vc_leave_policy as lp
        ok, why = lp.vc_leave_authorize(
            "STALE_CONTAINER_VERIFIED_ABSENT", "test", 1, evidence=None)
        self.assertFalse(ok)
        self.assertEqual(why, "validated_reason_requires_evidence")
        # and UNKNOWN is not a leave reason at all
        ok2, why2 = lp.vc_leave_authorize("UNKNOWN", "test", 1,
                                          evidence="x")
        self.assertFalse(ok2)
        self.assertTrue(why2.startswith("unknown_reason:"))


class TestHeartbeatPreserved(unittest.TestCase):
    """Matrix 19 — the heartbeat census + drift detector + sweep wiring
    keep their v99.11.1 shape (detection unchanged; v99.11.3 only adds
    the attribution pass AFTER a positive drift)."""

    def test_c1_heartbeat_census_markers(self):
        hd = _read(_HD)
        for marker in (
                "FD_CENSUS total=%d soft=%d sockets=%d",
                "fd_drift_evaluate as _v9911_drift",
                "sweep_for_leaks",
                "MEM_CENSUS"):
            self.assertIn(marker, hd)

    def test_c2_drift_detector_unchanged(self):
        vr = _read(_VR)
        for marker in (
                "VC_FD_DRIFT_SUSPECTED",
                "FLAT/SHRINKING",
                "streak=%d",
                "no destructive action taken"):
            self.assertIn(marker, vr)
        # the v99.11.3 attribution runs ONLY on a positive drift
        hd = _read(_HD)
        self.assertIn("if _v9913_drift_suspected:", hd)

    def test_c3_no_threshold_changes(self):
        """PRESERVE: no FD limits raised/lowered to mask the leak —
        the guard constants and the drift thresholds are byte-stable
        (the drift threshold model + the admission costs)."""
        vr = _read(_VR)
        self.assertIn("DEFAULT_JOIN_FD_COST = 8", vr)
        self.assertIn("DEFAULT_MAX_JOINED", vr)
        self.assertIn("d_fd >= max(1, int(dt / 60.0))", vr)


class TestSqlitePreserved(unittest.TestCase):
    """Matrix 20 — the SQLite/WAL suite remains collected and green."""

    def test_d1_sqlite_wal_suite_runs(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pytest",
             os.path.join(_ROOT, "tests", "test_v99_11_sqlite_wal.py"),
             "-q", "--timeout=120"],
            capture_output=True, text=True, timeout=240.0)
        self.assertEqual(proc.returncode, 0,
                         f"sqlite WAL suite failed:\n{proc.stdout[-1500:]}")
        self.assertIn("passed", proc.stdout)


class TestFix3Measurement(unittest.TestCase):
    """FIX 3 — the documented no-change decision (the evidence does
    not demonstrate contribution to the FD or invalid-entity
    problems)."""

    def test_e1_snapshot_unexpected_state_preserves(self):
        """The v99.11.1 snap_reason total-function state machine is
        intact: UNKNOWN/RECOVERY_PENDING preserve branches + the
        UNEXPECTED_STATE preserve branch (no automatic leaves)."""
        src = _read(_VC)
        for marker in (
                "VC_SNAPSHOT_STALE_UNEXPECTED_STATE",
                "PRESERVING (no ",
                "recovery, no leave, no ALREADY_JOINED)",
                "leaving the target eligible for re-join"):
            self.assertIn(marker, src)

    def test_e2_churn_evidence_documented(self):
        """The measurement contract: the 2026-09-25/26 logs show ≤2
        events per chat (36 total over 10.5h) — asserted as the
        documented no-change rationale in the source's evidence
        comments."""
        src = _read(_VC)
        self.assertIn("36 events total", src)


if __name__ == "__main__":
    unittest.main()
