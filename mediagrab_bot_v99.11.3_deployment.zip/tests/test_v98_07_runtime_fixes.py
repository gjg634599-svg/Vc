"""v98.07 runtime fixes — regression tests for the per-account resolution
poisoning + join-distribution skew + hard-freeze canary + auto-discovery
lifecycle + session hot-reload + observability upgrade.

CRITICAL RUNTIME EVIDENCE (bot-diagnostic.log.1, 2026-08-31
06:24:45→07:44:53, pid=7670, deployed v98.06 zip SHA256
f8e483f1799f5bb2713a9a1fb464b5038e6018e5fef1abe208ed7dcfefd56b14 —
all 5 module hashes banner-verified against the canonical zip):
  F1 HARD FREEZE: last heartbeat 07:44:07 (60s cadence healthy all run),
    last log line 07:44:53 mid-reconcile (VC_RECONCILE_CLIENT
    chat_id=1941982944); no graceful stop; 13 EVENT_LOOP_LAG all MODERATE
    (last 07:20:05, none before the silence); 46 watchdog disconnects
    (~1/min); the rotated tail segment (07:44:53→07:47:18) was NOT part
    of the upload — the mandate-cited 07:47:05/07:47:18 terminal lines
    are unverifiable from the provided files (log.1 ends 07:44:53 at the
    exact cited code region). Freeze mechanics = SOURCE-PROVEN-HYPOTHESIS;
    the FIX-SS canary is warranted either way.
  F2 PER-ACCOUNT RESOLUTION POISONING: 237x "Invalid channel object"
    VC_JOIN_ALL_DISCOVERY skip + 179x VC_PARTICIPATION_REDETECT_FAILED
    (all account_id=acc_919006065076); SNAPSHOT collapse 46→2→1→11 with
    already_joined=0 EVERY run (a lie — 40 chats joined fine in run 1).
    Source: vc_verify_target :7044-7055 consumed the REGISTRY
    access_hash (_global discovery scope) on the ACCOUNT client; the
    bare-int branch = the v98.06 FIX-LL bug class one call-site over;
    classification consumed rotation-account-cached entities via the
    global client.
  F3 JOIN DISTRIBUTION SKEW: 40/40 VC_ACTIVE_JOIN_BACKEND_SET
    account=acc_919006065076, acc_918335829278 ZERO join attempts (only
    HEALTH_OK + discovery fallback); 06:42:40 one FloodWait 74s on the
    loaded account → JOIN_ALL_BREAKER CLOSED→OPEN threshold=1 systemic —
    ONE account's flood parked the WHOLE run.
  F4 AUTO-DISCOVERY NEVER PAST cycle=1: CYCLE_STARTED only ever cycle=1
    (07:43:03, 07:44:48); the Join-All start CANCELLED the loop at
    07:43:12 (VC_JOIN_ALL_AUTO_DISCOVERY_STOPPED — 9s into cycle 1); the
    watchdog then skipped restart 32x while Join-All ran;
    DISCOVERY_V2_SEARCH_START variants=1 expand=False (engine supports
    expand=True at :15401/:15669); VC_DISCOVERY_DEFERRED queue=1 logged,
    never drained.
  F5 OBSERVABILITY HOLES: VC_JOIN_ALL_SNAPSHOT printed "(v97.78 detailed
    breakdown)" then NOTHING; VC_JOIN_SUCCESS 40 lines, 0 containing
    acc_; session import runs once at boot (found=2) — hot-reload absent.

v98.07 FIXES UNDER TEST:
  FIX-QQ: per-account resolution unification — scope-annotated entity
          cache + scope-gated cache hits (VC_HASH_SCOPE_MISMATCH),
          marked-form resolve_vc_entity everywhere in verify/redetect/
          classification/worker/detect paths (bare-int get_entity
          eliminated by grep+AST audit), detection on the scope-owning
          client, ChannelInvalid → evict + re-resolve ONCE without the
          foreign hash + retry detection ONCE (VC_VERIFY_RERESOLVE) —
          NEVER a permanent exclusion, NEVER a mark.
  FIX-RR: join distribution across ALL healthy accounts — least-loaded
          rank (ready_at, joins_made), cached rotation pin honored only
          while eligible, 2-5s post-join stagger, FloodWait parks ONE
          account (VC_ACCOUNT_PARKED_FLOODWAIT) with the global breaker
          tripping ONLY when every healthy account is parked; the global
          FloodWait gate is account-scoped (VC_JOIN_GLOBAL_FLOODWAIT_
          SCOPED); VC_JOIN_SUCCESS carries account=; VC_JOIN_DISTRIBUTION
          per-run summary.
  FIX-SS: anti-freeze package — thread-based heartbeat canary (daemon
          thread watching a 5s liveness stamp; >180s →
          faulthandler.dump_traceback side-file +
          VC_HEARTBEAT_CANARY_TRIGGERED + os._exit(86), config-gated
          default ON); bounded RW read-lock acquire (20s) +
          generation re-check re-dispatch (VC_CLIENT_GENERATION_MISMATCH)
          in mtproto_call_with_retry; sync-hazard sweep (1 hit: bun
          installer urlopen — install-time only, 120s→30s).
  FIX-TT: auto-discovery lifecycle — module-level global cycle counter
          (monotonic across task restarts), Join-All PAUSES the loop
          instead of cancelling (VC_AUTODISCOVERY_PAUSED_FOR_JOIN_ALL /
          VC_AUTODISCOVERY_RESUMED), deferred-queue drain after each
          cycle (VC_DEFERRED_DRAIN), expand=True config-gated default ON,
          per-cycle wall-time cap default 90s.
  FIX-UU: session hot-reload (60s filesystem-only rescan of the 4 roots;
          NEW .session path → the real import machinery, bounded 180s;
          SESSION_HOT_IMPORT added/duplicate/failed report) + ACCOUNTS_
          REPORT per-account visibility wired into the cluster:list panel.
  FIX-VV: the REAL "(v97.78 detailed breakdown)" — per-reason exclusion
          counts (VC_JOIN_ALL_SNAPSHOT_BREAKDOWN) + per-account join
          counters inside BOT_HEARTBEAT.

TEST LEVELS (honest):
  * SOURCE-PROVEN: source string/AST assertions on the exact fix shapes.
  * TEST-PROVEN: behavioral tests that AST-extract the ACTUAL shipped
    functions (ast.get_source_segment) and exec them with only I/O
    boundaries mocked (resolve/detect/cluster/config/paths/logger). These
    test the REAL code, not a re-implementation.
"""

import ast
import asyncio
import os
import sys
import time
import types
import unittest

_PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_PKG_ROOT, "mediagrab_bot", "voicechat.py")
_HANDLERS = os.path.join(_PKG_ROOT, "mediagrab_bot", "handlers.py")
_MTPROTO = os.path.join(_PKG_ROOT, "mediagrab_bot", "mtproto.py")
_BOOTSTRAP = os.path.join(_PKG_ROOT, "mediagrab_bot", "bootstrap.py")
_CONFIG = os.path.join(_PKG_ROOT, "mediagrab_bot", "config.py")
_INIT = os.path.join(_PKG_ROOT, "mediagrab_bot", "__init__.py")
_PIPELINE = os.path.join(_PKG_ROOT, "mediagrab_bot", "vc_pipeline.py")


def _read(path: str) -> str:
    with open(path, encoding="utf-8") as fh:
        return fh.read()


class _FakeLogger:
    """Captures formatted log records for assertions."""

    def __init__(self) -> None:
        self.records: list[tuple[str, str]] = []

    def _log(self, level: str, msg: str, *args) -> None:
        try:
            self.records.append((level, msg % args if args else msg))
        except Exception:  # noqa: BLE001
            self.records.append((level, msg))

    def info(self, msg, *args):  # noqa: ANN001
        self._log("INFO", msg, *args)

    def warning(self, msg, *args):  # noqa: ANN001
        self._log("WARNING", msg, *args)

    def debug(self, msg, *args):  # noqa: ANN001
        self._log("DEBUG", msg, *args)

    def error(self, msg, *args):  # noqa: ANN001
        self._log("ERROR", msg, *args)

    def text(self) -> str:
        return "\n".join(m for _, m in self.records)


def _extract_toplevel(src: str, name: str) -> str | None:
    """AST-extract the verbatim source of a top-level (async) function."""
    tree = ast.parse(src)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name == name:
                return ast.get_source_segment(src, node)
    return None


# =============================================================================
# §1 — FIX-QQ: per-account resolution unification
# =============================================================================

class TestFixQQVerifyRedetect(unittest.TestCase):
    """T-A: vc_verify_target redetect uses the scoped helper; the bare-int
    and registry-hash-InputPeer branches are GONE (AST call-graph)."""

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def _vc_verify_target_segment(self) -> str:
        seg = _extract_toplevel(self.src, "vc_verify_target")
        self.assertIsNotNone(seg, "vc_verify_target must exist")
        return seg

    def test_redetect_calls_scoped_helper(self):
        seg = self._vc_verify_target_segment()
        self.assertIn("_vc_detect_active_call_scoped", seg)
        self.assertIn('purpose="vc_verify_target"', seg)
        # The registry access_hash is passed through the helper (which
        # routes it via resolve_vc_entity's scope-gated machinery).
        self.assertIn('getattr(rec, "access_hash", 0)', seg)
        # Bounded overall.
        self.assertIn("timeout=45.0", seg)

    def test_old_registry_hash_inputpeer_branch_gone(self):
        seg = self._vc_verify_target_segment()
        # The EXACT v98.06 smoking gun (voicechat.py:7044-7055):
        #   entity = await mtproto_call_with_retry(
        #       client.get_entity, InputPeerChannel(int(chat_id), int(rec.access_hash)), ...)
        self.assertNotIn("client.get_entity,", seg)
        self.assertNotIn("InputPeerChannel(int(chat_id), int(rec.access_hash))", seg)

    def test_no_bare_int_get_entity_in_verify_target_ast(self):
        """AST call-graph: no Call to <anything>.get_entity with a bare
        int(<var>) argument anywhere inside vc_verify_target."""
        seg = self._vc_verify_target_segment()
        tree = ast.parse("async def _wrap():\n" + _indent(seg))
        found_bad: list[int] = []
        for node in ast.walk(tree):
            if (isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Attribute)
                    and node.func.attr == "get_entity"):
                for a in node.args:
                    if (isinstance(a, ast.Call)
                            and isinstance(a.func, ast.Name)
                            and a.func.id == "int"):
                        found_bad.append(node.lineno)
        self.assertEqual(found_bad, [], "bare-int get_entity reachable from vc_verify_target")

    def test_fix_e_semantics_preserved(self):
        """v98.00 FIX-E guardrail: redetect failure stays UNKNOWN — never
        absent, never destructive (the new code keeps Case B)."""
        seg = self._vc_verify_target_segment()
        self.assertIn("_redetect_error", seg)
        self.assertIn("VC_PARTICIPATION_REDETECT_FAILED", seg)
        full = self.src
        self.assertIn("reason=redetect_failed", full)


def _indent(seg: str) -> str:
    out = []
    for line in seg.split("\n"):
        out.append("    " + line if line.strip() else line)
    return "\n".join(out)


class TestFixQQScopedDetectBehavior(unittest.TestCase):
    """T-B/T-C behavioral: exec the REAL _vc_detect_active_call_scoped and
    _vc_is_channel_invalid_exc / _vc_evict_poisoned_entity_cache helpers
    with resolve/detect/cluster boundaries faked."""

    def _exec_detect(self):
        src = _read(_VOICECHAT)
        seg = _extract_toplevel(src, "_vc_detect_active_call_scoped")
        self.assertIsNotNone(seg)
        seg_i = _extract_toplevel(src, "_vc_is_channel_invalid_exc")
        seg_e = _extract_toplevel(src, "_vc_evict_poisoned_entity_cache")
        seg_b = _extract_toplevel(src, "_vc_both_id_forms")
        seg_s = _extract_toplevel(src, "_vc_scope_of_client")
        self.assertIsNotNone(seg_i)
        self.assertIsNotNone(seg_e)
        self.assertIsNotNone(seg_b)
        self.assertIsNotNone(seg_s)
        logger = _FakeLogger()
        ns: dict = {
            "asyncio": asyncio,
            "time": time,
            "logger": logger,
            "Any": object,
            "_vc_entity_cache": {},
            # boundary fakes (recorded):
            "_resolve_calls": [],
            "_detect_calls": [],
            "_client": types.SimpleNamespace(tag="account_b"),
            "_global_cluster": None,
        }

        async def _fake_resolve(client, marked, chat_id=0, access_hash=0):
            ns["_resolve_calls"].append(
                {"client": client, "marked": marked, "ah": access_hash})
            if len(ns["_resolve_calls"]) == 1:
                return {"ok": True, "entity": {"id": 1, "scope": "acc_A"},
                        "source": "cache", "error": ""}
            return {"ok": True, "entity": {"id": 2, "scope": "fresh"},
                    "source": "resolve_entity_full", "error": ""}

        async def _fake_detect(client, entity):
            ns["_detect_calls"].append({"client": client, "entity": entity})
            if len(ns["_detect_calls"]) == 1:
                # Cross-scope rejection (the F2 signature):
                raise RuntimeError("Telegram RPC error: Invalid channel object. "
                                   "Make sure to pass the right types")
            return {"call_id": -42, "access_hash": 99, "members": None}

        ns["resolve_vc_entity"] = _fake_resolve
        ns["vc_detect_active_call"] = _fake_detect
        ns["get_userbot_cluster"] = lambda: types.SimpleNamespace(
            get_client=lambda aid: ns["_client"])
        # _vc_scope_of_client delegates to _vc_client_scope (mtproto import
        # in the real module); for exec purposes the fallback (unknown) is
        # fine — the evict helper uses the CONSUMER scope string directly.
        scope_calls: list = []

        def _fake_client_scope(client):
            scope_calls.append(client)
            return "acc_B"

        ns["_vc_client_scope"] = _fake_client_scope
        exec(compile(seg_b + "\n\n" + seg_i + "\n\n" + seg_e + "\n\n" + seg_s
                     + "\n\n" + seg, "<v98.07_scoped>", "exec"), ns)
        return ns, logger

    def test_channel_invalid_reresolve_once_and_retry(self):
        """T-B: ChannelInvalid → evict poisoned cache + re-resolve WITHOUT
        the foreign hash + retry detection once → SUCCESS."""
        ns, logger = self._exec_detect()
        _marked_key = -1000000000000 - 1234
        # Poison the global cache for both id forms under scope acc_A.
        ns["_vc_entity_cache"][1234] = {"entity": {"id": 1},
                                         "scope": "acc_A", "source": "cache"}
        ns["_vc_entity_cache"][_marked_key] = {"entity": {"id": 1},
                                               "scope": "acc_A", "source": "cache"}
        out = asyncio.run(ns["_vc_detect_active_call_scoped"](
            ns["_client"], 1234, 555, purpose="test"))
        self.assertTrue(out["ok"])
        self.assertIsNotNone(out["info"])
        self.assertEqual(out["info"]["call_id"], -42)
        self.assertTrue(out["reresolved"])
        # TWO resolves; the second WITHOUT the foreign hash:
        self.assertEqual(len(ns["_resolve_calls"]), 2)
        self.assertEqual(ns["_resolve_calls"][0]["ah"], 555)
        self.assertEqual(ns["_resolve_calls"][1]["ah"], 0)
        # The poisoned entries were EVICTED (both id forms):
        self.assertNotIn(1234, ns["_vc_entity_cache"])
        self.assertNotIn(_marked_key, ns["_vc_entity_cache"])
        # VC_VERIFY_RERESOLVE logged with eviction count:
        self.assertIn("VC_VERIFY_RERESOLVE", logger.text())
        self.assertIn("evicted=2", logger.text())

    def test_second_failure_returns_unknown_never_marks(self):
        """T-B: if the scoped retry ALSO fails → ok=False with error text;
        the helper NEVER calls vc_mark_peeruser (grep the real source) and
        NEVER deletes/permamently excludes."""
        ns, logger = self._exec_detect()

        async def _always_bad(client, entity):
            raise RuntimeError("Invalid channel object. Make sure to pass types")
        ns["vc_detect_active_call"] = _always_bad
        out = asyncio.run(ns["_vc_detect_active_call_scoped"](
            ns["_client"], 1234, 0, purpose="test"))
        self.assertFalse(out["ok"])
        self.assertIn("Invalid channel object", out["error"])
        # FIX-NN-style full-fidelity failure log fired on the retry path:
        self.assertIn("VC_CLASSIFY_FAILURE", logger.text())
        # The helper source contains no blacklist escalation:
        src = _read(_VOICECHAT)
        seg = _extract_toplevel(src, "_vc_detect_active_call_scoped")
        self.assertNotIn("vc_mark_peeruser", seg)
        self.assertNotIn("vc_delete_group", seg)

    def test_non_channel_invalid_no_reresolve(self):
        """A genuine transport error (private channel) does NOT fire the
        scope-poisoning retry — exactly one resolve, one detect."""
        ns, logger = self._exec_detect()
        detect_calls: list = []

        async def _private_err(client, entity):
            detect_calls.append(1)
            raise RuntimeError("Channel is private — userbot is not a member.")
        ns["vc_detect_active_call"] = _private_err
        out = asyncio.run(ns["_vc_detect_active_call_scoped"](
            ns["_client"], 1234, 0, purpose="test"))
        self.assertFalse(out["ok"])
        self.assertIn("private", out["error"].lower())
        self.assertFalse(out["reresolved"])
        self.assertEqual(len(ns["_resolve_calls"]), 1)
        self.assertEqual(len(detect_calls), 1)

    def test_no_active_call_is_valid_case_c(self):
        """info=None with ok=True — the 'no active call' answer (Case C)
        flows through the scoped helper unchanged."""
        ns, logger = self._exec_detect()

        async def _none(client, entity):
            return None
        ns["vc_detect_active_call"] = _none
        out = asyncio.run(ns["_vc_detect_active_call_scoped"](
            ns["_client"], 1234, 0, purpose="test"))
        self.assertTrue(out["ok"])
        self.assertIsNone(out["info"])


class TestFixQQScopeGate(unittest.TestCase):
    """T-C: hash-scope mismatch detected → fresh resolution (scope field)."""

    def setUp(self):
        self.mt = _read(_MTPROTO)

    def _exec_scope_fns(self):
        src = self.mt
        seg_c = _extract_toplevel(src, "_vc_client_scope")
        seg_k = _extract_toplevel(src, "_vc_cache_scope_ok")
        self.assertIsNotNone(seg_c)
        self.assertIsNotNone(seg_k)
        ns: dict = {
            "Any": object,
            "_mtproto_client": types.SimpleNamespace(tag="global"),
            "_userbot_cluster": types.SimpleNamespace(_accounts={
                "__primary__": "x",
                "acc_A": {"client": types.SimpleNamespace(tag="A")},
                "acc_B": {"client": types.SimpleNamespace(tag="B")},
            }),
            # v99.06 FIX-1 test maintenance: _vc_client_scope now binds the
            # primary client to its REAL account id via the new
            # get_primary_account_id() helper before falling back to
            # "global".  This exec-harness stub returns None (the
            # "primary unidentifiable" shape), so the original v98.07
            # assertions hold byte-identical (global fallback + acc_X
            # cluster binding).  No assertion below changed.
            "get_primary_account_id": lambda: None,
        }
        exec(compile(seg_c + "\n\n" + seg_k, "<v98.07_scope>", "exec"), ns)
        return ns

    def test_scope_resolution(self):
        ns = self._exec_scope_fns()
        cA = ns["_userbot_cluster"]._accounts["acc_A"]["client"]
        cB = ns["_userbot_cluster"]._accounts["acc_B"]["client"]
        self.assertEqual(ns["_vc_client_scope"](ns["_mtproto_client"]), "global")
        self.assertEqual(ns["_vc_client_scope"](cA), "acc_A")
        self.assertEqual(ns["_vc_client_scope"](cB), "acc_B")
        self.assertEqual(ns["_vc_client_scope"](None), "(unknown)")
        self.assertTrue(ns["_vc_client_scope"](object()).startswith("client:"))

    def test_cache_scope_ok_gate(self):
        """A hash cached under scope X must NEVER be used to build an
        InputPeer for client Y; legacy (scope-less) entries still hit."""
        ns = self._exec_scope_fns()
        cA = ns["_userbot_cluster"]._accounts["acc_A"]["client"]
        cB = ns["_userbot_cluster"]._accounts["acc_B"]["client"]
        # Matching scope → consumable.
        self.assertTrue(ns["_vc_cache_scope_ok"]({"scope": "acc_A"}, cA))
        self.assertTrue(ns["_vc_cache_scope_ok"]({"scope": "global"},
                                                 ns["_mtproto_client"]))
        # MISMATCH → NOT consumable (the F2 poisoning gate).
        self.assertFalse(ns["_vc_cache_scope_ok"]({"scope": "acc_A"}, cB))
        self.assertFalse(ns["_vc_cache_scope_ok"]({"scope": "global"}, cA))
        # Legacy entries (pre-v98.07, no scope) → consumable (fast path).
        self.assertTrue(ns["_vc_cache_scope_ok"]({"entity": 1}, cB))
        self.assertTrue(ns["_vc_cache_scope_ok"]({}, cA))
        self.assertTrue(ns["_vc_cache_scope_ok"](None, cA))

    def test_resolve_step1_scope_gate_source(self):
        """resolve_vc_entity Step 1 checks the scope BEFORE returning a
        cache hit; cache writes are scope-annotated."""
        ridx = self.mt.find("async def resolve_vc_entity(")
        self.assertGreater(ridx, -1)
        # v98.10 test maintenance: window 10000 → 20000 — the v98.10
        # single-flight join (§41, shield-free mirror future) + Step-0
        # scoped routing (§15) + accounting blocks sit between the
        # function start and the Step-2 scope-annotated cache write; the
        # ASSERTIONS (the FIX-QQ contract) are unchanged.
        rwin = self.mt[ridx: ridx + 20000]
        self.assertIn("_vc_cache_scope_ok(cached, client)", rwin)
        self.assertIn("VC_HASH_SCOPE_MISMATCH", rwin)
        self.assertIn('"scope": _vc_client_scope(client)', rwin)
        self.assertIn('result["scope"]', rwin)

    def test_discovery_cache_write_scope_annotated(self):
        vsrc = self._vsrc()
        vidx = vsrc.find("def vc_detect_active_call(")
        win = vsrc[vidx: vidx + 4600]
        self.assertIn('"source": "vc_discovery"', win)
        self.assertIn('"scope": _vc_scope_of_client(client)', win)

    def _vsrc(self):
        return _read(_VOICECHAT)


class TestFixQQBareIntAudit(unittest.TestCase):
    """T-A extension: the mandated grep audit — every client.get_entity
    call site in voicechat.py takes an InputPeer/explicit Peer/string;
    the bare-int detection sites are eliminated (AST scan)."""

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_no_bare_int_get_entity_call_sites(self):
        tree = ast.parse(self.src)
        bad: list[int] = []
        for node in ast.walk(tree):
            if (isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Attribute)
                    and node.func.attr == "get_entity"):
                for a in node.args:
                    # bare int literal
                    if isinstance(a, ast.Constant) and isinstance(a.value, int):
                        bad.append(node.lineno)
                    # int(<var>) — the PeerUser side-effect form
                    if (isinstance(a, ast.Call) and isinstance(a.func, ast.Name)
                            and a.func.id == "int" and len(a.args) == 1
                            and isinstance(a.args[0], (ast.Name,))):
                        bad.append(node.lineno)
        self.assertEqual(
            bad, [],
            f"bare-int get_entity sites remain at lines {bad}")

    def test_detection_paths_use_scoped_helper(self):
        """Every detection path that previously used bare client.get_entity
        now routes through _vc_get_entity_for_detect (the sanctioned
        marked-form resolver)."""
        seg = _extract_toplevel(self.src, "_vc_get_entity_for_detect")
        self.assertIsNotNone(seg)
        self.assertIn("resolve_vc_entity", seg)
        self.assertIn("_vc_both_id_forms", seg)
        # The replaced sites (purpose-tagged):
        for purpose in ("watcher", "build_active_queue", "tour_recheck",
                        "manual_join", "join_multi", "two_target_probe",
                        "distributed_recheck", "revalidate_stale"):
            self.assertIn(f'purpose="{purpose}"', self.src,
                          f"detection path {purpose} must use the scoped helper")

    def test_classification_detect_uses_scope_owner_client(self):
        """The Join-All classification loop derives the detect client from
        the resolution source (account_rotation) + ChannelInvalid retry."""
        idx = self.src.find("_v807_dc = client")
        self.assertGreater(idx, -1, "classification detect-client derivation")
        win = self.src[max(0, idx - 1500): idx + 3500]
        self.assertIn('if "account_rotation:" in _v807_src', win)
        self.assertIn("vc_detect_active_call(_v807_dc, entity)", win)
        self.assertIn("_vc_is_channel_invalid_exc(_v807_dexc)", win)
        self.assertIn('purpose="join_all_classify"', win)

    def test_worker_recheck_channel_invalid_retry(self):
        idx = self.src.find('purpose="join_all_recheck"')
        self.assertGreater(idx, -1)
        win = self.src[max(0, idx - 2000): idx + 900]
        self.assertIn("_vc_is_channel_invalid_exc(_v807_rexc)", win)
        self.assertIn("vc_detect_active_call(re_client, re_entity)", win)


# =============================================================================
# §2 — FIX-RR: join distribution across ALL healthy accounts
# =============================================================================

class TestFixRRDistributionBehavior(unittest.TestCase):
    """T-D behavioral: least-loaded distribution over 2 accounts — the
    40/0 skew is structurally impossible."""

    def _exec_rr(self):
        src = _read(_VOICECHAT)
        segs = []
        for name in ("_vc_join_account_stats", "_vc_join_account_eligible",
                     "_vc_join_account_rank", "_vc_join_account_record_join",
                     "_vc_join_account_record_failure",
                     "_vc_join_account_park_floodwait",
                     "_vc_join_account_all_parked",
                     "_vc_join_distribution_summary", "_vc_join_account_pick"):
            seg = _extract_toplevel(src, name)
            self.assertIsNotNone(seg, f"{name} must exist")
            segs.append(seg)
        logger = _FakeLogger()
        clients = {"acc_A": types.SimpleNamespace(tag="A"),
                   "acc_B": types.SimpleNamespace(tag="B")}
        ns: dict = {
            "time": time,
            "logger": logger,
            "Any": object,
            "get_userbot_cluster": lambda: types.SimpleNamespace(
                get_client=lambda aid: clients.get(aid)),
            "_vc_account_join_stats": {},
        }
        exec(compile("\n\n".join(segs), "<v98.07_rr>", "exec"), ns)
        return ns, logger

    def test_least_loaded_spreads_over_two_accounts(self):
        """Simulate 40 sequential joins with the REAL pick + record
        machinery: with 2 healthy accounts the counts must BALANCE
        (the v98.06 run produced 40/0)."""
        ns, _ = self._exec_rr()
        healthy = [{"account_id": "acc_A"}, {"account_id": "acc_B"}]
        counts = {"acc_A": 0, "acc_B": 0}
        for _ in range(40):
            aid, _client = ns["_vc_join_account_pick"](healthy)
            self.assertIn(aid, counts, "pick must return a real account")
            counts[aid] += 1
            ns["_vc_join_account_record_join"](aid)
        self.assertGreaterEqual(min(counts.values()), 15,
                                f"distribution must balance, got {counts}")
        self.assertLessEqual(max(counts.values()) - min(counts.values()), 6,
                             f"distribution too skewed: {counts}")

    def test_record_join_sets_stagger_cooldown(self):
        ns, _ = self._exec_rr()
        ns["_vc_join_account_record_join"]("acc_A")
        rec = ns["_vc_account_join_stats"]["acc_A"]
        self.assertEqual(rec["joins_made"], 1)
        self.assertGreaterEqual(rec["cooldown_until"], time.monotonic() + 1.5)
        self.assertLessEqual(rec["cooldown_until"], time.monotonic() + 6.0)
        ok, why = ns["_vc_join_account_eligible"]("acc_A")
        self.assertFalse(ok)
        self.assertEqual(why, "stagger_cooldown")
        ok_b, why_b = ns["_vc_join_account_eligible"]("acc_B")
        self.assertTrue(ok_b)

    def test_floodwait_parks_one_account_only(self):
        """T-E behavioral: FloodWait parks ONE account; the other stays
        eligible; all_parked is False until EVERY account parks."""
        ns, logger = self._exec_rr()
        ns["_vc_join_account_park_floodwait"]("acc_A", 74.0, source="test")
        ok_a, why_a = ns["_vc_join_account_eligible"]("acc_A")
        self.assertFalse(ok_a)
        self.assertEqual(why_a, "floodwait_parked")
        ok_b, _ = ns["_vc_join_account_eligible"]("acc_B")
        self.assertTrue(ok_b, "healthy account must continue (the 06:42:40 "
                              "breaker run-killer)")
        self.assertFalse(ns["_vc_join_account_all_parked"](["acc_A", "acc_B"]))
        self.assertIn("VC_ACCOUNT_PARKED_FLOODWAIT", logger.text())
        self.assertIn("account=acc_A", logger.text())
        self.assertIn("seconds=74.0", logger.text())
        # Park the second → now ALL parked (global systemic trip allowed).
        ns["_vc_join_account_park_floodwait"]("acc_B", 74.0, source="test")
        self.assertTrue(ns["_vc_join_account_all_parked"](["acc_A", "acc_B"]))
        # The soft stagger cooldown does NOT count as parked:
        ns["_vc_join_account_stats"]("acc_A")["floodwait_until"] = 0.0
        ns["_vc_join_account_stats"]("acc_A")["cooldown_until"] = \
            time.monotonic() + 3.0
        self.assertFalse(ns["_vc_join_account_all_parked"](["acc_A", "acc_B"]))

    def test_distribution_summary_shape(self):
        ns, _ = self._exec_rr()
        ns["_vc_join_account_record_join"]("acc_A")
        ns["_vc_join_account_record_join"]("acc_A")
        ns["_vc_join_account_record_failure"]("acc_B")
        ns["_vc_join_account_park_floodwait"]("acc_B", 30.0)
        s = ns["_vc_join_distribution_summary"]("test")
        self.assertIn("source=test", s)
        self.assertIn("acc_A:confirmed=2:failed=0", s)
        self.assertIn("acc_B:confirmed=0:failed=1", s)
        self.assertIn("fw=30s", s)


class TestFixRRSourceContracts(unittest.TestCase):
    """FIX-RR source shapes: rotation pin eligibility, systemic gating,
    account-scoped global floodwait, telemetry markers."""

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_rotation_pin_only_when_eligible(self):
        # v99: the rotation candidate eligibility check lives in the
        # canonical pipeline's _try_rotate_account (§9); the pin is only
        # applied to eligible accounts (marker + eligibility in window).
        pipe = _read(_PIPELINE)
        idx = pipe.find("VC_JOIN_ROTATION_PIN_SKIPPED")
        self.assertGreater(idx, -1)
        win = pipe[max(0, idx - 1500): idx + 700]
        self.assertIn("_vc_join_account_eligible(aid)", win)

    def test_probe_order_least_loaded(self):
        # v99: the rotation probe order (least-loaded first) lives in the
        # canonical pipeline's _try_rotate_account (§9).
        pipe = _read(_PIPELINE)
        idx = pipe.find("least-loaded pick, v98.07 FIX-RR")
        self.assertGreater(idx, -1)
        win = pipe[max(0, idx - 1500): idx + 600]
        self.assertIn("candidates.sort", win)
        self.assertIn("_vc_join_account_rank(a)", win)

    def test_join_success_carries_account(self):
        """F5: VC_JOIN_SUCCESS MUST carry account= (was 40 lines, 0 with
        acc_)."""
        src = self.src
        idx = src.find("VC_JOIN_SUCCESS chat_id=%s call_id=%s strategy=%s")
        self.assertGreater(idx, -1)
        # v99.05 RC-F6 derivation: the success line gained the
        # attempt_id/verification_method/participant_identity/
        # verification_timestamp/rpc_result evidence args — the
        # _v807_join_aid arg moved further from the format anchor;
        # window 700 -> 1300 (contract unchanged).
        win = src[idx: idx + 1300]
        self.assertIn("account=%s", win)
        self.assertIn("_v807_join_aid", win)
        # v98.13 test maintenance: the accounting call now sits AFTER the
        # success log (Telegram-VERIFIED joins only — an unverified join
        # must not count as J); the CONTRACT (success records per-account
        # join accounting) is unchanged — window spans after the log.
        self.assertIn("_vc_join_account_record_join(_v807_join_aid)",
                      src[idx: idx + 2400])

    def test_breaker_systemic_only_when_all_parked(self):
        idx = self.src.find("VC_JOIN_ALL_ALL_ACCOUNTS_PARKED")
        self.assertGreater(idx, -1)
        win = self.src[max(0, idx - 2600): idx + 1800]
        self.assertIn("_vc_join_account_park_floodwait(", win)
        self.assertIn("_vc_join_account_all_parked(_v807_healthy_aids)", win)
        self.assertIn("is_systemic=bool(_v807_all_parked)", win)
        self.assertIn("account_id=(_v807_fw_aid", win)
        # The v98.06 UNCONDITIONAL systemic trip is gone from this site:
        self.assertNotIn(
            'reason=f"FloodWait {fw_secs}s (systemic)",\n'
            '                                    is_systemic=True,',
            win.replace("                                    ", ""))

    def test_global_floodwait_scoped_when_account_attributed(self):
        idx = self.src.find("VC_JOIN_GLOBAL_FLOODWAIT_SCOPED")
        self.assertGreater(idx, -1)
        win = self.src[max(0, idx - 1600): idx + 700]
        self.assertIn("if _v807_all_parked or not _v807_fw_aid:", win)
        self.assertIn("vc_set_global_floodwait(", win)

    def test_distribution_summary_at_run_complete(self):
        # v98.09-P3 (documented window correction, PATCH-2 precedent): the
        # §23 VC_JOIN_ALL_METRICS block sits between COMPLETE and the
        # distribution summary — window widened 900→3400 (contract intact).
        idx = self.src.find("VC_JOIN_DISTRIBUTION run_id=%s")
        self.assertGreater(idx, -1)
        win = self.src[max(0, idx - 3400): idx + 400]
        self.assertIn("VC_JOIN_ALL_COMPLETE", win)
        self.assertIn("_vc_join_distribution_summary(", win)


# =============================================================================
# §3 — FIX-SS: anti-freeze package
# =============================================================================

class TestFixSSCanaryBehavior(unittest.TestCase):
    """T-F behavioral: exec the REAL canary thread body with a fake clock —
    a stale liveness stamp fires dump + exit(86)."""

    def _exec_canary(self, stale_age: float, exit_enabled: bool = True):
        src = _read(_BOOTSTRAP)
        seg = _extract_toplevel(src, "_vc_heartbeat_canary_thread_body")
        self.assertIsNotNone(seg, "canary thread body must exist")
        seg_p = _extract_toplevel(src, "_vc_canary_dump_path")
        self.assertIsNotNone(seg_p)

        class _StopLoop(Exception):
            pass

        fake_now = [1000.0]
        sleep_calls: list[float] = []
        exit_calls: list[int] = []
        dump_calls: list = []
        stderr_lines: list[str] = []

        class _FakeTime:
            @staticmethod
            def monotonic() -> float:
                return fake_now[0]
            @staticmethod
            def sleep(s: float) -> None:
                sleep_calls.append(s)
                fake_now[0] += float(s)
                if len(sleep_calls) >= 2:
                    raise _StopLoop()

        class _FakeFaulthandler:
            @staticmethod
            def dump_traceback(file=None):
                dump_calls.append(file)
                if file is not None:
                    try:
                        file.write(
                            "Thread 0x7f0000000000 (idle): "
                            '"threading.run" '
                            "<canary-test-frame>\n")
                        file.flush()
                    except Exception:  # noqa: BLE001
                        pass

        class _FakeOs:
            @staticmethod
            def getpid() -> int:
                return 4242
            @staticmethod
            def _exit(code: int) -> None:
                exit_calls.append(code)
                raise _StopLoop()

        class _FakeConfig:
            vc_heartbeat_canary = exit_enabled

        class _FakeSys:
            stderr = types.SimpleNamespace(
                write=lambda s: stderr_lines.append(s) or len(s),
                flush=lambda: None,
            )

        logger = _FakeLogger()
        dump_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            f"_canary_dump_test_{os.getpid()}.txt")
        ns: dict = {
            "time": _FakeTime,
            "faulthandler": _FakeFaulthandler,
            "os": _FakeOs,
            "sys": _FakeSys,
            "config": _FakeConfig,
            "logger": logger,
            "print": lambda *a, **k: stderr_lines.append(" ".join(str(x) for x in a)),
            "open": open,
            "_VC_CANARY_TRIGGERED": False,
            "_VC_CANARY_CHECK_INTERVAL": 10.0,
            "_VC_CANARY_STALE_THRESHOLD": 180.0,
            # ARMED + a stamp that is stale by stale_age seconds:
            "_VC_LOOP_LIVENESS_ARMED": True,
            "_VC_LOOP_LIVENESS_STAMP": fake_now[0] - stale_age,
            "_VC_CANARY_DUMP_PATH_SENTINEL": dump_path,
        }

        def _fake_dump_path() -> str:
            return dump_path
        ns["_vc_canary_dump_path"] = _fake_dump_path
        try:
            exec(compile(seg, "<v98.07_canary>", "exec"), ns)
            ns["_vc_heartbeat_canary_thread_body"]()
        except _StopLoop:
            pass
        return {
            "exit_calls": exit_calls, "dump_calls": dump_calls,
            "stderr": "\n".join(stderr_lines), "logger": logger.text(),
            "triggered": ns["_VC_CANARY_TRIGGERED"],
            "dump_path": dump_path,
        }

    def test_canary_fires_dump_and_exit_86_when_stale(self):
        out = self._exec_canary(stale_age=200.0, exit_enabled=True)
        self.assertTrue(out["triggered"])
        self.assertEqual(out["exit_calls"], [86],
                         "os._exit(86) must fire exactly once")
        self.assertGreaterEqual(len(out["dump_calls"]), 1,
                                 "faulthandler.dump_traceback must fire")
        self.assertIn("VC_HEARTBEAT_CANARY_TRIGGERED", out["stderr"])
        self.assertIn("age=2", out["stderr"])  # 200-210s (fake-clock tick)
        self.assertIn("os._exit(86)", out["stderr"])
        self.assertIn("VC_HEARTBEAT_CANARY_TRIGGERED", out["logger"])
        # The side-file dump was written with the header + stack dump:
        self.assertTrue(os.path.exists(out["dump_path"]))
        with open(out["dump_path"], encoding="utf-8") as fh:
            content = fh.read()
        self.assertIn("VC_HEARTBEAT_CANARY_TRIGGERED", content)
        self.assertIn("Thread 0x", content)
        os.unlink(out["dump_path"])

    def test_canary_silent_when_fresh(self):
        out = self._exec_canary(stale_age=30.0, exit_enabled=True)
        self.assertFalse(out["triggered"])
        self.assertEqual(out["exit_calls"], [])
        self.assertEqual(out["dump_calls"], [])

    def test_canary_exit_disabled_by_config(self):
        out = self._exec_canary(stale_age=500.0, exit_enabled=False)
        self.assertTrue(out["triggered"])
        self.assertEqual(out["exit_calls"], [],
                         "config vc_heartbeat_canary=false disables the exit")
        self.assertIn("exit disabled by config", out["stderr"])
        if os.path.exists(out["dump_path"]):
            os.unlink(out["dump_path"])

    def tearDown(self):
        # belt-and-braces: never leave canary dump residue in tests/.
        import glob
        for f in glob.glob(os.path.join(os.path.dirname(os.path.abspath(
                __file__)), "_canary_dump_test_*.txt")):
            try:
                os.unlink(f)
            except OSError:
                pass

    def test_canary_not_armed_no_false_positive(self):
        """Unarmed (pre-post_init) canary must never fire — long startups
        are not freezes."""
        out = self._exec_canary(stale_age=9_000.0, exit_enabled=True)
        # _exec_canary forces ARMED=True; emulate unarmed by direct exec:
        # (covered by source assertion below)
        self.assertIn("VC_LOOP_LIVENESS_ARMED", _read(_BOOTSTRAP))


class TestFixSSGenerationAndLocks(unittest.TestCase):
    """T-G: bounded RW acquire + generation re-dispatch in
    mtproto_call_with_retry (source) + RW-lock writer preference
    (behavioral — a queued reader can be timed out)."""

    def setUp(self):
        self.mt = _read(_MTPROTO)

    def test_bounded_acquire_and_generation_check_source(self):
        idx = self.mt.find("VC_CLIENT_GENERATION_MISMATCH")
        self.assertGreater(idx, -1, "generation mismatch marker must exist")
        win = self.mt[max(0, idx - 2400): idx + 3200]
        self.assertIn("asyncio.wait_for(rw.acquire_read(), timeout=20.0)", win)
        self.assertIn("_v807_gen_before = _mtproto_generation", win)
        self.assertIn("if _mtproto_generation != _v807_gen_before:", win)
        # The mismatch raises INSIDE the inner try (lock released by the
        # finally — no read-lock leak):
        fin_idx = win.find("raise asyncio.TimeoutError(")
        rel_idx = win.find("await rw.release_read()")
        self.assertGreater(fin_idx, -1)
        self.assertGreater(rel_idx, -1)
        self.assertLess(fin_idx, rel_idx,
                        "generation raise must precede the release finally")

    def test_rw_lock_writer_preference_reader_timeout(self):
        """Behavioral: with a writer waiting/holding, a NEW reader blocks —
        wait_for(reader_acquire, 20s) times out instead of queueing forever
        (the F1 starvation shape)."""
        seg = _extract_toplevel(self.mt, "")  # placeholder; class extraction:
        tree = ast.parse(self.mt)
        cls_seg = None
        for node in tree.body:
            if isinstance(node, ast.ClassDef) and node.name == "_AsyncRWLock":
                cls_seg = ast.get_source_segment(self.mt, node)
        self.assertIsNotNone(cls_seg)
        ns: dict = {"asyncio": asyncio, "Any": object}
        exec(compile(cls_seg, "<rw>", "exec"), ns)
        lock = ns["_AsyncRWLock"]()

        async def _scenario() -> bool:
            # Writer acquires the exclusive lock and HOLDS it.
            await lock.acquire_write()
            try:
                # A reader trying to acquire while the writer holds → must
                # time out under wait_for (bounded), not queue forever.
                try:
                    await asyncio.wait_for(lock.acquire_read(), timeout=0.2)
                    return False  # acquired (unexpected while writer holds)
                except asyncio.TimeoutError:
                    return True
            finally:
                await lock.release_write()

        self.assertTrue(asyncio.run(_scenario()))
        # After the writer releases, readers flow again:
        async def _reader_ok() -> bool:
            await lock.acquire_read()
            await lock.release_read()
            return True
        self.assertTrue(asyncio.run(_reader_ok()))

    def test_canary_wiring_source(self):
        bs = _read(_BOOTSTRAP)
        self.assertIn("VC_HEARTBEAT_CANARY_STARTED", bs)
        self.assertIn("_vc_start_heartbeat_canary()", bs)
        self.assertIn("_vc_loop_liveness_start()", bs)
        self.assertIn('name="vc_heartbeat_canary", daemon=True', bs)
        self.assertIn("await asyncio.sleep(5)", bs)  # 5s stamp cadence
        self.assertIn("os._exit(86)", bs)
        self.assertIn("_VC_CANARY_STALE_THRESHOLD: float = 180.0", bs)
        # watchdog-supervised liveness task (no false positives):
        self.assertIn('("vc_loop_liveness", _watchdog_get_vc_loop_liveness, '
                      "_vc_loop_liveness_start)", bs)

    def test_sync_hazard_sweep_disposition(self):
        """FIX-SS(c): the sweep found ONE sync hazard (bun installer
        urlopen) — now bounded at 30s and documented as non-VC-path."""
        hd = _read(_HANDLERS)
        self.assertIn("_ur.urlopen(_req, timeout=30)", hd)
        self.assertNotIn("_ur.urlopen(_req, timeout=120)", hd)
        self.assertIn("NOT reachable from any VC path", hd)


# =============================================================================
# §4 — FIX-TT: auto-discovery lifecycle
# =============================================================================

class TestFixTTLifecycleBehavior(unittest.TestCase):
    """T-H behavioral: pause (not cancel) + resume; deferred drain."""

    def _exec_pause_resume(self):
        src = _read(_VOICECHAT)
        seg_p = _extract_toplevel(src, "_vc_autodiscovery_pause_for_join_all")
        seg_r = _extract_toplevel(src, "_vc_autodiscovery_resume_after_join_all")
        self.assertIsNotNone(seg_p)
        self.assertIsNotNone(seg_r)
        logger = _FakeLogger()
        task = types.SimpleNamespace(done=lambda: False)
        ns: dict = {
            "logger": logger,
            "_auto_discovery_state": {"active": True},
            "_auto_discovery_task": task,
            # Mirrors the module default: the pause Event is SET (running).
            "_auto_discovery_pause": asyncio.Event(),
            "_auto_discovery_paused_by_join_all": False,
            "_AUTO_DISCOVERY_GLOBAL_CYCLE": 7,
        }
        ns["_auto_discovery_pause"].set()
        exec(compile(seg_p + "\n\n" + seg_r, "<v98.07_tt>", "exec"), ns)
        return ns, logger, task

    def test_pause_keeps_task_alive_and_resumes(self):
        ns, logger, task = self._exec_pause_resume()
        self.assertTrue(ns["_auto_discovery_pause"].is_set())
        result = ns["_vc_autodiscovery_pause_for_join_all"]()
        self.assertEqual(result, "paused")
        self.assertFalse(ns["_auto_discovery_pause"].is_set(),
                         "pause event must be CLEARED (loop parks)")
        self.assertTrue(ns["_auto_discovery_paused_by_join_all"])
        self.assertEqual(ns["_auto_discovery_state"]["status"],
                         "waiting_join_all")
        self.assertIn("VC_AUTODISCOVERY_PAUSED_FOR_JOIN_ALL", logger.text())
        # The task object is UNTOUCHED (never cancelled — F4's killer):
        self.assertIs(ns["_auto_discovery_task"], task)
        # Resume:
        ns["_vc_autodiscovery_resume_after_join_all"]()
        self.assertTrue(ns["_auto_discovery_pause"].is_set())
        self.assertFalse(ns["_auto_discovery_paused_by_join_all"])
        self.assertIn("VC_AUTODISCOVERY_RESUMED", logger.text())
        self.assertIn("cycle=7", logger.text())

    def test_pause_noop_when_not_running(self):
        ns, _, _ = self._exec_pause_resume()
        ns["_auto_discovery_state"]["active"] = False
        self.assertEqual(ns["_vc_autodiscovery_pause_for_join_all"](),
                         "not_running")

    def test_join_all_start_pauses_instead_of_stops(self):
        src = _read(_VOICECHAT)
        idx = src.find("VC_JOIN_ALL_AUTO_DISCOVERY_PAUSED result=%s")
        self.assertGreater(idx, -1,
                           "Join-All start must log the PAUSE (not stop)")
        win = src[max(0, idx - 1500): idx + 900]
        self.assertIn("_vc_autodiscovery_pause_for_join_all()", win)
        self.assertNotIn("await auto_discovery_stop()", win)
        # Worker terminal resumes + drains:
        fidx = src.find("_vc_autodiscovery_resume_after_join_all()")
        self.assertGreater(fidx, -1)
        fwin = src[max(0, fidx - 1200): fidx + 800]
        self.assertIn("_vc_join_all_unblock_leaves()", fwin)
        self.assertIn("_vc_deferred_drain_bounded()", fwin)

    def test_repress_guard_preserved(self):
        """A re-press of vc:dauto:start must NOT cancel a running healthy
        loop — the ALREADY_RUNNING guard (pre-v98.07, preserved)."""
        src = _read(_VOICECHAT)
        idx = src.find("AUTO_DISCOVERY_ALREADY_RUNNING task_id=%s")
        self.assertGreater(idx, -1)
        win = src[max(0, idx - 700): idx + 300]
        self.assertIn('return "already_running"', win)


class TestFixTTDeferredDrainBehavior(unittest.TestCase):
    """T-H behavioral: exec the REAL _vc_deferred_drain_bounded — deferred
    entries are retried when capacity frees (F4d: logged-and-forgotten
    before v98.07)."""

    def test_drain_retries_deferred_items(self):
        src = _read(_VOICECHAT)
        seg = _extract_toplevel(src, "_vc_deferred_drain_bounded")
        self.assertIsNotNone(seg)
        logger = _FakeLogger()
        join_calls: list[dict] = []

        class _Rec:
            def __init__(self, state):
                self.state = state

        async def _fake_capacity_join(gid, *, title, call_id, access_hash,
                                      source="discovery"):
            join_calls.append({"gid": gid, "title": title,
                               "source": source})
            return "joined"

        ns: dict = {
            "asyncio": asyncio,
            "time": time,
            "logger": logger,
            "Any": object,
            "_vc_deferred_queue": [
                {"group_id": 111, "title": "A", "call_id": 1, "access_hash": 2},
                {"group_id": 222, "title": "B", "call_id": 3, "access_hash": 4},
            ],
            "_vc_deferred_queue_lock": asyncio.Lock(),
            "_vc_join_all_running": False,
            "vc_is_global_floodwait_active": lambda: False,
            "vc_registry_list": self._async_ret([_Rec("joined")]),
            "get_userbot_cluster": lambda: types.SimpleNamespace(
                get_healthy_accounts=lambda: [
                    {"account_id": "acc_A"}, {"account_id": "acc_B"}]),
            "config": types.SimpleNamespace(vc_multi_max_targets=10,
                                            vc_multi_join_timeout=5),
            "_vc_capacity_aware_join": _fake_capacity_join,
            "vc_add_event": lambda *a, **k: None,
        }
        exec(compile(seg, "<drain>", "exec"), ns)
        out = asyncio.run(ns["_vc_deferred_drain_bounded"]())
        self.assertEqual(out["retried"], 2)
        self.assertEqual(out["joined"], 2)
        self.assertEqual(out["remaining"], 0)
        self.assertEqual(len(join_calls), 2)
        self.assertEqual(join_calls[0]["source"], "deferred_drain")
        self.assertIn("VC_DEFERRED_DRAIN", logger.text())

    def test_drain_skips_when_no_capacity(self):
        src = _read(_VOICECHAT)
        seg = _extract_toplevel(src, "_vc_deferred_drain_bounded")
        logger = _FakeLogger()

        class _Rec:
            def __init__(self, state):
                self.state = state

        ns: dict = {
            "asyncio": asyncio,
            "time": time,
            "logger": logger,
            "Any": object,
            "_vc_deferred_queue": [{"group_id": 111, "title": "A",
                                    "call_id": 1, "access_hash": 2}],
            "_vc_deferred_queue_lock": asyncio.Lock(),
            "_vc_join_all_running": False,
            "vc_is_global_floodwait_active": lambda: False,
            "vc_registry_list": self._async_ret(
                [_Rec("joined")] * 20),
            "get_userbot_cluster": lambda: types.SimpleNamespace(
                get_healthy_accounts=lambda: [{"account_id": "acc_A"}]),
            "config": types.SimpleNamespace(vc_multi_max_targets=10,
                                            vc_multi_join_timeout=5),
            "vc_add_event": lambda *a, **k: None,
        }
        exec(compile(seg, "<drain>", "exec"), ns)
        out = asyncio.run(ns["_vc_deferred_drain_bounded"]())
        self.assertEqual(out["retried"], 0)
        self.assertEqual(out["remaining"], 1)

    @staticmethod
    def _async_ret(value):
        async def _ret():
            return value
        return _ret


class TestFixTTCycleAndConfigSource(unittest.TestCase):
    """FIX-TT source: global cycle counter, expand flag, 90s cap."""

    def setUp(self):
        self.src = _read(_VOICECHAT)
        self.cfg = _read(_CONFIG)

    def test_global_cycle_counter_monotonic(self):
        self.assertIn("_AUTO_DISCOVERY_GLOBAL_CYCLE: int = 0", self.src)
        idx = self.src.find("AUTO_DISCOVERY_CYCLE_STARTED cycle=%d global_cycle=%d")
        self.assertGreater(idx, -1)
        win = self.src[max(0, idx - 700): idx + 500]
        self.assertIn("_AUTO_DISCOVERY_GLOBAL_CYCLE += 1", win)
        # The start-path reset preserves the global cycle:
        ridx = self.src.find('"cycle": _AUTO_DISCOVERY_GLOBAL_CYCLE,')
        self.assertGreater(ridx, -1)
        # The loop calls the drain after each completed cycle:
        cidx = self.src.find("AUTO_DISCOVERY_CYCLE_COMPLETED cycle=%d queries=%d")
        cwin = self.src[cidx: cidx + 700]
        self.assertIn("_vc_deferred_drain_bounded()", cwin)

    def test_expand_config_gated_default_on(self):
        self.assertIn("vc_discovery_expand: bool = _env_bool(", self.cfg)
        self.assertIn('"VC_DISCOVERY_EXPAND", True', self.cfg)
        # Both auto-loop search sites pass the config flag:
        count = self.src.count(
            'expand=bool(getattr(config, "vc_discovery_expand", True))')
        self.assertEqual(count, 2, "both search call sites must be gated")

    def test_cycle_runtime_cap_90s_default(self):
        self.assertIn('"VC_DISCOVERY_MAX_RUNTIME_SECONDS", 90)', self.cfg)


# =============================================================================
# §5 — FIX-UU: session hot-reload + /accounts visibility
# =============================================================================

class TestFixUUHotReloadBehavior(unittest.TestCase):
    """T-I behavioral: exec the REAL _vc_session_hot_reload_loop with fake
    Path/cluster — a NEW .session path triggers the import machinery."""

    def _exec_loop(self, files_fn):
        src = _read(_MTPROTO)
        seg = _extract_toplevel(src, "_vc_session_hot_reload_loop")
        self.assertIsNotNone(seg)

        class _StopLoop(Exception):
            pass

        tick = [0]

        class _FakeAsyncio:
            sleep = None  # set below

            @staticmethod
            async def _sleep(s):
                tick[0] += 1
                if tick[0] > 3:
                    raise _StopLoop()
            wait_for = asyncio.wait_for

        class _FakeAsyncioModule(types.ModuleType):
            pass

        fake_asyncio = _FakeAsyncioModule("fake_asyncio")
        fake_asyncio.sleep = _FakeAsyncio._sleep
        fake_asyncio.wait_for = asyncio.wait_for

        class _FakePath:
            def __truediv__(self, other):
                return _FakePath()
        # Build a Path-like factory: Path(anything) -> root-ish object.

        class _FakeFile:
            def __init__(self, name):
                self.name = name

            def endswith(self, suf):
                return self.name.endswith(suf)

            def relative_to(self, root):
                return types.SimpleNamespace(
                    parts=tuple(self.name.split("/")))

            def resolve(self):
                return f"/fake/{self.name}"

        class _FakeSessionFile:
            """Orderable fake .session path object (sorted() needs <)."""

            def __init__(self, f):
                self.name = f

            def endswith(self, s):
                return self.name.endswith(s)

            def relative_to(self, root):
                return types.SimpleNamespace(
                    parts=tuple(self.name.split("/")))

            def resolve(self):
                return f"/fake/{self.name}"

            def __lt__(self, other):
                return self.name < other.name

        class _FakeRoot:
            def __init__(self, key):
                self.key = key

            def exists(self):
                return True

            def rglob(self, pattern):
                return sorted(
                    _FakeSessionFile(f)
                    for f in files_fn(self.key, tick[0]))

            def __repr__(self):
                return f"_FakeRoot({self.key})"

        class _PathFn:
            def __call__(self, *a):
                return _FakePath()

            def __truediv__(self, other):
                return _FakePath()
        # The loop does: Path(config.project_root) / "data" → we need
        # Path(x) / "data" to produce a root keyed by the suffix. Simplest:
        # a callable whose __truediv__ returns a _FakeRoot keyed on other.

        class _PathFactory:
            def __call__(self, base):
                return _PathSegment(base)

        class _PathSegment:
            def __init__(self, base):
                self.base = base

            def __truediv__(self, other):
                if self.base == "PROJECT_ROOT":
                    return _FakeRoot(str(other))
                return _FakeRoot(f"{self.base}/{other}")

        import_calls: list = []

        async def _fake_import():
            import_calls.append(tick[0])
            return {"imported": 1, "duplicate": 1, "skipped": 0,
                    "failed": 0, "reused_legacy": 0, "scanned": 3}

        logger = _FakeLogger()
        cluster = types.SimpleNamespace(
            import_existing_sessions=_fake_import)
        ns: dict = {
            "asyncio": fake_asyncio,
            "logger": logger,
            "Path": _PathFactory(),
            "config": types.SimpleNamespace(project_root="PROJECT_ROOT"),
            "_CLUSTER_ACCOUNTS_DIR": _FakeRoot("accounts"),
            "get_userbot_cluster": lambda: cluster,
            "mtproto_is_started": lambda: True,
            "_VC_HOT_RELOAD_KNOWN_PATHS": None,
        }
        exec(compile(seg, "<hotreload>", "exec"), ns)
        # DRIVE the real loop coroutine (the fake sleep stops it after
        # enough ticks; _StopLoop escapes asyncio.run and is swallowed).
        try:
            asyncio.run(ns["_vc_session_hot_reload_loop"]())
        except Exception:  # noqa: BLE001
            pass
        return ns, logger, import_calls

    def test_new_session_file_triggers_import(self):
        def files(key, tick_no):
            base = ["existing.session"]
            if tick_no >= 3:
                base = ["existing.session", "brand_new.session"]
            return [f"{key}/{f}" for f in base]
        ns, logger, import_calls = self._exec_loop(files)
        # Iteration 1: baseline (no import). Iteration 2+: new file → import.
        self.assertGreaterEqual(len(import_calls), 1,
                                "a NEW .session file must trigger the import")
        self.assertIn("SESSION_HOT_RELOAD_DETECTED", logger.text())
        self.assertIn("SESSION_HOT_IMPORT", logger.text())
        self.assertIn("added=1", logger.text())
        self.assertIn("SESSION_HOT_RELOAD_LOOP started", logger.text())

    def test_unchanged_roots_no_import(self):
        def files(key, tick_no):
            return [f"{key}/existing.session"]
        ns, logger, import_calls = self._exec_loop(files)
        self.assertEqual(import_calls, [],
                         "no import when the file set is unchanged "
                         "(filesystem-only rescan)")


class TestFixUUAccountsVisibilitySource(unittest.TestCase):
    """T-I: /accounts report shape (ACCOUNTS_REPORT + panel wiring)."""

    def test_accounts_report_marker_and_fields(self):
        hd = _read(_HANDLERS)
        idx = hd.find("ACCOUNTS_REPORT total=%d primary=%s")
        self.assertGreater(idx, -1, "ACCOUNTS_REPORT log line must exist")
        win = hd[max(0, idx - 2400): idx + 500]
        for field in ("file=", "phone=", "connected=", "joins_made=",
                      "last_floodwait=", "state="):
            self.assertIn(field, win, f"ACCOUNTS_REPORT must carry {field}")
        # The cluster:list panel shows the per-account Joins line:
        pidx = hd.find("Joins: `")
        self.assertGreater(pidx, -1)
        pwin = hd[max(0, pidx - 1400): pidx + 400]
        self.assertIn("_vc_account_join_stats", pwin)
        self.assertIn("cluster:list", hd[max(0, pidx - 4000): pidx + 2000])

    def test_hot_reload_wiring(self):
        bs = _read(_BOOTSTRAP)
        self.assertIn("_vc_session_hot_reload_start()", bs)
        self.assertIn('("vc_session_hot_reload", _watchdog_get_vc_session_'
                      "hot_reload, _vc_session_hot_reload_start)", bs)
        mt = _read(_MTPROTO)
        self.assertIn("SESSION_HOT_RELOAD_LOOP started", mt)
        self.assertIn("_CLUSTER_ACCOUNTS_DIR", mt)


# =============================================================================
# §6 — FIX-VV: the real SNAPSHOT breakdown + heartbeat counters
# =============================================================================

class TestFixVVObservability(unittest.TestCase):
    """T-J: SNAPSHOT breakdown rendered with per-reason counts; heartbeat
    per-account counters."""

    def test_breakdown_counter_helper_behavioral(self):
        src = _read(_VOICECHAT)
        seg = _extract_toplevel(src, "_vc_excl_reason")
        self.assertIsNotNone(seg)
        ns: dict = {"_vc_join_all_excl_reasons": {}}
        exec(compile(seg, "<excl>", "exec"), ns)
        ns["_vc_excl_reason"]("channel_invalid")
        ns["_vc_excl_reason"]("channel_invalid")
        ns["_vc_excl_reason"]("no_active_call")
        self.assertEqual(ns["_vc_join_all_excl_reasons"],
                         {"channel_invalid": 2, "no_active_call": 1})

    def test_snapshot_breakdown_line_after_snapshot(self):
        src = _read(_VOICECHAT)
        sidx = src.find("VC_JOIN_ALL_SNAPSHOT eligible=%d")
        self.assertGreater(sidx, -1)
        bidx = src.find("VC_JOIN_ALL_SNAPSHOT_BREAKDOWN total_excluded=%d")
        self.assertGreater(bidx, -1)
        # The breakdown is rendered AFTER the SNAPSHOT line, same phase:
        self.assertGreater(bidx, sidx)
        win = src[max(0, bidx - 1200): bidx + 900]
        self.assertIn("_vc_join_all_excl_reasons", win)
        self.assertIn("key=lambda kv: -kv[1]", win)

    def test_reason_instrumented_sites(self):
        src = _read(_VOICECHAT)
        for reason in ("mtproto_not_started", "dead_lettered",
                       "entity_timeout", "peeruser", "no_active_call",
                       "channel_invalid", "discovery_skip"):
            self.assertIn(f'_vc_excl_reason("{reason}")', src,
                          f"exclusion site {reason} must be instrumented")
        # Reset per run:
        self.assertIn("_vc_join_all_excl_reasons.clear()", src)

    def test_heartbeat_carries_per_account_joins(self):
        hd = _read(_HANDLERS)
        idx = hd.find("_v807_stats = getattr(_vc_mod, \"_vc_account_join_stats\", {})")
        self.assertGreater(idx, -1,
                           "heartbeat must read the per-account join stats")
        # v99.02 test maintenance: window 1600 -> 2400 — the FIX-3 FD
        # census block sits between the per-account stats and the
        # BOT_HEARTBEAT log call; the CONTRACT (heartbeat carries the
        # per-account join counters) is unchanged.
        # v99.03 test maintenance: window 2400 -> 5600 — the RC-10
        # ACCOUNT_HEALTH + RC-12 suppression-flush block sits between the
        # FD census and the BOT_HEARTBEAT log call; CONTRACT unchanged.
        # v99.10 test maintenance: window 5600 -> 7500 — the FIX-D
        # MEM_CENSUS block (rss/threads/joined_transports on every logged
        # beat) sits between the FD census and the BOT_HEARTBEAT log
        # call; CONTRACT unchanged (heartbeat carries the per-account
        # join counters + now the memory census).
        win = hd[max(0, idx - 900): idx + 7500]
        # v99.11: the old multi-placeholder BOT_HEARTBEAT
        # format string is GONE BY DESIGN (the P0-1
        # dropped-record fix — 5 placeholders vs 4 args
        # silently dropped EVERY heartbeat at handler
        # level); the emission is now the single-%s
        # pre-formatted census line. CONTRACT (heartbeat
        # carries the per-account join counters) kept.
        self.assertIn(
            'logger.info("BOT_HEARTBEAT %s", _v9911_line)',
            open(_HANDLERS).read())
        self.assertIn('f"{_aid}:J=', win)


# =============================================================================
# §7 — T-K: version bump + prior FIX marker preservation + guardrails
# =============================================================================

class TestVersionBump(unittest.TestCase):

    def test_init_version_is_v98_07(self):
        self.assertIn('__bot_version__ = "v99.11.3"', _read(_INIT))

    def test_bootstrap_identity_is_v98_07(self):
        bs = _read(_BOOTSTRAP)
        self.assertIn('DEPLOYMENT_IDENTITY version={_v9812_pkg_version} ', bs)  # v99: derivation site
        # The 7-module hash set is intact (v97.92 contract):
        for mod in ("voicechat", "utils_real", "config", "mtproto",
                    "bootstrap", "handlers", "join_all_worker"):
            self.assertIn(f"{mod}_sha256=", bs)


class TestPriorFixMarkersPreserved(unittest.TestCase):
    """HARD GUARDRAIL #2: every prior FIX marker (CC..PP) still greps."""

    def test_v98_05_markers(self):
        src = _read(_VOICECHAT)
        for marker in ("VC_PEERUSER_BLACKLIST_PURGED",
                       "VC_PEERUSER_BLACKLIST_SWEEP_DONE",
                       "VC_STALE_CONTAINER_RECOVERY"):
            # (substring find first — keeps failure messages SMALL instead
            # of embedding the whole multi-MB source)
            self.assertGreater(
                src.find(marker), -1,
                f"v98.05 marker {marker} must be preserved")
        # FIX-CC..FF core contracts (container recovery + heartbeat):
        self.assertGreater(src.find("VC_ACTIVE_JOIN_BACKEND_SET"), -1)
        hd = _read(_HANDLERS)
        # v99.11: the old multi-placeholder BOT_HEARTBEAT format string
        # is GONE BY DESIGN (the P0-1 dropped-record fix); the preserved
        # contract is the census payload + the single-%s emission.
        self.assertGreater(
            hd.find('logger.info("BOT_HEARTBEAT %s", _v9911_line)'), -1)
        self.assertGreater(hd.find("MEM_CENSUS rss_mb=%.0f threads=%d"), -1)

    def test_v98_06_fix_ll_markers(self):
        src = _read(_VOICECHAT)
        self.assertIn("VC_BLACKLIST_DECISION", src)
        self.assertIn("verdict=peeruser_rejected_evidence", src)
        self.assertIn("_vc_positive_evidence_for_chat", src)
        self.assertIn("def vc_mark_peeruser", src)
        # The evidence guard at the choke point is INTACT:
        idx = src.find("def vc_mark_peeruser")
        win = src[idx: idx + 4200]
        self.assertIn("_vc_positive_evidence_sync", win)

    def test_v98_06_fix_mm_markers(self):
        src = _read(_VOICECHAT)
        self.assertIn("VC_MOD_RECONCILE_FORCE_AFTER_STARVATION", src)
        self.assertIn("VC_COVERAGE_RECONCILE_START", src)

    def test_v98_06_fix_nn_oo_pp_markers(self):
        src = _read(_VOICECHAT)
        self.assertIn("def _vc_classify_failure_log", src)
        hd = _read(_HANDLERS)
        self.assertIn("_uptime = time.time() - _BOT_START_TIME", hd)
        mt = _read(_MTPROTO)
        self.assertIn("generation_sessions", mt)
        self.assertIn("live_clients", mt)

    def test_already_joined_fast_path_intact(self):
        """GUARDRAIL #4: the 5 correct ALREADY_JOINED backend_connected
        classifications keep working (v98.06 guardrail)."""
        # v98.09-P3 (documented window correction, PATCH-2 precedent): the
        # §13/§23 owner-visibility + metric lines sit between the branch
        # guard and the transition log — window widened 900→1300.
        src = _read(_VOICECHAT)
        idx = src.find("to=ALREADY_JOINED reason=backend_connected")
        self.assertGreater(idx, -1)
        win = src[max(0, idx - 1300): idx + 700]
        self.assertIn("if _backend_connected:", win)

    def test_fix_e_invariants_preserved(self):
        """GUARDRAIL #3: incomplete search ≠ absent; redetect failure ≠
        left (v98.00 FIX-E invariants)."""
        src = _read(_VOICECHAT)
        self.assertIn("reason=redetect_failed", src)
        self.assertIn("no destructive action", src)
        self.assertIn("INCOMPLETE SEARCH != ABSENT", src)

    def test_prior_breaker_contracts_preserved(self):
        """The v97.5 per-account breaker machinery still exists; the
        systemic path is now gated by all-parked (FIX-RR) but the breaker
        class itself is untouched."""
        jw = _read(os.path.join(_PKG_ROOT, "mediagrab_bot",
                                "join_all_worker.py"))
        self.assertIn("def record_failure", jw)
        self.assertIn("JOIN_ALL_BREAKER ACCOUNT_OPEN", jw)
        self.assertIn("is_systemic", jw)


if __name__ == "__main__":
    unittest.main()
