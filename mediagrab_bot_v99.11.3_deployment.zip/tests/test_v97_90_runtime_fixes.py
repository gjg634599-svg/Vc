"""
v97.90 — ROOT CAUSE FIX: setup_logging() NEVER CALLED + pre-wrap merge.

ROOT CAUSE #1 (RUNTIME-PROVEN from bot_forced (3).log):
  setup_logging() — the function that initializes the root logger with
  console + file handlers, emits DIAGNOSTIC_BOOT, creates the diagnostic
  file — was NEVER CALLED. It was defined in utils_real.py:45 but only
  called from _bot_core.py:88 — and _bot_core.py is NOT imported by
  bootstrap.py or __init__.py.

  bootstrap.py creates its logger via `logging.getLogger("mediagrab")`
  which returns a bare logger with NO file handlers → DIAGNOSTIC_BOOT
  never prints, no diagnostic file is created.

  Runtime proof (bot_forced (3).log):
  - DEPLOYMENT_IDENTITY version=v99.00 IS present (confirms deployment)
  - 0 DIAGNOSTIC_BOOT events
  - 0 DIAGNOSTIC_FILE_CREATE_RESULT events
  - 0 DIAGNOSTIC_PATH events
  - 0 PYTGCALLS_PREWRAP events (v97.89 pre-wrap not deployed)

FIX: call setup_logging() at the very start of main() in bootstrap.py.
This initializes the root logger BEFORE DEPLOYMENT_IDENTITY is emitted.

ROOT CAUSE #2 (SOURCE-PROVEN): Construction race
  PyTgCalls(client) registers an unfiltered Raw() handler at construction
  time. v97.89 added _prewrap_client_event_handlers() to fix this, but
  v97.89 was not deployed (confirmed by 0 PYTGCALLS_PREWRAP events).

  v97.90 preserves the v97.89 pre-wrap fix.

ROOT CAUSE #3 (SOURCE-PROVEN): vc_reset_backend orphaning
  vc_reset_backend() can null out _vc_backend without stopping the old
  PyTgCalls instance. v97.86 added preserve_connections=True to prevent
  this. v97.90 preserves this fix.

ROOT CAUSE #4 (SOURCE-PROVEN): Stale registry counting
  Registry says "joined" but backend is disconnected → counted as
  already_joined. v97.85 added VC_STALE_JOINED_RECORD detection.
  Runtime confirms this IS executing (27 events in bf3).
  v97.90 preserves this fix.

ALL v97.80-v97.89 fixes are preserved in this merged version.
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_BOOTSTRAP = os.path.join(_BASE, "mediagrab_bot", "bootstrap.py")
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_UTILS = os.path.join(_BASE, "mediagrab_bot", "utils_real.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


class TestSetupLoggingCalled(unittest.TestCase):
    """v97.90: setup_logging() MUST be called in main()."""

    def test_setup_logging_called_in_main(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        idx = src.find("def main() -> None:")
        self.assertGreater(idx, 0)
        body = src[idx:idx + 1000]
        self.assertIn("setup_logging()", body)

    def test_setup_logging_called_before_deployment_identity(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        setup_idx = src.find("setup_logging()", src.find("def main"))
        deploy_idx = src.find("DEPLOYMENT_IDENTITY", setup_idx)
        self.assertGreater(setup_idx, 0)
        self.assertGreater(deploy_idx, 0)
        self.assertLess(setup_idx, deploy_idx,
                        "setup_logging MUST be called before DEPLOYMENT_IDENTITY")


class TestDeploymentIdentity(unittest.TestCase):
    def test_version_is_v97_92(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn("version={_v9812_pkg_version}", src)  # v99: derivation site

    def test_init_version(self):
        with open(_INIT) as f:
            src = f.read()
        self.assertIn('__bot_version__ = "v99.11.3"', src)


class TestPreservedFixes(unittest.TestCase):
    """Verify all prior fixes are preserved in the merged version."""

    def test_prewrite_before_construction(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_prewrap_client_event_handlers", src)
        prewrap_idx = src.find("_prewrap_client_event_handlers(self._mtproto)")
        construct_idx = src.find("_PyTgCalls_cls(self._mtproto)", prewrap_idx)
        self.assertGreater(prewrap_idx, 0)
        self.assertGreater(construct_idx, 0)
        self.assertLess(prewrap_idx, construct_idx)

    def test_filter_no_idempotency_guard(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _wrap_pytgcalls_update_filter")
        body = src[idx:idx + 800]
        self.assertNotIn("if client_id in _PYTGCALLS_WRAPPED_CLIENTS", body)

    def test_backend_preservation(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_BACKEND_PRESERVED", src)
        self.assertIn("preserve_connections", src)

    def test_stale_joined_record(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_STALE_JOINED_RECORD", src)

    def test_is_open_property(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("VC_TRACKING_SNAPSHOT")
        block = src[idx:idx + 1200]
        self.assertIn("_vc_join_all_breaker.is_open ", block)

    def test_floodwait_defer(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_TARGET_FLOODWAIT_DEFERRED", src)

    def test_leave_block(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_LEAVE_BLOCKED_DURING_JOIN_ALL", src)

    def test_diagnostic_boot_in_setup_logging(self):
        with open(_UTILS) as f:
            src = f.read()
        self.assertIn("DIAGNOSTIC_BOOT", src)
        self.assertIn("DIAGNOSTIC_PATH", src)
        self.assertIn("DIAGNOSTIC_FILE_CREATE_RESULT", src)
        self.assertIn("DIAGNOSTIC_FALLBACK", src)

    def test_deployment_identity(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn("DEPLOYMENT_IDENTITY", src)
        self.assertIn("voicechat_sha256=", src)

    def test_forced_cancel(self):
        mtproto = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
        with open(mtproto) as f:
            src = f.read()
        self.assertIn("_mediagrab_bg_tasks", src)

    def test_reconnect_instrumentation(self):
        mtproto = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
        with open(mtproto) as f:
            src = f.read()
        self.assertIn("MTPROTO_RECONNECT_BEGIN", src)


class TestDiagnosticLoggingBehavioral(unittest.TestCase):
    """Test diagnostic .env parsing."""

    def test_true_parsed(self):
        raw = "true"
        result = raw.strip().lower() in ("1", "true", "yes", "on")
        self.assertTrue(result)

    def test_TRUE_parsed(self):
        raw = "TRUE"
        result = raw.strip().lower() in ("1", "true", "yes", "on")
        self.assertTrue(result)

    def test_false_not_parsed(self):
        raw = "false"
        result = raw.strip().lower() in ("1", "true", "yes", "on")
        self.assertFalse(result)

    def test_empty_not_parsed(self):
        raw = ""
        result = bool(raw) and raw.strip().lower() in ("1", "true", "yes", "on")
        self.assertFalse(result)


class TestJoinAllIdempotency(unittest.TestCase):
    """Test Join All idempotency invariants."""

    def test_join_all_preserves_already_joined(self):
        rec_state = "joined"
        rec_request_accepted = True
        is_already_joined = (rec_state == "joined" and rec_request_accepted)
        self.assertTrue(is_already_joined)
        self.assertEqual(rec_state, "joined")

    def test_leave_blocked_during_join_all(self):
        block_active = True
        reason = ""
        _destructive = ("leave_all", "shutdown", "tour", "Leave All", "Auto")
        is_blocked = block_active and reason not in _destructive
        self.assertTrue(is_blocked)

    def test_leave_all_not_blocked(self):
        block_active = True
        reason = "Leave All"
        _destructive = ("leave_all", "shutdown", "tour", "Leave All", "Auto")
        is_blocked = block_active and reason not in _destructive
        self.assertFalse(is_blocked)

    def test_stale_registry_not_already_joined(self):
        registry_state = "joined"
        backend_connected = False
        is_already_joined = backend_connected  # v97.85: only backend-confirmed
        self.assertFalse(is_already_joined)

    def test_backend_connected_wins(self):
        registry_state = "left"
        backend_connected = True
        is_already_joined = backend_connected  # v97.84: backend wins
        self.assertTrue(is_already_joined)


if __name__ == "__main__":
    unittest.main()
