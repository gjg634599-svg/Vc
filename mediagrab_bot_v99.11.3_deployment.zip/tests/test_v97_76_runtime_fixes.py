"""
v97.76 RUNTIME-DRIVEN FORENSIC FIX tests — STRICT SINGLE-FLIGHT RECONNECT.

Root cause fixed in v97.76 (driven by REAL production runtime log — note 46):

  P0  RECONNECT STORM — v97.75 had 4 fire-and-forget call sites that each did:
      `supervised_create_task(_mtproto_safe_reconnect(), name="mtproto_safe_reconnect")`
      Each trigger created a NEW asyncio.Task. Even though ReconnectCoordinator
      made the UNDERLYING reconnect single-flight (one operation), the TASKS
      themselves accumulated. Runtime proof: task dumps showed 11 simultaneous
      `mtproto_safe_reconnect` tasks (note 46 lines 858-868) and 14+ later
      (lines 1192-1205), all awaiting `coord.request_reconnect()`.
      FIX: `_mtproto_trigger_reconnect()` — a strict single-flight function that
      creates ONE shared task. All callers converge on it. At any instant: 0 or 1
      reconnect task.

  P0  TASK_DUMP_CATEGORIES instrumentation was BROKEN in v97.75 — it checked
      `frame_info` (filename:lineno) for function names like "_dispatch_update",
      but function names live in `co_name`. This caused 67 _dispatch_update tasks
      to be miscategorized as "other=99" in note 46. FIX: check co_name too.

  P0  RECONNECT_TASK_STORM alert — fires when mtproto_safe_reconnect task
      count > 1. The primary diagnostic for the v97.76 fix.

Tests A-G are REAL BEHAVIORAL asyncio tests (no telethon needed) that prove
the strict single-flight property at the pattern level.
"""
import asyncio
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_BOOTSTRAP = os.path.join(_BASE, "mediagrab_bot", "bootstrap.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


# ---------------------------------------------------------------------------
# Source-verification tests
# ---------------------------------------------------------------------------

class TestP0SharedReconnectTaskDeclared(unittest.TestCase):
    """P0: the shared reconnect task + trigger function must exist in mtproto.py."""

    def test_shared_task_var_declared(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_mtproto_reconnect_shared_task", src)

    def test_trigger_function_declared(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("def _mtproto_trigger_reconnect()", src)
        self.assertIn("MTPROTO_RECONNECT_SHARED_SKIP", src)

    def test_shared_runner_declared(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("async def _mtproto_safe_reconnect_shared_runner()", src)


class TestP0FireAndForgetSitesConverted(unittest.TestCase):
    """P0: all 4 fire-and-forget `supervised_create_task(_mtproto_safe_reconnect())`
    sites in voicechat.py must be converted to `_mtproto_trigger_reconnect()`."""

    def test_no_old_pattern_fire_and_forget(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        # The old pattern must be GONE (no new task per trigger)
        self.assertNotIn(
            'supervised_create_task(_mtproto_safe_reconnect(), name="mtproto_safe_reconnect")',
            src,
        )

    def test_all_4_sites_use_trigger(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        count = src.count("_mtproto_trig()  # v97.76: strict single-flight")
        self.assertGreaterEqual(count, 4,
                               "expected ≥4 trigger call sites, found %d" % count)


class TestP0InstrumentationFixed(unittest.TestCase):
    """P0: TASK_DUMP_CATEGORIES must check co_name (not just frame_info)."""

    def test_co_name_extracted(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn("func_name = f.f_code.co_name", src)

    def test_mtproto_safe_reconnect_category(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn('"mtproto_safe_reconnect"', src)

    def test_reconnect_task_storm_alert(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn("RECONNECT_TASK_STORM", src)
        self.assertIn("mtproto_safe_reconnect_tasks=", src)

    def test_dispatch_update_category(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn("telethon_dispatch_update", src)
        self.assertIn("TELETHON_DISPATCH_UPDATE_BACKLOG", src)


class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_92(self):
        with open(_INIT) as f:
            src = f.read()
        self.assertIn('__bot_version__ = "v99.11.3"', src)


# ---------------------------------------------------------------------------
# BEHAVIORAL TESTS A-G (real asyncio, no telethon)
# These prove the strict single-flight property at the pattern level.
# ---------------------------------------------------------------------------

class TestAConcurrentReconnectCallers(unittest.TestCase):
    """Test A — 100 concurrent callers must result in:
    - reconnect task count = 1
    - underlying reconnect executions = 1"""

    def test_100_callers_create_1_task_1_execution(self):
        execution_count = {"n": 0}
        task_count = {"max": 0, "current": 0}
        shared_task_ref = {"task": None}

        async def underlying_reconnect():
            execution_count["n"] += 1
            await asyncio.sleep(0.1)  # simulate drain+connect
            return True

        def trigger_reconnect():
            """v97.76 pattern: strict single-flight."""
            existing = shared_task_ref["task"]
            if existing is not None and not existing.done():
                return  # no-op — shared task in-flight
            task = asyncio.ensure_future(underlying_reconnect())
            shared_task_ref["task"] = task
            task_count["current"] += 1
            task_count["max"] = max(task_count["max"], task_count["current"])

            def _on_done(t):
                if shared_task_ref["task"] is t:
                    shared_task_ref["task"] = None
                task_count["current"] -= 1
            task.add_done_callback(_on_done)

        async def caller():
            trigger_reconnect()
            await asyncio.sleep(0.05)

        async def driver():
            # 100 concurrent callers
            await asyncio.gather(*[caller() for _ in range(100)])
            # Wait for the shared task to finish
            if shared_task_ref["task"] is not None:
                await shared_task_ref["task"]

        asyncio.new_event_loop().run_until_complete(driver())
        self.assertEqual(execution_count["n"], 1,
                         "underlying reconnect must execute exactly 1 time (got %d)" % execution_count["n"])
        self.assertLessEqual(task_count["max"], 1,
                             "max concurrent reconnect tasks must be ≤1 (got %d)" % task_count["max"])


class TestBReconnectFailurePropagation(unittest.TestCase):
    """Test B — all callers receive the appropriate failure without creating
    100 replacement tasks."""

    def test_failure_does_not_create_replacement_storm(self):
        execution_count = {"n": 0}
        shared_task_ref = {"task": None}
        task_created_count = {"n": 0}

        async def underlying_reconnect():
            execution_count["n"] += 1
            await asyncio.sleep(0.05)
            raise ConnectionError("reconnect failed")

        def trigger_reconnect():
            existing = shared_task_ref["task"]
            if existing is not None and not existing.done():
                return
            task = asyncio.ensure_future(underlying_reconnect())
            shared_task_ref["task"] = task
            task_created_count["n"] += 1

            def _on_done(t):
                if shared_task_ref["task"] is t:
                    shared_task_ref["task"] = None
            task.add_done_callback(_on_done)

        async def caller():
            trigger_reconnect()
            await asyncio.sleep(0.02)

        async def driver():
            await asyncio.gather(*[caller() for _ in range(100)])
            if shared_task_ref["task"] is not None:
                try:
                    await shared_task_ref["task"]
                except Exception:
                    pass

        asyncio.new_event_loop().run_until_complete(driver())
        self.assertEqual(execution_count["n"], 1,
                         "failed reconnect must NOT trigger replacement executions")
        self.assertLessEqual(task_created_count["n"], 1,
                             "only 1 task must be created even on failure (got %d)" % task_created_count["n"])


class TestCCancellationOfOneCaller(unittest.TestCase):
    """Test C — cancellation of one caller must NOT cancel the shared reconnect
    operation. In v97.76, `_mtproto_trigger_reconnect()` is fire-and-forget:
    it creates the shared task and returns None (callers can't await/cancel it)."""

    def test_cancel_trigger_does_not_cancel_shared_task(self):
        shared_task_ref = {"task": None}
        shared_task_cancelled = {"flag": False}
        shared_task_completed = {"flag": False}

        async def underlying_reconnect():
            try:
                await asyncio.sleep(0.2)
                shared_task_completed["flag"] = True
                return True
            except asyncio.CancelledError:
                shared_task_cancelled["flag"] = True
                raise

        def trigger_reconnect():
            """v97.76 pattern: fire-and-forget. Does NOT return the task.
            Callers cannot cancel the shared task because they don't have a ref."""
            existing = shared_task_ref["task"]
            if existing is not None and not existing.done():
                return  # no-op — shared task in-flight
            task = asyncio.ensure_future(underlying_reconnect())
            shared_task_ref["task"] = task

            def _on_done(t):
                if shared_task_ref["task"] is t:
                    shared_task_ref["task"] = None
            task.add_done_callback(_on_done)
            # v97.76: do NOT return the task — callers can't cancel it

        async def caller_trigger():
            """Simulates a fire-and-forget caller that triggers + does other work."""
            trigger_reconnect()
            await asyncio.sleep(0.3)  # caller does other work

        async def driver():
            caller = asyncio.ensure_future(caller_trigger())
            await asyncio.sleep(0.05)  # let caller trigger + do work
            caller.cancel()  # cancel the caller
            try:
                await caller
            except asyncio.CancelledError:
                pass
            # Wait for the shared task to complete naturally
            if shared_task_ref["task"] is not None:
                await shared_task_ref["task"]

        asyncio.new_event_loop().run_until_complete(driver())
        self.assertFalse(shared_task_cancelled["flag"],
                         "shared reconnect task must NOT be cancelled when caller is cancelled")
        self.assertTrue(shared_task_completed["flag"],
                        "shared reconnect task must complete normally despite caller cancellation")


class TestDRepeatedReconnectAfterCompletion(unittest.TestCase):
    """Test D — after the first reconnect finishes, a subsequent reconnect
    must be allowed."""

    def test_reconnect_allowed_after_completion(self):
        execution_count = {"n": 0}
        shared_task_ref = {"task": None}

        async def underlying_reconnect():
            execution_count["n"] += 1
            await asyncio.sleep(0.05)
            return True

        def trigger_reconnect():
            existing = shared_task_ref["task"]
            if existing is not None and not existing.done():
                return
            task = asyncio.ensure_future(underlying_reconnect())
            shared_task_ref["task"] = task

            def _on_done(t):
                if shared_task_ref["task"] is t:
                    shared_task_ref["task"] = None
            task.add_done_callback(_on_done)

        async def driver():
            trigger_reconnect()
            if shared_task_ref["task"]:
                await shared_task_ref["task"]  # first finishes
            first_count = execution_count["n"]
            self.assertEqual(first_count, 1)
            # shared_task_ref should be cleared now
            self.assertIsNone(shared_task_ref["task"])
            # Second reconnect — must be allowed
            trigger_reconnect()
            if shared_task_ref["task"]:
                await shared_task_ref["task"]
            self.assertEqual(execution_count["n"], 2,
                             "second reconnect must execute after first completes")

        asyncio.new_event_loop().run_until_complete(driver())


class TestEGenerationLifecycle(unittest.TestCase):
    """Test E — old generation must be completely dead before a new generation starts."""

    def test_old_generation_dead_before_new_starts(self):
        old_gen_alive = {"flag": False}
        new_gen_started_before_old_died = {"flag": False}

        async def old_gen_task():
            old_gen_alive["flag"] = True
            try:
                await asyncio.sleep(0.1)
            finally:
                old_gen_alive["flag"] = False

        async def new_gen_task():
            if old_gen_alive["flag"]:
                new_gen_started_before_old_died["flag"] = True
            await asyncio.sleep(0.01)

        async def driver():
            old = asyncio.ensure_future(old_gen_task())
            await asyncio.sleep(0.02)  # let old gen start
            # Wait for old gen to finish BEFORE starting new gen (v97.75 pattern)
            await old
            # Now old gen is dead — start new gen
            new = asyncio.ensure_future(new_gen_task())
            await new

        asyncio.new_event_loop().run_until_complete(driver())
        self.assertFalse(new_gen_started_before_old_died["flag"],
                         "new generation must NOT start before old generation is dead")


class TestFReconnectStormBounded(unittest.TestCase):
    """Test F — simulate hundreds of triggers and prove task count remains bounded."""

    def test_500_triggers_create_at_most_1_task(self):
        task_count = {"max": 0, "current": 0}
        shared_task_ref = {"task": None}

        async def underlying_reconnect():
            await asyncio.sleep(0.3)  # long reconnect
            return True

        def trigger_reconnect():
            existing = shared_task_ref["task"]
            if existing is not None and not existing.done():
                return  # no-op
            task = asyncio.ensure_future(underlying_reconnect())
            shared_task_ref["task"] = task
            task_count["current"] += 1
            task_count["max"] = max(task_count["max"], task_count["current"])

            def _on_done(t):
                if shared_task_ref["task"] is t:
                    shared_task_ref["task"] = None
                task_count["current"] -= 1
            task.add_done_callback(_on_done)

        async def driver():
            # 500 rapid triggers
            for _ in range(500):
                trigger_reconnect()
                await asyncio.sleep(0)  # yield
            # Wait for the shared task to complete
            if shared_task_ref["task"] is not None:
                await shared_task_ref["task"]

        asyncio.new_event_loop().run_until_complete(driver())
        self.assertLessEqual(task_count["max"], 1,
                             "500 triggers must create at most 1 concurrent task (got %d)" % task_count["max"])


class TestGPyTgCallsRegistration(unittest.TestCase):
    """Test G — repeated handler initialization must produce exactly one
    registered handler per relevant instance. (v97.75 fix preserved + verified.)"""

    def test_exactly_one_registration_per_instance(self):
        from weakref import WeakKeyDictionary
        registered = WeakKeyDictionary()
        call_count = {"n": 0}

        class FakePyTgCalls:
            def on_stream_data(self, handler):
                call_count["n"] += 1

        obj = FakePyTgCalls()
        # 10 repeated registration attempts
        for _ in range(10):
            if not registered.get(obj, False):
                obj.on_stream_data(lambda f: None)
                registered[obj] = True

        self.assertEqual(call_count["n"], 1,
                         "handler must be registered exactly once (got %d)" % call_count["n"])


if __name__ == "__main__":
    unittest.main()
