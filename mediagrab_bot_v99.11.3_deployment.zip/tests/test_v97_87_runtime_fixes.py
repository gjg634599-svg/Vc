"""
v97.87 — PYTGCALLS FILTER IDEMPOTENCY FIX (ROOT CAUSE OF VC AUTO-LEAVE).

Root cause (RUNTIME-PROVEN from note 57):
  899 _dispatch_update tasks + 59 pytgcalls tasks + 933 total tasks + 13.15s CRITICAL.
  The v97.80 PyTgCalls filter's idempotency guard tracked id(client) — the Telethon
  CLIENT. When vc_reset_backend() created a NEW PyTgCalls(client) on the SAME client,
  the guard said "already wrapped" → SKIPPED → the NEW Raw() handler was NOT filtered.

  Chain: unfiltered PyTgCalls → receives EVERY MTProto update → 899 dispatch tasks
  → 13.15s event-loop starvation → MTProto keepalive timeout → MTProto disconnect
  → PyTgCalls loses MTProto connection → VC physically leaves.

Fix: REMOVE the idempotency guard. Each call scans ALL Raw() handlers and replaces
only UNFILTERED ones (identified by __name__ != "_filtered_update_handler").
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


class TestFilterIdempotencyFix(unittest.TestCase):
    """v97.87: the idempotency guard must NOT prevent re-filtering."""

    def test_no_idempotency_guard(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _wrap_pytgcalls_update_filter")
        body = src[idx:idx + 800]
        self.assertNotIn("if client_id in _PYTGCALLS_WRAPPED_CLIENTS", body)
        self.assertNotIn("if client_id in _PYTGCALLS_WRAPPED", body)

    def test_already_filtered_check_exists(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn('_cb_name == "_filtered_update_handler"', src)

    def test_filter_skips_already_filtered(self):
        """Already-filtered handlers are skipped, unfiltered are replaced."""
        # Simulate the check
        cb_name = "_filtered_update_handler"
        is_already_filtered = (cb_name == "_filtered_update_handler")
        self.assertTrue(is_already_filtered)

        cb_name = "on_update"  # original PyTgCalls callback
        is_already_filtered = (cb_name == "_filtered_update_handler")
        self.assertFalse(is_already_filtered)

    def test_replacement_still_works(self):
        """New Raw() handlers from new PyTgCalls instances ARE replaced."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("Found an UNFILTERED Raw() handler", src)
        self.assertIn("client.remove_event_handler", src)
        self.assertIn("client.add_event_handler", src)


class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_92(self):
        with open(_INIT) as f:
            src = f.read()
        self.assertIn('__bot_version__ = "v99.11.3"', src)


class TestPreservedFixes(unittest.TestCase):
    """Verify all prior fixes preserved."""

    def test_backend_preservation(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_BACKEND_PRESERVED", src)
        self.assertIn("preserve_connections", src)

    def test_stale_joined_record(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_STALE_JOINED_RECORD", src)

    def test_backend_stop_instrumentation(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_BACKEND_STOP_REQUEST", src)

    def test_is_open_property(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("VC_TRACKING_SNAPSHOT")
        block = src[idx:idx + 1200]
        self.assertIn("_vc_join_all_breaker.is_open ", block)

    def test_floodwait_defer(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_TARGET_FLOODWAIT_DEFERRED", src)

    def test_leave_block(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_LEAVE_BLOCKED_DURING_JOIN_ALL", src)

    def test_diagnostic_logging(self):
        utils = os.path.join(_BASE, "mediagrab_bot", "utils_real.py")
        with open(utils) as f:
            src = f.read()
        self.assertIn("DIAGNOSTIC_LOGGING_INITIALIZED", src)

    def test_forced_cancel(self):
        mtproto = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
        with open(mtproto) as f:
            src = f.read()
        self.assertIn("_mediagrab_bg_tasks", src)


class TestDispatchExplosionPrevention(unittest.TestCase):
    """Test that the filter prevents dispatch explosion."""

    def test_filter_applies_to_new_instances(self):
        """When a new PyTgCalls is created, its Raw() handler IS filtered."""
        # v97.87: no idempotency guard → every call scans ALL Raw() handlers
        # → new unfiltered handlers ARE replaced
        already_wrapped = True  # client was wrapped before
        has_idempotency_guard = False  # v97.87 removed it
        will_reapply = not has_idempotency_guard  # True — will re-scan
        self.assertTrue(will_reapply)

    def test_already_filtered_skipped(self):
        """Already-filtered handlers are NOT double-wrapped."""
        handler_name = "_filtered_update_handler"
        is_already_filtered = handler_name == "_filtered_update_handler"
        should_skip = is_already_filtered
        self.assertTrue(should_skip)

    def test_unfiltered_replaced(self):
        """Unfiltered Raw() handlers ARE replaced."""
        handler_name = "on_update"  # original PyTgCalls callback
        is_already_filtered = handler_name == "_filtered_update_handler"
        should_replace = not is_already_filtered
        self.assertTrue(should_replace)


if __name__ == "__main__":
    unittest.main()
