"""v99.11 — THE POST-JOIN VC PERSISTENCE / LEAVE-POLICY SUITE (P0).

THE INVARIANT UNDER TEST (mission §post-join-persistence):

    JOIN SUCCESS → ACTIVE → REMAIN IN VC

A successful join may only be left for a deliberate, VALIDATED reason.
Uncertainty — verification failure, UNKNOWN, NOT_MEMBER/INACCESSIBLE,
stale call identity, Join-All processing a later target, resource
telemetry, resource-guard pressure, SQLite checkpoints, heartbeats,
queue-idle, another account joining, transient Telegram errors, entity
resolution failure — is NEVER sufficient evidence to destroy a healthy
transport.

The v99.10 leave audit found the gap: ``_vc_cleanup_stale_backend_call``
("cleanup") is a REAL Telegram leave; the Join-All snapshot could fire
it on registry=UNKNOWN (weak evidence — 1480× VC_PARTICIPATION_UNKNOWN
per 38-min production log); and NO leave path required a reason.
v99.11 routes every destructive call through ``vc_leave_policy`` with
explicit reason codes.

Scenarios marked MANDATORY in the mission are tagged [MANDATORY].
"""

from __future__ import annotations

import asyncio
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mediagrab_bot import vc_leave_policy as vlp  # noqa: E402
from mediagrab_bot.vc_leave_policy import LeaveReason  # noqa: E402


class TestLeavePolicyAuthorization(unittest.TestCase):
    """vc_leave_authorize: the reason-code decision table."""

    def test_a1_no_reason_denied(self):
        ok, cause = vlp.vc_leave_authorize("", "some_caller", 1)
        self.assertFalse(ok)
        self.assertEqual(cause, "no_reason")
        ok2, _ = vlp.vc_leave_authorize(None, "x", 1)
        self.assertFalse(ok2)

    def test_a2_unknown_reason_denied(self):
        ok, cause = vlp.vc_leave_authorize("BECAUSE_I_FELT_LIKE_IT", "x", 1)
        self.assertFalse(ok)
        self.assertIn("unknown_reason", cause)

    def test_a3_deliberate_reasons_always_authorized(self):
        for r in (LeaveReason.USER_REQUESTED, LeaveReason.ADMIN_REQUESTED,
                  LeaveReason.TARGET_REMOVED, LeaveReason.EXPLICIT_STOP,
                  LeaveReason.SHUTDOWN, LeaveReason.TOUR_CYCLE,
                  LeaveReason.MANUAL_OVERRIDE,
                  LeaveReason.MTPROTO_ADMIN_STOP):
            ok, cause = vlp.vc_leave_authorize(r, "test", 1)
            self.assertTrue(ok, f"{r} must be authorized: {cause}")

    def test_a4_validated_automatic_requires_evidence(self):
        for r in (LeaveReason.RECONCILE_CONFIRMED_ABSENT,
                  LeaveReason.STALE_CONTAINER_VERIFIED_ABSENT,
                  LeaveReason.VC_TERMINATED,
                  LeaveReason.ACCOUNT_LOGGED_OUT):
            ok, cause = vlp.vc_leave_authorize(r, "test", 1)
            self.assertFalse(ok, f"{r} without evidence must be denied")
            self.assertEqual(cause, "validated_reason_requires_evidence")
            ok2, _ = vlp.vc_leave_authorize(
                r, "test", 1, evidence="3-streak targeted negative")
            self.assertTrue(ok2)

    def test_a5_failed_join_cleanup_authorized_without_evidence(self):
        """The pipeline's OWN failed NEW join — always allowed (it never
        touches an ACTIVE transport; the pipeline only holds the chat
        while its own join is in flight)."""
        ok, _ = vlp.vc_leave_authorize(
            LeaveReason.FAILED_JOIN_CLEANUP, "vc_pipeline", 1)
        self.assertTrue(ok)

    def test_a6_resource_emergency_opt_in_only(self):
        import os
        os.environ.pop("VC_RESOURCE_EMERGENCY_LEAVE", None)
        ok, cause = vlp.vc_leave_authorize(
            LeaveReason.RESOURCE_EMERGENCY, "test", 1)
        self.assertFalse(ok)
        self.assertEqual(cause, "resource_emergency_not_enabled")
        try:
            os.environ["VC_RESOURCE_EMERGENCY_LEAVE"] = "1"
            ok2, _ = vlp.vc_leave_authorize(
                LeaveReason.RESOURCE_EMERGENCY, "test", 1)
            self.assertTrue(ok2)
        finally:
            os.environ.pop("VC_RESOURCE_EMERGENCY_LEAVE", None)

    def test_a7_join_all_block_denies_validated_automatic(self):
        """While a Join-All run is active, validated-automatic leaves are
        DENIED (an in-flight run must not destroy targets it or a
        previous run joined) — except FAILED_JOIN_CLEANUP and the
        v99.11.3 verified-dead release carve-out.

        v99.11.3 (documented correction): RECONCILE_CONFIRMED_ABSENT and
        STALE_CONTAINER_VERIFIED_ABSENT are now authorized during the
        block WHEN evidence is present.  Production evidence
        (2026-09-25 17:09:55-17:10:29): the blanket block DENIED the 8
        verified-absent stale-container releases during the Join-All
        snapshot phase → the dead native objects stayed in the calls
        container retaining sockets (fd 345→885 over 3.5h with joined
        FLAT) and the transport-lifecycle records stayed stuck in
        STOPPING (360× VC_TRANSPORT_RESOURCE_LEAK_SUSPECTED).  A
        verified-dead object is not a live Join-All target: releasing it
        can only return native resources.  Without evidence the denial
        stands (rule 4 unchanged); the remaining validated-automatic
        reasons keep the historical block."""
        import mediagrab_bot.voicechat as vw
        prev = vw._vc_join_all_leave_block_active
        try:
            vw._vc_join_all_leave_block_active = True
            # v99.11.3 carve-out: verified-dead releases WITH STRONG
            # evidence (authoritative-absence tokens) stay authorized
            # during the block (they release proven-dead objects only).
            ok, cause = vlp.vc_leave_authorize(
                LeaveReason.RECONCILE_CONFIRMED_ABSENT, "test", 1,
                evidence="3-streak negative")
            self.assertTrue(ok)
            self.assertEqual(cause, "")
            ok_v, cause_v = vlp.vc_leave_authorize(
                LeaveReason.STALE_CONTAINER_VERIFIED_ABSENT, "test", 1,
                evidence="verified absent")
            self.assertTrue(ok_v)
            # the production strong evidence passes
            ok_p, _ = vlp.vc_leave_authorize(
                LeaveReason.STALE_CONTAINER_VERIFIED_ABSENT, "test", 1,
                evidence="registry=joined but backend disconnected and "
                         "container lacks the object (passive removal)")
            self.assertTrue(ok_p)
            # WITHOUT evidence the denial stands (rule 4 unchanged)
            ok_ne, cause_ne = vlp.vc_leave_authorize(
                LeaveReason.RECONCILE_CONFIRMED_ABSENT, "test", 1)
            self.assertFalse(ok_ne)
            self.assertEqual(cause_ne,
                             "validated_reason_requires_evidence")
            # WEAK evidence (no authoritative-absence token) keeps the
            # historical block — the m7 guarantee
            ok_w, cause_w = vlp.vc_leave_authorize(
                LeaveReason.STALE_CONTAINER_VERIFIED_ABSENT, "test", 1,
                evidence="registry=unknown - NO, that is weak")
            self.assertFalse(ok_w)
            self.assertEqual(cause_w, "blocked_during_join_all")
            # the remaining validated-automatic reasons keep the block
            ok_b, cause_b = vlp.vc_leave_authorize(
                LeaveReason.VC_TERMINATED, "test", 1,
                evidence="terminated")
            self.assertFalse(ok_b)
            self.assertEqual(cause_b, "blocked_during_join_all")
            # deliberate reasons still pass during Join-All
            ok2, _ = vlp.vc_leave_authorize(
                LeaveReason.USER_REQUESTED, "test", 1)
            self.assertTrue(ok2)
            # the pipeline's own failed join still passes
            ok3, _ = vlp.vc_leave_authorize(
                LeaveReason.FAILED_JOIN_CLEANUP, "test", 1)
            self.assertTrue(ok3)
        finally:
            vw._vc_join_all_leave_block_active = prev


class _LeaveRecorder:
    """A leave factory that records whether the destructive call fired."""

    def __init__(self):
        self.fired = 0
        self.error = None

    async def __call__(self):
        self.fired += 1
        if self.error:
            raise self.error
        return "success"


class TestLeaveExecuteChokepoint(unittest.TestCase):
    """vc_leave_execute: REQUESTED → authorize → execute → COMPLETED/
    FAILED/DENIED markers (captured from the real logger)."""

    def _capture(self):
        import logging
        events = []

        class _Cap(logging.Handler):
            def emit(self, record):
                events.append(record.getMessage())

        cap = _Cap()
        lg = logging.getLogger("mediagrab")
        lg.setLevel(logging.INFO)
        lg.addHandler(cap)
        return lg, cap, events

    def test_b1_authorized_leave_full_marker_contract(self):
        lg, cap, events = self._capture()
        try:
            rec = _LeaveRecorder()
            ok = asyncio.run(vlp.vc_leave_execute(
                555, LeaveReason.USER_REQUESTED, "unit_test", rec,
                account_id="acc1", call_id=-42))
            self.assertTrue(ok)
            self.assertEqual(rec.fired, 1)
            joined = " | ".join(events)
            self.assertIn("VC_LEAVE_REQUESTED", joined)
            self.assertIn("account_id=acc1", joined)
            self.assertIn("chat_id=555", joined)
            self.assertIn("call_id=-42", joined)
            self.assertIn("reason=USER_REQUESTED", joined)
            self.assertIn("source=unit_test", joined)
            self.assertIn("VC_LEAVE_COMPLETED", joined)
            self.assertIn("reason=USER_REQUESTED", joined)
        finally:
            lg.removeHandler(cap)

    def test_b2_denied_leave_preserves_transport(self):
        lg, cap, events = self._capture()
        try:
            rec = _LeaveRecorder()
            ok = asyncio.run(vlp.vc_leave_execute(
                556, "", "sneaky_caller", rec))
            self.assertFalse(ok)
            self.assertEqual(rec.fired, 0,
                             "a denied leave must NOT fire the factory")
            joined = " | ".join(events)
            self.assertIn("VC_LEAVE_DENIED_UNAUTHORIZED", joined)
            self.assertIn("cause=no_reason", joined)
        finally:
            lg.removeHandler(cap)

    def test_b3_failed_leave_logs_failure(self):
        lg, cap, events = self._capture()
        try:
            rec = _LeaveRecorder()
            rec.error = RuntimeError("leave API exploded")
            ok = asyncio.run(vlp.vc_leave_execute(
                557, LeaveReason.ADMIN_REQUESTED, "unit_test", rec))
            self.assertFalse(ok)
            joined = " | ".join(events)
            self.assertIn("VC_LEAVE_FAILED", joined)
            self.assertIn("error=RuntimeError", joined)
        finally:
            lg.removeHandler(cap)


class TestMandatoryPostJoinPersistence(unittest.TestCase):
    """[MANDATORY] every scenario that must NOT leave an ACTIVE VC.

    These drive the REAL cleanup entry points with the v99.11 policy in
    force and assert the destructive leave NEVER fires for the active
    chat.  The real voicechat module is purged-reloaded per class (the
    established v99.x harness pattern).
    """

    @classmethod
    def setUpClass(cls):
        saved = {k: v for k, v in sys.modules.items()
                 if k == "mediagrab_bot" or k.startswith("mediagrab_bot.")}
        for k in saved:
            del sys.modules[k]
        import mediagrab_bot.voicechat as vw
        cls.vw = vw
        cls.saved = saved
        # A healthy ACTIVE transport for chat A (joined, owner recorded).
        cls.A = -1001111111000

        class _Backend:
            _account_id = "acc_test"

            def __init__(self):
                self.leave_targets = []

            async def _leave_target(self, chat_id):
                self.leave_targets.append(chat_id)
                return "success"

        cls.backend = _Backend()
        vw._vc_active_join_backends_by_chat[cls.A] = cls.backend

        class _Container(dict):
            pass

        # the container HOLDS chat A (the transport is live)
        async def fake_resolve_container(account_id=""):
            return {cls.A: SimpleNamespace(chat_id=cls.A)}

        vw.vc_resolve_calls_container = fake_resolve_container
        # ACTIVE lifecycle mark
        from mediagrab_bot.vc_resources import transport_lifecycle
        transport_lifecycle.mark_allocating(cls.A, "acc_test")
        transport_lifecycle.mark_active(cls.A)

    @classmethod
    def tearDownClass(cls):
        for k in [k for k in sys.modules
                  if k == "mediagrab_bot" or k.startswith("mediagrab_bot.")]:
            sys.modules.pop(k, None)
        sys.modules.update(cls.saved)

    def _leaves_on_A(self):
        return self.A in self.backend.leave_targets

    # [MANDATORY] successful join → temporary verification failure →
    # NO LEAVE  (vc_check_telegram_participation returning unknown for
    # transient errors — the classification feeds vc_verify_target which
    # maps non-absent verdicts to preserve classes).
    def test_m1_temporary_verification_failure_no_leave(self):
        vw = self.vw
        # A transient RPC error inside the participation check returns
        # "unknown" (the v98.00 FIX-E Case B semantics) — assert the
        # classification preserves (the verify marker vocabulary).
        self.assertEqual(
            vw.vc_check_telegram_participation.__name__,
            "vc_check_telegram_participation")
        # Simulate the classification mapping used by the reconcile:
        # tg=unknown (any cause) → cls UNKNOWN → preserve branch.
        # Source-proven: the LEFT branch requires tg == "absent".
        src = Path(vw.__file__).read_text(encoding="utf-8")
        self.assertIn('elif tg == "absent" and not lt:', src)
        # unknown → the preserve branch, no cleanup in it
        preserve_blk = src[src.find('cls = "UNKNOWN"'):src.find(
            'cls = "UNKNOWN"') + 900]
        self.assertNotIn("_vc_cleanup_stale_backend_call", preserve_blk)
        self.assertFalse(self._leaves_on_A())

    # [MANDATORY] NOT_MEMBER / INACCESSIBLE → NO LEAVE + registry kept
    def test_m2_not_member_inaccessible_no_leave(self):
        vw = self.vw
        # the inaccessible verdict maps to the INACCESSIBLE preserve
        # class (own bucket; no LEFT; no registry delete)
        src = Path(vw.__file__).read_text(encoding="utf-8")
        self.assertIn('elif tg == "inaccessible":', src)
        self.assertIn('cls = "INACCESSIBLE"', src)
        inacc_blk = src[src.find('elif tg == "inaccessible":'):
                        src.find('elif tg == "inaccessible":') + 700]
        self.assertNotIn("vc_registry_remove", inacc_blk)
        self.assertNotIn("_vc_cleanup_stale_backend_call", inacc_blk)
        # the backoff registry prevents repeated identical requests
        self.assertIn("_vc_not_member_recheck", src)
        self.assertIn("VC_NOT_MEMBER_RECHECK_SECONDS", src)
        self.assertFalse(self._leaves_on_A())

    # [MANDATORY] STALE_CALL_IDENTITY → redetection → NO LEAVE of the
    # healthy transport
    def test_m3_stale_identity_no_leave(self):
        vw = self.vw
        src = Path(vw.__file__).read_text(encoding="utf-8")
        # the stale-call branch returns unknown + the redetect machinery
        # (vc_verify_target's P1#13 re-detect) reconciles the identity
        stale_blk = src[src.find("VC_PARTICIPATION_STALE_CALL"):
                        src.find("VC_VERIFY_STALE_IDENTITY") + 400]
        self.assertIn("return \"unknown\"", stale_blk)
        self.assertNotIn('"absent"', stale_blk)
        self.assertIn("VC_VERIFY_STALE_IDENTITY", src)
        # verify_target's re-detect refreshes the identity atomically
        self.assertIn("VC_PARTICIPATION_CALL_ID_REFRESH", src)
        self.assertFalse(self._leaves_on_A())

    # [MANDATORY] Join-All processes target N+1 → target N stays ACTIVE
    def test_m4_join_all_next_target_no_leave(self):
        vw = self.vw
        # Source-proven: the worker loop's per-target branch only ever
        # cleans the CURRENT chat's own failed join; successful targets
        # keep their owner-map entries (only leave paths pop them).
        src = Path(vw.__file__).read_text(encoding="utf-8")
        self.assertIn("VC_JOIN_ALL_TARGET_START", src)
        # the leave-block invariant is active during Join-All
        self.assertIn("_vc_join_all_leave_block_active", src)
        # runtime proof: the owner map still holds A + lifecycle ACTIVE
        self.assertIn(self.A, vw._vc_active_join_backends_by_chat)
        from mediagrab_bot.vc_resources import transport_lifecycle
        self.assertEqual(transport_lifecycle.get_state(self.A),
                          "ACTIVE")
        self.assertFalse(self._leaves_on_A())

    # [MANDATORY] resource telemetry / resource guard → NO LEAVE
    def test_m5_resource_telemetry_and_guard_no_leave(self):
        vw = self.vw
        # run the admission check under blocked conditions — it returns
        # a defer decision and NEVER touches the owner map
        vw._vc_resource_state_cache["ts"] = 9999999999.0
        vw._vc_resource_state_cache["data"] = {
            "available": True, "rss_kb": 100 * 1024, "threads": 40,
            "fd_total": 50, "fd_soft": 1024,
            "joined_transports": 99, "active_joins": 0, "queued_joins": 0,
        }
        blocked, why = vw._vc_resource_pressure_check(quiet=True)
        self.assertTrue(blocked)
        self.assertIn(self.A, vw._vc_active_join_backends_by_chat,
                      "pressure must NEVER pop an ACTIVE owner entry")
        self.assertFalse(self._leaves_on_A())
        from mediagrab_bot.vc_resources import transport_lifecycle
        self.assertEqual(transport_lifecycle.get_state(self.A), "ACTIVE")

    # [MANDATORY] SQLite checkpoint / heartbeat / queue idle → NO LEAVE
    def test_m6_checkpoint_heartbeat_queue_idle_no_leave(self):
        vw = self.vw
        # None of these subsystems import or call a leave primitive —
        # source-proven across the three modules.
        for mod_name, needle in (
            ("handlers.py", "vc_leave_all_tracked"),
            ("utils_real.py", "_leave_target"),
            ("db_layer.py", "_leave_target"),
            ("join_all_worker.py", "_leave_target"),
        ):
            path = Path(vw.__file__).parent / mod_name
            if mod_name == "handlers.py":
                # handlers references leave-all only via the documented
                # dashboard/admin entry points (deliberate reasons).
                src = path.read_text(encoding="utf-8")
                self.assertNotIn("_vc_cleanup_stale_backend_call", src)
                self.assertNotIn("backend._leave_target", src)
            else:
                src = path.read_text(encoding="utf-8")
                self.assertNotIn(needle, src,
                                 f"{mod_name} must not touch leaves")
        self.assertFalse(self._leaves_on_A())

    # [MANDATORY] successful join Target A → join Target B → A ACTIVE
    def test_m7_join_b_preserves_a(self):
        vw = self.vw
        B = -1002222222000
        vw._vc_active_join_backends_by_chat[B] = self.backend
        from mediagrab_bot.vc_resources import transport_lifecycle
        transport_lifecycle.mark_allocating(B, "acc_test")
        transport_lifecycle.mark_active(B)
        try:
            self.assertIn(self.A, vw._vc_active_join_backends_by_chat)
            self.assertIn(B, vw._vc_active_join_backends_by_chat)
            # the snapshot evidence gate: registry=unknown + container
            # present must NOT run destructive recovery (the v99.11
            # weak-evidence branch) — proven by the policy itself:
            ok, cause = vlp.vc_leave_authorize(
                LeaveReason.STALE_CONTAINER_VERIFIED_ABSENT,
                "join_all_snapshot", self.A)
            self.assertFalse(ok)
            self.assertEqual(cause, "validated_reason_requires_evidence")
            # with the join-all block active (the snapshot's real
            # context), even evidence-carrying automatic reasons deny
            vw._vc_join_all_leave_block_active = True
            try:
                ok2, cause2 = vlp.vc_leave_authorize(
                    LeaveReason.STALE_CONTAINER_VERIFIED_ABSENT,
                    "join_all_snapshot", self.A,
                    evidence="registry=unknown — NO, that is weak")
                self.assertFalse(ok2)
                self.assertEqual(cause2, "blocked_during_join_all")
            finally:
                vw._vc_join_all_leave_block_active = False
            self.assertFalse(self._leaves_on_A())
        finally:
            vw._vc_active_join_backends_by_chat.pop(B, None)

    # [MANDATORY] NEW JOIN FAILS → cleanup partial transport → existing
    # ACTIVE transports untouched
    def test_m8_failed_new_join_cleans_only_its_own_target(self):
        from mediagrab_bot import vc_pipeline
        vw = self.vw
        C = -1003333333000  # the failing join's own target
        vw._vc_active_join_backends_by_chat[C] = self.backend
        try:
            asyncio.run(vc_pipeline._cleanup_local_call(
                self.backend, C,
                reason_code=LeaveReason.FAILED_JOIN_CLEANUP,
                evidence="telegram_absent for the join's own target"))
            self.assertIn(C, self.backend.leave_targets,
                          "the FAILED join's own transport is released")
            self.assertFalse(self._leaves_on_A(),
                             "the ACTIVE transport A must be untouched")
            from mediagrab_bot.vc_resources import transport_lifecycle
            self.assertEqual(transport_lifecycle.get_state(self.A),
                             "ACTIVE")
            self.assertEqual(transport_lifecycle.get_state(C), "RELEASED")
            # the owner map popped ONLY for C
            self.assertIn(self.A, vw._vc_active_join_backends_by_chat)
            self.assertNotIn(C, vw._vc_active_join_backends_by_chat)
        finally:
            vw._vc_active_join_backends_by_chat.pop(C, None)

    # [MANDATORY] ACTIVE JOIN EXISTS → unrelated join fails → ACTIVE
    # remains active (the pipeline cleanup only receives its own chat)
    def test_m9_unrelated_failure_preserves_active(self):
        from mediagrab_bot import vc_pipeline
        vw = self.vw
        D = -1004444444000
        vw._vc_active_join_backends_by_chat[D] = self.backend
        try:
            asyncio.run(vc_pipeline._cleanup_local_call(
                self.backend, D, reason_code=LeaveReason.FAILED_JOIN_CLEANUP))
            self.assertFalse(self._leaves_on_A())
            from mediagrab_bot.vc_resources import transport_lifecycle
            self.assertEqual(transport_lifecycle.get_state(self.A), "ACTIVE")
        finally:
            vw._vc_active_join_backends_by_chat.pop(D, None)

    # [MANDATORY] the full chain: join A+B → reconcile-classification of
    # every NON-absent verdict → verification → resource guard →
    # checkpoint → stale identity → pause/resume → A remains ACTIVE
    def test_m10_full_chain_a_remains_active(self):
        vw = self.vw
        # (a) reconciliation classifications for non-absent verdicts
        # never reach the LEFT branch (source-proven decision table)
        src = Path(vw.__file__).read_text(encoding="utf-8")
        for verdict in ('tg == "present"', 'tg == "inaccessible"'):
            self.assertIn(verdict, src)
        # the LEFT branch's cleanup call carries the explicit reason
        # code + evidence (find the call site, verify its argument block)
        call_idx = src.find(
            'await _vc_cleanup_stale_backend_call(\n                    rec.chat_id,\n                    reason="participation_reconcile_absent"')
        self.assertGreater(call_idx, 0,
                           "the reconcile LEFT cleanup call must exist")
        call_blk = src[call_idx:call_idx + 900]
        self.assertIn('reason_code="RECONCILE_CONFIRMED_ABSENT"', call_blk)
        self.assertIn("3-streak", call_blk)
        # (b) verification failure paths return unknown/inaccessible —
        # both flow to preserve classes (m1/m2 proofs)
        # (c) resource guard blocked → defer only (m5 proof)
        # (d) checkpoint → save_checkpoint only writes the run row
        wsrc = (Path(vw.__file__).parent
                / "join_all_worker.py").read_text(encoding="utf-8")
        self.assertIn("save_checkpoint", wsrc)
        self.assertNotIn("_leave_target", wsrc)
        # (e) stale identity → redetect + refresh (m3 proof)
        # (f) pause/resume → the checkpoint resume path preserves
        # already-joined VCs (join-all state machine; successful targets
        # stay in the registry + owner map)
        self.assertIn(self.A, vw._vc_active_join_backends_by_chat)
        # (g) the leave audit's crown assertion: nothing left A through
        # the ENTIRE chain above
        self.assertFalse(self._leaves_on_A(),
                          "THE INVARIANT: successful join remains ACTIVE")
        from mediagrab_bot.vc_resources import transport_lifecycle
        self.assertEqual(transport_lifecycle.get_state(self.A), "ACTIVE")


class TestLegitimateExplicitLeaves(unittest.TestCase):
    """The explicit leave paths still work (deliberate reasons)."""

    def test_e1_deliberate_reasons_fire_the_leave(self):
        for reason in (LeaveReason.USER_REQUESTED,
                       LeaveReason.ADMIN_REQUESTED,
                       LeaveReason.TARGET_REMOVED,
                       LeaveReason.EXPLICIT_STOP,
                       LeaveReason.SHUTDOWN):
            rec = _LeaveRecorder()
            ok = asyncio.run(vlp.vc_leave_execute(
                777, reason, "unit_test", rec))
            self.assertTrue(ok, f"{reason} must execute")
            self.assertEqual(rec.fired, 1)

    def test_e2_reconcile_confirmed_absent_with_evidence(self):
        """The validated ghost-cleanup path: 3-streak authoritative
        absence evidence authorizes the container cleanup."""
        rec = _LeaveRecorder()
        ok = asyncio.run(vlp.vc_leave_execute(
            778, LeaveReason.RECONCILE_CONFIRMED_ABSENT,
            "vc_reconcile_participations", rec,
            evidence="telegram_absent+locally_untracked; 3-streak "
                     "targeted-query negative, stable call_id"))
        self.assertTrue(ok)
        self.assertEqual(rec.fired, 1)

    def test_e3_shutdown_leave_all_still_works(self):
        """vc_leave_all_tracked → vc_leave_target chain: the deliberate
        shutdown/admin sweep executes per-VC leaves with reason codes
        (source-proven; runtime-verified via the policy unit above)."""
        src = (Path(__file__).resolve().parents[1] / "mediagrab_bot"
               / "voicechat.py").read_text(encoding="utf-8")
        self.assertIn("async def vc_leave_all_tracked", src)
        self.assertIn("vc_leave_target(", src)
        self.assertIn('reason_code: str = "USER_REQUESTED"', src)


class TestLeavePathSourceAudit(unittest.TestCase):
    """Every destructive site in the final source is reason-coded."""

    def test_p1_cleanup_helper_routes_through_policy(self):
        src = (Path(__file__).resolve().parents[1] / "mediagrab_bot"
               / "voicechat.py").read_text(encoding="utf-8")
        idx = src.find("async def _vc_cleanup_stale_backend_call")
        body = src[idx:idx + 16000]
        self.assertIn("vc_leave_execute(", body,
                      "the cleanup's destructive call routes through the "
                      "leave-policy chokepoint")
        self.assertIn("reason_code", body)

    def test_p2_no_direct_leave_call_outside_authorized_sites(self):
        """`backend._leave_target(` appears ONLY at the policy-gated
        sites (the policy factory + the pipeline's own failed-join
        factory + vc_leave_target's verified orchestrator + the internal
        _leave_target implementation)."""
        root = Path(__file__).resolve().parents[1] / "mediagrab_bot"
        for py in root.glob("*.py"):
            src = py.read_text(encoding="utf-8")
            if "_leave_target" not in src:
                continue
            # allowed definition/call sites
            allowed = (
                "async def _leave_target(",      # the backend method itself
                "backend._leave_target(chat_id)",   # policy factory (cleanup)
                "backend._leave_target(marked_chat)",  # pipeline factory
            )
            import re
            for m in re.finditer(r"\._leave_target\(", src):
                start = max(0, m.start() - 60)
                ctx = src[start:m.end() + 20]
                if "async def" in ctx:
                    continue
                self.assertTrue(
                    any(a in src for a in allowed),
                    f"unexpected _leave_target call context in {py.name}")

    def test_p3_every_leave_reason_is_a_known_code(self):
        codes = {getattr(LeaveReason, a) for a in dir(LeaveReason)
                 if not a.startswith("_")}
        self.assertEqual(vlp.ALL_KNOWN_REASONS, frozenset(codes) | {
            LeaveReason.RESOURCE_EMERGENCY})
        self.assertIn("RECONCILE_CONFIRMED_ABSENT", codes)
        self.assertIn("FAILED_JOIN_CLEANUP", codes)
        self.assertIn("SHUTDOWN", codes)


if __name__ == "__main__":
    unittest.main()
