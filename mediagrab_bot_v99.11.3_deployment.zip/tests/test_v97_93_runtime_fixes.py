"""v97.93 — Cluster client health monitoring + orphaned task observability.

This version captures the output of an INDEPENDENT deep forensic audit of
the MediaGrab Bot v97.92 runtime logs (bot-diagnostic (5).log +
bot (6).log). The v97.92 deployment was RUNTIME-PROVEN deployed (all 7
source SHA256 hashes match the deployment ZIP). The audit re-verified
all 13 v97.92 fixes PASSED, then identified two SOURCE-PROVEN gaps that
amplified (but did NOT directly cause) the cascade:

  CASCADE SUMMARY (RUNTIME-PROVEN from bot-diagnostic (5).log):
    01:22:38 PRIMARY recv_loop sees [Errno 103] (first server-side disconnect)
    01:22:39 watchdog fires → bot's _mtproto_safe_reconnect gen=1 (FAILS)
    01:25:25 gen=2 SUCCESS — primary reconnected
    01:25:37 first EVENT_LOOP_LAG_MODERATE (2.16s) — lag INCREASES over 80s
    01:26:45 first EVENT_LOOP_LAG_CRITICAL (11.32s)
    01:28:01 watchdog fires AGAIN → gen=3 created, gen=2 RETIRING
    01:28:15 gen=3 SUCCESS → ~80s later, watchdog fires again → gen=4
    ... cycle repeats 10 times until 01:38:09 (gen=10)

    01:37:17 TASK_DUMP total_tasks=469, telethon_dispatch_update=439
           (all 439 at the SAME stack: _dispatch_update() [await callback(event)])

  GAP-1 (SOURCE-PROVEN):
    During the PRIMARY's reconnect storm, the CLUSTER client
    (@Official_Ishitaa / acc_919006065076) silently disconnected.
    Evidence: TELETHON_BACKGROUND_OK telethon_background_tasks dropped
    from 12 (expected for 2 clients) → 7 → 6 with NO
    MTPROTO_CLUSTER_DISCONNECT_DETECTED event ever logged. The cluster
    client's _update_loop (Task-52) survived in `cancelling=1` state for
    40+ minutes (visible in dumps from 00:47:41 to 01:27:48) — orphaned.
    The v97.92 health loop ONLY checked the PRIMARY ``_mtproto_client``;
    cluster clients in ``UserbotCluster._clients`` had NO health
    monitoring. When their recv_loops died, the cluster reconnect loop
    (which only retries STATUS_CONNECTION_FAILED accounts) didn't see
    them as failed (their status was still STATUS_CONNECTED/STATUS_HEALTHY).
    They stayed silently dead.

  GAP-2 (SOURCE-PROVEN):
    The v97.92 ``_forcibly_cancel_telethon_tasks`` relied on the snapshot
    stored on ``client._mediagrab_bg_tasks``. But Telethon's
    ``client.disconnect()`` can DROP the reference to the old
    background-task attributes (e.g., ``_updates_handle = None``) before
    the cancel propagates. The orphaned task is then INVISIBLE to the
    next snapshot (which iterates via attribute names). Every forced-cancel
    reported ``MTPROTO_FORCED_CANCEL_NONE_FOUND — all 6 snapshotted tasks
    already done (client-specific)`` while Task-52 was actually alive in
    ``cancelling=1`` state.

  PRIMARY ROOT CAUSE (UNPROVEN — requires additional evidence):
    WHY the connection drops every ~80s after the first disconnect.
    Hypotheses: (a) Telethon's keepalive_loop times out (60s interval)
    due to event-loop starvation, triggering internal _reconnect;
    (b) Telegram actively rate-limiting or rejecting the session after
    too many reconnects in a short window;
    (c) The bot's reconnect doesn't fully establish a healthy MTProto
    session (auth handshake incomplete).
    To distinguish: need Telethon DEBUG logs (mtprotosender.py:_reconnect +
    _keepalive_loop) — currently suppressed by F3 (set to WARNING level).

v97.93 implements TWO minimal fixes — both with RUNTIME-PROVEN evidence:

  G1. ``_check_cluster_clients_health()`` (helper called from
      ``_mtproto_health_loop`` every 30s): iterates ``UserbotCluster
      ._clients``. For each cluster client whose status is HEALTHY/
      CONNECTED but whose ``client.is_connected()`` returns False, emits
      ``MTPROTO_CLUSTER_DISCONNECT_DETECTED`` AND transitions the account
      to STATUS_CONNECTION_FAILED. The EXISTING ``_cluster_reconnect_loop``
      (60s, exponential backoff) then automatically retries
      ``connect_account()`` on the next iteration. No new background task;
      no behavioral change to the reconnect path itself — just
      observability + status transition that triggers existing reconnect
      infrastructure for cluster accounts.

  G2. ``_log_orphaned_telethon_tasks(client, snapshot, label)`` (helper
      called from ``_forcibly_cancel_telethon_tasks`` after the snapshot
      cancel+verify): scans ``asyncio.all_tasks(loop)`` for any Telethon
      bg task (by coroutine qualname) that is alive but NOT in this
      client's snapshot. Emits ``MTPROTO_ORPHAN_TELETHON_TASKS_DETECTED``
      with owner classification (this_client vs other_client) and
      ``cancelling=N`` state. Pure observability — does NOT cancel
      anything (asyncio cannot kill a stuck cancelling=1 task anyway).

The PRIMARY root cause (connection drops every ~80s) is NOT fixed in
v97.93 — there is INSUFFICIENT EVIDENCE to identify the exact trigger.
The next deployment with v97.93's improved observability (which captures
cluster disconnects + orphaned task leaks) will narrow the next
investigation. Enabling ``telethon.network`` DEBUG logging temporarily
would prove whether keepalive timeouts are firing.

Acceptance standard:
- SOURCE:           PASS (both fixes implemented + verified by source-text tests)
- STATIC:           PASS (py_compile + import checks + all 705 existing tests pass)
- TESTS:            PASS (705 existing + new v97.93 tests, all pass)
- RUNTIME EVIDENCE: UNPROVEN (cannot deploy in this environment)
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_UTILS = os.path.join(_BASE, "mediagrab_bot", "utils_real.py")
_BOOTSTRAP = os.path.join(_BASE, "mediagrab_bot", "bootstrap.py")
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_HANDLERS = os.path.join(_BASE, "mediagrab_bot", "handlers.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


def _read(path: str) -> str:
    with open(path, encoding="utf-8") as f:
        return f.read()


# =========================================================================
# Version bump (v97.92 → v97.93)
# =========================================================================

class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_93(self):
        src = _read(_INIT)
        self.assertIn('__bot_version__ = "v99.11.3"', src)

    def test_deployment_identity_version(self):
        src = _read(_BOOTSTRAP)
        self.assertIn("version={_v9812_pkg_version}", src)  # v99: derivation site (v98.12 correction)


# =========================================================================
# G1: cluster client health monitoring
# =========================================================================

class TestClusterHealthMonitoring(unittest.TestCase):
    """G1: _mtproto_health_loop must ALSO check cluster clients' connection
    state. The v97.92 loop only watched the PRIMARY client; cluster clients
    silently died without anyone noticing (proven by telethon_background
    dropping 12→6 in bot-diagnostic (5).log with no MTPROTO_CLUSTER_DISCONNECT_DETECTED)."""

    def test_check_cluster_clients_health_helper_defined(self):
        src = _read(_MTPROTO)
        idx = src.find("async def _check_cluster_clients_health")
        self.assertGreater(idx, 0, "_check_cluster_clients_health helper not defined")

    def test_health_loop_calls_cluster_check(self):
        src = _read(_MTPROTO)
        idx = src.find("async def _mtproto_health_loop")
        # Health loop body should call the cluster health check helper.
        body = src[idx:idx + 4000]
        self.assertIn("_check_cluster_clients_health()", body,
                      "health loop must call _check_cluster_clients_health() every cycle")

    def test_cluster_disconnect_marker_emitted(self):
        src = _read(_MTPROTO)
        self.assertIn("MTPROTO_CLUSTER_DISCONNECT_DETECTED", src,
                      "cluster disconnect must emit MTPROTO_CLUSTER_DISCONNECT_DETECTED log marker")

    def test_cluster_status_transition_to_connection_failed(self):
        src = _read(_MTPROTO)
        # When is_connected() returns False on a healthy-status cluster
        # client, the helper must transition the account to
        # STATUS_CONNECTION_FAILED so _cluster_reconnect_loop will retry.
        idx = src.find("async def _check_cluster_clients_health")
        body = src[idx:idx + 4000]
        self.assertIn("STATUS_CONNECTION_FAILED", body,
                      "cluster health check must transition to STATUS_CONNECTION_FAILED on disconnect")
        self.assertIn("cluster.update_status", body,
                       "cluster health check must call cluster.update_status to trigger reconnect loop")

    def test_cluster_check_skips_non_healthy_accounts(self):
        """Don't disturb accounts that are already in a non-healthy state
        (those are handled by _cluster_reconnect_loop)."""
        src = _read(_MTPROTO)
        idx = src.find("async def _check_cluster_clients_health")
        body = src[idx:idx + 4000]
        self.assertIn("STATUS_HEALTHY", body)
        self.assertIn("STATUS_CONNECTED", body)
        # The check must EXPLICITLY skip non-healthy accounts.
        self.assertIn("if st not in (STATUS_HEALTHY, STATUS_CONNECTED)", body)

    def test_cluster_check_skips_global_mtproto_client(self):
        """The global _mtproto_client is checked separately by the primary
        health check; cluster check must skip it to avoid double-evaluation."""
        src = _read(_MTPROTO)
        idx = src.find("async def _check_cluster_clients_health")
        body = src[idx:idx + 4000]
        self.assertIn("if client is _mtproto_client", body,
                      "cluster check must skip the global _mtproto_client (it's checked separately)")

    def test_cluster_check_uses_is_connected(self):
        """The check must use client.is_connected() — Telethon's authoritative
        liveness probe — rather than relying on get_me() (which can trip
        FloodWait during flapping)."""
        src = _read(_MTPROTO)
        idx = src.find("async def _check_cluster_clients_health")
        body = src[idx:idx + 4000]
        self.assertIn("client.is_connected()", body)


# =========================================================================
# G2: orphaned Telethon task observability
# =========================================================================

class TestOrphanedTaskObservability(unittest.TestCase):
    """G2: _forcibly_cancel_telethon_tasks must surface orphaned Telethon bg
    tasks that are alive but NOT in this client's snapshot. The v97.92
    forced-cancel silently missed Task-52 (cluster client's _update_loop
    stuck in cancelling=1 for 40+ minutes) because the snapshot didn't
    include it."""

    def test_log_orphaned_telethon_tasks_helper_defined(self):
        src = _read(_MTPROTO)
        idx = src.find("async def _log_orphaned_telethon_tasks")
        self.assertGreater(idx, 0, "_log_orphaned_telethon_tasks helper not defined")

    def test_forced_cancel_calls_orphan_scan(self):
        src = _read(_MTPROTO)
        idx = src.find("async def _forcibly_cancel_telethon_tasks(")
        # Find the end of the primary function (next top-level def).
        end = src.find("\nasync def ", idx + 10)
        end2 = src.find("\ndef ", idx + 10)
        primary_end = min(end, end2) if end > 0 and end2 > 0 else (end if end > 0 else end2)
        primary_body = src[idx:primary_end]
        self.assertIn("_log_orphaned_telethon_tasks(client, snapshot, label)",
                      primary_body,
                      "primary forced-cancel must call _log_orphaned_telethon_tasks")

    def test_orphan_marker_emitted(self):
        src = _read(_MTPROTO)
        self.assertIn("MTPROTO_ORPHAN_TELETHON_TASKS_DETECTED", src,
                      "orphan scan must emit MTPROTO_ORPHAN_TELETHON_TASKS_DETECTED log marker")

    def test_orphan_scan_filters_by_telethon_bg_coro_qualname(self):
        src = _read(_MTPROTO)
        idx = src.find("async def _log_orphaned_telethon_tasks")
        body = src[idx:idx + 4000]
        # Must filter to Telethon bg tasks only (not arbitrary asyncio tasks).
        self.assertIn("_update_loop", body)
        self.assertIn("_keepalive_loop", body)
        self.assertIn("_send_loop", body)
        self.assertIn("_recv_loop", body)

    def test_orphan_scan_classifies_owner(self):
        """Orphan scan must distinguish 'this_client' vs 'other_client' so
        operators can tell whether the orphan belongs to the reconnecting
        client or to a different (cluster) client."""
        src = _read(_MTPROTO)
        idx = src.find("async def _log_orphaned_telethon_tasks")
        body = src[idx:idx + 5000]
        self.assertIn("cr_frame", body,
                      "must inspect cr_frame.f_locals to classify owner")
        self.assertIn("this_client", body)
        self.assertIn("other_client", body)

    def test_orphan_scan_reports_cancelling_state(self):
        """Orphan scan must report the _cancelling counter so operators can
        see whether the orphan is mid-cancellation (stuck) vs alive+active."""
        src = _read(_MTPROTO)
        idx = src.find("async def _log_orphaned_telethon_tasks")
        body = src[idx:idx + 5000]
        self.assertIn("_cancelling", body,
                      "must report task._cancelling state to distinguish stuck cancelling=1 tasks")

    def test_orphan_scan_is_observability_only(self):
        """The orphan scan must NOT cancel anything — it is pure observability.
        asyncio cannot safely kill a stuck cancelling=1 task, and we cannot
        reliably determine which client an arbitrary Telethon bg task
        belongs to without risk of cancelling another client's healthy tasks."""
        src = _read(_MTPROTO)
        idx = src.find("async def _log_orphaned_telethon_tasks")
        # Find the end of the helper function.
        end = src.find("\nasync def ", idx + 10)
        end2 = src.find("\ndef ", idx + 10)
        helper_end = min(end, end2) if end > 0 and end2 > 0 else (end if end > 0 else end2)
        helper_body = src[idx:helper_end]
        # Must NOT contain task.cancel() — the orphan scan must be observability-only.
        self.assertNotIn("task.cancel", helper_body,
                         "orphan scan must NOT cancel tasks (observability-only)")
        self.assertNotIn("t.cancel", helper_body,
                         "orphan scan must NOT cancel tasks (observability-only)")

    def test_primary_forced_cancel_preserves_v97_79_no_all_tasks_invariant(self):
        """The v97.79 invariant: the PRIMARY _forcibly_cancel_telethon_tasks
        body must NOT contain asyncio.all_tasks() — the primary path is
        CLIENT-SPECIFIC, never global. The orphan scan must be in a
        SEPARATE helper (not in the primary function body)."""
        src = _read(_MTPROTO)
        idx = src.find("async def _forcibly_cancel_telethon_tasks(")
        # Find the next top-level def (which should be the global fallback).
        end = src.find("async def _forcibly_cancel_telethon_tasks_global", idx)
        primary_body = src[idx:end]
        self.assertNotIn("asyncio.all_tasks(loop)", primary_body,
                         "primary forced-cancel must NOT contain asyncio.all_tasks (v97.79 invariant) — "
                         "orphan scan must be in a separate helper")


# =========================================================================
# Preserved v97.92 fixes (must NOT regress)
# =========================================================================

class TestPreservedV97_92Fixes(unittest.TestCase):
    """All 13 v97.92 fixes must remain in place after the v97.93 audit-driven
    source change. The v97.93 changes are ADDITIVE observability/health — they
    do NOT alter or weaken any v97.92 fix."""

    def test_prewrap_weakset_primary(self):
        src = _read(_VOICECHAT)
        self.assertIn("_PREWRAPPED_CLIENTS_WEAK", src)

    def test_health_loop_triggers_reconnect(self):
        src = _read(_MTPROTO)
        # v99.07 (documented correction): window 3000 -> 3600 — the FIX-12
        # worker-heartbeat block at the loop head shifted the markers down.
        idx = src.find("async def _mtproto_health_loop")
        body = src[idx:idx + 3600]
        self.assertIn("_mtproto_trigger_reconnect()", body)
        self.assertIn("MTPROTO_HEALTH_DISCONNECT_DETECTED", body)

    def test_watchdog_10s_interval(self):
        src = _read(_MTPROTO)
        idx = src.find("async def _mtproto_watchdog_loop")
        # v99.07 (documented correction): window 3000 -> 3600 — the FIX-12
        # worker-heartbeat block at the loop head shifted the markers down.
        body = src[idx:idx + 3600]
        # v98.12 TEST-MECHANISM CORRECTION (documented): the literal pin
        # "asyncio.sleep(10)" was updated for the v98.12 §11 adaptive
        # cadence (`_v9812_wd_interval = 30.0 if streak >= 6 else 10.0` —
        # first-detection latency stays 10s; sustained-outage polling widens
        # to 30s). The invariant this test guards (FAST first detection) is
        # unchanged — the `else 10.0` arm IS the 10s interval.
        self.assertIn("else 10.0", body)
        self.assertIn("MTPROTO_WATCHDOG_DISCONNECT_DETECTED", body)

    def test_deployment_identity_7_hashes(self):
        src = _read(_BOOTSTRAP)
        for h in ("voicechat_sha256", "utils_real_sha256", "config_sha256",
                  "mtproto_sha256", "bootstrap_sha256", "handlers_sha256",
                  "join_all_worker_sha256"):
            self.assertIn(h, src, f"DEPLOYMENT_IDENTITY must include {h}")

    def test_reconciler_markers_distinguished(self):
        src = _read(_VOICECHAT)
        self.assertIn("VC_MOD_RECONCILE_", src)
        self.assertIn("VC_COVERAGE_RECONCILE_", src)


if __name__ == "__main__":
    unittest.main()
