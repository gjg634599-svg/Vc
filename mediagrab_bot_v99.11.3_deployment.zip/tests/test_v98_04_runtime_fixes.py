"""v98.04 runtime fixes — regression tests for the auto-leave +
never-rejoin bug + discovery PeerUser pollution.

CRITICAL USER-REPORTED BUG (bot-diagnostic (17).log):
  After Join All Active VC, VCs successfully join, but after a few
  minutes some/all VCs automatically leave. When Join All is clicked
  again, the bot incorrectly skips them as 'already joined', so they
  are never rejoined.

ROOT CAUSES (all RUNTIME-PROVEN in (17).log, traced to exact source lines):
  FIX-X: _leave_target passed the RAW form to PyTgCalls' leave API, but
         PyTgCalls 2.3.3 stores calls under the MARKED form (-100...).
         leave_call(raw_positive_id) is a SILENT NO-OP — no exception,
         no removal. Returns "success" falsely. The container object
         PERSISTS. Next Join-All snapshot sees the stale object and marks
         ALREADY_JOINED, overwriting the reconcile's correct LEFT detection.
         Timeline (chat 1922822605):
           03:38:21 VC_JOIN_SUCCESS (raw 1922822605, marked -1001922822605)
           03:47:31 reconcile detected absence → _vc_cleanup_stale_backend_call
                   → _leave_target(1922822605) → leave_call(1922822605) = NO-OP
                   → returned "success" (FALSE) → container STILL has -1001922822605
           03:48:17 snapshot _backend_connected=True → ALREADY_JOINED
                   → synced registry LEFT→JOINED → user sees "already joined"
                   but bot NOT in VC.
  FIX-Y: snapshot's _backend_connected check trusted the container object's
         existence as proof of participation. But container objects PERSIST
         after passive removal (PyTgCalls 2.3.3 fires no reliable stream-end
         callback, FIX-W documented limitation). Trusting it when registry=left
         overwrites the correct reconcile detection.
  FIX-Z: verify_joined returns True from container presence alone even when
         registry=left (proven absent). Defense-in-depth — complements FIX-X/Y.
  FIX-AA: discovery stored User entities (PeerUser) as group_ids in vc_groups.
         4 storage sites: Stage 1 (ResolveUsernameRequest.users), Stage 2
         (invite link → User), Stage 3-6 (SearchGlobalRequest.users), Source B
         (explicit targets → User). 346 PeerUser skip events per Join-All cycle.
  FIX-BB: snapshot's get_entity retries PeerUser IDs 2x + 0.5s pacing + dead-
          letter counter. ~5 minutes of pure waste per Join-All cycle with
          60+ bad IDs. Fix: detect PeerUser errors, immediately mark + delete
          from vc_groups. Same-session fast-skip via in-memory set.

EVIDENCE CLASSIFICATION:
  * RUNTIME-PROVEN: traced to actual (17).log events with timestamps + chat IDs
  * SOURCE-PROVEN: verified in source code (string/pattern assertions)
  * TEST-PROVEN: this test file
  * NOT PROVEN: marked explicitly (no fabrication)
"""

from __future__ import annotations

import ast
import inspect
import os
import unittest

# Resolve the source path relative to the deployed package layout.
_HERE = os.path.dirname(os.path.abspath(__file__))
_SRC_DIR = os.path.join(os.path.dirname(_HERE), "mediagrab_bot")
_VOICECHAT = os.path.join(_SRC_DIR, "voicechat.py")
_DB_LAYER = os.path.join(_SRC_DIR, "db_layer.py")
_INIT = os.path.join(_SRC_DIR, "__init__.py")
_BOOTSTRAP = os.path.join(_SRC_DIR, "bootstrap.py")


def _read(path: str) -> str:
    with open(path, encoding="utf-8") as f:
        return f.read()


class TestVC804VersionBump(unittest.TestCase):
    """§1 — version bump v98.03 → v98.04."""

    def setUp(self):
        self.init_src = _read(_INIT)
        self.boot_src = _read(_BOOTSTRAP)

    def test_init_bot_version_is_v98_04(self):
        self.assertIn('__bot_version__ = "v99.11.3"', self.init_src)

    def test_bootstrap_deployment_identity_is_v98_04(self):
        self.assertIn('version={_v9812_pkg_version}', self.boot_src)  # v99: derivation site


class TestVC804FixXLeaveTargetBothIdForms(unittest.TestCase):
    """§2 — FIX-X: _leave_target must try BOTH ID forms + verify container clean.

    ROOT CAUSE (RUNTIME-PROVEN via (17).log chat 1922822605):
      _leave_target(1922822605) called self._pytgcalls.leave_call(1922822605)
      but PyTgCalls stores calls under -1001922822605 (marked form). The leave
      was a SILENT NO-OP (no exception, no removal). Returned "success" falsely.
      Container object PERSISTED → next Join-All snapshot marked ALREADY_JOINED
      → synced registry LEFT→JOINED → user's "auto-leave + never-rejoin" bug.
    """

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_fix_x_docstring_present(self):
        """The FIX-X docstring must document the runtime proof + root cause."""
        idx = self.src.find("async def _leave_target")
        self.assertGreater(idx, -1, "_leave_target must exist")
        window = self.src[idx:idx + 6000]
        self.assertIn("v98.04 FIX-X", window)
        self.assertIn("BUG-VC-LEAVE-TARGET-ID-FORM", window)
        self.assertIn("RUNTIME-PROVEN via", window)
        self.assertIn("1922822605", window)

    def test_fix_x_computes_both_id_forms(self):
        """_leave_target must compute BOTH raw + marked forms to try."""
        idx = self.src.find("async def _leave_target")
        self.assertGreater(idx, -1)
        window = self.src[idx:idx + 6000]
        # Must compute the marked form from raw positive (and vice versa).
        self.assertIn("-1000000000000 - chat_id", window)
        self.assertIn("abs(chat_id) % 1000000000000", window)
        # Must build a _forms list with both.
        self.assertIn("_forms", window)

    def test_fix_x_tries_each_form_in_loop(self):
        """_leave_target must iterate over _forms and call the leave API for each."""
        idx = self.src.find("async def _leave_target")
        self.assertGreater(idx, -1)
        # v98.09 PATCH-2: window 6000→6800 (the §10-instrumented dispatch
        # lines are longer; see the note in test_fix_x_preserves_leave_strategies).
        window = self.src[idx:idx + 6800]
        self.assertIn("for _form in _forms", window)
        # All four strategies must be dispatched with _form.
        # v98.09 PATCH-2 §10 (evidence-documented mechanism update, NOT a
        # weakening): the dispatch is now instrumented — each strategy
        # routes through _v9809_leave_api(self, "<api>", _form), which
        # resolves getattr(self._pytgcalls, "<api>") and calls it with
        # _form. The both-forms dispatch is additionally proven
        # BEHAVIORALLY by tests/test_v98_09_leave_regression.py Case A
        # (raw+marked both hit the pytgcalls instance) and Case B.
        self.assertIn('_v9809_leave_api(self, "leave_group_call", _form)', window)
        self.assertIn('_v9809_leave_api(self, "leave_call", _form)', window)
        self.assertIn('_v9809_leave_api(self, "stop_call", _form)', window)
        # The instrumented helper must actually reach self._pytgcalls:
        helper_idx = self.src.find('async def _v9809_leave_api(')
        self.assertGreater(helper_idx, -1,
                           "_v9809_leave_api helper must exist")
        helper_window = self.src[helper_idx:helper_idx + 2500]
        self.assertIn("_pytg = getattr(backend, \"_pytgcalls\", None)",
                      helper_window)
        self.assertIn("_fn = getattr(_pytg, api, None)", helper_window)
        self.assertIn("await _fn(form)", helper_window)

    def test_fix_x_verifies_container_clean_after_leave(self):
        """_leave_target must verify the container no longer has the chat."""
        idx = self.src.find("VC_LEAVE_TARGET_NOOP")
        self.assertGreater(idx, -1, "VC_LEAVE_TARGET_NOOP marker must exist")
        # Look in a window around this marker.
        window = self.src[max(0, idx - 2000):idx + 1000]
        self.assertIn("vc_resolve_calls_container", window)
        self.assertIn("_extract_chat_ids_from_container", window)
        self.assertIn("_still_present", window)
        # If still present, must return "failed" (truthful, not false-success).
        self.assertIn('return "failed"', window)

    def test_fix_x_leave_current_call_only_one_form(self):
        """For leave_current_call (no chat_id arg), only one call is needed."""
        idx = self.src.find("async def _leave_target")
        self.assertGreater(idx, -1)
        window = self.src[idx:idx + 6000]
        self.assertIn('if self._leave_strategy == "leave_current_call"', window)

    def test_fix_x_preserves_leave_strategies(self):
        """All four leave strategies must still be dispatched."""
        idx = self.src.find("async def _leave_target")
        self.assertGreater(idx, -1)
        # v98.09 PATCH-2: window 6000→6800 — the four §10-instrumented
        # dispatch lines are ~35 chars longer each, which pushed the last
        # strategy literal past the old boundary. Same assertions; the
        # strategies themselves are unchanged (dispatch still keyed on
        # self._leave_strategy for all four).
        window = self.src[idx:idx + 6800]
        self.assertIn('"leave_group_call"', window)
        self.assertIn('"leave_call"', window)
        self.assertIn('"leave_current_call"', window)
        self.assertIn('"stop_call"', window)


class TestVC804FixYSnapshotLeftToJoinedGuard(unittest.TestCase):
    """§3 — FIX-Y: snapshot must NOT trust container when registry=left.

    ROOT CAUSE (RUNTIME-PROVEN via (17).log):
      03:47:31 reconcile marked registry=left (proven absent via GetParticipants
      scan, 91 inspected, complete=yes).
      03:48:17 snapshot's _backend_connected check found the stale container
      object → marked ALREADY_JOINED → synced registry LEFT→JOINED →
      user's "auto-leave + never-rejoin" bug.
    """

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_fix_y_registry_left_check_in_snapshot(self):
        """The snapshot's _backend_connected branch must check registry=left.

        v98.05 FIX-DD EXTENDS this guard to also cover registry=unknown and
        registry=recovery_pending (closing the UNKNOWN->ALREADY_JOINED gap
        proven in (18).log). The original v98.04 FIX-Y safety property
        (registry=left is checked) must STILL be present.
        """
        # The snapshot branch is uniquely identified by the BUG marker.
        bug_idx = self.src.find("BUG-VC-SNAPSHOT-LEFT-TO-JOINED")
        self.assertGreater(bug_idx, -1, "snapshot BUG marker must exist")
        # The v98.04 FIX-Y comment must still annotate the snapshot branch.
        self.assertIn("v98.04 FIX-Y", self.src)
        # The registry=left check must exist (v98.05 uses a ternary covering
        # left/unknown/recovery_pending; the "left" branch is preserved).
        self.assertIn('_registry_state_for_skip == "left"', self.src)
        # The snapshot's outer guard (`if _backend_connected:`) opens the
        # branch; the BUG marker sits in the comment block INSIDE it, so the
        # guard appears BEFORE the marker. Look backward.
        window = self.src[max(0, bug_idx - 3000):bug_idx + 2000]
        self.assertIn("if _backend_connected:", window)

    def test_fix_y_does_not_skip_when_registry_left(self):
        """When registry=left, _backend_connected must be overridden to False.

        v98.05 FIX-DD preserves this: after the stale-container recovery
        state machine runs, _backend_connected is set False and the chat
        falls through to active_targets (NOT skipped as already_joined).
        """
        idx = self.src.find("VC_SNAPSHOT_STALE_CONTAINER")
        self.assertGreater(idx, -1, "VC_SNAPSHOT_STALE_CONTAINER marker must exist")
        # v98.05 inserts the recovery state machine between the log and the
        # override, so the override is farther than the v98.04 ~36 lines.
        # Use a generous forward window to remain robust to the extension.
        window = self.src[idx:idx + 6000]
        self.assertIn("_backend_connected = False", window)
        # Must fall through to active_targets (not continue/skip).
        self.assertIn("active_targets", self.src)

    def test_fix_y_cleans_stale_container_when_registry_left(self):
        """When registry=left + container has object, cleanup must be attempted.

        v98.05 FIX-CC: the snapshot now delegates to _vc_stale_container_recovery()
        which internally calls _vc_cleanup_stale_backend_call (FIX-X-enabled,
        both ID forms). The safety property (cleanup attempted on a stale
        container when registry=left) is PRESERVED through this delegation.
        """
        self.assertIn("snapshot_stale_container:left_registry", self.src)
        # v98.05: snapshot delegates to the recovery state machine.
        self.assertIn("_vc_stale_container_recovery(", self.src)
        # The recovery function must internally call the cleanup helper.
        rec_idx = self.src.find("async def _vc_stale_container_recovery(")
        self.assertGreater(rec_idx, -1, "recovery function must be defined")
        rec_window = self.src[rec_idx:rec_idx + 4000]
        self.assertIn("_vc_cleanup_stale_backend_call", rec_window)

    def test_fix_y_inner_if_guard_for_already_joined(self):
        """The already_joined branch must be inside an inner if (not the outer)."""
        # The inner guard is the SECOND `if _backend_connected:` in the snapshot.
        idx = self.src.find("v98.04 FIX-Y: registry=left would NOT enter this branch")
        self.assertGreater(idx, -1, "inner guard comment must exist")
        window = self.src[max(0, idx - 1500):idx + 500]
        self.assertIn("if _backend_connected:", window)
        self.assertIn("already_joined_count += 1", window)


class TestVC804FixZVerifyJoinedRegistryLeftGuard(unittest.TestCase):
    """§4 — FIX-Z: verify_joined must NOT return True when registry=left.

    Defense-in-depth — complements FIX-X (cleanup actually works) + FIX-Y
    (snapshot doesn't trust container when registry=left). If both somehow
    fail, verify_joined returns None (UNKNOWN) so the caller knows the state
    is uncertain and does NOT mark confirmed-joined.
    """

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_fix_z_check_at_start_of_container_branch(self):
        """verify_joined's container-True branch must check registry=left first."""
        idx = self.src.find("if backend_has_target is True:")
        self.assertGreater(idx, -1, "verify_joined container branch must exist")
        window = self.src[idx:idx + 3000]
        self.assertIn("v98.04 FIX-Z", window)
        self.assertIn("BUG-VC-VERIFY-JOINED-CONTAINER-LEFT", window)

    def test_fix_z_returns_none_when_registry_left(self):
        """When registry=left + container has object, must return None (UNKNOWN)."""
        idx = self.src.find("if backend_has_target is True:")
        self.assertGreater(idx, -1)
        # v98.12 TEST-MECHANISM CORRECTION (documented): window 3000 -> 4200 —
        # the v98.12 §5 evidence-recording call inside the registry-left
        # branch sits above the return; the INVARIANT (return None) unchanged.
        window = self.src[idx:idx + 4200]
        self.assertIn('state", None) == "left"', window)
        self.assertIn("VC_JOIN_EVIDENCE_REGISTRY_LEFT", window)
        self.assertIn("return None", window)

    def test_fix_z_tries_both_id_forms_for_registry_lookup(self):
        """The registry lookup must try raw + marked forms."""
        idx = self.src.find("if backend_has_target is True:")
        self.assertGreater(idx, -1)
        window = self.src[idx:idx + 3000]
        self.assertIn("vc_registry_get(chat_id)", window)
        self.assertIn("-1000000000000 - chat_id", window)
        self.assertIn("abs(chat_id) % 1000000000000", window)


class TestVC804FixAADiscoveryPeerUserFilter(unittest.TestCase):
    """§5 — FIX-AA: discovery must NOT store User entities as group_ids.

    ROOT CAUSE (RUNTIME-PROVEN via (17).log: 346 PeerUser skip events):
      4 discovery storage sites stored User entities (PeerUser) as group_ids
      in vc_groups. At Join-All snapshot time, client.get_entity(user_id)
      fails with "Could not find the input entity for PeerUser" — wasting
      2 retries + 0.5s pacing per bad ID (~5 minutes per Join-All cycle).
    """

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_fix_aa_stage1_does_not_store_users(self):
        """Stage 1 (ResolveUsernameRequest) must NOT store User entities."""
        # The FIX-AA comment for Stage 1 must exist.
        idx = self.src.find("v98.04 FIX-AA (BUG-VC-DISCOVERY-STORE-PEERUSER")
        self.assertGreater(idx, -1, "FIX-AA comment must exist")
        # The Stage 1 FIX-AA comment must reference 346 skip events.
        # Verify the old user-storage loop is gone by checking that
        # `cls._entity_to_dict(u, "username_resolution")` does NOT appear
        # anywhere in the file (it was only used by the old loop).
        self.assertNotIn(
            'cls._entity_to_dict(u, "username_resolution")',
            self.src,
            "Stage 1 must NOT store User entities via _entity_to_dict",
        )

    def test_fix_aa_stage3_does_not_store_users(self):
        """Stage 3-6 (SearchGlobalRequest) must NOT store User entities."""
        # SearchGlobalRequest appears many times in comments + imports.
        # The Stage 3-6 FIX-AA comment is identified by the unique phrase
        # 'The `users` list is intentionally ignored' which I added.
        idx = self.src.find("The `users` list is intentionally ignored")
        self.assertGreater(idx, -1, "Stage 3-6 FIX-AA comment must exist")
        # Verify the FIX-AA comment is present.
        window = self.src[max(0, idx - 2000):idx + 500]
        self.assertIn("v98.04 FIX-AA", window)
        self.assertIn("BUG-VC-DISCOVERY-STORE-PEERUSER", window)
        # The old user-storage pattern must NOT be present anywhere in the file.
        self.assertNotIn(
            'cls._entity_to_dict(u, source)',
            self.src,
            "Stage 3-6 must NOT store User entities via _entity_to_dict(u, source)",
        )

    def test_fix_aa_stage2_invite_link_isinstance_check(self):
        """Stage 2 (invite link) must add isinstance(entity, (Channel, Chat))."""
        idx = self.src.find("Stage 2: Invite link resolution")
        self.assertGreater(idx, -1, "Stage 2 must exist")
        window = self.src[idx:idx + 2000]
        self.assertIn("v98.04 FIX-AA", window)
        self.assertIn("isinstance(entity, (_TgChannel, _TgChat))", window)
        self.assertIn("DISCOVERY_STAGE2_INVITE_SKIP_NON_GROUP", window)

    def test_fix_aa_source_b_explicit_targets_isinstance_check(self):
        """Source B (explicit targets) must add isinstance check."""
        idx = self.src.find("Source B: explicit targets supplied by admin")
        self.assertGreater(idx, -1, "Source B must exist")
        window = self.src[idx:idx + 2500]
        self.assertIn("v98.04 FIX-AA", window)
        self.assertIn("isinstance(entity, (_TgChannel2, _TgChat2))", window)
        # The warning log mentions "not a" + "group" (split across lines
        # for string concatenation). Check for the parts.
        self.assertIn("not a", window)
        self.assertIn("group", window)


class TestVC804FixBBSnapshotPeerUserFastSkip(unittest.TestCase):
    """§6 — FIX-BB: snapshot must fast-skip PeerUser IDs + mark for DB delete.

    ROOT CAUSE (RUNTIME-PROVEN via (17).log: 346 PeerUser skip events):
      Each PeerUser ID wasted 2 retries + 0.5s pacing + dead-letter counter
      increment. With 60+ bad IDs, ~5 minutes of pure waste per Join-All cycle.
      Fix: detect PeerUser errors, immediately mark + delete from vc_groups.
      Same-session fast-skip via in-memory set.
    """

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_fix_bb_module_level_set_exists(self):
        """The in-memory _vc_known_peeruser_ids set must exist."""
        self.assertIn("_vc_known_peeruser_ids: set[int] = set()", self.src)

    def test_fix_bb_helper_functions_exist(self):
        """vc_is_known_peeruser + vc_mark_peeruser must exist."""
        self.assertIn("def vc_is_known_peeruser(chat_id: int) -> bool:", self.src)
        self.assertIn("def vc_mark_peeruser(chat_id: int) -> None:", self.src)

    def test_fix_bb_fast_skip_in_snapshot_loop(self):
        """The snapshot loop must fast-skip known PeerUser IDs before get_entity."""
        idx = self.src.find("gid = g[\"group_id\"]")
        self.assertGreater(idx, -1)
        # Find the FIRST occurrence in the join-all worker (there are multiple).
        # Look for the one followed by the FIX-BB check.
        search_area = self.src[idx:idx + 3000]
        self.assertIn("vc_is_known_peeruser(gid)", search_area)
        self.assertIn("reason=known_peeruser", search_area)

    def test_fix_bb_peeruser_error_handler_in_snapshot(self):
        """The entity-failure handler must detect PeerUser errors + mark + continue."""
        # Find the entity-failure handler (catches ent_exc).
        idx = self.src.find("except Exception as ent_exc:")
        self.assertGreater(idx, -1)
        window = self.src[idx:idx + 3000]
        self.assertIn("v98.04 FIX-BB", window)
        self.assertIn('"peeruser" in _ent_msg_lower', window)
        self.assertIn("vc_mark_peeruser(gid)", window)

    def test_fix_bb_does_not_increment_dead_letter_for_peeruser(self):
        """PeerUser errors must NOT increment the entity-failure counter."""
        idx = self.src.find('"peeruser" in _ent_msg_lower')
        self.assertGreater(idx, -1, "PeerUser error check must exist")
        # The PeerUser branch must call vc_mark_peeruser + continue BEFORE
        # reaching vc_record_entity_failure.
        # v98.07 test maintenance: 600 → 900 / 1000 → 1400 — the v98.07
        # FIX-VV reason instrumentation (_vc_excl_reason("peeruser")) sits
        # between the mark and the continue; the CONTRACT (no dead-letter
        # increment inside the PeerUser branch) is unchanged.
        window = self.src[idx:idx + 900]
        self.assertIn("vc_mark_peeruser(gid)", window)
        self.assertIn("continue", window)
        # vc_record_entity_failure must be AFTER the continue (i.e., NOT
        # in the PeerUser branch). Check the full handler area.
        handler_area = self.src[idx:idx + 1400]
        self.assertIn("vc_record_entity_failure(gid)", handler_area)


class TestVC804DbLayerDeleteGroupHelper(unittest.TestCase):
    """§7 — db_layer.vc_delete_group helper must exist (FIX-AA-db / FIX-BB)."""

    def setUp(self):
        self.src = _read(_DB_LAYER)

    def test_vc_delete_group_exists(self):
        self.assertIn("async def vc_delete_group(group_id: int) -> bool:", self.src)

    def test_vc_delete_group_uses_delete_sql(self):
        idx = self.src.find("async def vc_delete_group")
        self.assertGreater(idx, -1)
        window = self.src[idx:idx + 1500]
        self.assertIn("DELETE FROM vc_groups WHERE group_id = ?", window)
        self.assertIn("await db.commit()", window)

    def test_vc_delete_group_rollback_on_error(self):
        idx = self.src.find("async def vc_delete_group")
        self.assertGreater(idx, -1)
        window = self.src[idx:idx + 1500]
        self.assertIn("await db.rollback()", window)
        self.assertIn("return False", window)


class TestVC804RuntimeEvidenceCorrelation(unittest.TestCase):
    """§8 — correlation between v98.04 fixes and (17).log runtime evidence.

    These tests verify the fix addresses the EXACT runtime behavior observed
    in bot-diagnostic (17).log. They do NOT re-run the production scenario
    (that requires a real Telegram soak — NOT PROVEN here, marked honestly).
    """

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_fix_x_addresses_chat_1922822605_timeline(self):
        """FIX-X docstring must reference the 1922822605 timeline from (17).log."""
        idx = self.src.find("async def _leave_target")
        self.assertGreater(idx, -1)
        window = self.src[idx:idx + 6000]
        # Must reference the exact timeline from (17).log.
        self.assertIn("03:38:21", window)
        self.assertIn("03:47:31", window)
        self.assertIn("03:48:17", window)
        self.assertIn("-8258460203439130263", window)

    def test_fix_y_addresses_left_to_already_joined_transition(self):
        """FIX-Y docstring must reference the LEFT→ALREADY_JOINED overwrite."""
        idx = self.src.find("if _backend_connected:")
        self.assertGreater(idx, -1)
        window = self.src[idx:idx + 4000]
        self.assertIn("LEFT→JOINED", window)
        self.assertIn("auto-leave + never-rejoin", window)

    def test_fix_bb_references_346_skip_events(self):
        """FIX-BB must reference the 346 PeerUser skip events from (17).log."""
        # The module-level set + helper must reference the runtime count.
        idx = self.src.find("_vc_known_peeruser_ids: set[int] = set()")
        self.assertGreater(idx, -1)
        # The "346" count appears in the COMMENT BLOCK BEFORE the set definition.
        # Search a window that includes the comment before the set.
        window = self.src[max(0, idx - 2000):idx + 1000]
        self.assertIn("346", window)
        self.assertIn("PeerUser", window)


class TestVC804PreservedInvariants(unittest.TestCase):
    """§9 — v98.04 must NOT break any prior fix (v97.30-v98.03)."""

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_v97_98_fix_a_cleanup_helper_preserved(self):
        """_vc_cleanup_stale_backend_call must still exist + call _leave_target."""
        idx = self.src.find("async def _vc_cleanup_stale_backend_call")
        self.assertGreater(idx, -1)
        # The function must still call backend._leave_target.
        # Use a generous window (the docstring is long).
        # v99.11: 8000 -> 13000 — the leave-policy chokepoint docstring
        # grew the helper; CONTRACT unchanged (backend._leave_target is
        # still the destructive call, now inside the policy factory).
        window = self.src[idx:idx + 13000]
        self.assertIn("backend._leave_target(chat_id)", window)

    def test_v97_99_fix_c_marked_form_check_preserved(self):
        """The snapshot's _backend_connected check must still test all 3 ID forms."""
        # Find the SPECIFIC v97.99 FIX-C comment in the snapshot check
        # (NOT the reference in the FIX-X docstring at line ~3779).
        idx = self.src.find("v97.99 FIX-C (BUG-VC-BACKEND-CONNECTED-ID-FORM")
        self.assertGreater(idx, -1, "v97.99 FIX-C snapshot comment must exist")
        # The marked-form check is ~42 lines (~3400 chars) after this comment.
        # Use a generous window.
        window = self.src[idx:idx + 4500]
        self.assertIn("_marked_gid = -1000000000000 - gid", window)
        self.assertIn("gid in _resolved_ids", window)
        self.assertIn("abs(gid) in _resolved_ids", window)
        self.assertIn("_marked_gid in _resolved_ids", window)

    def test_v98_00_fix_e_three_branches_preserved(self):
        """FIX-E's three-branch distinction (Case A/B/C) must be preserved."""
        # FIX-E is in vc_verify_target. Find it.
        idx = self.src.find("async def vc_verify_target")
        self.assertGreater(idx, -1)
        # v99.11: 8000 -> 9000 (documented correction; the P1
        # NOT_MEMBER/INACCESSIBLE recheck-backoff gate inserted at the
        # head of vc_verify_target pushed the FIX-E Case A/B/C branches
        # down (Case B now at ~8.1k chars, Case C at ~8.4k); INVARIANT
        # unchanged: all three branches still present in order).
        window = self.src[idx:idx + 9000]
        # Case A (no client) → unknown
        self.assertIn("Case A", window)
        # Case B (redetect raised) → unknown
        self.assertIn("Case B", window)
        # Case C (genuine absence) → absent
        self.assertIn("Case C", window)

    def test_v98_00_fix_f_gid_before_floodwait_preserved(self):
        """FIX-F's gid assignment before FloodWait log must be preserved."""
        idx = self.src.find("VC_TARGET_FLOODWAIT_DEFERRED")
        self.assertGreater(idx, -1)
        # The gid assignment must be BEFORE this log.
        # The FIX-F comment block is long (~600 chars); the actual gid = g[...]
        # assignment is ~32 lines above the log. Use a generous window.
        before = self.src[max(0, idx - 3000):idx]
        self.assertIn('gid = g["group_id"]', before)

    def test_v98_03_fix_t_call_id_assignment_preserved(self):
        """FIX-T's _current_call_id assignment in join success must be preserved."""
        idx = self.src.find("v98.03 FIX-T")
        self.assertGreater(idx, -1)
        window = self.src[idx:idx + 2500]
        # v99: the pipeline outcome carries the verified call identity.
        self.assertIn("self._current_call_id = outcome.call_id", window)
        self.assertIn("self._current_chat_id = marked", window)
        self.assertIn("self._current_access_hash = int(outcome.access_hash or 0)", window)

    def test_v98_03_fix_w_lifecycle_callback_probe_preserved(self):
        """FIX-W's PyTgCalls 2.x lifecycle callback probe must be preserved."""
        idx = self.src.find("VC_PYTGCALLS_NO_LIFECYCLE_CALLBACKS")
        self.assertGreater(idx, -1)
        window = self.src[idx:idx + 2000]
        self.assertIn("on_network_status_changed", window)


class TestVC804HonestScopeMarkers(unittest.TestCase):
    """§10 — honest scope markers. NOT PROVEN scenarios are explicitly marked."""

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_fix_x_docmark_runtime_proven(self):
        idx = self.src.find("async def _leave_target")
        self.assertGreater(idx, -1)
        window = self.src[idx:idx + 6000]
        self.assertIn("RUNTIME-PROVEN via", window)

    def test_fix_y_docmark_runtime_proven(self):
        idx = self.src.find("if _backend_connected:")
        self.assertGreater(idx, -1)
        window = self.src[idx:idx + 4000]
        self.assertIn("RUNTIME-PROVEN via", window)

    def test_no_false_production_ready_claim(self):
        """The source must NOT claim production-ready without runtime proof."""
        # Grep for any "PRODUCTION READY" claim in the source.
        self.assertNotIn("PRODUCTION READY", self.src)
        self.assertNotIn("production ready", self.src.lower().upper())


class TestVC804SourceCompiles(unittest.TestCase):
    """§11 — source modules must compile without syntax errors."""

    def test_voicechat_compiles(self):
        import py_compile
        py_compile.compile(_VOICECHAT, doraise=True)

    def test_db_layer_compiles(self):
        import py_compile
        py_compile.compile(_DB_LAYER, doraise=True)

    def test_init_compiles(self):
        import py_compile
        py_compile.compile(_INIT, doraise=True)

    def test_bootstrap_compiles(self):
        import py_compile
        py_compile.compile(_BOOTSTRAP, doraise=True)

    def test_voicechat_is_valid_ast(self):
        with open(_VOICECHAT, encoding="utf-8") as f:
            ast.parse(f.read())

    def test_db_layer_is_valid_ast(self):
        with open(_DB_LAYER, encoding="utf-8") as f:
            ast.parse(f.read())


if __name__ == "__main__":
    unittest.main()
