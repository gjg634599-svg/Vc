"""v98.09 FIX-CCC regression tests — ROOT-CAUSE fix for the 2026-09-01
event-loop hard freezes (query-selection infinite loop).

CRITICAL RUNTIME EVIDENCE (all four artifacts uploaded 2026-09-01):
  * vc_canary_dump_10077_20260901_073038.txt — event-loop thread frozen at
    voicechat.py:19987 in _auto_discovery_run_one_cycle (the ``while
    ei < len(exploit) or xi < len(explore):`` condition line; canary
    age=186s > threshold 180s, pid 10077).
  * vc_canary_dump_25848_20260901_073407.txt — event-loop thread frozen at
    voicechat.py:19989 in _auto_discovery_run_one_cycle (the
    ``if xi < len(explore) and len(queries_to_run) < max_q:`` line; canary
    age=181s, pid 25848 — cycle 1 of a FRESH process, frozen within
    seconds of AUTO_DISCOVERY_CYCLE_STARTED because the DB-persisted
    autonomous pool already exceeded vc_discovery_max_queries_per_cycle).
  * bot-diagnostic.log (SHA256 7e438168c5133f7cfe746e66f57a81987712c304
    60897aef852af7161b5646c0): DEPLOYMENT_IDENTITY version=v99.00 (6/7
    module hashes match the canonical v98.08 zip byte-exactly;
    voicechat.py differs — production ran a locally-modified variant with
    a +4-line offset: zip L19830 call-site → prod L19834, zip L19983
    while-cond → prod L19987, zip L19985 inner-if → prod L19989 — the
    line mapping is exact and unambiguous); PID 10077 cycle 1 completed
    (CAPPED queries_done=3 elapsed=104s cap=90s), pool grew past 20
    between 07:20:59 and 07:27:35, cycle 2 froze at 07:27:35 → canary
    07:30:38 → exit(86) → manual restart (supervisor=none); PID 25848
    boot 07:31:07 → cycle 1 froze ~07:31:27 → canary 07:34:08 → exit(86)
    → PID 27751 boot 07:34:47 (would freeze again identically).
  * mediagrab_bot_v98.08_deployment.zip (SHA256 d9345a07daa6680f7ce2
    983dfe3d409ae739bd367565f6bc5e2a508f3528ce4) — the shipped source
    containing the identical defect (verbatim block reproduced in §A
    below, with the v98.07 zip byte-verified to contain the same block:
    the defect is ancient and latent, detonating the moment
    len(merged) > max_q).

ROOT CAUSE (source-proven, canary-corroborated): once
``len(queries_to_run) == max_q`` BOTH append conditions in the v98.08
selection loop are False, so neither ei nor xi ever advances while the
``while`` condition stays True whenever any input entry remains
unconsumed — a synchronous infinite loop owning the event-loop thread.
No await → the heartbeat starves → the thread-based canary fires →
exit(86). The 90s cycle wall-cap cannot help: it is checked inside the
per-query loop, which this selection loop precedes.

FIX UNDER TEST (FIX-CCC): selection delegates to
``_vc_discovery_select_queries_bounded`` — every interleave iteration
appends >= 1 item and advances >= 1 index (capacity NEVER gates an
index advance), capacity enforced by ONE terminal slice; the cycle
function itself now contains ZERO while loops (AST-verified). The
90s wall-cap (FIX-WW) remains active as the secondary guard, now with
honest overshoot reporting.

TEST LEVELS (honest):
  * REPRODUCED: the verbatim v98.08 selection block is executed in an
    ISOLATED SUBPROCESS with a hard timeout and PROVEN non-terminating
    (Test A) — deterministic, cannot hang the suite.
  * TEST-PROVEN: the ACTUAL shipped helper is AST-extracted from
    voicechat.py and exec'd — every behavioral test runs it through a
    subprocess wrapper with a hard timeout, so ANY regression back to
    an unbounded loop fails CLEANLY (subprocess timeout) instead of
    hanging the suite.
"""

import ast
import json
import os
import subprocess
import sys
import time
import unittest

_PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_PKG_ROOT, "mediagrab_bot", "voicechat.py")
_BOOTSTRAP = os.path.join(_PKG_ROOT, "mediagrab_bot", "bootstrap.py")
_CONFIG = os.path.join(_PKG_ROOT, "mediagrab_bot", "config.py")
_SERVICE = os.path.join(_PKG_ROOT, "deploy", "mediagrab.service")
_INSTALLER = os.path.join(_PKG_ROOT, "deploy", "install_supervisor.sh")
_DEPLOY_MD = os.path.join(_PKG_ROOT, "DEPLOYMENT.md")

_SUBPROC_TIMEOUT = 10.0  # hard isolation bound; bounded work finishes in <1s


def _read(path: str) -> str:
    with open(path, encoding="utf-8") as fh:
        return fh.read()


# The v98.08 selection block VERBATIM (zip lines 19975-19990 of
# mediagrab_bot/voicechat.py, SHA256 11560f7916f2254a...; identical block
# present in v98.07's voicechat.py at L19558-19563 — the defect predates
# v98.08). Reproduced bit-for-bit for the deterministic incident replay.
_V9808_SELECTION_BLOCK = r'''
queries_to_run = []
if len(merged) > 4:
    exploit = merged[:int(len(merged) * 0.8)]
    explore = merged[int(len(merged) * 0.8):]
    ei, xi = 0, 0
    while ei < len(exploit) or xi < len(explore):
        for _ in range(3):
            if ei < len(exploit) and len(queries_to_run) < max_q:
                queries_to_run.append(exploit[ei]); ei += 1
        if xi < len(explore) and len(queries_to_run) < max_q:
            queries_to_run.append(explore[xi]); xi += 1
else:
    queries_to_run = merged[:max_q]
'''

# Subprocess driver: builds `merged` of size n, runs the given code with
# a done-marker, prints a JSON result line. Used for BOTH the v98.08
# reproduction (expected to hang → TimeoutExpired) and the v98.09 helper
# (expected to complete).
_SUBPROC_DRIVER = r'''
import ast, json, sys
merged = [{"query": "q%05d" % i, "source": "autonomous",
           "priority": 1000 - i, "enabled": True} for i in range(__N__)]
max_q = __MAX_Q__
__BODY__
print("V9809_DONE " + json.dumps({"n": len(queries_to_run),
      "queries": [d["query"] for d in queries_to_run]}))
'''


def _run_subprocess(n: int, max_q, body: str, timeout: float = _SUBPROC_TIMEOUT):
    """Run `body` with merged(n) + max_q in an isolated interpreter.

    Returns ("done", payload-dict) on clean completion,
    ("timeout", None) if the process had to be killed.
    """
    script = (_SUBPROC_DRIVER
              .replace("__N__", str(n))
              .replace("__MAX_Q__", str(max_q))
              .replace("__BODY__", body))
    try:
        proc = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True, text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return ("timeout", None)
    for line in (proc.stdout or "").splitlines():
        if line.startswith("V9809_DONE "):
            try:
                return ("done", json.loads(line[len("V9809_DONE "):]))
            except json.JSONDecodeError:
                return ("done", None)
    return ("no_marker", {"stdout": (proc.stdout or "")[:400],
                          "stderr": (proc.stderr or "")[:400]})


def _helper_body() -> str:
    """Extract the REAL _vc_discovery_select_queries_bounded source from
    the shipped voicechat.py (AST, verbatim) and emit code that calls it."""
    src = _read(_VOICECHAT)
    tree = ast.parse(src)
    seg = None
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) \
                and node.name == "_vc_discovery_select_queries_bounded":
            seg = ast.get_source_segment(src, node)
    if seg is None:
        raise AssertionError(
            "_vc_discovery_select_queries_bounded must exist as a "
            "top-level function in voicechat.py")
    return (
        "from typing import Any\n"
        + seg
        + "\nqueries_to_run = _vc_discovery_select_queries_bounded("
          "merged, max_q)\n"
    )


def _expected_interleave(n: int, max_q: int) -> list:
    """Reference model of the INTENDED v98.08 semantics (what the old
    loop would produce if it terminated when the inputs were exhausted):
    3 exploit : 1 explore, intra-list order preserved, first max_q items."""
    merged = ["q%05d" % i for i in range(n)]
    if n <= 4:
        return merged[:max(max_q, 0)]
    exploit = merged[:int(n * 0.8)]
    explore = merged[int(n * 0.8):]
    out = []
    ei = xi = 0
    while ei < len(exploit) or xi < len(explore):
        for _ in range(3):
            if ei < len(exploit):
                out.append(exploit[ei]); ei += 1
        if xi < len(explore):
            out.append(explore[xi]); xi += 1
    return out[:max(max_q, 0)]


# =============================================================================
# §A — TEST A: exact deterministic reproduction of the v98.08 infinite loop
# =============================================================================

class TestA_V9808InfiniteLoopReproduction(unittest.TestCase):
    """The v98.08 algorithm, on len(merged) > max_q, NEVER terminates.

    Runs the verbatim v98.08 block in an isolated subprocess with a hard
    10s timeout. The loop is provably infinite (after the last append,
    no index ever advances and no await/break exists), so the subprocess
    is killed at the timeout — the reproduction is deterministic, not
    timing-dependent. This test MUST pass (i.e., the hang MUST reproduce)
    while the v98.08 source is the shipped code; the companion tests in
    §B prove the v98.09 production helper terminates on the SAME input.
    """

    def test_a_infinite_loop_reproduced_exact_condition(self):
        # merged=25 > max_q=20 (the production trigger: DB-persisted
        # autonomous pool crossed vc_discovery_max_queries_per_cycle).
        status, payload = _run_subprocess(25, 20, _V9808_SELECTION_BLOCK,
                                          timeout=3.0)
        self.assertEqual(
            status, "timeout",
            "the v98.08 selection block was expected to hang forever "
            "on len(merged) > max_q; it completed instead: %r" % (payload,))

    def test_a_freeze_signature_matches_canary_dumps(self):
        """Canary dumps froze at the while-condition (10077 → 19987) and
        at the capacity-gated if (25848 → 19989). Simulate BOTH sampling
        points: the loop's post-append steady state has ei/xi frozen
        while the while-condition stays True — assert exactly that state
        (no subprocess: this models the frozen state, it does not run
        the infinite loop)."""
        merged = list(range(25))
        max_q = 20
        queries_to_run = []
        exploit = merged[:int(len(merged) * 0.8)]
        explore = merged[int(len(merged) * 0.8):]
        ei = xi = 0
        # Run the v98.08 loop body EXACTLY as the interpreter would until
        # appends stop — then STOP (bounded emulation of the defect).
        guard = 0
        while (ei < len(exploit) or xi < len(explore)) and guard < 1000:
            guard += 1
            progressed = False
            for _ in range(3):
                if ei < len(exploit) and len(queries_to_run) < max_q:
                    queries_to_run.append(exploit[ei]); ei += 1
                    progressed = True
            if xi < len(explore) and len(queries_to_run) < max_q:
                queries_to_run.append(explore[xi]); xi += 1
                progressed = True
            if not progressed:
                # THE DEFECT: one full while-iteration completed with NO
                # append and NO index advance, while the while-condition
                # is still True — from here the v98.08 loop spins forever.
                self.assertLess(ei, len(exploit))  # condition operand alive
                break
        self.assertEqual(len(queries_to_run), max_q)
        self.assertEqual(guard, 6, "defect steady state reached on the 6th "
                         "iteration (5 productive + 1 zero-progress spin)")
        # THE DEFECT SIGNATURE: the while-condition is STILL True (the OR
        # has at least one live operand — here ei=15 < len(exploit)=20
        # while explore is fully consumed), but no future iteration can
        # ever append (capacity full) or advance either index. For
        # merged=25/max_q=20 the live operand is ei; xi is exhausted —
        # exactly the state the interpreter spins on at the while-line
        # (10077, dump line 19987) and at the capacity-gated if-lines
        # (25848, dump line 19989).
        self.assertTrue(ei < len(exploit) or xi < len(explore),
                        "while-condition stays True forever")
        self.assertLess(ei, len(exploit), "ei stuck below len(exploit)")


# =============================================================================
# §B — TESTS B-G: the production helper (real shipped source, subprocess)
# =============================================================================

class TestB_ProductionHelperBehavior(unittest.TestCase):
    """Every behavioral test exec's the REAL shipped helper inside an
    isolated subprocess (hard 10s timeout): a regression back to an
    unbounded loop fails CLEANLY via subprocess timeout."""

    @classmethod
    def setUpClass(cls):
        cls.body = _helper_body()

    def _run(self, n, max_q, timeout=_SUBPROC_TIMEOUT):
        return _run_subprocess(n, max_q, self.body, timeout=timeout)

    # --- Test B: max_q larger than input -------------------------------
    def test_b_max_q_larger_than_input_selects_all_exactly_once(self):
        status, payload = self._run(25, 200)
        self.assertEqual(status, "done", payload)
        self.assertEqual(payload["n"], 25)
        self.assertEqual(sorted(payload["queries"]),
                         sorted("q%05d" % i for i in range(25)))
        self.assertEqual(len(payload["queries"]),
                         len(set(payload["queries"])), "no duplicates")

    # --- Test C: max_q == 1 ---------------------------------------------
    def test_c_max_q_1_returns_exactly_one(self):
        status, payload = self._run(25, 1)
        self.assertEqual(status, "done", payload)
        self.assertEqual(payload["n"], 1)
        self.assertEqual(payload["queries"], ["q00000"])

    # --- Test A2: the incident input through the FIXED helper ----------
    def test_a2_incident_input_terminates_with_exact_capacity(self):
        """The exact Test-A input through the v98.09 production helper:
        completes in <1s (subprocess), exactly max_q entries, order
        byte-identical to the INTENDED v98.08 interleave."""
        status, payload = self._run(25, 20, timeout=3.0)
        self.assertEqual(status, "done", payload)
        self.assertEqual(payload["n"], 20)
        self.assertEqual(payload["queries"],
                         _expected_interleave(25, 20))

    # --- Test D: exploit exhausted first, capacity filled from explore -
    def test_d_exploit_exhausted_first_fills_from_explore(self):
        # merged=6: exploit=4, explore=2. Interleave consumes all exploit
        # (ei=4) while capacity remains → remaining capacity is filled
        # from explore. Expected: [e0,e1,e2,x0,e3,x1].
        status, payload = self._run(6, 6)
        self.assertEqual(status, "done", payload)
        self.assertEqual(
            payload["queries"],
            ["q00000", "q00001", "q00002", "q00004",
             "q00003", "q00005"],
            "exploit-then-explore fill must preserve the 3:1 interleave "
            "order and fill leftover capacity")

    # --- Test E: explore exhausted first, capacity filled from exploit -
    def test_e_explore_exhausted_first_fills_from_exploit(self):
        # merged=10: exploit=8, explore=2, max_q=10. After 2 interleaves
        # explore is exhausted (xi=2) with capacity remaining → the rest
        # fills from exploit contiguously.
        status, payload = self._run(10, 10)
        self.assertEqual(status, "done", payload)
        self.assertEqual(payload["n"], 10)
        self.assertEqual(
            payload["queries"],
            ["q00000", "q00001", "q00002", "q00008",
             "q00003", "q00004", "q00005", "q00009",
             "q00006", "q00007"])

    # --- Test F: empty / degenerate inputs ------------------------------
    def test_f_empty_merged_returns_empty(self):
        status, payload = self._run(0, 5)
        self.assertEqual(status, "done", payload)
        self.assertEqual(payload["n"], 0)

    def test_f_max_q_zero_returns_empty(self):
        status, payload = self._run(25, 0)
        self.assertEqual(status, "done", payload)
        self.assertEqual(payload["n"], 0)

    def test_f_max_q_negative_returns_empty(self):
        status, payload = self._run(25, -3)
        self.assertEqual(status, "done", payload)
        self.assertEqual(payload["n"], 0)

    def test_f_max_q_none_returns_empty(self):
        # max_q=None must not raise out of the helper (defensive int()).
        status, payload = _run_subprocess(
            25, "None", self.body.replace("_vc_discovery_select_queries_"
                                          "bounded(merged, max_q)",
                                          "_vc_discovery_select_queries_"
                                          "bounded(merged, None)"))
        # driver sets max_q = None literal; body still passes merged.
        self.assertIn(status, ("done", "no_marker"))
        if status == "done":
            self.assertEqual(payload["n"], 0)

    def test_f_small_pool_slice_semantics_preserved(self):
        # len(merged) <= 4 → same slice semantics as v98.08's else branch.
        status, payload = self._run(3, 5)
        self.assertEqual(status, "done", payload)
        self.assertEqual(payload["queries"], ["q00000", "q00001", "q00002"])
        status, payload = self._run(3, 2)
        self.assertEqual(status, "done", payload)
        self.assertEqual(payload["queries"], ["q00000", "q00001"])

    def test_f_empty_explore_branch(self):
        # int(len*0.8) == len for len=5 → explore empty → exploit-only.
        status, payload = self._run(5, 5)
        self.assertEqual(status, "done", payload)
        self.assertEqual(payload["n"], 5)

    # --- Test G: huge input, runtime bounded ----------------------------
    def test_g_huge_input_bounded_runtime_and_output(self):
        t0 = time.monotonic()
        status, payload = self._run(20000, 20, timeout=5.0)
        dt = time.monotonic() - t0
        self.assertEqual(status, "done", payload)
        self.assertEqual(payload["n"], 20)
        self.assertLess(dt, 5.0, "20k-query selection must stay bounded")

    def test_g_huge_input_max_capacity(self):
        status, payload = self._run(20000, 200, timeout=5.0)
        self.assertEqual(status, "done", payload)
        self.assertEqual(payload["n"], 200)
        self.assertEqual(payload["queries"],
                         _expected_interleave(20000, 200))

    def test_g_output_never_exceeds_max_q(self):
        for n, mq in [(25, 20), (10, 4), (100, 7), (1000, 13), (6, 6),
                      (5, 3), (4, 4), (3, 1), (20000, 1)]:
            status, payload = self._run(n, mq, timeout=5.0)
            self.assertEqual(status, "done", (n, mq, payload))
            self.assertLessEqual(payload["n"], mq,
                                 f"len<=max_q violated for n={n} max_q={mq}")

    def test_g_order_matches_intended_v9808_semantics(self):
        """For a matrix of shapes the fixed helper's output is exactly
        the INTENDED v98.08 interleave (first max_q items)."""
        for n, mq in [(25, 20), (25, 25), (10, 10), (10, 6), (100, 50),
                      (100, 12), (7, 3), (9, 9), (1000, 33)]:
            status, payload = self._run(n, mq, timeout=5.0)
            self.assertEqual(status, "done", (n, mq))
            self.assertEqual(
                payload["queries"], _expected_interleave(n, mq),
                f"interleave order diverged for n={n} max_q={mq}")

    def test_g_exploration_preserved(self):
        """Invariant 5 (no silent removal of exploration): whenever
        explore is non-empty and max_q >= 4, at least one explore item is
        selected (3:1 interleave puts x0 at position 3)."""
        for n in (25, 100, 1000):
            status, payload = self._run(n, 4, timeout=5.0)
            self.assertEqual(status, "done", payload)
            self.assertEqual(payload["n"], 4)
            self.assertIn(
                "q%05d" % int(n * 0.8), payload["queries"],
                f"explore entry missing for n={n}")

    def test_g_intra_list_order_preserved(self):
        """Invariant 7: relative order within exploit and within explore
        is preserved (each list's selected subsequence is increasing)."""
        for n, mq in [(25, 20), (100, 50), (1000, 137)]:
            status, payload = self._run(n, mq, timeout=5.0)
            self.assertEqual(status, "done", payload)
            nums = [int(q[1:]) for q in payload["queries"]]
            exploit_part = [v for v in nums if v < int(n * 0.8)]
            explore_part = [v for v in nums if v >= int(n * 0.8)]
            self.assertEqual(exploit_part, sorted(exploit_part))
            self.assertEqual(explore_part, sorted(explore_part))


# =============================================================================
# §H — TEST H: event-loop responsiveness under the cycle-head logic
# =============================================================================

class TestH_EventLoopResponsiveness(unittest.TestCase):
    """The heartbeat coroutine must keep executing while the selection
    logic runs. The v98.09 helper (real source, exec'd in a subprocess
    event loop) coexists with a 5ms heartbeat; the v98.08 block (verbatim)
    starves it forever — both directions are asserted, isolated in
    subprocesses with hard timeouts so neither can hang the suite."""

    _HELPER_ASYNC = r'''
import ast, asyncio, json, sys
from typing import Any
src = open("__VOICECHAT_PATH__", encoding="utf-8").read()
tree = ast.parse(src)
seg = None
for node in tree.body:
    if isinstance(node, ast.FunctionDef) \
            and node.name == "_vc_discovery_select_queries_bounded":
        seg = ast.get_source_segment(src, node)
assert seg is not None, "helper missing"
ns = {"Any": Any}
exec(compile(seg, "<helper>", "exec"), ns)
select = ns["_vc_discovery_select_queries_bounded"]

heartbeats = 0
async def heartbeat():
    global heartbeats
    while True:
        await asyncio.sleep(0.005)
        heartbeats += 1

async def main():
    global heartbeats
    hb = asyncio.create_task(heartbeat())
    # 100 selection cycles over a 5000-query pool each (500k selections
    # total), with the same real await cadence the discovery cycle has
    # between queries (per-query RPC awaits). The heartbeat (5ms cadence,
    # exactly like the loop-liveness stamper the canary watches) must
    # keep ticking throughout — proving no synchronous section owns the
    # event loop.
    for cycle in range(100):
        merged = [{"query": "q%05d" % i, "source": "autonomous",
                   "priority": 1000 - i, "enabled": True}
                  for i in range(5000)]
        out = select(merged, 20)
        assert len(out) == 20, len(out)
        await asyncio.sleep(0.02)
    hb.cancel()
    print("V9809_HB " + json.dumps({"heartbeats": heartbeats}))

asyncio.run(main())
'''.replace("__VOICECHAT_PATH__", _VOICECHAT)

    _V9808_ASYNC = r'''
import asyncio, json, sys

heartbeats = 0
async def heartbeat():
    global heartbeats
    while True:
        await asyncio.sleep(0.005)
        heartbeats += 1

merged = [{"query": "q%05d" % i} for i in range(25)]
max_q = 20

async def main():
    global heartbeats
    hb = asyncio.create_task(heartbeat())
    await asyncio.sleep(0.05)          # heartbeat proves alive pre-selection
    __V9808_BODY__                     # v98.08 selection: never returns
    hb.cancel()
    print("V9809_SHOULD_NOT_REACH")

asyncio.run(main())
'''.replace("__V9808_BODY__", _V9808_SELECTION_BLOCK)

    def test_h_heartbeat_ticks_while_fixed_selection_runs(self):
        try:
            proc = subprocess.run(
                [sys.executable, "-c", self._HELPER_ASYNC],
                capture_output=True, text=True, timeout=15.0)
        except subprocess.TimeoutExpired:
            self.fail("selection logic blocked the event loop "
                      "(subprocess timeout) — regression to an unbounded "
                      "synchronous loop")
        for line in (proc.stdout or "").splitlines():
            if line.startswith("V9809_HB "):
                hb = json.loads(line[len("V9809_HB "):])["heartbeats"]
                # 100 bounded selections (each ~ms) + per-cycle awaits:
                # the 5ms heartbeat must have ticked MANY times (>50).
                # An infinite synchronous selection yields 0 ticks and
                # the subprocess timeout kill instead — this assertion
                # is the responsive-vs-starved discriminator.
                self.assertGreater(hb, 50,
                                   "heartbeat starved during selection: "
                                   "%d ticks" % hb)
                return
        self.fail("helper harness produced no heartbeat marker: "
                  f"{(proc.stderr or '')[:400]}")

    def test_h_v9808_block_starves_heartbeat_forever(self):
        """The incident mechanics: with the v98.08 block, the heartbeat
        coroutine NEVER runs again (sync loop owns the thread) — the
        subprocess is killed at the timeout. This is exactly what the
        thread-based canary detects (age > 180s → dump → exit(86))."""
        try:
            proc = subprocess.run(
                [sys.executable, "-c", self._V9808_ASYNC],
                capture_output=True, text=True, timeout=3.0)
            self.fail("v98.08 block unexpectedly completed: "
                      f"{(proc.stdout or '')[:200]}")
        except subprocess.TimeoutExpired:
            pass  # REPRODUCED: heartbeat starved, selection never returned


# =============================================================================
# §I — TEST I: cycle wall-cap remains intact (secondary guard)
# =============================================================================

class TestI_CycleWallCapIntact(unittest.TestCase):
    def setUp(self):
        self.src = _read(_VOICECHAT)
        tree = ast.parse(self.src)
        self.cycle_seg = None
        for node in tree.body:
            if isinstance(node, ast.AsyncFunctionDef) \
                    and node.name == "_auto_discovery_run_one_cycle":
                self.cycle_seg = ast.get_source_segment(self.src, node)
                self.cycle_node = node
        self.assertIsNotNone(self.cycle_seg)

    def test_i_cap_check_precedes_each_query(self):
        self.assertIn("_VC_DISCOVERY_CYCLE_DEADLINE_MONO", self.cycle_seg)
        self.assertIn("time.monotonic() > _VC_DISCOVERY_CYCLE_DEADLINE_MONO",
                      self.cycle_seg)
        self.assertIn("AUTO_DISCOVERY_CYCLE_CAPPED", self.cycle_seg)

    def test_i_capped_log_reports_overshoot_honestly(self):
        """v98.09: elapsed may exceed cap by the in-flight query duration
        (no unsafe cancellation) — the log must say so explicitly."""
        self.assertIn("overshoot=", self.cycle_seg)
        self.assertIn("in-flight query completing normally", self.cycle_seg)

    def test_i_cap_config_knob_unchanged(self):
        cfg = _read(_CONFIG)
        self.assertIn('vc_discovery_cycle_wall_cap', cfg)
        self.assertIn('VC_DISCOVERY_CYCLE_WALL_CAP', cfg)
        self.assertIn(
            'vc_discovery_cycle_wall_cap: int = _env_int('
            '"VC_DISCOVERY_CYCLE_WALL_CAP", 90)', cfg)

    def test_i_cap_defers_not_cancels(self):
        """The cap must break out of the per-query loop (defer semantics),
        not raise/cancel in-flight Telethon operations."""
        seg = self.cycle_seg
        i_log = seg.index("AUTO_DISCOVERY_CYCLE_CAPPED")
        i_break = seg.index("break", i_log)
        # The break immediately follows the capped log block (window
        # covers the v98.09 overshoot-reporting comment + format args).
        self.assertLess(i_break - i_log, 2000)

    def test_i_cycle_function_contains_zero_while_loops(self):
        """STRUCTURAL TERMINATION GUARANTEE (v98.09): the entire cycle
        function — from entry through per-query loop — contains NO while
        loop at all. Every iteration construct is a for over a finite
        list; the only former while (the v98.08 selection loop) is gone."""
        whiles = [n.lineno for n in ast.walk(self.cycle_node)
                  if isinstance(n, ast.While)]
        self.assertEqual(whiles, [],
                         "while loops reintroduced into the discovery "
                         f"cycle at lines {whiles}")

    def test_i_selection_delegates_to_bounded_helper(self):
        calls = [n.lineno for n in ast.walk(self.cycle_node)
                 if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                 and n.func.id == "_vc_discovery_select_queries_bounded"]
        # v99: 22911 -> 21827 (documented correction; the v99 pipeline
        # rewrite moved the 850-line join body into vc_pipeline.py —
        # net -794 lines above the anchor; INVARIANT unchanged: ONE
        # call-site, zero while-loops)
        # v99.05: 21980 -> 22197 (documented correction; the RC-F1
        # peer-matching helper + targeted-query/verification fixes
        # added +217 lines above the anchor; INVARIANT unchanged:
        # ONE call-site, zero while-loops)
        # v99.03: 21930 -> 21980 (documented correction; the RC-13
        # discovery/reconcile short-circuit insertions (+50 lines
        # above the anchor) shifted the call-site; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.02: 21827 -> 21930 (documented correction; the FIX-2/FIX-5
        # voicechat insertions added +103 lines above the anchor; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.06: 22197 -> 22874 (documented correction; the FIX-2
        # parallel per-account discovery pass helpers + the concurrent
        # launch/await blocks inside _auto_discovery_run_one_cycle
        # added +677 lines above the anchor; INVARIANT unchanged:
        # ONE call-site, zero while-loops)
        # v99.06 (D8 fix correction): 22874 -> 22885 — the FIX-3b
        # registry terminal-state entry-capture fix in
        # vc_registry_register added +11 lines above the anchor;
        # INVARIANT unchanged: ONE call-site, zero while-loops.
        # v99.07: 22885 -> 23116 (documented correction; the FIX-1/2/3
        # backend-start unification [getter rewrite + _adopt_started_transport
        # method + generation tracking + join-site start gate] + FIX-4
        # shutdown disambiguation + FIX-8 filter-scan counters added +231
        # lines above the anchor; INVARIANT unchanged: ONE call-site,
        # zero while-loops)
        # v99.07 (post-FIX-12 correction): 23116 -> 23129 — the FIX-12
        # worker-heartbeat block at the vc_reconcile_loop head sits ABOVE
        # the discovery cycle and added +13 lines to the anchor shift;
        # INVARIANT unchanged: ONE call-site, zero while-loops.
        # v99.08: 23129 -> 23263 (documented correction; the v99.08
        # Patch-1 flat-scope comparison block + the item-8 cache-bound
        # helpers inserted above the anchor; INVARIANT unchanged)
        # v99.09: 23263 -> 23302 (documented correction; the FIX-C
        # verify_joined form-aware ownership lookup + one-hop
        # delegation guard in PyTgCallsBackend (above the discovery
        # cycle) added +39 lines to the anchor shift; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.10: 23302 -> 23776 (documented correction; the v99.10
        # FIX-A/B/C/E/F insertions above the anchor; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.11: 23776 -> 24553 (documented correction; the P1
        # get_contacts ladder (+3) + the P0 leave-policy reason-code
        # wiring + the admission-gate/transport-lifecycle blocks + the
        # P1 verification-state classification (VC_VERIFY_INACCESSIBLE /
        # not-member recheck backoff) + the crash-loop startup-recovery
        # guard (all above the anchor) added +777 lines; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.11 (config-audit correction): 24553 -> 24561 — the
        # VC_JOIN_RETRY_BASE/MAX_SECONDS env wiring at module top
        # added +8 lines above the anchor; INVARIANT unchanged.
        # v99.11.1 (documented correction): 24561 -> 24962 — the FIX-3
        # already-joined classification helper at the module head
        # (+401 lines above the anchor) shifted the call-site;
        # INVARIANT unchanged: ONE call-site, zero while-loops.
        # v99.11.2 (documented correction): 24962 -> 25115 — the FIX
        # cluster-owned already-joined convergence (the owner-scope
        # helper at the module head +68 and the convergence branch in
        # the Join-All worker +85, both above the anchor) shifted the
        # call-site; INVARIANT unchanged: ONE call-site, zero
        # while-loops.
        # v99.11.3 (documented correction): 25115 -> 25479 -> 25513 —
        # the FIX-1 deterministic-native-release bookkeeping in the
        # stale-call cleanup + the settled-phase wiring at the join/
        # leave sites + the FIX-2 entity-invalid classification/
        # cooldown/gate in the Join-All worker + the drift-attribution
        # pass function + the terminal-tracker remediation extension
        # + the FIX-3 measurement note (all above the anchor) shifted
        # the call-site; INVARIANT unchanged: ONE call-site, zero
        # while-loops.
        self.assertEqual(calls, [25513])

    def test_i_max_q_semantics_unchanged(self):
        """max_q keeps its meaning: min(per-cycle config, pool size)."""
        self.assertIn(
            "max_q = min(config.vc_discovery_max_queries_per_cycle, "
            "len(merged))", self.cycle_seg)

    def test_i_cap_behavioral_defers_remaining_queries(self):
        """Behavioral: exec the REAL per-query loop head (verbatim source
        slice: stop-check -> pause-wait -> stop-check -> deadline-check
        -> break) with the deadline ALREADY in the past — ZERO queries
        may start; the cap defers the whole batch, no exception raised."""
        driver = r'''
import ast, asyncio, json, sys, time
src = open("__VOICECHAT_PATH__", encoding="utf-8").read()
tree = ast.parse(src)
seg = None
for node in tree.body:
    if isinstance(node, ast.AsyncFunctionDef) \
            and node.name == "_auto_discovery_run_one_cycle":
        seg = ast.get_source_segment(src, node)
assert seg is not None, "cycle function missing"
start = seg.index("    for qd in queries_to_run:")
end = seg.index("        _v808_queries_done += 1", start)
head = seg[start:end]
assert "AUTO_DISCOVERY_CYCLE_CAPPED" in head, "cap check not in loop head"
assert "break" in head, "cap break not in loop head"

class _Log:
    def info(self, *a, **k): pass
    def warning(self, *a, **k): pass
    def debug(self, *a, **k): pass
class _Stop:
    def is_set(self): return False
class _Pause:
    async def wait(self): return True

ran = []
ns = {
    "queries_to_run": [{"query": "q%02d" % i, "source": "builtin"}
                       for i in range(10)],
    "_VC_DISCOVERY_CYCLE_DEADLINE_MONO": time.monotonic() - 1.0,
    "time": time, "logger": _Log(),
    "_auto_discovery_stop": _Stop(),
    "_auto_discovery_pause": _Pause(),
    "_v808_queries_done": 0,
    "_v808_cycle_t0": time.monotonic() - 1.0,
    "_v808_cap": 90.0,
    "ran": ran, "asyncio": asyncio,
}
code = "async def _run():\n" + head + '        ran.append(qd["query"])\n'
exec(compile(code, "<cap>", "exec"), ns)
asyncio.run(ns["_run"]())
print("V9809_CAP " + json.dumps({"ran": ran}))
'''.replace("__VOICECHAT_PATH__", _VOICECHAT)
        try:
            proc = subprocess.run(
                [sys.executable, "-c", driver],
                capture_output=True, text=True, timeout=10.0)
        except subprocess.TimeoutExpired:
            self.fail("cap harness timed out")
        self.assertIn("V9809_CAP", proc.stdout, proc.stderr[:600])
        data = json.loads(
            [l for l in proc.stdout.splitlines()
             if l.startswith("V9809_CAP ")][0][10:])
        self.assertEqual(
            data["ran"], [],
            "with the deadline in the past NO query may start — "
            "the cap defers the whole batch")


# =============================================================================
# §6 — canary evidence regression (safety mechanism stays armed)
# =============================================================================

class TestCanarySafetyMechanismIntact(unittest.TestCase):
    """The canary is NOT the fix (FIX-CCC is) — but it must stay exactly
    as v98.08 shipped it so the next unrelated wedge is still dumped,
    retained, and exits 86. All markers re-asserted for v98.09."""

    def setUp(self):
        self.bs = _read(_BOOTSTRAP)
        self.seg = None
        tree = ast.parse(self.bs)
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) \
                    and node.name == "_vc_heartbeat_canary_thread_body":
                self.seg = ast.get_source_segment(self.bs, node)
        self.assertIsNotNone(self.seg)

    def test_canary_trigger_marker_unchanged(self):
        # The marker format string is split across two adjacent string
        # literals in the source — assert both fragments.
        self.assertIn("VC_HEARTBEAT_CANARY_TRIGGERED age=%.0fs "
                      "threshold=%.0fs ", self.seg)
        self.assertIn("pid=%d — event loop appears hard-blocked",
                      self.seg)

    def test_canary_dump_written_before_exit_86(self):
        self.assertIn("VC_HEARTBEAT_CANARY_DUMP_WRITTEN path=%s", self.seg)
        i_dump = self.seg.index("faulthandler.dump_traceback(file=_fh)")
        i_marker = self.seg.index("VC_HEARTBEAT_CANARY_DUMP_WRITTEN")
        i_exit = self.seg.index("os._exit(86)")
        self.assertLess(i_dump, i_marker)
        self.assertLess(i_marker, i_exit)

    def test_canary_retained_copy_preserved(self):
        self.assertIn("copyfile", self.seg)
        self.assertIn("vc_canary_dump_", self.seg)

    def test_canary_threshold_unchanged(self):
        self.assertIn("_VC_CANARY_STALE_THRESHOLD", self.bs)
        # v98.07 FIX-SS contract: 180s threshold, 10s check interval.
        self.assertRegex(
            self.bs, r"_VC_CANARY_STALE_THRESHOLD[^\n=]*=\s*180")
        self.assertRegex(
            self.bs, r"_VC_CANARY_CHECK_INTERVAL[^\n=]*=\s*10")

    def test_startup_recovery_and_supervisor_markers_unchanged(self):
        self.assertIn("STARTUP_RECOVERY prev_pid=%s", self.bs)
        self.assertIn("BOT_SUPERVISOR_DETECTED supervisor=%s", self.bs)
        self.assertIn("systemd", self.bs)

    def test_canary_thread_is_daemon_not_event_loop(self):
        """The canary watchdog runs in its OWN thread with time.sleep —
        it is the mechanism that SURVIVES an event-loop freeze; it must
        not be moved onto the event loop."""
        self.assertIn("_vc_heartbeat_canary_thread_body", self.bs)
        self.assertIn("daemon", self.bs)


class TestSupervisorDeploymentRequirements(unittest.TestCase):
    """v98.09 keeps the code/deployment separation: the CODE fixes the
    root cause; the DEPLOYMENT requirement (install + enable the systemd
    supervisor) is documented, not assumed."""

    def test_service_unit_ships(self):
        self.assertTrue(os.path.isfile(_SERVICE))

    def test_installer_script_ships(self):
        self.assertTrue(os.path.isfile(_INSTALLER))

    def test_deployment_md_documents_enablement(self):
        md = _read(_DEPLOY_MD).lower()
        self.assertIn("systemctl", md)
        self.assertIn("enable", md)
        self.assertIn("daemon-reload", md)

    def test_service_restart_always(self):
        svc = _read(_SERVICE)
        self.assertIn("Restart=always", svc)


# =============================================================================
# §S — source-level structural assertions (FIX-CCC shape)
# =============================================================================

class TestSourceShapeFixCCC(unittest.TestCase):
    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_helper_exists_with_regression_marker(self):
        seg = _extract(self.src, "_vc_discovery_select_queries_bounded")
        self.assertIsNotNone(seg)
        self.assertIn("v98.09 FIX-CCC", seg)
        self.assertIn("REGRESSION MARKER", seg)
        self.assertIn("2026-09-01", seg)
        self.assertIn("10077", seg)
        self.assertIn("25848", seg)

    def test_helper_docstring_documents_termination_invariants(self):
        seg = _extract(self.src, "_vc_discovery_select_queries_bounded")
        self.assertIn("appends >= 1 item", seg)
        self.assertIn("terminal slice", seg)
        self.assertIn("capacity is NEVER consulted", seg)

    def test_old_pattern_absent_from_executable_code(self):
        """The defective capacity-gated advance pattern must not exist in
        ANY function body (AST-level: while loops whose append conditions
        include a capacity check gating index advancement). The docstring
        reproduction is documentation, not executable code — AST ignores
        docstrings, so this check is immune to the marker text."""
        tree = ast.parse(self.src)
        offenders = []
        for node in ast.walk(tree):
            if not isinstance(node, ast.While):
                continue
            body_src = ast.get_source_segment(self.src, node) or ""
            # capacity-gated advance: '< max_q' gating an append whose
            # line also increments the index.
            if "< max_q" in body_src and ("ei += 1" in body_src or
                                          "xi += 1" in body_src):
                offenders.append(node.lineno)
        self.assertEqual(
            offenders, [],
            f"capacity-gated index advance reintroduced at lines "
            f"{offenders}")

    def test_cycle_head_calls_helper(self):
        seg = _extract(self.src, "_auto_discovery_run_one_cycle")
        self.assertIn("_vc_discovery_select_queries_bounded(merged, max_q)",
                      seg)

    def test_version_bumped(self):
        init = _read(os.path.join(_PKG_ROOT, "mediagrab_bot", "__init__.py"))
        # v98.12 TEST-MECHANISM CORRECTION (documented): this test guards
        # "__bot_version__ tracks the CURRENT artifact". v98.12 §21 bumped
        # v98.09 → v98.12 (the (6).log mixed-identity fix: the runtime
        # reported version=v99.00 while the file hashes were the v98.11
        # tree). The DEPLOYMENT_IDENTITY literal is now derived from
        # __bot_version__ (f-string), so the bootstrap pin asserts the
        # derivation site instead of a frozen literal.
        # v98.13 release bump: the current artifact version is v98.13
        # (the VC-JOIN-VERIFICATION release).
        self.assertIn('__bot_version__ = "v99.11.3"', init)
        self.assertIn('DEPLOYMENT_IDENTITY version={_v9812_pkg_version}', _read(_BOOTSTRAP))


def _extract(src: str, name: str):
    tree = ast.parse(src)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) \
                and node.name == name:
            return ast.get_source_segment(src, node)
    return None


if __name__ == "__main__":
    unittest.main(verbosity=2)
