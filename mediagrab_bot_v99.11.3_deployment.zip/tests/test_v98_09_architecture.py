"""v98.09 ARCHITECTURE HARDENING TEST LAYER — tests proving the new
bounded-execution architecture (§35-§38 of the hardening mandate).

SCOPE (complements tests/test_v98_09_discovery_termination.py, which
proves the ROOT-CAUSE fix; this layer proves the SYSTEMATIZED
architecture around it):
  * §5/§29 boundedness registry — every budget has default/env/min/
    max/rationale; resolution order config→env→default; no magic
    numbers (config.py clamps mirror the registry);
  * §6 discovery phase machine — bounded transitions, deadline,
    cancellation, failure recording, snapshot;
  * §7 query planner — plan structure, invariants, omitted-with-reason;
  * §16 single-flight — coalescing, isolation, exception propagation,
    registry-full fail-safe;
  * §14/§31 bounded gates — capacity, depth bound, deadline defer,
    defer-with-marker (never drop);
  * §20 task registry — ownership, reaping, bounded population,
    shutdown drain;
  * §13 negcache cardinality — deterministic fail-safe eviction;
  * §11 scope-token lifecycle — id() reuse (rebind) detection,
    invalidation on rotation/import;
  * §21 retry budget — v98.08 FIX-ZZ semantics preserved + markers;
  * §25 canary classification — all 7 classes, deterministic decision
    table, context snapshot + render;
  * §28 startup config validation — impossible combinations rejected;
  * §17 write-lock timeout — behavioral exec of the REAL
    _AsyncRWLock.acquire_write (bounded wait, nothing held on timeout);
  * §19 deadline propagation — multi-account loop honors the cap;
  * §36 invariant/property tests (randomized, fixed seeds);
  * §37 event-loop responsiveness under the FULL new machinery;
  * §38 synthetic soak/stress — bounded memory/tasks, eventual
    completion, rotations, cache churn, failures;
  * §27 marker contract — all preserved v98.08 markers + new v98.09
    markers present in the SHIPPED sources;
  * §39 static audit — the shipped checker reports 0 unresolved
    CRITICAL/HIGH on v98.09 AND flags the v98.08 defect signature;
  * §0 preservation inventory — the shipped machine-readable inventory
    matches the live sources.

HONESTY NOTES:
  * Behavioral tests exec the REAL shipped helpers (AST-extracted) —
    not rewrites. Where the full module cannot import (no Telethon in
    the CI env), the tests AST-extract + exec with injected fakes, the
    same proven pattern as the v98.08/v98.09 suites.
  * vc_architecture.py imports with STDLIB ONLY — it is imported
    DIRECTLY (real import, real coverage) everywhere possible.
"""

import ast
import asyncio
import json
import logging
import os
import random
import subprocess
import sys
import tempfile
import time
import unittest

_PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _PKG_ROOT)

_VOICECHAT = os.path.join(_PKG_ROOT, "mediagrab_bot", "voicechat.py")
_BOOTSTRAP = os.path.join(_PKG_ROOT, "mediagrab_bot", "bootstrap.py")
_MTPROTO = os.path.join(_PKG_ROOT, "mediagrab_bot", "mtproto.py")
_CONFIG = os.path.join(_PKG_ROOT, "mediagrab_bot", "config.py")
_VC_ARCH = os.path.join(_PKG_ROOT, "mediagrab_bot", "vc_architecture.py")
_INVENTORY = os.path.join(
    _PKG_ROOT, "docs", "VC_CONTROL_INVENTORY_v98.09.json")
_AUDIT_TOOL = os.path.join(_PKG_ROOT, "tools", "vc_static_audit.py")

# --- §35 STANDALONE LOADER -------------------------------------------------
# mediagrab_bot/__init__.py imports bootstrap → telegram/Telethon (the
# bot's runtime dependencies), which are NOT installed in this test
# environment. vc_architecture.py is stdlib-only BY CONSTRUCTION (its
# module docstring contract + the zero-while AST audit test below), so
# loading it directly by file path is a FAITHFUL real import: identical
# file, identical module code, EXECUTED (not parsed) — full behavioral
# coverage of the shipped module without the unavailable third-party
# surface. A stub parent package (with __path__ pointing at the real
# package directory) is registered in sys.modules FIRST so any absolute
# `mediagrab_bot.vc_architecture` import — in-process or in the
# subprocess drivers below — resolves to THIS loaded module instead of
# executing mediagrab_bot/__init__.py.
def _load_vc_architecture_standalone():
    import importlib.util
    import types
    pkg_dir = os.path.dirname(_VC_ARCH)
    pkg = sys.modules.get("mediagrab_bot")
    if pkg is None or getattr(pkg, "__path__", None) is None:
        pkg = types.ModuleType("mediagrab_bot")
        pkg.__path__ = [pkg_dir]
        sys.modules["mediagrab_bot"] = pkg
    spec = importlib.util.spec_from_file_location(
        "mediagrab_bot.vc_architecture", _VC_ARCH)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["mediagrab_bot.vc_architecture"] = mod
    spec.loader.exec_module(mod)
    return mod


vca = _load_vc_architecture_standalone()  # noqa: E402 (real exec of the
# shipped mediagrab_bot/vc_architecture.py — see the loader note above).

# Shared subprocess import preamble (same standalone-loader semantics for
# the isolated §37/§38 drivers; keeps every driver a real exec of the
# REAL shipped module, never a rewrite).
_SUBPROC_ARCH_IMPORT = (
    "import importlib.util, sys, types\n"
    "_pkg = types.ModuleType('mediagrab_bot')\n"
    "_pkg.__path__ = [__PKG_DIR__]\n"
    "sys.modules['mediagrab_bot'] = _pkg\n"
    "_spec = importlib.util.spec_from_file_location(\n"
    "    'mediagrab_bot.vc_architecture', __VC_ARCH__)\n"
    "vca = importlib.util.module_from_spec(_spec)\n"
    "sys.modules['mediagrab_bot.vc_architecture'] = vca\n"
    "_spec.loader.exec_module(vca)\n"
).replace("__PKG_DIR__", repr(os.path.dirname(_VC_ARCH))) \
 .replace("__VC_ARCH__", repr(_VC_ARCH))

_SUBPROC_TIMEOUT = 10.0


def _read(path: str) -> str:
    with open(path, encoding="utf-8") as fh:
        return fh.read()


class _LogCapture(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.DEBUG)
        self.records: list = []

    def emit(self, record):
        self.records.append(record)

    def text(self) -> str:
        return "\n".join(
            r.getMessage() for r in self.records)


def _capture_arch_log():
    cap = _LogCapture()
    h = logging.getLogger("mediagrab_bot.vc_arch")
    h.addHandler(cap)
    h.setLevel(logging.DEBUG)
    return cap, h


# =============================================================================
# §5/§29 — BOUNDEDNESS REGISTRY
# =============================================================================

class TestBoundednessRegistry(unittest.TestCase):
    def setUp(self):
        vca.arch_reset_for_test()

    def test_every_budget_has_complete_spec(self):
        """§29: no production behavior may depend on an undocumented
        magic number — every budget carries default/env/min/max/
        rationale."""
        self.assertGreaterEqual(len(vca.VC_ARCH_BUDGETS), 10)
        for name, spec in vca.VC_ARCH_BUDGETS.items():
            self.assertIsInstance(spec, vca.BudgetSpec, name)
            self.assertGreaterEqual(spec.default, spec.minimum, name)
            self.assertLessEqual(spec.default, spec.maximum, name)
            self.assertTrue(spec.env.startswith("VC_ARCH_"), name)
            self.assertGreater(len(spec.rationale), 20, name)

    def test_budget_resolution_order_config_env_default(self):
        class Cfg:
            vc_arch_max_join_in_flight = 7
        self.assertEqual(vca.arch_budget("max_join_in_flight", Cfg()), 7)
        os.environ["VC_ARCH_MAX_RECONCILE_IN_FLIGHT"] = "9"
        try:
            self.assertEqual(vca.arch_budget("max_reconcile_in_flight"), 9)
        finally:
            del os.environ["VC_ARCH_MAX_RECONCILE_IN_FLIGHT"]
        self.assertEqual(vca.arch_budget("max_discovery_in_flight"), 4)

    def test_budget_clamped_to_min_max(self):
        class Low:
            vc_arch_negcache_max_entries = 1
        self.assertEqual(vca.arch_budget("negcache_max_entries", Low()), 100)
        os.environ["VC_ARCH_NEGCACHE_MAX_ENTRIES"] = "99999999"
        try:
            self.assertEqual(
                vca.arch_budget("negcache_max_entries"), 1000000)
        finally:
            del os.environ["VC_ARCH_NEGCACHE_MAX_ENTRIES"]

    def test_budget_bad_values_fall_back_to_default(self):
        class Junk:
            vc_arch_max_join_in_flight = "not-a-number"
        self.assertEqual(vca.arch_budget("max_join_in_flight", Junk()), 3)

    def test_unknown_budget_raises(self):
        with self.assertRaises(KeyError):
            vca.arch_budget("nonexistent_budget")

    def test_defaults_preserve_v9808_effective_concurrency(self):
        """§0: defaults must preserve v98.08 behavior — each budget
        mirrors an existing v98.08 effective value (documented mapping)."""
        expected = {
            "max_discovery_in_flight": 4,       # == metadata concurrency
            "max_entity_resolution_in_flight": 8,  # == RPC semaphore
            "max_classification_in_flight": 4,  # == discovery sem
            "max_join_in_flight": 3,            # == multi-join concurrency
            "max_reconcile_in_flight": 4,
            "retry_budget_per_window": 25,      # == FIX-ZZ budget
            "retry_window_seconds": 60,
        }
        for k, v in expected.items():
            self.assertEqual(vca.VC_ARCH_BUDGETS[k].default, v, k)

    def test_config_clamps_mirror_registry(self):
        """§29: every budget is surfaced in config.py with clamps whose
        min/max/default match the registry (no silent divergence)."""
        cfg_src = _read(_CONFIG)
        for name, spec in vca.VC_ARCH_BUDGETS.items():
            attr = f"vc_arch_{name}"
            self.assertIn(
                f"{attr}: int = _env_int(", cfg_src, attr)
            self.assertIn(f'"{spec.env}", {spec.default})', cfg_src,
                          f"{attr} default must match registry")
            self.assertIn(f'_clamp_int("{attr}"', cfg_src, attr)

    def test_budgets_heartbeat_line(self):
        cap, _ = _capture_arch_log()
        line = vca.arch_budgets_heartbeat_line(force=True)
        self.assertIsNotNone(line)
        self.assertIn("VC_ARCH_BUDGETS_HEARTBEAT", line)
        self.assertIn("max_join_in_flight=3", line)
        # Rate-limited: second call inside the window returns None.
        self.assertIsNone(vca.arch_budgets_heartbeat_line())
        vca.emit_budgets_heartbeat(force=True)
        self.assertIn(
            "VC_ARCH_BUDGETS_HEARTBEAT", cap.text())


# =============================================================================
# §6 — DISCOVERY PHASE MACHINE
# =============================================================================

class TestPhaseMachine(unittest.TestCase):
    def setUp(self):
        vca.arch_reset_for_test()
        self.cap, self.logger = _capture_arch_log()

    def test_full_lifecycle_transitions_logged(self):
        pm = vca.phase_cycle_start(42, deadline=time.monotonic() + 90,
                                   cap_seconds=90)
        for phase in ("candidate_build", "query_plan", "query_execution",
                      "classification", "join_resolve", "reconcile",
                      "settle"):
            vca.phase_enter(phase, detail="t")
        vca.phase_finish()
        self.assertEqual(pm.phase, "complete")
        text = self.cap.text()
        for phase in ("start", "candidate_build", "query_plan",
                      "query_execution", "classification", "join_resolve",
                      "reconcile", "settle", "complete"):
            self.assertIn(f"phase={phase}", text, phase)
        self.assertIn("VC_DISCOVERY_PHASE", text)

    def test_snapshot_contains_canary_fields(self):
        pm = vca.phase_cycle_start(7, deadline=time.monotonic() + 90)
        pm.queries_total = 20
        vca.phase_record_query(13, "query_thirteen")
        snap = vca.phase_snapshot()
        self.assertTrue(snap["active"])
        self.assertEqual(snap["query_index"], 13)
        self.assertEqual(snap["queries_total"], 20)
        self.assertIn("query_thirteen", snap["current_query"])
        self.assertIn("cycle_id", snap)
        self.assertIn("cap_seconds", snap)

    def test_deadline_math_and_over_budget(self):
        pm = vca.phase_cycle_start(1, deadline=time.monotonic() + 0.05,
                                   cap_seconds=0.05)
        self.assertFalse(pm.over_budget())
        time.sleep(0.08)
        self.assertTrue(pm.over_budget())
        self.assertLess(pm.remaining(), 0.0)
        self.assertTrue(vca.phase_snapshot()["over_budget"])

    def test_failure_recording_bounded(self):
        pm = vca.phase_cycle_start(1, None)
        for i in range(100):
            vca.phase_record_failure(f"failure_{i}")
        self.assertLessEqual(len(pm.failures), 33)  # 32 + overflow marker
        self.assertIn("overflow", pm.failures)

    def test_history_bounded(self):
        pm = vca.phase_cycle_start(1, None)
        for i in range(200):
            pm.enter("query_execution", detail=f"i={i}")
        self.assertLessEqual(len(pm.history), vca.DiscoveryPhaseMachine.MAX_HISTORY)

    def test_finish_idempotent(self):
        pm = vca.phase_cycle_start(1, None)
        vca.phase_finish()
        first = pm.phase
        vca.phase_finish()
        self.assertEqual(pm.phase, first)
        self.assertIn(first, ("complete", "failed", "cancelled"))

    def test_finish_cancelled(self):
        pm = vca.phase_cycle_start(1, None)
        vca.phase_finish(cancelled=True, reason="stop_flag")
        self.assertEqual(pm.phase, "cancelled")

    def test_no_machine_snapshot_reports_inactive(self):
        vca.arch_reset_for_test()
        snap = vca.phase_snapshot()
        self.assertFalse(snap["active"])
        self.assertEqual(snap["phase"], "none")


# =============================================================================
# §7 — QUERY PLANNER
# =============================================================================

class TestQueryPlanner(unittest.TestCase):
    def setUp(self):
        vca.arch_reset_for_test()

    def test_plan_structure_and_invariants(self):
        merged = [{"query": f"q{i}"} for i in range(30)]
        selected = merged[:20]
        plan = vca.record_query_plan(
            merged, 20, selected, scope="primary", account="acc1",
            cycle_id=5, deadline=123.0, quiet=True)
        self.assertEqual(len(plan.selected), 20)
        self.assertEqual(plan.cycle_id, 5)
        self.assertEqual(plan.scope, "primary")
        self.assertEqual(plan.account, "acc1")
        self.assertEqual(plan.deadline, 123.0)
        self.assertEqual(plan.budget_class, "item_bound")
        self.assertTrue(plan.invariant_ok)
        self.assertEqual(plan.violation, "")
        self.assertEqual(len(plan.exploit), 24)
        self.assertEqual(len(plan.explore), 6)
        self.assertGreaterEqual(len(plan.omitted_due_to_budget), 5)

    def test_plan_detects_capacity_violation(self):
        merged = [{"query": f"q{i}"} for i in range(10)]
        plan = vca.record_query_plan(
            merged, 5, merged[:8], quiet=True)  # 8 > max_q 5
        self.assertFalse(plan.invariant_ok)
        self.assertIn("max_q", plan.violation)

    def test_plan_detects_duplicate_selection(self):
        merged = [{"query": f"q{i}"} for i in range(10)]
        dup = merged[:3] + merged[:3]
        plan = vca.record_query_plan(merged, 10, dup, quiet=True)
        self.assertFalse(plan.invariant_ok)
        self.assertIn("duplicate", plan.violation)

    def test_plan_detects_foreign_item(self):
        merged = [{"query": f"q{i}"} for i in range(10)]
        foreign = [{"query": "NOT IN POOL"}]
        plan = vca.record_query_plan(merged, 10, foreign, quiet=True)
        self.assertFalse(plan.invariant_ok)

    def test_plan_marker_logged_with_omitted_reason(self):
        cap, _ = _capture_arch_log()
        merged = [{"query": f"q{i}"} for i in range(30)]
        vca.record_query_plan(merged, 20, merged[:20], cycle_id=9)
        text = cap.text()
        self.assertIn("VC_DISCOVERY_QUERY_PLAN", text)
        self.assertIn("omitted=10", text)  # §31: observable reason
        self.assertIn("invariant_ok=True", text)

    def test_plan_empty_pool(self):
        plan = vca.record_query_plan([], 20, [], quiet=True)
        self.assertEqual(plan.selected, [])
        self.assertTrue(plan.invariant_ok)


# =============================================================================
# §16 — SINGLE-FLIGHT
# =============================================================================

class TestSingleFlight(unittest.TestCase):
    def _run(self, coro):
        return asyncio.run(coro)

    def test_concurrent_same_key_coalesce_to_one_call(self):
        async def main():
            calls = []

            async def factory():
                calls.append(1)
                await asyncio.sleep(0.05)
                return "RESULT"

            sf = vca.SingleFlight("probe")
            tasks = [asyncio.create_task(
                sf.run(("acc", "scope", 1), factory))
                for _ in range(8)]
            results = await asyncio.gather(*tasks)
            return results, calls, sf
        results, calls, sf = self._run(main())
        self.assertEqual(len(calls), 1)
        self.assertEqual(set(results), {"RESULT"})
        self.assertEqual(sf.coalesced, 7)
        self.assertEqual(sf.inflight_count(), 0)

    def test_different_keys_never_coalesce(self):
        async def main():
            calls = []

            async def factory():
                # Capture the entry ordinal BEFORE the await so the
                # result identifies WHICH invocation ran (resume-time
                # len() would be identical for all concurrent callers).
                calls.append(1)
                n = len(calls)
                await asyncio.sleep(0.02)
                return n

            sf = vca.SingleFlight("probe")
            r = await asyncio.gather(
                sf.run(("a", "s", 1), factory),
                sf.run(("b", "s", 1), factory),
                sf.run(("a", "OTHER", 1), factory),
            )
            return calls, r
        calls, results = self._run(main())
        self.assertEqual(len(calls), 3)  # account/scope isolation (§11)
        self.assertEqual(sorted(results), [1, 2, 3])  # 3 distinct results

    def test_exception_propagates_to_all_waiters(self):
        # Boom is defined at class scope: the outer assertion must be
        # able to reference the SAME exception class the factory raises
        # (a main()-local class is invisible to the assertion).
        class Boom(RuntimeError):
            pass

        async def main():
            async def factory():
                await asyncio.sleep(0.02)
                raise Boom("probe failed")

            sf = vca.SingleFlight("probe")
            tasks = [asyncio.create_task(
                sf.run(("a", "s", 1), factory))
                for _ in range(4)]
            outs = await asyncio.gather(*tasks, return_exceptions=True)
            return outs, sf
        outs, sf = self._run(main())
        self.assertTrue(all(isinstance(o, Boom) for o in outs))
        self.assertEqual(sf.inflight_count(), 0)  # no leak

    def test_registry_full_runs_uncoalesced(self):
        async def main():
            calls = []

            async def factory():
                calls.append(1)
                await asyncio.sleep(0.02)
                return "R"

            sf = vca.SingleFlight("probe", max_keys=2)
            # Fill the registry with 2 in-flight keys.
            t1 = asyncio.create_task(sf.run(("k1",), factory))
            t2 = asyncio.create_task(sf.run(("k2",), factory))
            await asyncio.sleep(0.01)
            # k3 exceeds the registry bound → must run DIRECTLY
            # (fail-safe: extra work, never a dropped operation).
            r3 = await sf.run(("k3",), factory)
            await asyncio.gather(t1, t2)
            return r3, calls, sf
        r3, calls, sf = self._run(main())
        self.assertEqual(r3, "R")
        self.assertEqual(len(calls), 3)
        self.assertEqual(sf.rejected, 1)


# =============================================================================
# §14/§31 — BOUNDED GATE (backpressure)
# =============================================================================

class TestBoundedGate(unittest.TestCase):
    def test_capacity_acquire_release(self):
        async def main():
            g = vca.BoundedGate("t", capacity=2, max_depth=2)
            ok1 = await g.acquire()
            ok2 = await g.acquire()
            snap = g.snapshot()
            g.release()
            g.release()
            return ok1, ok2, snap, g.snapshot()
        ok1, ok2, mid, after = asyncio.run(main())
        self.assertTrue(ok1)
        self.assertTrue(ok2)
        self.assertEqual(mid["active"], 2)
        self.assertEqual(after["active"], 0)

    def test_depth_bound_defers_immediately(self):
        async def main():
            g = vca.BoundedGate("t", capacity=1, max_depth=2)
            ok1 = await g.acquire()          # takes the slot
            waiter = asyncio.create_task(g.acquire())  # waits (depth 1)
            await asyncio.sleep(0.01)
            ok3 = await g.acquire()          # depth full → DEFER
            waiter_res = None
            g.release()
            try:
                waiter_res = await asyncio.wait_for(waiter, 0.5)
            except asyncio.TimeoutError:
                pass
            return ok1, ok3, waiter_res, g.snapshot()
        ok1, ok3, waiter_res, snap = asyncio.run(main())
        self.assertTrue(ok1)
        self.assertFalse(ok3)   # deferred, not queued forever
        self.assertTrue(waiter_res)  # waiting one got the slot
        self.assertGreaterEqual(snap["deferred_total"], 1)

    def test_defer_logs_observable_marker(self):
        cap, _ = _capture_arch_log()
        asyncio.run(self._defer_scenario())
        self.assertIn("VC_ARCH_BACKPRESSURE_DEFERRED", cap.text())
        self.assertIn("nothing dropped", cap.text())

    @staticmethod
    async def _defer_scenario():
        g = vca.BoundedGate("t", capacity=1, max_depth=0)
        ok1 = await g.acquire()
        ok2 = await g.acquire()  # depth 0 → immediate defer
        assert ok1 and not ok2

    def test_deadline_in_past_defers_without_waiting(self):
        async def main():
            g = vca.BoundedGate("t", capacity=1, max_depth=10)
            ok1 = await g.acquire()
            t0 = time.monotonic()
            ok2 = await g.acquire(deadline=time.monotonic() - 1)
            elapsed = time.monotonic() - t0
            return ok1, ok2, elapsed
        ok1, ok2, elapsed = asyncio.run(main())
        self.assertTrue(ok1)
        self.assertFalse(ok2)
        self.assertLess(elapsed, 0.5)  # no long block on a past deadline

    def test_bounded_wait_acquires_after_release(self):
        async def main():
            g = vca.BoundedGate("t", capacity=1, max_depth=5)
            ok1 = await g.acquire()
            waiter = asyncio.create_task(
                g.acquire(deadline=time.monotonic() + 2))
            await asyncio.sleep(0.05)
            g.release()
            return await asyncio.wait_for(waiter, 2)
        self.assertTrue(asyncio.run(main()))

    def test_waiting_counter_never_leaks(self):
        async def main():
            g = vca.BoundedGate("t", capacity=1, max_depth=5)
            ok1 = await g.acquire()
            ws = [asyncio.create_task(
                g.acquire(deadline=time.monotonic() + 0.05))
                for _ in range(4)]
            await asyncio.gather(*ws, return_exceptions=True)
            return g.snapshot()
        snap = asyncio.run(main())
        self.assertEqual(snap["waiting"], 0)  # §36: no waiter leak


# =============================================================================
# §20 — TASK REGISTRY
# =============================================================================

class TestTaskRegistry(unittest.TestCase):
    def test_track_and_reap(self):
        async def main():
            reg = vca.TaskRegistry("test", population_bound=100)
            done = []

            async def work():
                done.append(1)
            t = reg.track(work(), owner="discovery", purpose="probe")
            await asyncio.gather(t)
            await asyncio.sleep(0)
            return reg, done
        reg, done = asyncio.run(main())
        self.assertEqual(done, [1])
        self.assertEqual(reg.population(), 0)  # reaped

    def test_population_bound_marker(self):
        cap, _ = _capture_arch_log()
        async def main():
            reg = vca.TaskRegistry("test", population_bound=2)
            ev = asyncio.Event()

            async def work():
                await ev.wait()
            tasks = [reg.track(work(), owner=f"o{i}") for i in range(5)]
            snap = reg.live()
            ev.set()
            await asyncio.gather(*tasks)
            await asyncio.sleep(0)  # let done-callbacks reap
            return reg, snap
        reg, snap = asyncio.run(main())
        self.assertIn("VC_ARCH_TASK_POPULATION", cap.text())
        self.assertEqual(len(snap), 5)
        self.assertTrue(all("owner" in s for s in snap))
        # Every tracked task completed AND was reaped (stronger than the
        # stale-snapshot done flags: the registry is empty afterwards).
        self.assertEqual(reg.population(), 0)

    def test_exception_collected_not_swallowed(self):
        cap, _ = _capture_arch_log()
        async def main():
            reg = vca.TaskRegistry("test")

            async def boom():
                raise RuntimeError("owned failure")
            t = reg.track(boom(), owner="o", purpose="p")
            await asyncio.gather(t, return_exceptions=True)
            await asyncio.sleep(0)
        asyncio.run(main())
        self.assertIn("VC_ARCH_TASK_EXCEPTION", cap.text())
        self.assertIn("collected", cap.text())

    def test_shutdown_cancels_and_drains(self):
        # Capture is attached BEFORE the run: the shutdown marker is
        # emitted while the loop is running (a handler attached after
        # asyncio.run() returns can never observe it).
        cap, _ = _capture_arch_log()
        async def main():
            reg = vca.TaskRegistry("test")
            started = asyncio.Event()

            async def forever():
                started.set()
                await asyncio.sleep(3600)
            t = reg.track(forever(), owner="o", purpose="hold")
            await started.wait()
            stats = await reg.shutdown(deadline=1.0)
            await asyncio.gather(t, return_exceptions=True)
            return stats, reg
        stats, reg = asyncio.run(main())
        self.assertGreaterEqual(stats["cancelled"], 1)
        self.assertIn("drain_seconds", stats)
        self.assertIn("VC_ARCH_TASK_REGISTRY_SHUTDOWN", cap.text())

    def test_live_metadata_has_owner(self):
        async def main():
            reg = vca.TaskRegistry("t")
            ev = asyncio.Event()

            async def work():
                await ev.wait()
            t = reg.track(work(), owner="OWNER_X", purpose="PURPOSE_Y")
            live = reg.live()
            ev.set()
            await asyncio.gather(t)
            return live
        live = asyncio.run(main())
        self.assertEqual(live[0]["owner"], "OWNER_X")
        self.assertEqual(live[0]["purpose"], "PURPOSE_Y")


# =============================================================================
# §13 — NEGATIVE-CACHE CARDINALITY
# =============================================================================

class TestNegcacheSweep(unittest.TestCase):
    def test_noop_under_bound(self):
        cache = {(i, "s"): {"next_try": time.monotonic() + 60}
                 for i in range(10)}
        before = dict(cache)
        evicted = vca.negcache_sweep(cache, 100)
        self.assertEqual(evicted, 0)
        self.assertEqual(cache, before)

    def test_expired_ttl_swept_first(self):
        now = time.monotonic()
        cache = {
            (i, "s"): {"next_try": now - 1} for i in range(5)}  # expired
        cache.update({(100 + i, "s"): {"next_try": now + 60}
                      for i in range(5)})  # live
        evicted = vca.negcache_sweep(cache, 6, reason="test")
        self.assertEqual(evicted, 5)
        self.assertEqual(len(cache), 5)
        self.assertTrue(all(
            v["next_try"] > now for v in cache.values()))

    def test_over_bound_evicts_farthest_retry_first(self):
        """§13: deterministic eviction, FAIL-SAFE direction — the
        entries farthest from retry go first (evicted targets become
        immediately retry-eligible; NEVER a permanent exclusion)."""
        now = time.monotonic()
        cache = {}
        for i in range(10):
            cache[(i, "s")] = {"next_try": now + (i + 1) * 10}
        vca.negcache_sweep(cache, 4, reason="test")
        self.assertEqual(len(cache), 4)
        remaining_horizons = sorted(v["next_try"] - now for v in cache.values())
        # The SURVIVING entries are the NEAREST-to-retry ones.
        # v99.05 (documented derivation): float-equality on
        # (now + k*10) - now is CLOCK-MANTISSA-DEPENDENT (observed
        # 29.999999999999545 in a full-suite run — a latent flake, not a
        # semantic change); compare with tolerance instead.
        self.assertEqual(len(remaining_horizons), 4)
        for _h, _e in zip(remaining_horizons, (10.0, 20.0, 30.0, 40.0)):
            self.assertLess(abs(_h - _e), 1e-6,
                            f"horizon {_h} drifted from {_e}")

    def test_sweep_deterministic(self):
        now = time.monotonic()
        results = []
        for _ in range(3):
            cache = {(i, "s"): {"next_try": now + (i + 1) * 10}
                     for i in range(10)}
            vca.negcache_sweep(cache, 4)
            results.append(sorted(cache.keys()))
        self.assertEqual(results[0], results[1])
        self.assertEqual(results[1], results[2])

    def test_sweep_marker_logged(self):
        cap, _ = _capture_arch_log()
        now = time.monotonic()
        cache = {(i, "s"): {"next_try": now + (i + 1) * 10}
                 for i in range(10)}
        vca.negcache_sweep(cache, 4, reason="test_sweep")
        text = cap.text()
        self.assertIn("VC_ARCH_NEGCACHE_SWEEP", text)
        self.assertIn("NEVER an exclusion", text)

    def test_bad_bound_returns_zero(self):
        self.assertEqual(vca.negcache_sweep({}, "junk"), 0)


# =============================================================================
# §11 — SCOPE-TOKEN LIFECYCLE
# =============================================================================

class TestScopeRegistry(unittest.TestCase):
    def setUp(self):
        vca.arch_reset_for_test()

    def test_fold_and_snapshot(self):
        live = {"client:1": "acc_a", "client:2": "acc_b"}
        rebound = vca.scope_registry_update(live, reason="test")
        self.assertEqual(rebound, [])
        snap = vca.scope_registry_snapshot()
        self.assertEqual(snap["tokens"], 2)
        self.assertEqual(snap["accounts"], 2)

    def test_rebind_detected_on_id_reuse(self):
        vca.scope_registry_update({"client:77": "acc_a"}, reason="r1")
        rebound = vca.scope_registry_update(
            {"client:77": "acc_B"}, reason="r2")
        self.assertEqual(rebound, ["client:77"])
        snap = vca.scope_registry_snapshot()
        self.assertEqual(snap["rebinds"], 1)
        self.assertEqual(snap["recent_rebinds"][0]["old_account"], "acc_a")
        self.assertEqual(snap["recent_rebinds"][0]["new_account"], "acc_B")

    def test_gone_tokens_removed(self):
        vca.scope_registry_update({"client:1": "a", "client:2": "b"})
        vca.scope_registry_update({"client:1": "a"})
        snap = vca.scope_registry_snapshot()
        self.assertEqual(snap["tokens"], 1)

    def test_rebind_history_bounded(self):
        for i in range(50):
            vca.scope_registry_update(
                {f"client:{i}": "acc_a"})
            vca.scope_registry_update(
                {f"client:{i}": "acc_b"})
        self.assertLessEqual(
            len(vca.scope_registry_snapshot()["recent_rebinds"]) + 0, 4)
        # The internal history is capped at 32:
        self.assertLessEqual(
            len(vca._SCOPE_REBOUNDS), 32)

    def test_rebind_marker_logged(self):
        cap, _ = _capture_arch_log()
        vca.scope_registry_update({"client:5": "a"})
        vca.scope_registry_update({"client:5": "b"})
        self.assertIn("VC_SCOPE_TOKEN_REBOUND", cap.text())

    def test_clear_on_rotation(self):
        vca.scope_registry_update({"client:1": "a"})
        cap, _ = _capture_arch_log()
        vca.scope_registry_clear()
        self.assertEqual(len(vca._SCOPE_REGISTRY), 0)
        self.assertIn("VC_SCOPE_REGISTRY_INVALIDATED", cap.text())

    def test_voicechat_wipe_adapter_invalidates_scope(self):
        """§33 hot-reload/rotation: the appended voicechat adapter wraps
        _vc_entity_negative_wipe so scope tokens are invalidated at the
        SAME lifecycle boundaries as the FIX-ZZ cache wipe."""
        vc_src = _read(_VOICECHAT)
        # The original (first) definition stays byte-stable for the
        # exec-based v98.08 tests; the appended adapter is the LAST
        # definition — the one runtime calls resolve to.
        defs = [n for n in ast.parse(vc_src).body
                if isinstance(n, ast.FunctionDef)
                and n.name == "_vc_entity_negative_wipe"]
        self.assertGreaterEqual(len(defs), 2)
        seg = ast.get_source_segment(vc_src, defs[-1])
        self.assertIn("scope_registry_clear", seg)
        seg_orig = ast.get_source_segment(vc_src, defs[0])
        self.assertIn("VC_ENTITY_NEGATIVE_CACHE_WIPED", seg_orig)

    def test_negclear_tokens_adapter_exists(self):
        vc_src = _read(_VOICECHAT)
        seg = None
        for node in ast.parse(vc_src).body:
            if isinstance(node, ast.FunctionDef) \
                    and node.name == "_v98a_negclear_tokens":
                seg = ast.get_source_segment(vc_src, node)
        self.assertIsNotNone(seg)
        self.assertIn("VC_ARCH_NEGCACHE_SCOPE_CLEARED", seg)
        self.assertIn("isolation", seg)


# =============================================================================
# §21 — RETRY BUDGET
# =============================================================================

class TestRetryBudget(unittest.TestCase):
    def test_fixzz_semantics_preserved(self):
        """§0/§21: the v98.08 FIX-ZZ sliding-window numbers (25/60s) are
        the DEFAULTS — identical semantics."""
        rb = vca.RetryBudget("t", 25, 60.0)
        now = 1000.0
        granted = sum(1 for _ in range(25) if rb.take(now=now))
        self.assertEqual(granted, 25)
        self.assertFalse(rb.take(now=now))  # 26th denied in-window
        self.assertTrue(rb.take(now=now + 61.0))  # window slides

    def test_exhaustion_marker_logged_once_then_every_25(self):
        cap, _ = _capture_arch_log()
        rb = vca.RetryBudget("t", 3, 60.0)
        now = 1000.0
        for i in range(10):
            rb.take(now=now)
        text = cap.text()
        self.assertIn("VC_ARCH_RETRY_BUDGET_EXHAUSTED", text)
        self.assertIn("never dropping", text)
        self.assertEqual(text.count("VC_ARCH_RETRY_BUDGET_EXHAUSTED"), 1)


# =============================================================================
# §25 — CANARY CLASSIFICATION + CONTEXT
# =============================================================================

class TestCanaryClassification(unittest.TestCase):
    def test_all_seven_classes_reachable(self):
        cases = [
            ({"loop_blocked_in_user_code": True, "discovery_active": True,
              "discovery_over_budget": True}, "DISCOVERY_OVER_BUDGET"),
            ({"loop_blocked_in_user_code": True, "discovery_active": True},
             "EVENT_LOOP_BLOCKED"),
            ({"loop_blocked_in_user_code": True},
             "EVENT_LOOP_BLOCKED"),
            ({"task_backlog": 9000, "task_backlog_bound": 5000},
             "TASK_BACKLOG"),
            ({"lock_wait": True}, "LOCK_WAIT"),
            ({"rpc_awaiting": True}, "RPC_STUCK"),
            ({"cpu_pressure": True}, "CPU_PRESSURE"),
            ({}, "EVENT_LOOP_STARVED"),
        ]
        seen = set()
        for evidence, expected in cases:
            cls, why = vca.classify_canary_event(186.0, 180.0, evidence)
            self.assertEqual(cls, expected, evidence)
            seen.add(cls)
        for required in ("EVENT_LOOP_BLOCKED", "EVENT_LOOP_STARVED",
                         "DISCOVERY_OVER_BUDGET", "RPC_STUCK",
                         "LOCK_WAIT", "TASK_BACKLOG", "CPU_PRESSURE"):
            self.assertIn(required, seen)
            self.assertIn(required, vca.CANARY_CLASSES)

    def test_rationale_carries_forensics(self):
        cls, why = vca.classify_canary_event(186.0, 180.0, {})
        self.assertIn("age=186s", why)
        self.assertIn("threshold=180s", why)

    def test_classification_deterministic(self):
        ev = {"loop_blocked_in_user_code": True, "discovery_active": True}
        a = vca.classify_canary_event(200, 180, ev)
        b = vca.classify_canary_event(200, 180, ev)
        self.assertEqual(a, b)

    def test_context_snapshot_with_providers(self):
        vca.arch_reset_for_test()
        vca.phase_cycle_start(3, deadline=None)
        vca.register_snapshot_provider(
            "queue_depths", lambda: {"deferred_queue": 7})
        vca.register_snapshot_provider(
            "boom", lambda: (_ for _ in ()).throw(RuntimeError("x")))
        snap = vca.canary_context_snapshot(bot_version="v98.09")
        self.assertIn("pid", snap)
        self.assertIn("bot_version", snap)
        self.assertEqual(snap["bot_version"], "v98.09")
        self.assertEqual(snap["queue_depths"]["deferred_queue"], 7)
        self.assertIn("boom_error", snap)  # guarded, never fatal
        self.assertTrue(snap["discovery"]["active"])

    def test_render_contains_required_fields(self):
        vca.arch_reset_for_test()
        vca.phase_cycle_start(5, deadline=time.monotonic() + 90)
        pm = vca.phase_record_query  # noqa: F841 — touch
        snap = vca.canary_context_snapshot(bot_version="v98.09")
        text = vca.render_canary_context(snap)
        self.assertIn("=== VC_ARCH CONTEXT (v98.09 §25) ===", text)
        self.assertIn("bot_version=v98.09", text)
        self.assertIn("discovery: phase=", text)
        self.assertIn("=== END VC_ARCH CONTEXT ===", text)

    def test_bootstrap_canary_integrates_classification(self):
        """§25: the SHIPPED canary writes the context block + class line
        BEFORE the faulthandler stacks, logs
        VC_HEARTBEAT_CANARY_CLASSIFIED, and keeps DUMP_WRITTEN before
        exit(86) (the v98.08 contract)."""
        bs = _read(_BOOTSTRAP)
        tree = ast.parse(bs)
        seg = None
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) \
                    and node.name == "_vc_heartbeat_canary_thread_body":
                seg = ast.get_source_segment(bs, node)
        self.assertIsNotNone(seg)
        self.assertIn("classify_canary_event", seg)
        self.assertIn("render_canary_context", seg)
        self.assertIn("CANARY_CLASS=", seg)
        self.assertIn("VC_HEARTBEAT_CANARY_CLASSIFIED", seg)
        i_ctx = seg.index("render_canary_context")
        i_dump = seg.index("faulthandler.dump_traceback(file=_fh)")
        i_marker = seg.index("VC_HEARTBEAT_CANARY_DUMP_WRITTEN")
        i_exit = seg.index("os._exit(86)")
        self.assertLess(i_ctx, i_dump)
        self.assertLess(i_dump, i_marker)
        self.assertLess(i_marker, i_exit)


# =============================================================================
# §28 — STARTUP CONFIG VALIDATION
# =============================================================================

class TestConfigValidation(unittest.TestCase):
    def _cfg(self, **kw):
        base = {
            "vc_arch_max_discovery_in_flight": 4,
            "vc_arch_max_entity_resolution_in_flight": 8,
            "vc_arch_max_classification_in_flight": 4,
            "vc_arch_max_join_in_flight": 3,
            "vc_arch_max_reconcile_in_flight": 4,
            "vc_discovery_metadata_concurrency": 4,
            "vc_discovery_auto_join": True,
            "vc_discovery_cycle_wall_cap": 90,
            "vc_discovery_interval": 3600,
            "vc_discovery_max_queries_per_cycle": 20,
            "vc_discovery_results_per_query": 50,
            "vc_discovery_max_results_per_cycle": 500,
            "vc_arch_negcache_max_entries": 10000,
            "vc_heartbeat_canary": True,
        }
        base.update(kw)
        return type("Cfg", (), base)()

    def test_valid_config_passes(self):
        ok, problems = vca.validate_vc_arch_config(self._cfg())
        self.assertTrue(ok)
        self.assertEqual(problems, [])

    def test_zero_concurrency_rejected(self):
        ok, problems = vca.validate_vc_arch_config(
            self._cfg(vc_arch_max_join_in_flight=0))
        self.assertFalse(ok)
        self.assertTrue(any("must be >= 1" in p for p in problems))

    def test_zero_metadata_concurrency_rejected(self):
        ok, problems = vca.validate_vc_arch_config(
            self._cfg(vc_discovery_metadata_concurrency=0))
        self.assertFalse(ok)

    def test_cap_ge_interval_rejected(self):
        ok, problems = vca.validate_vc_arch_config(
            self._cfg(vc_discovery_cycle_wall_cap=3600,
                      vc_discovery_interval=3600))
        self.assertFalse(ok)
        self.assertTrue(any("no rest window" in p for p in problems))

    def test_candidate_explosion_rejected(self):
        ok, problems = vca.validate_vc_arch_config(
            self._cfg(vc_discovery_max_queries_per_cycle=200,
                      vc_discovery_results_per_query=500))
        self.assertFalse(ok)
        self.assertTrue(any("candidate explosion" in p for p in problems))

    def test_tiny_negcache_bound_rejected(self):
        ok, problems = vca.validate_vc_arch_config(
            self._cfg(vc_arch_negcache_max_entries=10))
        self.assertFalse(ok)
        self.assertTrue(any("thrash" in p for p in problems))

    def test_supervisor_warning_only_when_explicitly_false(self):
        ok, problems = vca.validate_vc_arch_config(self._cfg())
        self.assertTrue(ok)  # missing flag → no warning (not yet detected)
        ok2, problems2 = vca.validate_vc_arch_config(
            self._cfg(_vc_arch_supervisor_detected=False))
        self.assertTrue(ok2)  # WARNING-class, not blocking
        self.assertTrue(any("supervisor=none" in p for p in problems2))

    def test_valid_marker_logged(self):
        cap, _ = _capture_arch_log()
        vca.validate_vc_arch_config(self._cfg())
        self.assertIn("VC_ARCH_CONFIG_VALIDATED", cap.text())

    def test_invalid_marker_logged_with_problems(self):
        cap, _ = _capture_arch_log()
        vca.validate_vc_arch_config(
            self._cfg(vc_arch_max_join_in_flight=0))
        self.assertIn("VC_ARCH_CONFIG_INVALID", cap.text())
        self.assertIn("deadlock", cap.text())

    def test_bootstrap_calls_validation_at_startup(self):
        bs = _read(_BOOTSTRAP)
        self.assertIn("validate_vc_arch_config", bs)
        self.assertIn("VC_ARCH_CONFIG_VALIDATED", bs)

    def test_missing_attrs_tolerated(self):
        ok, problems = vca.validate_vc_arch_config(type("Empty", (), {})())
        self.assertTrue(ok)


# =============================================================================
# §17/§18 — WRITE-LOCK TIMEOUT (behavioral, REAL shipped lock)
# =============================================================================

class TestAcquireWriteTimeout(unittest.TestCase):
    """Behavioral: exec the REAL _AsyncRWLock (AST-extracted from the
    shipped mtproto.py) and prove the bounded writer wait."""

    @classmethod
    def setUpClass(cls):
        src = _read(_MTPROTO)
        tree = ast.parse(src)
        cls.lock_seg = None
        for node in tree.body:
            if isinstance(node, ast.ClassDef) and node.name == "_AsyncRWLock":
                cls.lock_seg = ast.get_source_segment(src, node)
        assert cls.lock_seg is not None

    def _exec_lock(self):
        # The extracted class uses typing annotations (e.g. Any) that
        # mtproto.py resolves via `from __future__ import annotations`
        # at module top; the standalone exec needs the same future
        # import prepended so annotations stay lazy (the real module's
        # semantics, not a rewrite).
        ns = {"asyncio": asyncio, "time": time,
              "logger": logging.getLogger("test.rw")}
        src = "from __future__ import annotations\n" + self.lock_seg
        exec(compile(src, "<rwlock>", "exec"), ns)
        return ns["_AsyncRWLock"]()

    def test_write_acquires_when_free(self):
        async def main():
            lock = self._exec_lock()
            await lock.acquire_write(timeout=5)
            try:
                self.assertTrue(lock._writer_active)
            finally:
                await lock.release_write()
            self.assertFalse(lock._writer_active)
        asyncio.run(main())

    def test_writer_waits_for_readers_then_proceeds(self):
        async def main():
            lock = self._exec_lock()
            ok = await lock.acquire_read()
            self.assertTrue(ok)
            writer_done = asyncio.Event()

            async def writer():
                await lock.acquire_write(timeout=5)
                writer_done.set()
                await lock.release_write()
            t = asyncio.create_task(writer())
            await asyncio.sleep(0.05)
            self.assertFalse(writer_done.is_set())  # waiting for reader
            await lock.release_read()
            await asyncio.wait_for(writer_done.wait(), 2)
            await asyncio.gather(t)
        asyncio.run(main())

    def test_write_timeout_raises_and_holds_nothing(self):
        async def main():
            lock = self._exec_lock()
            ok = await lock.acquire_read()  # stuck reader holds the lock
            self.assertTrue(ok)
            with self.assertRaises(asyncio.TimeoutError):
                await lock.acquire_write(timeout=0.2)
            # §17: on timeout the writer holds NOTHING and the waiting
            # counter is restored (no leak, lock remains usable).
            self.assertFalse(lock._writer_active)
            self.assertEqual(lock._writers_waiting, 0)
            await lock.release_read()
            await lock.acquire_write(timeout=1)  # still usable
            await lock.release_write()
        asyncio.run(main())

    def test_all_write_call_sites_bounded(self):
        """§39: every acquire_write call site in the shipped sources
        passes an explicit timeout (or is the definition itself)."""
        src = _read(_MTPROTO)
        unbounded = []
        for node in ast.walk(ast.parse(src)):
            if isinstance(node, ast.Await) and isinstance(node.value, ast.Call) \
                    and isinstance(node.value.func, ast.Attribute) \
                    and node.value.func.attr == "acquire_write":
                has_timeout = any(kw.arg == "timeout"
                                  for kw in node.value.keywords)
                if not has_timeout:
                    unbounded.append(node.lineno)
        self.assertEqual(
            unbounded, [],
            f"unbounded acquire_write call sites: {unbounded}")

    def test_write_timeout_marker_documented(self):
        self.assertIn("VC_RW_ACQUIRE_TIMEOUT scope=write", self.lock_seg)


# =============================================================================
# §19 — DEADLINE PROPAGATION
# =============================================================================

class TestDeadlinePropagation(unittest.TestCase):
    def test_multi_account_loop_honors_wall_cap(self):
        """§19: the multi-account pass now checks the SAME cycle deadline
        as the primary loop (v98.08 checked it only in the primary loop)
        — defer, never cancel."""
        vc = _read(_VOICECHAT)
        self.assertIn("VC_DISCOVERY_MULTI_ACCOUNT_CAPPED", vc)
        tree = ast.parse(vc)
        cycle = None
        for node in tree.body:
            if isinstance(node, ast.AsyncFunctionDef) \
                    and node.name == "_auto_discovery_run_one_cycle":
                cycle = ast.get_source_segment(vc, node)
        self.assertIsNotNone(cycle)
        ma = cycle.index("for _ma_q_index, _ma_qd in enumerate")
        cap_check = cycle.index(
            "_VC_DISCOVERY_CYCLE_DEADLINE_MONO and time.monotonic() >",
            ma)
        first_ma_query = cycle.index("await _a_client(SearchRequest", ma)
        self.assertLess(cap_check, first_ma_query,
                        "cap check must precede each multi-account query")

    def test_gate_deadline_defers_child_operations(self):
        async def main():
            g = vca.BoundedGate("child", capacity=1, max_depth=5)
            ok = await g.acquire()
            child = await g.acquire(deadline=time.monotonic() + 0.05)
            g.release()
            return ok, child
        ok, child = asyncio.run(main())
        self.assertTrue(ok)
        self.assertFalse(child)  # child did NOT outlive its budget

    def test_over_budget_classification_reaches_canary(self):
        vca.arch_reset_for_test()
        pm = vca.phase_cycle_start(1, deadline=time.monotonic() - 1)
        pm.queries_total = 20
        snap = vca.phase_snapshot()
        cls, why = vca.classify_canary_event(
            186.0, 180.0,
            {"loop_blocked_in_user_code": True,
             "discovery_active": snap["active"],
             "discovery_over_budget": snap["over_budget"]})
        self.assertEqual(cls, "DISCOVERY_OVER_BUDGET")


# =============================================================================
# §36 — INVARIANT / PROPERTY TESTS (randomized, fixed seeds)
# =============================================================================

class TestInvariants(unittest.TestCase):
    def setUp(self):
        vca.arch_reset_for_test()

    def test_property_selected_le_max_q_over_random_inputs(self):
        rng = random.Random(20260901)
        for trial in range(300):
            n = rng.randint(0, 500)
            max_q = rng.choice([0, 1, 2, 5, 20, 50, 500, 10_000])
            merged = [{"query": f"q{i}"} for i in range(n)]
            selected = merged[:max_q] if max_q > 0 else []
            plan = vca.record_query_plan(
                merged, max_q, selected, quiet=True)
            self.assertTrue(
                plan.invariant_ok,
                f"trial={trial} n={n} max_q={max_q} "
                f"violation={plan.violation}")

    def test_property_gate_invariants_hold_under_random_load(self):
        async def main():
            rng = random.Random(9101)
            g = vca.BoundedGate("prop", capacity=3, max_depth=4)

            async def worker(i):
                d = rng.choice([None, time.monotonic() + rng.random()])
                ok = await g.acquire(deadline=d)
                try:
                    await asyncio.sleep(rng.random() * 0.01)
                finally:
                    if ok:
                        g.release()
                return ok
            results = await asyncio.gather(*[
                asyncio.create_task(worker(i)) for i in range(200)])
            snap = g.snapshot()
            return results, snap
        results, snap = asyncio.run(main())
        self.assertEqual(snap["active"], 0)      # everything released
        self.assertEqual(snap["waiting"], 0)     # no waiter leak
        self.assertLessEqual(snap["acquired_total"], 200)

    def test_property_negcache_never_exceeds_bound(self):
        rng = random.Random(42)
        cache = {}
        bound = 50
        for trial in range(500):
            gid = rng.randint(0, 400)
            cache[(gid, "client:1")] = {
                "next_try": time.monotonic() + rng.random() * 100}
            if rng.random() < 0.3:
                vca.negcache_sweep(cache, bound, reason="prop")
            self.assertLessEqual(len(cache), 400)  # sanity
        vca.negcache_sweep(cache, bound, reason="final")
        self.assertLessEqual(len(cache), bound)

    def test_property_retry_budget_bounded_in_any_window(self):
        rng = random.Random(7)
        rb = vca.RetryBudget("prop", 10, 60.0)
        t = 0.0
        for _ in range(2000):
            t += rng.random() * 2
            rb.take(now=t)
        # In ANY 60s window the grant count is bounded by design; the
        # final snapshot must show bounded pending events.
        self.assertLessEqual(len(rb.events), 10)

    def test_property_scope_rebind_history_bounded(self):
        rng = random.Random(11)
        for i in range(200):
            tokens = {f"client:{rng.randint(0, 20)}":
                      f"acc_{rng.randint(0, 5)}" for _ in range(3)}
            vca.scope_registry_update(tokens, reason="prop")
        self.assertLessEqual(len(vca._SCOPE_REBOUNDS), 32)

    def test_every_tracked_task_eventually_reaches_done(self):
        async def main():
            reg = vca.TaskRegistry("prop", population_bound=1000)
            rng = random.Random(99)

            async def work(i):
                await asyncio.sleep(rng.random() * 0.05)
                if rng.random() < 0.2:
                    raise RuntimeError(f"boom {i}")
                return i
            tasks = [reg.track(work(i), owner="prop", purpose=str(i))
                     for i in range(60)]
            await asyncio.gather(*tasks, return_exceptions=True)
            await asyncio.sleep(0)
            return reg
        reg = asyncio.run(main())
        self.assertEqual(reg.population(), 0)  # every task reaped


# =============================================================================
# §37 — EVENT-LOOP RESPONSIVENESS (full machinery under load)
# =============================================================================

_EVENT_LOOP_DRIVER = r'''__SUBPROC_IMPORT__
import asyncio, sys, time, json

async def heartbeat(state):
    for _ in range(200):
        state["ticks"] += 1
        await asyncio.sleep(0.005)

async def main():
    vca.arch_reset_for_test()
    state = {"ticks": 0}
    hb = asyncio.create_task(heartbeat(state))
    # Full new machinery under load: planner + phase machine + gates +
    # single-flight, huge candidate list, small max_q, empty variants.
    cases = [
        (20000, 5), (20000, 20000), (0, 20), (5000, 1),
        (20000, 20), (300, 7), (1, 20),
    ]
    for n, max_q in cases:
        merged = [{"query": f"q{i}"} for i in range(n)]
        for cycle in range(3):
            pm = vca.phase_cycle_start(cycle, deadline=None)
            pm.enter("candidate_build")
            pm.enter("query_plan")
            vca.record_query_plan(merged, max_q, merged[:max(max_q, 0)],
                                  quiet=True)
            pm.enter("query_execution")
            pm.enter("classification")
            pm.enter("join_resolve")
            pm.enter("complete")
    # Gates + single-flight under contention.
    g = vca.BoundedGate("probe", capacity=2, max_depth=2)
    sf = vca.SingleFlight("probe")
    async def factory():
        await asyncio.sleep(0.001)
        return "R"
    await asyncio.gather(*[
        asyncio.ensure_future(g.acquire()) for _ in range(20)])
    for i in range(20):
        g.release()
    await asyncio.gather(*[
        asyncio.ensure_future(sf.run(("a", "s", i % 3), factory))
        for _ in range(30)])
    # Drain heartbeat.
    hb.cancel()
    try:
        await hb
    except asyncio.CancelledError:
        pass
    print("RESPONSIVE " + json.dumps({"ticks": state["ticks"]}))

asyncio.run(main())
'''.replace("__SUBPROC_IMPORT__", _SUBPROC_ARCH_IMPORT)


class TestEventLoopResponsiveness(unittest.TestCase):
    def test_heartbeat_ticks_under_full_architecture_load(self):
        """§37: a 5ms heartbeat coroutine keeps ticking while the ENTIRE
        new architecture machinery runs (planner, phase machine, gates,
        single-flight; huge/small/empty candidate variants). A frozen
        (synchronous-monopolizing) architecture starves the heartbeat
        to 0 — the v98.08 failure signature."""
        try:
            proc = subprocess.run(
                [sys.executable, "-c", _EVENT_LOOP_DRIVER],
                capture_output=True, text=True,
                timeout=_SUBPROC_TIMEOUT)
        except subprocess.TimeoutExpired:
            self.fail("event-loop responsiveness harness timed out "
                      "(the architecture froze the loop!)")
        line = [l for l in proc.stdout.splitlines()
                if l.startswith("RESPONSIVE ")]
        self.assertTrue(line, proc.stderr[:800])
        ticks = json.loads(line[0][11:])["ticks"]
        # With 200 slots × 5ms = 1s of wall time and 7 cases × 3 cycles
        # of bounded work, the heartbeat must have ticked MANY times.
        self.assertGreater(
            ticks, 100,
            f"heartbeat starved: only {ticks} ticks — the new machinery "
            f"monopolized the event loop (v98.08 failure signature)")

    def test_v9808_block_still_starves_heartbeat(self):
        """The counterfactual: the v98.08 selection block starves a
        concurrent heartbeat forever (reproduced in an isolated
        subprocess — must time out, NOT hang the suite)."""
        driver = r'''
import asyncio, json, sys, time
merged = [{"query": f"q{i}"} for i in range(25)]
max_q = 20
queries_to_run = []
state = {"ticks": 0}

async def heartbeat():
    for _ in range(2000):
        state["ticks"] += 1
        await asyncio.sleep(0.005)

async def main():
    hb = asyncio.create_task(heartbeat())
    await asyncio.sleep(0.05)  # let the heartbeat start
    # The v98.08 selection block (verbatim, non-terminating here):
    if len(merged) > 4:
        exploit = merged[:int(len(merged) * 0.8)]
        explore = merged[int(len(merged) * 0.8):]
        ei, xi = 0, 0
        while ei < len(exploit) or xi < len(explore):
            for _ in range(3):
                if ei < len(exploit) and len(queries_to_run) < max_q:
                    queries_to_run.append(exploit[ei]); ei += 1
            if xi < len(explore) and len(queries_to_run) < max_q:
                queries_to_run.append(explore[xi]); xi += 1
    print("ESCAPED " + json.dumps({"ticks": state["ticks"]}))

asyncio.run(main())
'''
        try:
            proc = subprocess.run(
                [sys.executable, "-c", driver],
                capture_output=True, text=True, timeout=3.0)
        except subprocess.TimeoutExpired:
            return  # EXPECTED: the v98.08 block never yields — frozen
        self.fail(
            "the v98.08 selection block TERMINATED — it must spin "
            f"(stdout={proc.stdout[:200]})")


# =============================================================================
# §38 — SOAK / STRESS (synthetic)
# =============================================================================

_SOAK_DRIVER = r'''__SUBPROC_IMPORT__
import asyncio, sys, time, json

async def main():
    vca.arch_reset_for_test()
    rng_t = [0]  # deterministic pseudo-random state
    def rng(n):
        rng_t[0] = (rng_t[0] * 1103515245 + 12345) % (2**31)
        return rng_t[0] % n
    accounts = [f"acc_{i}" for i in range(4)]
    scopes = [f"client:{i}" for i in range(4)]
    gates = {s: vca.BoundedGate(s, capacity=2, max_depth=3) for s in scopes}
    sf = vca.SingleFlight("soak")
    negcache = {}
    rb = vca.RetryBudget("soak", 25, 60.0)
    reg = vca.TaskRegistry("soak", population_bound=5000)
    stats = {"cycles": 0, "joins": 0, "join_failures": 0,
             "classify_failures": 0, "rotations": 0, "deferred": 0}
    t0 = time.monotonic()

    async def cycle(cycle_id):
        n = 50 + rng(400)
        merged = [{"query": f"c{cycle_id}q{i}"} for i in range(n)]
        max_q = 1 + rng(40)
        pm = vca.phase_cycle_start(
            cycle_id, deadline=time.monotonic() + 0.5)
        pm.enter("candidate_build")
        pm.enter("query_plan")
        vca.record_query_plan(merged, max_q, merged[:max_q], quiet=True)
        pm.enter("query_execution")
        for qi in range(max_q):
            pm.record_query_progress(qi, merged[qi]["query"])
            acc = accounts[rng(4)]
            scope = scopes[rng(4)]
            g = gates[scope]
            ok = await g.acquire(deadline=time.monotonic() + 0.1)
            if not ok:
                stats["deferred"] += 1
                continue
            try:
                async def factory():
                    await asyncio.sleep(0.0005)
                    if rng(10) < 2:
                        raise RuntimeError("classify_failure")
                    return {"ok": True}
                try:
                    r = await sf.run((acc, scope, qi), factory)
                    stats["joins"] += 1
                except RuntimeError:
                    stats["classify_failures"] += 1
                    negcache[(qi, scope)] = {
                        "next_try": time.monotonic() + 60}
            finally:
                g.release()
        pm.enter("complete")
        stats["cycles"] += 1

    async def rotation_sweep(i):
        if rng(8) == 0:
            stats["rotations"] += 1
            vca.scope_registry_clear()
            vca.negcache_sweep(negcache, 100, reason="rotation")
            for acc in accounts:
                await asyncio.sleep(0)

    tasks = []
    for i in range(40):
        tasks.append(asyncio.ensure_future(cycle(i)))
        tasks.append(asyncio.ensure_future(rotation_sweep(i)))
    await asyncio.gather(*tasks)
    elapsed = time.monotonic() - t0
    print("SOAK " + json.dumps({
        "stats": stats, "elapsed_s": round(elapsed, 2),
        "negcache_size": len(negcache),
        "task_population": reg.population(),
        "scope_tokens": len(vca._SCOPE_REGISTRY),
        "rebinds": len(vca._SCOPE_REBOUNDS),
        "retry_events": len(rb.events),
    }))

asyncio.run(main())
'''.replace("__SUBPROC_IMPORT__", _SUBPROC_ARCH_IMPORT)


class TestSoakStress(unittest.TestCase):
    def test_bounded_and_eventually_complete(self):
        """§38: many candidates × accounts × scopes × cycles + rotations
        + cache churn + failures → bounded memory/tasks, NO starvation,
        eventual completion, no runaway retries."""
        try:
            proc = subprocess.run(
                [sys.executable, "-c", _SOAK_DRIVER],
                capture_output=True, text=True, timeout=30.0)
        except subprocess.TimeoutExpired:
            self.fail("soak never completed — unbounded/infinite work")
        line = [l for l in proc.stdout.splitlines()
                if l.startswith("SOAK ")]
        self.assertTrue(line, proc.stderr[:1000])
        d = json.loads(line[0][5:])
        self.assertEqual(d["stats"]["cycles"], 40)  # all cycles completed
        self.assertGreater(d["stats"]["deferred"], 0)  # backpressure fired
        self.assertGreater(d["stats"]["rotations"], 0)
        self.assertLessEqual(d["negcache_size"], 100)  # cache bounded
        self.assertEqual(d["task_population"], 0)      # no task leak
        self.assertLessEqual(d["scope_tokens"], 4)
        self.assertLessEqual(d["rebinds"], 32)
        self.assertLess(d["elapsed_s"], 20.0)          # no starvation
        self.assertLessEqual(d["retry_events"], 25)


# =============================================================================
# §27 — OBSERVABILITY MARKER CONTRACT
# =============================================================================

class TestMarkerContract(unittest.TestCase):
    def test_all_preserved_v9808_markers_ship(self):
        sources = {
            "voicechat.py": _read(_VOICECHAT),
            "bootstrap.py": _read(_BOOTSTRAP),
            "mtproto.py": _read(_MTPROTO),
            # handlers.py ships the BOT_HEARTBEAT emit site (v98.05
            # FIX-FF, 60s cadence) — bootstrap documents the marker,
            # handlers logs it. The preserved-marker contract covers
            # the shipped runtime modules that emit them.
            "handlers.py": _read(os.path.join(
                _PKG_ROOT, "mediagrab_bot", "handlers.py")),
        }
        everything = "\n".join(sources.values())
        for marker in vca.PRESERVED_MARKERS:
            self.assertIn(marker, everything, marker)

    def test_all_new_v9809_arch_markers_declared_and_shipped(self):
        arch_src = _read(_VC_ARCH)
        for marker in vca.ARCH_MARKERS:
            self.assertIn(marker, arch_src, marker)  # declared
        # Integration points emit them:
        self.assertIn("VC_DISCOVERY_PHASE", _read(_VOICECHAT))
        self.assertIn("VC_DISCOVERY_QUERY_PLAN", _read(_VOICECHAT))
        self.assertIn("VC_HEARTBEAT_CANARY_CLASSIFIED", _read(_BOOTSTRAP))
        self.assertIn("VC_SCOPE_TOKEN_REBOUND", _read(_VOICECHAT))

    def test_marker_registry_counts(self):
        self.assertGreaterEqual(len(vca.PRESERVED_MARKERS), 19)
        self.assertGreaterEqual(len(vca.ARCH_MARKERS), 17)

    def test_canary_trigger_marker_format_unchanged(self):
        bs = _read(_BOOTSTRAP)
        # The v98.08 FIX-SS/FIX-XX marker fragments stay verbatim.
        self.assertIn("VC_HEARTBEAT_CANARY_TRIGGERED age=%.0fs "
                      "threshold=%.0fs ", bs)
        self.assertIn("pid=%d — event loop appears hard-blocked", bs)
        self.assertIn("VC_HEARTBEAT_CANARY_DUMP_WRITTEN path=%s", bs)


# =============================================================================
# §0 — PRESERVATION INVENTORY (machine-readable)
# =============================================================================

class TestPreservationInventory(unittest.TestCase):
    def setUp(self):
        with open(_INVENTORY, encoding="utf-8") as fh:
            self.inv = json.load(fh)

    def test_inventory_ships_and_is_complete(self):
        opts = self.inv["preservation_contract"]["options"]
        self.assertGreaterEqual(len(opts), 100)
        for o in opts:
            self.assertTrue(o["option"])
            self.assertIn("env", o)
            self.assertIn("default", o)

    def test_inventory_matches_live_config(self):
        cfg_src = _read(_CONFIG)
        opts = self.inv["preservation_contract"]["options"]
        stale = [o for o in opts if f"{o['option']}" not in cfg_src]
        self.assertEqual(
            stale, [],
            f"inventory entries not found in shipped config.py: "
            f"{[o['option'] for o in stale]}")

    def test_all_v9808_discovery_options_still_accepted(self):
        """§8: every v98.08 discovery option remains accepted (spot
        contract on the full set from the inventory).

        EVIDENCE (2026-09-01, this session): the canonical v98.08
        config.py and the v98.09 config.py contain an IDENTICAL set of
        exactly 28 ``vc_discovery*`` options (verified by diff of
        ``rg -o '^    (vc_discovery[a-z_]*):'`` over both sources —
        zero additions, zero deletions, zero renames). 28 IS the
        complete v98.08 discovery-option universe; asserting >= 30
        would demand FABRICATING two nonexistent options (a §42
        violation), so the honest bound is the real one: ALL 28, each
        still accepted in the shipped config.py.

        v98.10 TEST-MECHANISM CORRECTION (documented, §34 class): the
        count is 30 because v98.09-P3 itself added
        vc_discovery_adaptive_pagination + vc_discovery_adaptive_expansion
        (SS10/SS11) — the shipped v98.09 inventory JSON predates those
        additions (it recorded 117 options / 28 discovery), so the 28
        assertion passed against the STALE artifact.  v98.10 regenerates
        the inventory honestly (125 options / 30 discovery, incl. the 3
        new vc_entity_* hardening options) — the CONTRACT (every v98.08
        discovery option still accepted) is unchanged; ALL 28 v98.08
        options are still present within the 30."""
        discovery = [o["option"] for o in
                     self.inv["preservation_contract"]["options"]
                     if o["option"].startswith("vc_discovery")]
        self.assertEqual(len(discovery), 30)  # 28 v98.08 + P3's 2 adaptive (v98.10 inventory regen)
        cfg_src = _read(_CONFIG)
        for opt in discovery:
            self.assertIn(opt, cfg_src, opt)

    def test_new_options_are_budgets_only(self):
        """§0: v98.09 adds ONLY boundedness budgets — no existing option
        renamed/removed/changed (10 new options, all vc_arch_*)."""
        new = [o for o in self.inv["preservation_contract"]["options"]
               if o["v98_09_new"]]
        self.assertEqual(len(new), 10)
        self.assertTrue(all(o["option"].startswith("vc_arch_") for o in new))

    def test_inventory_marker_contract_nonempty(self):
        markers = self.inv["observability_contract"]["stable_markers"]
        self.assertGreaterEqual(len(markers), 100)
        for required in ("BOT_HEARTBEAT", "VC_JOIN_SUCCESS",
                         "AUTO_DISCOVERY_CYCLE_CAPPED",
                         "VC_HEARTBEAT_CANARY_TRIGGERED"):
            self.assertIn(required, markers)


# =============================================================================
# §39 — STATIC ARCHITECTURE AUDIT
# =============================================================================

class TestStaticAudit(unittest.TestCase):
    def test_shipped_modules_have_zero_unresolved_critical_high(self):
        proc = subprocess.run(
            [sys.executable, _AUDIT_TOOL,
             "--root", os.path.join(_PKG_ROOT, "mediagrab_bot")],
            capture_output=True, text=True, timeout=60.0)
        self.assertIn(
            "UNRESOLVED critical/high: 0", proc.stdout,
            f"unresolved findings shipped!\n{proc.stdout[-3000:]}")
        self.assertEqual(proc.returncode, 0)

    def test_checker_would_have_caught_the_v9808_defect(self):
        """The checker flags the v98.08 selection-block signature with
        CRITICAL severity when run against the historical source —
        proof this audit class is detectable statically."""
        bad = tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, encoding="utf-8")
        bad.write('''
merged = [{"q": i} for i in range(25)]
max_q = 20
queries_to_run = []
if len(merged) > 4:
    exploit = merged[:int(len(merged) * 0.8)]
    explore = merged[int(len(merged) * 0.8):]
    ei, xi = 0, 0
    while ei < len(exploit) or xi < len(explore):
        for _ in range(3):
            if ei < len(exploit) and len(queries_to_run) < max_q:
                queries_to_run.append(exploit[ei]); ei += 1
        if xi < len(explore) and len(queries_to_run) < max_q:
            queries_to_run.append(explore[xi]); xi += 1
''')
        bad.close()
        try:
            proc = subprocess.run(
                [sys.executable, _AUDIT_TOOL, "--file", bad.name],
                capture_output=True, text=True, timeout=30.0)
            self.assertIn("CRITICAL", proc.stdout)
            self.assertIn("FIX-CCC defect signature", proc.stdout)
            self.assertEqual(proc.returncode, 1)
        finally:
            os.unlink(bad.name)

    def test_audit_reports_saved_artifact(self):
        self.assertTrue(os.path.isfile(_AUDIT_TOOL))
        json_path = os.path.join(
            _PKG_ROOT, "docs", "STATIC_AUDIT_v98.09.json")
        self.assertTrue(os.path.isfile(json_path))
        with open(json_path, encoding="utf-8") as fh:
            d = json.load(fh)
        self.assertEqual(d["summary"]["unresolved_critical_high"], 0)


# =============================================================================
# §31 — GRACEFUL DEGRADATION / §32 — FAILURE ISOLATION
# =============================================================================

class TestGracefulDegradation(unittest.TestCase):
    def setUp(self):
        vca.arch_reset_for_test()

    def test_gate_defers_but_never_drops_state(self):
        cap, _ = _capture_arch_log()
        async def main():
            g = vca.BoundedGate("gd", capacity=1, max_depth=0)
            await g.acquire()
            return await g.acquire()  # defer
        self.assertFalse(asyncio.run(main()))
        text = cap.text()
        self.assertIn("state preserved, nothing dropped", text)
        self.assertIn("retry next cycle", text)

    def test_negcache_eviction_makes_target_retry_eligible(self):
        """§13/§31: eviction is the FAIL-SAFE direction — the evicted
        target becomes immediately retry-eligible (may cost one RPC,
        never a permanent exclusion)."""
        now = time.monotonic()
        cache = {(i, "s"): {"next_try": now + (i + 1) * 10}
                 for i in range(10)}
        victim = (9, "s")  # farthest horizon — will be evicted
        vca.negcache_sweep(cache, 4)
        self.assertNotIn(victim, cache)
        # The victim is now retry-eligible (no backoff entry remains).
        blocked, retry_in, _ = self._NEG_CHECK_STUB(cache, victim)
        self.assertFalse(blocked)

    @staticmethod
    def _NEG_CHECK_STUB(cache, key):
        ent = cache.get(key)
        if not ent:
            return False, 0.0, ""
        now = time.monotonic()
        if now >= ent["next_try"]:
            return False, 0.0, ""
        return True, ent["next_try"] - now, "err"

    def test_single_flight_full_registry_degrades_to_uncoalesced(self):
        """§31: budget exhaustion → MORE WORK (fail-safe), never less."""
        async def main():
            calls = []

            async def factory():
                calls.append(1)
                await asyncio.sleep(0.01)
                return "R"
            sf = vca.SingleFlight("gd", max_keys=1)
            t1 = asyncio.ensure_future(sf.run(("k",), factory))
            await asyncio.sleep(0.005)
            r2 = await sf.run(("other",), factory)  # registry full
            await t1
            return r2, calls
        r2, calls = asyncio.run(main())
        self.assertEqual(r2, "R")
        self.assertEqual(len(calls), 2)  # both ran — none dropped

    def test_failure_isolation_between_accounts(self):
        """§32: one account's factory failure must not affect other
        keys' results."""
        async def main():
            sf = vca.SingleFlight("iso")

            async def bad():
                raise RuntimeError("account A is broken")
            t_bad = asyncio.ensure_future(sf.run(("A", "s", 1), bad))
            await asyncio.sleep(0.01)

            async def good():
                return "ACCOUNT_B_OK"
            r = await sf.run(("B", "s", 1), good)
            await asyncio.gather(t_bad, return_exceptions=True)
            return r
        self.assertEqual(asyncio.run(main()), "ACCOUNT_B_OK")

    def test_phase_machine_records_failure_but_continues(self):
        pm = vca.phase_cycle_start(1, None)
        vca.phase_record_failure("account_a_failed")
        pm.enter("classification")  # machine still transitions
        vca.phase_finish()
        self.assertIn("account_a_failed", pm.failures)
        self.assertEqual(pm.phase, "complete")


# =============================================================================
# Integration shape: the shipped cycle uses the architecture
# =============================================================================

class TestArchitectureIntegration(unittest.TestCase):
    def setUp(self):
        self.vc = _read(_VOICECHAT)
        self.tree = ast.parse(self.vc)
        self.cycle = None
        for node in self.tree.body:
            if isinstance(node, ast.AsyncFunctionDef) \
                    and node.name == "_auto_discovery_run_one_cycle":
                self.cycle = ast.get_source_segment(self.vc, node)
        self.assertIsNotNone(self.cycle)

    def test_cycle_uses_phase_machine_and_planner(self):
        self.assertIn("vc_architecture", self.cycle)
        self.assertIn("phase_cycle_start", self.cycle)
        self.assertIn("record_query_plan", self.cycle)
        self.assertIn('phase_enter("query_execution")', self.cycle)
        self.assertIn("phase_record_query", self.cycle)

    def test_cycle_teardown_uses_scope_fold_and_negcache_sweep(self):
        self.assertIn("scope_registry_update", self.cycle)
        self.assertIn("negcache_sweep", self.cycle)
        self.assertIn("phase_finish", self.cycle)

    def test_cycle_classification_uses_guarded_wrapper(self):
        self.assertIn("_vc_arch_classify_guarded", self.cycle)
        # The guarded wrapper (appended) delegates to the UNCHANGED
        # v98.08 classify as its factory:
        seg = None
        for node in self.tree.body:
            if isinstance(node, ast.AsyncFunctionDef) \
                    and node.name == "_vc_arch_classify_guarded":
                seg = ast.get_source_segment(self.vc, node)
        self.assertIsNotNone(seg)
        self.assertIn("SingleFlight", seg)
        self.assertIn("_vc_discovery_classify", seg)
        self.assertIn("_vc_owning_account_of_client", seg)

    def test_cycle_still_has_zero_while_loops(self):
        node = None
        for n in self.tree.body:
            if isinstance(n, ast.AsyncFunctionDef) \
                    and n.name == "_auto_discovery_run_one_cycle":
                node = n
        whiles = [n.lineno for n in ast.walk(node)
                  if isinstance(n, ast.While)]
        self.assertEqual(whiles, [])

    def test_fixccc_call_site_line_contract(self):
        node = None
        for n in self.tree.body:
            if isinstance(n, ast.AsyncFunctionDef) \
                    and n.name == "_auto_discovery_run_one_cycle":
                node = n
        calls = [n.lineno for n in ast.walk(node)
                 if isinstance(n, ast.Call)
                 and isinstance(n.func, ast.Name)
                 and n.func.id == "_vc_discovery_select_queries_bounded"]
        # v99: 22911 -> 21827 (documented correction; the v99 pipeline
        # rewrite MOVED the 850-line join body out of voicechat.py into
        # vc_pipeline.py — net -794 lines above the anchor; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.05: 21980 -> 22197 (documented correction; the RC-F1
        # peer-matching helper + targeted-query/verification fixes
        # added +217 lines above the anchor; INVARIANT unchanged:
        # ONE call-site, zero while-loops)
        # v99.03: 21930 -> 21980 (documented correction; the RC-13
        # discovery/reconcile short-circuit insertions (+50 lines
        # above the anchor) shifted the call-site; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.02: 21827 -> 21930 (documented correction; the FIX-2
        # targeted-no-match absent-streak block + the FIX-5a/5b identity
        # resolution fixes in vc_check_telegram_participation /
        # vc_verify_target added +103 lines above the anchor; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.06: 22197 -> 22874 (documented correction; the FIX-2
        # parallel per-account discovery pass helpers + the concurrent
        # launch/await blocks inside _auto_discovery_run_one_cycle
        # added +677 lines above the anchor; INVARIANT unchanged:
        # ONE call-site, zero while-loops)
        # v99.06 (D8 fix correction): 22874 -> 22885 — the FIX-3b
        # registry terminal-state entry-capture fix in
        # vc_registry_register added +11 lines above the anchor;
        # INVARIANT unchanged: ONE call-site, zero while-loops.
        # v99.07: 22885 -> 23116 (documented correction; the FIX-1/2/3
        # backend-start unification [getter rewrite + _adopt_started_transport
        # method + generation tracking + join-site start gate] + FIX-4
        # shutdown disambiguation + FIX-8 filter-scan counters added +231
        # lines above the anchor; INVARIANT unchanged: ONE call-site,
        # zero while-loops)
        # v99.07 (post-FIX-12 correction): 23116 -> 23129 — the FIX-12
        # worker-heartbeat block at the vc_reconcile_loop head sits ABOVE
        # the discovery cycle and added +13 lines to the anchor shift;
        # INVARIANT unchanged: ONE call-site, zero while-loops.
        # v99.08: 23129 -> 23263 (documented correction; the v99.08
        # Patch-1 flat-scope comparison block + the item-8 cache-bound
        # helpers inserted above the anchor; INVARIANT unchanged:
        # ONE call-site, zero while-loops)
        # v99.10: 23302 -> 23776 (documented correction; the v99.10
        # FIX-A/B/C/E/F insertions above the anchor; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.09: 23263 -> 23302 (documented correction; the FIX-C
        # verify_joined form-aware ownership lookup + one-hop
        # delegation guard in PyTgCallsBackend (above the discovery
        # cycle) added +39 lines to the anchor shift; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.11: 23776 -> 24553 (documented correction; the P1
        # get_contacts ladder replacement at resolve's Step 3 (+3 lines)
        # + the P0 leave-policy reason-code wiring + the admission-gate/
        # transport-lifecycle blocks + the P1 verification-state
        # classification (VC_VERIFY_INACCESSIBLE / not-member recheck
        # backoff) + the crash-loop startup-recovery guard (all above
        # the anchor) added +777 lines; INVARIANT unchanged: ONE
        # call-site, zero while-loops)
        # v99.11 (config-audit correction): 24553 -> 24561 — the
        # VC_JOIN_RETRY_BASE/MAX_SECONDS env wiring at module top
        # added +8 lines above the anchor; INVARIANT unchanged.
        # v99.11.1 (documented correction): 24561 -> 24962 — the FIX-3
        # already-joined classification helper at the module head
        # (+401 lines above the anchor) shifted the call-site;
        # INVARIANT unchanged: ONE call-site, zero while-loops.
        # v99.11.2 (documented correction): 24962 -> 25115 — the FIX
        # cluster-owned already-joined convergence (the owner-scope
        # helper at the module head +68 and the convergence branch in
        # the Join-All worker +85, both above the anchor) shifted the
        # call-site; INVARIANT unchanged: ONE call-site, zero
        # while-loops.
        # v99.11.3 (documented correction): 25115 -> 25479 -> 25513 —
        # the FIX-1 deterministic-native-release bookkeeping in the
        # stale-call cleanup + the settled-phase wiring at the join/
        # leave sites + the FIX-2 entity-invalid classification/
        # cooldown/gate in the Join-All worker + the drift-attribution
        # pass function + the terminal-tracker remediation extension
        # + the FIX-3 measurement note (all above the anchor) shifted
        # the call-site; INVARIANT unchanged: ONE call-site, zero
        # while-loops.
        self.assertEqual(calls, [25513])

    def test_vc_architecture_module_has_zero_while_loops(self):
        arch = _read(_VC_ARCH)
        whiles = [n.lineno for n in ast.walk(ast.parse(arch))
                  if isinstance(n, ast.While)]
        self.assertEqual(
            whiles, [],
            f"vc_architecture.py reintroduced while loops at {whiles}")

    def test_liveness_loop_runs_maintenance(self):
        bs = _read(_BOOTSTRAP)
        self.assertIn("negcache_sweep", bs)
        self.assertIn("scope_registry_update", bs)
        self.assertIn("emit_budgets_heartbeat", bs)
        self.assertIn("liveness_sweep", bs)

    def test_invariants_report_available(self):
        rep = vca.check_invariants()
        self.assertIn("task_population_le_bound", rep)
        self.assertTrue(rep["task_population_le_bound"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
