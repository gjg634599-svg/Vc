"""v99.11.3 FIX-1 — FD/ATTRIBUTION/LIFECYCLE-RELEASE SUITE.

PRODUCTION EVIDENCE (bot-diagnostic.log (2).2 / (3).1, 2026-09-25/26 —
the GitHub evidence repo gjg634599-svg/Vc):
  * process 1 (16:18→20:53): fd 20→885/1024 with joined FLAT 41-43 from
    17:30 onward (+2-4 sockets/min, 3h23m) — the process was killed at
    the FD boundary and restarted at 20:54;
  * process 2 (20:54→02:14): fd 20→376 with joined FLAT 18-21;
    23:00-23:44 was PERFECTLY FLAT (151-152), growth started exactly at
    23:47 (+5, then +1..+7/min for 2.5h) — the onset coincides with new
    Telegram group calls rotating in the tracked chat set;
  * per-minute event-correlation: EVERY candidate marker NEGATIVELY
    correlated with growth; threads FLAT (48-54); no TelegramClient
    creation; pipes/files FLAT — growth is SOCKETS ONLY;
  * one native_leave of stale chat 2144563093 (00:02:14-15) released
    delta_total=-36 delta_sockets=-36 — a single native transport had
    accumulated 36 retained sockets (≈5× its steady state);
  * 360× VC_TRANSPORT_RESOURCE_LEAK_SUSPECTED: 8 transports stuck in
    STOPPING since 17:09-17:10 — their stale-container cleanups were
    DENIED by the leave policy (cause=blocked_during_join_all) and NO
    exit path finalized the tracker record.

ROOT CAUSE (proven by the controlled native experiment —
tests/_v9913_native_lifecycle_driver.py, REAL ntgcalls):
  * each create_call-without-stop retains 2 UDP + 2-6 TCP sockets
    INDEFINITELY (GC does not release them; only an explicit stop()
    does);
  * the production leak = native call objects that are never
    deterministically stopped: (a) failed joins whose exception path
    never released the partially-created native (the pipeline's
    transport-dispatch exception path had NO cleanup), (b) stale/dead
    transports whose verified-absent release was DENIED during Join-All
    runs (the leave-policy blanket block), (c) their lifecycle tracker
    records stuck in STOPPING forever.

THE v99.11.3 FIX UNDER TEST (all additive, no v99.11.1/2 behavior
change):
  * deterministic native release on the pipeline's transport-dispatch
    exception path (FAILED_JOIN_CLEANUP — the same authorized reason
    the other failed-join paths already use);
  * leave-policy carve-out: STALE_CONTAINER_VERIFIED_ABSENT /
    RECONCILE_CONFIRMED_ABSENT (WITH evidence) stay authorized during
    the Join-All leave-block — a verified-dead object is not a live
    Join-All target;
  * bookkeeping completion: every _vc_cleanup_stale_backend_call exit
    path reaches a terminal tracker state (RELEASED) when the container
    is verified absent — no more stuck-STOPPING records;
  * drift-triggered ATTRIBUTION census (fd_socket_census →
    VC_FD_DRIFT_ATTRIBUTION: tcp/udp/state + tracked_active /
    stale_in_container / registry_managed / ORPHANS) + the bounded,
    evidence-gated orphan release pass (vc_fd_drift_attribution_pass);
  * the delayed "settled" op-delta phase (fd_op_settled →
    VC_FD_OP_DELTA phase=settled 30-60s after join/leave/cleanup).

PRESERVED guarantees asserted here: the drift detector stays
observability (detection unchanged); admission denies only NEW joins;
ACTIVE healthy transports are never touched by the remediation; the
already-joined convergence subsystem is NOT modified.
"""

from __future__ import annotations

import asyncio
import os
import socket
import subprocess
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mediagrab_bot import vc_resources as vr  # noqa: E402

_ROOT = str(Path(__file__).resolve().parents[1])
_VC = os.path.join(_ROOT, "mediagrab_bot", "voicechat.py")
_HD = os.path.join(_ROOT, "mediagrab_bot", "handlers.py")
_VP = os.path.join(_ROOT, "mediagrab_bot", "vc_pipeline.py")
_VR = os.path.join(_ROOT, "mediagrab_bot", "vc_resources.py")
_LP = os.path.join(_ROOT, "mediagrab_bot", "vc_leave_policy.py")
_DRV_NATIVE = os.path.join(_ROOT, "tests", "_v9913_native_lifecycle_driver.py")
_DRV_INVALID = os.path.join(
    _ROOT, "tests", "_v9913_invalid_channel_driver.py")
_DRV_ATTR = os.path.join(
    _ROOT, "tests", "_v9913_attribution_driver.py")


def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


class TestSocketCensus(unittest.TestCase):
    """fd_socket_census — the TCP/UDP attribution primitive."""

    def test_a1_counts_a_real_udp_socket(self):
        before = vr.fd_socket_census()
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.bind(("127.0.0.1", 0))
            during = vr.fd_socket_census()
        finally:
            s.close()
        after = vr.fd_socket_census()
        self.assertEqual(
            during["sockets"], before["sockets"] + 1)
        self.assertEqual(during["udp"], before["udp"] + 1)
        self.assertGreaterEqual(during["unattributed"] + during["udp"]
                                + during["tcp"] + during["udp6"]
                                + during["tcp6"], during["sockets"])
        self.assertEqual(after["sockets"], before["sockets"])

    def test_a2_counts_a_real_tcp_socket(self):
        before = vr.fd_socket_census()
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        cli = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            srv.bind(("127.0.0.1", 0))
            srv.listen(1)
            cli.connect(srv.getsockname())
            during = vr.fd_socket_census()
        finally:
            cli.close()
            srv.close()
        self.assertEqual(during["sockets"], before["sockets"] + 2)
        self.assertEqual(during["tcp"], before["tcp"] + 2)
        self.assertGreaterEqual(during["tcp_established"], 1)

    def test_a3_never_raises(self):
        out = vr.fd_socket_census()
        self.assertIsInstance(out, dict)
        for k in ("sockets", "tcp", "udp", "unattributed",
                  "tcp_established"):
            self.assertIn(k, out)


class TestSettledPhase(unittest.TestCase):
    """fd_op_settled — the 30-60s post-op census."""

    def test_b1_schedules_and_emits(self):
        vr.reset_fd_instrumentation()
        base = vr.fd_class_census()
        vr._fd_op_baselines[("settled_probe", 4242)] = dict(base)

        async def _run():
            ok = vr.fd_op_settled(
                "settled_probe", 4242, delay_seconds=5.0)
            self.assertTrue(ok)
            self.assertGreaterEqual(vr.fd_settled_task_count(), 1)
            await asyncio.sleep(5.3)
            self.assertEqual(vr.fd_settled_task_count(), 0)
        asyncio.run(_run())
        vr.reset_fd_instrumentation()

    def test_b2_no_loop_returns_false(self):
        self.assertFalse(vr.fd_op_settled("x", 1, delay_seconds=1.0))

    def test_b3_env_override_clamped(self):
        os.environ["VC_FD_SETTLED_SECONDS"] = "0"
        try:
            # clamped UP to the 5s floor — never below
            async def _run():
                # just verify scheduling works with the env set
                ok = vr.fd_op_settled("probe2", 7, delay_seconds=6.0)
                if ok:
                    await asyncio.sleep(0.05)
                    for t in list(vr._settled_timers):
                        t.cancel()
                    await asyncio.sleep(0.05)
                return True
            self.assertTrue(asyncio.run(_run()))
        finally:
            os.environ.pop("VC_FD_SETTLED_SECONDS", None)
            vr._settled_timers.clear()


class TestDriftAttribution(unittest.TestCase):
    """fd_drift_attribution — the classification census."""

    def test_c1_classification(self):
        out = vr.fd_drift_attribution(
            container_ids={1, 2, 3, 4, 5},
            tracker_states={1: "ACTIVE", 2: "STOPPING",
                            3: "RELEASED", 4: "ALLOCATING"},
            registry_joined={5},
            joined_transports=9,
        )
        self.assertEqual(out["tracked_active"], [1])
        self.assertEqual(sorted(out["stale_in_container"]), [2, 3, 4])
        self.assertEqual(out["registry_managed"], [5])
        self.assertEqual(out["orphans"], [])
        self.assertEqual(out["tracker_stuck"], [2, 4])
        self.assertEqual(out["container_count"], 5)
        self.assertEqual(out["registry_joined_count"], 1)
        self.assertEqual(out["joined_transports"], 9)

    def test_c2_orphan_detection(self):
        out = vr.fd_drift_attribution(
            container_ids={10, 11, 12},
            tracker_states={10: "ACTIVE"},
            registry_joined={11},
        )
        # 12: in container, NO tracker record, NOT registry-joined →
        # the proven socket-retention class.
        self.assertEqual(out["orphans"], [12])
        self.assertEqual(out["tracked_active"], [10])
        self.assertEqual(out["registry_managed"], [11])

    def test_c3_never_raises(self):
        out = vr.fd_drift_attribution()
        self.assertIsInstance(out, dict)
        self.assertEqual(out["container_count"], 0)


class TestLeavePolicyCarveOut(unittest.TestCase):
    """The v99.11.3 policy boundary: verified-dead releases stay
    authorized during the Join-All leave-block (evidence required)."""

    def _lp(self):
        # import the REAL policy module against a minimal stub surface
        sys.path.insert(0, _ROOT)
        from mediagrab_bot import vc_leave_policy as lp
        return lp

    def test_d1_verified_absent_authorized_during_join_all(self):
        lp = self._lp()
        # force the join-all leave-block ACTIVE
        orig = lp._join_all_leave_block_active
        lp._join_all_leave_block_active = lambda: True
        try:
            ok, why = lp.vc_leave_authorize(
                "STALE_CONTAINER_VERIFIED_ABSENT", "test", 123,
                evidence="stale container verified absent")
            self.assertTrue(ok, why)
            ok2, why2 = lp.vc_leave_authorize(
                "RECONCILE_CONFIRMED_ABSENT", "test", 123,
                evidence="positive telegram recheck absent — "
                         "authoritative absence")
            self.assertTrue(ok2, why2)
        finally:
            lp._join_all_leave_block_active = orig

    def test_d2_evidence_still_required(self):
        lp = self._lp()
        orig = lp._join_all_leave_block_active
        lp._join_all_leave_block_active = lambda: True
        try:
            ok, why = lp.vc_leave_authorize(
                "STALE_CONTAINER_VERIFIED_ABSENT", "test", 123,
                evidence=None)
            self.assertFalse(ok)
            self.assertEqual(why, "validated_reason_requires_evidence")
        finally:
            lp._join_all_leave_block_active = orig

    def test_d3_other_validated_reasons_still_blocked(self):
        lp = self._lp()
        orig = lp._join_all_leave_block_active
        lp._join_all_leave_block_active = lambda: True
        try:
            ok, why = lp.vc_leave_authorize(
                "VC_TERMINATED", "test", 123, evidence="terminated")
            self.assertFalse(ok)
            self.assertEqual(why, "blocked_during_join_all")
        finally:
            lp._join_all_leave_block_active = orig

    def test_d4_no_block_behavior_unchanged(self):
        lp = self._lp()
        orig = lp._join_all_leave_block_active
        lp._join_all_leave_block_active = lambda: False
        try:
            ok, why = lp.vc_leave_authorize(
                "STALE_CONTAINER_VERIFIED_ABSENT", "test", 123,
                evidence="e")
            self.assertTrue(ok)
            # unknown reason still denied
            ok2, why2 = lp.vc_leave_authorize("BOGUS", "t", 1)
            self.assertFalse(ok2)
        finally:
            lp._join_all_leave_block_active = orig


class TestAttributionDriver(unittest.TestCase):
    """The bookkeeping-completion + attribution-pass seams (the exact
    production boundaries), run via the SUBPROCESS driver — the
    v99.11.2 convention: the fastpath harness stubs telethon/telegram/
    mtproto module surfaces, so in-process use would poison sys.modules
    for every later suite (the discovered ordering hazard: crash_loop /
    resource_guard / sqlite_wal / leave_policy import the REAL
    modules)."""

    def test_e1_e2_e3_f1_f2_f3_driver_all_cases_pass(self):
        proc = subprocess.run(
            [sys.executable, _DRV_ATTR],
            capture_output=True, text=True, timeout=300.0)
        self.assertEqual(proc.returncode, 0,
                         f"attribution driver failed:\n"
                         f"{proc.stdout[-2000:]}\n{proc.stderr[-2000:]}")
        self.assertIn("SUMMARY: 6/6 cases passed", proc.stdout)
        # the exact 17:09:55 stuck-STOPPING repair
        self.assertIn("CASE BOOK-DENIED: PASS", proc.stdout)
        # ACTIVE healthy transports are never touched
        self.assertIn("CASE PASS-ACTIVE: PASS", proc.stdout)


class TestSourceContracts(unittest.TestCase):
    """§G — the v99.11.3 seams exist at the exact production sites."""

    def test_g1_pipeline_transport_exception_cleanup_wired(self):
        src = _read(_VP)
        # the exception path now releases the partially-created native
        self.assertIn(
            "v99.11.3 FIX-1 (deterministic native release on the",
            src)
        self.assertIn(
            'reason_code="FAILED_JOIN_CLEANUP",\n                        '
            'evidence=(\n                            "transport_dispatch',
            src.replace("    ", "    ") if False else src)
        # it sits INSIDE the transport-retry exception handler (after
        # the classification, before the class branches)
        self.assertLess(
            src.index("cls = _classify_transport_exc(transport_error)"),
            src.index("v99.11.3 FIX-1 (deterministic native release"),
        )

    def test_g2_settled_phase_wiring(self):
        vc = _read(_VC)
        vp = _read(_VP)
        # join dispatch after → settled
        self.assertIn('fd_op_settled as _v9913_settled', vc)
        self.assertIn('_v9913_settled("native_join_dispatch", chat_id',
                      vc)
        # leave after → settled
        self.assertIn(
            '_v9913_settled_l("native_leave", chat_id', vc)
        # failed-join cleanup → settled
        self.assertIn(
            'fd_op_settled as _v9913_settled_c', vp)

    def test_g3_drift_attribution_wired_in_heartbeat(self):
        hd = _read(_HD)
        self.assertIn("_v9913_drift_suspected", hd)
        self.assertIn("vc_fd_drift_attribution_pass", hd)
        # fired ONLY when the drift detector triggers
        self.assertIn("if _v9913_drift_suspected:", hd)

    def test_g4_bookkeeping_completion_both_paths(self):
        vc = _read(_VC)
        self.assertIn("VC_TRANSPORT_RELEASED_BOOKKEEPING", vc)
        # the early-return path AND the denied-leave re-check path
        self.assertIn("container_verified_absent", vc)
        self.assertIn(
            "container_verified_absent_after_denied_leave", vc)

    def test_g5_attribution_census_emits_classification(self):
        vr = _read(_VR)
        for marker in (
                "VC_FD_DRIFT_ATTRIBUTION",
                "phase=settled",
                "fd_socket_census",
                "tracked_active",
                "stale_in_container",
                "registry_managed",
                "orphans"):
            self.assertIn(marker, vr)
        vc = _read(_VC)
        for marker in (
                "VC_FD_DRIFT_ATTRIBUTION",
                "VC_FD_DRIFT_REMEDIATION_APPLIED"):
            self.assertIn(marker, vc)

    def test_g6_already_joined_subsystem_untouched(self):
        """PRESERVE: the v99.11.2 convergence subsystem is NOT modified
        by v99.11.3 — the classifier, the owner-scope helper and the
        convergence branch keep their exact marker set."""
        vc = _read(_VC)
        for marker in (
                "VC_JOIN_ALL_ALREADY_JOINED_CONVERGED",
                "owner_scope=own_cluster_account",
                "breaker_recorded=false",
                "_v9912_owner_is_own_cluster_account",
                "_v9911_classify_already_joined_exc"):
            self.assertIn(marker, vc)

    def test_g7_fd_guard_and_admission_untouched(self):
        """PRESERVE: the v99.11.1 admission model + guard boundaries
        (no thresholds changed to mask the leak)."""
        vr_src = _read(_VR)
        self.assertIn("DEFAULT_JOIN_FD_COST", vr_src)
        self.assertIn("VC_JOIN_FD_COST", vr_src)
        self.assertIn("DEFAULT_MAX_JOINED", vr_src)


class TestNativeLifecycleDriver(unittest.TestCase):
    """The controlled native experiment (REAL ntgcalls): the FD matrix
    cases 1-8 + the census integration (cases 9-10 live in the harness
    pairing suite).  Skips when ntgcalls is unavailable."""

    def test_h1_driver_all_cases_pass(self):
        try:
            import ntgcalls  # noqa: F401
        except Exception:
            self.skipTest("ntgcalls not importable in this environment")
        proc = subprocess.run(
            [sys.executable, _DRV_NATIVE],
            capture_output=True, text=True, timeout=300.0)
        self.assertEqual(proc.returncode, 0,
                         f"driver failed:\n{proc.stdout[-2000:]}"
                         f"\n{proc.stderr[-2000:]}")
        self.assertIn("SUMMARY: 8/8 cases passed", proc.stdout)

    def test_h2_invalid_channel_driver_all_cases_pass(self):
        proc = subprocess.run(
            [sys.executable, _DRV_INVALID],
            capture_output=True, text=True, timeout=300.0)
        self.assertEqual(proc.returncode, 0,
                         f"driver failed:\n{proc.stdout[-2000:]}"
                         f"\n{proc.stderr[-2000:]}")
        self.assertIn("SUMMARY: 5/5 cases passed", proc.stdout)


class TestHarnessPairingMatrix(unittest.TestCase):
    """The v99.11.3 FD matrix (harness pairing, mirroring the v99.11.1
    §E class): every lifecycle shape returns the census to baseline
    with the NEW release seams active."""

    class FakeNative:
        """2 sockets per native, released only by stop (the proven
        retention semantics)."""

        def __init__(self):
            self.sock = None
            self.stopped = False

        def create(self):
            self.sock = socket.socket(
                socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.bind(("127.0.0.1", 0))

        def stop(self):
            if self.sock is not None:
                self.sock.close()
                self.sock = None
            self.stopped = True

    def _baseline(self) -> int:
        return vr.fd_class_census()["sockets"]

    def test_i1_join_leave_baseline_recovery(self):
        base = self._baseline()
        n = self.FakeNative()
        n.create()
        self.assertGreater(vr.fd_class_census()["sockets"], base)
        n.stop()
        self.assertEqual(vr.fd_class_census()["sockets"], base)

    def test_i2_five_cycle_churn(self):
        base = self._baseline()
        for _ in range(5):
            n = self.FakeNative()
            n.create()
            n.stop()
        self.assertEqual(vr.fd_class_census()["sockets"], base)

    def test_i3_failed_join_cleanup(self):
        base = self._baseline()
        n = self.FakeNative()
        n.create()  # native created…
        try:
            raise RuntimeError("Invalid channel object")  # …join fails
        except RuntimeError:
            pass  # the v99.11.3 wiring: release on the exception path
            n.stop()
        self.assertEqual(vr.fd_class_census()["sockets"], base)

    def test_i4_failed_join_without_cleanup_retains(self):
        """The pre-fix behavior (the regression guard): WITHOUT the
        release the socket is retained — detectable by the census."""
        base = self._baseline()
        n = self.FakeNative()
        n.create()
        try:
            self.assertGreater(vr.fd_class_census()["sockets"], base)
        finally:
            n.stop()
        self.assertEqual(vr.fd_class_census()["sockets"], base)

    def test_i5_stale_container_recovery(self):
        """The stale-object release via the authorized cleanup: the
        stuck object's resources return to baseline."""
        base = self._baseline()
        n = self.FakeNative()
        n.create()
        # the object goes stale (its call ended) but the native still
        # holds the socket — the verified-dead release reclaims it:
        n.stop()
        self.assertEqual(vr.fd_class_census()["sockets"], base)

    def test_i6_delayed_settled_no_rebind(self):
        """After release + settling, no re-binding occurs (the release
        is final)."""
        base = self._baseline()
        n = self.FakeNative()
        n.create()
        n.stop()

        async def _settle():
            await asyncio.sleep(0.3)
        asyncio.run(_settle())
        self.assertEqual(vr.fd_class_census()["sockets"], base)

    def test_i7_interleaved_multi_transport(self):
        base = self._baseline()
        a = self.FakeNative()
        b = self.FakeNative()
        a.create()
        b.create()
        self.assertEqual(vr.fd_class_census()["sockets"], base + 2)
        a.stop()
        self.assertEqual(vr.fd_class_census()["sockets"], base + 1)
        b.stop()
        self.assertEqual(vr.fd_class_census()["sockets"], base)


if __name__ == "__main__":
    unittest.main()
