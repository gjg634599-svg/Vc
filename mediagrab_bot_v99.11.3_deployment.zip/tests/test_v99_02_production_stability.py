#!/usr/bin/env python3
"""v99.02 — PRODUCTION STABILITY regression suite.

Every test in this file targets a root cause that was RUNTIME-PROVEN by the
v99.01 production deployment (upload/bot-diagnostic.log{,.1,.2},
2026-09-09 17:55 → 2026-09-10 03:20, ~10h, three rotations):

  RC-1  The deployed tree was missing assets/vc_silence_600s.opus → every
        join fell back to the null-stream transport (168 dispatches → 0
        Telegram-side verifications → VC_JOIN_SUCCESS=0) while
        BUILD_IDENTITY_VERIFIED passed (assets were never runtime-hashed).
  RC-2  1,215× VC_PARTICIPATION_TARGETED_EMPTY_RESULT (targeted query
        returned OTHER participants, not ours) never engaged the FIX-L
        absent-streak — only the empty-list branch did — so the dominant
        production path stayed UNKNOWN forever.
  RC-3  ~1024 FDs accumulated over ~6h → 4,811× Errno 24 → a 3.2-hour
        zombie death spiral (reconnect storm + failed saves). The bot's
        Python paths were proven clean offline (300 pipeline join cycles +
        1000 atomic writes → ΔFD=0); the census/guard make the next run
        self-diagnosing and recoverable.
  RC-4  (a) classify_failure never matched "Connection to Telegram failed
        N time(s)"/Errno 24 → class=unknown → short ladder forever (345
        reconnects / 2.3h ≈ every 19s, failures=103 still wait=8.5s);
        (b) the cluster reconnect loop's generic except never incremented
        fail_count → 140 retries at exactly 60s (backoff 60/300/900 never
        engaged); (c) 344 generations created, ZERO retired.
  RC-5  vc_verify_target's redetect used the ROUTER-picked client for
        global-scope records (cross-account hash → CHANNEL_INVALID ×128)
        and vc_check_telegram_participation(account_id="global") resolved
        through the cluster → None → INSTANT unknown with no query.
  RC-6  Heartbeat/snapshot failures logged at DEBUG — the operator saw
        nothing at INFO+ for the entire death spiral.
  RC-7  Deterministic leaks: document=open(...) never closed (PTB);
        ffprobe/ffmpeg children not killed on timeout.

Method: behavioural tests against the REAL modules (the pipeline through
the v99.00 mock harness with production-default env; mtproto_generation
standalone; voicechat imported with a fake telethon/pytgcalls stack) plus
source contracts where behaviour is not offline-reproducible (bootstrap
startup identity wiring). Each test documents the marker it guards.
"""
from __future__ import annotations

import asyncio
import importlib.util
import os
import re
import sys
import types
import unittest
from pathlib import Path

_SRC = Path(__file__).resolve().parent.parent / "mediagrab_bot"
_VC_TEXT = (_SRC / "voicechat.py").read_text(encoding="utf-8")
_PIPE_TEXT = (_SRC / "vc_pipeline.py").read_text(encoding="utf-8")
_MTGEN_TEXT = (_SRC / "mtproto_generation.py").read_text(encoding="utf-8")
_BOOT_TEXT = (_SRC / "bootstrap.py").read_text(encoding="utf-8")
_HANDLERS_TEXT = (_SRC / "handlers.py").read_text(encoding="utf-8")
_MEDIA_TOOLS_TEXT = (_SRC / "media_tools.py").read_text(encoding="utf-8")
_FRAME_EXT_TEXT = (_SRC / "frame_extractor.py").read_text(encoding="utf-8")
_INIT_TEXT = (_SRC / "__init__.py").read_text(encoding="utf-8")
_SERVICE_TEXT = (Path(__file__).resolve().parent.parent /
                 "deploy" / "mediagrab.service").read_text(encoding="utf-8")

# Reuse the v99.00 behavioural harness (fake voicechat/mtproto + the REAL
# vc_pipeline.py). Its own module import is side-effect-light.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v99_00_vc_pipeline as T  # noqa: E402


# ===========================================================================
# FIX-1 (RC-1) — the null-stream join gate
# ===========================================================================

class TestV9902NullStreamGate(T.PipelineTestBase):
    """v99.02 FIX-1: null-stream dispatches are blocked by default.

    Production proof: 168 null-stream dispatches over 10h produced ZERO
    Telegram-side verifications (the account was NEVER in a participant
    list) — the dispatches are pure churn (native transports + reconcile
    load + registry noise)."""

    def setUp(self):
        super().setUp()
        # Production default: NO null-stream opt-in. The base Harness
        # sets VC_ALLOW_NULL_STREAM_JOIN=1 for its own behavioural
        # scenarios; this suite asserts the DEFAULT (gate active).
        os.environ.pop("VC_ALLOW_NULL_STREAM_JOIN", None)
        os.environ.pop("VC_SILENCE_ASSET", None)

    def test_gate_blocks_dispatch_and_raises_honest_transport_error(self):
        async def run():
            out = None
            with self.assertLogs("mediagrab", level="CRITICAL") as logs:
                try:
                    out = await self._join()
                except self.h.VCTransportError as exc:
                    # Honest deterministic failure — the join machinery's
                    # standard failure backoff applies (NOT a success
                    # shortcut, NOT an UNKNOWN-preserve).
                    self.assertIn("blocked", str(exc))
                    self.assertIsNotNone(exc)
                else:
                    self.fail("gate must raise VCTransportError")
            self.assertIsNone(out)
            # NO dispatch happened — no native transport, no verification.
            self.assertEqual(len(self.backend.dispatches), 0)
            self.assertEqual(len(self.h.verify_calls), 0)
            # The one-time CRITICAL marker fired exactly once.
            self.assertTrue(any("VC_NULL_STREAM_JOINS_DISABLED" in line
                                for line in logs.output),
                            logs.output)
            self.assertEqual(
                sum(1 for line in logs.output
                    if "VC_NULL_STREAM_JOINS_DISABLED" in line), 1)

        asyncio.run(run())

    def test_gate_marker_has_reason_and_escape_hatch(self):
        async def run():
            with self.assertLogs("mediagrab", level="WARNING") as logs:
                try:
                    await self._join()
                except self.h.VCTransportError:
                    pass
            blocked = [line for line in logs.output
                       if "VC_JOIN_BLOCKED_NULL_STREAM" in line]
            self.assertEqual(len(blocked), 1)
            # The per-block marker names the chat + the fix tag…
            self.assertIn("chat_id=-1001234567890", blocked[0])
            self.assertIn("v99.02 FIX-1", blocked[0])
            self.assertIn("reason=", blocked[0])
            # …and the raised error carries the documented escape hatch.
            try:
                await self._join()
            except self.h.VCTransportError as exc:
                self.assertIn("VC_ALLOW_NULL_STREAM_JOIN", str(exc))

        asyncio.run(run())

    def test_env_opt_in_allows_null_stream_dispatch(self):
        async def run():
            os.environ["VC_ALLOW_NULL_STREAM_JOIN"] = "1"
            try:
                # verification stays unknown → the unverified raise is the
                # honest outcome; the DISPATCH must have happened.
                with self.assertRaises(self.h.VCJoinUnverifiedError):
                    await self._join()
                self.assertGreaterEqual(len(self.backend.dispatches), 1)
            finally:
                os.environ.pop("VC_ALLOW_NULL_STREAM_JOIN", None)

        asyncio.run(run())

    def test_explicit_prefer_real_stream_zero_is_an_implicit_opt_in(self):
        """An operator who sets VC_JOIN_PREFER_REAL_STREAM=0 has already
        chosen the null-stream transport — the gate honours that choice."""
        async def run():
            os.environ["VC_JOIN_PREFER_REAL_STREAM"] = "0"
            try:
                with self.assertRaises(self.h.VCJoinUnverifiedError):
                    await self._join()
                self.assertGreaterEqual(len(self.backend.dispatches), 1)
            finally:
                os.environ.pop("VC_JOIN_PREFER_REAL_STREAM", None)

        asyncio.run(run())

    def test_gate_source_contract(self):
        # The gate is wired at the dispatch site, before transport_error.
        self.assertIn("if stream is None and not _null_ok:", _PIPE_TEXT)
        self.assertIn("raise _null_stream_gate_block(out, sm, marked_chat, account)",
                      _PIPE_TEXT)
        # The outcome fields make the blocked join observable.
        self.assertIn('out.join_result = "null_stream_blocked"', _PIPE_TEXT)
        self.assertIn('out.retry_reason = "silence_stream_unavailable"',
                      _PIPE_TEXT)


# ===========================================================================
# FIX-4a/4b/4d (RC-4) — reconnect-storm fixes (real mtproto_generation)
# =========================================================================##

def _load_mtgen():
    spec = importlib.util.spec_from_file_location(
        "mg_v9902_mtgen", str(_SRC / "mtproto_generation.py"))
    mod = importlib.util.module_from_spec(spec)
    sys.modules["mg_v9902_mtgen"] = mod
    spec.loader.exec_module(mod)
    return mod


class TestV9902ClassifyFailure(unittest.TestCase):
    """v99.02 FIX-4a: the storm-phase exception classes must map to the
    LONG backoff ladder. Production: 345/345 reconnect failures classified
    unknown (wait=8.5s at failures=103)."""

    @classmethod
    def setUpClass(cls):
        cls.m = _load_mtgen()

    def test_fd_exhaustion_maps_to_network_unreachable(self):
        self.assertEqual(
            self.m.classify_failure(None, "Too many open files: '/x'"),
            self.m.NetworkFailureClass.NETWORK_UNREACHABLE)
        self.assertEqual(
            self.m.classify_failure(None, "[Errno 24] foo"),
            self.m.NetworkFailureClass.NETWORK_UNREACHABLE)

    def test_telethon_retry_exhausted_maps_to_network_unreachable(self):
        self.assertEqual(
            self.m.classify_failure(
                None, "Connection to Telegram failed 3 time(s)"),
            self.m.NetworkFailureClass.NETWORK_UNREACHABLE)

    def test_oserror_and_connectionerror_instances(self):
        self.assertEqual(
            self.m.classify_failure(OSError(24, "Too many open files")),
            self.m.NetworkFailureClass.NETWORK_UNREACHABLE)
        self.assertEqual(
            self.m.classify_failure(
                ConnectionError("Connection to Telegram failed 3 time(s)")),
            self.m.NetworkFailureClass.NETWORK_UNREACHABLE)

    def test_existing_classes_unchanged(self):
        m = self.m
        self.assertEqual(m.classify_failure(
            None, "AUTH_KEY_UNREGISTERED"), m.NetworkFailureClass.AUTH_FAILURE)
        self.assertEqual(m.classify_failure(
            None, "a wait of 30 seconds is required"),
            m.NetworkFailureClass.FLOOD_WAIT)
        self.assertEqual(m.classify_failure(
            asyncio.TimeoutError()), m.NetworkFailureClass.TIMEOUT)
        self.assertEqual(m.classify_failure(
            None, "connection timeout"), m.NetworkFailureClass.TIMEOUT)
        # Session-invalidation semantics unchanged.
        self.assertTrue(m.is_session_invalidating(
            m.NetworkFailureClass.AUTH_FAILURE))
        self.assertFalse(m.is_session_invalidating(
            m.NetworkFailureClass.NETWORK_UNREACHABLE))


class TestV9902SustainedBackoff(unittest.TestCase):
    """v99.02 FIX-4b: a SUSTAINED outage escalates to the long ladder
    regardless of class. Production: failures=103, class=unknown, but the
    wait stayed ≤ 16s+jitter forever."""

    @classmethod
    def setUpClass(cls):
        cls.m = _load_mtgen()

    def _coordinator(self):
        c = self.m.ReconnectCoordinator()
        return c

    def test_short_ladder_below_threshold(self):
        c = self._coordinator()
        c._fail_count["k"] = 7
        for _ in range(20):
            w = c._compute_backoff("k", self.m.NetworkFailureClass.UNKNOWN)
            self.assertLessEqual(w, 16.0 * 1.25 + 0.5)

    def test_long_ladder_at_sustained_threshold(self):
        c = self._coordinator()
        c._fail_count["k"] = 8
        for _ in range(20):
            w = c._compute_backoff("k", self.m.NetworkFailureClass.UNKNOWN)
            self.assertGreaterEqual(
                w, 60.0 * 0.75 - 1e-9,
                "sustained failures must use the long ladder "
                f"(60s cap ± 25% jitter); got {w:.1f}s")

    def test_long_ladder_disjoint_from_short(self):
        c = self._coordinator()
        c._fail_count["k"] = 8
        w_long = c._compute_backoff("k", self.m.NetworkFailureClass.UNKNOWN)
        c._fail_count["k"] = 7
        w_short = c._compute_backoff("k", self.m.NetworkFailureClass.UNKNOWN)
        self.assertGreater(w_long, w_short)

    def test_backoff_never_gives_up_permanently(self):
        """The cap stays bounded (≤ 60s + jitter) at ANY failure count —
        the coordinator never stops retrying, it only slows down."""
        c = self._coordinator()
        c._fail_count["k"] = 10_000
        w = c._compute_backoff("k", self.m.NetworkFailureClass.UNKNOWN)
        self.assertLessEqual(w, 60.0 * 1.25 + 0.5)


class TestV9902GenerationPruning(unittest.TestCase):
    """v99.02 FIX-4d: terminal generations are pruned. Production: 344×
    MTPROTO_GEN_CREATED with ZERO MTPROTO_GEN_RETIRED — the per-session
    generation list grew without bound during the storm."""

    @classmethod
    def setUpClass(cls):
        cls.m = _load_mtgen()

    def test_terminal_generations_bounded(self):
        async def run():
            c = self.m.ReconnectCoordinator()
            gm = c._gen_manager
            with self.assertLogs("mediagrab", level="INFO") as logs:
                for _ in range(30):
                    g = await gm.create_generation("s.sess", "primary")
                    g.mark_failed()
            gens = gm._generations.get(gm._key("s.sess", "primary"), [])
            terminal = [g for g in gens
                        if g.state == self.m.GenState.FAILED]
            # The bound is _MAX_TERMINAL_GENS after any create_generation
            # call, +1 transiently after the NEWEST generation goes
            # terminal (the next creation prunes it). The production
            # defect was 344 NEVER pruned; the invariant is "bounded at a
            # small constant".
            self.assertLessEqual(
                len(terminal), gm._MAX_TERMINAL_GENS + 1,
                f"terminal generations unbounded: {len(terminal)}")
            self.assertLessEqual(len(gens), gm._MAX_TERMINAL_GENS + 2)
            self.assertTrue(any("MTPROTO_GEN_PRUNED" in line
                                for line in logs.output), logs.output)

        asyncio.run(run())

    def test_active_generation_never_pruned(self):
        async def run():
            c = self.m.ReconnectCoordinator()
            gm = c._gen_manager
            active = await gm.create_generation("s2.sess", "primary")
            for _ in range(20):
                g = await gm.create_generation("s2.sess", "primary")
                g.mark_failed()
            gens = gm._generations.get(gm._key("s2.sess", "primary"), [])
            self.assertIn(active, gens, "an ACTIVE generation must never "
                                        "be pruned (lifecycle invariant)")

        asyncio.run(run())


# ===========================================================================
# FIX-4c (RC-4b) — cluster reconnect loop counts every failure
# ===========================================================================

class TestV9902ClusterReconnectFailCount(unittest.TestCase):

    def test_source_contract_fail_count_incremented_on_exception(self):
        """The loop's generic except must bump fail_count (production:
        140 consecutive failures all reported fail_count=0 backoff=60s)."""
        # The increment sits inside the ACCOUNT_RECONNECT_FAILED exception
        # handler (bootstrap.py _cluster_reconnect_loop).
        self.assertRegex(
            _BOOT_TEXT,
            r"ACCOUNT_RECONNECT_FAILED account_id=%s[\s\S]{0,2000}?"
            r"_acc2\[\"fail_count\"\] = \(\s*int\(_acc2\.get\(\"fail_count\", 0\) or 0\) \+ 1\)")

    def test_behavioural_fail_count_escalates_backoff(self):
        """Simulate the loop's failure accounting: 3 exceptions → the
        documented 60/300/900 ladder engages (fail_count 1/2/3)."""
        backoff_ladder = [60, 300, 900]
        acc = {"fail_count": 0}
        # The exact code from the v99.02 exception handler:
        for _ in range(3):
            acc["fail_count"] = (
                int(acc.get("fail_count", 0) or 0) + 1)
        # The loop's index formula: backoff_idx = min(fail_count, 2).
        # fail_count=0 → 60s (the PRE-attempt gate), and after failures
        # 1/2/3 the NEXT retry waits 300/900/900s — the documented
        # 1m→5m→15m ladder. The production defect was fail_count stuck at
        # 0 → every wait stayed 60s forever.
        waits = [backoff_ladder[min(fc, len(backoff_ladder) - 1)]
                 for fc in (0, 1, 2, 3)]
        self.assertEqual(waits, [60, 300, 900, 900])


# ===========================================================================
# FIX-2 + FIX-5 (RC-2/RC-5) — REAL voicechat behavioural tests
# ===========================================================================

_VW_CACHE = {}


def _load_real_voicechat():
    """Import the REAL voicechat.py against a fake telethon/pytgcalls stack
    (the audit/vcenv offline-probe method — the import was proven to work
    with these fakes). Returns (voicechat_module, mtproto_module)."""
    if "vw" in _VW_CACHE:
        return _VW_CACHE["vw"], _VW_CACHE["mt"]

    # --- fake telethon (extended: tl.functions.phone for the check) -----
    telethon = T._install_fake_telethon()

    class _FakeReq:
        def __init__(self, **kw):
            self.__dict__.update(kw)

    phone_mod = types.ModuleType("telethon.tl.functions.phone")
    phone_mod.GetGroupCallRequest = type(
        "GetGroupCallRequest", (_FakeReq,), {})
    phone_mod.GetGroupParticipantsRequest = type(
        "GetGroupParticipantsRequest", (_FakeReq,), {})
    sys.modules["telethon.tl.functions"] = types.ModuleType(
        "telethon.tl.functions")
    sys.modules["telethon.tl.functions.phone"] = phone_mod

    types_mod = sys.modules["telethon.tl.types"]
    types_mod.InputGroupCall = type("InputGroupCall", (_FakeReq,), {})

    # --- fake pytgcalls ---------------------------------------------------
    ptg = types.ModuleType("pytgcalls")
    ptg.__version__ = "2.3.3-fake"
    sys.modules["pytgcalls"] = ptg
    for sub in ("pytgcalls.types", "pytgcalls.types.input_stream",
                "pytgcalls.mtypes", "pytgcalls.helpers"):
        sys.modules.setdefault(sub, types.ModuleType(sub))

    # --- real package import ----------------------------------------------
    # Earlier suites in the same process may have installed FAKE
    # mediagrab_bot.* stub modules (e.g. a dict-backed db_layer without
    # vc_groups_active) — the real mtproto then imports the STUB and
    # fails. Purge every mediagrab_bot* entry and restore them after this
    # suite finishes (tearDownModule) so load order never matters.
    _VW_CACHE["purged"] = {
        k: v for k, v in sys.modules.items()
        if k == "mediagrab_bot" or k.startswith("mediagrab_bot.")
    }
    for k in list(_VW_CACHE["purged"]):
        del sys.modules[k]
    pkg = types.ModuleType("mediagrab_bot")
    pkg.__path__ = [str(_SRC)]
    sys.modules["mediagrab_bot"] = pkg
    for name in ("config", "db_layer", "mtproto", "voicechat"):
        mod_path = _SRC / f"{name}.py"
        spec = importlib.util.spec_from_file_location(
            f"mediagrab_bot.{name}", str(mod_path))
        mod = importlib.util.module_from_spec(spec)
        sys.modules[f"mediagrab_bot.{name}"] = mod
        spec.loader.exec_module(mod)
    _VW_CACHE["vw"] = sys.modules["mediagrab_bot.voicechat"]
    _VW_CACHE["mt"] = sys.modules["mediagrab_bot.mtproto"]
    return _VW_CACHE["vw"], _VW_CACHE["mt"]


def tearDownModule():
    """Restore any mediagrab_bot* modules this suite displaced, so a
    later suite in the same process sees the environment it expects."""
    purged = _VW_CACHE.pop("purged", None)
    if purged:
        for k in [k for k in sys.modules
                  if k == "mediagrab_bot" or k.startswith("mediagrab_bot.")]:
            if k not in purged:
                del sys.modules[k]
        sys.modules.update(purged)


class _FakePart:
    def __init__(self, user_id):
        self.user_id = user_id


class _FakeCallResult:
    def __init__(self, participants, next_offset="", count=None):
        self.participants = participants
        self.participants_next_offset = next_offset
        self.next_offset = next_offset
        self.count = count


class _FakeMe:
    def __init__(self, uid):
        self.id = uid


class _FakeClient:
    def __init__(self, uid, name):
        self.uid = uid
        self.name = name
        self.get_me_calls = 0

    async def get_me(self):
        self.get_me_calls += 1
        return _FakeMe(self.uid)

    def is_connected(self):
        return True


class TestV9902TargetedNoMatchStreak(unittest.TestCase):
    """v99.02 FIX-2 → v99.05 RC-F2: the targeted-query FOREIGN-result
    branch (participants returned, none ours).  v99.02 converged this to
    absent after 3 repeats — RUNTIME-PROVEN WRONG on 2026-09-12 (the
    matcher was blind: the returned participant WAS us); v99.05 keeps
    foreign results UNKNOWN forever (only the EMPTY answer converges
    via the FIX-L streak — covered by the v99.05 suite's b3)."""

    @classmethod
    def setUpClass(cls):
        cls.vw, cls.mt = _load_real_voicechat()

    def setUp(self):
        self.vw._vc_targeted_absent_streak.clear()
        self.vw._vc_my_user_id = 4242
        self.scripted = []

        async def fake_call_with_retry(client, request, **kw):
            return self.scripted.pop(0)

        self.vw.mtproto_call_with_retry = fake_call_with_retry
        # explicit identity client (the pipeline's join-time verify form)
        self.client = _FakeClient(4242, "global_client")

    def _script_no_match(self, other_uid=777, call_id=-42):
        # Broad scan page 0: 1 OTHER participant, no next offset →
        # incomplete (inspected < MIN_ABSENT_PROOF_PARTICIPANTS).
        # Targeted query ids=[my_id]: returns OTHER participants (the
        # observed production server behaviour for non-participants).
        self.scripted = [
            _FakeCallResult([_FakePart(other_uid)]),
            _FakeCallResult([_FakePart(other_uid)]),
        ]

    def test_single_no_match_is_unknown_not_absent(self):
        async def run():
            self._script_no_match()
            res = await self.vw.vc_check_telegram_participation(
                -1001234567890, call_id=-42, access_hash=999,
                account_id="global", client=self.client)
            self.assertEqual(res, "unknown")

        asyncio.run(run())

    def test_three_consecutive_no_match_converges_to_absent(self):
        # v99.05 RC-F2: foreign results NEVER converge to absent — the
        # historical convergence (3 consecutive "no-match" answers)
        # relied on the blind matcher and destroyed 9 REAL joins on
        # 2026-09-12.  Sustained foreign answers stay UNKNOWN forever
        # (non-destructive); ONLY the empty-list answer (a DIRECT
        # Telegram negative for our exact id) converges via FIX-L.
        async def run():
            for i in range(5):
                self._script_no_match()
                res = await self.vw.vc_check_telegram_participation(
                    -1001234567890, call_id=-42, access_hash=999,
                    account_id="global", client=self.client)
                self.assertEqual(
                    res, "unknown",
                    f"a foreign-result must NEVER become absent "
                    f"(iteration {i}; v99.05 RC-F2 — the v99.02 "
                    f"escalation is REMOVED)")
            # no streak was ever recorded on the foreign path:
            self.assertNotIn(-1001234567890,
                             self.vw._vc_targeted_absent_streak)

        asyncio.run(run())

    def test_call_id_change_resets_streak(self):
        async def run():
            for cid in (-42, -42, -99):
                self._script_no_match()
                res = await self.vw.vc_check_telegram_participation(
                    -1001234567890, call_id=cid, access_hash=999,
                    account_id="global", client=self.client)
            self.assertEqual(res, "unknown",
                             "a call_id change mid-streak must prevent "
                             "convergence (FIX-L stability guard)")

        asyncio.run(run())

    def test_present_short_circuits_and_resets(self):
        async def run():
            # 2 no-match rounds …
            for _ in range(2):
                self._script_no_match()
                await self.vw.vc_check_telegram_participation(
                    -1001234567890, call_id=-42, access_hash=999,
                    account_id="global", client=self.client)
            # … then the account IS a participant (broad scan finds us).
            self.scripted = [_FakeCallResult([_FakePart(4242)])]
            res = await self.vw.vc_check_telegram_participation(
                -1001234567890, call_id=-42, access_hash=999,
                account_id="global", client=self.client)
            self.assertEqual(res, "present")

        asyncio.run(run())

    def test_source_contract_no_match_branch_records_streak(self):
        # v99.05 RC-F2 SEMANTICS CHANGE (FINAL REBUILD — RUNTIME-PROVEN
        # WRONG via the 2026-09-12 v99.04 production log): the v99.02
        # no-match→absent streak escalation is REMOVED.  The "no matching
        # participant" observation was an artifact of the BLIND matcher
        # (getattr(p, "user_id") on a Telethon GroupCallParticipant whose
        # identity lives in `peer`): the targeted ids=[self] query WAS
        # returning our own participant, unrecognized.  9/9 REAL joins
        # were destroyed by the escalation on 2026-09-12.  New contract:
        # a non-empty targeted answer with no self is a FOREIGN result →
        # UNKNOWN (never absent); only the EMPTY-list answer (a direct
        # Telegram negative) converges via the FIX-L streak.
        self.assertNotIn(
            "_streak2 = _vc_targeted_absent_streak_record(", _VC_TEXT)
        self.assertNotIn("VC_PARTICIPATION_ABSENT_VIA_TARGETED_NO_MATCH",
                         _VC_TEXT)
        self.assertIn("VC_PARTICIPATION_TARGETED_FOREIGN_RESULT", _VC_TEXT)


class TestV9902GlobalVerifyClient(unittest.TestCase):
    """v99.02 FIX-5a/5b: global-scope records verify through the GLOBAL
    backend's OWN bound client — never the cluster router's pick — and
    account_id="global" resolves a client instead of returning an instant
    no-query unknown."""

    @classmethod
    def setUpClass(cls):
        cls.vw, cls.mt = _load_real_voicechat()

    def setUp(self):
        self.vw._vc_my_user_id = 4242
        self.global_client = _FakeClient(4242, "global_bound_client")
        self.router_client = _FakeClient(5151, "router_pick_acc")
        self.get_me_probe = 0

        class _FakeBackend:
            _mtproto = None

        self.backend = _FakeBackend()
        self.backend._mtproto = self.global_client

        # Patch the resolution chain in the voicechat namespace.
        self.vw.vc_get_backend = lambda account_id="": self.backend
        self.vw.mtproto_get_client = lambda: self.router_client

        class _FakeCluster:
            def get_client(self, aid):
                return None  # "global" is not a cluster account

            def get_account(self, aid):
                return None

        self.vw.get_userbot_cluster = lambda: _FakeCluster()

        async def fake_call_with_retry(client, request, **kw):
            # Whoever queries: return OUR participant on the broad scan.
            return _FakeCallResult([_FakePart(4242)])

        self.vw.mtproto_call_with_retry = fake_call_with_retry

    def test_account_id_global_resolves_bound_client_and_queries(self):
        """OLD behaviour: cluster.get_client("global") → None → instant
        "unknown" WITHOUT any query (the reconcile side never verified
        global-backend joins). NEW: the global backend's bound client is
        used and the targeted query actually runs."""
        async def run():
            res = await self.vw.vc_check_telegram_participation(
                -1001234567890, call_id=-42, access_hash=999,
                account_id="global")
            self.assertEqual(res, "present",
                             "the global path must query with the bound "
                             "client and find our participant")

        asyncio.run(run())

    def test_router_pick_client_is_never_used_for_global_records(self):
        async def run():
            await self.vw.vc_check_telegram_participation(
                -1001234567890, call_id=-42, access_hash=999,
                account_id="global")
            # The global client was used for the query (get_me may run for
            # identity); the ROUTER-picked account client must stay idle.
            self.assertEqual(
                self.router_client.get_me_calls, 0,
                "the cluster router's pick must NOT be used to verify a "
                "global-scope record (RC-5: cross-account hash → "
                "CHANNEL_INVALID)")

        asyncio.run(run())

    def test_verify_target_source_contract_identity_chain(self):
        """vc_verify_target: global/legacy → global_backend_bound; a real
        account with no client → account_client_unavailable (honest
        unknown) — the router pick is gone from this path."""
        self.assertIn('"global_backend_bound" if _reconcile_aid == "global"',
                      _VC_TEXT)
        self.assertIn('"account_client_unavailable"', _VC_TEXT)
        # The old fallback marker for this path must be gone.
        self.assertNotIn(
            '_reconcile_client_source = "primary_fallback" if _reconcile_aid',
            _VC_TEXT)


# ===========================================================================
# FIX-3 (RC-3) — FD census + exhaustion guard (extracted from handlers.py)
# ===========================================================================

# v99.02 test-safety: the guard body does an INNER ``import threading``
# (handlers.py has no module-level threading import) — an exec-namespace
# threading binding is SHADOWED at call time and the REAL Timer would be
# armed: a 2s SIGTERM against the test runner! The sandbox swaps
# sys.modules["threading"] for a recording fake during evaluate() calls.
_FAKE_TIMERS: list = []


class _NoOpTimer:
    def __init__(self, interval, function=None, *a, **kw):
        self.interval = interval
        self.function = function
        self.started = False
        _FAKE_TIMERS.append(self)

    def start(self):
        self.started = True

    def cancel(self):
        pass


class _FakeThreadingModule(types.ModuleType):
    Timer = staticmethod(_NoOpTimer)
    TIMERS = _FAKE_TIMERS


_FAKE_THREADING_MOD = _FakeThreadingModule("threading_sandbox")


import contextlib


@contextlib.contextmanager
def _sandbox_threading():
    _real = sys.modules.get("threading")
    del _FAKE_TIMERS[:]
    sys.modules["threading"] = _FAKE_THREADING_MOD
    try:
        yield _FAKE_TIMERS
    finally:
        if _real is not None:
            sys.modules["threading"] = _real
        else:
            sys.modules.pop("threading", None)


def _extract_functions(source_text, names):
    """Exec-extract named top-level functions from a source file into a
    sandbox namespace (handlers.py's full import chain is not needed —
    the census/guard are pure stdlib + module globals).

    The sandboxed ``threading`` provides a NO-OP Timer: the real guard
    schedules a 2s SIGTERM Timer on its SECOND confirmation — letting that
    run inside a test runner would kill the runner. The no-op Timer keeps
    the guard's logic under test without the lethal side effect."""
    import ast
    import textwrap

    tree = ast.parse(source_text)
    wanted = set(names)
    pieces = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in wanted:
            pieces.append(ast.get_source_segment(source_text, node))
    found = {p.split("(")[0].replace("def ", "").strip() for p in pieces}
    missing = wanted - found
    assert not missing, f"functions not found in source: {missing}"
    ns = {"os": os, "time": __import__("time"),
          "logger": __import__("logging").getLogger("mediagrab_test")}
    # The guard's module-level globals must exist in the sandbox.
    ns["_v9902_hb_fail_logged_at"] = 0.0
    ns["_v9902_fd_guard_confirmed"] = 0
    ns["_v9902_fd_guard_last_error"] = 0.0
    ns["threading"] = _FAKE_THREADING_MOD
    exec(compile(textwrap.dedent("\n\n".join(pieces)), "<extract>", "exec"),
         ns)
    return ns


class TestV9902FdCensusAndGuard(unittest.TestCase):
    """v99.02 FIX-3: the census reports FDs by class; the guard restarts
    only on TWO consecutive ≥85% confirmations (and honours the env kill
    switch). Production: no census existed — the 6h leak was invisible
    until hard exhaustion."""

    @classmethod
    def setUpClass(cls):
        cls.ns = _extract_functions(
            _HANDLERS_TEXT, ["_fd_census", "_fd_guard_evaluate"])

    def test_census_reports_live_process(self):
        c = self.ns["_fd_census"]()
        self.assertTrue(c["available"])
        self.assertGreater(c["total"], 0)
        self.assertGreater(c["soft"], 0)
        self.assertEqual(c["total"],
                         c["sockets"] + c["pipes"] + c["files"]
                         + c["anon"] + c["other"],
                         "class counts must sum to the total")

    def test_guard_idle_below_threshold(self):
        ns = self.ns
        ns["_v9902_fd_guard_confirmed"] = 0
        c = {"available": True, "total": 10, "soft": 1024,
             "sockets": 5, "pipes": 2, "files": 2, "anon": 1, "other": 0}
        ns["_fd_guard_evaluate"](c)
        self.assertEqual(ns["_v9902_fd_guard_confirmed"], 0)

    def test_guard_requires_two_confirmations(self):
        """A SINGLE hot census must NOT restart (transient spike guard);
        TWO consecutive must schedule the graceful-restart timer — and
        the timer's callback (invoked synchronously here, os.kill
        patched) must SIGTERM THIS process exactly as the admin /restart
        button does."""
        ns = self.ns
        ns["_v9902_fd_guard_confirmed"] = 0
        hot = {"available": True, "total": 1000, "soft": 1024,
               "sockets": 900, "pipes": 50, "files": 40, "anon": 10,
               "other": 0}
        with _sandbox_threading():
            # First hot census: spike guard — no timer scheduled.
            ns["_fd_guard_evaluate"](hot)
            timers = list(_FAKE_TIMERS)
            self.assertEqual(len(timers), 0,
                             "a SINGLE hot census must not schedule a restart")
            # Second consecutive hot census: exactly ONE restart timer.
            ns["_fd_guard_evaluate"](hot)
            timers = list(_FAKE_TIMERS)
        self.assertEqual(len(timers), 1,
                         "TWO consecutive hot censuses must schedule the "
                         "graceful restart")
        timer = timers[0]
        self.assertTrue(timer.started)
        self.assertAlmostEqual(timer.interval, 2.0)
        self.assertTrue(callable(timer.function))
        # Invoke the timer's callback synchronously with os.kill patched —
        # proving the restart mechanism (SIGTERM to self, the SAME signal
        # the admin /restart button uses → PTB graceful stop → supervisor
        # respawn).
        killed = []
        real_kill = os.kill
        os.kill = lambda pid, sig: killed.append((pid, sig))
        try:
            timer.function()
        finally:
            os.kill = real_kill
        self.assertEqual(len(killed), 1)
        pid, sig = killed[0]
        self.assertEqual(pid, os.getpid())
        import signal
        self.assertEqual(sig, signal.SIGTERM)

    def test_guard_env_kill_switch(self):
        ns = self.ns
        ns["_v9902_fd_guard_confirmed"] = 0
        old = os.environ.get("VC_FD_GUARD_RESTART")
        os.environ["VC_FD_GUARD_RESTART"] = "0"
        try:
            hot = {"available": True, "total": 1000, "soft": 1024,
                   "sockets": 900, "pipes": 50, "files": 40, "anon": 10,
                   "other": 0}
            with _sandbox_threading():
                ns["_fd_guard_evaluate"](hot)
                ns["_fd_guard_evaluate"](hot)
                timers = list(_FAKE_TIMERS)
            self.assertEqual(len(timers), 0,
                             "VC_FD_GUARD_RESTART=0 must disable the "
                             "restart (census still logs)")
        finally:
            if old is None:
                os.environ.pop("VC_FD_GUARD_RESTART", None)
            else:
                os.environ["VC_FD_GUARD_RESTART"] = old

    def test_census_wired_into_heartbeat_source(self):
        self.assertIn("FD_CENSUS total=%d soft=%d sockets=%d",
                      _HANDLERS_TEXT)
        self.assertIn("await asyncio.to_thread(_fd_guard_evaluate, _census)",
                      _HANDLERS_TEXT)
        self.assertIn("VC_FD_GUARD_CRITICAL", _HANDLERS_TEXT)
        self.assertIn("VC_FD_GUARD_RESTART", _HANDLERS_TEXT)

    def test_service_limit_nofile_is_a_documented_margin(self):
        """The systemd unit raises LimitNOFILE as an operational margin —
        explicitly documented as NOT the leak fix."""
        self.assertIn("LimitNOFILE=4096", _SERVICE_TEXT)
        self.assertIn("NOT THE LEAK FIX", _SERVICE_TEXT)


# ===========================================================================
# FIX-1a (RC-1) — bootstrap asset identity
# ===========================================================================

class TestV9902BootstrapAssetIdentity(unittest.TestCase):

    def test_runtime_asset_hashing_present(self):
        self.assertIn("_v9812_runtime_asset_hashes", _BOOT_TEXT)
        self.assertIn('"assets/vc_silence_600s.opus"', _BOOT_TEXT)

    def test_asset_mismatch_loop_present(self):
        # Stamped assets join the mismatch comparison with an explicit
        # actual=missing entry.
        self.assertRegex(
            _BOOT_TEXT,
            r"for _v9812_asset, _v9812_expected_asha in "
            r"_v9812_asset_hashes\.items\(\):")

    def test_identity_line_includes_asset_hash(self):
        self.assertIn("vc_silence_asset_sha256=", _BOOT_TEXT)

    def test_verified_marker_counts_assets(self):
        self.assertIn("assets=%d", _BOOT_TEXT)
        self.assertIn("stamped data assets verified", _BOOT_TEXT)

    def test_stamp_file_has_assets_dict(self):
        import json
        stamp = json.loads((_SRC / "build_stamp.json").read_text())
        self.assertIn("assets", stamp)
        self.assertIn("assets/vc_silence_600s.opus", stamp["assets"])

    def test_packaged_asset_exists_in_tree(self):
        asset = _SRC / "assets" / "vc_silence_600s.opus"
        self.assertTrue(asset.is_file(),
                        "the silence asset MUST ship in the package — its "
                        "absence in production was RC-1")
        self.assertGreater(asset.stat().st_size, 1024)


# ===========================================================================
# FIX-6 (RC-6) — storm visibility
# ===========================================================================

class TestV9902HeartbeatVisibility(unittest.TestCase):

    def test_heartbeat_failure_is_error_level(self):
        # The rate-limited ERROR form (5-minute throttle).
        self.assertRegex(
            _HANDLERS_TEXT,
            r"logger\.error\(\s*\"BOT_HEARTBEAT_WRITE_FAILED exc=%s "
            r"\(v99\.02 FIX-6")

    def test_rate_limit_window_present(self):
        self.assertIn("_v9902_hb_fail_logged_at >= 300.0", _HANDLERS_TEXT)


# ===========================================================================
# FIX-7 (RC-7) — deterministic leaks
# ===========================================================================

class TestV9902DeterministicLeaks(unittest.TestCase):

    def test_export_document_open_is_context_managed(self):
        # The with-block around send_document (PTB never closes
        # caller-provided file objects).
        self.assertIn("with open(path_str, \"rb\") as _export_fh:", _VC_TEXT)
        self.assertIn("document=_export_fh,", _VC_TEXT)
        self.assertNotIn("document=open(path_str, \"rb\"),", _VC_TEXT)

    def test_media_tools_ffprobe_killed_on_timeout(self):
        self.assertRegex(
            _MEDIA_TOOLS_TEXT,
            r"except \(FileNotFoundError, asyncio\.TimeoutError\) as exc:"
            r"[\s\S]{0,400}?proc\.kill\(\)")

    def test_frame_extractor_children_killed_on_timeout(self):
        for fn in ("_probe_duration", "_duration_via_ffmpeg"):
            self.assertRegex(
                _FRAME_EXT_TEXT,
                rf"async def {fn}\([\s\S]*?"
                rf"except \(FileNotFoundError, asyncio\.TimeoutError\)"
                rf"[\s\S]{{0,300}}?proc\.kill\(\)")


# ===========================================================================
# Artifact version
# ===========================================================================

class TestV9902VersionStamp(unittest.TestCase):

    def test_init_version(self):
        self.assertIn('__bot_version__ = "v99.11.3"', _INIT_TEXT)

    def test_service_version(self):
        self.assertIn("(24/7 supervised, v99.11)", _SERVICE_TEXT)  # v99.11 release bump: tracks CURRENT  # v99.06 derivation


if __name__ == "__main__":
    unittest.main()
