# BOT-18 PRODUCTION FIX REPORT

**Build:** payload-bot_PRODUCTION_B18_FINAL (schema v39)
**Evidence base:** bot-19.log (the authoritative production run), the
uploaded B17 PRODUCTION ZIP (SHA-256 `2b992694cd9623d604ce52203547a94d
2ca1a7ec317e2c4e32b302a976e5d8ee`, 184 entries, schema v38) as the
authoritative baseline, and the B17 UX session's implementation (carried
forward verbatim — see §5).
**Mandate:** fix the two bot-19.log root causes (Network Bot delivery
honesty + Force Join link health), preserve ALL valid B17 functionality
including the website UX, and never substitute FDB success for Network
Bot success in evidence or metrics.

---

## 1. ROOT CAUSES (bot-19.log, final)

### 1.1 Network Bot delivery — the invisible STORAGE channel + the lying labels

```
03:18:30 DELIVERY_SEND_START job_id=34 network_bot_id=2 chat_id=8370454312
03:18:30 NETWORK_RELAY_CREATE_BAD_REQUEST group=-1003963643527
         src=-1004460709020/737 error=Chat not found
         classification=GROUP_INACCESSIBLE_TO_NETWORK_BOT   ← WRONG
03:18:32 NETWORK_DELIVERY_GROUP_ACCESS_CHECK … group_reachable=True
         group_type=supergroup bot_membership=administrator   ← group HEALTHY
         storage_reachable=False                              ← the REAL cause
03:18:32 DELIVERY_GROUP_CAPABILITY_LOST network_bot_id=0
         reason=group access lost: Chat not found             ← group blamed
03:18:32 DELIVERY_MODE_FALLBACK … reason=group_lost
03:18:33 FDB_DIRECT_DELIVERY_SUCCESS chat_id=8370454312 user_message_id=794
03:18:33 NETWORK_DELIVERY_SUCCESS job_id=34 msg_id=794 mode=fdb_direct
                                                              ← THE LIE
03:35:12 (job 35) NETWORK_RELAY_CREATE_TRANSIENT attempt=1 TimedOut
03:35:24 (job 35) NETWORK_RELAY_CREATE_TRANSIENT attempt=2 TimedOut
03:35:27 FDB_DIRECT_DELIVERY_SUCCESS … NETWORK_DELIVERY_SUCCESS mode=fdb_direct
```

Three distinct defects:

1. **The misclassification.** The Mode-A relay-create `copyMessage`
   reads FROM the Storage master INTO the group. "Chat not found" on
   that hop means the NETWORK BOT cannot see the STORAGE channel — the
   access check in the SAME second proved `group_reachable=True` +
   `bot_membership=administrator` + `storage_reachable=False`. The B17
   code blanket-classified "chat not found" as GROUP_INACCESSIBLE and
   marked a HEALTHY delivery group LOST (`DELIVERY_GROUP_CAPABILITY_
   LOST`), hiding the real remediation (add the network bot to the
   Storage channel).
2. **The lying success label.** Jobs 34/35 were delivered by the FDB
   (Mode B fallback) but logged `NETWORK_DELIVERY_SUCCESS … mode=
   fdb_direct` — Mode A never succeeded once, yet the metrics read as
   network-bot delivery.
3. **The transport bound.** PTB's default HTTPX timeouts (read 5 s)
   are too short for large-media `copyMessage` operations — job 35 hit
   two consecutive TimedOut on the same copy (the storage master is an
   856 MB video; `STREAM_AUTH_OK size=856182925`), and the same
   worker's `set_chat_menu_button` TimedOut at 03:34:04 — a client
   headroom problem, not "Telegram is merely slow".

### 1.2 Force Join — a Bot API method that does not exist + the re-add trap

```
03:16:01 FORCE_JOIN_STARTUP_HEALTH channels=7 healthy=0 temporary=7
03:23:57 FORCE_JOIN_INVITE_ROTATE … step=stored → step=revoked →
         result=success                      ← the bot JUST minted a link
03:23:59 FORCE_JOIN_LINK_HEALTH state=temporary_error prev=healthy
         detail=bot API lacks get_chat_invite_link    ← and calls it dead-ish
03:33:55 FORCE_JOIN_LINK_HEALTH state=link_invalid prev=-
         detail=stored link is not a t.me link        ← after remove/re-add
03:33:58 FORCE_JOIN_STARTUP_HEALTH channels=7 healthy=0 temporary=6
         dead_links=1([-1003963044126])               ← a VALID channel, dead
```

Two distinct defects:

1. **The nonexistent method.** The B17 verifier's invite-link path
   called `bot.get_chat_invite_link` — the Telegram Bot API HAS NO
   getChatInviteLink (it can create/edit/revoke invite links but cannot
   introspect them by hash). Every channel with an invite link degraded
   to `temporary_error` at EVERY startup — including a link the bot
   itself had just created, stored and verified 2 seconds earlier.
2. **The re-add trap.** `add_force_channel` creates rows with
   `invite_link=NULL`; after remove/re-add the verifier classified the
   MISSING link as `link_invalid` ("stored link is not a t.me link")
   → `dead_links=1` for a perfectly valid channel. The parser also
   rejected legitimate spellings (tg:// deep links, telegram.dog
   mirrors, @usernames, query strings).

---

## 2. THE B18 FIXES

### 2.1 Evidence-based "Chat not found" disambiguation (app/network/file_delivery.py)

`classify_telegram_delivery_failure` gained `failing_hop` +
`group_reachable`/`storage_reachable` evidence parameters and a NEW
canonical class `STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT` (the
taxonomy is now 11 classes). The Mode-A relay-create runs the REAL
access check FIRST and uses its evidence:

* group proven unreachable → `group_lost` (unchanged honest semantics);
* group reachable + Storage unreachable → verdict
  `storage_master_inaccessible`, classification
  `STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT`, the group is NOT
  degraded, and `NETWORK_RELAY_CREATE_STORAGE_MASTER_INACCESSIBLE`
  states the remediation;
* no usable probe evidence → the legacy honest semantics.

The final user-copy hop (`final_user_copy`) uses the same evidence
before ever degrading the group (a group PROVEN healthy means the
failure is on the user-chat side — `NETWORK_DELIVERY_USER_SIDE_BAD_
REQUEST`, the group is not blamed).

### 2.2 Honest success labels + truthful fallback metrics

* `NETWORK_DELIVERY_SUCCESS` is logged ONLY when the network bot itself
  performed the user-facing send (`mode=network_relay` — first attempt
  or retry). Every FDB send (first attempt, handoff completion, retry)
  logs `FDB_DIRECT_DELIVERY_SUCCESS`. `mode=fdb_direct` can NEVER
  appear behind the NETWORK_DELIVERY_SUCCESS label.
* `DELIVERY_MODE_FALLBACK` logs the TRUE Mode-A verdict verbatim (the
  B17 editorial "the standard deployment … exactly the primitives that
  WORKED" spin is gone) and records it durably on the job row:
  `delivery_jobs.mode_a_failure` / `mode_a_failure_at` (schema v39) —
  including `no_delivery_group` (Mode A impossible) and
  `capability_cached_no` (the probe cache skip). Metrics distinguish
  "Mode A failed → fallback delivered" from a clean Mode-B delivery
  without parsing logs.
* `NETWORK_RELAY_MESSAGE_CREATED_BY_NETWORK_BOT` appears only on a real
  network-bot relay creation (unchanged, now regression-locked).

### 2.3 Diagnostics on every failure class + the true nid

`NETWORK_DELIVERY_GROUP_ACCESS_CHECK` (the real executable diagnostic
probing with the network bot's OWN client) now runs on BadRequest,
ChatNotFound, Forbidden, TimedOut, NetworkError and unknown exceptions —
RetryAfter logs the classification WITHOUT probes (extra API calls
under flood control make it worse). The check carries `failing_hop`
(so `source_reachable` reflects the chat the failing copy actually READ
from — bot-19.log 03:18:32 reported `source_reachable=True` for a
Mode-A failure whose source, the Storage master, was provably
unreachable), the TRUE registry nid (bot-19.log showed
`network_bot_id=0 registered_bot_id=-` because the old call guessed via
a group-id heuristic), and re-derives the classification from its OWN
probe evidence.

### 2.4 Explicit delivery HTTP timeouts

PTB's 5 s HTTPX defaults produced bot-19.log's consecutive TimedOut
failures. Every delivery client now uses explicit timeouts,
centralized in `_delivery_httpx_request_kwargs` (read/write 60 s,
connect 30 s, pool 30 s): the network worker applications
(`ApplicationBuilder.request(HTTPXRequest(...))` +
`.get_updates_request(...)` in `app/network/lifecycle.py`) and the FDB
manager client (`app/network/file_delivery.py:_make_client`). The
fallback semantics stay UNCHANGED (TimedOut remains transient, bounded
retries, then Mode B) — this raises the headroom so a merely-slow
Telegram no longer fails the hop.

### 2.5 The Bot-API-CAPABLE Force Join link health (app/core/fj_link_health.py)

* **`normalize_join_link`** — the canonical URL normalizer:
  https://t.me/<username>, https://t.me/+<hash>,
  https://t.me/joinchat/<hash>, http/https + bare-domain forms,
  telegram.me + telegram.dog mirrors, `tg://join?invite=<hash>`,
  `tg://resolve?domain=<username>`, @username, query strings/fragments,
  case-insensitive hosts → the canonical `https://t.me/<...>` form
  (joinchat normalizes to the uniform `+<hash>` spelling). Message
  permalinks (`t.me/c/...`) are honestly rejected (not join links).
* **`verify_invite_link`** rewritten:
  * missing/blank link → `NO_LINK` (NOT dead — auto-creatable; the
    remove/re-add fix);
  * garbage → `LINK_INVALID` (honest dead, the valid-join-link wording);
  * public links → verified by username resolution via getChat: id
    MATCH = HEALTHY (proven), id MISMATCH = LINK_INVALID (Telegram-
    proven wrong-chat), resolution failure NEVER a dead verdict
    (UNVERIFIABLE / TEMPORARY_ERROR for transient errors);
  * invite links → the Bot API cannot introspect the hash (documented
    precisely — no getChatInviteLink exists); the correct alternative
    path verifies the CHANNEL: the bot's own membership via
    getChatMember (administrator/creator → the bot can serve the
    channel, check user membership and mint links) + the link's
    PROVENANCE: `bot_created` = provably valid until OUR OWN rotation
    revokes it; `custom` = trusted with the capability limit stated
    (Test Channel / Auto Change Link remain available). Non-admin →
    `BOT_PERMISSION` (actionable, not dead); channel gone →
    `CHANNEL_INVALID`; transient → `TEMPORARY_ERROR`.
  * A capability limitation NEVER becomes a misleading permanent
    failure (the every-channel-temporary loop) NOR a dead verdict.
* **Provenance (schema v39)** — `force_join_channels.link_provenance`
  ('bot_created' | 'custom' | NULL=legacy-trusted): set by the rotate /
  export / create paths ('bot_created') and the custom-link path
  ('custom'); `set_force_invite_link` gained the keyword.

### 2.6 Remove/re-add self-healing (app/presentation/telegram/forcejoin.py + lifecycle.py)

The startup Force-Join pass is extracted into the testable
`fj_startup_health_pass` (same behavior, driven by post_init) and:

* `NO_LINK` channels self-heal: when the auto-repair policy
  (`fj_link_auto_rotate`, default ON) allows it, the bot MINTS a fresh
  link (`export_chat_invite_link` — admin + invite rights required),
  stores it with `provenance='bot_created'`, marks the channel healthy
  and logs `FORCE_JOIN_LINK_AUTO_CREATED` — remove/re-add needs NO
  manual workaround. On failure NO_LINK stays honest (the link is
  created lazily on the next Join-button render).
* The startup aggregate gained the `no_link` count
  (`FORCE_JOIN_STARTUP_HEALTH … no_link=N`).
* The admin custom-link validator (`_fj_validate_custom_link`) accepts
  the full normalized vocabulary; the add-wizard URL branch
  (`_fj_resolve_input`) handles telegram.me / telegram.dog / bare
  t.me hosts.

### 2.7 Honest DELIVERED (audit of every write path)

All `JOB_DELIVERED` writes were audited (and are now regression-locked
by a source/AST test): every write is gated on a real Telegram send's
message id (`mid/sent is not None`, the fail-early `if sent is None:
return` form, the `_mark_delivered_and_cleanup(sent_mid: int)` contract
with caller gating, or the TTL pass's confirmed-only rule
`status == JOB_DELIVERED and user_message_id`); every other TTL row
settles EXPIRED — an unconfirmed outcome can NEVER be DELIVERED.

---

## 3. VERIFICATION

* **Full regression battery:** 42 suites, **3,082 checks, 0 failures**
  (incl. the 3 new B18 suites: delivery honesty 53, FJ link health 76,
  FJ remove/re-add 31 — the exact 12-step Phase-5 production sequence
  against a real v39 DB + simulated Telegram, ending with the bot-19
  aggregate reproduction: `channels=7 healthy=7 temporary=0
  dead_links=0` where bot-19.log showed `healthy=0 temporary=7`).
* **Browser QA (real Chromium):** B17 UX suite **37/37** (auto-hide
  lifecycle, single-row bar at 320/360/390/412, mobile Settings sheet,
  16:9 stage, tablet/large-desktop, loading/buffering/error+retry/FJ
  gates/unavailable/ad states, light theme, ZERO severe console errors)
  + B16 functional suite **45/45** (real HLS transcode, quality/speed
  menus, fullscreen/PiP, resume/start-over, ad separation, FJ gate +
  in-place verify, no /site/site URLs, zero console errors) — the
  carried-forward UX work has NO regression.
* **compileall** clean; **secret scan** 217 files, 0 findings.
* **Legacy upgrades:** a v38-stamped DB missing the v39 columns is
  migrated (columns re-added, version 39) — verified.
* **Obsolete tests replaced with documented reasons** (the Phase-8
  rule): the `get_chat_invite_link` introspection pins (the premise —
  that some clients have the method — is false; the fake HAVING it is
  why the suite passed while production burned), the B11 FDB-authored
  relay flow pins (network-bot-authored relays are the B17+ invariant),
  the B16 crash-ambiguous→DELIVERED rule (the lie bot-16.log disproved),
  and the schema version pins (36/37/38 → 39).

---

## 4. ENVIRONMENT-BLOCKED (honest)

* **Real Telegram E2E** (the network bot itself creating a relay +
  delivering to a real user; Force Join verifying a real channel after
  remove/re-add): no real Telegram credentials / production Local Bot
  API are available in this environment. All Telegram interactions in
  the B18 suites are SIMULATED (fabricated exceptions with the exact
  production class names and texts, capability probes, membership
  states). **Code/package verified; real Telegram E2E remains
  environment-blocked.**
* **Large-file production E2E (≈800–856 MB):** requires the production
  Local Bot API server. The B17 large-file pipeline (MEDIA_GETFILE_
  TIMEOUT, resume, locking, concurrency, FFprobe/FFmpeg, HLS, cleanup)
  is preserved and covered by the B16/B17 test surfaces
  (test_bot16_transcode 149/0 + the browser HLS checks); the
  production-size run itself is environment-blocked.

---

## 5. B17 UX PRESERVATION (carried forward, verified)

The uploaded B17 PRODUCTION ZIP predates the UX session (its html.py
has none of the UX markers), so the UX implementation was carried
forward from the UX session's tree verbatim: the SVG icon system,
auto-hide controls (2.8 s idle; mouse/touch/keyboard wake; pinned
while paused/menu-open), the mobile single-row control bar + Settings
sheet (speed/quality/PiP), the 16:9 letterboxed stage (object-fit
contain), responsive 320–1536, the FJ gate mobile fix, the big-play
z-order fix, the anchored popover menus, verdict/state SVG icons, HLS
player, fullscreen/PiP, resume/start-over, error/retry UI, ad
separation, and light/dark themes. Both browser suites re-verified the
whole surface on the B18 tree (37/37 + 45/45).

---

## 6. MIGRATION NOTES

Schema v38 → v39 is additive and idempotent (three new nullable
columns; legacy rows keep NULLs — `link_provenance` NULL is treated as
trusted-custom, `mode_a_failure` NULL means "no Mode-A failure
recorded"). Fresh databases stamp 39 directly. No setting seeds, no
row modifications, no breaking changes for v36/v37/v38 databases.
