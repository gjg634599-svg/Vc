# WEBSITE PHASE 4 REPORT — Media Gateway + Large-File Streaming + Cache

**Status:** IMPLEMENTED → TESTED → FULL REGRESSION → CLEAN BUILD → ZIP →
FRESH-EXTRACTION RE-TEST → DIFFERENTIAL CHECK → **STOPPED AT THE GATE**.

**Baseline:** the verified Phase 3 ZIP (`payload-bot_website_phase3_1.zip`)
was extracted into a clean directory and the full Phase 3/2/1 critical
battery re-run GREEN **before any modification** (197/0 + 70/0 + 77/0 +
88/0 + 96/0 + both evidence runners).

**Deliverable:** `payload-bot_website_phase4.zip` (992,655 bytes,
168 entries, `unzip -t` clean, junk scan: 0 — the single grep hit is
`.env.example`, a placeholder template with no secrets).

---

## 1. Media Gateway architecture (spec §1/§6)

```
Website pages (app/web/site)
  → Mini App initData (multi-token HMAC, server-side)
  → Website Payload authorization (Phase 3 listing resolver)
  → EXISTING Access Engine (injected access_check — re-verified on EVERY
      stream request: a revoked user cannot ride an unexpired token)
  → short-lived AEAD stream token (app/media/streamtokens.py)
  → MEDIA GATEWAY (app/media/gateway.py — owns streaming behavior)
  → Phase 1 MediaResolver + sources (Local Bot API / Cloud — reused,
      never duplicated; the ranged retry policy lives in stack.py)
  → bounded shared streaming cache (app/media/streamcache.py)
  → HTTP response (app/web/site/stream.py — thin HTTP ⇄ StreamPlan)
```

Layering proof (structural pins, test_media_phase4.py §19): the gateway
and web/stream modules import **no telegram library**, contain **no
`api.telegram.org` calls**, no `file_id` recovery logic, no second Access
Engine, no second resolver. `bot.py` changes are thin wiring + migration
seeds only (+153/−5 lines, every removal is a docstring/version-bump
line).

## 2. Range behavior (spec §7/§25)

`app/media/ranges.py` (pure RFC 7233 single-range parser) + the gateway:

| Request | Result |
|---|---|
| no Range | `200` + `Content-Length: size` + `Accept-Ranges: bytes` |
| `bytes=0-0` | `206`, 1 byte, `Content-Range: bytes 0-0/size` |
| `bytes=0-1023` | `206` + exact window + headers |
| middle range | `206` + exact window |
| `bytes=1024-` | `206` to EOF |
| `bytes=-1024` | `206` last 1024 bytes (suffix > file ⇒ whole file) |
| exact final byte | `206`, 1 byte |
| end > EOF | clamped to EOF (`206`, not 416) |
| start ≥ EOF / `bytes=-0` | `416` + `Content-Range: bytes */size` |
| malformed (`bytes=abc`, `bytes=5-2`, …) | ignored → `200` full |
| multiple ranges | ignored → `200` full (single-range server) |
| unknown size | ranges not advertised; honest `200` stream |
| HEAD | headers only (Content-Length/Type/Accept-Ranges), **no body,
  no download** (§9) |

All verified over real HTTP in test_media_phase4.py (§5, 25 range checks)
and over the live loopback local Bot API (§15).

**A small range is never a full-file download:** local mode seeks
natively (`open_range_with_retry`); cloud mode transfers only the prefix
and **stops at the window end** (stream-skip passthrough, bounded RAM);
a cached media serves the window from disk with zero upstream calls.

## 3. Stream-token design (spec §4/§5)

* **Binding:** user id + listing opaque id + canonical file pk + purpose
  (`stream`|`thumb`) + expiry + random nonce. AEAD through the EXISTING
  `CredentialVault` (Fernet primary / stdlib HMAC-CTR fallback) — no new
  cryptography; plaintext contains **no** bot tokens, **no** file_ids,
  **no** DB secrets.
* **Lifetime:** default **300 s**, live-configurable via the
  `website_stream_token_ttl` bot_setting (admin panel, minutes
  granularity), hard-clamped to [30 s, 3600 s]. Documented in the admin
  panel and this report. Tokens are intentionally REUSABLE within their
  short life (video players issue many Range requests per token);
  outside the lifetime every binding fails closed.
* **Fail-closed:** tampered / wrong key / malformed / expired / wrong
  purpose → 401; wrong media/payload membership → 404; the Phase 3
  video-ref format is not interchangeable with stream tokens.
* **Replay outside context:** the gateway re-runs the EXISTING Access
  Engine on every request with the token's user — access revocation
  takes effect immediately (proven by ACC3: a token minted for an
  authorized user becomes 403 the moment their access is revoked).
* **Bearer semantics (honest limitation):** `<video src>` cannot present
  a second credential, so within its short TTL a copied token is usable
  by whoever holds it — identical to every signed-CDN video URL design.
  Mitigations: short TTL + per-request engine re-verification + rate
  limits + concurrency caps.

## 4. Cache design (spec §14–§18)

`app/media/streamcache.py`:

* **Identity:** `file_unique_id` (via `app/media.cachekeys`, hashed into
  the on-disk path). A repaired `file_id` never changes the logical
  entry (proven: CCH6 — no duplicate entries after repair).
* **Bounds:** configurable root (`MEDIA_CACHE_ROOT` env or
  `<db dir>/media_cache`), max total bytes (default 2 GiB, live admin
  setting), TTL (default 3600 s, live admin setting). Deterministic
  LRU eviction + TTL expiry + size-cap pressure (proven: CCH8/CCH9).
* **Active-reader protection (mandatory):** every reader holds a
  refcount; cleanup/purge NEVER delete an entry with readers > 0;
  purged-and-active entries are doomed and removed after the last
  reader finishes (proven: ARP1–ARP5 — a reader completes correctly
  AFTER cleanup ran mid-read).
* **Concurrency/coalescing:** the first reader of uncached media becomes
  the filler — ONE upstream download per identity; concurrent readers
  (full GETs or overlapping ranges) read the committed prefix from disk
  and follow the fill via a per-entry condition (proven: CON1–CON4 —
  two and four simultaneous readers, exactly ONE upstream open).
* **Failure safety:** any disk failure degrades the reader to direct
  passthrough and drops the un-persisted entry (CCH10/11 — exact bytes
  still served, canonical records untouched). Fill abort keeps the
  partial prefix and falls back to direct for the remainder.
* **Restart safety:** partial `data` files are recovered as partial
  entries (available = file size); `meta.json` disagreement with bytes
  is treated as incomplete (honest).

## 5. Local Bot API / Cloud status (spec §10/§11/§27)

* **Local Bot API (primary large-file transport):** implemented through
  the Phase 1 `LocalBotApiSource` — HTTP mode (Range → requires 206,
  honest `RangeUnsupportedError` otherwise) AND shared-filesystem disk
  mode (`MEDIA_LOCAL_FILE_ROOT` + realpath containment + native seeks).
  The ranged transport runs under the stack's single-retry repair policy
  (`open_range_with_repair`, added to `stack.py`).
  **LIVE Local Bot API status: NOT available in this sandbox — no real
  Local Bot API instance exists here.** Verified through: (a) a REAL
  loopback aiohttp server emulating a Local Bot API with true Range
  semantics (test §15 + the browser QA driver), and (b) disk-mode tests
  with native seeks. Reported honestly: **implemented + fake/loopback
  verified; live untested.**
* **Cloud Bot API:** the 20 MB (configurable) retrieval cap is enforced
  BEFORE streaming — media beyond the cap answers a controlled **503
  `too_large_for_transport`** with the Local Bot API guidance (TOO1–3).
  No infinite fallback loops, no fake multi-GB claims.

## 6. file_id repair integration (spec §12)

The gateway contains **no repair logic** — the Phase 1 stack owns it:
`stack.open` (single-retry policy) for full streams, the NEW
`stack.open_range_with_repair` for native-seek ranges (same discipline:
exactly ONE recovery + atomic DB repair + ONE retry; never after bytes
were yielded; never a loop). Verified end-to-end through the gateway
(REP1–REP6b): stale `file_id` → upstream rejection → source recovery →
identity validation → atomic `file_id`-column repair (canonical row
preserved) → one retry → exact bytes. Persistent identity failure ⇒
bounded honest abort (never the full media, never a hang).

## 7. Player integration (spec §20/§21/§22)

The Phase 3 honest "Open in Telegram / playback arrives with the
streaming update" page is now the real player page:

* **Playback:** `POST /site/api/stream` (verified initData + video ref +
  Access Engine) mints the token; the page mounts a **native
  `<video controls playsinline preload="metadata">`** (play/pause/seek/
  buffering/volume/fullscreen/progress via native controls), `<audio>` for
  audio/*, `<img>` for image/* — selected by the **indexed MIME**
  (never a blind `video/mp4`); anything else renders the honest
  "Not streamable in the web player" state (PLA11, SEC-R3:
  `application/pdf` served as `application/pdf`).
* **Next/previous:** parts pills + Prev/Next navigate ONLY within the
  canonical Payload's ordered file list (PLA5/PLA6 — never unrelated
  payloads).
* **Resume:** client-side `localStorage` scoped STRICTLY to
  `user + payload + media` (`plresume:<uid>:<listing>:<file_pk>`) with a
  Resume / Start-over bar; cleared on ended; throttled writes; one
  user's position never affects another's (§21).
* **Live browser proof:** real playback through the gateway (video
  `t=2.96 s, paused=false`, duration 8 s), seeking (t=6.97 s after seek
  to 5), feed thumbnails loading (4/4 `<img>` complete), parts
  navigation, honest deny state outside the Mini App, and maintenance
  mode toggling — screenshots in `download/phase4-qa/`.
* **Thumbnails (§23):** `/site/thumb/{token}` serves bounded bytes
  (2 MiB cap, magic-byte type sniffing, browser caching) through the
  Phase 3 priority chain over the EXISTING source classes with a
  thumb-scoped file-id provider; un-fetchable Telegram document thumbs
  degrade to the styled placeholder SVG — never an error page, never
  arbitrary retrieval (AEAD token bound to the published listing).

## 8. Security results (spec §24 A–S)

| # | Test | Result |
|---|---|---|
| A | valid token | 200/206 exact bytes ✓ |
| B | expired token | 401 ✓ |
| C | malformed token | 401 ✓ |
| D | modified token (bit flip) | 401 ✓ |
| E | wrong user (token's user denied) | 403 ✓ (bound to the token's user) |
| F | wrong media (file not in payload) | 404 ✓ |
| G | wrong payload (unknown listing) | 404 ✓ |
| H | wrong purpose (thumb↔stream swap) | 401 ✓ both directions |
| I | direct stream URL without authorization | 401 (no token) / 403 (revoked) ✓ |
| J | Website OFF | 503 maintenance on media/thumb/issuance; `/healthz` alive; engine verdicts identical ✓ |
| K | invalid initData | 401 at issuance ✓ |
| L | admin/non-admin separation | `wsite:*` behind the bot.py master admin gate (structural pin) ✓ |
| M | path traversal (`../../`, `%2e%2e`) | 400/401/404, no file access ✓ |
| N | file_id leakage | none in pages/responses ✓ |
| O | bot token leakage | none in pages/headers ✓ |
| P | stream token leakage | tokens only in the authorized issuance response; never in pages/headers/logs ✓ |
| Q | SQL injection (opaque id / token / video_ref) | parameterized; 404/401/400, no crash ✓ |
| R | XSS (`<script>` in file names) | HTML-escaped, JSON-safe ✓ |
| S | rate limiting | issuance 30/min → 429; media 240/min; thumb 120/min → 429; per-IP concurrent cap 6 → 7th stream 429 ✓ |

Website OFF independence (§3/§31): the engine span contains **no**
website flag (structural pin); `enforce_access` call sites unchanged
(== 9); engine verdicts byte-identical with the Website ON vs OFF; the
Website flag is checked only in the presentation handlers.

## 9. Large-file test results (spec §26/§19)

Controlled 64 MiB deterministic fixture through the REAL loopback local
Bot API + the shared cache:

* initial playback range (first 1 MiB) — exact bytes;
* middle seek (16 MiB) + later seek (47 MiB + offset) — exact 206 bytes;
* resume continuation (`bytes=20971520-` open-ended) — exactly
  LARGE_SIZE − 20 MiB bytes;
* concurrent reader during the fill — both exact, ONE fill;
* cache reuse — full 64 MiB replay with **zero** upstream opens;
* **bounded memory:** `ru_maxrss` high-water delta while streaming
  63 MiB stayed **< 48 MiB** (observed ≪; the whole 64 MiB was streamed
  and cached on disk — full-file RAM buffering would have pushed the
  high-water by ≥ 64 MiB);
* client disconnect mid-stream — concurrency slot and cache reader
  released, no leaks.

**Honest scope statement:** no live multi-GB Telegram media was tested —
the environment has no real Local Bot API instance. The HTTP/memory/
cache mechanics are proven with the controlled 64 MiB local fixture;
live multi-GB behavior depends on the Local Bot API deployment and is
**not claimed as tested**.

## 10. Tests — exact commands and counts

All commands executed from the working tree, the clean staging tree, and
the fresh ZIP extraction (Python 3.12, aiohttp 3.13, python-telegram-bot
22.8):

```
python3 test_media_phase4.py        # MEDIA PHASE 4 RESULT: 200 passed, 0 failed
python3 test_media_phase3_ux.py     # 70/0
python3 test_media_phase3.py        # 197/0
python3 test_media_phase2.py        # 77/0
python3 test_media_phase1.py        # 88/0
python3 test_watch_ads.py           # 91/0
python3 test_watch_ads_v2.py        # 142/0
python3 test_watch_ads_v3.py        # 104/0
python3 test_watch_ads_v4.py        # 153/0
python3 test_watch_ads_v5.py        # 142/0
python3 test_watch_ads_v6.py        # 113/0
python3 test_watch_ads_v7.py        # 85/0
python3 test_botv13_phase6.py       # 124/0
python3 test_botv13_phase7.py       # 151/0
python3 test_botv13_phase7_hotfix.py# 94/0
python3 test_botv13_phase8.py       # 77/0
python3 test_network.py             # 79/0
ADMIN_IDS=1001 BOT_TOKEN=123456:TEST-TOKEN-PHASE1 python3 test_architecture.py   # 96/0
python3 run_phase8_evidence.py      # PHASE 8 EVIDENCE: ALL SECTIONS PASS
python3 run_network_evidence.py     # NETWORK EVIDENCE: ALL SECTIONS PASS
```

**Total: 18 suites, 2,083 checks, 0 failures + 2 evidence runners — all
executed NOW (not historical).** Version-stamp expectations in 10 prior
test files were updated (values only) for the v32 chain — the documented
Phase 3 pin discipline.

## 11. Clean build + ZIP integrity

* Clean staging `phase4-clean/payload-bot`: 142 files, junk scan 0
  (no `__pycache__`/`*.pyc`/logs/DBs/`.env`/cache dirs); `py_compile` all
  modified files; clean-interpreter `import bot` + all new modules OK.
* Critical battery re-run from clean staging: 200/0 + 197/0 + 77/0 +
  88/0.
* `payload-bot_website_phase4.zip`: 992,655 bytes, 168 entries,
  `unzip -t` — no errors; junk scan — only `.env.example` (placeholder
  template, no secrets).
* Fresh extraction into a NEW directory re-ran: phase4 200/0 + phase3
  197/0 + phase3ux 70/0 + phase2 77/0 + phase1 88/0 + architecture
  96/0 + network 79/0 + phase7-hotfix 94/0.

## 12. Differential vs the Phase 3 ZIP

* **Added (6):** `app/media/gateway.py`, `app/media/ranges.py`,
  `app/media/streamcache.py`, `app/media/streamtokens.py`,
  `app/web/site/stream.py`, `test_media_phase4.py`.
* **Deleted (0).**
* **Changed (19):** source — `bot.py`, `app/bot/handlers/website.py`,
  `app/media/stack.py`, `app/storage/migrations.py`,
  `app/web/site/html.py`, `app/web/site/pages.py`,
  `app/web/site/ratelimit.py`; tests — 12 files with version-stamp pin
  updates only.
* **bot.py change categories (every line accounted):** +153/−5. Added:
  the v32 settings-only migration block (INSERT OR IGNORE seeds, no
  DDL), the `_website_media_gateway()` lazy singleton + its two module
  globals (stack+cache+gateway composition with the production recovery
  transports), `media_gateway=` fields in `_website_deps_factory` and
  `_wsite_deps`, and explanatory comments. Removed: the `SCHEMA_VERSION`
  value line (31→32) and two docstring lines updated in place. **No
  Telegram flow, handler, or frozen log line was touched.**

## 13. Admin controls (spec §30)

Streaming & Cache panel (inside the EXISTING Website Settings — no
second panel): REAL stream/cache ON/OFF toggles (live on the next
request — proven by ADM5), stream-token TTL editor (clamped 1–60 min,
honored end-to-end — ADM7/8), cache size + TTL editors, REAL cache purge
(active-reader aware — ADM9), Local Bot API transport status (mode,
READY/not-configured, chunk size, timeout), cache stats (entries/bytes/
readers/hits/misses/evictions/fallbacks), playback readiness counts.
Every button is functional; none are fake.

## 14. Observability (spec §29)

Log vocabulary: `STREAM_AUTH_OK` / `STREAM_AUTH_FAIL` /
`STREAM_START` (range + strategy) / `STREAM_HTTP_COMPLETE` /
`STREAM_HTTP_ABORT` / `STREAM_CLIENT_DISCONNECT` / `STREAM_ERROR` /
`RANGE_ERROR` / `MEDIA_CACHE_FILL_START|COMPLETE|ABORT|EVICT|PURGE|
CLEANUP|ERROR|THUMB_*` + the Phase 1 `MEDIA_*` vocabulary. Logged fields
are identities, byte counts, and durations — **never** stream tokens,
bot tokens, or file_ids (proven: OBS4–6).

## 15. Honest limitations

1. **No live Local Bot API instance** exists in this sandbox — local
   transport verified against a REAL loopback HTTP emulation (true Range
   semantics) and disk-mode native seeks; live deployment verification
   remains for the operator.
2. **No live multi-GB Telegram media test** — controlled 64 MiB local
   fixture proves the HTTP/memory/cache mechanics; nothing larger is
   claimed.
3. **Stream tokens are bearer credentials within their short TTL**
   (standard signed-URL semantics) — revocation is enforced per request
   via the Access Engine, but a copied unexpired token is replayable by
   its holder until expiry (mitigated by the 300 s default TTL).
4. **Cloud range requests transfer the prefix** from Telegram's
   non-ranged file endpoint (bounded RAM, no full-file buffering, stop
   at window end) — inherent to the cloud Bot API; the local transport
   is the ranged path by design.
5. **Telegram document/video thumbnails are generally not retrievable
   through the Bot API** — those listings render the styled placeholder
   (honest degradation); photo-based artwork serves real bytes.
6. **The web player resume state is client-side localStorage** (per
   §21's "client-side or server-assisted as appropriate") — no server
   playback telemetry is stored.

## 16. Remaining risks

* A Local Bot API deployment behind a PUBLIC host would only receive a
  warning log (the Phase 1 heuristic) — operator must enforce the
  private-network requirement (spec §17).
* The cache directory grows toward its cap between cleanups; eviction
  runs on maintenance calls and fills (a periodic cleanup job is
  available via `cache.cleanup()` for ops scheduling).
* Browsers that ignore `Accept-Ranges` heuristics on unknown-size media
  receive honest 200 streams (never fabricated 206s).

**STOP GATE: Phase 4 complete. Phase 5 NOT started. Awaiting explicit
operator approval.**
