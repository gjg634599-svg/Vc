# ARCHITECTURE DECOUPLING REPORT — bot.py extraction (FINAL ARCHITECTURAL HARDENING)

Baseline: `payload-bot_website_phase5.zip` (SHA-256 `6fb6b92e3744feb1d3ead3d57e535a41356eaa5102168a970af64d6c26cfecfa`, 145 files, bot.py md5 `e04dc1466e37387ca0d84ff041c8c99c`, SCHEMA_VERSION=32, Phase 5 regression 2,175/0).

Final artifact: `payload-bot_architecture_final.zip` — 152 files (151 code/test files + this report), bot.py md5 `817273ac8fd58a3c57300a676d56d5dc`, SCHEMA_VERSION **unchanged** = 32, full regression **2,226/0** = 2,175/0 existing + 51/0 new architecture-decoupling suite, both evidence runners ALL SECTIONS PASS, and the ZIP extraction itself re-ran the complete battery. The artifact's SHA-256 is external metadata (this report ships INSIDE the ZIP, so the container hash is recorded in the delivery handover, not self-referenced here).

Objective status: **the application's composition no longer depends on bot.py.** `run.py → app/bootstrap/application.py → (injected legacy handler layer) → app/services/container.py → domain services → Telegram/Web handlers`. bot.py is no longer the architectural center: it is the legacy Telegram handler layer plus a thin, documented compatibility facade.

---

## 1. Original bot.py responsibilities (Phase 5, 28,286 lines)

| Zone (baseline lines) | Responsibility | Classification | Destination | Risk |
|---|---|---|---|---|
| 46–299 | stdlib/PTB/app imports | import glue | stays (facade imports) | none |
| 301–711 | `_svc_make_*` stubs, **208 lines of byte-identical duplicate definitions** (8 names redefined 2–42×) | P dead/obsolete | duplicates DELETED (verified identical; last binding preserved) | none |
| 714–1389 | ~200 `(*args, **kwargs)` forwarding facades → app/core + app/bot services | O compatibility shim | stays (facade layer) | none |
| 1391–1412 | aiohttp optional import | B/K config/web | `app/web/server.py` (guarded import) | low |
| 1414–1432 | BOT_TOKEN / ADMIN_IDS (2 hard ValueError guards) / DATABASE_FILE env parsing | B configuration | `app/bootstrap/config.py` (`RuntimeConfig.from_env`) | low (order + messages verbatim) |
| 1435–1450 | `_compute_runtime_build_id` (SHA-256 of bot.py source) | B configuration | `app/bootstrap/config.py` (`compute_runtime_build_id(source_file)`; bot.py passes `__file__` — test-pinned identity preserved) | low |
| 1453–1711 | operational constants + feature toggles (env) | B configuration | env-driven → `RuntimeConfig`; bound back as bot.py module names (patchable) | low |
| 1573 | `SCHEMA_VERSION: int = 32` | D/E schema | `app/storage/schema.py` (re-exported) | low |
| 1715–1725 | logging.basicConfig + shared logger | B process | stays in bot.py (process-level; CWD-relative bot.log is documented behavior) | none |
| 1731–2544 | `SCHEMA_SQL` (814-line DDL) | D/E schema | `app/storage/schema.py` **verbatim** | low |
| 2550–4242 | `class Database(DatabaseBase)` — full migration chain v2→v32 + all repositories mixins + watch-ad session store | D database / E migration | `app/storage/schema.py` **verbatim** (runtime context injected) | medium |
| 4264–7316 | delivery send infra, RateLimiter, index jobs, join requests, settings accessors, media extraction, FJ delivery-side, auto-delete | I Telegram business | **stays** (legacy handler layer — documented boundary) | n/a |
| 7316–7730 | `access_engine()` orchestration + `enforce_access` | I access | **stays** (engine core already in app/core/access; tests patch `B.access_engine`) | n/a |
| 7730–23045 | referral dashboards, watch-ad screens, retrieve/delivery, admin commands, reindex engine, text/media wizards, collections, broadcasts, admin panels | G/H/I handlers | **stays** (legacy handler layer) | n/a |
| 23045–25659 | `on_callback` router (2,614 lines) | H callback routing | **stays** (authoritative router; delegates to app/bot/callbacks/router.py where applicable) | n/a |
| 25659–25710 | `on_error` | G | stays | n/a |
| 25710–26111 | `post_init` + `startup_reindex_all_channels` | F/M lifecycle | orchestration stays (Telegram layer); infra parts now called through the new composition modules | medium |
| 26113–26138 | `post_shutdown` | M lifecycle | orchestration stays; calls the new facades | low |
| 26173–27508 | `_wad_*` Mini App request handlers + reward resume/notify | K web handlers | **stays** (handler layer; routes bind via ns) | n/a |
| 27508–27586 | `_website_media_gateway` (production gateway construction) | K media composition | `app/services/container.py` → `website_media_gateway(ns)` (§8) | HIGH VALUE |
| 27589–27624 | `_website_network_bot_tokens` | K | `app/services/container.py` → `website_network_bot_tokens(ns)` | medium |
| 27627–27659 | `_website_deps_factory` + `_wsite_deps` | K/J website deps | `app/services/container.py` → `website_deps_factory(ns)` / `website_admin_deps(ns)` | medium |
| 27662–27708 | `_handle_wsite_*` facades | O compat | stays (already facades → app/bot/handlers/website.py) | n/a |
| 27711–27774 | `start/stop_mini_app_server` (aiohttp AppRunner/TCPSite) | J server lifecycle | `app/web/server.py` | medium |
| 27791–28171 | network singletons, `init_network_services`, worker error classification, `_network_callback_guard`, `_build_network_bot_application`, `_network_send_file_by_source`, `network_startup`, `_net_health_loop`, `network_shutdown` | L/M network wiring | `app/network/lifecycle.py` (§7/§9) | medium |
| 28173–28275 | `build_application` (composition root: PTB builder + 38 command + 6 update handlers + error handler) | F composition | `app/bootstrap/application.py::build_application(mod)` + `app/bot/registration.py` (registry as data; order preserved verbatim) | medium |
| 28278–28285 | `main` | A entrypoint | `app/bootstrap/application.py::run_production(mod)`; run.py injects bot | low |

## 2. Extracted responsibilities (final architecture)

```
run.py ──────────────► app/bootstrap/application.py  (run_production — the REAL path)
                         │  build_application(mod): PTB composition + fail-closed guards
                         │  app/bot/registration.py: 38 commands + 6 handlers (order verbatim)
                         ▼
app/services/container.py  (AUTHORITATIVE composition boundary)
   ├── legacy_service_factories(ns): payload / referral / watch-ads /
   │     access-points / force-join / delivery / web-auth / keyboards / network-ui
   ├── website_media_gateway(ns)      ← §8 application-level media composition
   ├── website_network_bot_tokens(ns)
   ├── website_deps_factory(ns) / website_admin_deps(ns)
   └── (clean mode) ServiceContainer / create_container / bind_legacy bridge
                         ▼
app/storage/schema.py      (Database + SCHEMA_SQL + migration chain — storage-owned, §10)
app/web/server.py          (Mini App / Website aiohttp server lifecycle, §3/§8)
app/network/lifecycle.py   (network service init/start/shutdown + worker apps, §7/§9)
app/bot/handlers/ + app/bot/callbacks/   (extracted network/website handlers — unchanged)
app/core/*  app/media/*  app/network/*   (domain + infrastructure — unchanged Phase 1–5 modules)
                         ▼
bot.py (25,053 lines): legacy Telegram handler layer + compatibility facade
   • handlers/wizards/panels/on_callback/_wad_* request handlers (documented boundary)
   • thin facades delegating composition to the modules above
   • module-level names re-exported for the 488 test-visible attributes
```

**Late-binding contract (the key preservation mechanism):** every extracted composition function takes `ns` — the legacy bot.py namespace — and resolves ALL state/collaborators at CALL TIME (`ns.db`, `ns.access_engine`, `ns._net_registry`, `ns._website_gateway_singleton`, …). This preserves the regression suites' monkey-patching semantics exactly (1,350 `B.db` refs; patches of `B.MINI_APP_DEV_ALLOW_HTTP`, `B._website_gateway_singleton`, `B._mini_app_bot`, `B._net_workers`, `B._website_network_bot_tokens` all keep working — behaviorally proven by G1–G3 in the new suite and by the full 2,175/0 regression).

## 3. Remaining compatibility responsibilities in bot.py (documented boundaries, §21)

1. **The legacy Telegram handler layer (~20K lines)**: text/media wizards, admin panels, `on_callback` router, delivery orchestration, referral dashboards, `_wad_*` web request handlers. NOT moved because (a) wholesale relocation of ~600 interdependent functions is the highest-risk change possible with zero dependency-direction benefit (handlers already depend only on app/* services — the direction is correct); (b) the regression suites monkeypatch these as bot.py attributes, so the facade must exist regardless; (c) task rule 15 (do not rewrite working Phase 1–5 modules unnecessarily) and rule 20 (stop if an extraction risks behavior change). The boundary is exact: bot.py imports app/* only; NOTHING in app/* imports bot.py (clean-interpreter proof: suite check A1).
2. **The injected-module boundary**: `run.py` imports `bot` (the legacy handler module) inside its `__main__` guard and INJECTS it into `app.bootstrap.application.run_production(mod)`; `app/main.py` imports `bot` only inside `main()` (the pre-existing documented entry-adapter boundary). No app/* module imports bot.py at module level, statically or dynamically.
3. **Logging setup** (basicConfig, bot.log): process-level, stays in the entry layer (documented deployment behavior).
4. **Singleton state on the legacy namespace**: `_website_gateway_singleton`, `_net_*` singletons, `_mini_app_runner/_site/_bot`, `net_health_task` — state lives on bot.py (test patchability), owned/written by the extracted modules.

## 4. Import-direction audit (§12)

- Source scan (suite A2): zero app/* module-level `import bot` / `from bot …`.
- Clean-interpreter behavioral proof (suite A1): importing ALL seven composition modules (`app.bootstrap.application`, `app.bootstrap.config`, `app.services.container`, `app.web.server`, `app.network.lifecycle`, `app.storage.schema`, `app.bot.registration`) leaves `bot` OUT of `sys.modules`.
- `run.py` → app/bootstrap ✓ (suite B1/B2: `run.run_production is app.bootstrap.application.run_production`).
- `app/main.py`: bot import only inside `main()` (suite A3).
- Classify-all-occurrences scan of the repository for `import bot`/`from bot`/`bot.`: test files (test-orchestrated imports, sanctioned), run.py (`__main__`-guarded injection — documented), app/main.py (late import inside main() — documented). No other production dependency.

## 5. Service / container audit (§4)

- `app/services/container.py` is the single composition boundary: it owns the nine service-factory bodies previously embedded ad hoc in bot.py (`legacy_service_factories`), the website/media composition (§8), and retains the prior clean-mode `ServiceContainer`/`create_container`/`bind_legacy` API (no second container system — the existing one was extended, per rule 14).
- bot.py's `_svc_make_*` names are one-line delegators over the container closures (suite C4/M6).
- Dependency direction: handlers → application services (container closures) → repositories/infrastructure. No repository imports bot.py; no core service imports a Telegram handler module (test_architecture A/B sections, unchanged).

## 6. Access Engine audit (rule 10)

- The Access Engine remains the single authoritative access layer: `app/core/access/engine.py` (unchanged). The website deps namespace receives `ns.access_engine` — the SAME function object the Telegram flows use (suite F1: `deps.access_engine is B.access_engine`). No second/website access engine exists anywhere (suite F2). The admin-exempt first check, Force Join/Watch Ads/Referral/Points gating semantics: untouched (2,175/0 regression).

## 7. Website audit (rules 4/5/11)

- `app/web/site/*` presentation layer: byte-identical to Phase 5 (not in the differential).
- Website ON/OFF semantics: unchanged — verified behaviorally in §16 (OFF1–OFF7: maintenance 503, media fail-closed with a VALID token, issuance fail-closed, healthz 200, ON restore) and §17 browser QA (maintenance page visual, restore).
- The website deps factory + admin deps now construct through the container (suite E1–E4), late-bound through the legacy namespace.

## 8. Media Gateway audit (§8)

- `_website_media_gateway()` is no longer a hidden bot.py-specific implementation dependency: the construction lives in `app/services/container.py::website_media_gateway(ns)` — MediaTransportConfig.from_env → create_media_stack (bound to the production recovery transports `ns.fetch_channel_media` / `ns._recovery_admin_chat_id` / best-effort delete) → shared StreamCache → make_listing_resolver → make_media_gateway with the INJECTED Access Engine.
- The bot.py name is a facade; the singleton state stays on the legacy namespace (suite D2/D3, G1/G2).
- The REAL production path executed end-to-end (§16): production server start (`start_mini_app_server` → `app/web/server.py` → `register_site_routes(app, ns._website_deps_factory)`) → stream token → Access Engine → Media Gateway → resolver → transport (loopback local Bot API) → cache → byte-identical GET / HEAD / exact+open-ended+suffix 206 / 416 / cache fill+hit / disconnect slot release. **54/0 PASS.**

## 9. Worker lifecycle audit (§9)

- Explicit ownership: `app/network/lifecycle.py` owns network worker startup/shutdown (init_network_services → network_startup → net_health_loop / network_shutdown).
- Verified (suite J1–J5): disabled platform starts nothing; init creates singletons exactly once on the namespace; shutdown cancels the health task exactly once and stops broadcast engines BEFORE workers; a second shutdown is safe; production calls post_shutdown once. Background loop tasks (auto-reindex/broadcast-scheduler/cleanup/startup-reindex) remain owned by post_init/post_shutdown orchestration in the legacy layer (unchanged Phase 5 semantics, regression-verified).

## 10. Migrations audit (§10)

- `app/storage/schema.py` owns SCHEMA_VERSION + SCHEMA_SQL + the full migration chain (v2→v32), extracted byte-verbatim (verified programmatically). It imports only app.core constants + app.storage primitives — no telegram, no bot.
- Clean-interpreter proof (suite K1): the full chain (fresh DB → v32) runs with `bot` absent from `sys.modules`.
- Schema version UNCHANGED at 32 (suite K3; staging + ZIP-extraction regressions re-verify all migration suites).

## 11. Test results

| Suite | Baseline (Phase 5) | Final (ZIP extraction) |
|---|---|---|
| test_architecture | 96/0 | 96/0 |
| **test_architecture_decoupling (NEW)** | — | **51/0** |
| test_botv13_phase6/7/7hotfix/8 | 124/151/94/77 | 124/151/94/77 |
| test_media_phase1/2/3/3ux/4/5 | 88/77/197/70/200/92 | 88/77/197/70/200/92 |
| test_network | 79/0 | 79/0 |
| test_watch_ads v1–v7 | 91/142/104/153/142/113/85 | identical |
| run_phase8_evidence | ALL SECTIONS PASS | ALL SECTIONS PASS |
| run_network_evidence | ALL SECTIONS PASS | ALL SECTIONS PASS |
| **TOTAL** | **2,175/0** | **2,226/0** (2,175 + 51 new) |

§16 production-path execution: **54/0** (bootstrap reachability, Telegram Application construction with 44 handlers in production order, REAL production server start, gateway via container, full stream/Range/cache/disconnect/OFF chain).

Test-file changes (11 files): source-string pins that located the migration chain / SCHEMA_SQL / Database internals / server routes / network worker glue in bot.py were redirected to their new authoritative homes (app/storage/schema.py, app/web/server.py, app/network/lifecycle.py, app/services/container.py) — sanctioned by §13 ("progressively make tests exercise app/* directly"); every assertion's semantics preserved (same structural guarantees against the real code, now at its new location). No regression coverage was removed.

## 12. Browser QA (§17) — live, real production bootstrap

Driver: production server started via the REAL path (`B.start_mini_app_server(None)` → app/web/server.py → container deps), loopback Local Bot API (documented QA transport), QA proxy injecting only the client-side Telegram WebApp stub (`?qa_stub=1` — what the real Mini App environment provides). 11 screenshots (qa/screenshots/), **zero console errors**:

1. Feed: 4/4 thumbnails loaded, 0 errors (desktop + 390×844 mobile).
2. Collection detail: 3 parts with metadata.
3. Part 1 video page: readyState=4, duration 8.0s.
4. REAL PLAYBACK: muted play advanced 5.0s→8.0s (end) in real time through the production gateway; seek verified.
5. Next → Part 2 (direct ref + stub): readyState=4, PLAYING t=2.00s, paused=false.
6. Previous → Part 1: readyState=4.
7. Search "Episode": 1 result.
8. Single-payload video page: readyState=4.
9. Mobile feed: responsive layout, 12 cards at 390×844.
10. Website OFF: maintenance page; video page fail-closed WITH a valid AEAD ref; healthz 200.
11. Restore ON: feed back with the seeded episode.

(One behavioral observation, not a defect: clicking Next/Previous inside the browser carries no `?qa_stub=1`, so the page shows the HONEST "unlocked inside the Telegram Mini App" state — identical to Phase 5 behavior outside a real Mini App; the QA flow opens part URLs with the stub to emulate the Mini App environment.)

## 13. Full differential vs Phase 5 (§18)

- **Files added (7)**: `app/storage/schema.py`, `app/bootstrap/config.py`, `app/web/server.py`, `app/network/lifecycle.py`, `app/bot/registration.py`, `test_architecture_decoupling.py`, `docs/ARCHITECTURE_DECOUPLING_REPORT.md` (this report).
- **Files changed (16)**: `bot.py` (28,286 → 25,053 lines), `run.py`, `app/main.py`, `app/bootstrap/application.py`, `app/services/container.py`, + 11 test files (pin redirects only).
- **Files deleted: 0** (no unexpected deletions).
- **Schema changes: none** (SCHEMA_VERSION=32; all migration suites green; schema byte-verbatim extraction).
- **Requirements changes: none** (requirements.txt identical).
- **Import graph changes**: run.py → app.bootstrap (was → app.main → bot); app/main.py delegates to bootstrap; bot.py gains imports of the composition modules; NO new reverse dependencies.
- Product behavior differences: none (2,175/0 + evidence + §16/§17 behavioral verification).

## 14. Limitations (honest)

1. The ~20K-line Telegram handler mass remains in bot.py (documented legacy boundary — see §3; moving it was assessed and deliberately not forced per rules 15/20/§21).
2. Live Local Bot API / real Telegram / multi-GB validation remains environment-bound (same as Phase 4/5/deployment validation) — the loopback transport is clearly labeled QA-only.
3. `app/main.py` retains a late `import bot` inside `main()` (pre-existing documented entry-adapter boundary; run.py no longer needs it).
4. The 208 removed duplicate stub lines were verified byte-identical before deletion; the final binding of each name is unchanged.

## 15. Release recommendation

**GREEN — RELEASE-READY.** `payload-bot_architecture_final.zip`: clean (no pycache/db/log/screenshots/secrets — verified by entry scan), unzips cleanly, the ZIP extraction itself passed the complete regression (2,226/0 + both evidence runners). Schema unchanged at v32. No new features; behavior preserved per the full battery, the §16 real production-path execution, and live browser QA. Deployment notes from the Phase 5 deployment validation report remain applicable (trusted XFF-overwriting proxy, HTTPS termination, writable CWD + cache, Local Bot API for >20 MiB, log rotation, fd limits).
