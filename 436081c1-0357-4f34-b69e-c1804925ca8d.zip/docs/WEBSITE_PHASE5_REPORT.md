# WEBSITE PHASE 5 — FINAL PRODUCTION HARDENING / RELEASE GATE REPORT

Status: **GREEN — RELEASE RECOMMENDED (with documented limitations)**
Artifact: `payload-bot_website_phase5.zip`
Baseline: `payload-bot_website_phase4.zip` (the sole implementation baseline)

---

## 1. Baseline (§0)

- Authoritative Phase 4 ZIP located and extracted into a completely clean
  directory (`p5-work/payload-bot`) before ANY modification.
- Integrity: `unzip -t` clean (169 entries); **143 files**; junk scan **0**
  (no `__pycache__`, `*.pyc`, DB files, `.env`, logs, cache dirs);
  `.env.example` contains placeholders only (`BOT_TOKEN` placeholder;
  `ADMIN_IDS` is a plain example user ID present since Phase 1 — not a
  credential; `TELEGRAM_API_HASH` commented placeholder).
- Recorded: **bot.py md5 `5659ee2f884d3e18946e5b180b3f7573`**,
  ZIP size **1,001,371 bytes**, **SCHEMA_VERSION = 32**.
- Environment preparation ONLY (sandbox venv had been reset):
  python-telegram-bot 22.8, aiosqlite 0.22.1, aiohttp 3.13.3, cryptography,
  python-dotenv. Zero source changes for this step.
- Baseline battery re-run from the fresh extraction, all green:
  phase4 200/0 · phase3ux 70/0 · phase3 197/0 · phase2 77/0 · phase1 88/0 ·
  architecture 96/0 · watch_ads v1–v7 91+142+104+153+142+113+85 ·
  botv13 phase6/7/7hotfix/8 124+151+94+77 · network 79
  = **18 suites, 2,083/0** + run_phase8_evidence ALL PASS +
  run_network_evidence ALL PASS.

---

## 2. Phase 5 changes (what and why)

Four parallel deep audits (web layer; bot.py + app/bot; app/media;
core/storage/services/auth) plus personal line-by-line reads produced
**1 CRITICAL + 4 HIGH + 8 MEDIUM/LOW actionable findings**, all fixed.
No cosmetic refactors. bot.py stays a frozen wiring boundary — the single
bot.py content change is a two-line security log redaction.

| # | Severity | Location | Fix |
|---|----------|----------|-----|
| F1 | **CRITICAL** | `app/media/stack.py` | `create_media_stack(db, *, bot_token, …)` keyword-only signature vs bot.py's positional call `create_media_stack(db, BOT_TOKEN, …)` → `TypeError` at gateway construction → **the production Media Gateway NEVER built; all Website streaming was dead-on-arrival**. Phase 4's PIN5 check only string-matched the import; the QA driver built its own gateway with keyword args (masked it). Fix: `bot_token` is now positional-or-keyword — every existing keyword call site unchanged, bot.py untouched. Pinned forever by GATE1–GATE9 which invoke bot.py's real `_website_media_gateway()`. |
| F2 | **HIGH (DoS)** | `app/media/gateway.py`, `app/web/site/stream.py` | Concurrency-slot leak: the slot was acquired at plan time but released only in the body generator's `finally` — a body that is NEVER iterated (client vanished before `prepare()`/first chunk) leaked the slot permanently; ~32 request-then-instantly-disconnect cycles would lock `/site/media` behind 429 until restart. Fix: idempotent per-plan `release()` (flag-guarded) carried on `StreamPlan`, invoked by BOTH the generator's `finally` and the HTTP layer's `finally` (which now covers `resp.prepare()`). |
| F3 | **HIGH (data integrity + disk)** | `app/media/streamcache.py` | Fill-restart corruption: a re-fill after an aborted fill read upstream from byte 0 but APPENDED (`"ab"`) after the stale prefix → disk layout `[stale prefix][full new copy]`, `available` overwritten to the new copy's count → unbounded disk growth per retry and **wrong bytes served after a process restart** (probe trusted `getsize`). Fix: `_align_disk_prefix` enforces `file size == available` before appends (truncate over-long / shrink short / **reset to empty when over the known upstream size**); fills now RESUME from the committed prefix (straddling chunks split); the restart probe resets over-meta-size entries to empty (`MEDIA_CACHE_CORRUPT_RESET`). |
| F4 | **HIGH (policy)** | `app/media/streamcache.py` | The advertised cache policy was **dead code in production**: `cleanup()` had no production caller, so the 2 GiB size cap and TTL were never enforced (unbounded cache growth). Fix: the policy sweep runs after every successful fill (best-effort — never fails the fill), preserving active-reader protection for the just-filled entry. |
| F5 | **HIGH (security)** | `app/media/repair.py`, `bot.py` (2 lines) | `file_id` values logged verbatim in repair events (`old_file_id=%s new_file_id=%s`) — a file_id + bot token is a download capability and logs are typically less protected than the DB. Fix: `redact_file_id()` emits a SHA-256 correlation fingerprint + length (`#<8hex>(len=N)`) — same reference correlates across lines, nothing usable leaks. Applied to the module event AND bot.py's `BOT6_DELIVERY_FILE_ID_REPAIRED` (the only bot.py content change: two log lines + a lazy import). |
| F6 | MEDIUM (large-file) | `app/media/httpclient.py` | aiohttp's `ClientTimeout(total=30)` covers the WHOLE streamed transfer (verified empirically against aiohttp 3.13.3) → every transfer longer than 30 s aborted mid-stream (Local Bot API multi-GB files, slow cloud fetches). Fix: dual profiles — metadata calls (`get_json`/getFile) keep bounded TOTAL; body streams use `sock_connect` + `sock_read` with `total=None`: stalled connections still fail promptly, healthy slow transfers survive, reader cancellation propagates. |
| F7 | MEDIUM (availability) | `app/media/streamcache.py` | `cleanup()`/`purge()` held the state lock across `rmtree` awaits → an admin purge of a large cache stalled ALL new streams site-wide for the sweep duration. Fix: victims are selected/popped/doomed under the lock (synchronous); directory removal happens outside it; `_delete_entry` pops under the lock and removes idempotently. |
| F8 | MEDIUM (hygiene) | `app/media/streamcache.py` | The `disk_failed` path popped the entry without deleting its dir → untracked orphan dirs. Fix: the entry is doomed; the last reader's exit removes the dir (no orphans). |
| F9 | MEDIUM (observability) | `app/web/site/pages.py`, `app/web/site/stream.py` | DB failures in request paths were logged at DEBUG → at the default INFO level a DB outage was indistinguishable from an empty catalog / honest 404. Fix: `WEBSITE_FEED_ERROR` / `WEBSITE_SEARCH_ERROR` / `WEBSITE_DETAIL_ERROR` / `WEBSITE_RESOLVE_ERROR` at WARNING with exc_info. |
| F10 | MEDIUM (DoS/资源) | `app/web/site/pages.py`, `app/web/site/html.py` | Collection detail/player pages rendered the FULL file list: one AEAD token minted per file + unbounded HTML per anonymous request (a 10k-part collection = 10k Fernet ops + MBs of HTML). Fix: `MAX_DETAIL_FILES = 200` presentation cap (rows + pills + mints) with an honest "+N more parts — open the payload in Telegram" note; the count pill keeps the TRUE total; membership/stream authorization resolve the FULL canonical list (cap is presentation-only — verified by streaming part 203 of a 205-part collection). |
| F11 | LOW (liveness) | `app/media/streamcache.py` | Filler cancellation did not bump `fill_failed_gen` → followers stalled up to the 60 s follow-idle timeout before their direct fallback. Fix: the generation is bumped on cancellation; followers fall back immediately (verified < 1 s). |
| F12 | LOW (fd leak) | `app/media/gateway.py` | The thumbnail accumulation loop exited early (too-large) without `aclose()` on the source generator → the underlying HTTP response lingered until GC. Fix: explicit `aclose()` in a `finally`. |
| F13 | LOW (TTL honesty) | `app/media/streamcache.py` | Restart-adoption reset `created_at`/`last_access` to now → the idle-TTL clock restarted every process restart. Fix: the probe restores `created_at` from meta and seeds `last_access` from it (conservative — entries idle since before a restart age out honestly). |
| F14 | LOW (SQL hardening) | `app/storage/repositories/payloads.py` | `update_payload_field` interpolated the field name into SQL with no internal whitelist (all current callers pass literal constants; defense-in-depth gap for future callers). Fix: exhaustive whitelist (derived from every call site, including the test-driven `access_policy`); unknown fields raise `ValueError`. |
| F15 | LOW (SQL) | `payloads.py`, `media.py` | Two legacy admin searches built LIKE patterns from raw input without escaping → a literal `%`/`_` widened into full-table matches. Fix: LIKE-escaped input + `ESCAPE '\'` clauses. |
| F16 | LOW (growth) | `app/network/broadcast.py` | Completed broadcast workers stayed in the `_tasks` registry forever. Fix: identity-guarded done-callback pops completed tasks. |

**bot.py boundary (§2):** the only bot.py content change in Phase 5 is the
F5 log redaction (2 log lines + 1 lazy import) — a security hardening, not
wiring, and documented as such. No business logic entered bot.py; no
architecture moved.

---

## 3. Security audit (§4)

- **Stream tokens** (re-verified + hardened): AEAD (Fernet primary /
  encrypt-then-MAC fallback via CredentialVault), integrity-protected,
  expiry (TTL clamped 30–3600 s), purpose/user/listing/file binding,
  malformed/modified/wrong-key/wrong-purpose fail closed; not interchangeable
  with Phase 3 video refs. NEW in Phase 5: no token value, bot token, or
  file_id value appears in ANY log record during a full stream + range flow
  (SEC1–SEC5); `redact_file_id` removes the last capability leak.
- **WebApp auth**: initData HMAC over the official WebAppData construction;
  main token first, then ACTIVE network bots only; `auth_date` required with
  future-skew rejection; malformed input rejected. Unchanged and re-verified
  by the live browser QA (invalid/stub-free contexts → honest deny).
- **Public URLs**: permanent URLs carry opaque ids only
  (`secrets.token_hex` slugs; no DB ids, Telegram ids, file_ids, paths, or
  embedded secrets). Short-lived URLs carry AEAD tokens (≤ 1 h). No change.
- **HTML**: every dynamic sink escapes via `html.escape(quote=True)`,
  `quote_plus`, or JSON-encoding for JS contexts (audit re-verified all
  sinks; XSS matrix A–S re-run green in the Phase 4 suite).
- **Database**: parameterized SQL everywhere; the two remaining
  interpolation sites are now whitelist-guarded (F14) / constant-fragment
  order mappings (unchanged); LIKE escaping completed (F15).
- **Filesystem**: cache entry dirs derive from `sha256(file_unique_id)` with
  literal filenames only; local-mode disk access uses resolved-path
  containment (`realpath` + `commonpath`), rejecting symlinks that escape
  the mount. NEW: corruption reset (F3) and orphan cleanup (F8) keep the
  cache root bounded and self-consistent.
- **Secrets in the artifact**: junk scan 0; `.env.example` placeholders
  only; no credentials packaged.

---

## 4. Access Engine audit (§3)

Repository-wide search of every unlock/delivery eligibility decision:
all paths ultimately call the ONE `access_engine` (bot.py) — 9 Telegram
delivery call sites, Website access API, stream issuance, the Media
Gateway's per-request re-verification (revoked users cannot ride unexpired
tokens), points unlock (re-run before spending), referral wrapper, watch-ad
reward auto-resume, network WebApp auth. The single known duplicate —
bot.py's deny-only `_watch_ads_delivery_gate` last-line defense (Phase 7,
tested) — is deliberate fail-closed defense, documented as a drift risk
with NO bypass potential. **No bypass found.** Website OFF remains
presentation-only and never alters Telegram access decisions (re-verified:
`enforce_access` span contains no website flag; engine identical with the
website off).

---

## 5. Website ON/OFF regression (§7/§8)

Executed live in the browser QA (below) and in the suites:
- ON: feed → detail → parts → video page → stream token → engine →
  gateway → playback → seek → next/prev → thumbnails — all real HTTP
  against the actual stack.
- OFF: pages show maintenance; media/thumb/issuance endpoints answer 503;
  `healthz` stays 200; the maintenance copy honestly states Telegram
  delivery/access keep working; engine behavior identical (Phase 4 suite
  OFF section re-run green).

---

## 6. Media/cache hardening (§5)

Stressed beyond the Phase 4 suite (see test_media_phase5.py): fresh fill,
abort + RESUME (exact bytes, exact disk, one upstream per fill),
in-process corruption self-heal (truncate), restart-poisoned entry reset,
size-cap enforcement after fills, TTL enforcement, purge during an active
fill (prompt, exact bytes, doomed-then-removed), disk-write failure
(un-persisted honest passthrough + no orphan dir), filler cancellation
(immediate follower fallback), created_at/idle-TTL across restart, timeout
profiles (slow stream survives > timeout; stalled stream fails bounded),
slot release on never-iterated bodies. Memory bounding re-proven by the
Phase 4 LFM checks (ru_maxrss delta < 48 MiB over a 63 MiB stream) and the
unchanged chunk-bounded architecture.

---

## 7. Migration/startup verification (§10)

Fresh DB → v32; **three repeated startup cycles** on one file (idempotent,
no crash, correct final version); v31 → v32 upgrade preserves admin-set
values (INSERT OR IGNORE) — re-run in Phase 4 suite; settings persist
across restarts (MIGR1–MIGR4); two full server start/stop cycles with
healthz + feed alive after each restart and no unbounded task drift
(SHUT1–SHUT4).

---

## 8. Failure-mode testing (§11)

Controlled failures exercised (Phase 4 + Phase 5 suites + live QA):
invalid/expired/malformed/tampered/wrong-user/wrong-media/wrong-purpose
tokens (fail closed), revoked access (403 on unexpired token), unknown
payload/media (404), unpublished listing (404), cloud too-large (honest
503 + Local Bot API guidance), invalid/unsatisfiable ranges (416/ignored),
client disconnect mid-stream (slot + readers released; LFM10/11), client
vanish before body (slot released — SLOT7), upstream failure mid-fill
(bounded abort + one direct-remainder retry), disk-write failure (honest
un-persisted passthrough, canonical records untouched), corrupt cache
entries (reset + refill exact), DB query failure (honest empty feed with
WARNING), website OFF (503 presentation). No infinite retries, no task
leaks, no secret exposure, unrelated functionality preserved.

---

## 9. Concurrency/shutdown testing (§13)

All background loops stored + cancelled + awaited on shutdown (verified by
audit); per-IP concurrent stream semaphore released in `finally`;
concurrency slot exactly-once release (F2); active-reader refcounts fully
covered by try/finally (audit + tests); repeated startup/shutdown cycles
green; purge-under-lock stall eliminated (F7); broadcast task registry
bounded (F16). Known accepted limitation (documented, LOW): bot.py's
fire-and-forget admin reindex/verify/scheduled-broadcast tasks are not
cancelled before `db.close()` during shutdown — worst case is post-close
errors inside unreferenced tasks (DB stays consistent; stale `Processing`
broadcasts are marked Failed at next startup). Kept to honor the
zero-bot.py-changes discipline; recommended follow-up if a future phase
opens bot.py.

---

## 10. Dependency/packaging audit (§14)

`requirements.txt` declares python-telegram-bot, aiosqlite, aiohttp,
python-dotenv (all verified in use; lazy aiohttp imports are intentional).
**Gap found and fixed**: `cryptography` (the credential vault's PRIMARY
AEAD path) was undeclared — now declared with a comment documenting the
stdlib authenticated fallback. Python 3.10+ documented (verified on 3.12).
No test-only dependencies required in production; imports verified from a
clean extraction.

---

## 11. Browser QA (§18) — LIVE, real HTTP, production wiring

Driver: `qa/qa_site5_server.py` (ports 8078/8079; QA-only stub middleware
with a VALID HMAC initData; production pages untouched). **The Phase 5
difference: the Media Gateway is built by bot.py's REAL
`_website_media_gateway()` and the site routes receive the REAL
`_website_deps_factory()`** — the browser exercises the exact production
wiring chain, proving the F1 fix end to end.

Verified (screenshots in `download/phase5-qa/`):
1. Website ON; 2. feed (4 cards, 4/4 thumbnails loaded);
3. payload detail (filerows); 4. parts navigation (Part 1|2|3 pills +
   Previous/Next WITHIN the payload; Part 1↔2 both navigated);
5. video page; 6. **REAL PLAYBACK through the production gateway**
   (readyState=4, muted play → t=2.96 s PLAYING, dur=8 s);
7. **seek** to 5 s → playing at 7.43 s; 8. next/previous part;
9. thumbnails; 10. Website OFF → maintenance page with the honest
   Telegram-preserving copy; 11. media endpoint 503 + healthz 200 while
   OFF; 12. feed restored after ON; 13. audio payload renders `<audio>`
   with NO video element (MIME honesty); 14. honest "Open in Telegram"
   deny state outside the Mini App; 15. cache-backed delivery: 8 cache
   hits / 3 fills across the session, concurrency 0 and active readers 0
   at rest.
API-level through the same server: byte-identical full GET (md5 match),
exact 206 range with Content-Range, correct HEAD, range served from cache
with zero additional local-API opens.

Environmental note: muted `<audio>` autoplay did not advance in headless
Chromium (element mounted, readyState=4, full metadata — the transport,
MIME and authorization were fully proven; video playback is the
authoritative playback proof).

---

## 12. Differential report (§17) — Phase 5 vs Phase 4

- **Added (2):** `test_media_phase5.py` (92 checks),
  `docs/WEBSITE_PHASE5_REPORT.md` (this file).
- **Changed (12):**
  - Source (11): `app/media/stack.py`, `app/media/gateway.py`,
    `app/media/streamcache.py`, `app/media/repair.py`,
    `app/media/httpclient.py`, `app/web/site/stream.py`,
    `app/web/site/pages.py`, `app/web/site/html.py`,
    `app/storage/repositories/payloads.py`,
    `app/storage/repositories/media.py`, `app/network/broadcast.py`,
    `requirements.txt` (12th — packaging).
  - bot.py: **+5/−3 lines, one region** — the F5 log redaction only
    (format strings + lazy import). No Telegram-flow changes; md5 differs
    from Phase 4 solely because of this documented security redaction.
- **Deleted: 0.** Schema: unchanged (v32; no migration added).
- No architectural rewrite: ONE media stack, ONE Access Engine, ONE payload
  system, ONE search system — all preserved (architecture suite 96/0).

---

## 13. Test totals

| Suite | Result |
|---|---|
| **test_media_phase5 (NEW)** | **92 / 0** |
| test_media_phase4 | 200 / 0 |
| test_media_phase3_ux | 70 / 0 |
| test_media_phase3 | 197 / 0 |
| test_media_phase2 | 77 / 0 |
| test_media_phase1 | 88 / 0 |
| test_architecture | 96 / 0 |
| watch_ads v1–v7 | 91 / 142 / 104 / 153 / 142 / 113 / 85 — all 0 failed |
| botv13 phase6/7/7hotfix/8 | 124 / 151 / 94 / 77 — all 0 failed |
| test_network | 79 / 0 |
| run_phase8_evidence | ALL SECTIONS PASS |
| run_network_evidence | ALL SECTIONS PASS |

**19 suites, 2,175 checks, 0 failures** — executed from the working tree,
the clean staging tree, AND the fresh ZIP extraction (§16).

---

## 14. Final ZIP details (§15/§16/§21)

- Clean staging built by explicit copy (excludes `__pycache__`, `*.pyc`,
  `.pytest_cache`, DBs, `.env`, logs, media_cache, screenshots); junk scan
  0; `compileall` clean; clean-interpreter import (bot + every touched
  module) OK; critical battery green from staging.
- `payload-bot_website_phase5.zip` created from the staging tree;
  `unzip -t` clean; extracted into a second completely clean directory and
  the battery re-run from the extraction (§16 numbers above).
- bot.py md5 in the final ZIP: recorded in the gate report.

---

## 15. Honest limitations

1. **No live Local Bot API server and no live multi-GB Telegram transfer
   exist in this sandbox** — as in Phase 4. Verified instead: the real
   production gateway construction (F1), a REAL loopback HTTP "Local Bot
   API" with true Range semantics serving a real 8 s MP4, real browser
   playback/seek through the production wiring, and bounded-memory
   streaming over a 64 MiB fixture (Phase 4 LFM checks re-run). Live
   multi-GB claims are NOT made.
2. Muted audio autoplay did not advance in headless Chromium (transport
   proven; video is the playback proof).
3. Fire-and-forget admin reindex/verify/broadcast tasks are not tracked
   for cancellation before `db.close()` (LOW; documented in §9).
4. Per-IP rate limiting trusts `X-Forwarded-For` when present — the
   deployment MUST sit behind a trusted reverse proxy (documented in the
   startup log since Phase 3); direct exposure allows spoofed keys.
5. Force-Join-gated Website listings are denied for everyone except admins
   (the web layer passes `bot=None`; membership checks fail CLOSED by
   design — the payload remains fully deliverable through Telegram).
6. The deny-only `_watch_ads_delivery_gate` duplicate in bot.py (Phase 7
   last-line defense) remains by design; documented drift risk.
7. Bot.py contains four `print()` startup-banner lines (also logged
   properly) — kept to preserve the frozen boundary.
8. Dead-but-import-tested scaffolding (`app/services/container.py`,
   `app/web/application.py`, `app/web/routes.py`) retained deliberately —
   removal would break the architecture suite and is cosmetic, not a
   release risk.

---

## 16. Release recommendation

**RELEASE.** The system is internally consistent, production-safe,
regression-safe (2,175/0 across 19 suites + 2 evidence runners, executed
from three independent trees), operationally observable (distinguishing,
WARNING-visible failure modes; zero secret leakage), migration-safe
(idempotent v32, settings preserved), and verified end-to-end in a real
browser through the exact production wiring. The remaining limitations are
documented honestly above and carry no silent risk. The pre-Phase-5
production-critical defects found and fixed in this phase (dead gateway
wiring, slot-leak DoS, cache corruption, dead cache policy, log capability
leak) are precisely the class this release gate exists to catch.
