# PROMPT A FIXES REPORT — the bot-25.log production pass

**Baseline:** `payload-bot_PRODUCTION_B18_B23_FINAL.zip`
(SHA-256 `85877d06705090902396a21ef082a60c497a97e6118368a4a696e08488708a50`,
verified before extraction). All fixes applied IN PLACE — no B19, no
architecture change, nothing renamed. Schema stays at v40 (this pass
adds NO migrations).

**Evidence base:** `/home/z/my-project/upload/bot-25.log` (959 lines,
2026-09-19 08:41–10:33). Jobs 48/49 both terminally FAILED after 5
attempts each: 12 relay messages created (ids 245–258), every single
forward/copy answered `Message to forward not found` /
`RELAY_INACCESSIBLE_TO_NETWORK_BOT` while
`NETWORK_DELIVERY_GROUP_ACCESS_CHECK` proved `identity_match=True`,
`group_type=supergroup`, `bot_membership=administrator`,
`read_capability=yes(admin)` — the Telegram bot-to-bot supergroup
invisibility. The group then went `chat_not_found` (8 failed verifies);
the only successful delivery was job 50 `mode=fdb_direct`.

---

## A.8 verification table

| Item | Tag | Evidence |
|---|---|---|
| A.1 Telegram fullscreen | VERIFIED (logic, browser) / ENVIRONMENT-BLOCKED (real Android WebView) | `toggleFullscreen` routes `tgWebApp()` contexts without the Bot-API-8.0 API DIRECTLY to fake fullscreen (order pinned `telegram-api → tgWebApp-fake → container`, tests/test_a_prompt_fixes.py 1a); enterFake/exitFake lock BOTH `<html>` and `<body>` (1b/1c) with the new `html.fsfake-scroll-lock,body.fsfake-scroll-lock` CSS block (1d); the real element-fullscreen chain untouched (1e). Browser AF4–AF4d (headless Chromium, pre-8.0 Telegram stub): `#pfs` enters `.fsfake` with `document.fullscreenElement === null`, both locks applied, player pinned `position:fixed`, Esc releases everything — 13/13 browser checks. A physical Telegram-Android 12.10.3 WebView needs a real device — not available in this sandbox. |
| A.2 Delivery Channel migration | SIMULATED (unit/integration) / ENVIRONMENT-BLOCKED (real Telegram) | Terminology + the canonical 4-step setup pinned (suite checks 2a–2l: `DELIVERY CHANNEL SETUP`, `Use Existing Channel`/`Create New Channel`, "Post /setup yourself (a human must post it…)", `+5 points … completes Delivery Channel setup`, `✅ DELIVERY CHANNEL READY`; DB identifiers `delivery_group_chat_id`/`network_delivery_groups` NOT renamed — 2i). Detection handler: channel posts with `from=None` accepted (3a–3e), wrong-user group posts still ignored (3f), private chats still ignored (3g). Worker filter `CHANNEL \| GROUPS` + the named `network_delivery_channel_guard` shim (5a–5f). `verify_delivery_group` accepts `ChatType.CHANNEL` → `DELIVERY_READY` (4a/4b), still rejects private chats `not_a_group` (4c). A REAL private channel with the real FDB + a real Network Bot requires production credentials — not available in this sandbox. |
| A.3 Open-in-browser removal | VERIFIED | Source: no `openextbtn` button (6c), `_OPEN_EXT_JS` gone (6d), no ext route registration (6a), handlers kept as dead functions (6b), `_INTRO_JS` landscape lock after theme boot (6e/6f). Browser AF5–AF5c: no `#openextbtn` in the DOM, no `__EXT_LINK_API__`, synchronous POST `/site/api/ext-link` → 404; `/site/ext/<t>` → 404. b22 suite section D rewritten to the retirement contract (D1–D6) + F1–F3 pins. |
| A.4 Multi-file expansion | VERIFIED (browser + real-DB integration) | `find_collection_id_for_index_id` added (payloads.py). Real-DB integration (suite [7]): a payload whose canonical file is member #3 of a 5-file collection expands to 5 parts in canonical position order (7e/7f), every part preserves the full file contract incl. channel/message (7g), `file_id` never exposed (7h); a standalone payload stays EXACTLY one file (7j/7k); a payload in a single-item collection stays one file (phase3 M3). Browser AF1–AF3 (real server + Chromium): the payload listing renders 5 part rows with per-part hrefs, the player carries the 5-part pill bar, pill 5 → part 5, Previous-part walks back inside the same listing. phase4's media matrix re-based onto dedicated collection members (the per-kind payloads keep the exact single-file contract). |
| A.5 Reactivation window | VERIFIED (mechanism) / SIMULATED (journey) | `nreg:reactivate` + `nreg:changeconfirm` added to `CONVERSATION_INPUT_ENTRY_EXEMPT` (8a/8b); `nreg:changecancel`/`nreg:back` deliberately NOT exempt (8c). The pinned bug: the master purge destroys the held-token state (8d) — which is exactly why the entry must be exempt. Window source audited: the 10-minute window is measured from the token-receipt stamp (`stamp_conversation_state` ts — the equivalent of a token row's `created_at`); fresh states pass (8e), expired states still fail closed (8f), the handler reads the preserved state (8g). A real Telegram paste→confirm→worker-start journey needs production credentials — the mechanism is fully unit-pinned. |
| A.6.1 Age-gate identity binding | VERIFIED (already present) | `pages.py` `handle_site_api_get_file` / `handle_site_api_pack` already require `session is not None AND session.user_id == uid AND session.age_ok` (the B23 P0-3 fix, mirrored from `stream.py::_session_age_confirmed`); pinned by `tests/test_b23_website_watchad.py` D1/D2 — battery green, not re-fixed. |
| A.6.2 HLS age recheck | VERIFIED (already present) | `hls.py::handle_site_hls` rechecks the shared identity-bound age predicate on EVERY request (master playlists, variants and each `.ts` segment flow through the one handler; failure fails CLOSED 404); pinned by `test_b23_website_watchad.py` §3.2 — battery green, not re-fixed. |
| A.6.3 Session codec `\|` | VERIFIED (already present) | `session.py` uses the s2 percent-escaped envelope INSIDE the AEAD ciphertext (`%25`/`%7C` exact-inverse single pass) since B23-3 §5.19; `first_name="A\|B"` round-trips (pinned `test_b23_repo_audits.py` L1–L6) — battery green, not re-fixed. |
| A.6.4 Lock naming | VERIFIED (already present) | `DatabaseBase.write_lock` is the single public property; every repository mixin acquires `self.write_lock`; ZERO `self._write_lock` uses in repositories; the `media_stats.set_media_reaction` defensive getattr is GONE (B23-3 §5.1, pinned `test_b23_repo_audits.py` A) — battery green, not re-fixed. |
| A.6.5 Getfile guard eviction | VERIFIED | `_getfile_guard_set` evicts EXPIRED entries first (timestamped garbage) then the oldest half — live entries survive (9a–9c); `_getfile_lock` evicts oldest-by-insertion until under cap — every other live entry survives (9d/9e); no `.clear()` remains (9f). |
| A.6.6 Pack channel_id | VERIFIED | `get_payload_file_overview` projects `i.channel_id, i.message_id` (10f); `get_listing_detail` carries per-file durable source refs for BOTH canonical kinds; `_pack_row` prefers the file's own channel, then the canonical channel, then 0. Real-DB integration (10a–10e): every multi-file payload pack row carries the REAL channel + message ids; the standalone payload row carries the canonical file's channel (never 0); the fallback order is file → canonical → 0. |

## Verification runs (this pass, on THIS tree)

* `python -m compileall app` — ZERO errors.
* Full battery: **48/48 suites ALL GREEN** (incl. the new
  `tests/test_a_prompt_fixes.py` — 70/70 checks for this pass; updated
  pins: b22 D/F1–F3/F7, b23-hybrid 6b, phase3 M1 (A.4 contract),
  phase4 fixture de-overlap).
* Browser QA `battery/browser_qa_afix.py`: **13/13** (AF1–AF6 above).
* The B23 browser chains re-run on THIS tree: **b23 27/27** (multi-file
  rendering, parts nav, photo <img>, SPA history, Telegram BackButton,
  Bot-API-8.0 fullscreen, 320px responsive), **b22 32/32** (engagement
  independence, watch-ad waiver, the RETIRED openext T7/T8 checks,
  responsive 320–1280), **final1 11/11** (the real element-fullscreen
  chain + pseudo-fullscreen fallback).
* Startup smoke + clean-extraction verification against the produced
  ZIP: **PASS** — `compileall` clean; fresh-DB auto-migration to
  `DATABASE_SCHEMA_VERSION=40`; `WATCH_AD Mini App HTTP server started`;
  `GET /healthz` 200; `GET /sw.js` exact provider bytes. (The
  FORCE_JOIN_STARTUP_HEALTH + NETWORK_WORKERS_STARTED lines are emitted
  by the full runtime bring-up in production; the fresh-smoke harness
  covers the package-boot surface.)

## Honest environment limits

* **Real Telegram channel setup (A.2.5)** and the **real Android
  Telegram WebView (A.1)** require production credentials/devices this
  sandbox does not have — ENVIRONMENT-BLOCKED, never claimed VERIFIED.
  The exact expected production success lines are the ones this pass
  preserves/extends: `SETUP_COMMAND_RECEIVED` →
  `DELIVERY_GROUP_VERIFIED … mode_a_ready=True hybrid_mode_ready=True`
  → `✅ DELIVERY CHANNEL READY` in the channel → owner DM → +5 award;
  then `NETWORK_DELIVERY_SUCCESS mode=network_relay` for deliveries.
* Delivery through the deprecated supergroup relay remains supported
  for already-verified rows (never broken), but new setups are directed
  to channels.
