# Architecture — Payload Delivery Bot (PHASE 8)

## Before / After

**Before (PHASE 7 HOTFIX, bot6-db5578c370f4):** a single 30,073-line
`bot.py` — battle-tested (1,199 regression checks) but with the indexing,
verification and link-health correctness gaps documented in
`docs/MIGRATION.md` §"Why v28".

**After (PHASE 8):** a **controlled vertical-slice modularization** — the
proven core stays intact as `bot.py` (the compatibility core), and the NEW
correctness-critical services live in a proper package:

```
payload-bot/
├── run.py                     ← PRODUCTION ENTRYPOINT (python run.py)
├── bot.py                     ← compatibility core (all handlers, callbacks,
│                                 delivery, access engine, watch ads, mini
│                                 app server, admin panels, DB layer)
├── app/
│   ├── main.py                ← entrypoint adapter (delegates to bot.main)
│   └── core/
│       ├── indexing_engine.py    ← durable index jobs, resume plans,
│       │                            truthful scan states (SCAN_*)
│       ├── verification.py       ← source↔DB↔payload verification +
│       │                            non-destructive reconciliation
│       └── fj_link_health.py     ← Force-Join invite-link health states,
│                                    TTL cache, exception classification
├── docs/                      ← this documentation set
├── tests/                     ← (test_*.py suites live at the root; see
│                                 TEST_REPORT.md)
├── requirements.txt
└── .env.example
```

`python bot.py` still works identically (legacy entrypoint), and
`python run.py` is the documented production entry. Both require the
`app/` package to be deployed together with `bot.py` — the new services
are hard imports (fail-fast with a clear ImportError rather than silently
running without correctness features).

## Why vertical slices (not a full split)

The unified specification explicitly demands: *"THIS IS A CONTROLLED
REFACTOR, NOT A REWRITE"* and *"Use adapters/services around existing
logic instead of replacing working systems unnecessarily."*

The three new subsystems are exactly the ones the specification declares
**release blockers** ("Correct indexing + verification + link health are
release blockers"), and they are the ones whose correctness is testable in
isolation. The remaining core (handlers, callbacks, wizard, panels, watch
ads, referral, mini app) is proven by 1,199+ regression checks that operate
through the module boundary (`import bot`) — moving it wholesale would have
invalidated every one of those tests for zero behavioral gain.

## The new services

### `app/core/indexing_engine.py` — durable scan jobs
* `index_job:<channel_id>` KV records persisted every 25 messages, at
  every batch flush, and at completion.
* `SCAN_RUNNING / SCAN_COMPLETE / SCAN_STOPPED / SCAN_FAILED / SCAN_PARTIAL`
  — the ONLY terminal vocabulary; the UI can never say "complete" for a
  partial scan.
* `resume_plan()` — backward first scans resume DOWNWARD (their remaining
  work is below the interruption point); forward incremental scans resume
  upward. A stale RUNNING record (dead process) is resumable; a live one
  is not.
* `SCAN_RUNAWAY_GUARD` (2,000,000) replaces the old 500-message truncation.

### `app/core/verification.py` — real verification + reconciliation
Phase A: read-only live-source walk (latest → 1). Phase B: DB snapshot +
**targeted orphan probes** (every DB message_id not seen live is probed
individually — immune to history gaps). Phase C: DB cross-matrix (duplicate
identities, NULL-identity pairs, broken payload refs, payloads on
unavailable files, cross-channel orphans, invalid file_ids/media types,
token-epoch staleness). Phase D (opt-in reconcile): index missing media,
atomic in-place file_id repair, mark unavailable, recover — **nothing is
ever deleted and payload relationships are never modified**. Identity
discipline: a source message hosting a different file is REPORTED, never
auto-merged.

### `app/core/fj_link_health.py` — Force-Join link health
States: `HEALTHY / TEMPORARY_ERROR / LINK_EXPIRED / LINK_REVOKED /
LINK_INVALID / CHANNEL_INVALID / BOT_PERMISSION / UNVERIFIABLE / NO_LINK`.
`verify_invite_link()` uses the Bot API `get_chat_invite_link` (expired_at,
is_revoked, belongs-to-this-chat) — exception classification is
name-based so the module has zero PTB imports and is unit-testable.
`LinkHealthCache` implements the spec §18 TTL cache with explicit
invalidation triggers.

## Data model (v28 additions)

```
indexed_files            + source_status TEXT        (NULL = legacy = available)
                         + source_verified_at TEXT
force_join_channels      + link_type TEXT
                         + link_health TEXT
                         + link_health_updated_at TEXT
                         + link_last_error TEXT
                         + link_expires_at TEXT
                         + link_validation_status TEXT
bot_settings             + fj_link_auto_rotate = '1'      (seeded)
                         + fj_link_health_cache_ttl = '300' (seeded)
                         + index_job:<channel_id>          (durable scan jobs)
                         + index_verify:<channel_id>       (verification reports)
indexes                  + idx_indexed_files_source_status
                         + idx_fjc_link_health
```

## Identity rules (unchanged, enforced everywhere)

* `file_id` — bot-scoped sendable identifier; refreshed in place by the
  duplicate-repair path and by reconciliation; never overwritten on
  ambiguous identity.
* `file_unique_id` — deduplication identity ONLY; never sent through a
  send API.
* `source_channel_id + message_id` — recovery/reference pair.

## Staged migration map (future phases)

The specification's full `app/bot/handlers/...` tree remains the target.
Recommended order once PHASE 3/4 (Mini App browsing + streaming) lands:
1. `app/media/` — MediaResolver + stream gateway (new code, new module).
2. `app/web/` — extract the mini-app HTTP server routes.
3. `app/bot/handlers/` — move handler groups one panel at a time, keeping
   `bot.py` re-exporting names so the regression suites stay green.

---

# Architecture — NETWORK PLATFORM (Phase 8 → Network, v29)

## Additive layer

```
payload-bot/
├── run.py                     ← PRODUCTION ENTRYPOINT (unchanged)
├── bot.py                     ← compatibility core + network wiring
├── app/
│   ├── main.py                ← entrypoint adapter (unchanged)
│   ├── core/                  ← PHASE 8 services (unchanged)
│   │   ├── indexing_engine.py
│   │   ├── verification.py
│   │   └── fj_link_health.py
│   └── network/               ← NEW: the multi-bot expansion services
│       ├── credentials.py     ← CredentialVault (authenticated token
│       │                          encryption; Fernet / stdlib AEAD)
│       ├── registry.py        ← verified-activation registration state
│       │                          machine, health/lifecycle transitions,
│       │                          memberships
│       ├── points.py          ← idempotent points ledger service
│       ├── routing.py         ← health-aware weighted-random router +
│       │                          opaque signed Global Payload Links
│       ├── broadcast.py       ← durable network broadcast engine
│       └── workers.py         ← BotWorkerManager (PTB manual lifecycle;
│                                  shared handlers, per-bot context)
├── docs/NETWORK.md            ← the network platform documentation
└── ...
```

Same discipline as `app/core/*`: standalone modules, never importing the
bot monolith; `bot.py` wires them with its DB adapter and transports at
call time.

## Execution model

```
                    MAIN APPLICATION (run_polling, unchanged)
                                   │ post_init
                                   ▼
                     network_startup: init services,
                     restart ACTIVE bot workers, resume
                     RUNNING broadcasts, health loop
                                   │
        ┌──────────────────────────┼──────────────────────────┐
        ▼                          ▼                          ▼
   BotWorker A                 BotWorker B                BotWorker C
 (shared handlers,      (shared handlers,           (shared handlers,
  bot_data context)      bot_data context)            bot_data context)
        │                          │                          │
        └────────── ONE SHARED LAYER ───────────────────────────┘
              Access Engine · Delivery Engine · Payloads · Search
              Indexing (Phase 8) · Verification · Force Join
              Watch Ads · Referral · Points · Settings · SQLite
```

* The main bot's `run_polling` lifecycle is untouched. Workers use
  `initialize → start → updater.start_polling` (PTB custom lifecycle) on
  the SAME event loop.
* Workers register the SAME handler functions (`start_command`,
  `on_callback` via the user-safe guard, `text_handler`, …) — one bug fix
  reaches every bot.
* `/start` inside a worker records the user↔bot membership
  (reachability) and stamps the network context.

## Media transport across bot identities (the hard rule)

`file_id`s are MAIN-BOT-scoped. A network bot delivers payload files via
**native source copy** — `copy_message(user, source_channel,
source_message)` using the indexed file's durable source references.
Albums go as sequential source copies. A network bot that cannot access
the storage channel is honestly payload-ineligible (capability tracked at
registration + health checks) — the router excludes it; the user never
gets a dead end. No cross-bot file_id reuse; no file_unique_id in send
APIs; no downloads for delivery.

## Broadcast topology

`broadcasts` (owner's ONE job) → `broadcast_bot_jobs` (per-bot durable
cursor) → `broadcast_deliveries` (per-user durable state). Reachability
(ACTIVE memberships) governs targeting; the engine's per-bot workers
send with per-bot pacing, FloodWait handling, and failure classification;
restart resumes from the durable rows. The legacy
`scheduled_broadcasts` single-bot system remains untouched.

## Where the wiring lives (bot.py)

* Migration v29 + ~35 DB adapter methods (Database class).
* Access Engine: points as the third OR alternative (three check sites:
  referral-locked branch, watch-ad gate, last-line delivery gate).
* `ptunlock:` callback — the atomic purchase transaction.
* `/start g<code>` — Global Payload Link routing.
* `send_file` / `send_album` network branches (source-copy transport).
* `/network` user panel + registration wizard + admin Network Control /
  Broadcast Center / Global Link management callbacks.
* `post_init`/`post_shutdown` hooks (network_startup/network_shutdown).
* Mini App `POST /api/network/auth` (WebApp initData HMAC validation).

See `docs/NETWORK.md` for the full behavioral specification mapping.

---

# Architecture — ARCHITECTURE PHASE (post-extraction)

## The layered platform

```
run.py → app.main → bot.main → build_application (pinned facade)
                                  │
                                  ▼
              app/bootstrap/application.create_application
              app/services/container.ServiceContainer
                                  │
        ┌─────────────────────────┴─────────────────────────┐
        │ ADAPTERS                                               │
        │  app/bot/handlers/network.py (42 net handlers)      │
        │  app/bot/callbacks/router.py (namespace registry)    │
        │  app/bot/keyboards/builders.py                       │
        │  app/web/{application,auth,routes,watch_ads}.py     │
        │  app/network/* (baseline services, unchanged)        │
        └─────────────────────────┬─────────────────────────┘
                                  ▼
        CORE SERVICES (no bot.py imports, no Telegram UI objects)
        app/core/access/engine.py        AccessResult + points alternative
        app/core/payload/service.py      slugs/links/creation
        app/core/delivery/service.py     recovery card + retrieve resolvers
        app/core/force_join/service.py   membership + active-batch machine
        app/core/referral/service.py     gate/qualification/links
        app/core/watch_ads/service.py    config/gate/session URL/templates
        app/core/indexing/engine.py      durable scan jobs (Phase 8 core)
        app/core/verification/engine.py  verification + reconcile (Phase 8)
        app/core/{constants,format}.py   shared leaf modules
                                  ▼
        REPOSITORIES (no Telegram imports at all)
        app/storage/repositories/{users,media,payloads,force_join,
        referrals,watch_ads,network,broadcasts,deliveries,settings}.py
        app/storage/database.py (DatabaseBase) + migrations.py + dbutil.py
                                  ▼
        SQLite (aiosqlite) — schema v29, unchanged semantics
```

## The extraction mechanism (why the regression suites stay green)

Two patterns, both verbatim-body moves (zero logic edits):

1. **Mixin composition (storage)** — `bot.Database(DatabaseBase)` inherits
   ~236 repository methods composed from ten domain mixins; only the
   source-pinned migration core and Watch Ads transaction methods remain
   in the subclass.
2. **Closure factories (services)** — each service module exposes
   `make_<service>(db, *, <explicit deps>)` returning the verbatim
   implementations bound to explicit dependencies. bot.py keeps one thin
   wrapper per function that reads the CURRENT module globals at call
   time — which is exactly why the suites' monkey-patching
   (`B.db = …`, `B.force_join_active = …`, `B._deliver_files_core = …`)
   keeps working: the patch replaces the wrapper, and every frozen caller
   resolves the wrapper through the bot.py namespace at call time.

## Frozen zones (the honest constraint)

The 12 regression suites pin ~181 literal source-text patterns inside
bot.py (function bodies, log formats, call counts, HTML). Those bodies
STAY in bot.py verbatim and are inventoried in
`docs/BOT_COMPATIBILITY.md`. The single-engine rule is preserved: the
pinned shells call INTO the extracted sub-services; nothing is
duplicated.

## Media boundary for the NEXT phase

`app/media/interfaces.py` defines MediaSource / MediaHandle /
MediaResolver (abstract only). The next phase implements
TelegramSource / LocalBotApiSource / CacheSource + the MediaGateway with
HTTP Range against these contracts — WITHOUT touching business logic,
and never exposing bot tokens to web code.
