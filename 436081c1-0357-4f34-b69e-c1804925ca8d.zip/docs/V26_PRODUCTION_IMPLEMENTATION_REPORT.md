# V26 PRODUCTION IMPLEMENTATION REPORT

## 1. Executive Summary

V26 was implemented against the REAL uploaded production tree
(`payload-delivery-bot-V25 (3).zip`, schema v42 / BOT-26 UX build) IN
PLACE at `/home/z/my-project/pdb-v25` — no rebuild, no architecture
change, no V25/V42 functionality removed. Every requirement was traced
to a real code path, root-caused from the uploaded production evidence
(bot-36.log, bot-37.log, the 3-page production PDF), implemented, and
verified through **63/63 automated checks** on the real runtime
namespace + real schema, **live HTTP verification** of the exact PDF
page-2 scenario, **live browser verification** of the fresh first-click
Age Gate, and a full `py_compile` pass.

Verification classes used throughout (strict distinction):
**LIVE VERIFIED** (real browser / real HTTP against the real stack) ·
**MOCKED VERIFIED** (mock Telegram transport boundary, deterministic
assertions) · **AUTOMATED VERIFIED** (integration checks over real code
+ real DB) · **NOT VERIFIED LIVE** (requires a real Telegram
deployment).

## 2. Production Evidence Analyzed

| Evidence | What it showed |
|---|---|
| bot-36.log / bot-37.log | main bot @Moviefilven_bot, admin 8370454312, 3 ACTIVE network bots, schema v42 verified, two-stage Delivery Channel WORKING (NETWORK_BOT_COPY_TO_USER_SUCCESS jobs 83/84), Watch Ad sessions 138/139/140 created + polled, FJ progressive batches healthy (6/6 channels), AGE gate flows at 17:16/17:38/17:44 (each fresh session re-requested /site/c/adult before confirming) |
| PDF page 1 | the website header + a payload card (site works) |
| PDF page 2 | **Watch Ad "Ad Unavailable — This ad session could not reach the server. Check your connection and retry, or return to Telegram and press Watch Ad again." (Try Again / Rewarded ad · verification required)** — opened from a NETWORK bot ("X Bot") |
| PDF page 3 | the Force Join "Required Channels" gate (the FJ prerequisite before Watch Ads) |
| bot-37.log message-872 timeline | 17:26/17:27 create wizards for message 872 → payload 787 created → **Button_data_invalid** on every Payload Manager render (the admin tapped pcw:create 5+ times); 00:49 + 01:29 re-forwards of the SAME message → `decision=create_wizard` again (duplicate risk) |

## 3. Root Causes → Fixes

### 3.1 Network Bot Watch Ads — "Ad Unavailable" (PDF page 2)

* **Root cause**: `app/presentation/telegram/miniapp.py`
  `_wad_handle_status` (line 819) and `_wad_handle_ad_event` (line 911)
  validated initData with `validate_telegram_init_data` — the MAIN bot
  token ONLY. A Watch Ad Mini App launched from a NETWORK bot signs its
  initData with THAT bot's token → 401 on every poll → the frontend's
  bounded sync (6 × 900 ms + the 20 s deadline) expired → the exact PDF
  error text (the `tg.initData`-present branch). The public Website has
  had multi-token validation since WEBSITE PHASE 3 §11; the Watch Ads
  mini app did not. Same defect class in `_net_handle_webapp_auth`
  (line 1295).
* **Fix**: `_wad_validate_init_data_multi` — the main bot token FIRST
  (the existing canonical validator, byte-identical main-bot behavior),
  then every ACTIVE network bot token via the EXISTING
  `_website_network_bot_tokens` provider (credential registry +
  dedicated-key decryption; tokens never logged), each validated with
  the SAME canonical `_validate_webapp_init_data` HMAC validator. NO
  second HMAC implementation, NO bypass. Applied to the status +
  ad-event endpoints and `/api/network/auth` (which now also reports
  `via: main|network`). `WATCH_AD_AUTH_VIA_NETWORK bot_id=… user_id=…`
  is the structured observability line.

### 3.2 Reward routing through the serving bot

* **Root cause**: `_notify_watch_ad_reward` used `_mini_app_bot` (the
  MAIN bot). A user who only talks to a network bot (they clicked ITS
  payload link) may have never started the main bot — its DM fails
  Forbidden, so the "Ad reward verified!" notification and the
  auto-resume delivery never reached the user.
* **Fix**: the launch context is recorded on the session — schema v43
  `watch_ad_sessions.launch_network_bot_id` (additive, nullable,
  idempotent; legacy rows stay NULL = main-bot semantics), stamped by
  `build_watch_ad_session_url(network_bot_id=…)` when the access
  screen renders inside a network worker (`_serving_network_bot_id`
  resolves the serving bot through the live BotWorkerManager —
  telegram-id lookup first, username fallback, the same guarded
  resolution lifecycle.py uses; `handle_watch_ad` uses
  `_net_context_id(context)`). `process_watch_ad_reward` returns the
  launch context on every outcome; `_wad_reward_delivery_bot` resolves
  the network bot's LIVE worker client (`_net_workers.get_bot_client`)
  and falls back to the main bot for legacy sessions, stopped workers,
  or any lookup failure. The Access Engine re-entry in
  `_auto_resume_watch_ad_delivery` remains the single authorization
  layer — Force Join, admin/premium exemptions and the unlock window
  are unchanged.

### 3.3 The message-872 identity issue — Button_data_invalid

* **Root cause (REPRODUCED before the fix)**: payload 787's routing
  slug `clipmatezone_indias_got_latent_2026_bonus_s02e03_1080p` begins
  with "c"; `pm_payload_detail` used the naive
  `routing_slug.startswith(COLLECTION_LINK_PREFIX)` → the single-file
  payload was misdetected as a collection → the Files button became
  `managefiles:lipmatezone_indias_got_latent_2026_bonus_s02e03_1080p` =
  **65 bytes > Telegram's 64-byte callback_data limit** →
  `BadRequest: Button_data_invalid` on BOTH `safe_edit_text` AND the
  fallback `safe_send_text` — the Payload Manager could NEVER render
  (bot-37.log 17:27:26–17:30:26, 01:29:00).
* **Fix**: the CANONICAL `is_collection_link` predicate (c + hex-only
  body — the exact /start routing truth) replaces the naive checks at
  every site: `pm_payload_detail` (access_panels.py), the preview-mode
  panel, retrieve.py ×3, wizard.py ×2, delivery.py's retry-file
  verification, admin_commands.py's retrieve list (which also gets the
  canonical `is_msg_link` — an "m…"-named payload is no longer a
  phantom "File" row). A 64-byte guard on the `managefiles` callback is
  defense in depth. REPRODUCTION AFTER: zero over-limit callbacks; the
  Files button is the truthful single-file shape (`Files (1)` /
  `filepreview:<index_id>`); real collections keep
  `managefiles:<hex>`.

### 3.4 The message-872 identity issue — duplicate detection

* **Root cause**: `_finalize_forward_batch`'s duplicate detection was
  COLLECTION-ONLY (`find_collection_by_message_ids`). Re-forwarding
  message 872 (payload 787's exact file, file_pk 1174) always produced
  `existing_collection_id=None decision=create_wizard` — bot-37.log
  shows FOUR wizards for one file (17:26, 17:27, 00:49, 01:29).
* **Fix**: `find_single_payload_by_channel_message` (payloads repo)
  resolves the single-file payload by the EXACT channel+message
  identity (lowest payload id wins — deterministic). The forward flow
  now shows the same P12 "Existing Payload Found" screen with the
  payload's OWN buttons (Edit `pcw:edit`, Manage `pldetail`, File
  `filepreview`, Preview `linkpreview:m:<mid>` — all bounded, all ≤ 64
  bytes). `BOT6_PAYLOAD_DETECT` now logs `existing_payload_id=` too.

### 3.5 Fresh first-click Age Gate

* **Root cause**: the one-time welcome overlay (`#wintro` —
  position:fixed, inset:0, z-index 220, auto-hides after ~2.9 s) is
  rendered by `_page()` on the FIRST page of a browser session. On the
  age-gate interstitial it sat ON TOP of the "I am 18 or older" button
  — the user's first tap hit the overlay. bot-37.log shows every fresh
  session re-requesting `/site/c/adult` before the
  `POST /site/api/session/age` confirm fired (17:16→17:16:42→confirm;
  17:38→17:38:16→confirm; 17:43:47→17:43:59→confirm).
* **Fix**: `_page(no_intro=True)` omits ONLY the overlay markup — the
  bootstrap script still ships (it owns the header THEME toggle; its
  intro half is null-safe when `#wintro` is absent). The age gate page
  passes `no_intro=True`. Content pages keep the overlay (verified),
  so the one-time welcome still appears — on the first CONTENT page
  instead of blocking a gate.

### 3.6 No group/supergroup delivery (V26 mandate)

* **State**: V25 already routes every job two-stage (Storage Channel →
  FDB → Delivery Channel → Network Bot → User) with NO group-based
  production routing (the file_delivery.py module header documents the
  full removal; legacy group primitives retained only as deprecated
  audit tooling).
* **Gap closed by V26**: `verify_delivery_channel` accepted
  GROUP/SUPERGROUP chat types for NEW setups. NEW setups now REQUIRE
  `ChatType.CHANNEL` (rejected with the honest remediation:
  create a private broadcast channel, add the FDB as ADMIN + the
  network bot, then /setup there). The chat ALREADY persisted as the
  bot's `delivery_channel_chat_id` (the v42 legacy migration —
  production evidence bot-37.log jobs 83/84) stays grandfathered, and
  `DELIVERY_CHANNEL_LEGACY_CHAT_ACCEPTED` logs the acceptance
  honestly. A bot with a persisted legacy channel cannot SWAP to a
  different supergroup through the back door.

## 4. Files Changed (V25 → V26)

| File | Change |
|---|---|
| `app/storage/schema.py` | SCHEMA_VERSION 42→43; `watch_ad_sessions.launch_network_bot_id` (SCHEMA_SQL + WATCH_AD_SESSION_COLUMNS + the v43 migration block); `process_watch_ad_reward` returns the launch context |
| `app/storage/repositories/watch_ads.py` | `set_watch_ad_session_launch_network_bot_id` (best-effort, idempotent) |
| `app/storage/repositories/payloads.py` | `find_single_payload_by_channel_message` (exact-identity single-file lookup) |
| `app/presentation/telegram/miniapp.py` | `_wad_validate_init_data_multi` (multi-token initData); status/ad-event endpoints use it; `_net_handle_webapp_auth` multi-token + `via`; `_wad_reward_delivery_bot` (launch-context routing with main-bot fallback) |
| `app/presentation/telegram/watchads.py` | `_serving_network_bot_id`; `show_watch_ad_access_screen` + `handle_watch_ad` stamp the launch context; `_resolve_watch_ads_dashboard_context(network_bot_id=…)` |
| `app/presentation/telegram/_manifest.py` | the 3 new namespace functions registered |
| `app/presentation/telegram/access_panels.py` | canonical `is_collection_link` + `parse_collection_link` + the 64-byte guard (payload detail + preview panel) |
| `app/presentation/telegram/retrieve.py` | canonical `is_collection_link`/`parse_collection_link`/`is_msg_link` ×3 sites |
| `app/presentation/telegram/wizard.py` | canonical predicates ×2 sites (edit mode + auto-preview scan) |
| `app/presentation/telegram/delivery.py` | canonical predicate (retry-file verification); the single-file "Existing Payload Found" screen + `BOT6_PAYLOAD_DETECT existing_payload_id` |
| `app/presentation/telegram/admin_commands.py` | canonical predicates (retrieve list rendering) |
| `app/core/watch_ads/service.py` | `build_watch_ad_session_url(network_bot_id=…)` + launch-context stamping |
| `app/web/site/html.py` | `_page(no_intro=…)` — suppress ONLY the #wintro overlay markup |
| `app/web/site/screens.py` | `age_gate_page` renders with `no_intro=True` |
| `app/network/file_delivery.py` | NEW Delivery Channel setups require ChatType.CHANNEL (grandfathered persisted legacy chats); `_safe_row_get` import |
| `tests/test_v26_production.py` | NEW — 63 checks (sections A–G) |
| `mini-services/site-demo/`, `mini-services/watchad-demo/` | NEW — demo-only browser-QA services (never part of the production boot path) |
| `README.md`, `docs/V26_PRODUCTION_IMPLEMENTATION_REPORT.md` | the V26 release notes + this report |

## 5. Database / Compatibility

* Schema v42 → v43 is **additive, nullable, idempotent and
  restart-safe**: one column (`watch_ad_sessions.launch_network_bot_id`),
  no existing row modified, legacy rows keep NULL (main-bot semantics —
  pre-V26 reward routing preserved exactly). Fresh DBs get the column
  from SCHEMA_SQL; v42 DBs get it from the migration; a stamped-v43 DB
  re-running init_schema is a no-op (verified).
* All v39/v42 columns, the legacy `network_delivery_groups` compat
  table and every prior migration are untouched (regression-pinned:
  G3/G4/G8).

## 6. Security Posture (explicitly unchanged / strengthened)

* initData HMAC-SHA256 (the official WebAppData model) is enforced for
  EVERY accepted token — main AND network. Tampered signatures are
  rejected (A4, live check 3); stale auth_date rejected (A6).
* Cross-user session usage rejected 403 (A9, live check 2).
* Unknown/foreign bot signatures rejected (A3/A13).
* Monetag S2S postback remains the ONLY reward authority — the status
  and ad-event endpoints are display-only and NEVER advance reward
  state (G7).
* Ownership/worker resolution never fabricates access: the launch
  context only routes WHICH bot sends; the Access Engine re-entry
  re-checks Force Join and the unlock window (unchanged).
* No tokens are logged or exposed; the network token provider is the
  existing registry/vault boundary.

## 7. Verification Performed

### 7.1 Automated (tests/test_v26_production.py — 63/63)

Sections A (multi-token Watch Ads auth ×14), B (launch context +
reward routing ×15), C (message-872: the Button_data_invalid
reproduction + duplicate detection ×11), D (age gate ×6), E (delivery
channel policy ×5), F (schema v43 ×4), G (V25/V42 regression pins ×8).
Executed against the REAL runtime namespace + real Database/schema on
a throwaway SQLite file.

### 7.2 LIVE VERIFIED (real HTTP against the real handlers)

`mini-services/watchad-demo` — the production Watch Ads route table
with one ACTIVE network bot (real encrypted credential, dedicated
NETWORK_TOKEN_ENCRYPTION_KEY) and a live ad session:

1. network-bot-signed status poll → **HTTP 200 `{"status":"pending",
   "required_ads":1,"completed_ads":0,"next_ad_index":1,…}`** — the
   exact PDF page-2 scenario, now fixed. Server log:
   `WATCH_AD_AUTH_VIA_NETWORK bot_id=424242 user_id=8922807758`.
2. cross-user poll (user B, network-signed) → 403 forbidden.
3. tampered signature → 401 unauthorized.
4. main-bot-signed poll → 200 pending (unchanged).
5. ad-event (network-signed) → 200 ok.
6. `/api/network/auth` (network-signed) → 200
   `{"ok":true,…,"via":"network"}`.

### 7.3 LIVE VERIFIED (real browser — agent-browser + VLM screenshots)

`mini-services/site-demo` — the REAL production website stack
(app/web/site) with a seeded DB, the Telegram SDK shim and autologin:

* **Fresh first-click Age Gate**: fresh session → `/site/c/adult` →
  the gate renders with NO `#wintro` overlay (`hasIntro:false`,
  `btnEnabled:true`) → the FIRST tap on "I am 18 or older" fired
  `POST /site/api/session/age` IMMEDIATELY (network log: `(Fetch) 200`)
  → the page reloaded into the adult CONTENT listing. The content page
  still shows the one-time welcome overlay (`hasIntro:true`) — the
  intro moved to the first content page instead of blocking the gate.
* VLM screenshot reviews: the gate modal (nothing overlapping the
  button), the desktop home (correct cards/nav), the Watch Ad mini app
  page (Watch Ad button + token present).
* Responsive: no horizontal overflow at 320 px; no console/page errors
  on any surface.

### 7.4 Compile / schema

`python3 -m py_compile` across EVERY app module + tests + run.py: clean.
Schema verify report (from the live demo boot): every column PASS
including `watch_ad_sessions.launch_network_bot_id=PASS`, DB stamped
v43.

## 8. What is NOT verified live (honest classification)

* **Real Telegram transport** (no bot token / outbound Telegram API in
  this environment): the network-bot Watch Ads flow is verified to the
  REAL HTTP handler boundary with the official initData signing model
  (the signature the real Telegram client produces); the worker-side
  launch-context stamping is verified at the function level with the
  real resolution logic; the reward notification send through the
  network worker client is MOCKED-verified (the client resolution +
  fallback matrix). The live production deployment should re-confirm
  `WATCH_AD_AUTH_VIA_NETWORK` + `WATCH_AD_REWARD_ROUTE` in the logs on
  the first real network-bot Watch Ad.
* **The live message-872 payload 787 row itself** lives in the
  production DB (not shipped in the ZIP) — the defect was REPRODUCED
  locally with the exact slug/message identity from bot-37.log and the
  fix verified against that reproduction; the production row needs no
  migration (the fix is render-time).
* **Monetag SDK ad playback + S2S postback delivery** require the
  provider's live zone traffic — unchanged by V26 (regression-pinned
  at the reward-transaction level).

## 9. V25/V42 Regression Outcome

All preserved: main-bot Watch Ads auth byte-identical (G1/G2 + live
check 4), the two-stage Delivery Channel schema + routing markers
(G3/G4), real collection routing (G5, C3), the Watch Ads page contract
(G6), the display-only status endpoint semantics (G7), the legacy
group compat table (G8), the FJ gate rendering (browser-verified),
site rendering + responsiveness (browser-verified), schema migration
idempotence (F3/F4). Nothing was weakened or deleted; the V26 suite is
entirely NEW (the uploaded ZIP is the runtime-only package — it
contains no prior tests to weaken).

## 10. Final V26 Status

**COMPLETE.** All four documented V26 items are implemented with
root-cause evidence, verified through the automated suite (63/63),
live HTTP verification (the PDF page-2 scenario), and live browser
verification (the fresh first-click Age Gate). The remaining
NOT-VERIFIED-LIVE items are exactly the ones that require a real
Telegram deployment and are classified honestly above.

---

## 11. Round 2 — QA hardening, gateway-aware demos, verification-center upgrade

**Date:** 2026-09-22 (round 2 of the V26 verification center)

### Bugs found by QA and fixed (demo/QA surface only — the production tree is untouched)

1. **Demo services died between shell commands.** This sandbox kills every
   process spawned directly by a command when it completes (setsid/nohup do
   NOT survive). Fixed with a double-fork daemonizer +
   `mini-services/start-demos.sh` (correct `pkill` pattern for the
   cwd-relative `python3 index.py` cmdline + an explicit port-free wait so a
   stale listener can never shadow a fresh instance with "address already in
   use").
2. **The preview-panel "Open" links 404'd.** The gateway (Caddy) routes to
   the demo ports via `?XTransformPort=<port>`, but ANY redirect, link or
   fetch that dropped the param fell back to the Next.js app (404). Fixed
   with `mini-services/_gateway_aware.py` — a demo-only middleware that
   rewrites Location headers (including aiohttp RAISED `HTTPFound`s), HTML
   attribute URLs and root-relative JS string literals inside `<script>`
   blocks. 12 unit checks + the full gateway E2E pass; direct-access
   requests stay byte-identical.
3. **The Telegram SDK shim never applied (both demos).** Two latent bugs:
   `await resp.text()` on a non-awaitable property (TypeError swallowed by
   `except: pass`) and `web.Response(..., content_type=..., headers=...)`
   with a copied Content-Type header (ValueError — aiohttp forbids both).
   Both fixed; the shim now rewrites correctly.
4. **watchad-demo had no always-fresh entry point.** The seeded session
   expires after 900s. Added `GET /demo/renew` (reuses or re-mints the
   session, redirects to the live Mini App page) + a root redirect.

### New live-verification capability (the biggest round-2 win)

The watchad-demo SDK shim now generates initData **signed at request time
with the NETWORK bot token** using the exact official Telegram WebAppData
model (`secret = HMAC_SHA256("WebAppData", bot_token)`,
`hash = HMAC_SHA256(secret, data_check_string)`, fresh `auth_date`). A real
browser session through the gateway now demonstrates the ENTIRE V26 fix
live:

* the status poll carries a NETWORK-bot signature →
  `WATCH_AD_AUTH_VIA_NETWORK bot_id=424242` in the log → **200 pending**
  (previously the exact PDF page-2 "Ad Unavailable");
* `▶️ Watch Ad` → ad-event → "Verifying reward…";
* the Monetag S2S postback (`?ymid=<token>&event=show&value=valued`) →
  **"🎉 Your payload is unlocked! Rewards verified: 1/1"**.

### Verification Center (Next.js /) — upgraded

* **New APIs:** `/api/v26/logs` (live log tails, both services),
  `/api/v26/test-run` (POST — runs the real suite via the venv Python,
  parses every check; GET — last run), `/api/v26/status` now includes
  per-demo latency + working gateway links + the live Watch Ad session.
* **New UI:** interactive suite explorer (accordion + "Run suite now" with
  per-check results + toasts), live terminal-style log viewer with
  service tabs + auto-refresh + colorized `WATCH_AD_AUTH_VIA_NETWORK`
  lines, evidence gallery with lightbox (7 real QA screenshots), animated
  stat counters, upgraded architecture flow, scroll-progress bar,
  copy-to-clipboard for the ZIP SHA-256 + session token, reveal-on-scroll
  animations (reduced-motion aware).
* **Fixed a mobile regression found by QA:** accordion triggers overflowed
  at 320/390px (nested `truncate` chains do not stop intrinsic min-content
  propagation — the trigger itself needed `min-w-0`). Verified clean at
  320/390/768/1280.

### Round-2 verification classes

* LIVE (real browser, through the real gateway): autologin chain, age-gate
  first click → content, watch-ad renew → Mini App, network-signed status
  poll, ad click, S2S postback, unlock screen.
* LIVE (real HTTP): all gateway rewrites, ZIP download with matching
  SHA-256, both healthz endpoints.
* AUTOMATED: 63/63 suite (re-run twice this round), 12 gateway-rewrite
  unit checks, ZIP completeness diff against the tree.
* Still NOT-LIVE (unchanged, honest): real Telegram transport, the
  production DB row 787, Monetag zone traffic.

### Production ZIP (round 2)

`payload-delivery-bot-V26.zip` rebuilt (200 files — now includes
`mini-services/_gateway_aware.py` + `start-demos.sh`; this document and
the README carry the round-2 notes). The live SHA-256 is always shown on
the verification center (it is served from the same ZIP, so a hash
embedded here could never be self-consistent). The production tree
(`app/`, `cloudflare/`, `docs/`, `tests/`, `run.py`, `requirements.txt`,
`README.md`) is byte-identical to round 1 apart from this report + the
README round-2 note — every functional round-2 change lives in demo-only
glue.

---

## 12. Round 3 — the interactive verification center

**Date:** 2026-09-22 (round 3) · production tree untouched (all changes are
demo glue + the Next.js QA surface).

### The flagship: drive-the-fix-yourself Watch Ad demo

The verification center now embeds the REAL Watch Ads Mini App and lets a
user complete the entire V26 fix flow with three clicks — no terminal, no
curl:

1. **Launch** — `POST /api/v26/watchad-demo {action:"mint"}` proxies a new
   demo-only `POST /demo/mint` on the watchad-demo (mints/validates a
   session, returns the token + a freshly NETWORK-bot-signed initData).
   The Mini App page embeds as a same-origin iframe through the preview
   gateway.
2. **Watch** — the user presses ▶️ Watch Ad INSIDE the real production
   page (stub SDK resolves instantly). The dashboard detects the
   "Verifying reward…" state by reading the same-origin iframe DOM.
3. **Reward** — the "Send Monetag S2S postback" button calls the REAL
   production endpoint (`GET /api/watch-ad/postback?ymid=<token>&event=
   show&value=valued`); the embedded Mini App's own polling loop then
   flips to "Your payload is unlocked" — 5/5 steps, verified end-to-end
   in an automated agent-browser run.

A 5-step live indicator tracks the flow (session minted → Mini App
loaded → ad watched → S2S postback → reward verified) with a live
session panel (token, network bot id, TTL countdown, ads progress) and
a "Fresh session" restart. Token-shaped input is regex-validated at the
proxy boundary (`/^[0-9a-f]{32}$/`).

### Other additions

- `/demo/status` (demo-only JSON session reader) for the step indicator —
  the REAL status endpoint remains the initData-authenticated path.
- Verification-evidence mix chart (LIVE/AUTOMATED/MOCKED/NOT-LIVE bar
  distribution computed from the fix cards).
- Deploy quick-start card (3 copyable commands + the production log
  markers to watch) and a V25→V26 release-timeline card.
- Latency sparklines on the demo cards (20-sample ring buffers),
  loading skeletons for the initial fetch, hero dot-grid pattern.
- Bug fixes found by QA this round: `sqlite3.Row` has no `.get()` in the
  mint handler; the postback ledger keys on `ymid_prefix = token[:10]`
  (not 6); the step-5 terminal state never displayed as done; a mobile
  overflow regression from flex-layout mono identifiers in the deploy
  footnote. All fixed; 320/390/768/1280 clean.

### Verification classes (round 3)

LIVE (automated agent-browser through the gateway): the full interactive
demo flow 5/5 including the in-iframe Watch Ad click and the reward
unlock; all new sections render; zero console errors; zero broken
images; no horizontal overflow at 320/390/768/1280. AUTOMATED: 63/63
suite re-verified; lint clean. ZIP rebuilt (200 files, sha256
`965bbc56…`, hash synced + download-verified).

## 13. Round 5 — before/after: reproduce the V25 bug on demand + accessibility hardening

Scope: demo glue + the Next.js verification center ONLY. The production
tree (`app/`, `tests/`, `run.py`, schema) is byte-identical to round 1
apart from nothing — this round touched zero production files.

### The V25 pre-fix fault injection (watchad-demo, demo-only)

- `GET /watch-ad/<token>?mode=v25` sets a `demo_v25` cookie (Lax,
  1h). While the cookie is set, a demo-only middleware (outermost in
  the stack, BEFORE the production handlers) answers
  `POST /api/watch-ad/status` and `POST /api/watch-ad/ad-event` with
  `401 {"status": "unauthorized"}` — the EXACT response shape the
  pre-V26 main-token-only validator produced for a NETWORK-bot-signed
  initData. `?mode=v26` (on any watch-ad page) clears the cookie and
  restores the real V26 validation.
- Every short-circuited poll logs
  `WATCH_AD_DEMO_V25_MODE path=… result=401 reason=main_token_only_validator_pre_v26`
  (and cookie set/clear lines) so the simulation is always visible in
  the service log — nothing is silently faked.
- The Mini App itself is untouched: with the cookie set, its real
  frontend treats the 401s as transient, retries, and after the REAL
  20-second production sync deadline renders the EXACT PDF page-2
  screen: "Ad Unavailable — This ad session could not reach the
  server. Check your connection and retry, or return to Telegram and
  press Watch Ad again." with the 🔄 Try Again button.
- Verified over real HTTP (curl): no cookie → `200 pending` +
  `WATCH_AD_AUTH_VIA_NETWORK bot_id=424242`; cookie → `401
  unauthorized` + the WATCH_AD_DEMO_V25_MODE line. Verified live in a
  real browser through the gateway: launch in V25 mode → live
  countdown (18s → 13s → 9s → 6s → 2s) → "Ad Unavailable" → BUG
  REPRODUCED panel → "Switch to V26 and watch it work" → the same
  session syncs instantly → Watch Ad → S2S postback → "Your payload
  is unlocked!" 5/5.

### Dashboard: the before/after demo surface

- The Watch Ad demo card now has a V26/V25 radiogroup toggle. V25 mode
  renders a 5-step FAILURE stepper (session minted → Mini App loaded →
  status polls rejected → 20s sync deadline with a live countdown →
  "Ad Unavailable"), a rose BUG REPRODUCED · PDF p.2 badge, a root
  cause panel (network-bot signature vs main-token-only validation,
  the fix contract) with the verbatim PDF quote, and a one-click
  "Switch to V26" CTA.
- Bug found & fixed during QA: the iframe DOM detection originally
  read `body.textContent`, which INCLUDES the inline script source —
  the string literals "Ad Unavailable" / "Syncing with server…" fired
  the detection instantly (and would have false-positived the V26
  "Verifying reward" step too). The detection now reads the RENDERED
  `#headline` / `#state` elements only. A second bug: relaunching
  with the same session token did not reload the iframe (same React
  key + same src) — fixed with a run counter in the iframe key.

### Accessibility hardening (the verification center)

- axe-core audit before: 7 violations (aria-valid-attr-value ×2,
  aria-progressbar-name, link-name, scrollable-region-focusable ×2,
  heading-order, landmark-unique) + 118 contrast nodes. After:
  **0 violations** (the remaining 25 "incomplete" nodes are
  manual-review items — gradient-clipped and translucent-background
  text axe cannot compute; visually verified passing).
- Heading hierarchy: every section title is now a real `<h2>`
  (previously styled divs); the accordion items stay `<h3>`.
- Landmarks labelled (`header`/`main`/`footer` aria-labels) so they
  stay unique against the embedded production pages' landmarks.
- The log panels are keyboard-focusable scrollable regions
  (`role="log"` + `tabIndex=0` + the custom scrollbar), replacing the
  Radix ScrollArea viewport quirk.
- Both Tabs surfaces (log viewer, endpoint explorer) now render real
  `TabsContent` panels — the Radix `aria-controls` targets exist (the
  endpoint explorer previously had a TabsList with no content panels,
  and the log viewer rendered its panels outside the Tabs).
- Contrast sweep: zinc-500 body text → zinc-400, zinc-600 footnotes →
  zinc-500, quick-nav chips → zinc-300 (the dark theme now meets
  4.5:1 across informational text).
- Branded `icon.svg` favicon (violet→fuchsia) served locally; the
  layout metadata no longer points at the CDN logo.
- Release timeline entry "V26 · R5" added; the log-viewer colorizer
  highlights `WATCH_AD_DEMO_V25_MODE` lines in rose.

### Verification classes (round 5)

LIVE (agent-browser through the gateway): the complete before/after
story in one session — V25 launch → live countdown → exact PDF p.2
"Ad Unavailable" → switch → V26 unlock 5/5 + REWARD VERIFIED; the
age-gate demo re-verified (gate renders, button uncovered, no wintro,
first tap → 18+ feed, latched proofs); zero console errors; zero
failed requests; no horizontal overflow at 320/390/768/1280; axe-core
0 violations. AUTOMATED: 63/63 suite re-verified after the round
(1180ms); lint clean. ZIP rebuilt with the new demo source (201 files). The authoritative
sha256 is published OUTSIDE the archive (the verification center's
/api/v26/status + page footer) and is download-verified byte-identical
— a hash printed inside the ZIP could never describe itself.

## 14. Round 6 — V27: launch-context metrics + the age-gate before/after

Round-6 work focus (all services green after QA, both mandatory items):
the worklog's own deferred suggestion #1 — the **V27 admin metrics
surface for `launch_network_bot_id`** (production-tree work, its own
round + tests) — plus deferred suggestion #2, the **age-gate V25
fault injection** (the pre-V26 first-tap swallow, on demand).

### The production change (additive, read-only)

`Database.watch_ad_launch_metrics()`
(app/storage/repositories/watch_ads.py) — sessions grouped by launch
context with a LEFT JOIN on network_bots:

* **main** — `launch_network_bot_id IS NULL OR = 0` (NULL and 0 are
  two separate SQL GROUP BY groups but the SAME launch context: the
  main bot / a legacy pre-V26 row — merged in Python, statuses summed,
  last_activity maxed);
* **network[]** — one row per launch bot with the joined username,
  telegram id, bot status, the status split, the completion rate
  (rewarded/sessions, 3 decimals) and last activity;
* **unknown[]** — launch ids with no network_bots row (impossible in
  practice — bots are REMOVED, never deleted — but labeled honestly,
  never silently merged);
* `total_sessions` — always reconciles (main + network + unknown).

Failures return the zeroed structure (observability never breaks the
panel); the method never mutates state. The 📊 Watch Ads Status panel
(watch_ads_status_panel) renders it as the 🚀 Launch context section —
e.g. `@v26_demo_netbot [ACTIVE]: 3 sessions · 2 rewarded (67%)` — and
renders NOTHING when there are no sessions (a fresh deployment's panel
stays exactly as long as before).

### The tests (section H — the suite grows to 73/73)

H1 empty structure on a fresh DB · H2 NULL+0 merge into main with the
status split · H3 the network join (username + telegram id + status) ·
H4 the rate math (2/3 → 0.667) · H5 orphan honesty · H6 totals
reconcile · H7 last_activity = MAX(created_at) · H8 read-only (run
twice → identical, no writes) · H9 the admin panel renders the section ·
H10 no sessions → no section (panel unchanged for fresh deployments).
All on a controlled scratch DB + the main suite DB; the panel check
swaps NS.db temporarily to prove the empty case.

### The demo surface (demo-only glue; the production tree ships only
the repo method + the panel section)

watchad-demo: every `/demo/mint` + `/demo/renew` now stamps the network
launch context through the PRODUCTION setter (the same write
`build_watch_ad_session_url` performs — NET_ROW_ID, the network_bots
row id); the seed adds two historical rewarded sessions (one main, one
network) with FUTURE unlock windows (a past window would be lazily
flipped to 'expired' by `watch_ad_unlock_valid` on the first reward
auto-resume — and being the highest-id rewarded row it would shadow the
fresh session's unlock check); `GET /demo/metrics` serves the REAL
production rollup over the demo DB.

site-demo: `?mode=v25` sets a demo-only cookie; while set, the age-gate
page's HTML gets the `#wintro` overlay markup injected back before the
intro bootstrap script (which always ships — it owns the theme toggle —
so the div alone restores the complete pre-V26 overlay behavior). A
fresh-session guard clears the sessionStorage intro flag first (the
bug happened on the FIRST page of a fresh session). `mode=v26` clears
the cookie. Production code untouched; every injection logs
`SITE_DEMO_V25_MODE`.

### The verification center (dashboard)

* A new **Launch-context metrics** section (id=launch-metrics, in the
  quick-nav): the live rollup from `/demo/metrics` through the Next API
  proxy (action=metrics), a stacked share bar (main vs network vs
  unknown), the per-context table (sessions / rewarded / rate / a
  stacked funnel micro-chart: rewarded-pending-expired-rejected / last
  activity), the honest-unknown rows, an auto-refresh toggle (8s) +
  manual refresh, and the funnel key.
* The **age-gate demo** gained the V25/V26 radiogroup toggle (matching
  the Watch Ad demo): V25 renders the 4-step failure stepper (fresh
  session → interstitial WITH the overlay → first tap swallowed → the
  ~2.9s fade), the live DOM probe showing the INVERSE evidence
  (`#wintro overlay PRESENT`, `button COVERED`), the bot-37.log evidence
  panel (17:16 / 17:38 / 17:44 — every fresh session double-requested),
  the BUG REPRODUCED · bot-37.log badge, and the one-click "Switch to
  V26 and watch the first tap land" CTA.
* The suite count 63 → 73 everywhere (status route, counters, header,
  footer, metadata); the release timeline gained the V27 · R6 entry;
  the endpoint explorer documents /demo/metrics (15 endpoints).

### Verification classes (round 6)

LIVE (agent-browser through the gateway + curl): /demo/metrics over
real HTTP (fresh boot: main 2/1, network 1/1, total 3); a dashboard
mint stamps the network context (main 2→1, network 1→2 — the reused
pending session moves buckets exactly as production stamps it); the
full watch-ad E2E re-verified after the metrics integration (mint →
watch → postback → "Your payload is unlocked!" + REWARD VERIFIED, the
metrics table updates); the seeded sessions STAY rewarded after the
reward path (the future-window fix); the age-gate before/after in one
session — V25 launch → overlay present + button covered (live-detected,
BUG REPRODUCED) → switch → V26 first tap → 18+ feed + FIRST CLICK —
CONFIRMED; zero console errors; zero failed requests; zero broken
images; no horizontal overflow at 320/390/768/1280. AUTOMATED: the
suite 73/73 (re-verified 3× this round); py_compile clean on every
touched production file; lint clean. NOT-LIVE (honest, unchanged): the
real Telegram transport, Monetag zone traffic, the production DB.

## 15. Round 7 — V27: the per-payload launch metrics

Round-7 work focus (all green after QA): the worklog's own remaining
actionable suggestion — the **per-payload launch-metrics breakdown**
("the repo method generalizes: GROUP BY payload_id,
launch_network_bot_id") — plus the dashboard view + styling.

### The production change (additive, read-only)

`Database.watch_ad_payload_launch_metrics(limit=5)`
(app/storage/repositories/watch_ads.py) — GROUP BY payload_id with a
LEFT JOIN on payloads:

* top payloads by session volume (ordered sessions DESC, payload_id
  ASC; limit bounded 1..20 — the admin panel stays within Telegram's
  message limits);
* per row: the reward funnel (rewarded/pending/expired/rejected), the
  completion rate (3 decimals), last_activity = MAX(created_at);
* the **launch split** — main_sessions (NULL/0 launch context) vs
  network_sessions (`launch_network_bot_id > 0`); computed in SQL so
  `main + network == sessions` holds for every row by construction;
* the payload join (code + display name); sessions with no payloads row
  keep payload_code None — the caller renders the numeric id, never a
  fabricated name.

Failures return [] (observability never breaks the panel); the method
never mutates state. The 📊 Watch Ads Status panel renders it as the 📦
Top payloads section — e.g. `• v26_watchme: 3 sessions · 2 rewarded
(67%) · main 2 · network 1` — absent when there are no sessions.

### The tests (section I — the suite grows to 85/85)

I1 empty list · I2 top-N ordering · I3 per-payload funnel counts ·
I4 the launch split (NULL+0 main, >0 network; main+network==sessions
for every row) · I5 rate math (2/3 → 0.667) · I6 last_activity ·
I7 limit honored · I8 the payload join + the orphan label · I9
read-only (identical twice) · I10 the CROSS-ROLLUP RECONCILIATION
(sum of per-payload sessions == watch_ad_launch_metrics total) ·
I11 the panel renders the Top payloads section · I12 no sessions →
no section. Controlled dataset on a fresh scratch DB (two real
payloads + an orphan payload id; one indexed_files row satisfies the
payloads FK — FOREIGN KEY enforcement is ON in this schema).

### The demo + dashboard surface

watchad-demo: a SECOND Watch-Ads payload (`v27_metrics2` — Watch Ads
enabled, own indexed file) with two seeded sessions (one rewarded
MAIN launch with a future unlock window, one expired NETWORK launch),
so the breakdown shows two rows with different funnels and launch
splits; `/demo/metrics` now serves BOTH rollups (`metrics` +
`payloads`).

The verification center's metrics card gained a "by launch context /
per payload" view toggle (radiogroup, violet/emerald) — the per-payload
table renders the funnel micro-bars, a NEW two-segment launch-split
micro-bar (violet main / emerald network, with the `main·network`
counts), and the reconciliation footnote. The status route exposes the
second features[] entry; the suite count 73 → 85 everywhere; the
release timeline gained the V27 · R7 entry.

### Verification classes (round 7)

LIVE (agent-browser through the gateway + curl): /demo/metrics serves
both rollups over real HTTP (fresh boot: launch main 3 · network 2 ·
total 5; payloads v26_watchme 3/2/67%/2·1 and v27_metrics2 2/1/50%/1·1);
the dashboard mint re-stamps the reused pending session and the
per-payload split updates live (2·1 → 1·2); after the full watch-ad
E2E (launch → watch → postback → unlock + REWARD VERIFIED) the
auto-poll shows v26_watchme 3/3/100%; the dashboard suite runner
parses 85/85 (1221ms, 9 sections); zero console errors / failed
requests; no overflow at 320/390/768/1280; axe-core 0 violations with
the per-payload view rendered. AUTOMATED: the suite 85/85; py_compile
clean; lint clean. NOT-LIVE (honest, unchanged): the real Telegram
transport, Monetag zone traffic, the production DB.

## 16. Round 8 — V27.1: the windowed rollups + the feature drill-down

Round-8 work focus: the worklog's time-series suggestion ("a windowed
variant — last 24h/7d — of both rollups; same SQL shape, WHERE
created_at >= cutoff") + the dashboard drill-down suggestion ("the
features[] cards could gain a section-per-check drill-down link") +
styling hardening.

### The production change (additive, read-only, backward-compatible)

Both V27 rollups accept `window_hours`:

* `watch_ad_launch_metrics(window_hours=None)` — when set (clamped to
  >= 1; 0/negative = all-time), the rollup only counts sessions with
  `created_at >= (now − window_hours)` (UTC ISO string comparison —
  the exact convention the postback last-24h filter already uses, so
  the two recency readouts can never disagree);
* `watch_ad_payload_launch_metrics(limit=5, window_hours=None)` — the
  same cutoff on the per-payload breakdown, so the cross-rollup
  reconciliation (`per-payload session sum == launch-context total`)
  holds PER WINDOW;
* `None` is byte-identical to the V27 behavior (no SQL change on the
  default path — verified by the backward-compat check J4).

The 📊 Watch Ads Status panel renders the 📈 **Sessions · windows
(V27.1)** line — `Last 24h: N | Last 7d: M (windowed rollups)` — only
when sessions exist (a fresh deployment's panel is unchanged). The
windows use the production rollups themselves (`window_hours=24/168`),
not a separate query.

### The tests (section J — the suite grows to 96/96)

11 checks on a controlled scratch DB with sessions aged 2h / 30h /
200h / and a clamp case: the empty-DB shape, 24h filtering (2h in;
30h+200h out), 7d filtering (30h in; 200h out), the all-time default
(unchanged — backward compat), the windowed last_activity (MAX within
the window), the `<= 0` clamp, the windowed per-payload breakdown, the
CROSS-WINDOW reconciliation (payload sum == launch total), read-only
(identical twice), the admin panel line render, and the no-session
absence.

### The demo + dashboard surfaces

* watchad-demo: the seed history spans 2h / 30h / 200h ago so the
  windows genuinely differ; `/demo/metrics` now serves three rollups
  (all-time + `windows.h24` + `windows.h168`, each with metrics AND
  payloads — all through the production methods).
* The dashboard metrics card: a three-way window radiogroup
  (all-time / last 7d / last 24h — zinc/teal/amber), a recency strip
  (`all-time 9 · last 7d −1 older 8 · last 24h −1 older 7`) where each
  chip is itself a selector, window-aware tables in BOTH views, and a
  window evidence footnote (the exact SQL cutoff + the seeded ages that
  make them differ + the per-window reconciliation guarantee).
* NEW — the feature drill-down: every features[] card now carries TWO
  links. "See it live — …" dispatches `v26:focus-metrics` (the card
  focuses that view/window and glows violet for 1.6s; the anchor
  handles navigation) with per-feature accents (F1 violet, F2 emerald,
  F3 amber). "Suite H/I/J — N checks" scrolls to the suite explorer and
  expands EXACTLY that section (the accordion is now controlled state).
* Fixed live: the share bar renders the ACTIVE window's numbers (it
  previously showed all-time totals alongside windowed tables) and
  carries a window badge; the window footnote has an honesty guard
  (only renders when the windowed rollup actually backs the tables).

### Verification classes

* LIVE (real HTTP through the gateway): `/demo/metrics` windows differ
  on the seeded ages (all 9 / 7d 8 / 24h 7 at verification time); the
  full Watch Ad E2E after the reseed — launch (network-stamped session
  9) → in-iframe Watch Ad (AD_START/AD_FINISH waiting_for=s2s_postback)
  → the S2S postback → "Your payload is unlocked!" + 5/5 stepper → the
  metrics live-update (network 24h row 3→4 sessions, 1→2 rewarded); the
  drill-down links (F3 live → the card switches to launch+24h with the
  share bar showing the window total; F3 suite → section J expands with
  11 checks listed; F2 live → per-payload view preserved the window).
* AUTOMATED: the suite 96/96 (section J); py_compile clean; lint clean
  (the vendored public/axe.min.js excluded via `public/**` in the
  eslint ignores — it had flooded 522 lint problems).
* ACCESSIBILITY: axe-core 4.11.1 (the newer engine — computes blended
  translucent backgrounds) found 25 definitive color-contrast nodes
  (zinc-500 small text at ~4.3:1) in the metrics card → swept to
  zinc-400 (~7.6:1) → **0 violations** in static AND dynamic states
  (window selected, payload view, accordion open). Widths clean at
  320/390/768/1280; zero failed requests.
* NOT-LIVE (honest, unchanged): the real Telegram transport, Monetag
  zone traffic, the production DB.

## 17. Round 9 — V27.2: the hourly trend (buckets + direction) + the fixes drill-down

### The production change

`Database.watch_ad_session_trend(window_hours=24)` — the worklog's own
deferred suggestion ("per-window TREND arrows … needs a bucketed GROUP
BY hour"). One new read-only repo method in
`app/storage/repositories/watch_ads.py`:

* **Hour buckets**: `GROUP BY substr(created_at, 1, 13)` over the
  sessions created at/after the first generated hour key — the last N
  hour-aligned calendar buckets ending at the current hour
  (`floor(now)-(N-1)h .. floor(now)`), zero-filled, OLDEST first. Each
  bucket carries `sessions`, `rewarded`, `main_sessions` (NULL/0 launch
  context) and `network_sessions` (`launch_network_bot_id > 0`).
* **The window comparison**: `current` = the exact sum of the N
  buckets (reconciliation by construction — the window is hour-aligned
  on purpose, NOT the minute-precise V27.1 cutoff, so bucket sums can
  never drift from the window total), `previous` = the N hours before
  the window, plus `delta`, `trend` and the rewarded variants.
* **The peak**: the busiest bucket, ties resolved to the LATEST hour
  (the operationally relevant one), `None` when there are no sessions —
  never fabricated. `max_bucket_sessions = max(1, …)` for chart scale.
* **Clamps**: `<= 0` → 24 (a zero-hour "trend" is meaningless —
  documented, deliberate, unlike the V27.1 all-time clamp); upper bound
  168 (a week of buckets). Failures return the zeroed structure —
  observability must never break the panel.

The 📊 Watch Ads Status panel (`watch_ads_status_panel`) renders the
📈 **Hourly trend (V27.2 · 24h buckets)** line — `This 24h: N ·
previous 24h: M ▲ up · rewarded K · peak P @ HH:00` — guarded to
disappear entirely on a session-less DB (the fresh-deployment panel
stays exactly as long as before, the same empty guarantee as H/I/J).

### The tests (section K — the suite grows to 108/108)

12 checks on a controlled scratch DB with fully relative timestamps
(1h / 2h / 2h / 26h / 50h ago — deterministic hour buckets regardless
of the minute the suite runs): the zeroed structure; the contiguous
24-key skeleton ending at the current hour; aggregation into the right
bucket (two rows share one); rewarded per bucket; the main/network
split (main + network == sessions for every bucket); current=3 vs
previous=1 with trend up + the rewarded variants; the 50h-ago row
counted nowhere; peak + chart scale; the clamps (0→24, 500→168, N=3
honored); read-only (identical twice, no writes); the panel line
("This 24h: 3", "previous 24h: 1 ▲ up", "peak 2 @ HH:00"); the
no-session absence.

### The demo + dashboard surfaces

* **watchad-demo**: a 5h-ago network-bot rewarded session joins the
  seed history (the hourly chart now shows three active hours);
  `/demo/metrics` serves `trend.h24` + `trend.h168` — the exact
  production method over the demo DB (fresh boot live-verified: this
  24h 7 · previous 1 · up · peak 5 @ the boot hour; 7d 8 vs 1).
* **The dashboard metrics card**: the hourly chart — 24 slim stacked
  bars (violet main / emerald network), the peak bucket ringed amber,
  a wall-clock hour axis (multiples of 6 + "now"), per-bar title
  tooltips with the full bucket numbers, an sr-only summary, and the
  direction line ("this 24h: 7 · previous: 1 ▲ +6 · peak 5 @ 02:00").
  Trend arrows on the recency-strip window chips (▲/▼/▶ + delta +
  "prev Nh: M", mirrored in the aria-labels). The chart renders for
  the 24h window (its native resolution) and live-updates as the demo
  is driven (verified: 5 → 6 rewarded after a dashboard E2E reward).
* **The fixes drill-down** (the worklog's remaining suggestion): every
  fix card now carries "Suite X — N checks" links (fix 1 → A+B; fixes
  2/3 → C; fix 4 → D; fix 5 → E) that expand the exact accordion
  section AND glow the QA explorer card violet for 1.6s (the same
  focus contract as the metrics card); fixes 1 and 4 additionally
  carry "Drive it — …" anchors into their live demos. The V27.2
  feature card joins the existing feature drill-down (See it live →
  the metrics card focuses the 24h window + glows; Suite K → 12
  checks).

### Verification classes

* DEFINITE (live): `/demo/metrics` trend over HTTP (both windows, the
  seeded ages); the dashboard hourly chart + arrows + live updates;
  the drill-down links E2E (accordion expands exactly the section; the
  QA card glows; the metrics card focuses + glows + switches view and
  window); the full Watch Ad E2E (launch → ad → S2S postback → unlock
  + REWARD VERIFIED) re-run after the changes; axe-core 4.11.1 with
  ALL demo states rendered: **0 violations** (10 pre-existing
  contrast bugs found and fixed this round — inactive TabsTriggers
  inheriting the light-theme near-black `text-foreground` on the dark
  surface, plus the endpoint rows / log footnote); widths clean at
  320/390/768/1280; zero console errors / failed requests; lint clean.
* AUTOMATED: the suite 108/108 (section K); py_compile clean.
* NOT-LIVE (honest, unchanged): the real Telegram transport, Monetag
  zone traffic, the production DB rows.

## 18. Round 10 — V27.3: the day-bucketed trend + the persisted prefs

### The production change

`watch_ad_session_trend(window_hours=24, bucket="hour")` — the worklog's
deferred suggestion ("a window picker for 7d — day-bucketed, GROUP BY
substr(created_at,1,10), same SQL shape"). The `bucket` parameter:

* **`bucket="day"`**: `days = max(1, window_hours // 24)` (the 168h cap
  ⇒ at most 7 — one week), day keys `YYYY-MM-DD` (today-(days-1) ..
  today), zero-filled, OLDEST first; `substr(created_at, 1, 10)` for
  both the bucket GROUP BY and the previous-window filter; `previous` =
  the same number of calendar days immediately before the window.
* **Every V27.2 guarantee kept**: `current == sum(buckets)` exactly
  (day-aligned by construction — documented as deliberately distinct
  from the V27.1 minute-precise cutoff AND from the hour-aligned 24h
  mode), the main/network split per bucket, the peak (latest day on
  ties, never fabricated), the honest `max_bucket_sessions` scale,
  read-only, failures return the zeroed structure.
* **Compatibility**: the output gains a `bucket` field ("hour"|"day");
  the bucket key still rides `hour_start` (structure compatibility —
  documented). An unknown bucket value falls back to hour mode, never
  an error. Hour mode is byte-identical — all 12 K checks pass
  unchanged against the extended method.

The 📊 Watch Ads Status panel renders the 7d line directly under the
hourly one (`This 7d: N · previous 7d: M ▲ up · rewarded K · peak P @
MM-DD  (V27.3 · day buckets)`), guarded to vanish on a session-less DB
(the fresh-deployment empty guarantee).

### The tests (section L — the suite grows to 121/121)

13 checks on a controlled scratch DB with fully relative timestamps
(2h ×2 / 30h / 192h / 384h ago — the expected day keys derived from the
row timestamps themselves, so midnight straddles stay deterministic):
the zeroed day-mode structure; the contiguous 7-day skeleton ending
today; same-day aggregation (the two 2h-ago rows share one bucket);
current=3 vs previous=1 + trends + the 16d row counted nowhere;
reconciliation (current == sum); the launch split; the peak + scale;
hour-mode default stability; the unknown-bucket fallback; the days
derivation (24h→1d, 48h→2d, 500h→cap 168→7d); read-only; the panel 7d
line ("This 7d: 3", "previous 7d: 1 ▲ up", "peak 2 @ MM-DD"); the
no-session absence.

### The demo + dashboard surfaces

* **watchad-demo**: `/demo/metrics` serves `trend.h168d` (the exact
  production method in day mode); the boot log prints the V27.3
  baseline (live-verified: this 7d 8 · prev 1 · up · peak 6 @ the boot
  day; three active days on the seeded history — all reconciling).
* **The dashboard metrics card**: the chart is now MODE-AWARE — hour
  buckets for the 24h window (V27.2), DAY buckets for the 7d window
  (V27.3: 7 weekday-labelled bars — "Thu, Fri, Sat, Sun, Mon, Tue,
  Wed·today" — a V27.3 · day badge, per-bar day titles, an sr-only
  daily summary); a chart LEGEND row (main / network / peak / rewarded)
  with the **rewarded-overlay toggle** — amber dashed watermarks at the
  rewarded height INSIDE each bar (a level marker, never a second bar:
  rewarded ⊂ sessions — no double counting), the last/peak buckets at
  full opacity, others at 70% + full on hover. The view / window /
  overlay preferences **persist across reloads** (guarded localStorage
  — corrupt values fall back, private-mode storage never errors).
* **BUG FIXED this round** (found while testing the drill-down): the QA
  explorer's section list came from the persisted last-run cache (the
  test-run route's memory) — a stale cache could HIDE a newly shipped
  suite section (section L was missing from the accordion until a
  re-run). The list is now the manifest-anchored merge: the status
  route's suite.sections define WHICH sections exist; the live run's
  parsed per-check detail is merged in by section id.

### Verification classes

* DEFINITE (live): `/demo/metrics` trend.h168d over HTTP (7 day
  buckets, three active on the seeded ages, current-vs-previous
  reconciling); the dashboard day chart (weekday axis, V27.3 badge,
  HTTP-matching numbers); the overlay toggle (3 dashed watermarks on
  the 3 rewarded days) + its persistence; the prefs persistence across
  reload (7d + overlay restored from localStorage, verified live); the
  V27.3 feature-card drill-down (live link → the metrics card focuses
  the 7d window + glows + the day chart renders; Suite L link → exactly
  section L expands + the QA card glows); the full Watch Ad E2E (unlock
  + REWARD VERIFIED) and the age-gate E2E (FIRST CLICK — CONFIRMED)
  re-run after all changes; the dashboard suite runner 121/121; axe-core
  4.11.1 with the day chart + overlay + both demos + the open accordion
  rendered: 0 violations; widths clean at 320/390/768/1280; zero
  console errors / failed requests; lint clean.
* AUTOMATED: the suite 121/121 (section L); py_compile clean.
* NOT-LIVE (honest, unchanged): the real Telegram transport, Monetag
  zone traffic, the production DB rows.
