# Production Bug-Fix & Security & Website & Cloudflare & Monetag — Final Report (v35)

Target: the v34 `payload-bot_filedelivery_final.zip` + the live production
log (`bot-5.log`, 2026-09-14) + the provider-supplied Monetag Website
`sw.js` (156 bytes, domain `3nbf4.com`, zone `11800971`).

This report follows the master task's §52 format. Every automated claim
below was executed in this build; every NOT-executed item is listed in
§10 with its reason.

---

## 1. Issue → Root Cause → Fix → Test table

| Issue | Root Cause | Fix | Automated Test | Live Tested | Status |
|---|---|---|---|---|---|
| `panel:control` crash `_svc_make_control_ui` not defined | compat facade not manifest-owned/reachable on the runtime namespace | manifest owns all 11 `_svc_*` factories; rebinding contract pinned | test_callback_integrity_v35 A2/A4/B0-B9 (40/0) | loopback real-namespace render | FIXED |
| `dg:main` crash `_svc_make_delivery_ui` not defined | same facade gap | same manifest fix | test_callback_integrity_v35 A2/B1 | loopback real-namespace render | FIXED |
| `ncreate:start` crash (same class) | same facade gap | same manifest fix | test_callback_integrity_v35 A2/B2 | loopback real-namespace render | FIXED |
| Every other button/callback integrity | no exhaustive audit existed | 345/345 static literals dispatched, 39/39 worker-guard prefixes, 543/543 section names | test_callback_integrity_v35 (40/0) | — | VERIFIED |
| `fj:list` at-render crash `valid_flags` NameError | pre-PHASE-8 leftover dict deleted long ago | per-button health prefix derived from live `health_states` | test_callback_integrity_v35 B9+E1 (mutation-proven) | — | FIXED |
| 4.3 MB file → `STREAM_AUTH_OK` → getFile HTTP 400 → `STREAM_HTTP_ABORT` → "Stream ended or expired" | (1) unrecognized deterministic getFile 400 never classified as stale → repair pipeline never ran; (2) post-repair failure surfaced as truncated 206 | getfile-phase 400 → `FileIdInvalidError(probable=True)` → repair runs; web layer pulls the FIRST upstream chunk BEFORE `prepare()` → honest JSON errors | test_media_v35 B/C/D (81/0: real-HTTP 4/5/10/19 MB matrix, stale-id repaired + unrecoverable) | loopback fake api.telegram.org cloud transport | FIXED |
| Every player error lied "Stream ended or expired" | one-size frontend error mapping | truthful machine-readable state machine (probe + 13 states + Retry Stream + Telegram fallback) | test_media_v35 E (81/0) | browser (see §8) | FIXED |
| `MEDIA_CACHE_FILL_ABORT … partial prefix kept` | cache-fill raced the honest-error contract | JSON error plans marked; cache prefix fallback retained | test_media_v35 D | — | FIXED |
| "Website ads do not show" | the libtl.com tag is the TMA Watch-Ads SDK, NOT a Website ad tag; the Website ad tag was never supplied by the provider | TMA SDK confined to `GET /watch-ad/{token}` (structurally + live-asserted); Website ad-tag integration point implemented + validated (`website_monetag_ad_tag` / `WEBSITE_MONETAG_AD_TAG`); NO tag fabricated | test_website_monetag_v35 (60/0) | browser: `/api/website/monetag-status` shows `configured:false` | INTEGRATED — provider tag still to be supplied |
| Supplied `sw.js` unreachable in production (404 at worker domain root) | aiohttp app served nothing at `/`; the worker allowlist didn't include it either | origin serves `/sw.js` verbatim at the domain root; hardened `cloudflare/worker.js` allowlists it | test_website_monetag_v35 + node --check worker | local: HTTP 200, 156 exact bytes | FIXED (deploy steps §7) |
| Cloudflare worker: `redirect:"manual"` + streaming semantics unverified; header gaps | audit found pass-through was mostly sound; missing hardening | streaming preserved, manual redirects kept, `Permissions-Policy`, nosniff, Referrer-Policy added; CSP left comment-only (provider scripts not yet final); optional `X-Origin-Key` origin lockdown | test_website_monetag_v35 source pins + node --check | — | HARDENED |
| Watch-Ad dead-end (`watch_ad_required` but no ad) | frontend dead-ends were untruthful states, not ad-logic bypasses | truthful state machine; ad gate preserved; no bypass | test_media_v35 E + test_watch_ads v1-v7 (790 checks) | — | VERIFIED |
| Force Join health: 7 channels / 0 healthy / 7 invalid | PRODUCTION CONFIG (channel IDs/deleted channels), not code | honest `Force Join: DEGRADED — X/Y channels healthy` on the Website + admin diagnostics | test_website_security_v35 3.x/4.x (55/0) | browser (gate shows degraded banner) | CODE CORRECT — config requires operator action (§9) |
| `safe_edit_text: markdown parse failed … byte offset 177` | raw `` `{value}` `` MARKDOWN spans with admin-typed backticked codes | `md_code_span`/`escape_md` at EVERY dynamic interpolation site (retrieve analytics/settings, text_input, admin_commands, watchads, wizard, search, stats_panels, callbacks, start, access_panels, files_panels, help/dashboard editors) | test_callback_integrity_v35 F0-F5 (mutation-proven) | — | FIXED |
| Website `?user_id=`/`?username=` trust (IDOR) | audited: identity only from HMAC-validated initData / AEAD session cookie — 3 real holes fixed (ads decision session_key trust; pack token cross-user leak; FJ exception → joined=true) | server-side session-derived identity everywhere; generic 403/404 | test_website_security_v35 (55/0: 12 IDOR vectors + verify matrix) | — | FIXED |
| Force Join exception reported `joined=true` | needs_gate flag discarded on exception | `joined:false` + `verification:"unavailable"` + retry hint | test_website_security_v35 2.x | browser ("Could not verify"/retry state machine) | FIXED |
| Control Panel unreachable with network platform OFF | `init_network_services` early-returned before constructing `ns._fdb` | services constructed BEFORE the `network_enabled` check; failures isolated | test_architecture_decoupling J1/J1b/J1c (53/0) | — | FIXED |
| Global Link mint refused (no signing key) | correct fail-closed §29 design | startup diagnostic + Credentials panel booleans + creation path | test_network (82/0) §J | — | BY DESIGN — operator must set `NETWORK_GLOBAL_LINK_SIGNING_KEY` |
| Network token encryption missing | correct fail-closed §30 design | same diagnostics + registrations refused | test_network_security (34/0) | — | BY DESIGN — operator must set `NETWORK_TOKEN_ENCRYPTION_KEY` |
| File Delivery Bot unconfigured | correct §31 NOT_CONFIGURED state | honest NOT_CONFIGURED reporting; runtime add/rotate via Control Bot | test_file_delivery B (75/0) | — | BY DESIGN — operator supplies FDB token |
| Control Bot optional dependency | main-bot Control Panel must not depend on `CONTROL_BOT_TOKEN` | control panel in main bot's admin area; dedicated control bot optional | test_callback_integrity_v35 B0 | — | VERIFIED |
| +5 reward timing/idempotency | (regression risk from v34 retime) | awarded ONLY at DELIVERY_READY, idempotent key + legacy guard | test_file_delivery H (75/0) | — | VERIFIED |
| Storage master deletion risk | (audit item) | relay messages only; master never deleted | test_file_delivery A/E + network evidence | — | VERIFIED |
| Website audio option (must stay removed) | (audit item) | removed; no UI anywhere (browser-verified; only CSS design comments mention audio) | test_website_gapclosure (66/0) | browser | VERIFIED |
| Dark/Normal mode | v34 implementation + v35 polish | system→dark→light cycle, `eutheme` persistence, no-flash head script, ARIA-pressed | test_website_gapclosure | browser (§8) | VERIFIED |
| Dead `_NET_USER_CALLBACK_PREFIXES` entries | stale `recentsearch:`/`plsclear:` prefixes | exact-match entries corrected; guard semantics modeled | test_callback_integrity_v35 C4 | — | FIXED |

## 2. Files changed (v34 → v35)

**Modified (26):** `app/media/errors.py`, `app/media/gateway.py`,
`app/media/sources/_base.py`, `app/network/lifecycle.py`,
`app/presentation/telegram/{_manifest,admin_commands,admin_panels,callbacks,
control_ui,forcejoin,retrieve,search,start,state,stats_panels,text_input,
watchads,wizard}.py`, `app/services/container.py`, `app/web/routes.py`,
`app/web/server.py`, `app/web/site/{html,pages,screens,stream}.py`,
`test_architecture_decoupling.py`.

**New (9):** `app/web/website_monetag.py`, `app/web/static/sw.js`
(provider bytes verbatim), `cloudflare/worker.js`, `cloudflare/wrangler.toml`,
`.env.example`, `docs/MONETAG_WEBSITE.md`,
`test_media_v35.py`, `test_website_security_v35.py`,
`test_website_monetag_v35.py`, `test_callback_integrity_v35.py`.

## 3. Migrations added/changed

**None.** Schema stays `SCHEMA_VERSION=34`. Fresh-DB creation and
v33→v34 upgrade are re-verified in this build (test_file_delivery A,
test_website_monetag_v35 schema pins). No production data touched.

## 4. Environment variables

See `.env.example` (complete annotated list). Summary:
REQUIRED: `BOT_TOKEN`, `ADMIN_IDS`, `DATABASE_FILE`.
OPTIONAL: `FILE_DELIVERY_BOT_TOKEN`, `CONTROL_BOT_TOKEN`,
`NETWORK_TOKEN_ENCRYPTION_KEY`, `NETWORK_GLOBAL_LINK_SIGNING_KEY`,
`WEBSITE_MONETAG_AD_TAG`, `TELEGRAM_API_MODE`, `TELEGRAM_LOCAL_API_URL`,
`MINI_APP_*`, `ORIGIN_PROXY_SECRET` (worker↔origin shared secret).
NOT CONFIGURED (honest, fail-closed): network encryption key, global-link
signing key, FDB token, Website Monetag ad tag — each clearly diagnosed
in admin UI + startup logs; none fabricates a default.

## 5. Website deployment requirements

1. Deploy this repo's `app/` + restart the aiohttp process (origin then
   serves `/sw.js` and `/api/website/monetag-status`).
2. `cd cloudflare && npx wrangler deploy` (verify account first:
   `npx wrangler whoami`) — the hardened worker replaces the current one.
3. Verify live: `curl -sS -D - https://<worker-domain>/sw.js` → 200,
   `application/javascript`, exactly 156 bytes matching the upload.
4. Obtain the Monetag WEBSITE ad-zone tag from the provider account and
   set `WEBSITE_MONETAG_AD_TAG` (or DB `website_monetag_ad_tag`); confirm
   via `/api/website/monetag-status` → `configured:true`.
5. Optional hardening: `npx wrangler secret put ORIGIN_PROXY_SECRET`,
   set the same on the origin env, restart; then firewall the origin port
   to Cloudflare IP ranges (direct-origin access now 403s without the key).

## 6. Cloudflare changes

`cloudflare/worker.js` (hardened): path allowlist (+ `/sw.js`,
`/api/website/monetag-status`), encoded-path/traversal/double-slash
rejection, streaming bodies + `redirect:"manual"` preserved for Range
semantics, `X-Content-Type-Options`/`Referrer-Policy`/
`Permissions-Policy` added, CSP left as a comment-only template (final
CSP must allow the provider's Website ad origins once the tag exists —
not weakened speculatively), optional `X-Origin-Key` origin lockdown.

## 7. Monetag configuration required

* **TMA (Watch Ads):** already correct — the libtl.com tag
  (`data-zone='11742509'`) is the Mini App SDK; it renders on
  `GET /watch-ad/{token}` ONLY (live-asserted; never on `/site`).
* **Website:** `sw.js` (zone `11800971`) served verbatim at the domain
  root. **The Website ad-zone HTML/JS tag was NOT supplied by the
  provider and was NOT fabricated** — set `WEBSITE_MONETAG_AD_TAG` once
  obtained; the validated injection point renders it into every
  `/site` `<head>`.

## 8. Browser QA executed (agent-browser, real server, schema v34)

Zero console/page errors across the whole session:
EndieFans boot → login (ID confirmation) → Force-Join gate (unjoined
channel + Join + Verify Membership; honest "Still missing 1 channel"
state; mid-session join flip → Verify lifts the gate and reloads to the
feed) → feed/categories/search → payload page → video page: `readyState=4`,
duration 30 s, 640 px, REAL playback with time advancing, seek to 15 s
works, **"Get File in Telegram" below the player** (§16), mute control
present and correctly disabled per the §8 contract; theme cycle
system→dark→light→system with `localStorage('eutheme')` persistence across
reload and correct body backgrounds; settings page has Theme controls and
NO audio option (only CSS design comments mention audio); plain-browser
video page shows the honest deny ("Open it from the bot to continue");
mobile 390×844: no horizontal overflow; `/sw.js` 200 with exact provider
bytes; `/api/website/monetag-status` honest JSON (`configured:false`);
no `libtl.com` resource anywhere on `/site`.

## 9. Tests actually run (this build, exact counts)

25 legacy suites: file_delivery 75/0 · network 82/0 · network_security
34/0 · architecture 96/0 · architecture_decoupling 53/0 ·
admin_panels_gapclosure 43/0 · botv13_phase8 77/0 · media_phase1 88/0 ·
media_phase2 77/0 · media_phase3 200/0 · media_phase3_ux 70/0 ·
media_phase4 204/0 · media_phase5 95/0 · media_transport_auto 74/0 ·
watch_ads 91/0 · v2 142/0 · v3 104/0 · v4 153/0 · v5 142/0 · v6 113/0 ·
v7 85/0 · website_gapclosure 66/0 · botv13_phase6 124/0 ·
botv13_phase7 151/0 · botv13_phase7_hotfix 94/0.

4 new v35 suites: media_v35 81/0 · website_security_v35 55/0 ·
website_monetag_v35 60/0 · callback_integrity_v35 40/0.

Evidence runners: run_phase8_evidence ALL PASS · run_network_evidence ALL
PASS. Static scans clean (§39: no tokens/keys in source, no QA stub
literal in product HTML, no audio remnants, no `_bot_storage_ok`
residue, no TODO placeholders). `python -m compileall` CLEAN;
`node --check cloudflare/worker.js` OK.

**Total: 2,769 checks / 0 failed.**

## 10. Live tests NOT possible in this environment (honest list)

* Real Telegram infrastructure: relay copyMessage between real bots,
  real Delivery Group promotion/verification, real bot token validation,
  Managed-bot creation via the official mechanism.
* Real-device Telegram clients (Android/desktop): Main Mini App,
  Watch-Ads Mini App (verified in-browser via the WebApp stub + honest
  plain-browser deny instead).
* The LIVE production website (`shy-leaf-cac1.kyahuyaphirse.workers.dev`):
  source-side changes are complete; **the worker redeploy + origin
  restart in §5 are deployment steps only the operator can perform**
  (no Cloudflare credentials exist in this environment — by policy none
  were requested or stored). Until then the live site runs the OLD code.
* Monetag Website ad serving: blocked on the provider-supplied Website
  ad tag (§7). No-fill vs code failure cannot be distinguished until a
  real tag runs.
* 2-3 GB transfers (>20 MiB Bot API limit): loopback-verified policy
  verdicts only.
* Origin exposure/firewalling (§26): recommendations in §5; not
  executable here.

## 11. Remaining blockers / operator actions

1. Deploy origin + worker (§5 steps 1-3) — everything else on the
   live path depends on this.
2. Supply the Monetag Website ad tag (§7).
3. Fix the 7 force-join channels in production config (deleted/wrong
   IDs) — the code now reports DEGRADED honestly either way.
4. Set the dedicated secrets (`NETWORK_TOKEN_ENCRYPTION_KEY`,
   `NETWORK_GLOBAL_LINK_SIGNING_KEY`, optional
   `FILE_DELIVERY_BOT_TOKEN`/`CONTROL_BOT_TOKEN` per architecture).

## 12. Final artifact

`payload-bot_prodbugfix_final.zip` — see the packaging section of
`TEST_REPORT.md` for the file count, `unzip -t` result, fresh-extraction
smoke results, and the SHA-256.
