# FINAL CODE AUDIT — BOT-13 continuation (second full pass, §45/§63)

**Scope:** every Python module, the DB schema/migrations, Telegram
handlers/callbacks, web routes/templates/JS/CSS, service/worker
lifecycle, delivery/retry workers, Global Link code, Force Join code,
Network Bot registry, token lifecycle, Mini App code, video/player/ads
code, Watch Ads code, 18+ code, Cloudflare worker, configuration,
environment handling, logging, error handling, tests, docs — the
COMPLETE tree as shipped in this release, not only files changed this
pass.

**Method:** §45.1 known-pattern sweep (from_message_id,
InlineKeyboardButton, network_bot_id=0, current_context, MAIN_BOT,
can_manage_bots, DELIVERY_READY, GLOBAL_LINK, Get File, redirect,
PRE_ROLL, WATCH_AD, adult, age, token, safe_edit_text, copy_message,
send_video, send_document, send_photo, callback_data) + §45.2
architectural-duplication check + §45.3 state-machine audit via the
existing regression battery + fresh §45.4 gap report (this document).

---

## Findings

### F1 — Dropped regression coverage from the B11 TEST archive
* **Severity:** HIGH (coverage gap; no runtime defect)
* **Affected files:** tests/ (three suites absent from the working tree)
* **Runtime impact:** none in production — but the B11 battery's 47-suite
  guarantee had silently degraded to 32 suites when the upload set
  carried only the PRODUCTION zip (runtime-only, 200 files, no tests).
  Missing: website monetag (sw.js/TMA separation/ad-tag/origin secret),
  the 18+ age-gate chain, markdown entity balance.
* **Current status:** FIXED
* **Fix applied:** three suites recreated against the CURRENT code
  surfaces (not blindly restored): `tests/test_website_monetag_v35.py`
  (40 checks), `tests/test_b10_agegate.py` (34 checks),
  `tests/test_b10_markdown_balance.py` (37 checks) — all green.
* **Test coverage:** the suites themselves + the full battery re-run.
* **Remaining external dependency:** none.

### F2 — Browser-QA driver defects (never-run code)
* **Severity:** MEDIUM (QA infrastructure; no production defect)
* **Affected files:** tests/qa_bot13_browser_server.py
* **Runtime impact:** the B13 browser QA driver could not start
  (await on a bound method; a route added to a frozen router; a wrong
  codec import name; the fake gateway returned `bytes` where the real
  StreamPlan contract requires an async iterator — the site answered
  STREAM_PREFLIGHT_FAIL for every media request).
* **Current status:** FIXED
* **Fix applied:** seed() fixed; the ad media + QA stub SDK moved to a
  second :8081 aiohttp server; `make_site_session_codec().issue_session`
  used; the gateway now returns an async-generator body.
* **Test coverage:** browser_qa.py — 39/39 checks green.
* **Remaining external dependency:** none.

### F3 — QA determinism: the official Telegram SDK race
* **Severity:** INFO (QA technique; production unaffected)
* **Affected files:** tests/qa_bot13_browser_server.py (QA-only)
* **Runtime impact:** in a plain browser the synchronous
  telegram-web-app.js in every site <head> resolves with EMPTY initData
  and the player correctly denies auth ("Open in Telegram"). A post-load
  stub injection races it nondeterministically.
* **Current status:** FIXED (QA-side)
* **Fix applied:** the QA server rewrites the SDK tag in its OWN HTML to
  a stub served at :8081 whose initData is freshly HMAC-signed per
  request — deterministic, production HTML untouched.
* **Test coverage:** browser_qa.py auth lifecycle (all 39 checks).
* **Remaining external dependency:** none.

### F4 — cloudflare/ absent from the working tree
* **Severity:** MEDIUM (release completeness)
* **Affected files:** cloudflare/worker.js, cloudflare/wrangler.toml
* **Runtime impact:** the B11 TEST archive carried the worker; the
  upload set (PRODUCTION zip only) did not, so §29's TEST zip would have
  been incomplete.
* **Current status:** FIXED
* **Fix applied:** worker.js + wrangler.toml rebuilt EXACTLY to the
  hardening spec in docs/MONETAG_WEBSITE.md §4 (allowlist + /sw.js,
  path-safety-before-allowlist, verbatim media streaming, security
  headers, no HSTS on *.workers.dev, ORIGIN_PROXY_SECRET injection).
  `node --check` clean.
* **Test coverage:** tests/test_website_monetag_v35.py check 7a.
* **Remaining external dependency:** live Cloudflare deploy (operator
  credentials — ENVIRONMENT BLOCKED).

### F5 — Historical production defects: verified fixed + regression-locked
* **Severity:** (was CRITICAL/HIGH — now closed)
* `from_message_id` keyword: ZERO invalid occurrences remain. The four
  matches are attribute READS of the real PTB
  `forward_from_message_id` field (messaging.py) and one documentation
  comment. Locked by tests/test_bot12_delivery_ptb_signature.py (17
  checks incl. the exact-TypeError reproduction).
* `copy_message(` calls: all seven production call sites use the valid
  positional or `message_id=` form (broadcast, network_ui ×2, mediaops,
  delivery, indexing, file_delivery).
* Managed-bot capability: persisted value is a TTL cache — never a
  permanent False; refresh-before-refuse, Refresh button, refresh on
  restart/token-change/registration (bot13_capability_refresh, 19 checks).
* `network_bot_id=0`: every occurrence is intentional main-bot semantics
  (Mini App apply-to-main, legacy link compatibility, comments).
* DELIVERY_READY: derived from the full 8-step chain (member/storage/
  FDB/capability), never from getChat alone (bot11 suites).
* Keyboard type errors: repo-wide `validate_keyboard_markup` defensive
  layer + honest re-raise semantics (bot11_keyboard_types, 23 checks;
  markdown balance suite §6).
* Global Link targeting: persisted target + mode; removed bots never
  resurrect (bot11_global_links, 7 checks).
* Force Join: main-bot verifier swap + fresh server-side Check Again +
  honest error semantics (bot11_force_join_main_verifier, 26 checks).

### F6 — Architectural duplication check (§45.2)
* **Severity:** INFO — NONE found.
* ONE implementation each: Force Join verification (`_fj_verifier_bot`
  + the core service), Global Link signing (GlobalPayloadLinks),
  target resolution (routing.mint_targeted_link), Network Bot registry
  (repositories/network.py), credential storage (network/credentials),
  delivery routing (NetworkRouter), file delivery
  (network/file_delivery.py), Mini App canonical URL
  (network/bot_miniapp.py), Website Get File
  (pages.handle_site_api_get_file + routing.select_random_delivery_bot —
  the router method is a thin delegate), website video-ad state
  (web/site/video_ads.py), Watch Ads rewards (core/watch_ads), 18+
  authorization (`_listing_age_restricted` — one shared predicate).

### F7 — Provider independence (§49/§51)
* **Severity:** INFO — verified.
* The player understands PRE_ROLL + the `vast|direct|none` provider
  decision. "HilltopAds" appears ONLY in docstrings as an example. No
  provider URL is fabricated: unconfigured ⇒ "Video Ads: Not
  Configured" and content plays. VAST capability claims match the real
  implementation (Inline + skipoffset + duration + beacons; Wrapper NOT
  supported — honest no-fill; VMAP partial, documented in
  MONETAG_WEBSITE.md §7).

### F8 — Watch Ads / website-ad reward separation (§52)
* **Severity:** INFO — verified.
* app/web/site/video_ads.py has ZERO watch_ad references; the pre-roll
  decision path never creates watch-ad sessions/rewards (bot13 suite
  part F pins this).

### F9 — Live-boundary items (§31/§64 — ENVIRONMENT BLOCKED, honestly)
* **Live Telegram delivery** (managed-bot creation, real t.me clicks,
  real /setup in a group, setChatMenuButton): no live token in this
  sandbox. All code below the PTB boundary ran for real in the suites
  (delivery e2e 26 checks; PTB signature 17). **LIVE TELEGRAM:
  BLOCKED.**
* **Live VAST/HilltopAds inventory:** none supplied, none fabricated.
  The direct provider + the VAST client adapter logic are
  suite-verified; the browser QA exercised the real client machine
  against locally served ad bytes. **LIVE AD INVENTORY: BLOCKED.**
* **Cloudflare deployment:** no credentials — worker carried in the
  TEST zip, node --check clean, NOT deployed. **LIVE CLOUDFLARE:
  BLOCKED.**

---

## Summary counts

| Severity | Count | Status |
|---|---|---|
| CRITICAL | 0 open | (historical items closed — F5) |
| HIGH | 0 open | (F1 fixed) |
| MEDIUM | 0 open | (F2, F4 fixed) |
| LOW | 0 open | — |
| INFO | 4 | F3, F6, F7, F8 (verified states, no action) |
| BLOCKED (external) | 3 | F9 (live Telegram / live ads / Cloudflare deploy) |

**Battery:** 35 suites, 2,590 checks, 0 failures.
**Browser QA:** 39/39 (desktop + 390×844 mobile + fail-open paths).
**Compile:** 182 py files + worker.js + sw.js + miniapp_driver.js clean.
**Secret scan:** 217 files scanned, 0 findings (fake placeholders only).
