# WEBSITE PHASE 3 — UX CONTINUATION REPORT

**Baseline:** `payload-bot_website_phase3.zip` (Phase 3 STOP-gate artifact, 197/0)
**Scope of this pass:** presentation-layer polish + additive feed features ONLY.
No Phase 4 work (no Media Gateway, no HTTP Range streaming, no shared stream
cache, no stream-token playback — those remain gated on operator approval).
`bot.py` is **byte-identical** to the Phase 3 ZIP (md5 `9bf0facc58316c2dafdb0d66115689df`).

## What changed (and why)

### 1. Files touched (exactly 3 modified + 1 new)

| File | Change |
|---|---|
| `app/web/site/html.py` | Full presentation rewrite (pure rendering — zero business logic) |
| `app/web/site/pages.py` | Additive `?sort=` wiring (feed/search/detail back-links) |
| `app/storage/repositories/website.py` | Additive optional `order` parameter on `list_website_payloads_paged` |
| `test_media_phase3_ux.py` | NEW additive suite — 70 checks (UX-A … UX-I) |

### 2. Styling overhaul (html.py)

- **Design tokens**: near-black neutral canvas with radial emerald ambience,
  elevated surfaces, hairline borders, two-tier shadows; emerald accent family
  (brand unchanged; no blue/indigo).
- **Deterministic gradient art**: every payload renders hash-stable SVG
  gradient art (8 dark rich palettes) with a centered media-type glyph inside
  an emerald ring + glow — the same payload always looks like itself.
- **Glassmorphism** count badge + media type pill over the art.
- **Header**: sticky glass header, pulsing brand dot, WEBSITE tag, search
  input with embedded magnifier icon + circular arrow submit button.
- **Cards**: hover lift + shadow, press feedback, staggered rise-in animation
  (`--i` index), bolder titles, brighter description tone.
- **Detail page**: hero card, back-link pill (chevron icon), meta pills row
  (count / Part range / **≈ total size**), refined file rows (part badge,
  bold accent media-type label, lighter secondary meta, ghost play button
  that fills on hover/press).
- **Motion + a11y**: `prefers-reduced-motion` disables all animation;
  `:focus-visible` rings; skip-to-content link; `aria-current` on the active
  sort option and page; touch targets ≥ 44px; semantic landmarks.
- **Errors/maintenance**: polished mbox cards with floating glyph animation
  and retry actions.

### 3. Additive features (all within the Phase 3 boundary)

1. **Sort control** — `?sort=curated|newest|title` on the feed and search.
   The repo gains an optional `order` parameter that maps to a **whitelisted**
   SQL fragment table (`_WEBSITE_ORDER_BY`) — user input never reaches SQL
   text; unknown values fall back to the exact pre-UX ordering
   (position ASC, id DESC). Default call sites behave byte-identically.
2. **Clickable tag chips** — every tag chip links into the ONE search system
   (`/site/search?q=<tag>`); no second search engine.
3. **Numbered windowed pagination** — first/last + a ±2 window with
   ellipses, 44px pills, current pill filled; the compact `N / M` position
   indicator is retained on every viewport (pinned wording preserved).
4. **Feed statistics** — "N payloads published" header (from the existing
   COUNT — no extra query).
5. **Media-type pills** — Video / Audio / Photo / Document / Animation /
   Collection classification from existing metadata; suppressed when the
   count badge already carries the type word (single video card).
6. **Total-size + Part-range meta pills** on the detail page (client-side
   sum of the already-fetched file list — no extra query).
7. **Search-state preservation, now END-TO-END** — search cards carry
   `?q=&p=&sort=` so the detail page's back link returns to the exact
   results page (this closes a real spec-§10 gap: the original cards never
   carried the state, leaving "Back to results" dead).
8. **Head/meta** — `theme-color`, per-page `description`, OG title/description
   on detail pages, `noindex` on search/video/error pages (feed/detail stay
   indexable), robots hygiene.
9. **URL escaping normalization** — every dynamic href now passes through
   `esc()` (proper `&amp;` in attributes).

## Verification

### Test battery (all executed from this tree)

| Suite | Result |
|---|---|
| test_media_phase3_ux.py (NEW) | **70 / 0** |
| test_media_phase3.py (original contract — UNMODIFIED) | **197 / 0** |
| test_media_phase2.py | 77 / 0 |
| test_media_phase1.py | 88 / 0 |
| 13 baseline suites | 1,451 / 0 (91+142+104+153+142+113+85+124+151+94+77+79+96) |
| run_phase8_evidence.py | ALL SECTIONS PASS |
| run_network_evidence.py | ALL SECTIONS PASS |
| **TOTAL** | **1,883 / 0** |

The original Phase 3 suite file is untouched — all pinned HTTP contract
strings (`class="card"`, "N files"/"N videos" badge wording, "N / M" pager,
`>P1<` part markers, search input `value=`, "No payloads match",
maintenance page content) still hold.

### Live browser QA (agent-browser, real Chromium)

- Feed/search/detail/video interactions re-verified: sort clicks, numbered
  pagination clicks, tag-chip click → filtered search ("2 results for
  'action'"), card → detail → file row → video verdict (fail-closed
  "Open in Telegram" outside the Mini App), 0 console errors.
- Maintenance toggle via DB: all site routes 503, `/healthz` stays 200.
- VLM design review of before/after screenshots: feed **4/10 → 8.5/10**,
  detail page **9/10**, desktop grid 8/10 (remaining notes are polish-level:
  optical alignment, masonry-style height variance).
- Screenshots: `/home/z/my-project/download/phase3-qa2/` (r2-*, final-*).

## Honest NOT-IMPLEMENTED (unchanged, Phase 4 gated)

- Servable thumbnail bytes (Media Gateway) — art remains deterministic
  placeholder SVG at every thumbnail-priority level.
- Playback transport / HTTP Range / shared stream cache / stream tokens.
- `website_stream_events` deliberately still not created (no real Phase 3
  metric requires it).

## Known limitations

- Sort "A–Z" uses `eff_title COLLATE NOCASE` (presentation titles); ties
  break by id DESC — deterministic.
- Tag chips link to a plain word search; quoted/phrase search is not part
  of the ONE search system's semantics (unchanged).
- Desktop card heights vary with tag counts (strict grid, not masonry).
