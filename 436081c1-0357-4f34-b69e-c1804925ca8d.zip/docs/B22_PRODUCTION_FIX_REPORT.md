# B22 PRODUCTION FIX REPORT — the bot-22.log final pass (B18, in place)

**Release identity:** the CURRENT B18 codebase, repaired in place. No B19,
nothing renamed. Baseline tree hash before this pass (sha256 of the sorted
app+run.py file-hash list):
`c223b704ff8898b9b5a396281e20a77ab0b31ab3b39413f09ac76ffcb6c47126`.

**Evidence baseline:** `/home/z/my-project/upload/bot-22.log` (1,005 lines,
read chronologically, every conclusion below tied to a log line or a
runtime verification in THIS tree).

---

## 1. Issue table (every issue from the directive + everything found)

| ID | Issue | Root Cause | Fix | Test | Runtime Proof | Status |
|----|-------|-----------|-----|------|---------------|--------|
| R1 | Network Bot Mode A fails (`NETWORK_RELAY_CREATE_BAD_REQUEST` "Chat not found" → fallback → `FDB_DIRECT_DELIVERY_SUCCESS`) | **Deployment**: network bot 2 (@helpsupport_dox_bot, `identity_match=True`, verified via its OWN client) is **not a member of the Storage channel** −1004460709020 (`source_reachable=False storage_reachable=False`), while the FDB IS (`fdb_storage_access=full` + its storage→user copyMessage succeeds). Telegram `copyMessage` requires the copying bot to access the source chat — group admin rights are irrelevant for the source hop. | Code already detects/classifies (`STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT`), TTL-caches the negative (300 s, health-pass refresh), falls back honestly (`mode=fdb_direct`, never labeled network delivery). THIS PASS: the first `NETWORK_RELAY_CREATE_BAD_REQUEST` line now carries `probe=pending_evidence` so the pre-probe `GROUP_INACCESSIBLE` classification can never be misread as a final verdict (bot-22 line 63). **Operator action required for Mode A: add @helpsupport_dox_bot to the Storage channel (as admin).** | tests/test_bot18_delivery_honesty.py (53/0) + G1 pin | bot-22.log lines 63–71, 954–962 (the FINAL-1 diagnostics running in production) | FIXED (code) + DEPLOYMENT ACTION documented |
| R2 | Website "Watch an ad to continue" gate duplicated the Telegram payload Watch-Ad requirement inside the player | `STATE_TEXT.WATCH_AD_REQUIRED` in html.py rendered a site-side ad-gate heading on a `watch_ad_required` stream denial (bot-22: user 8922807758 denied 3× while trying to watch) | The state is REMOVED; denials now render `UNLOCK_IN_TELEGRAM` ("Unlock this payload in Telegram") + a "Return to Telegram" CTA; `_REQUIREMENT_TEXT` points to the bot. The website pre-roll (VAST) remains a separate, optional system | E1–E5 source pins + T6 browser | Browser T6/T6b/T6c on the REAL stack (33/33) | FIXED |
| R3 | `WEBSITE_TOGGLE admin=8370454312 website_enabled=False` — why was the site disabled? | The ADMIN disabled it deliberately at 16:15:05 (callback `wsite:toggle`) after the normal user's blocked experience (R2). It is a DB setting (`website_enabled`), persists across restart, and every page/API answers the maintenance screen while OFF. | No defect found in the toggle architecture (verified: `_website_on` fail-closed, maintenance HTML+JSON on every surface, stream issuance refuses while OFF). The R2 fix removes the UX reason the admin turned it off. Re-enable via the panel. | test_bot16_website_fj (79/0) | bot-22 log lines 939–941 + code audit | EXPLAINED (no code defect) |
| R4 | Stale `file_id` (`MEDIA_UPSTREAM_ERROR` "wrong file_id") | Telegram rotated the file_id for `AgADVBoAArduMFQ` (bot-22 16:03:29). The FINAL-1 repair path already handles it transparently. | None needed beyond verification: `DELIVERY_SOURCE_RECOVERY` → `DELIVERY_FILE_ID_REPAIRED` (atomic, 1.5 s, `hide_source_bypassed=True` internal fetch) → single retry → 206 s served. The player never showed an error (the repair happens inside the failing request). | test_bot16_transcode (149/0) | bot-22 log lines 694–700 (the transparent recovery + 206 s) | VERIFIED WORKING |
| R5 | Views / Like / Dislike (new requirement) | n/a (new feature) | Schema v40 (`media_view_events`, `media_reactions`, `website_handoffs`), `MediaStatsRepoMixin`, `app/web/site/engagement.py` (view ping: session identity, video files only, ≥5 s watched / 25 % of short videos, 6 h per-viewer dedupe; reactions: one per user per file, SERVER-authoritative toggle, atomic switch), the player engagement bar + in-place count updates. | tests/test_b22_final_engagement.py (67/0) | Browser T1–T5: bar renders; like→1 in place; repeat removes; switch atomic; view counts at the threshold; RELOAD+seek still 1; Video 2's counters independent of Video 1 | COMPLETE |
| R6 | "Open in browser" for the Mini App (Issue G) | n/a (new feature) | Signed, short-lived (120 s), SINGLE-USE AEAD handoff (`/site/api/ext-link` mint with initData validation → `Telegram.WebApp.openLink`; `/site/ext/{token}` consume → nonce burned in DB → site session cookie → 302 to the bound path). No raw user id in any URL; site-relative target whitelist incl. dot-segment rejection; replay/expiry → the honest Session-expired page. | D1–D8 + path-traversal matrix | Browser T7/T7b/T7c/T8/T8b/T8c: the ↗ control appears in the Mini App context; openLink receives the signed URL; the external browser session works; the REPLAY gets the expired page | COMPLETE |
| R7 | Multi-media payloads show only part of the collection | **Not reproducible on this tree** — the payload page renders the complete ordered file list (MAX_DETAIL_FILES=200 cap + honest "+N more"), the player page carries parts pills + prev/next, and bot-22 shows the user opening Video 1 AND Video 2 of the same payload. Per-file refs are AEAD-bound to (listing, file_pk) — URL tampering fails closed (tests pin this). | Nothing to fix; per-file independence of the NEW engagement counters added (R5) with browser proof | test_bot16_website_fj + b22 C12/C13 + H | bot-22 lines 145/323 (two distinct video refs of one listing opened) | VERIFIED WORKING |
| R8 | Quality menu / persistence (Issue E) | Quality menus were already real (hls.js `levels` / native variants — only actual manifest variants render; Auto is adaptive). Gap: the selection did not persist. | `loadQualityPref`/`saveQualityPref` (sessionStorage, user-scoped): the hls.js menu re-applies the persisted level on setup and saves on every manual choice; the native-HLS variant menu persists the variant id identically. | F5/F6 pins | browser_qa16.py 45/45 (the real HLS/transcode/quality chain) | COMPLETE |
| R9 | Fullscreen dead button (Issue F) | Already fixed by FINAL-1 (container → video-element → CSS pseudo-fullscreen → honest toast). This pass integrates the ↗ escape hatch into the toast and verifies the chain again. | Toast now references "↗ Open in browser (top)"; the header control (R6) is the secure external path. | test_final1 D-block (47/0) | browser_qa_final1.py 11/11 re-run on THIS tree | VERIFIED + ENHANCED |
| R10 | FJ mode semantics (Issue L) | **Not a defect**: mode is explicit + admin-configurable (3-mode selector: show_all / progressive_random / fixed_order + batch size) and the production DB runs `progressive_random` by operator choice. Enforcement is complete: batches gate progress; once all batches complete, access live-checks ALL channels (bot-22: `required=6 joined=6 ALLOW`); leaving a channel re-denies. | None (verified) | test_bot11_force_join_main_verifier (30/0) + the b16 FJ suites | bot-22 lines 100–206 (the full progressive journey of user 8922807758) | VERIFIED |
| R11 | Registry `duplicate_bot` friction (admin re-registering a REMOVED bot's token) | The refusal is BY DESIGN (removal is terminal; consent flow differs from re-registration). bot-22 shows the admin completed the offered one-tap recovery (`nreg:reactivate`) within seconds. | None (auto-reactivation would bypass the explicit removal lifecycle; the recovery path is honest + fast). | test_bot16_bot_removal (54/0) | bot-22 lines 966–989 | VERIFIED WORKING |
| D1 | `_resolve_target` called the async listing resolver without `await` (coroutine `.get` AttributeError) — found by the NEW suite before release | New-code bug | `async def _resolve_target` + awaited at both call sites | C-section (the APIs would 500) | tests/test_b22_final_engagement.py C3–C13 | FIXED |
| D2 | Handoff path validator accepted `/site/../admin` (dot-segment traversal → the browser normalizes outside /site) — found by the NEW suite before release | New-code bug | Dot-segment rejection (`.`/`..` path segments refused at mint AND consume) | D4 matrix | tests/test_b22_final_engagement.py D4 | FIXED |
| D3 | `_OPEN_EXT_JS` armed once at DOMContentLoaded — a late-loading Mini App SDK never revealed the ↗ control | New-code bug (found by browser QA) | SDK poll (50 ms interval, 3 s cap) mirroring the player bootstrap | Browser T7 | browser_qa_b22.py T7 | FIXED |

---

## 2. Network Bot root cause — the full forensic answer (Issue A1–A7)

The question: *why can the FDB access Storage message −1004460709020/737
while Network Bot 8640674456 gets `BadRequest: Chat not found`?*

The answer, from bot-22's own runtime diagnostics (the access check runs
with the network bot's OWN client, never the FDB's):

1. **Identity is NOT the problem.** `registered_bot_id=8640674456
   actual_bot_id=8640674456 identity_match=True bot_username=
   helpsupport_dox_bot` (getMe on the failing client).
2. **The delivery group is NOT the problem.** `group_reachable=True
   group_type=supergroup bot_membership=administrator` (getChat +
   getChatMember on the same client) and `fdb_membership=administrator`.
3. **The Storage channel IS the problem.** `source_reachable=False
   storage_reachable=False` — the network bot's own `getChat` on
   −1004460709020 fails, and its real `copyMessage` (the
   `mode_a_relay_create` hop) fails with `Chat not found`
   (`copy_capability=failed:BadRequest:Chat not found`).
4. **The FDB is a Storage member; the network bot is not.**
   `DELIVERY_GROUP_VERIFIED … fdb_storage_access=full
   network_bot_storage_access=none mode_a_ready=False` (the health pass
   probes storage with BOTH clients), and the FDB's own
   `copyMessage(storage → user)` succeeds
   (`FDB_DIRECT_DELIVERY_SUCCESS`, jobs 41/42, message ids 803/804).

Telegram Bot API semantics: `copyMessage` reads from `from_chat_id` —
the copying bot must be able to access that chat (membership with
adequate rights in a private supergroup/channel). "Chat not found" on
this hop means precisely: **this bot cannot see that chat**.
Administrator rights in the *destination* group are irrelevant to the
*source* hop.

**Remediation (operator):** add @helpsupport_dox_bot to the Storage
channel (administrator recommended). Mode A resumes within one health
pass or the 300 s negative-cache TTL — no restart needed
(`MODE_A_CAPABILITY_NEGATIVE_EXPIRED … re-probing` in bot-22 proves the
re-probe path). Until then every delivery honestly reports
`mode=fdb_direct` with `mode_a_failure=storage_master_inaccessible` on
the job row — never "network delivery".

Capability cache audit (A6): negatives are `(bool, ts)` with
`MODE_A_NEGATIVE_TTL=300 s`; every write logs
`MODE_A_CAPABILITY_NEGATIVE_CACHED` with the verdict; expiry re-probes
with a real copy; `refresh_mode_a_capability()` (health-pass hook)
re-probes with the network bot's own client and logs RESTORED /
STILL_MISSING. No permanent poisoning (bot-22 line:
`MODE_A_CAPABILITY_NEGATIVE_EXPIRED … the cached 'no' was never
permanent`).

---

## 3. Website Watch-Ad conflation — the exact flow (Issue C)

Production trace (bot-22, user 8922807758): payload → FJ
`progressive_random` (3 batches joined progressively, live membership
checks, UI edits in place) → ALLOW (`required=6 joined=6`) → website
video page → `POST /site/api/stream` → `WEBSITE_STREAM_ISSUE_DENIED
reason=watch_ad_required completed_ads=0 required_ads=1 session=130
pending` (×3) → the player rendered the state whose heading read
"**Watch an ad to continue**" — as if the WEBSITE demanded an ad.

The fix separates the two ad systems **by design**:

* **Telegram payload Watch-Ad** (server-authoritative, completed in the
  bot): still enforced by the ONE Access Engine at stream issuance — an
  unauthorized user now gets the honest `UNLOCK_IN_TELEGRAM` state +
  "Return to Telegram" CTA. Never a site-side ad gate.
* **Website pre-roll** (VAST monetization): unchanged, optional,
  server-decided (`WEBSITE_VIDEOAD_DECISION surface=website_preroll`),
  never blocks playback (fail-open to content). bot-22 proves it worked
  (real 30 s webm ad, skip at 16 s, for the admin).

Once a user completes the Telegram requirement, the SAME canonical
engine authorizes the stream — the website never re-asks.

---

## 4. Files / functions changed (this pass)

| File | Change |
|------|--------|
| `app/storage/schema.py` | SCHEMA_VERSION 39→40; v40 tables in SCHEMA_SQL; the `if current < 40` migration block |
| `app/storage/migrations.py` | v40 registry entry |
| `app/storage/repositories/media_stats.py` | **NEW** — views/reactions/handoffs repository |
| `app/storage/database.py` | MediaStatsRepoMixin composed into DatabaseBase |
| `app/web/site/engagement.py` | **NEW** — view/react APIs + ext-link mint + ext consume + route registration |
| `app/web/site/pages.py` | `_REQUIREMENT_TEXT` copy; video handler passes engagement state; engagement routes registered |
| `app/web/site/html.py` | UNLOCK_IN_TELEGRAM state (old gate state removed); state-aware tgButton; `engagement_bar_html` + `_ENGAGEMENT_JS`; new icons (thumbs-up/down, eye, browser, rotate-cw); engagement CSS; `openextbtn` header control + `_OPEN_EXT_JS` (SDK poll); `ext_api_script`; quality load/save prefs (hls.js + native menus); fs toast references the ↗ hatch; `session_expired_page` |
| `app/web/site/ratelimit.py` | `site_engage` (60/min) + `site_ext` (12/min) buckets |
| `app/network/file_delivery.py` | `probe=pending_evidence` marker on the first relay-create BAD_REQUEST line |
| `tests/qa_bot16_browser_server.py` | QA: `engine_mode` knob (watch_ad denial injection), `BOT_USERNAME` seed, openLink-recording SDK stub |
| `battery/browser_qa_b22.py` | **NEW** — the 33-check browser proof for this pass |
| `battery/build_zips_b22.py` | **NEW** — the release zip builder |
| `battery/run_battery_final.sh`, `battery/run_battery18.sh` | + the b22 suite; tree-relative SRC fixes |
| `battery/browser_qa.py`, `battery/run_battery.sh` | stale hard-coded b11 paths → tree-relative |
| `tests/test_b22_final_engagement.py` | **NEW** — 67 checks (8 sections) |
| 19 legacy suites | schema pins 39→40 (stale pins; the same advance discipline as v37→v38→v39) |

## 5. Database changes

**v40 (additive, idempotent — verified fresh + v39→v40 upgrade):**
`media_view_events (file_pk, viewer_key, last_view_at, PK(file_pk,
viewer_key))`, `media_reactions (file_pk, user_id, reaction CHECK
like|dislike, reacted_at, PK(file_pk, user_id))`,
`website_handoffs (nonce PK, user_id, target, expires_at, used_at,
created_at)` + expiry index. No existing row modified; v36–v39 DBs
upgrade in place on startup.

## 6. Security changes / audit (Issue P)

* **Handoff flow (new):** AEAD-signed token (no raw user id in URLs);
  120 s TTL (clamped 60–600); SINGLE-USE nonce burned in the DB
  (`UPDATE … WHERE used_at IS NULL` — replay fails closed even across
  restarts); target whitelist (`/site` prefix, no `//`, no scheme, no
  `javascript:`, no dot-segments — traversal matrix pinned in tests);
  the 18+ flag rides along ONLY from a session belonging to the SAME
  verified user; rate limits at mint + consume; tokens/nonces never
  logged.
* **Engagement flow (new):** HttpOnly signed session identity only;
  published-listing + collection-membership resolution before any
  count; views video-only; per-user reaction rate bound; no Telegram
  user id or sensitive identifier in any response (counts + the
  caller's own state only).
* **Existing surfaces re-verified:** stream tokens, video refs, HLS
  segments, thumbs (40+ suites); age-gate 404s; `show_get_file=0`
  endpoint refusal; secret scan 248 files, 0 findings.

## 7. Verification matrix (this tree, this pass)

| Evidence | Result |
|----------|--------|
| Full battery (`run_battery_final.sh`) | **44/44 suites, 3,196 checks, 0 failures** |
| tests/test_b22_final_engagement.py (new) | 67/0 |
| tests/test_final1_production_repair.py | 47/0 |
| browser_qa_b22.py (new — REAL Chromium on the REAL stack) | **33/33** |
| browser_qa_final1.py (fullscreen chain) | 11/11 |
| browser_qa16.py (HLS/transcode/quality) | 45/45 |
| browser_qa17_ux.py (B17 UX) | 37/37 |
| compileall (app + run.py) | clean |
| secret scan | 248 files, 0 findings |
| Schema v40 | fresh + v39→v40 upgrade verified |

## 8. Honest verification categories

* **VERIFIED in this environment:** everything in §7 (unit +
  integration + REAL browser runtime on the REAL site stack, normal
  NON-ADMIN user 4242 for the player flows — the admin 1001 only where
  admin behavior itself was the subject).
* **SIMULATED:** the QA access-engine stub's `watch_ad_required`
  denial (the real Monetag reward flow is not reachable from the
  sandbox); the Telegram SDK stub (real initData HMACs, stubbed
  openLink recording); FFmpeg-generated media fixtures.
* **ENVIRONMENT-BLOCKED:** real Telegram API operations with
  production credentials (getMe/getChat/copyMessage by network bot 2
  against Storage −1004460709020; a real Mode-A relay; a real
  `Telegram.WebApp.openLink` tap on a physical device; the Telegram
  WebView fullscreen behavior on the Samsung SM-A047F). The remaining
  exact real tests: (1) add @helpsupport_dox_bot to Storage, deliver
  once, expect `NETWORK_RELAY_MESSAGE_CREATED_BY_NETWORK_BOT` +
  `NETWORK_DELIVERY_SUCCESS mode=network_relay`; (2) tap ↗ on a real
  device, expect the external browser session; (3) tap fullscreen in
  the real WebView, expect the pseudo-fullscreen + toast. Everything
  short of the real API call is proven: the diagnostics, the TTL
  cache, the honest fallback labels, the handoff cryptography/replay
  walls, and the browser flows.

## 9. Remaining limitations (honest)

1. Mode A requires the operator action of §2 (no code can add a bot to
   a channel).
2. The `duplicate_bot` refusal on re-registering a REMOVED bot's token
   is intentional (recovery is one tap; bot-22 shows it works).
3. Real-device Telegram WebView behaviors (fullscreen, openLink) are
   verified through Chromium simulations + the supported-API contract,
   not on physical hardware.
