# WEBSITE PHASE 1 REPORT — Media Transport + File-ID Repair

> PHASE 1 of the 5-phase Website/Mini-App/Streaming plan
> (docs/WEBSITE_PHASE0_AUDIT.md §5). STOP-AND-REPORT gate per spec §50.
> Every test below was EXECUTED by this build. bot.py was NOT touched
> (27,751 lines, byte-identical to the baseline — zero new business logic
> in the monolith; the CORE RULE holds).

## What was built (all additive, under app/media/)

```
app/media/
├── interfaces.py              FROZEN ABC foundation (byte-identical)
├── config.py                  MediaTransportConfig.from_env — cloud|local
│                              mode, Local Bot API URL/API_ID/API_HASH,
│                              shared-FS root, chunk size, timeouts,
│                              private-host warning (spec §17)
├── errors.py                  Taxonomy: FileIdInvalid / TooLarge /
│                              SourceUnavailable / BadRequest /
│                              RangeUnsupported / RangeNotSatisfiable /
│                              Unresolvable / RecoveryFailed +
│                              classify_botapi_error (production marker
│                              parity with bot.py:_WRONG_FILE_ID_MARKERS)
├── cachekeys.py               Cache identity: file_unique_id-keyed
│                              (never file_id — repairs stay cache-valid)
├── httpclient.py              Token-safe HTTP surface: URLs (which carry
│                              the bot token) NEVER enter exception text;
│                              lazy aiohttp; injected-client ready
├── resolver.py                indexed_files row → MediaHandle (identity
│                              + source refs; NO file_id in web contract)
├── repair.py                  File-id recovery service — the Phase 7
│                              hotfix contract, verbatim semantics
│                              (identity discipline, atomic in-place
│                              repair, hide_delivery_source-independent
│                              internal fetch), transports INJECTED
├── sources/
│   ├── _base.py               Shared getFile/classification plumbing
│   ├── telegram_cloud.py      Cloud source — 20MB cap with honest
│                              guidance ("enable TELEGRAM_API_MODE=local")
│   └── local_botapi.py        Local Bot API source — no size cap; disk
│                              mode with TRUE SEEKS (open_range) +
│                              realpath containment security; HTTP mode
│                              with Range/206 verification
└── stack.py                   create_media_stack composition +
                               open_with_repair / size_with_repair —
                               THE single-retry policy (spec §23)
```

## The retry policy (spec §23, exactly)

```
upstream wrong-file-id (only BEFORE any byte is yielded)
  → ONE source recovery (copy/forward into an admin chat, internal,
    hide_delivery_source never blocks it, temp message deleted)
  → identity discipline (file_unique_id + media_type must match —
    otherwise the canonical row is NEVER modified)
  → ATOMIC in-place file_id repair (db.repair_indexed_file_file_id —
    only file_id changes; pk/source refs/payload references preserved)
  → retry ONCE
  → still invalid / bytes already yielded / no repair bound
      → MediaRecoveryFailedError (honest, never a loop)
```

Cache identity discipline: keys derive from `file_unique_id` only, so a
repaired row keeps its cache entries valid with zero invalidation logic.

## Local Bot API architecture (spec §17)

* The media layer talks to the Local Bot API DIRECTLY over HTTP
  (`{url}/bot<token>/getFile` + `{url}/file/bot<token>/<path>`) — the
  main bot's polling lifecycle stays on the cloud API untouched (the
  pinned `build_application` was not modified).
* `MEDIA_LOCAL_FILE_ROOT` enables disk reads with true seeks; the
  resolved real path must stay INSIDE the root (realpath containment —
  a compromised server response can never read arbitrary files).
* Public-looking Local Bot API hosts log a deployment warning.
* Cloud mode remains fully usable (≤20 MB) with an honest upgrade path.

## Tests EXECUTED (this build)

| Suite | Checks | Result |
|---|---|---|
| test_media_phase1.py (NEW) | 88 | **0 failed** |
| All 13 pre-existing suites | 1,451 | **0 failed** (identical to baseline) |
| run_phase8_evidence.py | 24 sections | ALL PASS (exit 0) |
| run_network_evidence.py | 19 sections | ALL PASS (exit 0) |

The full battery was RE-EXECUTED after implementation (operator rule: never
trust a previous run): all numbers above are from this build's fresh runs,
and the baseline md5 of bot.py matches the Architecture Phase ZIP.

Coverage highlights (88 checks): config parsing/validation/warnings;
resolver identity separation (handles carry NO file_id); classifier
parity with production error shapes; cloud 20MB cap + guidance + zero-
upstream-call pre-check; chunked streaming; 404/429/5xx/network honest
classification; local no-cap (3 GiB); disk mode exact bytes + true-seek
ranges ([100,199], EOF, full-window, 416); root-relative path mapping;
containment refusal → HTTP fallback; Range/206 verification (200→
RangeUnsupported, 416→RangeNotSatisfiable); cloud refuses ranges
honestly; LOCAL SERVER UNAVAILABLE / 429 (spec §13 J: network-level
failure → retryable MediaSourceUnavailableError, never an identity
failure); repair happy path / identity mismatch / type mismatch / fetch
failure / exception / no-admin-chat / idempotent second repair; DB
row-after-repair identity preservation (only file_id changed);
open_with_repair single-retry policy (2 getFile calls, spec §44 log
events DELIVERY_FILE_ID_INVALID/SOURCE_RECOVERY/FILE_ID_REPAIRED);
second-failure no-loop; mid-stream failure never retried; size_with_
repair; source selection; stack close; cache key stability across
repair; structural (clean-interpreter import without bot.py; no bot
imports; ABC conformance; py_compile; NO bot token in ANY exception
message).

## NOT IMPLEMENTED IN THIS PHASE (per the phased plan)

* HTTP-level streaming (206 responses, stream tokens, Media Gateway
  route) — Phase 4 (the sources expose open/open_range; the HTTP layer
  is deliberately absent).
* Shared cache implementation — Phase 4 (only the KEY discipline exists).
* Indexer capture of mime_type/width/height/thumbnails — Phase 2
  (resolver reads them opportunistically when the columns land).
* Wiring into the running application (bot.py/route integration) —
  Phase 3/4, when the website routes exist (keeps this phase pure and
  regression-proof: bot.py is byte-identical).

## Known limitations (honest)

1. No live Telegram / Local Bot API traffic (sandbox) — fake transports
   reproduce the documented production error shapes (the established
   pattern of every prior phase).
2. HTTP-mode ranges on the local server REQUIRE a 206-capable endpoint;
   a server that ignores Range raises RangeUnsupportedError honestly
   (documented remedy: MEDIA_LOCAL_FILE_ROOT shared mount).
3. api_id/api_hash are carried but unused by the current sources (some
   Local Bot API deployments require them; future MTProto source will
   consume them).

## Clean-build verification (spec §18)

A clean staging tree (no `__pycache__`, no `bot.log`, no `.env`, no db
files, no venvs) was built and the battery re-run from it; the release
ZIP was assembled from that clean tree, `unzip -t` verified, and a fresh
extraction of the ZIP itself re-ran the Phase 1 suite green. Details in
the Phase 1 completion section of the project worklog.
