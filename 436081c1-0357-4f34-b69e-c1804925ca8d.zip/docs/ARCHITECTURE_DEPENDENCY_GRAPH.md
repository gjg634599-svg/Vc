# ARCHITECTURE DEPENDENCY GRAPH — Before / After

## BEFORE (baseline `payload-bot_architecture_final.zip`)

```
                         ┌──────────────────────────────────────────────┐
   run.py ──import bot──▶ │  bot.py  (25,053 lines — THE center of       │
                         │  gravity: 562 functions, 157 globals,         │
                         │  ALL handlers + ALL state + 97 facades)      │
   app/main.py ──────────┘           │ (bot module injected as parameter)
        ▲                            ▼
        │                    app/bootstrap/application.py
        │                     run_production(mod) / build_application(mod)
        │                            │
        │                     app/bot/registration.py (mod.* late binding)
        │                            │
        │                    app/services/container.py
        │                     legacy_service_factories(ns)
        │                     website_media_gateway(ns)
        │                            │
   tests (20 files)        ┌────────┼──────────────────────────┐
   import bot as B ────────┤        │                          │
   (~200 monkey-patches    ▼        ▼                          ▼
   through the bot module) app/core/* (domain)      app/storage/* (persistence)
                            app/media/*  (infra)     app/network/* (infra)
                            app/web/*    (website)  app/bot/* (partial handlers)

  DEFECT: the production application CANNOT be constructed without
  importing bot.py — run.py and app/main.py both import it and inject it.
```

## AFTER (ARCHITECTURE PROPER BREAKDOWN)

```
 run.py ──────────────▶ app/bootstrap/application.py  (THE composition root)
 python -m app.main        │  load_runtime() · build_application(runtime)
                          │  run_production(runtime)
                          ▼
              app/presentation/telegram/  (presentation layer)
              ├── namespace.py ──── assembles `runtime` (the shared
              │     │                 namespace: state + all sections)
              │     ├── state.py     (imports, config bindings, constants,
              │     │                 locks, caches, singletons)
              │     ├── <31 sections> (delivery, forcejoin, watchads,
              │     │                 callbacks, miniapp, admin panels,
              │     │                 network wiring, lifecycle, ...)
              │     ├── registration.py · keyboards.py · network_ui.py
              │     ├── website_ui.py · router.py
              │     └── _manifest.py (generated completeness manifest)
              ▼
   app/services/container.py  (application layer)
   legacy_service_factories(runtime) · website_media_gateway(runtime)
   website_deps_factory · website_admin_deps
              │
     ┌────────┴─────────┬─────────────────┬─────────────────┐
     ▼                  ▼                 ▼                 ▼
 app/core/*        app/storage/*     app/media/*      app/network/*
 (domain:          (infrastructure:  (infrastructure: (infrastructure:
  access engine     schema v32,       cloud/local      credential vault,
  payload/referral  repositories,     Bot API media     registry, points,
  force-join/       migrations,       stack, gateway,    routing, workers,
  watch-ads/deliv-  dbutil re-export) repair, ranges,   broadcast engine)
  ery/verification/                    stream cache
  indexing/verify)                     + tokens)
     │                  ▲                 ▲                 ▲
     │        app/web/* (website presentation + server lifecycle + auth)
     │                  ▲
     └──────────────────┘  (domain may be imported by everything below;
                            it imports only itself + the config leaf)

   app/bootstrap/config.py — THE configuration leaf
   (RuntimeConfig + EnvDefaults: the ONLY env parsing outside
    app/media/config.py — the media transport's own config module)

   tests/ (24 hard gates) + 20 regression suites + 9 evidence scripts
   → from app.presentation.telegram import runtime as B
     (patching semantics preserved through the assembled namespace)

  bot.py: REMOVED. Nothing imports it. Nothing needs it.
```

## Layer rules (enforced by tests/test_architecture_proper_breakdown.py)

| Layer | May import | Never imports |
|---|---|---|
| domain (`app/core`) | domain, config leaf | telegram, aiohttp, SQL execution, os.environ, presentation |
| application (`app/services`) | domain, application, infrastructure, config | telegram, aiohttp, SQL execution, os.environ, presentation (module-level) |
| infrastructure (`app/storage`, `app/media`, `app/network`, `app/web`) | domain, infrastructure, config | presentation |
| presentation (`app/presentation`) | domain, application, infrastructure, presentation, config | — (downward only) |
| composition (`run.py`, `app/main.py`, `app/bootstrap/application.py`) | everything | — (privileged) |
| config leaf (`app/bootstrap/config.py`) | nothing (stdlib only) | — |

## Composition data flow (§22 real production path)

```
run.py
  → app.bootstrap.application.run_production()
      → load_runtime() = app.presentation.telegram.runtime
          (namespace._assemble: state foundation → manifest-driven
           function rebinding → closure patching → class rebuild →
           _LEGACY_NS/_SVCS binding → completeness verify)
      → build_application(runtime)
          → registration.build_handler_registry(runtime)  (44 handlers)
          → PTB ApplicationBuilder (token, post_init, post_shutdown)
      → run_polling(allowed_updates=ALL_TYPES)

post_init (app/presentation/telegram/lifecycle.py)
  → DB connect + schema v32 init
  → file-id epoch check · settings seeding · startup health
  → background workers (auto-reindex, broadcast scheduler, cleanup)
  → start_mini_app_server(bot)  (aiohttp :8080 — Watch Ads Mini App
                                  + Website Payload Platform routes)
  → network_startup(bot)        (network workers, if configured)

post_shutdown
  → network_shutdown() → stop_mini_app_server()
  → media gateway stack.close() (HTTP session released)
  → cancel + await every background task
  → db.close()
```
