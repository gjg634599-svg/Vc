# ARCHITECTURE PHASE FINAL REPORT

## Baseline (executed by this build, not trusted from prior reports)

- Exact test count: **1,355 checks across 12 suites — 0 failed**
  (test_watch_ads 91, v2 142, v3 104, v4 153, v5 142, v6 113, v7 85,
  phase6 124, phase7 151, phase7_hotfix 94, phase8 77, network 79).
- Evidence runners: run_phase8_evidence.py ALL PASS (exit 0);
  run_network_evidence.py ALL PASS (exit 0).
- Source state: `bot.py` = 34,068 lines (1.67 MB); additive
  `app/network/` (6 modules) + `app/core/` (3 modules); schema v29.

## Architecture Before

```
run.py → app.main → bot.main → giant bot.py
  L165-604    configuration/constants
  L605-1380   SCHEMA_SQL DDL
  L1383-6622  class Database (253 methods, ~5,240 lines)
  L6623-…     helpers, transport, FJ, access, watch ads, referral,
              delivery, /start, admin commands, reindex, panels,
              on_callback (2,600 lines), lifecycle, Mini App server,
              network wiring, build_application
```

bot.py responsibilities (before): EVERYTHING — database + migrations,
all repositories, access engine, delivery, FJ, referral, watch ads,
points, admin settings/panels, callbacks, Telegram handlers, keyboards,
network registry wiring, broadcast glue, Mini App + WebApp auth, aiohttp
lifecycle, configuration, logging, startup/shutdown.

## Architecture After

```
run.py → app.main → bot.main (compat facade) → build_application
            │
            ▼  app/bootstrap/application.create_application
            ▼  app/services/container.ServiceContainer
   ┌───────── ADAPTERS ─────────┐   ┌────────── CORE ──────────┐
   │ app/bot/handlers/network.py │   │ app/core/access/engine   │
   │ app/bot/callbacks/router.py │   │ app/core/payload/service │
   │ app/bot/keyboards/builders  │   │ app/core/delivery/service│
   │ app/web/{application,auth,  │   │ app/core/force_join/svc  │
   │          routes,watch_ads}  │   │ app/core/referral/service│
   │ app/network/* (baseline)    │   │ app/core/watch_ads/svc   │
   └──────────────────────────────┘   │ app/core/{indexing,      │
            ▼                          │  verification}/engine    │
   app/storage/repositories/* (10)     │ app/core/{constants,fmt}│
   app/storage/{database,migrations,   └──────────────────────────┘
                dbutil}.py                        ▼
            ▼                              (services depend on repos)
   SQLite (aiosqlite) — schema v29
```

Dependency direction: adapters → core services → repositories → SQLite.
Enforced by test_architecture.py D1 (no app/* module imports bot.py,
except the documented app/main.py bootstrap boundary) and B2/C1
(repositories import without telegram; network+web+router import without
bot.py, verified in clean interpreters).

## Extraction Results (every item physically moved, verbatim bodies)

| Responsibility | Old location | New location | Status |
|---|---|---|---|
| DB connection/locks | bot.py Database | app/storage/database.py DatabaseBase | MOVED |
| Migration primitives | Database methods | app/storage/migrations.py | MOVED (chain itself pinned, documented) |
| Users / media / payloads / FJ / referral / WA / network / broadcast / deliveries / settings repositories | Database class | app/storage/repositories/*.py (10 mixins, 236 methods) | MOVED |
| Shared constants (86) | bot.py config blocks | app/core/constants.py | MOVED (re-imported) |
| now_iso / safe_row_get | bot.py helpers | app/storage/dbutil.py | MOVED |
| Formatting helpers (8) | bot.py helpers | app/core/format.py | MOVED |
| Payload slugs/links/creation (22 fns) | bot.py | app/core/payload/service.py | MOVED |
| Referral gate/qualification/links | bot.py | app/core/referral/service.py | MOVED |
| Watch Ads config/gate/session-URL/templates (11 fns) | bot.py | app/core/watch_ads/service.py | MOVED |
| AccessResult + points alternative | bot.py | app/core/access/engine.py | MOVED (resolver shell pinned, calls into it) |
| FJ membership + active-batch machine (23 fns + 2 enums) | bot.py | app/core/force_join/service.py | MOVED |
| Delivery domain helpers (5) | bot.py | app/core/delivery/service.py | MOVED (_deliver_files_core pinned — REVERTED honestly) |
| WebApp initData validation | bot.py | app/web/auth.py | MOVED |
| aiohttp lifecycle | bot.py | app/web/application.py WebServerLifecycle | MOVED (route lines pinned) |
| Route registry | — | app/web/routes.py | NEW |
| Network UI handlers (42 fns) | bot.py wiring section | app/bot/handlers/network.py | MOVED (worker glue pinned) |
| Keyboards (2 builders) | bot.py | app/bot/keyboards/builders.py | MOVED |
| Callback registry + dispatch | — | app/bot/callbacks/router.py | NEW (on_callback chain pinned; registry live + tested) |
| Service container | — | app/services/container.py | NEW |
| Bootstrap composition | — | app/bootstrap/application.py | NEW (build_application pinned wrapper) |
| Media abstraction | — | app/media/interfaces.py | NEW (ABCs only) |
| Verification/indexing engines | app/core/{verification,indexing_engine}.py | …/{verification,indexing}/engine.py | REPACKAGED (re-exporting __init__ + legacy shims) |

## bot.py

- Before: **34,068 lines**
- After: **27,751 lines** (**−6,317 / −18.5%**, all physically relocated)
- Remaining responsibilities (full inventory in
  docs/BOT_COMPATIBILITY.md): source-pinned frozen zones (access resolver
  shell, _deliver_files_core ordering, watch-ad transaction core,
  migration chain, Mini App HTML/handlers/routes, on_callback branch
  chain, network worker glue), the admin panel/wizard UI,
  text/media input handler, bootstrap wiring, and the compatibility
  wrappers themselves. **No new business logic may be added to bot.py.**

## Tests

- Baseline: 1,355 / 0 (executed before any change).
- Checkpoint B (after storage): 1,355 / 0.
- Checkpoint C (after services/adapters): 1,355 / 0.
- Final (from the extracted ZIP copy): **1,355 / 0** across all 12
  suites + **96 / 0** new architecture checks (test_architecture.py).
- Network tests: 79/0 green. Phase 8 tests: 77/0 green.
- Behavior changed: **NO** at every checkpoint.
- Bugs found by the architecture work and fixed during extraction are
  documented in docs/TEST_REPORT.md.

## Migration

- Fresh DB → v29, all 10 network tables present (test_architecture.py I).
- Existing v28 DB → v29 (covered by test_network.py H1-H3, green).
- init_schema idempotent on second run (I3).
- No existing table/column/row touched; SCHEMA_SQL and the v1→v29 chain
  are byte-identical (pinned).

## Clean ZIP

- Archive: `payload-bot_architecture_phase.zip` (784,718 bytes,
  131 files, 86 Python modules).
- Extracted to a brand-new directory (`zip-verify/`), no dependence on
  the working directory.
- py_compile: ALL files OK.
- Import application: OK (SCHEMA_VERSION 29).
- Migrations against fresh DB: OK (v29).
- Complete test suite from the extracted copy: **1,355/0 + 96/0**.
- Network evidence: ALL PASS. Phase 8 evidence: ALL PASS.
- run.py entrypoint: build_application composes the PTB Application.
- No accidental files: no .db, no logs, no secrets, no .env (only
  .env.example) in the archive.

## NOT IMPLEMENTED IN THIS PHASE (intentionally deferred)

- Payload Web UI
- HTTP Range
- Video streaming
- seeking/resume
- Media Gateway implementation
- multi-GB cache
- Download Pack
- Local Bot API

The boundaries for all of these now exist: app/media/interfaces.py
(MediaResolver/MediaSource/MediaHandle), app/web/* (routes/lifecycle/
auth), app/core/access (the shared verdict the playback authorization
will call), and the service container.

## KNOWN LIMITATIONS

1. The regression suites pin ~181 source-text patterns INSIDE bot.py;
   the corresponding bodies (inventoried in docs/BOT_COMPATIBILITY.md)
   cannot move until the suites are refreshed — this phase kept them
   frozen rather than editing tests to claim extraction.
2. bot.py is NOT fully eliminated: the admin panel/wizard UI and the
   on_callback legacy chain remain (documented legacy, ~27.7k lines).
3. The callback router's dispatch surface is live and tested but no
   production namespace is registered to it yet (the legacy chain still
   owns all namespaces; extraction of panel groups is staged next).
4. No live Telegram / Monetag traffic was exercised (unchanged honest
   scope from all prior phases — fake transports reproduce the
   documented production error shapes).
5. `app/bootstrap/application.create_application` is the composition
   mechanics; `build_application` in bot.py remains the pinned wrapper
   that supplies the handler registry (single wiring, no duplicate).
