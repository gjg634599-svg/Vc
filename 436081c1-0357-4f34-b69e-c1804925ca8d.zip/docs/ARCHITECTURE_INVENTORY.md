# ARCHITECTURE INVENTORY — Before State (Authoritative Baseline)

> Generated as part of **ARCHITECTURE PROPER BREAKDOWN (FINAL MODULARIZATION)**.
> Baseline ZIP: `payload-bot_architecture_final.zip`
> ZIP SHA-256: `ac8b4b0b0a301c49027ec6511816633daec7e4527d081904cd4dfa9dfbd04a90`
> bot.py SHA-256: `cfc59185b6f18860700ef9dab746eec76e6438d943af565c426e459fff120b40`
> SCHEMA_VERSION: **32** (must remain 32 — no schema change is part of this work)
> Baseline test result: **2226 passed / 0 failed** (20 test files)

Machine-audited facts (AST + regex scans, `python3.12`):

| Metric | Count |
|---|---|
| bot.py lines | 25,053 |
| bot.py bytes | 1,227,275 |
| Top-level functions in bot.py | 562 |
| Top-level classes in bot.py | 1 (`RateLimiter`) |
| Top-level variables/globals in bot.py | 157 |
| `@admin_only`-decorated commands | 37 |
| Compatibility facade stubs (`*args, **kwargs` delegators) | 97 |
| SQL call sites remaining in bot.py | 63 (SELECT 37 / INSERT 11 / UPDATE 19 / DELETE 7) |
| Command handlers registered (`app/bot/registration.py` table) | 38 |
| Callback prefixes dispatched in `on_callback` | 126 |
| Background workers / lifecycle loops | 9 |
| Mini App / Website HTTP routes | 6 + site routes (`app/web/site`) |
| Files importing `bot` module | 29 (20 tests, 9 evidence scripts, `run.py`, `app/main.py`) |
| Duplicate top-level definitions | **0** |
| Environment reads outside `app/bootstrap` | 7 (constants.py×4, container×1, media/config×1, network/credentials×1) |

## A/B. bot.py top-level surface

* 562 functions + 1 class + 157 module-level names — the largest functions:
  `on_callback` (2,609 lines), `text_handler` (1,153), `_wad_mini_app_page` (585),
  `_run_reindex_inner` (519), `post_init` (382), `on_media_input` (327).
* Module-level control flow is minimal and safe to relocate: docstring,
  two optional-dependency `try/except` blocks (dotenv L98, aiohttp L1225),
  `_schema_set_runtime_context(...)` (L1516), logging setup (L1531–1540),
  `if __name__ == "__main__"` guard (L25052).
* No `globals()` / `eval()` / `exec()` usage anywhere in bot.py.
* No module-level assign references a function object; no forward references.
* Only 8 names are ever re-bound at runtime through `global` statements:
  `INDEX_GLOBAL_LOCK`, `auto_reindex_task`, `broadcast_scheduler_task`,
  `cleanup_task`, `startup_reindex_task`, `FILE_IDS_STALE_EPOCH`, `db`,
  `BOT_USERNAME`.
* Only 2 functions have module-name default arguments
  (`schedule_browse_delete` → `BROWSE_AUTO_DELETE_DELAY`,
  `send_recent_files_panel` → `RECENT_PAGE_SIZE`).

## C/D. Database access

SQLite ownership is already extracted into `app/storage/` (`schema.py`,
`migrations.py`, `database.py`, `repositories/*`). bot.py keeps **63 residual
SQL call sites** — all read/write helpers on top of the shared `db` object
(admin stats panels, index job persistence, startup checks). These move with
their owning presentation sections; no SQL ownership is newly created.

## E/F/G/H. Handlers

* 38 command handlers bound through `app/bot/registration.py`
  (`_COMMAND_TABLE` + channel-post / join-request / callback / media /
  text message handlers).
* 126 callback prefixes dispatched inside the single `on_callback` router.
* Admin authorization: `admin_only` decorator + permission model
  (`is_admin`, `has_permission`, owner/permission constants).

## I. Background tasks

`auto_reindex_loop`, `broadcast_scheduler_loop`, `cleanup_loop`,
`startup_reindex_all_channels`, network `net_health_loop`,
`init_network_services` / `network_startup` / `network_shutdown`,
scheduled-broadcast worker; started in `post_init`, cancelled in
`post_shutdown`.

## J. aiohttp routes

Mini App server (same process): `GET /watch-ad/{token}`,
`POST /api/network/auth`, `POST /api/watch-ad/status`,
`POST /api/watch-ad/ad-event`, `GET /api/watch-ad/postback`, `GET /healthz`
plus the Website Payload Platform routes registered from `app/web/site`
(feed/search/detail/stream/auth) via `register_site_routes`.

## K. Media operations

`app/media/*` already owns the stack (resolver, sources cloud/local,
repair, ranges, streamcache, streamtokens, gateway, httpclient).
bot.py retains the Telegram-side transport adapters (`fetch_channel_media`,
`_recover_file_id_from_source`, `send_file` retry ladder, album/forward
batching) — presentation-layer delivery code that moves to the Telegram
presentation package.

## L. Configuration access

`app/bootstrap/config.py::RuntimeConfig.from_env` owns parsing (bound in
bot.py as module names). Residual env reads outside bootstrap:
`app/core/constants.py` (4), `app/services/container.py` (1 —
`MEDIA_CACHE_ROOT`), `app/media/config.py` (1), `app/network/credentials.py`
(1). All are read-only tuning knobs; consolidated in the final state where
behavior-preserving.

## M. Network lifecycle operations

`app/network/lifecycle.py` owns startup/shutdown/health/workers — bot.py
keeps thin facades passing `_LEGACY_NS` (12 facades at tail).

## N. Service factories

`app/services/container.py::legacy_service_factories(ns)` is the
composition boundary for: payload/referral/watch-ads/access/force-join/
delivery services, web auth, keyboards, network UI, website media gateway,
website network tokens, website deps.

## O. Direct imports of bot.py

`run.py` (entrypoint), `app/main.py` (module entrypoint), 20 test files,
9 evidence scripts. **No file under `app/` imports bot.py** (enforced by
existing `test_architecture*.py` gates).

## P. Modules importing infrastructure directly

Presentation/website handlers reach SQLite only through the injected `db`
(namespace late binding). `app/web/site/*` receives a deps snapshot
(`website_deps_factory`) — no direct infrastructure imports.

## Q. Circular dependencies

None at import time between `app/*` modules (verified by clean-interpreter
import tests). The single cycle-shaped edge is **runtime late binding**
through the namespace object (`ns`), by design.

## R. Compatibility aliases/stubs

97 `*args/**kwargs` facades in bot.py delegating to `app/core/*` services +
12 network lifecycle facades + `_svc_make_*` delegators. These remain the
authoritative public seam for the regression suites (patching `B.<name>`).

## S. Duplicate definitions

None (AST-audited).

## T. Tests relying on bot.py internals

* All 20 test files: `import bot as B`.
* ~200 monkey-patches via `B.<name> = ...`.
* 19 files scan `bot.py` **source text** (string-presence assertions).
* 8 files assert on runtime values reached through `B`.

## Before-state dependency graph

```
run.py ──import bot──▶ bot.py (25,053 lines: ALL handlers + state + 97 facades)
  │                      │  (bot injected as parameter)
  └────────────────────▶ app/bootstrap/application.py (run_production(mod))
                              │
                              ├─▶ app/bot/registration.py (handler table → mod.*)
                              ├─▶ app/services/container.py (legacy_service_factories(ns))
                              │       ├─▶ app/core/* (domain services)
                              │       ├─▶ app/storage/* (persistence, schema v32)
                              │       ├─▶ app/media/* (media stack)
                              │       ├─▶ app/network/* (platform + lifecycle)
                              │       └─▶ app/web/* (website presentation)
                              └─▶ app/web/server.py (mini-app/website aiohttp)

app/main.py ──import bot──▶ same path (documented entry adapter)
tests (20 files) ──import bot as B──▶ bot.py namespace (patching + source scans)
```

**The architectural defect to remove:** `run.py` and `app/main.py` still
import bot.py; bot.py is still the constructor-supplied handler mass and
state root. The production application cannot be built without it.
