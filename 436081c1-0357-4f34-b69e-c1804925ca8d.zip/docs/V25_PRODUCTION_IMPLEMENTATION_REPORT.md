# V25 FINAL PRODUCTION IMPLEMENTATION REPORT

## 1. Executive Summary

V25 was implemented against the real B24 codebase (uploaded
`payload-bot_PRODUCTION_B24_FIXED.zip`) in `/home/z/my-project/payload-bot`.
Every requirement was traced to its real code path, implemented, and then
verified through **live browser interaction against the actual production
stack** (a demo instance of the REAL site code with a seeded database and
real playable media), **mocked-transport delivery tests**, and a **51-suite
regression battery (all GREEN)**. The live browser verification caught one
genuine production bug that every static test had missed (the A.4
collection-counts join bleed) — exactly the class of defect the V25 process
was designed to surface.

Verification classes used throughout (strict distinction):
**LIVE VERIFIED** (real browser against the real stack) ·
**MOCKED VERIFIED** (mock Telegram transport boundary, deterministic
assertions) · **AUTOMATED VERIFIED** (integration suites over real code +
real DB) · **NOT VERIFIED LIVE** (requires a real Telegram deployment).

## 2. Files Changed

| File | Change |
|---|---|
| `app/web/site/html.py` | collection card/detail badges; inner media rows (kind controls, per-row thumbs, P<n> overlay, dupe skip); two-level settings menu; canonical speed ladder; fullscreen state machine + lifecycle; category chevron + structured attrs + sheet CSS; teardown fixes; ambient leak fix; boot-rate re-apply |
| `app/web/site/pages.py` | `_file_thumb_urls()` per-media gateway tokens; `WEBSITE_MEDIA_INVENTORY` integrity trace |
| `app/web/site/service.py` | `WEBSITE_MEDIA_DEAD_DROPPED` loud logging; logger |
| `app/web/site/screens.py` | auto-auth login (auto-submit signed initData; manual form = fallback only) |
| `app/storage/repositories/website.py` | A.4 counts fix (fold detected collections into the count query) + the live-caught join-bleed fix |
| `app/network/file_delivery.py` | Hide Source COPY routing (`_deliver_layered`) |
| `app/presentation/telegram/delivery.py` | (unchanged — already COPY-guarded) |
| `tests/test_v25_production.py` | NEW — 127 checks (A–J sections) |
| `tests/test_b24_production_fix.py`, `tests/test_a_prompt_fixes.py`, `tests/test_bot11_delivery_e2e.py`, `test_network.py`, `test_media_phase3.py` | pins updated to V25 semantics (documented in-place) |
| `run_v25_battery.py` | NEW — full 51-suite battery runner |
| `mini-services/site-demo/index.py` | NEW — live demo service (production stack + demo seed + Telegram SDK shim) |
| Next.js: `src/app/page.tsx`, `src/app/api/v25/status/route.ts`, `next.config.ts`, `eslint.config.mjs` | the V25 verification center (live embed + battery status) |

## 3. B24 Issues Resolved

- The B24 collection media-counts special-case was a **false-positive
  test/implementation combination**: `_count_label`/`aggregate_media_counts`
  were correct, but both `card()` and `detail_page()` discarded
  `media_counts` whenever `is_collection=True`, and `collections_page()`
  stamped that flag on every item. Fixed at the render sites; the truthful
  badge now flows everywhere.
- The B24 fullscreen mirror (`if(tg.isFullscreen){ enterFakeFullscreen(); }`)
  forced video fullscreen on ANY Mini App expand — replaced by the
  intent-aware mirror inside the canonical state machine.
- The B24 `__playerTeardown` comment claimed listener cleanup but only ran
  `teardownMedia()/destroyHls()` — now it genuinely removes every named
  document handler and `tg.onEvent` registration, exits any video
  fullscreen (the stale scroll-lock), and dedups the pagehide writer.

## 4. Collection Rendering

- **Root cause**: `card()` html.py:3226 and `detail_page()` html.py:3539
  passed `media_counts=mc if not is_collection else None`.
- **Real render path**: fixture DB (collection, 3 videos + 2 photos) →
  `make_website_service(db).get_listing_detail()` (A.4 expansion) →
  `card()` / `detail_page()` / `screens.collections_page()` → HTML.
- **Media-count result**: "3 videos · 2 photos" on the card, the collections
  page and the detail badge (LIVE + AUTOMATED). No collapse to "1 video" or
  a bare "5 files".
- **Inner media result**: five rows in canonical order (V V V P P),
  `data-kind` per row, play controls for videos, view (eye) controls for
  photos, open/download controls for documents, real per-row thumbnails
  (Media Gateway tokens, lazy, bounded), P<n> overlay, zero duplicates.
- **Live-caught extra bug**: the A.4 listing-path join
  (`i.message_id = i.message_id`) bled collection counts onto every
  same-channel payload (Aurora/Blueprint cards showed the collection's
  counts). Fixed + regression-tested (batch isolation, non-member).

## 5. Media Integrity

- source count (5) == stored (5) == rendered rows (5) == badge summary ==
  batch API counts — verified in the automated fixture AND live.
- Dead collection members: `WEBSITE_MEDIA_DEAD_DROPPED` warning (never a
  silent drop); live re-resolution drops to a truthful 4-row inventory.
- Every multi-media detail render emits `WEBSITE_MEDIA_INVENTORY
  stored/rendered/capped_extra/duplicate_pks/media_counts`.

## 6. Player

- **Resume**: LIVE VERIFIED — seek to 45s → reload → "Continue watching —
  resume from 45s?" → Resume → t=45, bar dismissed; readiness-guarded seek.
- **Start Over**: LIVE VERIFIED — seeded 60s progress → Start Over → t=0,
  key cleared, bar dismissed; the `__playIntent="startover"` guard
  suppresses the loadedmetadata re-restoration race.
- **Quality**: real variants only — the menu stays hidden with a single
  source (§9 honesty); HLS levels + native variants flow unchanged;
  switching preserves position/play state and re-applies speed.
- **Speed**: exact 0.5/0.75/1/1.25/1.5/2 ladder, 1× = "Normal", invalid
  values fall back to 1×, persisted per session — LIVE VERIFIED (1.5×
  survives reload after the boot-rate re-apply fix).
- **Collection playback**: progress identity is
  `plresume:<uid>:<listing>:<file_pk>` — opening Video 2 resumes Video 2.

## 7. Fullscreen

- **Root cause**: a state conflict — the player button called
  `tg.exitFullscreen()` when the Mini App was already fullscreen
  (MINI_APP → NORMAL → re-enter), and the unconditional mirror forced
  video fullscreen on Telegram-UI expands.
- **State machine**: NORMAL → MINI_APP_FULLSCREEN → VIDEO_FULLSCREEN with
  the canonical layered exit (VIDEO_FS exit keeps the Mini App layer);
  `fsState()` derives the state; no competing browser fullscreen while the
  Mini App is fullscreen; entering from NORMAL requests the Mini App
  fullscreen (promise + intent-aware mirror).
- **Telegram fullscreen behavior**: verified structurally + live via the
  shim (fsfake engages inside the Mini App viewport, icon truthful). A real
  Telegram client cannot be driven here — see §20/§22.
- **Lifecycle**: `__playerTeardown` removes the named `keydown` (Esc),
  `fullscreenchange`/`webkitfullscreenchange`, outside-tap, and pagehide
  handlers + `tg.offEvent` registrations; exits video fullscreen FIRST.
  LIVE VERIFIED with 8 navigate→fullscreen→exit cycles (video alive, zero
  stale scroll-locks, clean console).
- **Blank region (§31)**: root causes were the stale
  `fsfake-scroll-lock` after SPA navigation away from a fullscreen player
  (fixed in teardown) and the old short categories sheet over a full-screen
  scrim (replaced by the bounded grouped sheet).

## 8. Delivery

- **Previous behavior**: layered Mode A (FDB copyMessage storage→group,
  network bot forwardMessage group→user) → Mode B (FDB copyMessage
  storage→user) → Mode C (handoff).
- **Root cause of the readiness flapping (bot-30.log)**: the configured
  delivery chat `-1003849433039` was temporarily `chat_not_found` for the
  FDB probe (07:09–07:29); the re-verification loop recovered it at
  07:32 (`DELIVERY_GROUP_VERIFY_RESULT result=ok status=DELIVERY_READY`),
  after which jobs 51/52 delivered via Mode A and job 53 via Mode B.
  The recovery path works; the chat was stale/transient, not permanently
  misconfigured.
- **Current behavior**: unchanged layering + the V25 Hide Source routing
  below. Live Telegram verification is NOT possible in this environment —
  delivery remains MOCKED VERIFIED here; the bot-30.log timeline is the
  production evidence for the readiness recovery.

## 9. Hide Source

- **Previous API/path**: Mode A hop 2 = network bot `forwardMessage`
  (group→user) — the delivered message carries Forwarded-from provenance
  whenever Mode A ran, regardless of the hide_source setting.
- **New API/path**: `_deliver_layered` reads the AUTHORITATIVE backend
  setting (`bot_settings.prot_v3_hide_source`, default ON). ON → Mode A is
  skipped entirely with a durable `mode_a_failure=
  "hide_source_copy_semantics"` marker and a `DELIVERY_HIDE_SOURCE_COPY`
  log; the user-facing send is the FDB's `copyMessage(storage→user)` — a
  true COPY. OFF → the layered relay is preserved.
- **COPY verification (MOCKED, exact method + params)**: ON →
  `copyMessage(chat_id=8370454312, from_chat_id=storage, message_id=737,
  protect_content=False)`, zero `forwardMessage` calls; OFF →
  `forwardMessage(chat_id=user, from_chat_id=group, message_id=relay)`
  with no FDB copy.
- **Forwarded provenance verification**: forwardMessage never fires when
  ON (transport-level assertion, not a source-string check).
- **Frontend override**: impossible — no `hide_source` exists anywhere in
  the web layer (automated pin).

## 10. Telegram Authentication

- **initData validation**: the canonical HMAC validator
  (`validate_telegram_init_data`, secret = HMAC("WebAppData", BOT_TOKEN),
  freshness window) — tampered hash and 30-day-old initData both REJECTED
  (automated).
- **Automatic authentication**: the login screen AUTO-submits the signed
  initData without confirm fields; the manual ID/username form is a
  fallback shown only after auto-auth fails. No manual entry is needed
  inside the Mini App (LIVE VERIFIED through the same HMAC+session-issuance
  path via the demo autologin; the page JS contract is pinned automated).
- **Returning user**: session round-trips the stable Telegram user id; a
  username change maps to the SAME canonical user (automated).
- **Duplicate-user protection**: identity is keyed on the Telegram user id
  (first-class session field); AEAD tampering fails closed.

## 11. Force-Join

- SHOW_ALL: all channels live-checked; all-joined → ALLOW, none → DENY
  with all three (automated, live membership mocks).
- PROGRESSIVE_RANDOM: batch of 2; fully-joined batch → ALLOW with the
  payload recorded unlocked; re-open → fast path; fresh user → DENY with
  exactly the batch; the randomized order is persistent (same batch twice).
- FIXED_ORDER: the batch follows the configured channel order.
- **Parity result**: the website deps bind the SAME canonical
  `_unjoined_for_access` (container pin) and thread `payload_id` through
  the gate (pages pin) — one engine, no duplicated logic.

## 12. Navigation

- **Back**: modal closers close temporary UI first (category sheet/panel
  registered; the settings submenu closes before the menu on Esc).
- **popstate**: the B24 applyDoc snapshot restore is preserved (battery
  green).
- **Categories**: the More `<details>` is a real state machine
  (aria-expanded sync, chevron down→up, outside-tap/ESC/Back close); the
  mobile sheet closes on navigation with no lingering scrim (LIVE).
- **Bottom navigation**: Home/Categories/Search/Library preserved,
  48px+ targets, active state, safe-area padding, hidden on desktop,
  no overlap (LIVE at 320/360/390/412/1280 — zero horizontal overflow).

## 13. UX/UI

- Category panel redesigned: grouped CONTENT / LIBRARY / APP, structured
  `data-cat-*` attributes (no label concatenation), 48px separate
  semantic rows with icons/active/pressed/focus states, bounded dynamic
  height with internal scrolling, scrim + grab + explicit Close.
- Responsive: no horizontal overflow at any tested width; the phone-frame
  demo embed in the Next.js center renders the real site.
- Blank-region fixes: teardown scroll-lock release + the new bounded sheet.
- Accessibility: aria-expanded/aria-controls/aria-current/aria-labels,
  44px+ targets, focus-visible rings, sr-only skip link, reduced-motion
  guards (carried forward + extended).

## 14. Performance

Evidence-based fixes only: the ambient canvas sampler self-terminates when
detached; per-mount duplicate listeners removed (fullscreenchange, outside
click, pagehide); the menu/DOM builders reuse one named handler; thumbnails
are lazy + bounded; first-4 priority loading preserved.

## 15. Security

initData HMAC validation (backend-only); sessions are AEAD cookies
(identity only, never access); no frontend hide_source surface; no secrets
in the demo (fake token); the demo autologin exists ONLY in the
mini-service, never in the production tree; the bot token never reaches
the frontend.

## 16. Database/Data Preservation

Additive only: schema stays v40, zero destructive migrations, the demo uses
its own DB file. No users/payloads/media/collections/points/progress/
force-join/delivery/bot configuration were reset in the production tree
(the production DB never ran here; the uploaded zip's DB was never touched).

## 17. Tests Added

- `tests/test_v25_production.py` — 127 checks across 10 sections
  (collection fixture→service→HTML, inner media, integrity, resume/
  start-over, settings/quality/speed, fullscreen machine + lifecycle,
  Hide Source COPY matrix (mocked transport, exact params), auto-auth +
  identity, category panel, FJ three-mode parity).
- Non-member/batch-isolation regressions for the live-caught A.4 bug.
- Updated pins (documented): b24 fullscreen mirror (intent-aware V25),
  a_prompt 1a naming, bot11 e2e + network G1 hide_source-OFF pinning,
  media_phase3 A7 (P<n> overlay).

## 18. Tests Executed

- `python -m py_compile` across every edited module (clean, no warnings).
- V25 suite: **127/127**.
- B24 regression: **53/53**.
- Full battery (`run_v25_battery.py`, 51 suites incl. every tests/ +
  root-level suite): **51/51 GREEN, 0 NOT GREEN**.
- `node --check` on the rendered player JS (syntax valid).
- `bun run lint` (Next.js tree) — clean.
- Browser (agent-browser): feed, mixed collection detail, player
  (play/seek/speed/settings/fullscreen/resume/start-over), categories
  sheet + chevron, search, collections, responsive widths, 8 fullscreen
  lifecycle cycles, VLM screenshot reviews.

## 19. Test Results

All green. The battery log: `/tmp/v25_battery.log` (51/51). The dashboard
at `/` renders live status + the per-suite table.

## 20. Live Telegram Verification

**Not available in this environment** (no real bot token / no outbound
Telegram API). Everything Telegram-transport-dependent is classified
MOCKED VERIFIED; the production evidence for delivery-readiness recovery
is the bot-30.log timeline (§8).

## 21. Mocked Verification

- Hide Source COPY matrix — mock bot clients recording every API call:
  exact method + parameter assertions for both settings.
- Force-Join live membership checks — mock `get_chat_member` statuses.
- Mode A relay E2E (bot11) and network G1 with hide_source pinned OFF.

## 22. Environment Limitations

- No live Telegram; the demo uses a Telegram WebApp SDK shim (demo-only
  glue) + HMAC-signed initData from the same signer the production login
  validates.
- The demo media gateway serves generated ffmpeg media (real bytes, real
  Range/206 seeking) instead of Telegram file storage.
- agent-browser network-route interception was non-functional in this
  environment; the SDK shim is served by the demo middleware instead.

## 23. Remaining Risks

- Live Telegram behavior of the Mini App fullscreen layer on real clients
  (structure + shim verified; real-client gesture matrix needs a device).
- The hide_source default (ON) means production deployments that never
  configured it will now route through Mode B (the COPY path) — this is
  the V25-mandated semantic, but operators should know Mode A relay will
  only run with hide_source explicitly OFF.

## 24. Final V25 Status

**COMPLETE.** All applicable acceptance criteria are satisfied with
evidence; the acceptance items that require a live Telegram deployment are
explicitly classified NOT VERIFIED LIVE rather than claimed. The
implementation — not merely the source — was verified through the live
browser golden path, the mocked transport matrix, and the full 51-suite
regression battery.
