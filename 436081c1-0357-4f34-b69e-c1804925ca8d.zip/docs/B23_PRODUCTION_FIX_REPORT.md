# B23 PRODUCTION FIX REPORT — the bot-23.log final pass (B18, in place)

**Release identity:** the CURRENT B18 codebase, repaired in place. No B19,
nothing renamed. Tree hash before packaging (sha256 of the sorted app
py-file hash list, 152 files):
`cb3f1050af998d042582294bfd58eca0995bcb134eb4a7188b369e6c897a9339`.

**Evidence baseline:** `/home/z/my-project/upload/bot-23.log` (the B22
build running schema v40; the 01:06 restart + the 01:11 normal-user
denial `reason=watch_ad_required` after FJ passed — the proof that the
B22 fix changed only the UI state, not the authorization path).

**Operator decision implemented:** **HYBRID delivery** — the FDB relays
Storage → Delivery Group; the Network Bot forwards Delivery Group → User;
the Network Bot needs **NO Storage access**.

---

## 1. Issue table (the directive issues + everything found)

| ID | Issue | Root Cause | Fix | Test | Runtime Proof | Status |
|----|-------|-----------|-----|------|---------------|--------|
| R1 | §1 Website Watch-Ad gate (bot-23: normal user 8922807758 denied `watch_ad_required` 3× at 01:11 AFTER Force Join passed) | The B22 pass changed the player's DENIAL RENDERING but not the authorization path — the site stream/access/pack issuance still denied with `watch_ad_required` | NEW `app/web/site/authz.py` `authorize_website_playback()` — the ONE website playback authorization chokepoint. Runs the SAME Access Engine and waives ONLY `reason=watch_ad_required` (safe: the engine emits it only AFTER the base policy authorized, so Force Join/referral/points stay enforced); logs `WEBSITE_PLAYBACK_WATCH_AD_WAIVED`. Wired into `handle_site_api_stream`, `handle_site_api_access`, `/site/api/pack` mint, `handle_site_pack` (re-auth) and `handle_site_hls`. The old watch-ad progress-denial BRANCH in stream.py is deleted (the condition is gone, not renamed) | tests/test_b23_website_watchad.py A1–A7, C1–C4 (31/0) | bot-23.log lines (01:11:15/26) vs the waiver log line; the Telegram-side gate preserved (B1/B2: the REAL engine still denies Telegram delivery; a rewarded unlock flips it) | FIXED |
| R2 | §2 HYBRID delivery (Mode A) | The network bot 8640674456 is NOT a member of Storage `-1004460709020` (its own `getChat` fails: `Chat not found`), so the old Mode A (network bot copies Storage→user) could never work. Operator decision: HYBRID | `app/network/file_delivery.py`: `FileDeliveryBotManager.relay_create_hybrid` (hop 1: the FDB's OWN client `copyMessage(Storage → Delivery Group)`), `_fdb_relay_create` wrapper (§2.5 START/SUCCESS lines) + `_classify_fdb_relay_failure` (§2.6 evidence pass, verdicts `storage_master_inaccessible`/`group_lost`/`bad_request`), `_forward_group_to_user` (hop 2: the NETWORK BOT `forwardMessage(Delivery Group → User)` — the user-facing send is attributable to the network bot, NEVER the FDB), `_mode_a_hybrid_relay` with the negative-capability cache + TTL + health-pass restore (re-probe via the FDB's client). Both relay self-heal paths (inline + retry plane) rebuilt on the hybrid hops. `NETWORK_DELIVERY_SUCCESS mode=hybrid_relay`. Diagnostics: `HYBRID_DELIVERY_DIAGNOSTICS` with per-identity attribution (`probed_fdb_hops`/`probed_network_bot_hops`); `NETWORK_BOT_STORAGE_ACCESS_MISSING` RETIRED (replaced by `HYBRID_MODE_NOT_READY` when hops fail) | tests/test_b23_hybrid_delivery.py (62/0); re-pinned: bot18 57/0, final1 52/0, bot12 18/0, bot11 27/0, network 80/0, bot13 19/0+45/0, bot16-relay 45/0 | Real Telegram API operation of the hybrid hops is ENVIRONMENT-BLOCKED in this sandbox (no production credentials) — see §5 | COMPLETE (code) |
| R3 | §2.3 Network bot identity check | A registered token could diverge from the live credential after a worker start | `app/network/workers.py` `start_worker` verifies the live identity after initialize: `NETWORK_BOT_IDENTITY_CHECK configured_bot_id/actual_bot_id/username/identity_match`; a MISMATCH refuses the worker (`NETWORK_BOT_IDENTITY_MISMATCH`) without breaking legitimate multi-bot operation | test_b23_hybrid_delivery.py §2.3 | — | COMPLETE |
| R4 | §2.4 /setup delivery wizard honesty | The wizard reported `DELIVERY_GROUP_READY` without naming the hybrid pipeline state | `app/presentation/telegram/delivery_ui.py`: the /setup report carries the separate `HYBRID_DELIVERY_READY=PASS/FAIL/UNKNOWN` line from the PERSISTED checks (never a fabricated PASS) | test_b23_hybrid_delivery.py §2.4 | — | COMPLETE |
| R5 | §3.1 Age-gate identity bypass (user A's age-approved cookie + user B's init_data) | The age_ok session flag was accepted from any session cookie regardless of the initData-verified caller | `pages.py` get-file + pack: session age_ok counts ONLY when `session.user_id == authenticated uid`; mismatch → the same honest 404 shape | test_b23_website_watchad.py D1–D5 | — | FIXED |
| R6 | §3.2 HLS age recheck (a long-lived HLS token must stop serving a listing that became age-restricted) | The HLS surface re-verified access but not the age state per request | `hls.py` `handle_site_hls`: identity-bound `_session_age_confirmed` + `_listing_age_restricted` recheck on EVERY segment/playlist request; unconfirmed/mismatched → the honest 404 shape (no existence leak) + `WEBSITE_HLS_AGE_DENIED`; fails closed | test_b23_website_watchad.py E1–E4 + the bot16 fixture update (see D5) | — | FIXED |
| R7 | §4.1 Multi-file rendering — **Photo 1 died with `naturalWidth=0`** (browser T3, 26/27) | **THE ROOT CAUSE (this pass):** ffprobe on a still JPEG reports its mjpeg stream as a VIDEO codec; `classify_browser_compatibility` read it as `transcode/mjpeg_video_codec`; the issuance minted an HLS ladder + `hls_url` FOR A PHOTO; the player mounted an `<img>` and `attachSource` ran `attachHls` on it — hls.js `attachMedia(<img>)` stamped a **MediaSource `blob:` URL** onto the image (the "persistent blob UUID") and the photo died (verdict "Playback error"). A SECOND crash path (already fixed at 05:12 pre-checkpoint): `setupPreRoll`/`mountPlayer` bound `el.play` on an `<img>` (TypeError → "Could not start playback") | **Three-layer fix:** (1) `stream.py` issuance — image media (`media_type photo/image` or `mime image/*`) NEVER enters the transcode/HLS machinery: `verdict=direct reason=image_media`, no `hls_url`, no `variants` (the transcode ladder is a VIDEO concept); (2) `html.py` `attachSource` — the HLS transports run ONLY for `<video>` elements (defense in depth, holds even if a future verdict regresses); (3) `html.py` `teardownMedia` — a lingering `blob:` src is revoked + cleared on EVERY teardown (the blob UUID can never survive) | test_b23_website_watchad.py **G1–G6** (issuance verdict, no hls_url/variants, the honest log line, both player-source guards) + browser T3/T3b (the real JPEG renders `naturalWidth>0`, no broken-video state) | Browser 27/27 on the REAL stack; the live diagnosis captured `imgSrc=blob:...`, `nw=0`, `verdict=transcode reason=mjpeg_video_codec` BEFORE the fix and a rendered photo after | **FIXED** |
| R8 | §4.1 six-file collection rendering (3 videos + 2 photos + 1 document) | Verified: nothing suppressed — detail page renders EVERY part with its own href, the player carries Part pills + prev/next, the document shows the honest not-streamable entry + Get File, per-file engagement independent | Fixture + browser proofs (no code change needed beyond R7) | browser T1/T1b/T1c/T2/T2b/T2c/T4/T4b/T5/T5b | — | VERIFIED |
| R9 | §4.2 Quality menu audit | Already compliant (levels from the real hls.levels / native variants; single-variant → hidden; Auto adaptive; the B22 persistence intact) | No change (audit) | browser_qa16 45/45 | — | VERIFIED |
| R10 | §4.3 Back button / internal history | The site had no internal history: platform Back closed the Mini App | NEW `_SITE_NAV_JS` (every page): same-origin /site links become fetch-and-swap transitions (`<main>` + `<title>` + category nav swap in place; swapped scripts re-execute), `history.pushState` per internal navigation, popstate restores from an in-memory snapshot cache with per-URL scroll positions, `.backlink` walks the history stack, modal-first back ordering, Telegram `BackButton` shown deeper than root / hidden at root with `onClick → history.back()`, same-URL clicks replaceState (no runaway entries), failed fetches fall back to honest full navigation, plain `<a>` works without JS | browser T6/T6b/T6c/T6d/T6e/T7/T7b/T7c/T7d | — | COMPLETE |
| R11 | §4.4 Telegram fullscreen | The toggle went straight to the container/video/pseudo chain, ignoring the platform API | `toggleFullscreen`: `Telegram.WebApp.requestFullscreen()` is PATH 0 (available + `isVersionAtLeast('8.0')`); `exitFullscreen` on toggle-out; `fullscreenChanged`/`fullscreenFailed` listeners keep the icon truthful; a rejected Telegram promise falls THROUGH to the FINAL-1 container → video → CSS pseudo chain → honest toast | browser T8/T8b/T8c (the stub records the API calls); final1 11/11 (the desktop chain in the plain-browser context) + qa16 G17 + qa17ux C4 re-verified | — | COMPLETE |
| R12 | §5 repository-layer audits (§5.1/§5.3/§5.4/§5.6/§5.7/§5.9/§5.10/§5.11/§5.13/§5.14/§5.15/§5.19) | Independent audit by a dedicated agent, verified by main | All items either FIXED with a regression or confirmed NOT A BUG with evidence (shared write lock, referral semantics, FJ link health reset, watch-ad clamp, feed SQL dead join, reaction transaction, category COALESCE, named-column access, module scoping, schema v40 agreement, session codec pipe-safety) | tests/test_b23_repo_audits.py (64/0) — **wired into the battery this pass** (it was missing from the suite list) | — | COMPLETE |
| D1 | `test_bot11_video_ads_youtube_flow` 6d failed: the location.href allowlist predated the B23-4 nav layer | The new `_SITE_NAV_JS` honest full-navigation fallbacks (`window.location.href = url` — an INTERNAL /site link) tripped the old "no Telegram redirect" pin | The pin now accepts a bare `url` RHS (exactly the two nav fallbacks) and still asserts no `t.me` write exists | bot11 26/0 | — | FIXED |
| D2 | `test_bot16_transcode` §12 failed: every HLS request 404'd | The B23-1 §3.2 age recheck consults the DB's listing categories; the suite's `_DBStub` (only `get_setting_bool`) failed the lookup → the recheck failed CLOSED → 404 (correct production behavior; the fixture lacked the production request shape) | The fixture's ClientSession now carries a signed age-CONFIRMED site-session cookie for the token's own user (uid 4242) — exactly the real confirmed-viewer shape; the recheck passes without the DB lookup | bot16_transcode 149/0 | — | FIXED |
| D3 | certifi `cacert.pem` vanished from the venv AGAIN (decoupling suite 500s of httpx SSL failures) | Recurring sandbox file-loss (documented twice before) | Restored from `/home/z/.venv` (272,441 bytes) | decoupling 51/0 | — | REPAIRED |
| D4 | The QA server's SDK swap missed `screens.py` pages — the REAL telegram.org SDK leaked into the QA browser (login/Join/age pages) and ran in 6.0 mode | `screens.py` binds `_page` DIRECTLY (`from .html import _page`); the QA's module-attribute monkeypatch never covered it. The B23-4 BackButton calls then produced real SDK warnings ("BackButton is not supported in version 6.0") | The QA server patches the `screens` binding too (every page the QA stack renders now carries the deterministic 8.0 stub) | b22 T10; the live tag check (login + feed → `/qa-sdk.js`) | — | FIXED |
| D5 | BackButton calls on real pre-6.1 clients | `syncBackButton` called `show()/hide()` unconditionally — the API exists from Bot API 6.1; older clients (and the real SDK outside Telegram) log a warning per call | Version gate: `isVersionAtLeast("6.1")` before any BackButton use (the site history is REAL history entries — the platform back control keeps working on old clients; the Telegram BackButton is an enhancement) | b22 T10 zero warnings; b23 T7 still passes (the 8.0 stub reports ≥6.1) | — | FIXED |
| D6 | `run_battery.sh` resume was broken (every suite re-ran on every invocation; duplicate summary rows) + `test_b23_repo_audits.py` missing from the list | The B23-1 rewrite corrupted the awk `-F` separator (tab → spaces); the suite list predated B23-3 | FS repaired to `-F'\t'`; the repo-audits suite added (47 total) | 47/47 summary rows, instant resume, `BATTERY COMPLETE: ALL GREEN` | — | FIXED |
| D7 | Browser harnesses measured the shared session's PERSISTENT console buffer (stale entries from earlier runs) | `agent-browser console` is per-session and the derived worktree session is shared across QA scripts and manual diagnostics | b22 + final1 clear the console at run start (T10/T5 measure THIS run only) | b22 33/33, final1 11/11 | — | FIXED |
| D8 | Desktop-fullscreen tests (final1 T1–T4, qa16 G17, qa17ux C4) conflicted with the new Telegram-API path 0 | The B23-4 §4.4 change correctly intercepts the click when an 8.0 Mini App surface is present — the desktop tests assumed no Mini App | The harnesses simulate the plain-browser context (`delete window.Telegram`) before the desktop-chain checks; the Telegram path 0 is proven separately by b23 T8 | final1 11/11, qa16 45/45, qa17ux 37/37 | — | FIXED |

---

## 2. The §4.1 photo root cause — the full forensic chain (this pass)

The checkpoint symptom: browser T3 "Photo 1 renders as a real image"
failed with the `<img>` stuck at `naturalWidth=0` while T3b (no broken
VIDEO state) "passed" — the verdict text was actually
**"Could not start playback. Check your connection and reload the page."**

1. The pre-checkpoint fix (05:12, committed in 02390e7) removed the two
   `<img>` crash paths: `mountPlayer` binds `el.play` only for
   VIDEO/AUDIO, and `setupPreRoll` uses a no-op `innerPlay` when
   `.play` is absent. The QA was never re-run after that edit.
2. This pass re-ran the QA: **T3 still failed** — so a third defect
   remained. Live diagnosis (real QA server + real Chromium):
   `imgSrc=blob:http://127.0.0.1:8080/21ec8cef-…`, `nw=0`, and the
   server log `WEBSITE_PLAYER_FORMAT … verdict=transcode
   reason=mjpeg_video_codec hls=yes variants=2` **for the photo**.
3. The chain: ffprobe reports a JPEG still as one mjpeg VIDEO stream →
   the video classifier (correctly, for video) says
   `transcode/mjpeg_video_codec` → the issuance mints a 6-hour HLS
   token + variant ladder for a PHOTO → the player mounts `<img
   class="pimg">` → `attachSource` sees `verdict=transcode && hls_url`
   → `attachHls(<img>)` → hls.js attaches a MediaSource and stamps its
   `blob:` object URL onto the image → the image can never decode it
   (`naturalWidth=0`) and the "persistent blob UUID" survives on the
   element until teardown.
4. The fix (three layers, R7): image media is ALWAYS direct at the
   issuance (the semantically correct layer — the transcode ladder is a
   video concept); the player never runs HLS on a non-VIDEO element
   (defense in depth); teardown revokes any lingering `blob:` URL.
5. Pinned at BOTH levels: unit G1–G6 (issuance + source guards) and
   browser T3 (the real JPEG renders).

---

## 3. Files changed (this pass, on top of the committed B23-1..4 work)

- `app/web/site/stream.py` — the image-media issuance gate (R7 layer 1).
- `app/web/site/html.py` — `attachSource` VIDEO-only HLS guard (R7
  layer 2); `teardownMedia` blob-URL revocation (R7 layer 3);
  `syncBackButton` Bot-API-6.1 version gate (D5).
- `tests/test_b23_website_watchad.py` — the §4.1 [G] photo regression
  section (G1–G6).
- `tests/test_bot11_video_ads_youtube_flow.py` — the 6d allowlist update
  (D1).
- `tests/test_bot16_transcode.py` — the HLS-smoke session-cookie fixture
  (D2).
- `tests/qa_bot16_browser_server.py` — the screens `_page` stub patch
  (D4).
- `battery/browser_qa_b22.py`, `battery/browser_qa_final1.py` — console
  clear at run start (D7); final1 additionally the plain-browser
  context for the desktop chain (D8).
- `battery/browser_qa16.py`, `battery/browser_qa17_ux.py` — the
  plain-browser context for G17/C4 (D8).
- `battery/run_battery.sh` — the resume FS repair + the repo-audits
  suite (D6).

## 4. DB changes

None this pass (schema **v40**, established by the B22 pass:
`media_view_events` + `media_reactions` + `website_handoffs`; additive,
idempotent; v36–v39 databases upgrade in place on startup — re-verified
by the battery's schema-pinning suites on THIS tree).

## 5. Security audit (this pass)

- The age-gate identity binding (§3.1) and the HLS age recheck (§3.2)
  are pinned by D1–D5/E1–E4.
- The photo fix introduces no new trust surface: image media is served
  through the SAME AEAD stream tokens + per-request Access Engine
  re-verification; the `<img>` surface inherits the same origin policy.
- The `blob:` revocation closes a minor resource-leak vector (a
  MediaSource URL left referenced by a removed element).
- The back-button version gate changes no trust decision (navigation
  only).
- Secret scan (this release, both zips' own extractions): 0 findings.

## 6. Verification matrix

| Verification | Result |
|---|---|
| Full battery (`battery/run_battery.sh`) | **47/47 suites, 3,364 checks, 0 failures** (`battery_results/b23/summary.tsv`) |
| Browser: B23 §4.1/§4.3/§4.4 (`browser_qa_b23.py`) | **27/27** (six-file rendering, photo T3, parts nav, engagement independence, SPA history, BackButton, Telegram fullscreen API, 320px responsive + sticky footer, zero console errors) |
| Browser: B22 engagement/handoff chain (`browser_qa_b22.py`) | **33/33** |
| Browser: fullscreen chain (`browser_qa_final1.py`) | **11/11** (desktop chain in the plain-browser context) |
| Browser: HLS/transcode/quality (`browser_qa16.py`) | **45/45** |
| Browser: B17 UX (`browser_qa17_ux.py`) | **37/37** |
| Clean-extraction verification | compileall clean; fresh-DB startup smoke (schema v40 applies); key suites re-run FROM the extraction; secret scans 0 findings (see §7) |

## 7. Honest verification status (Section 8 discipline)

- **VERIFIED (this sandbox, real runtime):** every code change above —
  through the real aiohttp stack, the real SQLite schema v40, the real
  ffmpeg/ffprobe pipeline, and real Chromium browser sessions against
  the real site code (all numbers in §6).
- **SIMULATED (harness models of external realities):** the Telegram
  Mini App surface (the 8.0-shaped stub; the BackButton + fullscreen
  API contracts), the QA media gateway (real AEAD tokens + the real
  resolver, local byte serving), the plain-browser / restrictive /
  rejecting WebView contexts in the browser harnesses.
- **ENVIRONMENT-BLOCKED (requires production Telegram credentials,
  unavailable in this sandbox):** real Telegram API operation of the
  HYBRID delivery hops (the FDB relay create + the network bot
  forwardMessage against the live Storage channel −1004460709020 and
  Delivery Group −1003963643527); the production end-to-end journey of
  a real normal (non-admin) user; the live VAST tag fill. The expected
  production success lines are documented: `FDB_RELAY_CREATE_SUCCESS`,
  `NETWORK_DELIVERY_SUCCESS mode=hybrid_relay user_msg=<id>` — and, if
  the network bot has not yet been added to the Delivery Group,
  `HYBRID_MODE_NOT_READY` with its remediation.

**Deployment actions (unchanged from the B23 analysis):** add the
network bot to the Delivery Group if not already an admin there (the
hybrid hop 2 requires it); Mode A Storage membership is NO LONGER
required for the network bot under the HYBRID architecture.
