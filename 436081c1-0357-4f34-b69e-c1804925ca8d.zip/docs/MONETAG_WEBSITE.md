# Monetag — Website Integration & Worker Hardening (WS-B)

This document is the single source of truth for the Monetag **WEBSITE**
integration (spec §19-§21) and the Cloudflare worker hardening
(spec §24-§28). Related code: `app/web/website_monetag.py`,
`app/web/server.py`, `cloudflare/worker.js`, `cloudflare/wrangler.toml`,
test suite `test_website_monetag_v35.py`.

---

## 1. The TWO integration surfaces (spec §19) — never mix them

| | **Telegram Mini App (Watch Ads)** | **Website (/site)** |
|---|---|---|
| Provider tag | `<script src='//libtl.com/sdk.js' data-zone='11742509' data-sdk='show_11742509'></script>` (TMA SDK) | **NOT SUPPLIED YET** — must come from the Monetag account (§3) |
| Service worker | — | `https://<domain>/sw.js` (root scope, zone `11800971`, domain `3nbf4.com`) — **deployed in the repo** (§2) |
| Where it renders | `GET /watch-ad/{token}` ONLY | every `/site` HTML page `<head>` (when configured) |
| Config storage | DB setting `watch_ads_monetag_sdk` | DB setting `website_monetag_ad_tag` OR env `WEBSITE_MONETAG_AD_TAG` |

### Current wiring (verified in code)

The libtl.com TMA script is **not hard-coded in the repo** — it is the
production value of the `watch_ads_monetag_sdk` database setting. The
complete chain:

* `app/presentation/telegram/text_input.py:268` — the admin pastes the SDK
  tag; stored via `db.set_setting("watch_ads_monetag_sdk", ...)`
  (validation: `app/core/watch_ads/service.py:78`
  `validate_watch_ads_sdk_code`).
* `app/core/watch_ads/service.py:149` — `get_watch_ads_global_config()`
  loads the setting (`sdk_code`).
* `app/presentation/telegram/miniapp.py:763-767` — `_wad_handle_page`
  renders the Mini App page for a valid pending watch-ad session and
  embeds the SDK verbatim.
* `app/presentation/telegram/miniapp.py:143` — `{sdk_code}` is injected
  into the `<head>` of the **Watch Ads Mini App page only** (the
  `_wad_mini_app_page` template served at `GET /watch-ad/{token}`).

The website renderer (`app/web/site/pages.py` + `app/web/site/html.py`)
has **zero** references to libtl.com / the TMA SDK / zone 11742509 —
verified by grep across `app/` and asserted live by
`test_website_monetag_v35.py` (§4 of the suite: `/site` never contains
`libtl.com`, before AND after the TMA SDK is configured).

**Rule:** the TMA SDK (libtl.com, zone 11742509) must NEVER load on
`/site`, and the website ad tag must NEVER load on `/watch-ad/{token}`.
`app/web/website_monetag.py` enforces this structurally: the head
injection middleware only matches `/site` HTML pages, and
`validate_website_ad_tag` rejects any tag referencing libtl.com or the
zones 11742509 / 11800971.

---

## 2. Service worker at the domain root (spec §20) — DONE

Monetag website integrations register the provider service worker at
**root scope**: the file MUST answer at `https://<domain>/sw.js`
(**not** `/site/sw.js`). Because it is served at the root, the
`Service-Worker-Allowed` header is NOT needed.

Implementation:

* The uploaded provider file is stored **verbatim** at
  `app/web/static/sw.js` (156 bytes: domain `3nbf4.com`, `zoneId`
  11800971, `importScripts('https://3nbf4.com/act/files/service-worker.min.js?r=sw')`).
  **Never edit it, never replace it, never change domain/zone.**
* `app/web/website_monetag.py :: handle_website_sw_js` serves those
  exact bytes at `GET /sw.js` — public (no auth),
  `Content-Type: application/javascript`, `Cache-Control: no-store`
  (so a provider-side worker update is picked up on the next navigation;
  `max-age=600` would also be acceptable), `X-Content-Type-Options:
  nosniff`.
* Route registered in `app/web/server.py` (before the site routes);
  path constant `WEBSITE_MONETAG_SW_PATH` in `app/web/routes.py`.
* The worker allowlist now includes `/sw.js` (see §5) so the file is
  reachable at **https://shy-leaf-cac1.kyahuyaphirse.workers.dev/sw.js**.

Verification after deploy:

```bash
curl -sS -D - https://shy-leaf-cac1.kyahuyaphirse.workers.dev/sw.js
# expect: HTTP/2 200, content-type: application/javascript,
#         cache-control: no-store, and the exact 156 provider bytes
```

---

## 3. Website ad-zone tag (spec §21) — integration POINT, tag REQUIRED

The actual Monetag **website** ad-zone `<script>` tag was **not
supplied** (only the SW file and the TMA SDK were). No provider code is
fabricated: the deployment implements a clean, validated configuration
point, and the tag must be obtained from the Monetag account (the
website zone created there).

### Configuration (two equivalent ways)

1. **Database setting (recommended — admin-configurable):** the generic
   settings store (`bot_settings` table, the same mechanism as
   `website_enabled` / `watch_ads_monetag_sdk`):

   ```sql
   INSERT INTO bot_settings(key, value) VALUES
     ('website_monetag_ad_tag',
      '<script src="https://<provider-domain>/tag.js" data-zone="<WEBSITE-ZONE>"></script>')
   ON CONFLICT(key) DO UPDATE SET value = excluded.value;
   ```

2. **Environment fallback:** `WEBSITE_MONETAG_AD_TAG` (documented in
   `.env.example`). The DB row always wins when set.

### Behavior

* **When set and valid:** the tag is injected into the `<head>` of every
  `/site` HTML page, immediately before `</head>` — the exact position
  the site renderer's `head_extra` mechanism occupies. (Implemented as a
  response middleware in `app/web/website_monetag.py`, wired in
  `app/web/server.py`, because `app/web/site/pages.py` / `html.py` are
  owned by a parallel workstream; `website_monetag_head_html()` is
  exported so the renderer can adopt `head_extra` directly later.)
* **When unset:** NOTHING is injected anywhere, and the diagnostics
  report exactly: `website ad tag: NOT CONFIGURED (provider tag required)`
  (server startup log + `GET /api/website/monetag-status`).
* **Validation** (`validate_website_ad_tag`): max 4096 chars; must be
  ONLY `<script>…</script>` tags (no other markup); every `src` must be
  `https://` or protocol-relative `//`; **rejects** libtl.com (TMA
  surface) and zones `11742509` / `11800971` (the website tag must be
  its own provider zone).
* **Diagnostics endpoint:** `GET /api/website/monetag-status` — JSON
  (no raw tag, no secrets):

  ```json
  {"ok": true, "service": "monetag-website",
   "service_worker": {"path": "/sw.js", "available": true, "bytes": 156, "scope": "/"},
   "website_ad_tag": {"configured": false, "source": null,
                      "message": "website ad tag: NOT CONFIGURED (provider tag required)"},
   "tma_separation": {"watch_ads_sdk_setting": "watch_ads_monetag_sdk",
                      "renders_on": "GET /watch-ad/{token} only"}}
  ```

---

## 4. Cloudflare worker hardening (spec §24-§28) — cloudflare/worker.js

Evolution of the previously deployed worker; full rationale in the file
header. Summary of the changes:

1. **`/sw.js` allowlisted** (+ `/api/website/monetag-status` for
   deployment verification). Nothing else was added to the allowlist.
2. **Path safety:** the pathname is percent-decoded and validated
   (malformed encoding, NUL, `..` traversal, `//` double slash → 404)
   BEFORE allowlist matching; the **original encoded path** is forwarded
   (no re-encoding smuggling).
3. **Media streaming:** request headers forwarded verbatim (only
   `Host` / `X-Forwarded-For` / `X-Real-IP` deleted — Range survives);
   response headers copied wholesale (Content-Range, Accept-Ranges,
   Content-Length, ETag, Last-Modified, Cache-Control…); statuses
   preserved verbatim (206/416 included); body never buffered (native
   Workers streaming); `redirect: "manual"` kept.
4. **OPTIONS passes through** to the origin (origin CORS governs;
   bodyless init is fine for a bodyless method).
5. **Security headers:** `X-Content-Type-Options: nosniff`,
   `Referrer-Policy: strict-origin-when-cross-origin`,
   `Permissions-Policy: camera=(), microphone=(), geolocation=()`.
   **CSP:** commented template only — the live site uses inline
   scripts/styles, so enabling a CSP requires either `'unsafe-inline'`
   (weak) or a nonce/hash refactor; the template lists the needed
   Monetag domains (`https://telegram.org`, `https://libtl.com`,
   `<PROVIDER-DOMAIN-FROM-TAG>`).
6. **HSTS deliberately not set** on `*.workers.dev` (Cloudflare already
   forces HTTPS at the edge before the worker runs; HSTS would pin a
   policy onto a shared cert domain for no benefit). Revisit with a
   custom domain.
7. **Origin exposure (verified live — the origin is publicly reachable
   over plain HTTP):**
   * Firewall origin port 25672 to Cloudflare IP ranges
     (https://www.cloudflare.com/ips/).
   * Optional shared secret: the worker injects `X-Origin-Key` from the
     `ORIGIN_PROXY_SECRET` **Worker secret**
     (`npx wrangler secret put ORIGIN_PROXY_SECRET` — never hardcoded),
     and the aiohttp server, when started with the same
     `ORIGIN_PROXY_SECRET` env, rejects (403) any request without the
     header (`app/web/website_monetag.py ::
     make_origin_proxy_middleware`, wired in `app/web/server.py`).
     Default: env unset → guard OFF → zero behavior change.
8. **Request smuggling:** `Content-Length`/`Transfer-Encoding` conflicts
   cannot be injected through a Workers `fetch()` (the runtime owns
   framing and re-serializes the request).

---

## 5. Deployment runbook (order matters)

1. **Deploy the app** (this repo — includes `/sw.js`,
   `/api/website/monetag-status`, the ad-tag injection point and the
   optional origin-secret guard).
2. **Redeploy the worker** from `cloudflare/`:
   ```bash
   cd cloudflare
   npx wrangler deploy          # verify worker name first: npx wrangler whoami
   ```
3. **Verify the SW** (spec §20):
   ```bash
   curl -sS -D - https://shy-leaf-cac1.kyahuyaphirse.workers.dev/sw.js
   ```
   → 200, `application/javascript`, exact 156 provider bytes.
4. **Verify diagnostics** (spec §21):
   ```bash
   curl -sS https://shy-leaf-cac1.kyahuyaphirse.workers.dev/api/website/monetag-status
   ```
   → `website_ad_tag.message` = `website ad tag: NOT CONFIGURED (provider tag required)`.
5. **Get the website ad-zone tag** from the Monetag account (website
   surface — a NEW zone; NOT 11742509, NOT 11800971) and configure it
   (DB setting `website_monetag_ad_tag` or env
   `WEBSITE_MONETAG_AD_TAG`).
6. **Re-verify:** `/site` HTML now contains the tag in `<head>`;
   `/api/website/monetag-status` reports `configured (source=…)`.
7. **Optional hardening:** set the same secret on both sides —
   `npx wrangler secret put ORIGIN_PROXY_SECRET` (worker) and
   `ORIGIN_PROXY_SECRET=…` env on the aiohttp server — then restart the
   app. Verify direct origin access without the header now returns 403.
   Firewall the origin to Cloudflare IP ranges.

## 6. Tests

`test_website_monetag_v35.py` (run with the project venv):

* `GET /sw.js` on the REAL server harness (`B.start_mini_app_server`)
  → 200, EXACT uploaded bytes, `application/javascript`, no auth.
* `/site` never contains `libtl.com` (before/after the TMA SDK is
  configured).
* `GET /watch-ad/{token}` contains the TMA SDK when configured.
* Ad-tag injection: set → in `/site` `<head>`; unset → absent +
  diagnostics say NOT CONFIGURED (+ validator separation rules).
* Origin proxy secret: with secret set, request without `X-Origin-Key`
  → 403, with the header → 200 (middleware tested directly AND on the
  real server).
* `node --check cloudflare/worker.js` (skipped silently when node is
  absent).

---

## 7. VAST capability — the EXACT supported surface (BOT-13 §50 audit)

The website pre-roll (`app/web/site/video_ads.py` + the player's client
adapter in `app/web/site/html.py`) supports PRECISELY this — nothing
more is claimed:

| Capability | Status | Detail |
|---|---|---|
| VAST **Inline** Linear ads | **SUPPORTED** | first `<Ad><InLine>` whose `<Creative><Linear>` carries an `mp4`/`webm` `<MediaFile>` (highest bitrate wins; first-mp4 tiebreak) |
| `skipoffset` | **SUPPORTED** | `HH:MM:SS(.mmm)` / `MM:SS` / plain seconds — `provider_controlled` mode: present ⇒ skippable after it; absent ⇒ strictly non-skippable |
| `Duration` | **SUPPORTED** | drives the honest countdown (never fabricated) |
| Impression / Error / ClickTracking beacons | **SUPPORTED** | no-cors beacon firing |
| VAST **Wrapper** (nested tag chaining) | **NOT SUPPORTED** | a Wrapper-only `<Ad>` is skipped → the honest **no-fill** path (§14 failure policy; content continues) |
| VMAP | **PARTIAL** | a VMAP document's first playable InLine ad is found (pre-roll only — the parser searches the whole document for `<Ad><InLine>`); VMAP ad-break scheduling is NOT implemented |
| Direct media (`.mp4`/`.webm` URL) | **SUPPORTED** | the `direct` provider — skippable/non-skippable per `website_preroll_mode` |

The provider stays **provider-independent**: the player understands the
`PRE_ROLL` slot + the `vast|direct|none` provider decision — never a
specific ad network (HilltopAds/Monetag URLs are ADMIN values).

---

## 8. BOT-26 — the WEBSITE_MONETAG_ENABLED diagnostic switch

Production context (bot-26): the website rendered as a SOLID GREEN page
on Telegram Android. The investigation (see
docs/BUXFIX_PRODUCTION_REPORT.md) isolated the green screen to a
malformed `<body>` tag in the site's OWN HTML (fixed in
`app/web/site/html.py::_page`) — NOT to Monetag. Because a third-party
layer (the provider service worker at root scope + the injected ad-tag
script) can never be fully ruled out from server logs alone, this
release adds a SAFE, REVERSIBLE diagnostic switch so an operator can
isolate the ad/service-worker layer WITHOUT removing the monetization
configuration:

| `WEBSITE_MONETAG_ENABLED` | `/sw.js` answers | Ad tag | Status endpoint |
|---|---|---|---|
| unset / `true` (DEFAULT) | provider bytes VERBATIM (unchanged) | injected when configured (unchanged) | `enabled: true` |
| `false` / `0` / `no` / `off` | the DIAGNOSTIC NO-OP worker (self-unregistering — it actively removes a previously-registered third-party worker from controlling clients and reloads them) | NOT injected (the db/env configuration stays untouched) | `enabled: false` + `DISABLED` message |

Properties (production-fix brief §6/§8):

* The production default is UNCHANGED (enabled) — no silent behavior
  change; the disabled state is loud in the startup log (`WARNING`).
* The Telegram Mini App (Watch Ads) surface is NEVER affected — the
  switch only governs the WEBSITE surface (`/sw.js` + `/site` head
  injection).
* The no-op worker is served STRICTLY behind the disabled flag — the
  provider file is never replaced in the enabled state.
* With the switch disabled the website (HTML/CSS/JS, B23 navigation)
  must remain FULLY functional — covered by
  `tests/test_buxfix_production.py` §4 + the browser QA sweep.
* `GET /api/website/monetag-status` reports the switch state, so the
  isolation is verifiable remotely.

Recovery path for a client poisoned by a third-party worker: set
`WEBSITE_MONETAG_ENABLED=false`, restart, have the user reopen the site
(the no-op worker unregisters the old one and reloads the client), then
re-enable. No data loss — the ad-tag configuration is untouched.

## 9. BOT-26 — dynamic /site HTML cache hardening

Every `/site` HTML page is a per-request render (session-aware chrome,
force-join state, shelves) — there is no reusable representation, so
since BOT-26 the production server (and the QA browser server) answers
every `/site`/`/site/*` `text/html` 200 with:

```
Cache-Control: no-store, no-cache, must-revalidate, max-age=0
Pragma: no-cache
Expires: 0
```

implemented by `make_site_html_cache_middleware` (innermost middleware —
the Monetag head-injection rebuild carries the headers through).
Media streams, HLS playlists/segments, thumbs, zip packs and JSON APIs
keep their own content-appropriate cache policies — the middleware
matches `/site` `text/html` 200 responses only. The site's JS/CSS is
INLINE in the HTML (no separate app-owned assets), so these HTML headers
are the COMPLETE cache-busting story — no asset versioning is needed.
