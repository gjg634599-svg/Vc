# WEBSITE PHASE 0 AUDIT — Architecture-Aware Mini App + Payload Website + Large-Media Streaming

> MANDATORY pre-implementation audit (spec §0). Produced BEFORE any code change.
> Source of truth: `payload-bot_architecture_phase.zip`, extracted to a CLEAN
> directory (`site-work/payload-bot`) — not the drifted working trees.
> Every fact below was verified by reading the code in this build; every test
> below was EXECUTED by this build (none trusted from prior reports).

## 1. Baseline verification (executed 2026-09-11, this build)

Environment: Python 3.12.14, python-telegram-bot 22.8, aiosqlite 0.22.1,
aiohttp 3.13.3, cryptography present (venv rebuilt — the sandbox was reset).

| Suite | Checks | Result (executed) |
|---|---|---|
| test_watch_ads.py | 91 | 0 failed |
| test_watch_ads_v2.py | 142 | 0 failed |
| test_watch_ads_v3.py | 104 | 0 failed |
| test_watch_ads_v4.py | 153 | 0 failed |
| test_watch_ads_v5.py | 142 | 0 failed |
| test_watch_ads_v6.py | 113 | 0 failed |
| test_watch_ads_v7.py | 85 | 0 failed |
| test_botv13_phase6.py | 124 | 0 failed |
| test_botv13_phase7.py | 151 | 0 failed |
| test_botv13_phase7_hotfix.py | 94 | 0 failed |
| test_botv13_phase8.py | 77 | 0 failed |
| test_network.py | 79 | 0 failed |
| test_architecture.py | 96 | 0 failed |
| **TOTAL** | **1,451** | **0 failed** |
| run_phase8_evidence.py | 24 sections | ALL PASS (exit 0) |
| run_network_evidence.py | 19 sections | ALL PASS (exit 0) |

**Baseline is GREEN → the Architecture Phase ZIP is the confirmed canonical
baseline. Proceeding is authorized.**

Audit finding A-1 (test-env robustness, NOT production): `test_architecture.py`
uses `os.environ.setdefault("ADMIN_IDS", "1001")`; when the environment
contains an EMPTY `ADMIN_IDS=` the setdefault is a no-op and `import bot`
raises the security ValueError. Production is unaffected (a real deployment
always has a non-empty value). Fix in a later phase: `os.environ["ADMIN_IDS"]
or "1001"` guard or explicit override in the suite.

## 2. Current state (verified facts)

* `bot.py` = **27,751 lines** — compatibility facade + pinned frozen zones +
  legacy admin UI + bootstrap wiring. **Rule in force: no new business logic
  in bot.py** (docs/BOT_COMPATIBILITY.md).
* `app/` = 58 modules: bootstrap / bot(handlers,callbacks,keyboards) /
  core(access,payload,delivery,force_join,referral,watch_ads,indexing,
  verification,constants,format) / network(6) / storage(database,migrations,
  dbutil + 10 repository mixins, 236 methods) / web(application,auth,routes,
  watch_ads) / media(interfaces ABCs) / services(container).
* Schema **v29** (43 tables). SQLite via aiosqlite, WAL, foreign_keys ON,
  single write_lock + BEGIN IMMEDIATE idiom.
* In-process aiohttp Mini App server (`start_mini_app_server`, port 8080,
  `MINI_APP_ENABLED` gate) with 6 routes — Watch Ads page + network auth.
* Mini App initData validation (official HMAC-SHA256 WebAppData scheme) in
  `app/web/auth.py` — **bound to the main BOT_TOKEN only**.
* Access Engine: `access_engine()` (pinned shell in bot.py) returns
  `AccessResult` (authorized/policy/reason/FJ batch/Watch-Ads/Points context);
  semantics = Force Join AND (Referral OR Watch Ads OR Points OR Admin bypass).
* Delivery: `send_file` = file_id primary + PROACTIVE (stale epoch) and
  REACTIVE ("Wrong file identifier") source recovery with atomic in-place
  file_id repair + retry-once; copy fallback guarded by hide_delivery_source;
  network bots use native source copy (`copy_message`) — never cross-bot
  file_id reuse, never file_unique_id in send APIs.
* Payload model: `payloads.index_id → indexed_files` (single-file payloads);
  multi-file = `collections` + `collection_items` (position ordering). There
  is NO `payload_files` join table, NO payload description/tags/thumbnail, and
  NO mime_type/thumbnail/width/height in `indexed_files` (capture is 7 keys in
  `extract_media`).
* Search: `search_payloads_fuzzy` — escaped LIKE prefilter + Python ranking
  (100/80/60/50/30), AND semantics, hashtag-aware tokenization; currently
  ranks ALL prefiltered rows in memory (limit=100000 call shape).
* Callback dispatch: single `on_callback` chain (327 branch checks) with the
  `app/bot/callbacks/router.py` registry live but not yet owning production
  namespaces. **`wsite:` / `web:` / `site:` prefixes are FREE** (verified —
  zero collisions in bot.py and app/**).
* Admin Control Center: `main_panel_keyboard()` root + `panel:` dispatch;
  integration point for `panel:website` confirmed (same pattern as
  `panel:wadsettings`).
* Auto Delete: pending_deletions DB + task tracker; admin panels/retrieve
  cards are persistent by design; browse 10s; previews configurable.

## 3. Component audit (the required map)

Legend — Reusable: ✅ as-is | 🔄 reuse with extension | 🆕 new (in app/*, never bot.py)
Bug?: verified defects found by THIS audit.

| # | Component | Current implementation | Reusable? | Bug? | Required change | Risk | Dependencies |
|---|---|---|---|---|---|---|---|
| 1 | Entrypoint/bootstrap | run.py → app.main → bot.main → build_application (pinned wrapper) + create_application | ✅ | — | None (website rides the same process/aiohttp app) | LOW | PTB |
| 2 | aiohttp server | `start_mini_app_server` (bot.py, pinned route lines), 6 routes, 0.0.0.0:8080 | 🔄 | — | ADD new website route lines AFTER the pinned ones (pins are membership `in src` checks — additive lines are safe; tests call with `bot=None` so registration must stay None-safe) | LOW | aiohttp |
| 3 | Web lifecycle | `app/web/application.py` WebServerLifecycle (currently unused by bot.py) | ✅ (future) | — | Optionally adopt later; not required now | LOW | aiohttp |
| 4 | WebApp auth | `app/web/auth.py` HMAC initData validators (two) | 🔄 | GAP: main BOT_TOKEN only — a Mini App launched from a NETWORK bot signs initData with that bot's token → 401 today | Multi-token validator (main + ACTIVE network bots) for website auth | MED | BOT_TOKEN, network registry |
| 5 | Access Engine | `access_engine` pinned shell + `AccessResult` in app/core/access | ✅ | — | Website calls `access_engine` (injected callable) — NEVER `enforce_access` (9-call-site pin) and NEVER a website_off branch (spec §6/§32) | MED (pin discipline) | db, FJ, WA, referral, points |
| 6 | Watch Ads engine | server-authoritative S2S state machine + pinned session/reward DB methods + mini app page | ✅ | — | None in engine; website reuses sessions + unlock checks verbatim | LOW | db, aiohttp |
| 7 | Force Join | app/core/force_join/service.py tri-state machine + link health | ✅ | — | None (website verdicts flow through access_engine) | LOW | db |
| 8 | Referral | app/core/referral/service.py | ✅ | — | None | LOW | db |
| 9 | Points | app/network/points.py + ptunlock atomic txn | ✅ | — | None | LOW | db |
| 10 | Delivery (Telegram) | `_deliver_files_core` (pinned) + `send_file` (recovery) + `send_album` | ✅ | — | None for Telegram path; website streaming does NOT reuse send_file (goes through Media Gateway) | LOW | PTB |
| 11 | file_id recovery | proactive stale-epoch + reactive repair (atomic, identity-preserving) | 🔄 | — | Reuse the SAME repair routine as the Media Gateway's upstream failure path (spec §23); standardize DELIVERY_FILE_ID_* log events | MED | PTB, source refs |
| 12 | Media identity rules | file_unique_id dedup-only; file_id bot-scoped; source refs durable | ✅ | — | Carry into every media module (MediaHandle already encodes it) | — | — |
| 13 | Indexer | app/core/indexing/engine.py + `extract_media` (7 keys) | 🔄 | — | Capture mime_type/width/height/thumbnail file_id (+v30 additive columns); indexing stays idempotent; never filename-only identity | MED | PTB media attrs |
| 14 | Schema/migrations | v29; chain pinned; v29 = the template | 🔄 | — | v30: DDL in SCHEMA_SQL + `if current < 30:` seeds block + SCHEMA_VERSION bump + SCHEMA_STEPS + documented pin updates (SCHEMA_VERSION == 29 → 30 in 8 test files — same documented precedent as 27→28→29) | MED (pins) | repos |
| 15 | Payload model | payloads.index_id + collections/collection_items | 🔄 | — | `website_payloads` presentation table references the CANONICAL payload/collection (never copies); no second payload DB | MED | payloads repo |
| 16 | Payload search | `search_payloads_fuzzy` (escaped LIKE + Python rank) | 🔄 | — | Add DB-side paginated variant in the SAME repo (no second search system); keep fuzzy semantics for #movie/MOVIE/Action #movie | LOW-MED | payloads repo |
| 17 | Storage Panel | `sc:` callbacks + verification reports | ✅ | — | Add cache usage row (Phase 4); every button already works | LOW | media repo |
| 18 | Admin Control Center | main_panel_keyboard + `panel:` dispatch + wizards | 🔄 | — | Add `panel:website` branch + `wsite:` namespace (FREE) + Add-Website-Payload wizard (thumbnail → payload-link resolve → preview → publish) | MED | callback router |
| 19 | Callback router | on_callback pinned chain + registry (live, tested, unused) | 🔄 | — | Register website admin handlers via `router.register` (canonical path); keep legacy chain untouched | LOW | handlers |
| 20 | Mini App watch-ad page | `_wad_mini_app_page` (pinned HTML) | ✅ | — | Leave frozen; website pages are NEW modules | — | — |
| 21 | Network platform | registry/workers/routing/broadcast | ✅ | — | Workers don't run webservers (by design); multi-token auth (#4) is the only touchpoint | LOW | — |
| 22 | Auto Delete | pending_deletions + schedulers | ✅ | — | Website content/config never auto-deleted (persistent by rule) | LOW | — |
| 23 | Settings KV | bot_settings + typed helpers | ✅ | — | Reuse for `website_enabled` + website/ streaming/ cache/ thumbnail settings (v30 seeds, INSERT OR IGNORE) | LOW | — |
| 24 | Rate limiting | in-process patterns (delivery + `_wad_status_ratelimit`) | 🔄 | — | Same in-process pattern for website endpoints (search/listing/stream-auth/stream) | LOW | — |
| 25 | Media abstraction | app/media/interfaces.py ABCs | 🆕 | — | IMPLEMENT: MediaResolver + TelegramCloudSource (≤20MB) + LocalBotApiSource + CacheSource + MediaGateway (Range/206) | HIGH (core of Phase 4) | aiohttp |
| 26 | Local Bot API | NOT IMPLEMENTED | 🆕 | — | Config (TELEGRAM_API_MODE/URL/API_ID/API_HASH) wired through PTB base_url/local mode; NEVER public without protection | MED | PTB, env |
| 27 | Download Pack | concept exists (delivery_type `download_all`, `coldl:` sends files individually; NO sync ZIP anywhere) | ✅ | — | Preserve; any packaging = background job, bounded disk, expiry, auth (spec §39) | LOW | — |
| 28 | Thumbnails | NOTHING indexed (referral preview_media + FJ media_file_id are admin-supplied precedents) | 🆕 | — | website thumbnail store (bounded) + admin upload + fallback chain (configured → payload image → indexed image → Telegram thumb → placeholder); NEVER download whole videos for thumbs | MED | media attrs |
| 29 | Analytics | payload_views/delivery_records/access_events | 🔄 | — | v30 `website_stream_events` (+WEBSITE_*/MEDIA_* structured logs; never tokens) | LOW | — |
| 30 | Tests | 13 suites, ~181 source pins (inventoried) | 🔄 | A-1 | v30 pin updates (documented); NEW suites per phase; NEVER edit a test to hide a regression | MED | — |
| 31 | bot.py facade | 27,751 lines; wrappers + frozen zones + wiring | ✅ (as facade) | — | ONLY wiring additions allowed (route lines + service injection + `panel:website` branch); zero new website/streaming business logic | HIGH (discipline) | everything |

## 4. Hard constraints discovered (design inputs, not obstacles)

1. **Cloud Bot API `getFile` is limited to 20 MB downloads.** Multi-GB video
   streaming is IMPOSSIBLE via the cloud API alone. Consequences (spec §17
   anticipated this): Local Bot API mode is the primary large-file transport;
   the cloud source remains for ≤20 MB files; the gateway must degrade
   honestly (clear error + admin guidance) when a large file is requested
   without local mode. This is the single most important infrastructure fact
   for Phase 4.
2. **Source-pinned frozen zones** (~181 patterns; inventories in
   docs/BOT_COMPATIBILITY.md + test grep): access resolver shell,
   `_deliver_files_core` ordering, watch-ad DB transaction core, migration
   chain, Mini App HTML + route registration lines, `on_callback` branch
   chain, network worker glue. All additions must be ADDITIVE (new lines,
   new namespaces), never edits of pinned lines.
3. **Migration v30 text constraints** (from test span extraction): the v30
   block sits between the v29 block and the final version stamp, i.e. INSIDE
   the v25/v26/v27 extracted spans — its body must NOT contain the strings
   `UPDATE payloads SET`, `DELETE FROM`, `fj_progress`, `referral_history`,
   `referral_campaigns`, `referral_unlocks` (it won't: CREATE TABLE IF NOT
   EXISTS + INSERT OR IGNORE seeds only). The exact `"file_id       TEXT NOT
   NULL"` 7-space alignment inside indexed_files DDL must be preserved if
   that DDL is ever touched (we do NOT touch existing DDL lines; new columns
   go in the v30 migration block, new tables get new DDL).
4. **`await enforce_access(` count is pinned at exactly 9** — the website
   authorization path calls `access_engine` directly (injected dependency),
   adding zero enforce_access sites.
5. **Website ON/OFF is a PRESENTATION-layer gate only** (spec §5-§7/§13/§32):
   a `website_enabled` setting checked in website routes/middleware →
   maintenance page. It must NEVER appear inside access_engine, watch ads,
   FJ, referral, points, delivery, or network code paths. Regression test
   required (Website OFF + Telegram unlock flow still green).
6. **`start_mini_app_server(None)`** is exercised by 5 suites with `bot=None`
   — website route registration must be import-time-safe and None-safe.
7. **Single process/event loop by design** — cache, active-reader tracking,
   and rate limiting are in-process; SQLite WAL + write_lock discipline
   applies to all new repos.
8. **Network bots never run the web server** — the website is served by the
   main bot process only; Mini Apps launched from network bots must be
   supported at the AUTH layer (multi-token initData validation), not by
   running more servers.
9. **Search must stay ONE system** — web feed adds a paginated repo method
   beside `search_payloads_fuzzy` (same tokenization/ranking helpers), not a
   second engine.
10. **Opaque URLs** (spec §4): website payload/video ids = signed/opaque
    codes (existing precedents: `g<code12>-<sig6>` global links, `c<8-hex>`
    collections, `ref_<16-hex>`); never expose DB ids, channel ids, message
    ids, file_ids, or tokens.

## 5. Implementation map (per spec §50, file-level targets)

**PHASE 1 — Media transport + file-id repair (STOP+report gate)**
* `app/media/sources/telegram_cloud.py` — cloud getFile source (≤20 MB),
  chunked reads.
* `app/media/sources/local_botapi.py` — Local Bot API source (getFile →
  local file path / file endpoint; unbounded).
* `app/media/resolver.py` — MediaResolver impl: indexed_files row →
  MediaHandle (+ repair hook: on upstream "file id invalid" → existing
  source-recovery routine → atomic file_id repair → retry ONCE).
* `app/core/constants.py` + `.env.example`: TELEGRAM_API_MODE / URL / API_ID
  / API_HASH / MEDIA_* config.
* Wiring: PTB local-mode via `app/bootstrap/application.py` config (verify
  build_application pin boundaries before touching bot.py wiring).
* Tests: identity separation, repair-on-upstream-failure, source selection,
  hide_delivery_source independence.

**PHASE 2 — Indexer + storage + search (STOP+report gate)**
* `extract_media` + `add_indexed_files_batch`/`update_indexed_file`: capture
  mime_type, width, height, thumbnail file_id (video/animation/document
  thumbs; photo sizes) — additive keys; idempotent re-index refresh.
* v30 part A: `indexed_files` additive columns (mime_type, width, height,
  thumb_file_id) via ALTER in the migration block.
* `app/storage/repositories/payloads.py`: paginated feed/search methods
  (DB-side LIMIT/OFFSET; same tokenization; hashtag/case-insensitive).
* Storage Panel: mime/thumb coverage rows (existing `sc:` surface).
* Tests: duplicate identity discipline, canonical preservation, pagination,
  search semantics (#movie/movie/MOVIE/Action #movie), state preservation.

**PHASE 3 — Website Payload Platform (STOP+report gate)**
* v30 part B: `website_payloads` (canonical payload_id/collection_id ref,
  title, description, tags, ordering, published, thumbnail fields) +
  `website_stream_events` + `website_enabled` & settings seeds.
* `app/web/site/` package: `pages.py` (mobile-first HTML: home feed, search,
  payload detail, video list, player shell), `api.py` (JSON endpoints),
  `maintenance.py` (ON/OFF gate), `templates.py` (Telegram-theme styling,
  skeletons, lazy loading).
* Opaque signed ids for website payload/video routes: `/site`,
  `/site/search`, `/site/payload/<opaque>`, `/site/payload/<opaque>/video/
  <opaque>`.
* Multi-token WebApp auth (main + ACTIVE network bots) — extends
  `app/web/auth.py` with a resolver; access verdict via injected
  `access_engine`.
* Admin: `panel:website` + `wsite:` callbacks (ON/OFF, Add Website Payload
  wizard: send thumbnail → paste/select payload link → resolve canonical
  payload → preview (video count) → publish), Manage Website Payloads
  (edit/thumbnail/link/enable-disable/preview/delete-listing — delete NEVER
  touches the underlying payload), Website analytics view.
* Regression test (spec §34 MANDATORY): Website OFF → maintenance on all
  /site routes WHILE Telegram payload link → FJ → Watch Ads → verified
  reward → unlock → Telegram delivery stays GREEN.

**PHASE 4 — Media Gateway + Streaming + Cache (STOP+report gate)**
* `app/media/gateway.py`: stream authorization (short-lived, user-bound,
  media-bound, purpose-bound HMAC stream tokens) → MediaResolver → source.
* `app/media/cache.py`: bounded shared cache (MEDIA_CACHE_* config; LRU +
  TTL; active-reader protection with eviction locking; range/chunk sharing;
  deduplicated concurrent upstream fetches; backward-seek re-fetch).
* `/stream/<token>` route: HEAD + GET, Accept-Ranges, 206/Content-Range/
  Content-Length/Content-Type, bounded buffers, disconnect/timeout/upstream
  failure handling; 503/416 semantics.
* Rate limits on stream auth + concurrent streams.
* Tests: range correctness (0-, mid-, 95%+ seeks, suffix ranges), concurrent
  viewers sharing upstream, active-reader eviction safety, token security
  matrix (A→A pass; A→B deny; expired deny; video A→B deny; payload A→B
  deny), RAM bounding.

**PHASE 5 — Release polish (only after all gates pass)**
* UI polish/animations/analytics, performance, docs (WEBSITE.md, MIGRATION
  v30, TEST_REPORT, DEPLOYMENT, .env.example), full regression, final ZIP +
  clean-directory verification, honest final report (incl. NOT IMPLEMENTED
  + KNOWN LIMITATIONS).

## 6. Open facts reported to the operator (no blockers)

* The sandbox cannot run a real Local Bot API server or real Telegram
  traffic — large-file and token-change tests will use the established
  fake-transport pattern (real logic, virtual wire), stated honestly in the
  final report.
* `bot.py` line count will grow ONLY by wiring lines (route registration,
  service injection, one `panel:website` branch) — tracked and reported
  before/after per spec §20.
* All 8 SCHEMA_VERSION pin updates in test files are the documented,
  semantics-preserving precedent (27→28 in Phase 8, 28→29 in Network) — they
  will be listed explicitly when made.
