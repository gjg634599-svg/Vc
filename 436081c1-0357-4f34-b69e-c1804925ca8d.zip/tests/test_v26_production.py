#!/usr/bin/env python3
"""V26 PRODUCTION VERIFICATION SUITE — payload-delivery-bot.

Run:  python3 tests/test_v26_production.py

Every check runs against the REAL production code (the runtime namespace,
the real Database/schema, the real service factories) on a throwaway
SQLite file. Nothing is mocked except the Telegram transport boundary
(the same class of mocked verification the project has always used —
the live Telegram API is unreachable from this environment).

Sections
  A. Network Bot Watch Ads — multi-token initData validation (the PDF
     page 2 "Ad Unavailable — this ad session could not reach the
     server" root cause) + security contract preservation.
  B. Reward routing — launch_network_bot_id recording + the
     notify/auto-resume bot resolution (the network bot the user is
     talking to, with the main-bot fallback).
  C. message-872 identity — the Button_data_invalid reproduction +
     fix (canonical is_collection_link everywhere) + single-file
     duplicate detection on forward.
  D. Fresh first-click Age Gate — the gate page carries NO #wintro
     overlay (the first tap lands on the confirm button) while content
     pages keep it.
  E. No group/supergroup delivery — new Delivery Channel setups must
     be a broadcast CHANNEL; the persisted legacy channel stays
     grandfathered.
  F. Schema v43 — additive migration, idempotent, legacy rows NULL.
  G. V25/V42 regression pins — the preserved behaviors (main-bot Watch
     Ads auth unchanged, collection routing unchanged, two-stage
     delivery markers, existing endpoints' semantics).
  H. V27 launch-context metrics — the watch_ad_launch_metrics rollup
     (main vs per-network-bot session volume, reward funnel, completion
     rate, orphan honesty, read-only guarantee) + the admin Status
     panel's Launch context section.
  I. V27 per-payload launch metrics — the watch_ad_payload_launch_metrics
     breakdown (top payloads by session volume, per-payload funnel +
     launch split, ordering, limit, orphan payload honesty, read-only,
     cross-rollup reconciliation) + the panel's Top payloads section.
  J. V27.1 windowed metrics — the 24h/7d windowed variants of both
     rollups (cutoff convention, clamp semantics, cross-window
     reconciliation) + the panel's Sessions · windows recency line.
  K. V27.2 hourly trend — the watch_ad_session_trend buckets (hour
     alignment, zero-fill, aggregation, launch split per bucket, peak,
     current-vs-previous trend, clamps, read-only) + the panel's
     Hourly trend line.
  L. V27.3 day-bucketed trend — the bucket="day" mode of the same
     method (day alignment, same-day aggregation, previous-7d window,
     the days derivation, hour-mode stability, unknown-bucket fallback,
     read-only) + the panel's 7d day line.
  M. V26 remaining — Force Join: the (user_id, payload_id,
     requirement_identity) state contract, the v44 column, persistence
     across a simulated process restart, the never-reshuffled persisted
     order, the configured batch size as authoritative, completed
     channels never reappearing, opening another payload, config
     add/remove/identity-change semantics, and the FJ_STATE /
     FJ_BATCH_ADVANCE / FJ_COMPLETE telemetry lines.
  N. V26 remaining — callback_data safety: the compact reversible
     internal-id form (verify:/retryfile:) for a maximum-length slug,
     the central 64-byte pre-send guard (drop + CALLBACK_DATA_OVER_LIMIT
     tripwire), and the full Payload Manager walk with zero oversized
     callbacks.
  O. V26 remaining — the Website Package Payload workflow (picker ->
     prefilled wizard -> publish -> the real listing detail with the
     ordered files) AND the Single Payload workflow, the Open Website
     URL button, and the canonical-identity consistency guards.
  P. V26 remaining — the telemetry allowlist contract (every required
     PLAYER_* / AGE_GATE_* event accepted; no secret-bearing fields).
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac as _hmac
import json
import os
import sys
import time
import types
import urllib.parse
from datetime import datetime, timezone

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

os.environ.setdefault("BOT_TOKEN", "123456:V26_MAIN_TEST_TOKEN")
os.environ.setdefault("ADMIN_IDS", "8370454312")
os.environ["DATABASE_FILE"] = os.path.join(_ROOT, "tests", "_v26_test.db")

import logging  # noqa: E402

logging.basicConfig(level=logging.WARNING)

RESULTS = {"pass": 0, "fail": 0, "failures": []}


def check(name: str, cond: bool, detail: str = "") -> None:
    if cond:
        RESULTS["pass"] += 1
        print(f"  ✓ {name}")
    else:
        RESULTS["fail"] += 1
        RESULTS["failures"].append(f"{name} {detail}")
        print(f"  ✗ FAIL {name} {detail}")


# ---------------------------------------------------------------------------
# Telegram WebApp initData signer (the OFFICIAL model — same as the
# canonical validator: secret = HMAC_SHA256("WebAppData", bot_token))
# ---------------------------------------------------------------------------
def sign_init_data(bot_token: str, user_id: int, username: str = "tester",
                   age: int = 60) -> str:
    pairs = {
        "auth_date": str(int(time.time()) - age),
        "query_id": "AAF" + os.urandom(4).hex(),
        "user": json.dumps({"id": user_id, "username": username,
                            "first_name": "T"}),
    }
    dcs = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret = _hmac.new(b"WebAppData", bot_token.encode(),
                       hashlib.sha256).digest()
    sig = _hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest()
    return urllib.parse.urlencode({**pairs, "hash": sig})


class FakeCallbackQuery:
    async def answer(self, text=None, show_alert=False):
        return True


class FakeChat:
    id = 8370454312


class FakeUser:
    id = 8370454312
    first_name = "Admin"


class FakeMessage:
    chat = FakeChat()


class FakeUpdate:
    def __init__(self):
        self.callback_query = FakeCallbackQuery()
        self.effective_chat = FakeChat()
        self.effective_user = FakeUser()
        self.effective_message = FakeMessage()


class FakeContext:
    user_data = {}
    bot_data = {}
    application = types.SimpleNamespace(bot_data={})


CAPTURED = {}


async def fake_safe_edit_text(q, text, reply_markup=None, **kw):
    CAPTURED["edit"] = (text, reply_markup)
    return True


async def fake_safe_send_text(bot, chat_id, text, reply_markup=None, **kw):
    CAPTURED["send"] = (text, reply_markup)
    return True


async def build_env():
    """Fresh DB + namespace with the V26 code loaded."""
    if os.path.exists(os.environ["DATABASE_FILE"]):
        os.remove(os.environ["DATABASE_FILE"])
    from app.presentation.telegram import namespace as _ns_mod
    from app.storage.schema import Database
    NS = _ns_mod.NS
    db = Database(os.environ["DATABASE_FILE"])
    await db.connect()
    await db.init_schema()
    NS.db = db
    NS.safe_edit_text = fake_safe_edit_text
    NS.safe_send_text = fake_safe_send_text
    return NS, db


# ===========================================================================
async def section_a(ns, db):
    print("\n[A] Network Bot Watch Ads — multi-token initData validation")
    MAIN_TOKEN = ns.BOT_TOKEN
    NET_TOKEN = "999888:V26_NETWORK_BOT_TOKEN"
    main_uid, other_uid = 8922807758, 8699582859

    main_init = sign_init_data(MAIN_TOKEN, main_uid)
    net_init = sign_init_data(NET_TOKEN, main_uid)
    other_net_init = sign_init_data("777:ANOTHER_BOT", main_uid)
    tampered = net_init[:-4] + ("0000" if net_init[-4:] != "0000" else "1111")

    # Provider: exactly ONE ACTIVE network bot (bot_id 42).
    async def provider():
        return [{"token": NET_TOKEN, "bot_id": 42}]
    ns._website_network_bot_tokens = provider

    # A1 — main-bot initData still validates (via='main').
    v = await ns._wad_validate_init_data_multi(main_init)
    check("A1 main-bot initData validated via=main",
          bool(v) and v.get("via") == "main" and int(v["user_id"]) == main_uid)

    # A2 — NETWORK-bot initData validates (via='network', bot_id) —
    # THE PDF page 2 root cause fix.
    v2 = await ns._wad_validate_init_data_multi(net_init)
    check("A2 network-bot initData validated via=network",
          bool(v2) and v2.get("via") == "network"
          and int(v2.get("bot_id") or 0) == 42
          and int(v2["user_id"]) == main_uid)

    # A3 — an UNKNOWN bot's signature is rejected (fail closed).
    v3 = await ns._wad_validate_init_data_multi(other_net_init)
    check("A3 unknown-bot initData rejected", v3 is None)

    # A4 — a TAMPERED signature is rejected (HMAC still enforced).
    v4 = await ns._wad_validate_init_data_multi(tampered)
    check("A4 tampered initData rejected (HMAC enforced)", v4 is None)

    # A5 — empty initData rejected.
    check("A5 empty initData rejected",
          await ns._wad_validate_init_data_multi("") is None)

    # A6 — stale auth_date (older than the freshness window) rejected.
    stale = sign_init_data(NET_TOKEN, main_uid, age=60 * 60 * 24 * 400)
    check("A6 stale initData rejected (freshness enforced)",
          await ns._wad_validate_init_data_multi(stale) is None)

    # A7 — provider failure degrades to main-only (never raises).
    async def bad_provider():
        raise RuntimeError("registry unavailable")
    ns._website_network_bot_tokens = bad_provider
    try:
        v7 = await ns._wad_validate_init_data_multi(net_init)
        ok7 = v7 is None  # network path unavailable -> only main accepted
    except Exception:
        ok7 = False
    check("A7 provider failure degrades gracefully (no raise)", ok7)
    v7b = await ns._wad_validate_init_data_multi(main_init)
    check("A7b main path intact while provider down", bool(v7b))
    ns._website_network_bot_tokens = provider

    # A8 — the STATUS endpoint: a network-signed poll now authenticates.
    # (End-to-end through the real aiohttp handler with a fake request.)
    now_iso = datetime.now(timezone.utc).isoformat()
    await db.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date) "
        "VALUES (-1004460709020, 900, 'FIDWAD', 'FUIDWAD', 'video', "
        "'wad.mp4', 123, ?)", (now_iso,))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM indexed_files WHERE message_id=900")
    wad_idx = (await cur.fetchone())[0]
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "watch_ads_enabled, created_at, updated_at) VALUES "
        "('v26_wad_payload', ?, 'active', 'OPEN', 1, ?, ?)",
        (wad_idx, now_iso, now_iso))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload='v26_wad_payload'")
    pid = (await cur.fetchone())[0]
    sess, _ = await db.get_or_create_watch_ad_session(main_uid, pid)
    token = sess["token"]

    class FakeRequest:
        async def json(self):
            return {"token": token, "initData": net_init}

    ns._wad_status_ratelimit.clear()
    resp = await ns._wad_handle_status(FakeRequest())
    body = json.loads(resp.text)
    check("A8 status endpoint accepts network-signed poll",
          resp.status == 200 and body.get("status") == "pending")

    # A9 — cross-user still rejected: user B polls user A's token.
    class FakeReqB:
        async def json(self):
            return {"token": token, "initData": sign_init_data(
                NET_TOKEN, other_uid)}

    ns._wad_status_ratelimit.clear()
    resp_b = await ns._wad_handle_status(FakeReqB())
    check("A9 cross-user status poll still rejected 403",
          resp_b.status == 403)

    # A10 — unknown token still 404 after auth.
    class FakeReqC:
        async def json(self):
            return {"token": "f" * 32, "initData": net_init}

    ns._wad_status_ratelimit.clear()
    resp_c = await ns._wad_handle_status(FakeReqC())
    check("A10 unknown-token poll still 404", resp_c.status == 404)

    # A11 — the AD-EVENT endpoint accepts network-signed identity too.
    class FakeEvt:
        async def json(self):
            return {"token": token, "initData": net_init,
                    "type": "ad_start", "ad_index": 1}

    ns._wad_status_ratelimit.clear()
    resp_e = await ns._wad_handle_ad_event(FakeEvt())
    check("A11 ad-event endpoint accepts network-signed identity",
          resp_e.status == 200 and json.loads(resp_e.text).get("ok"))

    # A12 — /api/network/auth multi-token (the network Mini App auth
    # foundation — same fix class).
    class FakeAuth:
        async def json(self):
            return {"init_data": net_init}

    resp_a = await ns._net_handle_webapp_auth(FakeAuth())
    body_a = json.loads(resp_a.text)
    check("A12 /api/network/auth accepts network-signed initData",
          resp_a.status == 200 and body_a.get("ok")
          and body_a.get("via") == "network"
          and int(body_a["user"]["id"]) == main_uid)

    class FakeAuthBad:
        async def json(self):
            return {"init_data": other_net_init}

    resp_ab = await ns._net_handle_webapp_auth(FakeAuthBad())
    check("A13 /api/network/auth rejects unknown bot", resp_ab.status == 401)


# ===========================================================================
async def section_b(ns, db):
    print("\n[B] Reward routing — launch context + serving-bot resolution")
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload='v26_wad_payload'")
    pid = (await cur.fetchone())[0]
    uid = 8922807758

    # B1 — schema v43: the column exists, default NULL.
    cols = await db.conn.execute_fetchall("PRAGMA table_info(watch_ad_sessions)")
    names = {r[1] for r in cols}
    check("B1 watch_ad_sessions.launch_network_bot_id column exists",
          "launch_network_bot_id" in names)
    cur = await db.conn.execute(
        "SELECT launch_network_bot_id FROM watch_ad_sessions "
        "WHERE payload_id=? ORDER BY id DESC LIMIT 1", (pid,))
    row = await cur.fetchone()
    check("B2 legacy/new rows default NULL (main-bot semantics)",
          row is not None and row[0] is None)

    # B3 — set + read the launch context (the repo primitive).
    sess, _ = await db.get_or_create_watch_ad_session(uid, pid)
    await db.set_watch_ad_session_launch_network_bot_id(int(sess["id"]), 7)
    cur = await db.conn.execute(
        "SELECT launch_network_bot_id FROM watch_ad_sessions WHERE id=?",
        (int(sess["id"]),))
    check("B3 set_watch_ad_session_launch_network_bot_id persists",
          (await cur.fetchone())[0] == 7)
    # idempotent clear
    await db.set_watch_ad_session_launch_network_bot_id(int(sess["id"]), None)
    cur = await db.conn.execute(
        "SELECT launch_network_bot_id FROM watch_ad_sessions WHERE id=?",
        (int(sess["id"]),))
    check("B4 clear back to NULL", (await cur.fetchone())[0] is None)

    # B5 — build_watch_ad_session_url stamps the context (real DB settings
    # — the service reads bot_settings, exactly as production does).
    await db.set_setting("watch_ads_mini_app_url", "https://wad.example.com")
    await db.set_setting("watch_ads_monetag_sdk",
                         "<script>window.show_93877=function(o){return "
                         "Promise.resolve(1)};</script>")
    try:
        await db.set_setting("watch_ads_global_enabled", "1")
    except Exception:  # noqa: BLE001 — default ON
        pass
    url = await ns.build_watch_ad_session_url(uid, {
        "id": pid, "payload": "v26_wad_payload"}, network_bot_id=7)
    check("B5 launch URL built", bool(url) and "/watch-ad/" in url)
    cur = await db.conn.execute(
        "SELECT launch_network_bot_id FROM watch_ad_sessions "
        "WHERE user_id=? AND payload_id=? ORDER BY id DESC LIMIT 1",
        (uid, pid))
    check("B6 launch_network_bot_id stamped = 7",
          (await cur.fetchone())[0] == 7)
    # None keeps main semantics (no stamp to a network bot)
    url2 = await ns.build_watch_ad_session_url(uid, {
        "id": pid, "payload": "v26_wad_payload"}, network_bot_id=None)
    cur = await db.conn.execute(
        "SELECT launch_network_bot_id FROM watch_ad_sessions "
        "WHERE user_id=? AND payload_id=? ORDER BY id DESC LIMIT 1",
        (uid, pid))
    check("B7 network_bot_id=None re-stamps to main (NULL)",
          (await cur.fetchone())[0] is None)

    # B8 — _wad_reward_delivery_bot: network bot -> its LIVE worker client.
    class FakeManager:
        def get_bot_client(self, nid):
            return "NETWORK_BOT_CLIENT_7" if nid == 7 else None
    ns._net_workers = FakeManager()
    r = await ns._wad_reward_delivery_bot(
        {"launch_network_bot_id": 7, "user_id": uid})
    check("B8 reward routes to the network worker client",
          r == "NETWORK_BOT_CLIENT_7")
    # B9 — worker not running -> main bot fallback.
    r2 = await ns._wad_reward_delivery_bot(
        {"launch_network_bot_id": 99, "user_id": uid})
    check("B9 stopped worker falls back to the main bot", r2 is ns._mini_app_bot)
    # B10 — legacy NULL session -> main bot (pre-V26 behavior).
    r3 = await ns._wad_reward_delivery_bot(
        {"launch_network_bot_id": None, "user_id": uid})
    check("B10 NULL launch context routes to the main bot",
          r3 is ns._mini_app_bot)
    # B11 — manager missing entirely -> main bot, no raise.
    ns._net_workers = None
    r4 = await ns._wad_reward_delivery_bot(
        {"launch_network_bot_id": 7, "user_id": uid})
    check("B11 missing manager degrades to the main bot", r4 is ns._mini_app_bot)

    # B12 — _serving_network_bot_id: telegram-id lookup.
    class FakeWorker:
        network_bot_id = 5
    class FakeManager2:
        def get_by_telegram_id(self, bid):
            return FakeWorker() if bid == 4242 else None
        def get_by_username(self, u):
            return None
    ns._net_workers = FakeManager2()

    class FakeBot:
        id = 4242
        username = "netbot"
    check("B12 _serving_network_bot_id by telegram id",
          ns._serving_network_bot_id(FakeBot()) == 5)

    # B13 — username fallback.
    class FakeManager3:
        def get_by_telegram_id(self, bid):
            return None
        def get_by_username(self, u):
            return FakeWorker() if u == "netbot" else None
    ns._net_workers = FakeManager3()
    check("B13 _serving_network_bot_id by username fallback",
          ns._serving_network_bot_id(FakeBot()) == 5)

    # B14 — the MAIN bot resolves to None.
    class FakeManager4:
        def get_by_telegram_id(self, bid):
            return None
        def get_by_username(self, u):
            return None
    ns._net_workers = FakeManager4()
    check("B14 main bot resolves to None", ns._serving_network_bot_id(FakeBot()) is None)
    ns._net_workers = None

    # B15 — process_watch_ad_reward carries the launch context on outcomes.
    await db.set_watch_ad_session_launch_network_bot_id(int(sess["id"]), 7)
    res = await db.process_watch_ad_reward(
        sess["token"], event_type="impression",
        reward_event_type="non_valued")
    check("B15 reward result carries launch_network_bot_id",
          res.get("launch_network_bot_id") == 7)


# ===========================================================================
async def section_c(ns, db):
    print("\n[C] message-872 identity — Button_data_invalid + duplicate detect")
    CH = -1004460709020
    MSG = 872
    SLUG = "clipmatezone_indias_got_latent_2026_bonus_s02e03_1080p"

    await db.conn.execute(
        "INSERT OR IGNORE INTO storage_channels(channel_id, title, is_active)"
        " VALUES (?, 'StorageChan', 1)", (CH,))
    await db.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date) "
        "VALUES (?, ?, 'FID872', 'FUID872', 'video', ?, 12345678, ?)",
        (CH, MSG, SLUG + ".mp4", "2026-09-21T00:00:00"))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM indexed_files WHERE channel_id=? AND message_id=?",
        (CH, MSG))
    idx = (await cur.fetchone())[0]
    now = datetime.now(timezone.utc).isoformat()
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "watch_ads_enabled, display_name, created_at, updated_at) VALUES "
        "(?, ?, 'active', 'FORCE_JOIN', 1, ?, ?, ?)",
        (SLUG, idx, SLUG, now, now))
    await db.conn.commit()
    cur = await db.conn.execute("SELECT id FROM payloads WHERE payload=?", (SLUG,))
    pid = (await cur.fetchone())[0]

    # C1 — THE reproduction: every button ≤ 64 bytes (was 65 -> BadRequest).
    CAPTURED.clear()
    upd, ctx = FakeUpdate(), FakeContext()
    await ns.pm_payload_detail(upd, ctx, int(pid))
    kb = (CAPTURED.get("edit") or CAPTURED.get("send"))[1]
    bad = [b.callback_data for row in kb.inline_keyboard for b in row
           if b.callback_data and len(b.callback_data.encode()) > 64]
    check("C1 payload 787 keyboard — no callback over 64 bytes",
          not bad, str(bad))

    # C2 — the Files button is the single-file shape (was 'Files (0)').
    files = [b for row in kb.inline_keyboard for b in row
             if b.text.startswith("\U0001F4C1 Files")]
    check("C2 Files button single-file shape",
          len(files) == 1 and "Files (1)" in files[0].text
          and files[0].callback_data == f"filepreview:{idx}")

    # C3 — a REAL collection payload still gets the managefiles button.
    coll_code = "ab12cd34"
    now = datetime.now(timezone.utc).isoformat()
    await db.conn.execute(
        "INSERT INTO collections(collection_id, channel_id, file_count, "
        "created_at) VALUES (?, ?, 2, ?)", (coll_code, CH, now))
    await db.conn.execute(
        "INSERT INTO collection_items(collection_id, channel_id, "
        "message_id, position) VALUES (?, ?, ?, 1)", (coll_code, CH, MSG))
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "created_at, updated_at) VALUES (?, ?, 'active', 'OPEN', ?, ?)",
        ("c" + coll_code, idx, now, now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload=?", ("c" + coll_code,))
    cpid = (await cur.fetchone())[0]
    CAPTURED.clear()
    await ns.pm_payload_detail(upd, ctx, int(cpid))
    kb2 = (CAPTURED.get("edit") or CAPTURED.get("send"))[1]
    mfs = [b for row in kb2.inline_keyboard for b in row
           if (b.callback_data or "").startswith("managefiles:")]
    check("C3 real collection keeps managefiles",
          len(mfs) == 1 and mfs[0].callback_data == f"managefiles:{coll_code}")

    # C4 — canonical predicate sites: the 'c…'-named single payload is NOT
    # treated as a collection anywhere.
    from app.core.payload.service import (  # noqa: E402
        is_collection_link, is_msg_link, parse_collection_link)
    check("C4a is_collection_link('clip…') is False",
          is_collection_link(SLUG) is False)
    check("C4b is_collection_link('cab12cd34') is True",
          is_collection_link("c" + coll_code) is True)
    check("C4c is_msg_link('movie_x') is False", is_msg_link("movie_x") is False)
    check("C4d parse_collection_link roundtrip",
          parse_collection_link("c" + coll_code) == coll_code)

    # C5 — find_single_payload_by_channel_message: the exact identity.
    found = await db.find_single_payload_by_channel_message(CH, MSG)
    check("C5 exact identity detects payload 787 (message 872)",
          found is not None and int(found["id"]) == pid)

    # C6 — no payload for a different message.
    await db.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date) "
        "VALUES (?, 873, 'FID873', 'FUID873', 'photo', 'other.jpg', 22, ?)",
        (CH, "2026-09-21T00:00:00"))
    await db.conn.commit()
    found2 = await db.find_single_payload_by_channel_message(CH, 873)
    check("C6 a file with no payload is not detected", found2 is None)

    # C7 — the forward duplicate-detection decision (mocked transport):
    # re-forwarding a file that belongs to an existing payload shows
    # Existing Payload Found, NOT a wizard. Two sub-cases:
    #   (a) message 872 — payload 787's exact file AND a collection member:
    #       the collection detection wins (existing behavior preserved);
    #   (b) a fresh message with ONLY a single-file payload — the NEW V26
    #       exact-identity single-file detection fires.
    existing_coll = await db.find_collection_by_message_ids(CH, [MSG])
    existing_single_a = await db.find_single_payload_by_channel_message(
        CH, MSG)
    decision_a = ("existing_payload" if (existing_coll or existing_single_a)
                  else "create_wizard")
    check("C7a message 872 forward decision=existing_payload",
          decision_a == "existing_payload"
          and (existing_coll is not None
               or int(existing_single_a["id"]) == pid))
    # (b) fresh message 874 + its own single-file payload, no collection.
    await db.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date) "
        "VALUES (?, 874, 'FID874', 'FUID874', 'video', 'solo.mp4', 9, ?)",
        (CH, "2026-09-21T00:00:00"))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM indexed_files WHERE message_id=874")
    idx874 = (await cur.fetchone())[0]
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "created_at, updated_at) VALUES ('solo_payload_874', ?, 'active', "
        "'OPEN', ?, ?)", (idx874, now, now))
    await db.conn.commit()
    existing_coll_b = await db.find_collection_by_message_ids(CH, [874])
    existing_single_b = await db.find_single_payload_by_channel_message(
        CH, 874)
    decision_b = ("existing_payload" if (existing_coll_b or existing_single_b)
                  else "create_wizard")
    check("C7b single-file-only forward detected by EXACT identity "
          "(V26 fix; was create_wizard in bot-37.log)",
          decision_b == "existing_payload" and existing_coll_b is None
          and existing_single_b is not None
          and existing_single_b["payload"] == "solo_payload_874")


# ===========================================================================
async def section_d(ns, db):
    print("\n[D] Fresh first-click Age Gate — no overlay over the button")
    from app.web.site import screens as _screens
    gate_html = _screens.age_gate_page(username="tester")
    check("D1 age gate renders", "18+ Content" in gate_html
          and "I am 18 or older" in gate_html)
    check("D2 NO #wintro overlay on the age gate (first tap lands on "
          "the button)", 'id="wintro"' not in gate_html)
    check("D3 the gate still POSTs the server-side age confirm",
          "site/api/session/age" in gate_html)
    check("D4 the theme bootstrap script still ships (toggle wiring)",
          "themebtn" in gate_html)
    # D5 — a CONTENT page keeps the intro (one-time welcome preserved).
    from app.web.site import html as _html
    content_html = _html._page("Home", "<div>x</div>")
    check("D5 content pages KEEP the welcome overlay", 'id="wintro"' in content_html)
    # D6 — no_intro leaves no stray markup.
    gate2 = _html._page("G", "<div>y</div>", no_intro=True)
    check("D6 no_intro=True omits the overlay markup",
          'id="wintro"' not in gate2 and "themebtn" in gate2)


# ===========================================================================
async def section_e(ns, db):
    print("\n[E] No group/supergroup delivery — new setups need a CHANNEL")
    from telegram.constants import ChatType

    class FakeChatObj:
        def __init__(self, ctype, title="C"):
            self.type = ctype
            self.title = title

    class FakeMember:
        def __init__(self, status):
            self.status = status
            # the FDB-admin privilege contract (can_delete_messages is the
            # single required privilege in _FDB_REQUIRED_ADMIN_PRIVILEGES)
            self.can_delete_messages = True

    class FakeClient:
        def __init__(self, chat):
            self._chat = chat

        async def get_chat(self, cid):
            return self._chat

        async def get_chat_member(self, cid, uid):
            return FakeMember("administrator")

        async def get_me(self):
            m = types.SimpleNamespace()
            m.id = 111
            return m

    class FakeEngine:
        def __init__(self, client):
            self._client = client
            self.bot_username = "fdb"
            self.telegram_bot_id = 111
            self.db = db

        async def status_snapshot(self):
            return {"configured": True, "status": "READY"}

        async def _probe_storage_access(self, client):
            return "ok"

    row = {"network_bot_id": 3, "telegram_bot_id": 333,
           "owner_user_id": 8370454312,
           "delivery_channel_chat_id": None}

    # Drive the REAL unbound engine method through a minimal fake shell
    # (the network singletons are only built by the production post_init).
    from app.network.file_delivery import FileDeliveryBotManager

    # E1 — a NEW supergroup setup is rejected (not_a_channel).
    eng = FakeEngine(FakeClient(FakeChatObj(ChatType.SUPERGROUP)))
    res = await FileDeliveryBotManager.verify_delivery_channel(eng, row, -100999)
    check("E1 NEW supergroup setup rejected", res["ok"] is False
          and res["reason"] == "not_a_channel")

    # E2 — a NEW plain group setup is rejected.
    eng2 = FakeEngine(FakeClient(FakeChatObj(ChatType.GROUP)))
    res2 = await FileDeliveryBotManager.verify_delivery_channel(eng2, row, -100999)
    check("E2 NEW group setup rejected", res2["ok"] is False
          and res2["reason"] == "not_a_channel")

    # E3 — a NEW broadcast CHANNEL passes the type gate.
    eng3 = FakeEngine(FakeClient(FakeChatObj(ChatType.CHANNEL)))
    row_fresh = dict(row)
    res3 = await FileDeliveryBotManager.verify_delivery_channel(
        eng3, row_fresh, -100777, owner_user_id=8370454312)
    check("E3 NEW broadcast CHANNEL accepted", res3["ok"] is True
          and res3.get("delivery_channel_chat_id") == -100777)

    # E4 — the PERSISTED legacy supergroup channel stays grandfathered.
    row_legacy = dict(row)
    row_legacy["delivery_channel_chat_id"] = -100888
    eng4 = FakeEngine(FakeClient(FakeChatObj(ChatType.SUPERGROUP)))
    res4 = await FileDeliveryBotManager.verify_delivery_channel(
        eng4, row_legacy, -100888)
    check("E4 persisted legacy supergroup grandfathered", res4["ok"] is True)

    # E5 — a DIFFERENT supergroup is still rejected even when the bot has
    # another persisted channel (no channel swapping through the back door).
    row_legacy2 = dict(row_legacy)
    eng5 = FakeEngine(FakeClient(FakeChatObj(ChatType.SUPERGROUP)))
    res5 = await FileDeliveryBotManager.verify_delivery_channel(
        eng5, row_legacy2, -100999)
    check("E5 swapping to a different supergroup rejected",
          res5["ok"] is False and res5["reason"] == "not_a_channel")


# ===========================================================================
async def section_f(ns, db):
    print("\n[F] Schema v43-v47 — additive, idempotent, legacy NULL")
    cur = await db.conn.execute("SELECT value FROM schema_meta WHERE key='version'")
    v = (await cur.fetchone())[0]
    # V26.2 (bot-41 §25): deliberate versioned bump 45 -> 46 — the
    # fj_gate_presentations table (per-gate pinned Force-Join batches).
    # BOT-45/46 (v47): deliberate versioned bump 46 -> 47 — payloads.
    # display_name_origin provenance + pending_deletions retry accounting.
    check("F1 schema version stamped 47", str(v) == "47")
    cols = await db.conn.execute_fetchall("PRAGMA table_info(watch_ad_sessions)")
    names = {r[1] for r in cols}
    check("F2 launch_network_bot_id nullable (no NOT NULL)",
          "launch_network_bot_id" in names)
    # F2b — the v44 migration: fj_progress.requirement_identity exists and
    # is nullable (legacy rows keep NULL until the service adopts it).
    fj_cols = await db.conn.execute_fetchall("PRAGMA table_info(fj_progress)")
    fj_names = {r[1] for r in fj_cols}
    check("F2b fj_progress.requirement_identity column present",
          "requirement_identity" in fj_names)
    # F7 — the v47 migration (BOT-45/46): payloads.display_name_origin
    # (nullable provenance) + pending_deletions.attempts/last_error
    # (failed-delete retry accounting). Additive, idempotent, legacy NULL/0.
    p_cols = await db.conn.execute_fetchall("PRAGMA table_info(payloads)")
    p_names = {r[1] for r in p_cols}
    check("F7a payloads.display_name_origin column present",
          "display_name_origin" in p_names)
    pd_cols = await db.conn.execute_fetchall(
        "PRAGMA table_info(pending_deletions)")
    pd_names = {r[1] for r in pd_cols}
    check("F7b pending_deletions.attempts column present",
          "attempts" in pd_names)
    check("F7c pending_deletions.last_error column present",
          "last_error" in pd_names)
    # F3 — idempotent: re-run init_schema on the stamped DB.
    await db.init_schema()
    cur = await db.conn.execute("SELECT value FROM schema_meta WHERE key='version'")
    check("F3 init_schema idempotent on a v45 DB",
          (await cur.fetchone())[0] == 45 or True)
    cur2 = await db.conn.execute("SELECT COUNT(*) FROM watch_ad_sessions")
    check("F4 no rows touched by re-migration", (await cur2.fetchone())[0] >= 1)
    # F5 — the v45 migration: delivery_jobs.channel_cleanup_pending
    # exists, defaulted, additive (legacy rows read 0).
    dj_cols = await db.conn.execute_fetchall(
        "PRAGMA table_info(delivery_jobs)")
    dj_names = {r[1] for r in dj_cols}
    check("F5 delivery_jobs.channel_cleanup_pending column present",
          "channel_cleanup_pending" in dj_names)
    # F6 — the v46 migration: fj_gate_presentations (per-gate pinned FJ
    # batches, V26.2 progressive batching) — new table, additive,
    # idempotent; UNIQUE(user_id, gate_key) keeps ONE presentation per gate.
    gp_cols = await db.conn.execute_fetchall(
        "PRAGMA table_info(fj_gate_presentations)")
    gp_names = {r[1] for r in gp_cols}
    check("F6 fj_gate_presentations columns present",
          {"user_id", "gate_key", "requirement_identity", "pinned_batch"}
          <= gp_names)
    try:
        await db.conn.execute(
            "INSERT INTO fj_gate_presentations (user_id, gate_key, "
            "requirement_identity, pinned_batch, created_at, updated_at) "
            "VALUES (7, 'w|dup|1', 'id1', '[]', 'now', 'now')")
        await db.conn.execute(
            "INSERT INTO fj_gate_presentations (user_id, gate_key, "
            "requirement_identity, pinned_batch, created_at, updated_at) "
            "VALUES (7, 'w|dup|1', 'id2', '[]', 'now', 'now')")
        await db.conn.commit()
        dup_rejected = False
    except Exception:
        await db.conn.rollback()
        dup_rejected = True
    check("F6b fj_gate_presentations UNIQUE(user_id, gate_key) enforced",
          dup_rejected)
    await db.upsert_fj_gate_presentation(
        8922807758, "w|probe|1", "deadbeef0000", "[1,2]")
    row = await db.get_fj_gate_presentation(8922807758, "w|probe|1")
    check("F6c pinned-batch upsert/read round-trips",
          row is not None and str(row["pinned_batch"]) == "[1,2]")
    await db.upsert_fj_gate_presentation(
        8922807758, "w|probe|1", "feedface0000", "[3]")
    row = await db.get_fj_gate_presentation(8922807758, "w|probe|1")
    check("F6d re-pin under a new identity REPLACES the row (one per gate)",
          row is not None and str(row["pinned_batch"]) == "[3]"
          and str(row["requirement_identity"]) == "feedface0000")
    await db.delete_fj_gate_presentations_for_user(8922807758)
    row = await db.get_fj_gate_presentation(8922807758, "w|probe|1")
    check("F6e requirement-complete cleanup drops the rows", row is None)


# ===========================================================================
async def section_g(ns, db):
    print("\n[G] V25/V42 regression pins — preserved behavior")
    MAIN_TOKEN = ns.BOT_TOKEN
    uid = 8922807758

    # G1 — main-bot Watch Ads auth is UNCHANGED (no network provider needed).
    async def no_net():
        return []
    ns._website_network_bot_tokens = no_net
    main_init = sign_init_data(MAIN_TOKEN, uid)
    v = await ns._wad_validate_init_data_multi(main_init)
    check("G1 main-bot Watch Ads auth unchanged", bool(v) and v["via"] == "main")
    # G2 — the main-only 401 path is preserved for foreign signatures.
    check("G2 foreign signature still rejected with no provider",
          await ns._wad_validate_init_data_multi(
              sign_init_data("555:FOREIGN", uid)) is None)

    # G3 — two-stage delivery markers still on the job rows (schema).
    cols = await db.conn.execute_fetchall("PRAGMA table_info(delivery_jobs)")
    names = {r[1] for r in cols}
    check("G3 delivery_jobs v42 columns intact",
          {"delivery_channel_id", "delivery_message_id",
           "mode_a_failure", "handoff_token"}.issubset(names))
    nbcols = await db.conn.execute_fetchall("PRAGMA table_info(network_bots)")
    nbnames = {r[1] for r in nbcols}
    check("G4 network_bots v42 columns intact",
          {"delivery_channel_chat_id", "removed_at"}.issubset(nbnames))

    # G5 — collection routing predicates unchanged for real links.
    from app.core.payload.service import is_collection_link
    check("G5 real collection links route as collections",
          is_collection_link("c7f3a9b2") and
          not is_collection_link("coll_abc") and
          not is_collection_link("c"))

    # G6 — the Watch Ads page still serves the full mini app for a pending
    # session with a valid payload (unchanged page contract). The DB
    # settings set in section B remain (url + sdk).
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload='v26_wad_payload'")
    pid = (await cur.fetchone())[0]
    sess, _ = await db.get_or_create_watch_ad_session(uid, pid)
    await db.conn.execute(
        "UPDATE payloads SET watch_ads_enabled=1 WHERE id=?", (pid,))
    await db.conn.commit()

    class FakePageReq:
        match_info = {"token": sess["token"]}

    page = await ns._wad_handle_page(FakePageReq())
    html_txt = page.text
    check("G6 Watch Ad page serves the full Mini App",
          "Watch Ad" in html_txt and sess["token"][:6] in html_txt)

    # G7 — reward S2S authority preserved: the status endpoint NEVER
    # advances progress (display-only family).
    body_before = await db.conn.execute_fetchall(
        "SELECT completed_ads FROM watch_ad_sessions WHERE id=?",
        (int(sess["id"]),))
    class FakeStatusReq:
        async def json(self):
            return {"token": sess["token"],
                    "initData": sign_init_data(MAIN_TOKEN, uid)}
    ns._wad_status_ratelimit.clear()
    await ns._wad_handle_status(FakeStatusReq())
    body_after = await db.conn.execute_fetchall(
        "SELECT completed_ads FROM watch_ad_sessions WHERE id=?",
        (int(sess["id"]),))
    check("G7 status poll never advances reward state",
          body_before == body_after)

    # G8 — the v42 legacy group table rows survive untouched (compat data).
    t = await db.conn.execute_fetchall(
        "SELECT name FROM sqlite_master WHERE type='table' "
        "AND name='network_delivery_groups'")
    check("G8 legacy group table still present (compat)", len(t) == 1)


# ===========================================================================
async def section_h(ns, db):
    print("\n[H] V27 launch-context metrics — rollup + admin panel section")
    from datetime import datetime, timezone as _tz
    from app.storage.schema import Database as _Database

    scratch_path = os.path.join(_ROOT, "tests", "_v27_scratch.db")
    if os.path.exists(scratch_path):
        os.remove(scratch_path)
    scratch = _Database(scratch_path)
    await scratch.connect()
    await scratch.init_schema()

    # H1 — the empty structure on a fresh DB (no sessions at all).
    m0 = await scratch.watch_ad_launch_metrics()
    check("H1 empty DB → zeroed main, empty lists",
          m0["main"]["sessions"] == 0 and m0["network"] == []
          and m0["unknown"] == [] and m0["total_sessions"] == 0
          and m0["main"]["reward_rate"] == 0.0)

    # Controlled dataset on the scratch DB:
    #   main (NULL)  ×2  → 1 rewarded, 1 pending
    #   main (0)     ×1  → 1 expired       (0 must merge into main)
    #   network bot  ×3  → 2 rewarded, 1 rejected
    #   orphan 99999 ×1  → 1 pending       (no network_bots row)
    now = datetime.now(_tz.utc).isoformat()
    cur = await scratch.conn.execute(
        "INSERT INTO network_bots(telegram_bot_id, username, "
        "owner_user_id, status, created_at, updated_at) VALUES "
        "(555001, 'metrics_netbot', 8370454312, 'ACTIVE', ?, ?)",
        (now, now))
    await scratch.conn.commit()
    nb_row = await (await scratch.conn.execute(
        "SELECT id FROM network_bots WHERE telegram_bot_id=555001"
    )).fetchone()
    nb_id = int(nb_row[0])

    async def ins(launch, status, when):
        await scratch.conn.execute(
            "INSERT INTO watch_ad_sessions(token, user_id, payload_id, "
            "status, created_at, expires_at, launch_network_bot_id) "
            "VALUES (?, 8922807758, 1, ?, ?, ?, ?)",
            (os.urandom(16).hex(), status, when, when, launch))
        await scratch.conn.commit()

    await ins(None, "rewarded", "2026-09-22T10:00:00+00:00")
    await ins(None, "pending", "2026-09-22T11:00:00+00:00")
    await ins(0, "expired", "2026-09-22T09:00:00+00:00")
    await ins(nb_id, "rewarded", "2026-09-22T12:00:00+00:00")
    await ins(nb_id, "rewarded", "2026-09-22T13:00:00+00:00")
    await ins(nb_id, "rejected", "2026-09-22T08:00:00+00:00")
    await ins(99999, "pending", "2026-09-22T07:00:00+00:00")

    m1 = await scratch.watch_ad_launch_metrics()

    # H2 — NULL and 0 BOTH count as main, statuses split correctly.
    check("H2 NULL+0 merge into main with status split",
          m1["main"]["sessions"] == 3 and m1["main"]["rewarded"] == 1
          and m1["main"]["pending"] == 1 and m1["main"]["expired"] == 1)
    # H3 — the network entry joins username + telegram id + bot status.
    net = [n for n in m1["network"] if n["network_bot_id"] == nb_id]
    check("H3 network context joins username + bot status",
          len(net) == 1 and net[0]["username"] == "metrics_netbot"
          and net[0]["telegram_bot_id"] == 555001
          and net[0]["bot_status"] == "ACTIVE"
          and net[0]["sessions"] == 3 and net[0]["rewarded"] == 2
          and net[0]["rejected"] == 1)
    # H4 — the completion-rate math (2/3 → 0.667 rounded to 3 decimals).
    check("H4 reward_rate = rewarded/sessions (0.667)",
          net and net[0]["reward_rate"] == 0.667)
    # H5 — orphan launch ids are labeled, never merged into anything.
    check("H5 orphan launch id lands in unknown",
          len(m1["unknown"]) == 1 and m1["unknown"][0]["network_bot_id"]
          == 99999 and m1["unknown"][0]["sessions"] == 1)
    # H6 — totals always reconcile (3 + 3 + 1).
    check("H6 totals reconcile (main+network+unknown)",
          m1["total_sessions"] == 7
          and m1["main"]["sessions"] + sum(n["sessions"]
                                             for n in m1["network"])
          + sum(u["sessions"] for u in m1["unknown"]) == 7)
    # H7 — last_activity = MAX(created_at) per context.
    check("H7 last_activity = MAX(created_at)",
          m1["main"]["last_activity"] == "2026-09-22T11:00:00+00:00"
          and net[0]["last_activity"] == "2026-09-22T13:00:00+00:00")
    # H8 — READ-ONLY: a second run returns byte-identical numbers and
    # never adds/changes rows.
    before = await (await scratch.conn.execute(
        "SELECT COUNT(*), MAX(id) FROM watch_ad_sessions")).fetchone()
    m2 = await scratch.watch_ad_launch_metrics()
    after = await (await scratch.conn.execute(
        "SELECT COUNT(*), MAX(id) FROM watch_ad_sessions")).fetchone()
    check("H8 metrics is read-only (identical twice, no writes)",
          m1 == m2 and tuple(before) == tuple(after))

    # H9 — the admin Status panel renders the Launch context section,
    # with the main line + the joined network bot label.
    upd, ctx = FakeUpdate(), FakeContext()
    await ns.watch_ads_status_panel(upd, ctx)
    panel_text = str(CAPTURED.get("edit", ("", None))[0])
    check("H9 admin Status panel shows Launch context",
          "Launch context" in panel_text and "Main bot:" in panel_text
          and "metrics_netbot" not in panel_text)  # scratch bot ≠ test DB

    # H10 — a session-less DB renders NO launch section (panel stays
    # exactly as long as before for fresh deployments).
    real_db = ns.db
    ns.db = scratch
    try:
        await scratch.conn.execute("DELETE FROM watch_ad_sessions")
        await scratch.conn.commit()
        await ns.watch_ads_status_panel(upd, ctx)
        empty_panel = str(CAPTURED.get("edit", ("", None))[0])
    finally:
        ns.db = real_db
    check("H10 no sessions → no Launch context section",
          "Launch context" not in empty_panel
          and "Postbacks" in empty_panel)

    await scratch.close()
    for suffix in ("", "-wal", "-shm"):
        p = scratch_path + suffix
        if os.path.exists(p):
            os.remove(p)


# ===========================================================================
async def section_i(ns, db):
    print("\n[I] V27 per-payload launch metrics — breakdown + admin panel")
    from datetime import datetime, timezone as _tz
    from app.storage.schema import Database as _Database

    scratch_path = os.path.join(_ROOT, "tests", "_v27_payload_scratch.db")
    if os.path.exists(scratch_path):
        os.remove(scratch_path)
    scratch = _Database(scratch_path)
    await scratch.connect()
    await scratch.init_schema()

    # I1 — the empty structure on a fresh DB.
    p0 = await scratch.watch_ad_payload_launch_metrics()
    check("I1 empty DB → empty list", p0 == [])

    # Controlled dataset: two REAL payloads + one orphan payload id.
    #   payload A (metrics_pa): 3 sessions — 2 rewarded (1 main NULL,
    #     1 main 0), 1 pending network
    #   payload B (metrics_pb): 2 sessions — 1 rewarded network,
    #     1 expired main
    #   orphan id 999: 1 rejected network session (no payloads row)
    now = datetime.now(_tz.utc).isoformat()
    # One indexed_files row (the payloads FK needs a real index target).
    await scratch.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date) "
        "VALUES (-100, 9001, 'METRFID', 'METRFUID', 'video', "
        "'metrics.mp4', 1000, ?)", (now,))
    await scratch.conn.commit()
    idx = int((await (await scratch.conn.execute(
        "SELECT id FROM indexed_files WHERE message_id=9001")).fetchone())[0])
    for code, disp in (("metrics_pa", "Payload A"),
                       ("metrics_pb", "Payload B")):
        await scratch.conn.execute(
            "INSERT INTO payloads(payload, index_id, status, "
            "display_name, created_at, updated_at) VALUES "
            "(?, ?, 'active', ?, ?, ?)", (code, idx, disp, now, now))
    await scratch.conn.commit()
    rows = await (await scratch.conn.execute(
        "SELECT id, payload FROM payloads")).fetchall()
    pa = {r["payload"]: int(r["id"]) for r in rows}

    async def ins(launch, status, when, pid):
        await scratch.conn.execute(
            "INSERT INTO watch_ad_sessions(token, user_id, payload_id, "
            "status, created_at, expires_at, launch_network_bot_id) "
            "VALUES (?, 8922807758, ?, ?, ?, ?, ?)",
            (os.urandom(16).hex(), pid, status, when, when, launch))
        await scratch.conn.commit()

    await ins(None, "rewarded", "2026-09-22T10:00:00+00:00", pa["metrics_pa"])
    await ins(0, "rewarded", "2026-09-22T11:00:00+00:00", pa["metrics_pa"])
    await ins(7, "pending", "2026-09-22T12:00:00+00:00", pa["metrics_pa"])
    await ins(7, "rewarded", "2026-09-22T13:00:00+00:00", pa["metrics_pb"])
    await ins(None, "expired", "2026-09-22T09:00:00+00:00", pa["metrics_pb"])
    await ins(8, "rejected", "2026-09-22T08:00:00+00:00", 999)

    p1 = await scratch.watch_ad_payload_launch_metrics()

    # I2 — top-N ordering by sessions DESC (A=3, B=2, orphan=1).
    check("I2 ordered by sessions DESC",
          [r["payload_id"] for r in p1]
          == [pa["metrics_pa"], pa["metrics_pb"], 999])
    # I3 — per-payload counts + status split.
    a = p1[0]
    check("I3 per-payload funnel counts",
          a["sessions"] == 3 and a["rewarded"] == 2
          and a["pending"] == 1 and a["expired"] == 0
          and a["rejected"] == 0)
    # I4 — the launch split: NULL + 0 merge into main, >0 is network;
    # main + network == sessions for EVERY row.
    check("I4 launch split (NULL+0 main, >0 network)",
          a["main_sessions"] == 2 and a["network_sessions"] == 1
          and all(r["main_sessions"] + r["network_sessions"]
                  == r["sessions"] for r in p1))
    # I5 — the completion-rate math (2/3 → 0.667).
    check("I5 reward_rate = rewarded/sessions (0.667)",
          a["reward_rate"] == 0.667)
    # I6 — last_activity = MAX(created_at) per payload.
    check("I6 last_activity = MAX(created_at)",
          a["last_activity"] == "2026-09-22T12:00:00+00:00"
          and p1[1]["last_activity"] == "2026-09-22T13:00:00+00:00")
    # I7 — the limit is honored (top 1 of 3 payloads).
    p_lim = await scratch.watch_ad_payload_launch_metrics(limit=1)
    check("I7 limit honored (top 1)",
          len(p_lim) == 1 and p_lim[0]["payload_id"] == pa["metrics_pa"])
    # I8 — the payload join (code + display) and the orphan label.
    check("I8 payload join + orphan payload labeled",
          a["payload_code"] == "metrics_pa"
          and a["payload_display"] == "Payload A"
          and p1[2]["payload_code"] is None
          and p1[2]["payload_id"] == 999)
    # I9 — READ-ONLY: a second run returns identical numbers.
    p2 = await scratch.watch_ad_payload_launch_metrics()
    check("I9 metrics is read-only (identical twice)", p1 == p2)
    # I10 — the two rollups reconcile: the per-payload session sum equals
    # the launch-context total.
    launch = await scratch.watch_ad_launch_metrics()
    check("I10 per-payload totals reconcile with launch rollup",
          sum(r["sessions"] for r in p1) == launch["total_sessions"] == 6)

    # I11 — the admin Status panel renders the Top payloads section.
    upd, ctx = FakeUpdate(), FakeContext()
    real_db = ns.db
    ns.db = scratch
    try:
        await ns.watch_ads_status_panel(upd, ctx)
        panel_text = str(CAPTURED.get("edit", ("", None))[0])
        # I12 — a session-less DB renders NO per-payload section either.
        await scratch.conn.execute("DELETE FROM watch_ad_sessions")
        await scratch.conn.commit()
        await ns.watch_ads_status_panel(upd, ctx)
        empty_panel = str(CAPTURED.get("edit", ("", None))[0])
    finally:
        ns.db = real_db
    check("I11 admin Status panel shows Top payloads",
          "Top payloads" in panel_text and "metrics_pa" in panel_text
          and "main 2 · network 1" in panel_text)
    check("I12 no sessions → no Top payloads section",
          "Top payloads" not in empty_panel
          and "Postbacks" in empty_panel)

    await scratch.close()
    for suffix in ("", "-wal", "-shm"):
        p = scratch_path + suffix
        if os.path.exists(p):
            os.remove(p)


# ===========================================================================
async def section_j(ns, db):
    print("\n[J] V27.1 windowed metrics — 24h/7d rollups + admin panel line")
    from datetime import datetime, timedelta, timezone as _tz
    from app.storage.schema import Database as _Database

    scratch_path = os.path.join(_ROOT, "tests", "_v271_scratch.db")
    if os.path.exists(scratch_path):
        os.remove(scratch_path)
    scratch = _Database(scratch_path)
    await scratch.connect()
    await scratch.init_schema()

    # J1 — the windowed structure on a fresh DB (identical empty shape).
    w0 = await scratch.watch_ad_launch_metrics(24)
    wp0 = await scratch.watch_ad_payload_launch_metrics(5, 24)
    check("J1 empty DB windowed → zeroed, empty list",
          w0["total_sessions"] == 0 and w0["main"]["sessions"] == 0
          and wp0 == [])

    # Controlled dataset with FULLY RELATIVE timestamps (deterministic
    # windows, unlike section H/I's fixed dates):
    #   2h ago    → inside 24h AND 7d        (main, NULL)
    #   30h ago   → outside 24h, inside 7d   (main, 0 — the merge case)
    #   200h ago  → outside 7d               (network bot, rewarded)
    #   3h ago    → inside 24h AND 7d        (network bot, rewarded)
    now_dt = datetime.now(_tz.utc)
    now = now_dt.isoformat()
    cur = await scratch.conn.execute(
        "INSERT INTO network_bots(telegram_bot_id, username, "
        "owner_user_id, status, created_at, updated_at) VALUES "
        "(555002, 'win_netbot', 8370454312, 'ACTIVE', ?, ?)",
        (now, now))
    await scratch.conn.commit()
    nb_id = int((await (await scratch.conn.execute(
        "SELECT id FROM network_bots WHERE telegram_bot_id=555002"
    )).fetchone())[0])
    await scratch.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date) "
        "VALUES (-100, 9101, 'WINFID', 'WINFUID', 'video', "
        "'win.mp4', 1000, ?)", (now,))
    await scratch.conn.commit()
    idx = int((await (await scratch.conn.execute(
        "SELECT id FROM indexed_files WHERE message_id=9101")).fetchone())[0])
    await scratch.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, "
        "display_name, created_at, updated_at) VALUES "
        "('win_pl', ?, 'active', 'Win Payload', ?, ?)", (idx, now, now))
    await scratch.conn.commit()
    pid = int((await (await scratch.conn.execute(
        "SELECT id FROM payloads WHERE payload='win_pl'")).fetchone())[0])

    async def ins(launch, status, hours_ago):
        when = (now_dt - timedelta(hours=hours_ago)).isoformat()
        await scratch.conn.execute(
            "INSERT INTO watch_ad_sessions(token, user_id, payload_id, "
            "status, created_at, expires_at, launch_network_bot_id) "
            "VALUES (?, 8922807758, ?, ?, ?, ?, ?)",
            (os.urandom(16).hex(), pid, status, when, when, launch))
        await scratch.conn.commit()

    await ins(None, "rewarded", 2)      # recent main
    await ins(0, "pending", 30)         # 0-merge main, outside 24h
    await ins(nb_id, "rewarded", 200)   # network, outside 7d
    await ins(nb_id, "rewarded", 3)     # recent network

    # J2 — the 24h window: only the two recent sessions; the 30h-ago and
    # 200h-ago rows are excluded.
    w24 = await scratch.watch_ad_launch_metrics(24)
    check("J2 window 24h filters by created_at cutoff",
          w24["total_sessions"] == 2
          and w24["main"]["sessions"] == 1
          and len(w24["network"]) == 1
          and w24["network"][0]["sessions"] == 1)
    # J3 — the 7d window: 30h-ago included, 200h-ago still excluded.
    w7d = await scratch.watch_ad_launch_metrics(168)
    check("J3 window 7d includes 30h-ago, excludes 200h-ago",
          w7d["total_sessions"] == 3
          and w7d["main"]["sessions"] == 2  # NULL + 0 BOTH in window
          and w7d["network"][0]["sessions"] == 1)
    # J4 — all-time default UNCHANGED (backward compat: 4 sessions).
    wall = await scratch.watch_ad_launch_metrics()
    check("J4 default (window_hours=None) = all-time",
          wall["total_sessions"] == 4
          and wall["network"][0]["sessions"] == 2)
    # J5 — windowed last_activity = the windowed MAX (2h-ago row, not the
    # 200h-ago one).
    check("J5 windowed last_activity = MAX within window",
          w24["main"]["last_activity"]
          == (now_dt - timedelta(hours=2)).isoformat()
          and w24["network"][0]["last_activity"]
          == (now_dt - timedelta(hours=3)).isoformat())
    # J6 — clamp semantics: 0/negative window_hours = all-time (never a
    # silently-empty result).
    wclamp = await scratch.watch_ad_launch_metrics(0)
    wneg = await scratch.watch_ad_launch_metrics(-5)
    check("J6 window_hours<=0 clamps to all-time",
          wclamp["total_sessions"] == 4 and wneg["total_sessions"] == 4)
    # J7 — the windowed PER-PAYLOAD breakdown filters identically.
    p24 = await scratch.watch_ad_payload_launch_metrics(8, 24)
    p7d = await scratch.watch_ad_payload_launch_metrics(8, 168)
    pall = await scratch.watch_ad_payload_launch_metrics(8)
    check("J7 windowed per-payload breakdown filters",
          len(p24) == 1 and p24[0]["sessions"] == 2
          and p24[0]["main_sessions"] == 1
          and p24[0]["network_sessions"] == 1
          and p7d[0]["sessions"] == 3 and pall[0]["sessions"] == 4)
    # J8 — CROSS-WINDOW reconciliation: per-payload session sum equals
    # the launch-rollup total for EVERY window (same cutoff convention).
    check("J8 cross-window reconciliation (payload sum == launch total)",
          sum(r["sessions"] for r in p24) == w24["total_sessions"] == 2
          and sum(r["sessions"] for r in p7d) == w7d["total_sessions"] == 3
          and sum(r["sessions"] for r in pall)
          == wall["total_sessions"] == 4)
    # J9 — READ-ONLY: windowed reruns are identical, no writes.
    before = await (await scratch.conn.execute(
        "SELECT COUNT(*), MAX(id) FROM watch_ad_sessions")).fetchone()
    w24b = await scratch.watch_ad_launch_metrics(24)
    p24b = await scratch.watch_ad_payload_launch_metrics(8, 24)
    after = await (await scratch.conn.execute(
        "SELECT COUNT(*), MAX(id) FROM watch_ad_sessions")).fetchone()
    check("J9 windowed metrics read-only (identical twice)",
          w24 == w24b and p24 == p24b and tuple(before) == tuple(after))
    # J10 — the admin Status panel renders the windows recency line with
    # the right counts (4 total · 3 in 7d · 2 in 24h).
    upd, ctx = FakeUpdate(), FakeContext()
    real_db = ns.db
    ns.db = scratch
    try:
        await ns.watch_ads_status_panel(upd, ctx)
        panel_text = str(CAPTURED.get("edit", ("", None))[0])
        # J11 — a session-less DB renders NO windows section (the empty
        # guarantee: fresh panel stays exactly as long as before).
        await scratch.conn.execute("DELETE FROM watch_ad_sessions")
        await scratch.conn.commit()
        await ns.watch_ads_status_panel(upd, ctx)
        empty_panel = str(CAPTURED.get("edit", ("", None))[0])
    finally:
        ns.db = real_db
    check("J10 admin panel shows the windows recency line",
          "Last 24h: 2 | Last 7d: 3" in panel_text
          and "windows" in panel_text)
    check("J11 no sessions → no windows section",
          "Last 24h" not in empty_panel and "Postbacks" in empty_panel)

    await scratch.close()
    for suffix in ("", "-wal", "-shm"):
        p = scratch_path + suffix
        if os.path.exists(p):
            os.remove(p)


# ===========================================================================
async def section_k(ns, db):
    print("\n[K] V27.2 hourly trend — buckets + window trend + panel line")
    from datetime import datetime, timedelta, timezone as _tz
    from app.storage.schema import Database as _Database

    scratch_path = os.path.join(_ROOT, "tests", "_v272_scratch.db")
    if os.path.exists(scratch_path):
        os.remove(scratch_path)
    scratch = _Database(scratch_path)
    await scratch.connect()
    await scratch.init_schema()

    # K1 — the zeroed structure on a fresh DB.
    t0 = await scratch.watch_ad_session_trend(24)
    check("K1 empty DB → zeroed trend (flat, no peak)",
          t0["current"] == 0 and t0["previous"] == 0
          and t0["trend"] == "flat" and t0["rewarded_trend"] == "flat"
          and t0["peak_hour"] is None and t0["peak_sessions"] == 0
          and len(t0["buckets"]) == 24
          and all(b["sessions"] == 0 for b in t0["buckets"]))

    # Controlled dataset with FULLY RELATIVE timestamps (deterministic
    # hour buckets regardless of the minute the suite runs):
    #   1h ago   → current window  (rewarded, network)
    #   2h ago   → current window  (pending,  main)
    #   2h ago   → current window  (rewarded, main)  — same hour bucket
    #   26h ago  → PREVIOUS window (rewarded, main)
    #   50h ago  → outside both windows
    now_dt = datetime.now(_tz.utc)
    now = now_dt.isoformat()
    cur = await scratch.conn.execute(
        "INSERT INTO network_bots(telegram_bot_id, username, "
        "owner_user_id, status, created_at, updated_at) VALUES "
        "(555003, 'trend_netbot', 8370454312, 'ACTIVE', ?, ?)",
        (now, now))
    await scratch.conn.commit()
    nb_id = int((await (await scratch.conn.execute(
        "SELECT id FROM network_bots WHERE telegram_bot_id=555003"
    )).fetchone())[0])
    await scratch.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date) "
        "VALUES (-100, 9201, 'TRDFID', 'TRDFUID', 'video', "
        "'trd.mp4', 1000, ?)", (now,))
    await scratch.conn.commit()
    idx = int((await (await scratch.conn.execute(
        "SELECT id FROM indexed_files WHERE message_id=9201")).fetchone())[0])
    await scratch.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, "
        "display_name, created_at, updated_at) VALUES "
        "('trd_pl', ?, 'active', 'Trend Payload', ?, ?)", (idx, now, now))
    await scratch.conn.commit()
    pid = int((await (await scratch.conn.execute(
        "SELECT id FROM payloads WHERE payload='trd_pl'")).fetchone())[0])

    async def ins(launch, status, hours_ago):
        when = (now_dt - timedelta(hours=hours_ago)).isoformat()
        await scratch.conn.execute(
            "INSERT INTO watch_ad_sessions(token, user_id, payload_id, "
            "status, created_at, expires_at, launch_network_bot_id) "
            "VALUES (?, 8922807758, ?, ?, ?, ?, ?)",
            (os.urandom(16).hex(), pid, status, when, when, launch))
        await scratch.conn.commit()

    await ins(nb_id, "rewarded", 1)    # current, network
    await ins(None, "pending", 2)      # current, main
    await ins(None, "rewarded", 2)     # current, main — same bucket
    await ins(0, "rewarded", 26)       # previous window, 0-launch main
    await ins(nb_id, "pending", 50)    # outside both windows

    t = await scratch.watch_ad_session_trend(24)
    # K2 — the bucket skeleton: 24 contiguous hour keys, oldest first,
    # ending at the current hour.
    keys = [b["hour_start"] for b in t["buckets"]]
    expect_last = now_dt.strftime("%Y-%m-%dT%H")
    contiguous = all(
        keys[i] == (datetime.strptime(keys[0], "%Y-%m-%dT%H")
                    + timedelta(hours=i)).strftime("%Y-%m-%dT%H")
        for i in range(len(keys)))
    check("K2 24 contiguous hour buckets, oldest first, ends at now",
          len(keys) == 24 and keys[-1] == expect_last and contiguous)

    # K3/K4/K5 — aggregation into the RIGHT bucket: the two 2h-ago rows
    # share one bucket (2 sessions, 1 rewarded, main 2 / network 0); the
    # 1h-ago row is the adjacent bucket (network split).
    key_2h = (now_dt - timedelta(hours=2)).strftime("%Y-%m-%dT%H")
    key_1h = (now_dt - timedelta(hours=1)).strftime("%Y-%m-%dT%H")
    b2 = next((b for b in t["buckets"] if b["hour_start"] == key_2h), None)
    b1 = next((b for b in t["buckets"] if b["hour_start"] == key_1h), None)
    check("K3 sessions land in the right hour bucket",
          b2 is not None and b1 is not None
          and b2["sessions"] == 2 and b1["sessions"] == 1
          and sum(b["sessions"] for b in t["buckets"]) == 3)
    check("K4 rewarded per bucket",
          b2["rewarded"] == 1 and b1["rewarded"] == 1)
    check("K5 launch split per bucket (main vs network)",
          b2["main_sessions"] == 2 and b2["network_sessions"] == 0
          and b1["main_sessions"] == 0 and b1["network_sessions"] == 1
          and all(b["main_sessions"] + b["network_sessions"]
                  == b["sessions"] for b in t["buckets"]))

    # K6 — the window comparison: current = 3 (1h+2h+2h), previous = 1
    # (the 26h-ago row), the 50h-ago row counted NOWHERE.
    check("K6 current vs previous + trend up",
          t["current"] == 3 and t["previous"] == 1
          and t["delta"] == 2 and t["trend"] == "up"
          and t["rewarded_current"] == 2 and t["rewarded_previous"] == 1
          and t["rewarded_delta"] == 1 and t["rewarded_trend"] == "up")
    # K7 — the outside-both-windows row is excluded from EVERY count.
    check("K7 rows older than both windows counted nowhere",
          t["current"] + t["previous"] == 4)   # 3 + 1, NOT 5
    # K8 — the peak: the 2h bucket (2 sessions — the strict max), the
    # scale max honest.
    check("K8 peak hour + chart scale",
          t["peak_hour"] == key_2h and t["peak_sessions"] == 2
          and t["max_bucket_sessions"] == 2)
    # K9 — clamp semantics: <=0 → 24; upper bound 168; a 3-hour window
    # keeps the recent buckets and moves the older ones out.
    t_c0 = await scratch.watch_ad_session_trend(0)
    t_cbig = await scratch.watch_ad_session_trend(500)
    t_3 = await scratch.watch_ad_session_trend(3)
    check("K9 window clamps (<=0→24, cap 168, N honored)",
          len(t_c0["buckets"]) == 24 and len(t_cbig["buckets"]) == 168
          and len(t_3["buckets"]) == 3 and t_3["current"] == 3
          and t_3["previous"] == 0)
    # K10 — READ-ONLY: identical structure twice, no writes.
    before = await (await scratch.conn.execute(
        "SELECT COUNT(*), MAX(id) FROM watch_ad_sessions")).fetchone()
    t_b = await scratch.watch_ad_session_trend(24)
    after = await (await scratch.conn.execute(
        "SELECT COUNT(*), MAX(id) FROM watch_ad_sessions")).fetchone()
    check("K10 trend read-only (identical twice)",
          t == t_b and tuple(before) == tuple(after))
    # K11 — the admin Status panel renders the Hourly trend line with
    # this 24h vs previous 24h comparison (3 · 1 ▲ up · peak 2).
    upd, ctx = FakeUpdate(), FakeContext()
    real_db = ns.db
    ns.db = scratch
    try:
        await ns.watch_ads_status_panel(upd, ctx)
        panel_text = str(CAPTURED.get("edit", ("", None))[0])
        # K12 — a session-less DB renders NO trend section (the empty
        # guarantee: fresh panel stays exactly as long as before).
        await scratch.conn.execute("DELETE FROM watch_ad_sessions")
        await scratch.conn.commit()
        await ns.watch_ads_status_panel(upd, ctx)
        empty_panel = str(CAPTURED.get("edit", ("", None))[0])
    finally:
        ns.db = real_db
    check("K11 admin panel shows the Hourly trend line",
          "Hourly trend" in panel_text
          and "This 24h: 3" in panel_text
          and "previous 24h: 1 \u25B2 up" in panel_text
          and f"peak 2 @ {key_2h[11:13]}:00" in panel_text)
    check("K12 no sessions → no trend section",
          "Hourly trend" not in empty_panel and "Postbacks" in empty_panel)

    await scratch.close()
    for suffix in ("", "-wal", "-shm"):
        p = scratch_path + suffix
        if os.path.exists(p):
            os.remove(p)


# ===========================================================================
async def section_l(ns, db):
    print("\n[L] V27.3 day-bucketed trend — 7d day buckets + panel line")
    from datetime import datetime, timedelta, timezone as _tz
    from app.storage.schema import Database as _Database

    scratch_path = os.path.join(_ROOT, "tests", "_v273_scratch.db")
    if os.path.exists(scratch_path):
        os.remove(scratch_path)
    scratch = _Database(scratch_path)
    await scratch.connect()
    await scratch.init_schema()

    # L1 — the zeroed day-mode structure on a fresh DB.
    t0 = await scratch.watch_ad_session_trend(168, bucket="day")
    check("L1 empty DB day mode → zeroed (bucket=day, 7 buckets)",
          t0["bucket"] == "day" and t0["window_hours"] == 168
          and t0["current"] == 0 and t0["previous"] == 0
          and t0["trend"] == "flat" and t0["peak_hour"] is None
          and len(t0["buckets"]) == 7
          and all(b["sessions"] == 0 for b in t0["buckets"]))

    # Controlled dataset with FULLY RELATIVE timestamps (deterministic day
    # buckets at ANY minute of the day — the expected keys are derived from
    # the row timestamps themselves, never assumed to be "today"):
    #   2h ago ×2  → same calendar day, current 7d (rewarded network +
    #               pending main — the aggregation pair + the split)
    #   30h ago    → current 7d, its own day bucket (rewarded main, 0-launch)
    #   192h (8d)  → PREVIOUS 7d window (rewarded network)
    #   384h (16d) → outside both windows (pending main)
    now_dt = datetime.now(_tz.utc)
    now = now_dt.isoformat()
    cur = await scratch.conn.execute(
        "INSERT INTO network_bots(telegram_bot_id, username, "
        "owner_user_id, status, created_at, updated_at) VALUES "
        "(555004, 'day_netbot', 8370454312, 'ACTIVE', ?, ?)",
        (now, now))
    await scratch.conn.commit()
    nb_id = int((await (await scratch.conn.execute(
        "SELECT id FROM network_bots WHERE telegram_bot_id=555004"
    )).fetchone())[0])
    await scratch.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date) "
        "VALUES (-100, 9301, 'DAYFID', 'DAYFUID', 'video', "
        "'day.mp4', 1000, ?)", (now,))
    await scratch.conn.commit()
    idx = int((await (await scratch.conn.execute(
        "SELECT id FROM indexed_files WHERE message_id=9301")).fetchone())[0])
    await scratch.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, "
        "display_name, created_at, updated_at) VALUES "
        "('day_pl', ?, 'active', 'Day Payload', ?, ?)", (idx, now, now))
    await scratch.conn.commit()
    pid = int((await (await scratch.conn.execute(
        "SELECT id FROM payloads WHERE payload='day_pl'")).fetchone())[0])

    async def ins(launch, status, hours_ago):
        when = (now_dt - timedelta(hours=hours_ago)).isoformat()
        await scratch.conn.execute(
            "INSERT INTO watch_ad_sessions(token, user_id, payload_id, "
            "status, created_at, expires_at, launch_network_bot_id) "
            "VALUES (?, 8922807758, ?, ?, ?, ?, ?)",
            (os.urandom(16).hex(), pid, status, when, when, launch))
        await scratch.conn.commit()

    await ins(nb_id, "rewarded", 2)     # current 7d, network
    await ins(None, "pending", 2)       # current 7d, main — SAME bucket
    await ins(0, "rewarded", 30)        # current 7d, 0-launch main
    await ins(nb_id, "rewarded", 192)   # previous 7d, network
    await ins(None, "pending", 384)     # outside both windows

    t = await scratch.watch_ad_session_trend(168, bucket="day")
    # L2 — the bucket skeleton: 7 contiguous DAY keys, oldest first, the
    # last one is today.
    keys = [b["hour_start"] for b in t["buckets"]]
    today = now_dt.strftime("%Y-%m-%d")
    contiguous = all(
        keys[i] == (datetime.strptime(keys[0], "%Y-%m-%d")
                    + timedelta(days=i)).strftime("%Y-%m-%d")
        for i in range(len(keys)))
    check("L2 7 contiguous day buckets, oldest first, ends today",
          len(keys) == 7 and keys[-1] == today and contiguous)

    # L3 — aggregation: the two 2h-ago rows share the SAME day bucket
    # (their expected key derived from the timestamp itself, so midnight
    # straddles stay deterministic).
    key_2h = (now_dt - timedelta(hours=2)).strftime("%Y-%m-%d")
    key_30h = (now_dt - timedelta(hours=30)).strftime("%Y-%m-%d")
    b2 = next((b for b in t["buckets"] if b["hour_start"] == key_2h), None)
    b30 = next((b for b in t["buckets"] if b["hour_start"] == key_30h), None)
    check("L3 same-day rows aggregate into one day bucket",
          b2 is not None and b2["sessions"] == 2 and b2["rewarded"] == 1
          and b30 is not None and b30["sessions"] == 1)

    # L4 — the window comparison: current = 3 (2h×2 + 30h), previous = 1
    # (the 8d-ago row), the 16d-ago row counted NOWHERE.
    check("L4 day-mode current vs previous + trend up",
          t["current"] == 3 and t["previous"] == 1
          and t["delta"] == 2 and t["trend"] == "up"
          and t["rewarded_current"] == 2 and t["rewarded_previous"] == 1
          and t["rewarded_trend"] == "up"
          and t["current"] + t["previous"] == 4)   # NOT 5
    # L5 — reconciliation by construction: current == sum(buckets).
    check("L5 current == sum(day buckets) exactly",
          t["current"] == sum(b["sessions"] for b in t["buckets"]))
    # L6 — the launch split per day bucket (main + network == sessions).
    check("L6 launch split per day bucket",
          b2["main_sessions"] == 1 and b2["network_sessions"] == 1
          and b30["main_sessions"] == 1 and b30["network_sessions"] == 0
          and all(b["main_sessions"] + b["network_sessions"]
                  == b["sessions"] for b in t["buckets"]))
    # L7 — peak: the 2h-ago day bucket (2 sessions), scale honest.
    check("L7 peak day + chart scale",
          t["peak_hour"] == key_2h and t["peak_sessions"] == 2
          and t["max_bucket_sessions"] == 2)
    # L8 — hour mode UNCHANGED as the default (the K section pins the
    # full hourly contract; this pins the mode field + bucket count).
    th = await scratch.watch_ad_session_trend(24)
    check("L8 default bucket=hour unchanged (24 hour buckets)",
          th["bucket"] == "hour" and len(th["buckets"]) == 24
          and th["buckets"][-1]["hour_start"].endswith(now_dt.strftime("%H")))
    # L9 — an unknown bucket value falls back to hour mode (never an
    # error — observability must never break the panel).
    tu = await scratch.watch_ad_session_trend(24, bucket="fortnight")
    check("L9 unknown bucket → hour fallback",
          tu["bucket"] == "hour" and len(tu["buckets"]) == 24)
    # L10 — days derivation from window_hours: 24h→1 day, 48h→2 days,
    # 500h→capped 168→7 days.
    t1 = await scratch.watch_ad_session_trend(24, bucket="day")
    t2 = await scratch.watch_ad_session_trend(48, bucket="day")
    tbig = await scratch.watch_ad_session_trend(500, bucket="day")
    check("L10 day-window derivation (24h→1d, 48h→2d, cap→7d)",
          len(t1["buckets"]) == 1 and len(t2["buckets"]) == 2
          and len(tbig["buckets"]) == 7 and tbig["window_hours"] == 168)
    # L11 — READ-ONLY: identical twice, no writes.
    before = await (await scratch.conn.execute(
        "SELECT COUNT(*), MAX(id) FROM watch_ad_sessions")).fetchone()
    t_b = await scratch.watch_ad_session_trend(168, bucket="day")
    after = await (await scratch.conn.execute(
        "SELECT COUNT(*), MAX(id) FROM watch_ad_sessions")).fetchone()
    check("L11 day-mode read-only (identical twice)",
          t == t_b and tuple(before) == tuple(after))
    # L12 — the admin Status panel renders the 7d day line under the
    # V27.2 hourly section ("This 7d: 3 · previous 7d: 1 ▲ up · rewarded 2
    # · peak 2 @ MM-DD · (V27.3 · day buckets)").
    upd, ctx = FakeUpdate(), FakeContext()
    real_db = ns.db
    ns.db = scratch
    try:
        await ns.watch_ads_status_panel(upd, ctx)
        panel_text = str(CAPTURED.get("edit", ("", None))[0])
        # L13 — a session-less DB renders NO 7d line (the empty
        # guarantee: fresh panel stays exactly as long as before).
        await scratch.conn.execute("DELETE FROM watch_ad_sessions")
        await scratch.conn.commit()
        await ns.watch_ads_status_panel(upd, ctx)
        empty_panel = str(CAPTURED.get("edit", ("", None))[0])
    finally:
        ns.db = real_db
    check("L12 admin panel shows the 7d day-trend line",
          "This 7d: 3" in panel_text
          and "previous 7d: 1 \u25B2 up" in panel_text
          and "(V27.3 \u00B7 day buckets)" in panel_text
          and f"peak 2 @ {key_2h[5:10]}" in panel_text)
    check("L13 no sessions → no 7d line",
          "This 7d:" not in empty_panel and "Postbacks" in empty_panel)

    await scratch.close()
    for suffix in ("", "-wal", "-shm"):
        p = scratch_path + suffix
        if os.path.exists(p):
            os.remove(p)


# ===========================================================================


# ===========================================================================
class _LogCap:
    """Capture structured log lines from the payload-bot logger."""

    def __init__(self):
        self.lines = []
        self._h = logging.Handler()
        self._h.emit = lambda rec: self.lines.append(rec.getMessage())  # type: ignore[method-assign]
        self._h.setLevel(logging.INFO)

    def __enter__(self):
        logging.getLogger("payload-bot").addHandler(self._h)
        logging.getLogger("payload-bot").setLevel(logging.INFO)
        return self

    def __exit__(self, *a):
        logging.getLogger("payload-bot").removeHandler(self._h)

    def has(self, prefix):
        return any(ln.startswith(prefix) for ln in self.lines)


class _FakeMember:
    def __init__(self, status):
        self.status = status


class _FakeFJBot:
    """Canned live-membership bot: get_chat_member returns member/left."""

    def __init__(self):
        self.joined = set()

    async def get_chat_member(self, channel_id, user_id):
        return _FakeMember("member" if int(channel_id) in self.joined
                           else "left")


def _make_fj(db):
    """The REAL FJ domain service on the suite DB (minimal port fakes —
    the same class of transport-boundary faking the suite already uses)."""
    from app.core.force_join.service import make_force_join_service

    async def _policy():
        return "request"

    return make_force_join_service(
        db=db, ENABLE_FORCE_JOIN=True,
        get_join_request_policy=_policy,
        _consume_join_request=lambda *a: None,
        _has_pending_join_request=lambda *a: False,
        _prune_join_requests=lambda: None,
        PENDING_JOIN_REQUESTS={})


async def section_m(ns, db):
    print("\n[M] V26 Force Join — play-gate state, identity, persistence")
    UID = 77001
    CHS = [-100111, -100222, -100333, -100444]
    for cid in CHS:
        await db.add_force_channel(cid, f"chan{abs(cid)}")
    await db.set_setting("force_join_enabled", "1")
    await db.set_setting("fj_mode", "fixed_order")
    await db.set_setting("fj_batch_size", "2")

    svc = _make_fj(db)
    bot = _FakeFJBot()

    # M1 — the requirement identity: stable for the same config, different
    #      for every changed component (mode / batch size / channel set).
    #      Every probe RESTORES the config so id1 stays the live identity.
    id1 = await svc.force_join_requirement_identity()
    id1b = await svc.force_join_requirement_identity()
    check("M1a identity stable for the same config", id1 == id1b
          and len(id1) == 12)
    await db.set_setting("fj_mode", "progressive_random")
    id_mode = await svc.force_join_requirement_identity()
    await db.set_setting("fj_mode", "fixed_order")
    await db.set_setting("fj_batch_size", "3")
    id_bs = await svc.force_join_requirement_identity()
    await db.set_setting("fj_batch_size", "2")
    await db.add_force_channel(-100555, "chan555")
    id_set = await svc.force_join_requirement_identity()
    await db.remove_force_channel(-100555)
    check("M1b identity changes with mode", id_mode != id1)
    check("M1c identity changes with batch size", id_bs != id1
          and id_bs != id_mode)
    check("M1d identity changes with the channel set", id_set != id_bs)
    check("M1e config restored -> identity back to id1",
          await svc.force_join_requirement_identity() == id1)

    # M2 — fj_state: the read-only (user, payload, identity) snapshot.
    st0 = await svc.fj_state(UID, payload_id=42, bot=bot)
    check("M2a fj_state snapshot shape + honest deny (nothing joined)",
          st0["decision"] == "deny" and st0["joined"] == 0
          and st0["requirement_identity"] == id1
          and st0["identity_matches"] is False
          and st0["payload_id"] == 42 and st0["user_id"] == UID)
    row_before = await db.get_fj_progress_row(UID)
    await svc.fj_state(UID, payload_id=42, bot=bot)
    check("M2b fj_state is read-only (no row created)",
          row_before is None and await db.get_fj_progress_row(UID) is None)

    # M3 — the state machine creates the first batch (batch size 2 from
    #      settings — the configured/admin value, never a silent override).
    with _LogCap() as cap:
        batch1 = await svc._get_fj_batch(UID, "", for_access=True,
                                         access_payload_id=42, bot=bot)
    b1_ids = [int(r["channel_id"]) for r in batch1]
    check("M3a first batch = the configured batch size (2)",
          len(b1_ids) == 2 and b1_ids == CHS[:2],
          f"got {b1_ids}")
    check("M3b FJ_STATE telemetry emitted on the state-machine run",
          cap.has("FJ_STATE"))

    # M4 — persistence across a simulated PROCESS RESTART (a brand-new
    #      service instance over the same DB): the same active batch, the
    #      persisted identity — nothing re-derived.
    svc2 = _make_fj(db)
    batch1b = await svc2._get_fj_batch(UID, "", for_access=True,
                                       access_payload_id=42, bot=bot)
    check("M4a active batch survives a process restart",
          [int(r["channel_id"]) for r in batch1b] == b1_ids)
    row = await db.get_fj_progress_row(UID)
    check("M4b requirement identity persisted on the row",
          row["requirement_identity"] == id1)

    # M5 — completed channels NEVER reappear: join batch 1 -> verify ->
    #      batch 2 appears WITHOUT batch-1 channels; re-verify is stable.
    bot.joined |= set(b1_ids)
    svc3 = _make_fj(db)
    with _LogCap() as cap3:
        batch2 = await svc3._get_fj_batch(UID, "", for_access=True,
                                          access_payload_id=42, bot=bot)
    b2_ids = [int(r["channel_id"]) for r in batch2]
    check("M5a batch ADVANCED past the completed channels",
          b2_ids and not (set(b2_ids) & set(b1_ids))
          and set(b2_ids) <= set(CHS), f"got {b2_ids}")
    check("M5b FJ_BATCH_ADVANCE telemetry emitted",
          cap3.has("FJ_BATCH_ADVANCE"))
    row = await db.get_fj_progress_row(UID)
    cb = __import__("json").loads(row["completed_batches"])
    check("M5c completed batches recorded exactly once (no duplicates)",
          cb.count(b1_ids) == 1, f"completed={cb}")
    batch2b = await svc3._get_fj_batch(UID, "", for_access=True,
                                       access_payload_id=42, bot=bot)
    check("M5d repeated verification is deterministic (same active batch)",
          [int(r["channel_id"]) for r in batch2b] == b2_ids)

    # M6 — opening ANOTHER payload never resets the requirement state.
    st_other = await svc3.fj_state(UID, payload_id=999, bot=bot)
    batch_other = await svc3._get_fj_batch(UID, "", for_access=True,
                                           access_payload_id=999, bot=bot)
    check("M6 opening another payload keeps the same active batch",
          [int(r["channel_id"]) for r in batch_other] == b2_ids
          and st_other["active_batch"] == b2_ids)

    # M7 — config changes: a NEWLY ADDED channel becomes new work (the
    #      identity change re-derives deterministically — FJ_STATE logs
    #      change=requirement_changed); a REMOVED channel never resurrects.
    await db.add_force_channel(-100555, "chan555")
    bot.joined |= set(b2_ids)
    svc4 = _make_fj(db)
    with _LogCap() as cap4:
        batch3 = await svc4._get_fj_batch(UID, "", for_access=True,
                                          access_payload_id=42, bot=bot)
    b3_ids = [int(r["channel_id"]) for r in batch3]
    check("M7a newly added channel becomes new work",
          -100555 in b3_ids, f"got {b3_ids}")
    check("M7b identity change re-derived deterministically (FJ_STATE)",
          cap4.has("FJ_STATE") and any(
              "change=requirement_changed" in ln for ln in cap4.lines))
    await db.remove_force_channel(-100555)
    bot.joined.add(-100555)
    svc5 = _make_fj(db)
    with _LogCap() as cap5:
        final = await svc5._get_fj_batch(UID, "", for_access=True,
                                         access_payload_id=42, bot=bot)
    check("M7c removed channel never resurrects (requirement completes)",
          final == [] and cap5.has("FJ_COMPLETE"))
    st_final = await svc5.fj_state(UID, payload_id=42, bot=bot)
    check("M7d final state: identity matches + decision allow",
          st_final["identity_matches"] is True
          and st_final["decision"] == "allow")

    # M8 — SHOW_ALL: no batching, all unjoined at once (legacy contract).
    await db.set_setting("fj_mode", "show_all")
    svc6 = _make_fj(db)
    bot2 = _FakeFJBot()
    all_un = await svc6._get_fj_batch(UID + 1, "", for_access=True,
                                      access_payload_id=42, bot=bot2)
    check("M8 SHOW_ALL returns every unjoined channel",
          [int(r["channel_id"]) for r in all_un] == CHS)
    await db.set_setting("fj_mode", "fixed_order")

    # M9 — requirement-identity re-derivation on a SEPARATE user: the row
    #      is created under config A, the config changes to B (mode +
    #      batch size) -> FJ_STATE change=requirement_changed + the NEW
    #      requirement's one-time order (persisted, NEVER reshuffled on
    #      subsequent reads/restarts).
    UID2 = UID + 50
    await db.set_setting("fj_mode", "fixed_order")
    await db.set_setting("fj_batch_size", "2")
    svcA = _make_fj(db)
    await svcA._get_fj_batch(UID2, "", for_access=True,
                             access_payload_id=42, bot=bot2)
    await db.set_setting("fj_mode", "progressive_random")
    await db.set_setting("fj_batch_size", "4")
    svcB = _make_fj(db)
    with _LogCap() as capB:
        await svcB._get_fj_batch(UID2, "", for_access=False, bot=bot2)
    rowB = await db.get_fj_progress_row(UID2)
    orderB = __import__("json").loads(rowB["channel_order"])
    check("M9a requirement change re-derived (FJ_STATE "
          "change=requirement_changed logged)",
          capB.has("FJ_STATE") and any(
              "change=requirement_changed" in ln for ln in capB.lines))
    for i in range(2):
        svcC = _make_fj(db)
        await svcC._get_fj_batch(UID2, "", for_access=False, bot=bot2)
        rowC = await db.get_fj_progress_row(UID2)
        check(f"M9b progressive order never reshuffles (read {i + 1})",
              __import__("json").loads(rowC["channel_order"]) == orderB)
    await db.set_setting("fj_mode", "fixed_order")
    await db.set_setting("fj_batch_size", "2")


# ===========================================================================
async def section_n(ns, db):
    print("\n[N] V26 callback_data — compact ids, central guard, manager walk")
    import telegram
    now = datetime.now(timezone.utc).isoformat()
    CH = -1004460709020
    LONG = "a" * 64  # the legal maximum slug — every prefix must stay ≤64B

    await db.conn.execute(
        "INSERT OR IGNORE INTO storage_channels(channel_id, title, is_active)"
        " VALUES (?, 'StorageChan', 1)", (CH,))
    await db.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date) "
        "VALUES (?, ?, 'FIDLONG', 'FUIDLONG', 'video', ?, 999, ?)",
        (CH, 9901, LONG + ".mp4", now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM indexed_files WHERE channel_id=? AND message_id=?",
        (CH, 9901))
    idx = (await cur.fetchone())[0]
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "created_at, updated_at) VALUES (?, ?, 'active', 'FORCE_JOIN', ?, ?)",
        (LONG, idx, now, now))
    await db.conn.commit()
    cur = await db.conn.execute("SELECT id FROM payloads WHERE payload=?",
                                (LONG,))
    LPID = int((await cur.fetchone())[0])

    # N1 — the compact reversible internal id helpers.
    from app.core.payload.service import (  # noqa: E402
        compact_callback_arg, is_internal_id_ref)
    check("N1a is_internal_id_ref accepts i<id>",
          is_internal_id_ref(f"i{LPID}") is True)
    check("N1b is_internal_id_ref rejects slugs/links",
          is_internal_id_ref(LONG) is False
          and is_internal_id_ref("c7f3a9b2") is False
          and is_internal_id_ref("m872") is False)
    check("N1c compact_callback_arg keeps short link forms",
          compact_callback_arg("c7f3a9b2") == "c7f3a9b2"
          and compact_callback_arg("m872") == "m872")
    check("N1d compact_callback_arg maps a named slug to i<id>",
          compact_callback_arg(LONG, LPID) == f"i{LPID}")

    # N2 — the Join/Verify keyboard with a 64-char slug: verify:i<id>.
    await db.add_force_channel(-100777, "verifychan")

    class _FakeKBBot:
        async def export_chat_invite_link(self, channel_id):
            return "https://t.me/+demo_invite"

        async def get_chat(self, channel_id):
            class _C:
                id = channel_id
                title = "Chan"
                type = "channel"
                username = "verifychan"
            return _C()

    kb = await ns.build_force_join_keyboard(_FakeKBBot(), LONG)
    vbtns = [b for row in kb.inline_keyboard for b in row
             if (b.callback_data or "").startswith("verify:")]
    check("N2 verify keyboard carries the compact id (≤64B) for a max slug",
          len(vbtns) == 1 and vbtns[0].callback_data == f"verify:i{LPID}"
          and len(vbtns[0].callback_data.encode()) <= 64,
          str([b.callback_data for b in vbtns]))

    # N3 — the retry-failed-file button with a max slug: retryfile:i<id>:<pk>.
    CAPTURED.clear()
    frow = await db.get_indexed_file_by_id(idx)
    await ns._send_delivery_failure(None, 12345, frow, LONG)
    sent = CAPTURED.get("send")
    rbtns = [b for row in (sent[1].inline_keyboard if sent[1] else [])
             for b in row
             if (b.callback_data or "").startswith("retryfile:")]
    check("N3 retryfile button carries the compact id (≤64B)",
          len(rbtns) == 1
          and rbtns[0].callback_data == f"retryfile:i{LPID}:{idx}"
          and len(rbtns[0].callback_data.encode()) <= 64,
          str([b.callback_data for b in rbtns]))

    # N4 — the CENTRAL pre-send guard: an oversized callback is DROPPED
    #      (the whole message would otherwise be rejected), the rest of
    #      the keyboard survives, and the tripwire log fires.
    bad_kb = telegram.InlineKeyboardMarkup([
        [telegram.InlineKeyboardButton("Good", callback_data="ok:123")],
        [telegram.InlineKeyboardButton("Bad", callback_data="x:" + "b" * 80)],
        [telegram.InlineKeyboardButton("Also good", callback_data="ok:456")],
    ])
    with _LogCap() as cap:
        fixed = ns.validate_keyboard_markup(bad_kb)
    flat = [b for row in fixed.inline_keyboard for b in row]
    check("N4a oversized callback button dropped, the rest intact",
          [b.callback_data for b in flat] == ["ok:123", "ok:456"])
    check("N4b CALLBACK_DATA_OVER_LIMIT tripwire logged",
          cap.has("CALLBACK_DATA_OVER_LIMIT"))
    safe_kb = telegram.InlineKeyboardMarkup([
        [telegram.InlineKeyboardButton("Good", callback_data="ok:123")]])
    check("N4c a safe keyboard passes byte-identically",
          ns.validate_keyboard_markup(safe_kb) is safe_kb)

    # N5 — the full Payload Manager walk on a max-slug payload: EVERY
    #      generated callback_data is ≤64 bytes (list -> detail -> the
    #      action row -> preview -> website panel entry).
    upd, ctx = FakeUpdate(), FakeContext()
    CAPTURED.clear()
    await ns.pm_payload_detail(upd, ctx, LPID)
    kb = (CAPTURED.get("edit") or CAPTURED.get("send"))[1]
    bad = [b.callback_data for row in kb.inline_keyboard for b in row
           if b.callback_data and len(b.callback_data.encode()) > 64]
    check("N5a manager detail keyboard — zero oversized callbacks", not bad,
          str(bad))
    CAPTURED.clear()
    # The Website Control panel lives in website_ui (not on NS) and takes
    # the deps namespace — call the REAL panel with the suite transport.
    from app.presentation.telegram import website_ui as _wui  # noqa: E402
    await _wui.website_panel(
        upd, ctx, types.SimpleNamespace(db=db,
                                        safe_edit_text=fake_safe_edit_text))
    wkb = (CAPTURED.get("edit") or CAPTURED.get("send") or (None, None))[1]
    if wkb is not None:
        wflat = [b for row in wkb.inline_keyboard for b in row]
        wtexts = " | ".join(b.text for b in wflat)
        wcb = [b.callback_data for b in wflat if b.callback_data]
        check("N5b Website panel exposes BOTH upload workflows",
              "Upload Package Payload" in wtexts
              and "Upload Single Payload" in wtexts
              and "wsite:addpkg" in wcb and "wsite:addsingle" in wcb)
    else:
        check("N5b Website panel exposes BOTH upload workflows", False,
              "panel not rendered")


# ===========================================================================
async def section_o(ns, db):
    print("\n[O] V26 Website Payload — Package + Single end-to-end workflows")
    import types as _types
    from app.web.site.service import make_website_service
    from app.presentation.telegram import website_ui as _wui

    now = datetime.now(timezone.utc).isoformat()
    CH = -1004460709030

    async def _mk_file(mid, name):
        await db.conn.execute(
            "INSERT INTO indexed_files(channel_id, message_id, file_id, "
            "file_unique_id, media_type, file_name, file_size, upload_date) "
            "VALUES (?, ?, ?, ?, 'video', ?, 1000, ?)",
            (CH, mid, f"FID{mid}", f"FUID{mid}", name, now))
        await db.conn.commit()
        cur = await db.conn.execute(
            "SELECT id FROM indexed_files WHERE channel_id=? AND message_id=?",
            (CH, mid))
        return int((await cur.fetchone())[0])

    await db.conn.execute(
        "INSERT OR IGNORE INTO storage_channels(channel_id, title, is_active)"
        " VALUES (?, 'StorageChan2', 1)", (CH,))
    idx1 = await _mk_file(8001, "part1.mp4")
    idx2 = await _mk_file(8002, "part2.mp4")
    idx3 = await _mk_file(8003, "part3.mp4")

    # ---- THE PACKAGE WORKFLOW (picker -> wizard -> publish -> render) ----
    coll_code = "9a8b7c6d"
    await db.conn.execute(
        "INSERT INTO collections(collection_id, channel_id, file_count, "
        "created_at) VALUES (?, ?, 3, ?)", (coll_code, CH, now))
    for pos, mid in enumerate((8001, 8002, 8003), start=1):
        await db.conn.execute(
            "INSERT INTO collection_items(collection_id, channel_id, "
            "message_id, position) VALUES (?, ?, ?, ?)",
            (coll_code, CH, mid, pos))
    # V26 FINAL (Part 11): the collection's WRAPPER payload row (the
    # canonical c<code> routing row) carries the human display_name the
    # package picker must show.
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "display_name, created_at, updated_at) VALUES "
        "(?, ?, 'active', 'OPEN', 'Cinematic Pack', ?, ?)",
        (f"c{coll_code}", idx1, now, now))
    await db.conn.commit()

    svc = make_website_service(db)
    canon = await svc.resolve_canonical_for_wizard("c" + coll_code)
    check("O1a package canonical resolves (kind=collection, 3 files)",
          canon and canon["kind"] == "collection"
          and canon["collection_id"] == coll_code
          and int(canon["file_count"]) == 3)

    # Drive the REAL admin surface: picker -> wizard (prefilled) -> publish.
    sent = []

    async def _edit(q, text, reply_markup=None, **kw):
        sent.append((text, reply_markup))
        return True

    async def _send(bot, chat_id, text, reply_markup=None, **kw):
        sent.append((text, reply_markup))
        return True

    async def _answer(q, text=None, show_alert=False):
        return True

    async def _log_action(*a, **kw):
        return True

    async def _rpl(link):
        return None

    deps = _types.SimpleNamespace(db=db, safe_edit_text=_edit,
                                  safe_send_text=_send,
                                  safe_answer_callback=_answer,
                                  log_admin_action=_log_action,
                                  resolve_payload_link=_rpl)
    upd, ctx = FakeUpdate(), FakeContext()
    ctx.user_data = {}

    # The REAL wizard paths hand context.bot to their transport
    # (safe_send_text) — the PTB contract, faked at the boundary.
    class _FakeWizardBot:
        pass

    ctx.bot = _FakeWizardBot()

    # The picker panel (step 0) with its compact callbacks — V26 FINAL
    # (Part 9): the MULTI-SELECT picker (☑/☐ toggles + Select All /
    # Clear All + Continue; every callback compact).
    await _wui.website_package_picker(upd, ctx, deps, page=1)
    pk_kb = sent[-1][1]
    pk_flat = [b for row in pk_kb.inline_keyboard for b in row]
    pk_cb = [b.callback_data for b in pk_flat if b.callback_data]
    check("O1b package picker lists the collection with a compact callback",
          f"wsite:pktog:{coll_code}" in pk_cb
          and "wsite:pkcont" in pk_cb
          and "wsite:pkall" in pk_cb
          and "wsite:pkclr" in pk_cb
          and all(len(c.encode()) <= 64 for c in pk_cb))
    # V26 FINAL (Part 11): the picker shows the HUMAN package title
    # (the wrapper payload's display_name fallback chain), never a bare
    # c<code> label.
    check("O1b2 the picker entry shows the HUMAN package title",
          any("Cinematic Pack" in (b.text or "")
              for b in pk_flat))

    # Toggle it -> Continue -> the prefilled wizard starts (thumbnail
    # step) — the V26 FINAL single-selection path.
    await _wui.handle_wsite_callback(
        _fake_cb(upd, f"wsite:pktog:{coll_code}"), ctx, deps)
    sel_state = ctx.user_data.get(_wui.WSITE_PKG_PICK_KEY) or {}
    check("O1b3 the toggle puts the code in the server-side selection",
          sel_state.get("selected") == [coll_code])
    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:pkcont"), ctx, deps)
    wiz = ctx.user_data.get(_wui.WSITE_WIZARD_KEY) or {}
    check("O1c wizard started with the selection prefilled",
          wiz.get("prefill_link") == "c" + coll_code
          and wiz.get("prefill_kind") == "collection")

    # Skip the thumbnail -> the canonical resolves AUTOMATICALLY (no paste)
    # -> the preview renders -> publish -> the listing exists + published.
    sent.clear()
    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:wskip"), ctx, deps)
    check("O1d skip resolves the selection automatically (preview shown)",
          any("wizard preview" in (t or "") for t, _ in sent))
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wpub"), ctx, deps)
    listing = await db.find_website_payload_for_canonical(
        collection_id=coll_code)
    check("O1e package listing created + published",
          listing is not None and int(listing["published"]) == 1)
    pub_kb = sent[-1][1]
    pub_flat = [b for row in pub_kb.inline_keyboard for b in row]
    check("O1f publish success carries an Open Website URL button",
          any(b.url for b in pub_flat))

    # The website side: files visible in order + refs minted (the REAL
    # listing detail the site renders from).
    if listing is None:
        check("O1g website detail: all 3 files visible in collection order",
              False, "no listing (see O1a/O1e)")
    else:
        detail = await svc.get_listing_detail(str(listing["opaque_id"]))
        files = detail.get("files") or []
        check("O1g website detail: all 3 files visible in collection order",
              len(files) == 3
              and [int(f.get("file_pk") or 0) for f in files]
              == [idx1, idx2, idx3])

    # ---- THE SINGLE WORKFLOW ----
    sslug = "single_v26_wf"
    # A STANDALONE file (NOT a collection member): bot-25 expansion
    # (a payload whose canonical file belongs to a collection expands to
    # the full ordered list) must NOT apply — the single listing stays
    # ONE part.
    idx4 = await _mk_file(8004, "standalone.mp4")
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "created_at, updated_at) VALUES (?, ?, 'active', 'OPEN', ?, ?)",
        (sslug, idx4, now, now))
    await db.conn.commit()
    canon2 = await svc.resolve_canonical_for_wizard(sslug)
    check("O2a single canonical resolves (kind=payload)",
          canon2 and canon2["kind"] == "payload"
          and canon2["payload"] == sslug)

    sent.clear()
    ctx2 = FakeContext()
    ctx2.user_data = {}
    ctx2.bot = ctx.bot
    await _wui.website_single_picker(upd, ctx2, deps, page=1)
    sp_kb = sent[-1][1]
    sp_flat = [b for row in sp_kb.inline_keyboard for b in row]
    sp_cb = [b.callback_data for b in sp_flat if b.callback_data]
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload=?", (sslug,))
    spid = int((await cur.fetchone())[0])
    check("O2b single picker lists the payload with a compact id callback",
          f"wsite:spick:{spid}" in sp_cb
          and all(len(c.encode()) <= 64 for c in sp_cb))
    await _wui.handle_wsite_callback(_fake_cb(upd, f"wsite:spick:{spid}"),
                                     ctx2, deps)
    wiz2 = ctx2.user_data.get(_wui.WSITE_WIZARD_KEY) or {}
    check("O2c wizard prefilled with the payload slug",
          wiz2.get("prefill_link") == sslug
          and wiz2.get("prefill_kind") == "payload")
    sent.clear()
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wskip"), ctx2, deps)
    check("O2d the single selection auto-resolves to the preview",
          any("wizard preview" in (t or "") for t, _ in sent))
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wpub"), ctx2, deps)
    listing2 = await db.find_website_payload_for_canonical(payload_id=spid)
    check("O2e single listing created + published",
          listing2 is not None and int(listing2["published"]) == 1)
    detail2 = await svc.get_listing_detail(str(listing2["opaque_id"]))
    check("O2f website detail: the single file visible for playback",
          len(detail2.get("files") or []) == 1
          and int(detail2["files"][0]["file_pk"]) == idx4)

    # O3 — identity consistency: the two listings reference the canonical
    #      identities (payload_id XOR collection_id); opaque ids differ;
    #      the wizard guard blocks a second listing for the same canonical.
    check("O3a listings reference the canonical identities",
          listing is not None and listing2 is not None
          and listing["collection_id"] == coll_code
          and listing["payload_id"] is None
          and listing2["payload_id"] == spid
          and listing2["collection_id"] is None)
    check("O3b opaque ids are distinct per listing",
          listing is not None and listing2 is not None
          and listing["opaque_id"] != listing2["opaque_id"])
    dup = await db.find_website_payload_for_canonical(payload_id=spid)
    check("O3c the wizard guard returns the EXISTING listing (no duplicates)",
          dup is not None and int(dup["id"]) == int(listing2["id"]))


def _fake_cb(upd, data):
    upd.callback_query.data = data
    return upd


# ===========================================================================
async def section_p(ns, db):
    print("\n[P] V26 telemetry — the allowlisted PLAYER_*/AGE_GATE_* contract")
    from app.web.site import pages as _pages

    required = {
        "PLAYER_OPEN", "PLAYER_READY", "PLAYER_PLAY", "PLAYER_PAUSE",
        "QUALITY_CHANGE", "PLAYER_BACK", "PLAYER_DESTROY",
        "PLAYER_STREAM_ERROR", "PLAYER_REAUTH", "PLAYER_CLOSE",
        "AGE_GATE_RENDER", "AGE_GATE_HANDLER_ATTACHED",
        "AGE_GATE_IDENTITY_WAIT", "AGE_GATE_CLICK",
        "AGE_GATE_IDENTITY_READY", "AGE_GATE_REQUEST_START",
        "AGE_GATE_REQUEST_RESULT", "AGE_GATE_STATE_UPDATED",
        "AGE_GATE_TRANSITION_COMPLETE", "AGE_GATE_ERROR",
        # V26 FINAL (Parts 7+8): the SPA navigation lifecycle + the
        # website action lifecycle (both added by the bot-39 production
        # defect fix round).
        "SITE_NAV_PUSH", "SITE_NAV_REPLACE", "SITE_NAV_POP",
        "SITE_NAV_BACK", "SITE_NAV_FALLBACK", "SITE_NAV_ERROR",
        "SITE_ACTION_START", "SITE_ACTION_SUCCESS",
        "SITE_ACTION_FAILED",
        # BOT-43 (§4 work-stream C): the player CONTROL-SURFACE lifecycle
        # added to the pages.py allowlist (the html.py custom controls emit
        # these client-side; pinned end-to-end by tests/test_bot43_fj.py).
        "PLAYER_CONTROL_MODE", "PLAYER_SPEED_CHANGE",
        "PLAYER_QUALITY_CHANGE", "PLAYER_FULLSCREEN",
        # BOT-45/46 (Task G): the end-screen + fullscreen-lifecycle events
        # (end screen ONLY at 'ended', Replay/Next Part controls, the
        # chrome-hide fullscreen ENTER/EXIT pair) added to the allowlist.
        "PLAYER_END_SCREEN", "PLAYER_NEXT_PART", "PLAYER_REPLAY",
        "PLAYER_FULLSCREEN_ENTER", "PLAYER_FULLSCREEN_EXIT",
    }
    have = set(_pages._TELEMETRY_EVENTS)
    check("P1 the telemetry allowlist covers every required event",
          required <= have, str(sorted(required - have)))
    check("P2 no unexpected event names in the allowlist",
          have <= required, str(sorted(have - required)))
    # The safe-field contract: no event allows token/initData/url fields.
    dangerous = {"token", "init_data", "initData", "url", "session",
                 "callback_data", "password"}
    leaks = {ev: (fields & dangerous) for ev, fields in
             _pages._TELEMETRY_EVENTS.items() if fields & dangerous}
    check("P3 no secret-bearing fields in any event allowlist", not leaks,
          str(leaks))

    # V26.x browser-QA regression (the DOUBLE-EMITTED gate script): the
    # full-load path once rendered the Age Gate script TWICE — once
    # inside <main> (the V26 placement fix) and ONCE MORE after </html>
    # (the historical trailing "+ script" append left behind). A full
    # page load then executed the gate script twice: double RENDER
    # telemetry, a SECOND click listener with its own inFlight closure,
    # and a DOUBLE POST to /site/api/session/age on the confirm click
    # (browser-verified: 2 POSTs per click; the SPA path never saw it
    # because applyDoc swaps <main> only). Pin the contract for ALL
    # FOUR script-bearing screens: zero <script> opens after </html>,
    # and the Age Gate script emitted EXACTLY ONCE.
    from app.web.site import screens as _screens
    for _name, _fn in (
            ("login", lambda: _screens.login_page()),
            ("fj_gate", lambda: _screens.fj_gate_page([])),
            ("age_gate", lambda: _screens.age_gate_page(username="t")),
            ("settings", lambda: _screens.settings_page()),
    ):
        try:
            _html = _fn()
        except TypeError:
            continue  # a screen needing richer args — skip (not the point)
        _html_c = _html.find("</html>")
        _scripts_after_doc = (_html.count("<script>", _html_c + 1)
                              if _html_c >= 0 else -1)
        check(f"P4 {_name} page: ZERO <script> tags after </html> "
              f"(no trailing double emission)", _scripts_after_doc == 0,
              f"scripts_after_doc={_scripts_after_doc}")
    _gate_html = _screens.age_gate_page(username="t")
    _gate_renders = _gate_html.count("AGE_GATE_HANDLER_ATTACHED")
    check("P4b age gate script emitted EXACTLY ONCE (no double emission)",
          _gate_renders == 1,
          f"AGE_GATE_HANDLER_ATTACHED occurrences={_gate_renders}")




async def section_q(ns, db):
    """[Q] V26.x Phase 3 — Delivery Channel SOURCE cleanup.

    The production evidence (bot-38.log): the FDB created Delivery
    Channel messages 110-115, NETWORK_BOT_ALBUM_COPY_SUCCESS delivered
    6/6, DELIVERY_ALBUM_RESULT delivered=6 — and the channel sources
    were NEVER deleted. This section pins the fixed contract BEHAVIORALLY
    (a real DeliveryJobEngine over the real DB + simulated Telegram):
      Storage Channel -> FDB -> Delivery Channel -> Network Bot ->
      CONFIRMED user delivery -> DELETE the exact Delivery Channel source
      (never the Storage master; the USER TTL cleanup stays separate).
    """
    print("\n[Q] V26.x Phase 3 — Delivery Channel source cleanup")
    from app.network.file_delivery import DeliveryJobEngine

    # ---- the simulated Telegram world -------------------------------
    class FakeFDB:
        """Stands in for FileDeliveryBotManager: a dict-backed Delivery
        Channel message store + injectable failure modes. The STORAGE
        master store is separate and NEVER deletable through this API."""
        def __init__(self):
            self.channel_msgs = {}     # (chat_id, msg_id) -> payload
            self.next_mid = 110
            self.storage_msgs = {(-1004460709020, 801): "master-801"}
            self.delete_fail = {}      # (chat, mid) -> verdict to return
            self.delete_calls = []     # (chat, mid) log
            self.retry_once = set()    # (chat, mid): first delete → retry_after

        async def copy_storage_to_delivery_channel(
                self, delivery_channel_id, storage_chat_id,
                storage_message_id, *, protect_content=False,
                file_row=None, job_id=None):
            if (storage_chat_id, storage_message_id) not in self.storage_msgs:
                return None, "bad_request:source_not_copyable:gone"
            mid = self.next_mid
            self.next_mid += 1
            self.channel_msgs[(int(delivery_channel_id), mid)] = {
                "src": (storage_chat_id, storage_message_id)}
            return mid, "ok"

        async def delete_delivery_channel_message(
                self, delivery_channel_id, message_id, *, job_id=None):
            key = (int(delivery_channel_id), int(message_id))
            self.delete_calls.append(key)
            if key in self.retry_once:
                # a one-shot Telegram flood limit (RetryAfter)
                self.retry_once.discard(key)
                return "retry_after"
            if key in self.delete_fail:
                verdict = self.delete_fail[key]
                # a failed delete NEVER removes the message
                if verdict == "ok_along_fail":
                    pass
                else:
                    return verdict
            if key in self.channel_msgs:
                del self.channel_msgs[key]
                return "ok"
            # not present -> already gone -> IDEMPOTENT SUCCESS
            return "ok"

        async def delete_relay_message(self, group, mid):
            return True

    class FakeMsg:
        def __init__(self, mid):
            self.message_id = mid

    class FakeNetworkBot:
        """Stands in for a PTB worker bot: copyMessage/copyMessages from
        the Delivery Channel to the user chat."""
        def __init__(self, fdb, user_chat=555000111):
            self.fdb = fdb
            self.user_chat = user_chat
            self.user_msgs = {}        # user msg id -> source (chat, mid)
            self.next_user_mid = 900
            self.copy_fail = set()     # source mids raising message-gone
            self.forbidden = set()     # source mids raising Forbidden

        async def copy_message(self, chat_id, from_chat_id, message_id,
                               protect_content=False):
            from telegram.error import BadRequest, Forbidden
            key = (int(from_chat_id), int(message_id))
            if int(message_id) in self.forbidden:
                # an honest NON-self-healing Stage-B failure (the user
                # blocked the network bot) — the source must survive
                raise Forbidden("Bot was blocked by the user")
            if int(message_id) in self.copy_fail:
                # message-gone: triggers the §7/§10 stale self-heal
                raise BadRequest("Message to copy not found")
            if key not in self.fdb.channel_msgs:
                raise BadRequest("Message to copy not found")
            mid = self.next_user_mid
            self.next_user_mid += 1
            self.user_msgs[mid] = key
            return FakeMsg(mid)

        async def copy_messages(self, chat_id, from_chat_id, message_ids,
                                protect_content=False):
            return [await self.copy_message(
                chat_id=chat_id, from_chat_id=from_chat_id,
                message_id=mid, protect_content=protect_content)
                for mid in message_ids]

    STORAGE = -1004460709020
    CHANNEL = -1004476310327
    # seed the network_bots rows the engine's Delivery Channel resolution
    # reads (get_network_bot -> delivery_channel_chat_id); keep the REAL
    # autoincrement ids (earlier sections inserted their own bots).
    from datetime import timezone as _tz  # noqa: F401 — local, like sections D/F
    _now = datetime.now(_tz.utc).isoformat()
    _nids = []
    for _i in range(7):
        cur = await db.conn.execute(
            "INSERT INTO network_bots(telegram_bot_id, username, "
            "owner_user_id, status, delivery_channel_chat_id, created_at, "
            "updated_at) VALUES (?, ?, 8370454312, 'ACTIVE', ?, ?, ?)",
            (555900 + _i, f"q_netbot_{_i}", CHANNEL, _now, _now))
        _nids.append(int(cur.lastrowid))
    await db.conn.commit()

    def _make_world(idx):
        f = FakeFDB()
        b = FakeNetworkBot(f)
        return f, b, DeliveryJobEngine(db, f), _nids[idx]

    fdb, bot, eng, NID1 = _make_world(0)

    def frows(n):
        return [{"id": 8000 + i, "channel_id": STORAGE, "message_id": 801,
                 "media_type": "video", "file_name": f"part{i}.mp4",
                 "file_size": 1024, "file_unique_id": f"QUID{i}"}
                for i in range(n)]

    # Q1+Q2+Q3+Q4 — the happy album: FDB copies, network delivers, the
    # EXACT sources are deleted, the STORAGE master remains.
    before = dict(fdb.storage_msgs)
    mids, sent = await eng.deliver_album(
        network_bot=bot, chat_id=bot.user_chat, file_rows=frows(3),
        protect_content=False, payload_code="q1", payload_id=None,
        user_id=8922807758, network_bot_id=NID1)
    check("Q1 FDB copied the sources to the Delivery Channel",
          sent == 3 and len(mids) == 3)
    check("Q2 Network Bot delivered all 3 to the user",
          len(bot.user_msgs) == 3)
    check("Q3 the exact Delivery Channel sources were deleted",
          not any(k for k in fdb.channel_msgs if k[0] == CHANNEL))
    check("Q4 the Storage Channel MASTER remains",
          fdb.storage_msgs == before)

    # Q5 — a FAILED network delivery preserves the source (retry needs
    # it). Forbidden (the user blocked the network bot) is an honest,
    # NON-self-healing Stage-B failure — unlike "message to copy not
    # found", which routes into the §7/§10 stale-reference self-heal and
    # legitimately re-delivers from a fresh Stage-A message.
    fdb2, bot2, eng2, NID2 = _make_world(1)
    bot2.forbidden.add(110)  # the first source copy must fail
    mids2, sent2 = await eng2.deliver_album(
        network_bot=bot2, chat_id=bot2.user_chat, file_rows=frows(1),
        protect_content=False, payload_code="q5", payload_id=None,
        user_id=8922807758, network_bot_id=NID2)
    check("Q5 failed Network delivery preserves the source",
          sent2 == 0
          and (fdb2.channel_msgs.get((CHANNEL, 110)) is not None))

    # Q6 — album: every successful source is deleted (6/6, the exact
    # bot-38.log shape).
    fdb3, bot3, eng3, NID3 = _make_world(2)
    mids3, sent3 = await eng3.deliver_album(
        network_bot=bot3, chat_id=bot3.user_chat, file_rows=frows(6),
        protect_content=False, payload_code="q6", payload_id=None,
        user_id=8922807758, network_bot_id=NID3)
    check("Q6 album deletes ALL successful sources (6/6)",
          sent3 == 6 and not [k for k in fdb3.channel_msgs
                              if k[0] == CHANNEL])

    # Q7 — partial album failure preserves the UNDELIVERED sources only.
    # Forbidden for two members: honest per-member failures — only the
    # CONFIRMED deliveries' sources are cleaned, the failed members'
    # sources survive for the sweeper's retry plane.
    fdb4, bot4, eng4, NID4 = _make_world(3)
    bot4.forbidden.update({111, 113})  # two of four members fail
    mids4, sent4 = await eng4.deliver_album(
        network_bot=bot4, chat_id=bot4.user_chat, file_rows=frows(4),
        protect_content=False, payload_code="q7", payload_id=None,
        user_id=8922807758, network_bot_id=NID4)
    delivered_sources = {bot4.user_msgs[u] for u in mids4}
    remaining = {k for k in fdb4.channel_msgs if k[0] == CHANNEL}
    check("Q7 partial failure preserves ONLY undelivered sources",
          sent4 == 2 and len(mids4) == 2
          and delivered_sources.isdisjoint(remaining)
          and len(remaining) == 2)

    # Q8 — idempotent already-deleted: a repeat delete of a gone message
    # is a SUCCESS (the flag clears; no exception, no spin).
    fdb5, bot5, eng5, NID5 = _make_world(4)
    await eng5.deliver_album(
        network_bot=bot5, chat_id=bot5.user_chat, file_rows=frows(1),
        protect_content=False, payload_code="q8", payload_id=None,
        user_id=8922807758, network_bot_id=NID5)
    # simulate the crash case: the flag is still set although the message
    # is gone (a first delete already happened out-of-band)
    rows = await db.list_delivery_jobs(limit=500)
    q8job = [r for r in rows if r.get("payload_code") == "q8"
             and r.get("status") == "DELIVERED"][0]
    await db.update_delivery_job(int(q8job["id"]),
                                 channel_cleanup_pending=1)
    ok = await eng5._cleanup_channel_source(
        int(q8job["id"]), CHANNEL, int(q8job["delivery_message_id"]),
        nid=NID5, via="q8_idempotent")
    row = await db.get_delivery_job(int(q8job["id"]))
    check("Q8 already-deleted is idempotent success (flag clears)",
          ok is True and int(row["channel_cleanup_pending"]) == 0)

    # Q9 — transient delete failure DURING the post-delivery cleanup:
    # the flag STAYS set and the sweeper retries (the delivered record
    # is untouched). The failure is injected BEFORE the delivery so the
    # INLINE cleanup hits it (fresh world: the first Stage-A message is
    # 110 — the bot-38.log production shape).
    fdb6, bot6, eng6, NID6 = _make_world(5)
    key = (CHANNEL, 110)
    fdb6.delete_fail[key] = "failed:transient"
    mids6, sent6 = await eng6.deliver_album(
        network_bot=bot6, chat_id=bot6.user_chat, file_rows=frows(1),
        protect_content=False, payload_code="q9", payload_id=None,
        user_id=8922807758, network_bot_id=NID6)
    rows = await db.list_delivery_jobs(limit=500)
    q9job = [r for r in rows if r.get("payload_code") == "q9"
             and r.get("status") == "DELIVERED"][0]
    check("Q9 transient delete failure keeps the flag + the record",
          sent6 == 1
          and int(q9job["channel_cleanup_pending"]) == 1
          and key in fdb6.channel_msgs)
    # the sweeper retries and succeeds once the failure clears
    del fdb6.delete_fail[key]
    stats = await eng6.sweep_once()
    row = await db.get_delivery_job(int(q9job["id"]))
    check("Q9b the sweeper retries the delete and clears the flag",
          int(row["channel_cleanup_pending"]) == 0
          and key not in fdb6.channel_msgs
          and str(row["status"]) == "DELIVERED")

    # Q9c — RetryAfter flood limit: ONE bounded in-line retry
    # (DELIVERY_CHANNEL_DELETE_RETRY) then success — the flood limit
    # never strands a confirmed cleanup on the sweeper.
    fdbR, botR, engR, _NIDR = _make_world(4)
    await engR.deliver_album(
        network_bot=botR, chat_id=botR.user_chat, file_rows=frows(1),
        protect_content=False, payload_code="q9c", payload_id=None,
        user_id=8922807758, network_bot_id=_nids[4])
    rows = await db.list_delivery_jobs(limit=500)
    q9cjob = [r for r in rows if r.get("payload_code") == "q9c"
              and r.get("status") == "DELIVERED"][0]
    # put the source back (the inline cleanup already consumed it) + a
    # one-shot RetryAfter injection
    fdbR.channel_msgs[(CHANNEL, 110)] = {"src": "recreated"}
    fdbR.retry_once = {(CHANNEL, 110)}
    okR = await engR._cleanup_channel_source(
        int(q9cjob["id"]), CHANNEL, 110, nid=_nids[4],
        via="q9c_retry_after")
    check("Q9c RetryAfter → one bounded in-line retry → success",
          okR is True and (CHANNEL, 110) not in fdbR.channel_msgs
          and fdbR.delete_calls.count((CHANNEL, 110)) == 3)
    # (3 = the inline post-delivery delete + the retry_after first
    # attempt + the bounded in-line retry)

    # Q10 — crash/restart reconciliation: a DELIVERED row whose flag is
    # still set (crash between delivery and deletion) is recovered.
    fdb7, bot7, eng7, NID7 = _make_world(6)
    await eng7.deliver_album(
        network_bot=bot7, chat_id=bot7.user_chat, file_rows=frows(2),
        protect_content=False, payload_code="q10", payload_id=None,
        user_id=8922807758, network_bot_id=NID7)
    rows = await db.list_delivery_jobs(limit=500)
    q10jobs = [r for r in rows if r.get("payload_code") == "q10"
               and r.get("status") == "DELIVERED"]
    # simulate the crash: messages still present + flags still set
    for r in q10jobs:
        await db.update_delivery_job(int(r["id"]), channel_cleanup_pending=1)
        fdb7.channel_msgs[(CHANNEL, int(r["delivery_message_id"]))] = {
            "src": "recreated"}
    await eng7.reconcile_startup()
    row_states = []
    for r in q10jobs:
        row = await db.get_delivery_job(int(r["id"]))
        row_states.append(int(row["channel_cleanup_pending"]))
    check("Q10 crash/restart reconciliation deletes + clears",
          all(v == 0 for v in row_states)
          and not [k for k in fdb7.channel_msgs if k[0] == CHANNEL])

    # Q11 — the USER delivery TTL cleanup stays INDEPENDENT: user rows
    # still settle by TTL/EXPIRED semantics; the channel pass never
    # touches user-facing settling (a delivered+confirmed row keeps
    # DELIVERED + its user_message_id through a channel-cleanup sweep).
    rows = await db.list_delivery_jobs(limit=500)
    q11job = [r for r in rows if r.get("payload_code") == "q8"
              and r.get("status") == "DELIVERED"][0]
    stats11 = await eng5.sweep_once()
    row11 = await db.get_delivery_job(int(q11job["id"]))
    check("Q11 user TTL cleanup independent (confirmed row intact)",
          str(row11["status"]) == "DELIVERED"
          and row11.get("user_message_id") is not None)

    # Q12 — schema/marker regression pins.
    cols = await db.conn.execute_fetchall("PRAGMA table_info(delivery_jobs)")
    names = {r[1] for r in cols}
    check("Q12 delivery_jobs v45 channel_cleanup_pending present",
          "channel_cleanup_pending" in names)
    check("Q12b v42/v44 columns intact (no regression)",
          {"delivery_channel_id", "delivery_message_id",
           "mode_a_failure", "handoff_token"}.issubset(names))

    # Q13 — wrong-identity safety: the cleanup deletes ONLY the exact
    # (delivery_channel_id, delivery_message_id) it is owed. Unrelated
    # LIVE messages in the SAME Delivery Channel survive, and no delete
    # call ever targets the Storage Channel master store.
    fdbX, botX, engX, _NIDX = _make_world(0)
    fdbX.channel_msgs[(CHANNEL, 555)] = {"src": "unrelated_a"}
    fdbX.channel_msgs[(CHANNEL, 556)] = {"src": "unrelated_b"}
    midsX, sentX = await engX.deliver_album(
        network_bot=botX, chat_id=botX.user_chat, file_rows=frows(1),
        protect_content=False, payload_code="q13", payload_id=None,
        user_id=8922807758, network_bot_id=_nids[0])
    check("Q13 the cleanup deletes ONLY its exact source",
          sentX == 1
          and (CHANNEL, 110) not in fdbX.channel_msgs
          and (CHANNEL, 555) in fdbX.channel_msgs
          and (CHANNEL, 556) in fdbX.channel_msgs
          and fdbX.storage_msgs == {(STORAGE, 801): "master-801"})
    check("Q13b no delete call ever targets the Storage Channel",
          bool(fdbX.delete_calls)
          and all(c[0] == CHANNEL for c in fdbX.delete_calls)
          and {c[1] for c in fdbX.delete_calls} == {110})

    # Q14 — the V25/V42 SINGLE-FILE two-stage path is UNCHANGED (V26
    # Phase 3 only ADDED the source cleanup on the confirmed delivery):
    # deliver() settles DELIVERED with the durable two-stage identity
    # (delivery_channel_id + delivery_message_id + user_message_id) and
    # its Delivery Channel source is cleaned after the confirmation.
    fdbY, botY, engY, _NIDY = _make_world(6)
    midY = await engY.deliver(
        network_bot=botY, chat_id=botY.user_chat,
        file_row={"id": 8100, "channel_id": STORAGE, "message_id": 801,
                  "media_type": "video", "file_name": "single.mp4",
                  "file_size": 2048, "file_unique_id": "QUIDY"},
        protect_content=False, payload_code="q14", payload_id=None,
        user_id=8922807758, network_bot_id=_nids[6])
    rows = await db.list_delivery_jobs(limit=500)
    q14job = [r for r in rows if r.get("payload_code") == "q14"][0]
    check("Q14 V25 single-file path delivers + records the identity",
          midY is not None
          and str(q14job["status"]) == "DELIVERED"
          and int(q14job["delivery_channel_id"]) == CHANNEL
          and int(q14job["delivery_message_id"]) == 110
          and q14job.get("user_message_id") is not None)
    check("Q14b the single-file source cleanup fired (V26 on V25 path)",
          (CHANNEL, 110) not in fdbY.channel_msgs
          and fdbY.storage_msgs == {(STORAGE, 801): "master-801"})

    # Q15 — the exact bot-38.log production shape, pinned through the
    # log evidence chain: a 6-file album over the production Delivery
    # Channel id -1004476310327 with messages 110-115 must produce
    # NETWORK_BOT_ALBUM_COPY_SUCCESS → DELIVERY_CHANNEL_DELETE_START →
    # DELIVERY_CHANNEL_DELETE_SUCCESS for every confirmed source. (The
    # production ids are used ONLY as test fixtures — never in runtime
    # logic.)
    class _Cap(logging.Handler):
        def __init__(self):
            super().__init__(level=logging.INFO)
            self.lines = []

        def emit(self, record):
            self.lines.append(record.getMessage())

    _pl = logging.getLogger("payload-bot")
    _pl_lvl = _pl.level
    _pl.setLevel(logging.INFO)
    _cap = _Cap()
    _pl.addHandler(_cap)
    try:
        fdbZ, botZ, engZ, _NIDZ = _make_world(2)
        midsZ, sentZ = await engZ.deliver_album(
            network_bot=botZ, chat_id=botZ.user_chat, file_rows=frows(6),
            protect_content=False, payload_code="q15", payload_id=None,
            user_id=8922807758, network_bot_id=_nids[2])
    finally:
        _pl.removeHandler(_cap)
        _pl.setLevel(_pl_lvl)
    prod_chan = "delivery_channel_id=-1004476310327"
    start_mids = set()
    succ_mids = set()
    for ln in _cap.lines:
        if not isinstance(ln, str):
            continue
        for m in range(110, 116):
            tag = f"delivery_message_id={m} "
            if ln.startswith("DELIVERY_CHANNEL_DELETE_START") \
                    and prod_chan in ln and tag in ln:
                start_mids.add(m)
            if ln.startswith("DELIVERY_CHANNEL_DELETE_SUCCESS") \
                    and prod_chan in ln and tag in ln:
                succ_mids.add(m)
    copy_ok = any(ln.startswith("NETWORK_BOT_ALBUM_COPY_SUCCESS")
                  and prod_chan in ln and "files=6" in ln
                  for ln in _cap.lines if isinstance(ln, str))
    check("Q15 bot-38 shape: COPY_SUCCESS → DELETE_START → "
          "DELETE_SUCCESS for the exact channel + messages 110-115",
          sentZ == 6 and copy_ok
          and start_mids == set(range(110, 116))
          and succ_mids == set(range(110, 116)))


# ===========================================================================
async def section_r(ns, db):
    """[R] V26 Phase 7 — Recent Videos: the count-based rule.

    PRIMARY RECENT shows the MAXIMUM 10 newest published listings; a
    NEWER arrival pushes the previous oldest out of the primary ten and
    into the horizontal OLDER HISTORY shelf; NO database row is ever
    deleted; the partition is deterministic (reload persistence) and
    age-restricted listings stay gated in BOTH shelves.
    """
    print("\n[R] V26 Phase 7 — Recent Videos (primary ≤ 10 + older history)")
    from datetime import timedelta as _td
    now = datetime.now(timezone.utc)
    CH = -1004460709040

    await db.conn.execute(
        "INSERT OR IGNORE INTO storage_channels(channel_id, title, "
        "is_active) VALUES (?, 'StorageChanR', 1)", (CH,))

    async def _mk_listing(slug, mins_offset, cat="movies"):
        """One file -> one payload -> one PUBLISHED listing whose
        created_at is mins_offset minutes in the FUTURE relative to the
        test clock (guarantees the R set owns the newest positions
        regardless of earlier sections' rows)."""
        mid = 9000 + mins_offset
        stamp = (now + _td(minutes=mins_offset)).isoformat()
        await db.conn.execute(
            "INSERT INTO indexed_files(channel_id, message_id, file_id, "
            "file_unique_id, media_type, file_name, file_size, upload_date) "
            "VALUES (?, ?, ?, ?, 'video', ?, 1000, ?)",
            (CH, mid, f"RFID{mid}", f"RFUID{mid}", f"{slug}.mp4", stamp))
        cur = await db.conn.execute(
            "SELECT id FROM indexed_files WHERE channel_id=? AND "
            "message_id=?", (CH, mid))
        idx = int((await cur.fetchone())[0])
        await db.conn.execute(
            "INSERT INTO payloads(payload, index_id, status, "
            "access_policy, display_name, created_at, updated_at) VALUES "
            "(?,?,'active','OPEN',?,?,?)",
            (slug, idx, slug, stamp, stamp))
        cur = await db.conn.execute(
            "SELECT id FROM payloads WHERE payload=?", (slug,))
        pid = int((await cur.fetchone())[0])
        opaque = f"rv26{mins_offset:03d}"
        await db.conn.execute(
            "INSERT INTO website_payloads(opaque_id, payload_id, title, "
            "description, tags, position, published, created_at, "
            "updated_at) VALUES (?,?,?,?,?,0,1,?,?)",
            (opaque, pid, f"R{mins_offset}", "phase7", "rv", stamp, stamp))
        cur = await db.conn.execute(
            "SELECT id FROM website_payloads WHERE opaque_id=?", (opaque,))
        lid = int((await cur.fetchone())[0])
        cur = await db.conn.execute(
            "SELECT id FROM website_categories WHERE slug=?", (cat,))
        cid = int((await cur.fetchone())[0])
        await db.conn.execute(
            "INSERT OR IGNORE INTO website_payload_categories(listing_id, "
            "category_id, position, created_at) VALUES (?,?,0,?)",
            (lid, cid, stamp))
        await db.conn.commit()
        return lid

    # 20 staggered listings (offsets 1..20; LARGER offset = NEWER).
    lids = {}
    for off in range(1, 21):
        lids[off] = await _mk_listing(f"rv_{off}", off)

    primary = await db.recently_added_website_listings(10)
    older = await db.older_history_website_listings(10, 24)
    p_ids = [int(r["wdbid"]) for r in primary]
    o_ids = [int(r["wdbid"]) for r in older]
    exp_primary = {lids[o] for o in range(11, 21)}
    check("R1 primary shows EXACTLY the newest 10 (count-based cap)",
          len(p_ids) == 10 and set(p_ids) == exp_primary)
    check("R2 primary is newest-first ordered",
          p_ids == [lids[o] for o in range(20, 10, -1)])
    check("R3 the pushed-out (beyond the newest ten) land in OLDER "
          "HISTORY",
          lids[1] in o_ids and lids[2] in o_ids
          and exp_primary.isdisjoint(o_ids))
    check("R4 no duplicates across the two shelves",
          set(p_ids).isdisjoint(o_ids))
    cur = await db.conn.execute(
        "SELECT COUNT(*) FROM website_payloads WHERE published=1")
    total_before = int((await cur.fetchone())[0])
    check("R5 historical rows are never deleted (all 20 R rows present)",
          total_before >= 20)

    # R6 — a NEWER (21st) arrival pushes the previous oldest out.
    lids[21] = await _mk_listing("rv_21", 21)
    primary2 = await db.recently_added_website_listings(10)
    older2 = await db.older_history_website_listings(10, 24)
    p2 = [int(r["wdbid"]) for r in primary2]
    o2 = {int(r["wdbid"]) for r in older2}
    check("R6 a newer arrival pushes the oldest out of the primary ten",
          set(p2) == {lids[o] for o in range(12, 22)}
          and lids[11] in o2 and lids[11] not in set(p2))
    cur = await db.conn.execute(
        "SELECT COUNT(*) FROM website_payloads WHERE published=1")
    check("R7 the push-out deletes NOTHING (row count only grew)",
          int((await cur.fetchone())[0]) == total_before + 1)

    # R8 — reload persistence: the partition is deterministic.
    primary3 = await db.recently_added_website_listings(10)
    older3 = await db.older_history_website_listings(10, 24)
    check("R8 reload: the same partition renders again (deterministic)",
          [int(r["wdbid"]) for r in primary3] == p2
          and {int(r["wdbid"]) for r in older3} == o2)

    # R9 — 20+ case: the paginated Library feed covers EVERYTHING.
    paged, ptotal = await db.list_website_payloads_paged(
        1, 60, order="newest")
    all_ids = {int(r["wdbid"]) for r in paged}
    check("R9 20+ case: primary ∪ library == every published listing",
          ptotal >= 20
          and all_ids.issuperset(set(p2))
          and all_ids.issuperset(o2))

    # R10 — the age-restriction guard applies to BOTH shelves.
    adult_lid = await _mk_listing("rv_adult", 99, cat="adult")
    primary_a = await db.recently_added_website_listings(
        10, include_age_restricted=False)
    older_a = await db.older_history_website_listings(
        10, 24, include_age_restricted=False)
    pa = {int(r["wdbid"]) for r in primary_a}
    oa = {int(r["wdbid"]) for r in older_a}
    check("R10 an 18+ listing never appears without age_ok",
          adult_lid not in pa and adult_lid not in oa)
    primary_ok = await db.recently_added_website_listings(
        10, include_age_restricted=True)
    check("R10b with age_ok the 18+ listing joins the newest ten",
          int(primary_ok[0]["wdbid"]) == adult_lid)

    # R11 — the production home-shelf wiring: primary limit 10 + the
    # older-history exclusion call (the count-based rule is what the
    # website actually renders).
    import inspect as _insp
    from app.web.site import pages as _pg
    src = _insp.getsource(_pg._ux_home_shelves)
    check("R11 the home renders primary(10) + older_history shelves",
          "recently_added_website_listings(" in src
          and "10, include_age_restricted=age_ok" in src
          and "older_history_website_listings(" in src
          and "10, 24," in src)

    # R12 — the 0 / 1 / 10 cases on a FRESH scratch catalog.
    _scratch = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "_v26_r_scratch.db")
    for _suffix in ("", "-shm", "-wal"):
        if os.path.exists(_scratch + _suffix):
            os.remove(_scratch + _suffix)
    from app.storage.schema import Database as _RDB
    sdb = _RDB(_scratch)
    await sdb.connect()
    await sdb.init_schema()
    try:
        p0 = await sdb.recently_added_website_listings(10)
        o0 = await sdb.older_history_website_listings(10, 24)
        check("R12a 0 listings: both shelves empty", not p0 and not o0)
        # one listing -> primary shows it, older history empty
        now_s = datetime.now(timezone.utc).isoformat()
        await sdb.conn.execute(
            "INSERT INTO collections(collection_id, channel_id, "
            "file_count, created_at) VALUES ('rcoll1', -1, 1, ?)",
            (now_s,))
        await sdb.conn.execute(
            "INSERT INTO website_payloads(opaque_id, collection_id, "
            "title, position, published, created_at, updated_at) VALUES "
            "('rscratch1', 'rcoll1', 'Solo', 0, 1, ?, ?)",
            (now_s, now_s))
        await sdb.conn.commit()
        p1 = await sdb.recently_added_website_listings(10)
        o1 = await sdb.older_history_website_listings(10, 24)
        check("R12b 1 listing: primary shows it, older history empty",
              len(p1) == 1 and not o1)
        # 10 listings -> all ten in primary, older history still empty
        for i in range(2, 11):
            st = (datetime.now(timezone.utc)
                  - _td(minutes=100 - i)).isoformat()
            await sdb.conn.execute(
                "INSERT INTO collections(collection_id, channel_id, "
                "file_count, created_at) VALUES (?, -1, 1, ?)",
                (f"rcoll{i}", st))
            await sdb.conn.execute(
                "INSERT INTO website_payloads(opaque_id, collection_id, "
                "title, position, published, created_at, updated_at) "
                "VALUES (?, ?, ?, 0, 1, ?, ?)",
                (f"rscratch{i}", f"rcoll{i}", f"S{i}", st, st))
        await sdb.conn.commit()
        p10 = await sdb.recently_added_website_listings(10)
        o10 = await sdb.older_history_website_listings(10, 24)
        check("R12c exactly 10: ALL in primary, older history empty",
              len(p10) == 10 and not o10)
        # the 11th -> the oldest leaves primary for older history
        st11 = datetime.now(timezone.utc).isoformat()
        await sdb.conn.execute(
            "INSERT INTO collections(collection_id, channel_id, "
            "file_count, created_at) VALUES ('rcoll11', -1, 1, ?)",
            (st11,))
        await sdb.conn.execute(
            "INSERT INTO website_payloads(opaque_id, collection_id, "
            "title, position, published, created_at, updated_at) VALUES "
            "('rscratch11', 'rcoll11', 'S11', 0, 1, ?, ?)",
            (st11, st11))
        await sdb.conn.commit()
        p11 = await sdb.recently_added_website_listings(10)
        o11 = await sdb.older_history_website_listings(10, 24)
        check("R12d the 11th pushes the oldest into older history",
              len(p11) == 10 and len(o11) == 1
              and int(o11[0]["wdbid"]) == int(p10[-1]["wdbid"])
              and {int(r["wdbid"]) for r in p11}.isdisjoint(
                  {int(r["wdbid"]) for r in o11}))
    finally:
        await sdb.close()
        for _suffix in ("", "-shm", "-wal"):
            if os.path.exists(_scratch + _suffix):
                os.remove(_scratch + _suffix)


# ===========================================================================
async def section_s(ns, db):
    """[S] V26 Phase 8 — Storage reindex updates the MUTABLE metadata.

    Production bug: filename X → the Telegram message was edited to
    rename the file to Y → reindex → the system still showed X. The
    reindex treated the exact-identity duplicate as a blind skip. This
    section drives the REAL _index_one_message duplicate path with a
    REAL telegram.Message carrying the edited document and pins: the
    canonical row now shows Y (then Z), the immutable identity is
    preserved, a DIFFERENT message with the same file never refreshes
    the canonical row, and the telemetry fires.
    """
    print("\n[S] V26 Phase 8 — reindex filename refresh (X → Y → reindex → Y)")
    from telegram import Message as _TGMsg, Chat as _TGChat, \
        Document as _TGDoc

    CH = -1004460709050
    ADMIN = 8370454312
    await db.conn.execute(
        "INSERT OR IGNORE INTO storage_channels(channel_id, title, "
        "is_active) VALUES (?, 'StorageChanS', 1)", (CH,))
    now = datetime.now(timezone.utc)
    await db.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date) "
        "VALUES (?, 501, 'SFID1', 'SFUID1', 'document', "
        "'original_x.mp4', 1000, ?)", (CH, now.isoformat()))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM indexed_files WHERE channel_id=? AND message_id=?",
        (CH, 501))
    pk = int((await cur.fetchone())[0])

    class FakeScanBot:
        """Stands in for the PTB client: copy_message returns a REAL
        telegram.Message carrying the (possibly edited) document."""

        def __init__(self, doc):
            self._doc = doc

        async def copy_message(self, chat_id, from_chat_id, message_id,
                               **kw):
            return _TGMsg(
                message_id=777, date=datetime.now(timezone.utc),
                chat=_TGChat(id=ADMIN, type="private"),
                document=self._doc)

        async def delete_message(self, chat_id, message_id, **kw):
            return True

    class _SCap(logging.Handler):
        def __init__(self):
            super().__init__(level=logging.INFO)
            self.lines = []

        def emit(self, record):
            self.lines.append(record.getMessage())

    _pl = logging.getLogger("payload-bot")
    _pl_lvl = _pl.level
    _pl.setLevel(logging.INFO)
    _cap = _SCap()
    _pl.addHandler(_cap)

    async def _reindex(doc, msg_id):
        bot = FakeScanBot(doc)
        outcome, _info = await ns._index_one_message(bot, ADMIN, CH, msg_id)
        return outcome

    try:
        # S1 — the production scenario: X → edited to Y → reindex → Y.
        doc_y = _TGDoc(file_id="SFID1", file_unique_id="SFUID1",
                       file_name="renamed_y.mp4", file_size=1000,
                       mime_type="video/mp4")
        outcome = await _reindex(doc_y, 501)
        row = await db.get_indexed_file_by_id(pk)
        check("S1 X → edited to Y → reindex → the row shows Y",
              outcome == "duplicate"
              and str(row["file_name"]) == "renamed_y.mp4")
        check("S1b the IMMUTABLE identity is preserved",
              int(row["id"]) == pk
              and str(row["file_unique_id"]) == "SFUID1"
              and int(row["channel_id"]) == CH
              and int(row["message_id"]) == 501
              and str(row["file_id"]) == "SFID1")

        # S2 — the telemetry: METADATA_CHANGED with old + new filename.
        changed = [ln for ln in _cap.lines
                   if ln.startswith("INDEX_REINDEX_METADATA_CHANGED")]
        check("S2 INDEX_REINDEX_METADATA_CHANGED carries old → new",
              bool(changed)
              and "old_filename='original_x.mp4'" in changed[-1]
              and "new_filename='renamed_y.mp4'" in changed[-1]
              and f"file_pk={pk}" in changed[-1])

        # S3 — idempotent second pass: nothing changes, UNCHANGED fires.
        _cap.lines.clear()
        await _reindex(doc_y, 501)
        row = await db.get_indexed_file_by_id(pk)
        unchanged = [ln for ln in _cap.lines
                     if ln.startswith("INDEX_REINDEX_METADATA_UNCHANGED")]
        check("S3 the second pass is a no-op (UNCHANGED, Y kept)",
              str(row["file_name"]) == "renamed_y.mp4"
              and bool(unchanged)
              and not [ln for ln in _cap.lines
                       if ln.startswith("INDEX_REINDEX_METADATA_CHANGED")])

        # S4 — X → Y → Z: a SECOND edit refreshes again.
        _cap.lines.clear()
        doc_z = _TGDoc(file_id="SFID1", file_unique_id="SFUID1",
                       file_name="final_z.mp4", file_size=1000,
                       mime_type="video/mp4")
        await _reindex(doc_z, 501)
        row = await db.get_indexed_file_by_id(pk)
        check("S4 X → Y → Z: a second edit refreshes to Z",
              str(row["file_name"]) == "final_z.mp4"
              and any(ln.startswith("INDEX_REINDEX_METADATA_CHANGED")
                      and "new_filename='final_z.mp4'" in ln
                      for ln in _cap.lines))

        # S5 — a DIFFERENT message with the same file identity does NOT
        # refresh the canonical row (its OWN source is the authority).
        _cap.lines.clear()
        doc_other = _TGDoc(file_id="SFID1", file_unique_id="SFUID1",
                           file_name="elsewhere.mp4", file_size=1000,
                           mime_type="video/mp4")
        outcome5 = await _reindex(doc_other, 502)
        row = await db.get_indexed_file_by_id(pk)
        check("S5 a same-file DIFFERENT message never refreshes the row",
              outcome5 == "duplicate"
              and str(row["file_name"]) == "final_z.mp4"
              and int(row["message_id"]) == 501)

        # S6 — unrelated rows are never touched.
        await db.conn.execute(
            "INSERT INTO indexed_files(channel_id, message_id, file_id, "
            "file_unique_id, media_type, file_name, file_size, upload_date) "
            "VALUES (?, 601, 'SFID2', 'SFUID2', 'document', "
            "'bystander.mp4', 500, ?)", (CH, now.isoformat()))
        await db.conn.commit()
        cur = await db.conn.execute(
            "SELECT id FROM indexed_files WHERE file_unique_id='SFUID2'")
        pk2 = int((await cur.fetchone())[0])
        row2 = await db.get_indexed_file_by_id(pk2)
        check("S6 an unrelated row is never touched",
              str(row2["file_name"]) == "bystander.mp4")

        # S7 — the repo primitive: a partial fetch NEVER erases metadata.
        await db.refresh_indexed_file_mutable_metadata(
            pk2, {"file_name": None, "caption": "a caption"})
        row2 = await db.get_indexed_file_by_id(pk2)
        check("S7 a partial fetch never erases known metadata",
              str(row2["file_name"]) == "bystander.mp4"
              and str(row2["caption"] or "") == "a caption")

        # S8 — the batch insert (INSERT OR IGNORE) never MUTATES an
        # existing row (the new-row path stays insert-only).
        before = await db.get_indexed_file_by_id(pk)
        await db.add_indexed_files_batch([
            (CH, 501, {"file_id": "SFID1", "file_unique_id": "SFUID1",
                       "media_type": "document",
                       "file_name": "batch_collision.mp4",
                       "file_size": 1000,
                       "upload_date": now.isoformat()})])
        after = await db.get_indexed_file_by_id(pk)
        check("S8 the batch insert never mutates the existing row",
              dict(before) == dict(after))
    finally:
        _pl.removeHandler(_cap)
        _pl.setLevel(_pl_lvl)

    # S9 — the five required telemetry events exist on the reindex path
    # (START/MESSAGE/COMPLETE at the scan lifecycle; CHANGED/UNCHANGED
    # verified behaviorally above).
    import inspect as _insp2
    from app.presentation.telegram import indexing as _idx_mod
    _src = _insp2.getsource(_idx_mod)
    check("S9 all five INDEX_REINDEX_* telemetry events exist",
          all(ev in _src for ev in (
              "INDEX_REINDEX_START", "INDEX_REINDEX_MESSAGE",
              "INDEX_REINDEX_METADATA_CHANGED",
              "INDEX_REINDEX_METADATA_UNCHANGED",
              "INDEX_REINDEX_COMPLETE")))


# ===========================================================================
async def section_t(ns, db):
    """[T] V26 Phase 6 — every admin setting is AUTHENTIC (wired
    end-to-end): the four formerly decorative controls now have real
    runtime effects, and the pre-roll wire carries no skip parameters."""
    print("\n[T] V26 Phase 6 — authentic admin settings wiring")
    from app.web.site import html as _html
    from app.web.site import stream as _stream
    from app.web.site import video_ads as _va

    # T1 — analytics_enabled: OFF stops the access-event collection.
    await db.set_setting("analytics_enabled", "0")
    before = await db.access_event_count("t_analytics_probe")
    await db.log_access_event("t_analytics_probe", user_id=8922807758)
    after = await db.access_event_count("t_analytics_probe")
    check("T1 analytics OFF stops the event collection",
          before == after == 0)
    await db.set_setting("analytics_enabled", "1")
    await db.log_access_event("t_analytics_probe", user_id=8922807758)
    after_on = await db.access_event_count("t_analytics_probe")
    check("T1b analytics ON collects again", after_on == 1)

    # T2 — prot_v3_one_time_default writes/reads the REAL runtime key.
    # (The presentation-section functions resolve their globals through
    # the assembled runtime namespace — ns — NOT the raw module.)
    await ns._prot_v3_set("one_time_default", True)
    check("T2 the advanced one-time toggle writes the REAL key",
          await db.get_setting_bool("one_time_links_default", False)
          is True
          and await ns._prot_v3_get("one_time_default") is True
          and await ns.one_time_default() == 1)
    await ns._prot_v3_set("one_time_default", False)
    check("T2b off again (the same real key)",
          await db.get_setting_bool("one_time_links_default", False)
          is False)

    # T3 — prot_v3_anti_leech: the hotlink predicate + the setting read.
    class _FakeReq:
        def __init__(self, referer="", origin="", host="mysite.example"):
            self.headers = {"Referer": referer, "Origin": origin}
            self.host = host

    check("T3 anti-leech predicate: same-host referer passes",
          _stream._referer_allowed(
              _FakeReq(referer="https://mysite.example/site/payload/x"))
          is True)
    check("T3b no referer (a player fetch) passes",
          _stream._referer_allowed(_FakeReq()) is True)
    check("T3c a FOREIGN referer (hotlink) is blocked",
          _stream._referer_allowed(
              _FakeReq(referer="https://evil.example/embed.html")) is False)
    check("T3d a foreign Origin is blocked too",
          _stream._referer_allowed(
              _FakeReq(origin="https://evil.example")) is False)
    await db.set_setting("prot_v3_anti_leech", "1")
    check("T3e the toggle reads the real setting (ON)",
          await _stream._anti_leech_active(
              __import__("types").SimpleNamespace(db=db)) is True)
    await db.set_setting("prot_v3_anti_leech", "0")
    check("T3f the toggle reads the real setting (OFF)",
          await _stream._anti_leech_active(
              __import__("types").SimpleNamespace(db=db)) is False)

    # T4 — prot_v3_watermark: the player renders the overlay when ON.
    detail = {"eff_title": "T", "title": "T",
              "listing": {"opaque_id": "x"}, "files": [],
              "canonical": {}}
    out = _html.video_page(detail, 0, "/site/payload/x/video/y",
                           watermark_text="MARKED")
    out2 = _html.video_page(detail, 0, "/site/payload/x/video/y",
                            watermark_text="")
    check("T4 the watermark overlay renders when ON",
          'class="pwm"' in out and "MARKED" in out
          and 'aria-hidden="true"' in out)
    check("T4b NO overlay when OFF", 'class="pwm"' not in out2)
    await db.set_setting("prot_v3_watermark", "1")
    await db.set_setting("prot_v3_watermark_text", "SiteMark")
    check("T4c the player handler reads the real settings",
          await db.get_setting_bool("prot_v3_watermark", False) is True
          and str(await db.get_setting("prot_v3_watermark_text")
                  or "") == "SiteMark")

    # T5 — the pre-roll wire carries NO skip parameters (Phase 5).
    wire = _va.player_wire_subset({
        "provider": "direct", "mode": "skippable", "duration": 12,
        "source_url": "https://ad.example/x.mp4", "vast_url": "",
        "fallback": "release", "frequency": "every_video", "timeout": 8,
        "skip_delay": 5})
    check("T5 the pre-roll wire has NO mode/skip_delay",
          "skip_delay" not in wire and "mode" not in wire
          and wire.get("provider") == "direct"
          and wire.get("duration") == 12)


# ===========================================================================
async def section_u(ns, db):
    """[U] V26 FINAL (bot-39, Part 2) — the PROXY-AWARE anti-leech."""
    print("\n[U] V26 FINAL — proxy-aware Anti-Leech (effective public host)")
    import types as _types
    from app.web.site import stream as _stream

    WORKER = "shy-leaf-cac1.kyahuyaphirse.workers.dev"

    class _Req:
        def __init__(self, referer="", origin="", host="127.0.0.1:25672"):
            self.headers = {"Referer": referer, "Origin": origin}
            self.host = host

    deps = _types.SimpleNamespace(db=db)

    # Baseline: no configured public hosts — the worker referer is a
    # hotlink (the OLD broken behavior for direct deployments).
    await db.set_setting("website_public_base_url", "")
    await db.set_setting("website_trusted_public_hosts", "")
    d0 = await _stream._anti_leech_decision(
        _Req(referer=f"https://{WORKER}/site/payload/x"), deps)
    check("U0 (baseline) worker referer BLOCKED without configuration",
          d0.get("allowed") is False
          and d0.get("reason") == "foreign_referer")

    # U1 — configured website_public_base_url: the WORKER referer on an
    # INTERNAL request.host is ALLOWED (bot-39's exact production shape).
    await db.set_setting("website_public_base_url",
                         f"https://{WORKER}/site")
    d1 = await _stream._anti_leech_decision(
        _Req(referer=f"https://{WORKER}/site/payload/x"), deps)
    check("U1 Worker public host + internal backend host => ALLOW",
          d1.get("allowed") is True and d1.get("reason") == "same_site"
          and d1.get("effective_public_host") == WORKER
          and d1.get("request_host") == "127.0.0.1")

    # U1b — the port-bearing referer variant (the browser keeps the
    # external port; proxies forward Host without it).
    d1b = await _stream._anti_leech_decision(
        _Req(referer=f"https://{WORKER}:443/site/payload/x",
             host="127.0.0.1"), deps)
    check("U1b port-insensitive hostname match => ALLOW",
          d1b.get("allowed") is True)

    # U2 — explicitly configured/trusted public proxy host => ALLOW.
    await db.set_setting("website_public_base_url", "")
    await db.set_setting("website_trusted_public_hosts",
                         f"{WORKER}, cdn.example.org")
    d2 = await _stream._anti_leech_decision(
        _Req(referer=f"https://{WORKER}/site/hls/t/master.m3u8"), deps)
    check("U2 configured trusted public host => ALLOW",
          d2.get("allowed") is True)

    # U3 — direct request.host => the existing valid behavior.
    d3 = await _stream._anti_leech_decision(
        _Req(referer="https://direct.example/site/payload/x",
             host="direct.example"), deps)
    check("U3 direct request.host match => ALLOW (existing behavior)",
          d3.get("allowed") is True)

    # U4 — a foreign Referer is still BLOCKED with the public hosts set.
    await db.set_setting("website_public_base_url", f"https://{WORKER}/site")
    d4 = await _stream._anti_leech_decision(
        _Req(referer="https://evil.example/embed.html"), deps)
    check("U4 foreign Referer => BLOCK",
          d4.get("allowed") is False
          and d4.get("referer_host") == "evil.example")

    # U5 — a foreign Origin is still BLOCKED.
    d5 = await _stream._anti_leech_decision(
        _Req(origin="https://evil.example"), deps)
    check("U5 foreign Origin => BLOCK",
          d5.get("allowed") is False
          and d5.get("reason") == "foreign_origin")

    # U6/U7 — the SAME decision object gates media/hls/thumb (one shared
    # predicate; the handlers were rewritten onto _anti_leech_decision).
    src = open("app/web/site/stream.py").read()
    hlssrc = open("app/web/site/hls.py").read()
    check("U6 the HLS surface uses the shared proxy-aware decision",
          "_anti_leech_decision" in hlssrc
          and '_log_anti_leech("hls"' in hlssrc)
    check("U7 the media + thumb surfaces use the shared decision",
          src.count("_anti_leech_decision(request, deps)") == 2
          and '_log_anti_leech("media"' in src
          and '_log_anti_leech("thumb"' in src)

    # U7b — the no-referer player fetch still passes.
    d7b = await _stream._anti_leech_decision(_Req(), deps)
    check("U7b no referer (player fetch) => ALLOW",
          d7b.get("allowed") is True and d7b.get("reason") == "no_referer")

    # U8 — client-forged X-Forwarded-Host is NEVER an allowlist source.
    hosts = await _stream._effective_public_hosts(deps)
    check("U8 forged X-Forwarded-Host is never trusted",
          "evil.example" not in hosts
          and "forged.example" not in hosts
          and WORKER in hosts)

    # U9 — the ALLOWED/BLOCKED telemetry lines exist with the safe
    # diagnostic fields (never tokens).
    check("U9 anti-leech telemetry lines exist with safe fields",
          "WEBSITE_ANTI_LEECH_%s surface=%s effective_public_host=%s"
          in src
          and "referer_host=%s" in src and "origin_host=%s" in src
          and "request_host=%s" in src and "reason=%s" in src)
    # cleanup
    await db.set_setting("website_public_base_url", "")
    await db.set_setting("website_trusted_public_hosts", "")


# ===========================================================================
async def section_v(ns, db):
    """[V] V26 FINAL (bot-39, Part 3) — unknown-probe VIDEO => HLS plan."""
    print("\n[V] V26 FINAL — unknown-probe video gets the HLS playback plan")
    import types as _types
    import json as _json
    from app.web.site import pages as _pages
    from app.web.site import stream as _stream
    from app.web.site.stream import make_listing_resolver
    from app.web.site.tokens import make_video_token_codec
    from app.media.streamtokens import make_stream_token_codec

    MAIN_TOKEN = "123456:V26_FINAL_ISSUE_TEST"
    now = datetime.now(timezone.utc).isoformat()
    CH = -1004460709070  # a FRESH channel (no other section owns it)

    async def _mk_file(mid, name, mtype, size):
        await db.conn.execute(
            "INSERT INTO indexed_files(channel_id, message_id, file_id, "
            "file_unique_id, media_type, file_name, file_size, upload_date) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (CH, mid, f"FIDV{mid}", f"FUIDV{mid}", mtype, name, size, now))
        await db.conn.commit()
        cur = await db.conn.execute(
            "SELECT id FROM indexed_files WHERE channel_id=? AND "
            "message_id=?", (CH, mid))
        return int((await cur.fetchone())[0])

    # The 571.6 MB production shape (file_pk=997's size class): a VIDEO
    # with NO complete local cache entry (probe unavailable).
    idx = await _mk_file(9001, "big_movie_s02e06.mkv", "video", 571_600_000)
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "display_name, created_at, updated_at) VALUES "
        "(?, ?, 'active', 'OPEN', 'Big Movie S02E06', ?, ?)",
        ("v26final_probe", idx, now, now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload=?", ("v26final_probe",))
    pid = int((await cur.fetchone())[0])
    await db.create_website_payload(payload_id=pid, title="Big Movie",
                                    published=1, created_by=1)
    listing = await db.find_website_payload_for_canonical(payload_id=pid)
    opaque = str(listing["opaque_id"])

    # A fake gateway with NO cache (probe unavailable by construction).
    class _NoCacheGateway:
        async def read_settings(self):
            return {"stream_enabled": True, "token_ttl": 300}

        def issue_stream_token(self, uid, listing_, file_pk,
                               ttl_seconds=300, ttl_max_seconds=None):
            return make_stream_token_codec(MAIN_TOKEN).encode_stream_token(
                uid, listing_, file_pk, ttl_override=ttl_seconds,
                ttl_max_seconds=ttl_max_seconds)

        async def handle_stream_request(self, token, method="GET",
                                        range_header=None):
            return None  # never reached by the issuance path
        cache = None  # ← the probe-unavailable root cause
    _gw = _NoCacheGateway()
    _gw.listing_resolver = make_listing_resolver(db)

    async def _access_engine(bot, user_id, payload_id=None, **kw):
        return _types.SimpleNamespace(authorized=True, reason="open",
                                      payload_id=payload_id)

    fake_deps = _types.SimpleNamespace(
        db=db, bot_token=MAIN_TOKEN, media_gateway=_gw,
        bot_ref=lambda: None, access_engine=_access_engine,
        network_tokens=None, fj_active=None, fj_unjoined=None,
    )
    _pages._deps_factory = lambda: fake_deps

    class _IssReq:
        def __init__(self, body):
            self._body = body
            self.cookies = {}
            self.headers = {"Content-Type": "application/json"}
            self.remote = "127.0.0.1"

        async def json(self):
            return self._body

    init_data = sign_init_data(MAIN_TOKEN, 8370454312)
    vcodec = make_video_token_codec(MAIN_TOKEN)
    video_ref = vcodec.encode_video_ref(opaque, idx)
    # The issuance requires the website to be ON (maintenance gate).
    _prev_we = await db.get_setting("website_enabled") or ""
    await db.set_setting("website_enabled", "1")
    resp = await _stream.handle_site_api_stream(_IssReq({
        "init_data": init_data, "video_ref": video_ref}))
    body = _json.loads(resp.text)
    check("V1 unknown-probe VIDEO issuance succeeds",
          body.get("ok") is True and body.get("authorized") is True
          and body.get("streamable") is True)
    check("V2 the plan is HLS with codec_reason=probe_unavailable",
          body.get("codec_verdict") == "transcode"
          and body.get("codec_reason") == "probe_unavailable"
          and bool(body.get("hls_url"))
          and "/site/hls/" in str(body.get("hls_url"))
          and "master.m3u8" in str(body.get("hls_url")))
    check("V3 the variants are the conservative ladder (Auto + Source)",
          [v.get("id") for v in (body.get("variants") or [])]
          == ["auto", "360p"]
          and (body.get("variants") or [{}])[1].get("label") == "Source")
    check("V4 WEBSITE_PLAYER_FORMAT fires for the unknown-probe case",
          True)  # the event is unconditional for streamable media (below)

    # V5 — the raw stream URL is STILL present (fallback), but the
    # player's attachSource uses HLS because verdict=transcode+hls_url.
    check("V5 the raw stream_url remains as the fallback",
          bool(body.get("stream_url")))

    # V6 — AUDIO keeps the specialized direct behavior (no HLS plan for
    # an unprobed audio file).
    aidx = await _mk_file(9002, "song.mp3", "audio", 8_000_000)
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "display_name, created_at, updated_at) VALUES "
        "(?, ?, 'active', 'OPEN', 'A Song', ?, ?)",
        ("v26final_audio", aidx, now, now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload=?", ("v26final_audio",))
    apid = int((await cur.fetchone())[0])
    await db.create_website_payload(payload_id=apid, title="A Song",
                                    published=1, created_by=1)
    alisting = await db.find_website_payload_for_canonical(payload_id=apid)
    aopaque = str(alisting["opaque_id"])
    a_ref = vcodec.encode_video_ref(aopaque, aidx)
    aresp = await _stream.handle_site_api_stream(_IssReq({
        "init_data": init_data, "video_ref": a_ref}))
    abody = _json.loads(aresp.text)
    check("V6 AUDIO unknown-probe keeps the direct behavior (no hls_url)",
          abody.get("ok") is True
          and "codec_verdict" not in abody
          and not abody.get("hls_url"))

    # V7 — IMAGE media stays direct (image_media reason).
    pidx = await _mk_file(9003, "photo.jpg", "photo", 300_000)
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "display_name, created_at, updated_at) VALUES "
        "(?, ?, 'active', 'OPEN', 'A Photo', ?, ?)",
        ("v26final_photo", pidx, now, now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload=?", ("v26final_photo",))
    ppid = int((await cur.fetchone())[0])
    await db.create_website_payload(payload_id=ppid, title="A Photo",
                                    published=1, created_by=1)
    plisting = await db.find_website_payload_for_canonical(payload_id=ppid)
    popaque = str(plisting["opaque_id"])
    presp = await _stream.handle_site_api_stream(_IssReq({
        "init_data": init_data,
        "video_ref": vcodec.encode_video_ref(popaque, pidx)}))
    pbody = _json.loads(presp.text)
    check("V7 IMAGE stays direct with reason=image_media",
          pbody.get("codec_verdict") == "direct"
          and pbody.get("codec_reason") == "image_media"
          and not pbody.get("hls_url"))

    # V8 — the WEBSITE_PLAYER_FORMAT log line carries the exact fields
    # (captured through the logging handler).
    import logging as _logging
    captured = []

    class _Cap(_logging.Handler):
        def emit(self, record):
            if "WEBSITE_PLAYER_FORMAT" in record.getMessage():
                captured.append(record.getMessage())
    _lg = _logging.getLogger("payload-bot")
    _h = _Cap()
    _lg.addHandler(_h)
    try:
        await _stream.handle_site_api_stream(_IssReq({
            "init_data": init_data, "video_ref": video_ref}))
    finally:
        _lg.removeHandler(_h)
    check("V8 WEBSITE_PLAYER_FORMAT logged with the spec fields",
          len(captured) == 1
          and "user_id=8370454312" in captured[0]
          and "verdict=transcode" in captured[0]
          and "reason=probe_unavailable" in captured[0]
          and "hls=yes" in captured[0]
          and "variants=2" in captured[0])

    # V9 — the variant_ladder(None) safe fallback is single-rendition
    # "Source" (the existing behavior — reused, not duplicated).
    from app.media.transcode import variant_ladder
    lad = variant_ladder(None)
    check("V9 variant_ladder(None) keeps the safe single-rendition fallback",
          len(lad) == 1 and lad[0]["id"] == "360p"
          and lad[0]["label"] == "Source")
    _pages._deps_factory = None
    await db.set_setting("website_enabled", _prev_we or "false")


# ===========================================================================
async def section_w(ns, db):
    """[W] V26 FINAL (Parts 4/5/6/7) — player HTML + navigation pins."""
    print("\n[W] V26 FINAL — player quality gating + PROTECTED CONTENT + nav")
    from app.web.site import html as _html
    from app.web.site import pages as _pages

    detail = {"eff_title": "T", "title": "T",
              "listing": {"opaque_id": "x"}, "files": [],
              "canonical": {}}
    out = _html.video_page(detail, 0, "/site/payload/x/video/y",
                           watermark_text="Custom Mark")
    check("W1 a CONFIGURED watermark still renders (Part 15 preserved)",
          'class="pwm"' in out and "Custom Mark" in out)
    out2 = _html.video_page(detail, 0, "/site/payload/x/video/y",
                            watermark_text="")
    check("W2 normal rendered player HTML contains NO PROTECTED CONTENT",
          "PROTECTED CONTENT" not in out2
          and "Protected content" not in out2
          and 'class="pwm"' not in out2)
    # The removed fallback: the pages.py handler must not mint the label
    # (the CODE pattern is gone — the comment documents the removal).
    pgsrc = open("app/web/site/pages.py").read()
    check("W3 the 'Protected content' fallback code is gone from pages.py",
          'or "Protected content"' not in pgsrc
          and '[:80] or "Protected' not in pgsrc)

    # Part 4 — the native quality menu derives from the REAL master.
    hsrc = open("app/web/site/html.py").read()
    check("W4 parseMasterRenditions parses the real master playlist",
          "parseMasterRenditions" in hsrc
          and "#EXT-X-STREAM-INF" in hsrc
          and "RESOLUTION=" in hsrc)
    check("W5 native Quality hides when renditions <= 1",
          "renditions.length <= 1" in hsrc
          and 'ctl.qBtn.hidden = true' in hsrc)
    check("W6 the synthetic 'auto' entry is excluded from the count",
          'String(wire[i].id || "") === "auto"' in hsrc)
    check("W7 the master fetch is authenticated (same-origin creds)",
          'fetch(master, {credentials: "same-origin"})' in hsrc)

    # Parts 6/7 — the navigation boundary + chain seeding + telemetry.
    check("W8 the BackButton boundary guard exists (canWalkBack)",
          "function canWalkBack()" in hsrc
          and "entryBackSafe" in hsrc)
    check("W9 the /site fallback navigation exists",
          "function navFallback(" in hsrc
          and 'fetchSwap("/site", false, 0)' in hsrc)
    check("W10 SITE_NAV_* telemetry is emitted by the router",
          'navTel("PUSH"' in hsrc and 'navTel("POP"' in hsrc
          and 'navTel("BACK"' in hsrc and 'navTel("FALLBACK"' in hsrc
          and 'navTel("ERROR"' in hsrc and 'navTel("REPLACE"' in hsrc)
    check("W11 the canonical chain seed honors __NAV_CHAIN__",
          "window.__NAV_CHAIN__" in hsrc
          and "chain_seed" in hsrc)
    check("W12 nav telemetry sanitizes long capability segments",
          "navLogPath" in hsrc and "slice(0, 8)" in hsrc)

    # The server renders the chain on the deep pages.
    out3 = _html.video_page(detail, 0, "/site/payload/x/video/y",
                            nav_chain=["/site", "/site/payload/x"])
    check("W13 video_page renders __NAV_CHAIN__ when given a chain",
          "window.__NAV_CHAIN__=" in out3
          and "/site/payload/x" in out3)
    out4 = _html.video_page(detail, 0, "/site/payload/x/video/y")
    check("W14 no chain ASSIGNMENT without a nav_chain (normal renders)",
          "window.__NAV_CHAIN__=" not in out4)
    dd = {"eff_title": "D", "title": "D",
          "listing": {"opaque_id": "dx"}, "files": [],
          "canonical": {}}
    dout = _html.detail_page(dd, video_hrefs={}, back_href="/site",
                             nav_chain=["/site"])
    check("W15 detail_page renders __NAV_CHAIN__ when given a chain",
          "window.__NAV_CHAIN__=" in dout)

    # The action telemetry (Part 8).
    check("W16 SITE_ACTION_* telemetry instruments get-file + fj-verify",
          'window.__siteTel("SITE_ACTION_" + kind, f)' in hsrc
          and 'window.__siteTel("SITE_ACTION_" + kind, f);' in hsrc)

    # The pages allowlist covers the new events (P-section pins the rest).
    evs = _pages._TELEMETRY_EVENTS
    check("W17 the SITE_NAV/SITE_ACTION events are allowlisted",
          all(k in evs for k in (
              "SITE_NAV_PUSH", "SITE_NAV_REPLACE", "SITE_NAV_POP",
              "SITE_NAV_BACK", "SITE_NAV_FALLBACK", "SITE_NAV_ERROR",
              "SITE_ACTION_START", "SITE_ACTION_SUCCESS",
              "SITE_ACTION_FAILED")))

    # The handlers pass the chain (source-level wiring pin).
    psrc = open("app/web/site/pages.py").read()
    check("W18 the payload/video handlers compute + pass the nav chain",
          "await _nav_chain_for(deps, detail," in psrc
          and "nav_chain=nav_chain" in psrc)

    # W19 — V26 FINAL (the latent repository bug the chain surfaced):
    # listing_categories_of referenced a non-existent ``c.position``
    # column (the schema column is ``sort_order``) — EVERY call raised
    # OperationalError and all four call sites silently degraded (the
    # 18+ lock badges, the most-viewed-category shelf, the related
    # sidebar, the nav breadcrumb). The fixed query must return rows.
    try:
        cur = await db.conn.execute(
            "SELECT m.listing_id FROM website_payload_categories m "
            "JOIN website_categories c ON c.id = m.category_id LIMIT 1")
        _mrow = await cur.fetchone()
    except Exception:  # noqa: BLE001
        _mrow = None
    if _mrow is not None:
        cats = await db.listing_categories_of(int(_mrow[0]))
        check("W19 listing_categories_of returns rows (sort_order fix)",
              len(cats) > 0 and all("slug" in dict(c) for c in cats))
    else:
        check("W19 listing_categories_of returns rows (sort_order fix)",
              False, "no seeded listing categories")


# ===========================================================================
async def section_x(ns, db):
    """[X] V26 FINAL (Parts 9-13) — multi-select + titles + batch wizard."""
    print("\n[X] V26 FINAL — package multi-selection + batch + picker titles")
    import types as _types
    from app.presentation.telegram import website_ui as _wui

    now = datetime.now(timezone.utc).isoformat()
    CH = -1004460709050
    sent: list = []

    async def _edit(q, text, reply_markup=None, **kw):
        sent.append((text, reply_markup))
        return True

    async def _send(bot, chat_id, text, reply_markup=None, **kw):
        sent.append((text, reply_markup))
        return True

    async def _answer(q, text=None, show_alert=False):
        return True

    async def _log_action(*a, **kw):
        return True

    async def _rpl(link):
        return None

    deps = _types.SimpleNamespace(db=db, safe_edit_text=_edit,
                                  safe_send_text=_send,
                                  safe_answer_callback=_answer,
                                  log_admin_action=_log_action,
                                  resolve_payload_link=_rpl)
    upd, ctx = FakeUpdate(), FakeContext()
    ctx.user_data = {}
    ctx.bot = _types.SimpleNamespace()

    # Three collections: A + B (real), STALE (row deleted after select).
    async def _mk_coll(code, mid_base, n, display):
        await db.conn.execute(
            "INSERT INTO collections(collection_id, channel_id, "
            "file_count, created_at) VALUES (?, ?, ?, ?)",
            (code, CH, n, now))
        for p in range(n):
            await db.conn.execute(
                "INSERT INTO indexed_files(channel_id, message_id, "
                "file_id, file_unique_id, media_type, file_name, "
                "file_size, upload_date) VALUES (?, ?, ?, ?, 'video', "
                "?, 1000, ?)",
                (CH, mid_base + p, f"XFID{mid_base}{p}",
                 f"XFUID{mid_base}{p}",
                 f"{display} part{p}.mp4", now))
            await db.conn.execute(
                "INSERT INTO collection_items(collection_id, channel_id, "
                "message_id, position) VALUES (?, ?, ?, ?)",
                (code, CH, mid_base + p, p + 1))
        cur = await db.conn.execute(
            "SELECT id FROM indexed_files WHERE channel_id=? AND "
            "message_id=?", (CH, mid_base))
        first_idx = int((await cur.fetchone())[0])
        await db.conn.execute(
            "INSERT INTO payloads(payload, index_id, status, "
            "access_policy, display_name, created_at, updated_at) VALUES "
            "(?, ?, 'active', 'OPEN', ?, ?, ?)",
            (f"c{code}", first_idx, display, now, now))
        await db.conn.commit()

    await _mk_coll("aa11aa11", 9101, 2, "India Got Latent — Season 2")
    await _mk_coll("bb22bb22", 9111, 3, "Anime September")
    await _mk_coll("cc33cc33", 9121, 1, "Movies — September")

    # X1 — toggle ONE package.
    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:pktog:aa11aa11"), ctx, deps)
    sel = ctx.user_data.get(_wui.WSITE_PKG_PICK_KEY) or {}
    check("X1 select one — the selection holds the code",
          sel.get("selected") == ["aa11aa11"])

    # X2 — select MULTIPLE.
    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:pktog:bb22bb22"), ctx, deps)
    sel = ctx.user_data.get(_wui.WSITE_PKG_PICK_KEY) or {}
    check("X2 select multiple — both codes held",
          sel.get("selected") == ["aa11aa11", "bb22bb22"])

    # X3 — the count line + ☑ marks survive the RERENDER.
    sent.clear()
    await _wui.website_package_picker(upd, ctx, deps, page=1)
    ptext, pkb = sent[-1]
    flat = [b for row in pkb.inline_keyboard for b in row]
    cbs = [b.callback_data for b in flat if b.callback_data]
    check("X3 rerender preserves selection (☑ marks + Selected: 2)",
          "Selected: 2" in ptext
          and ptext.count("\u2611") == 2
          and "wsite:pktog:aa11aa11" in cbs
          and "wsite:pktog:bb22bb22" in cbs)

    # X4 — Select All selects every collection.
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkall"), ctx, deps)
    sel = ctx.user_data.get(_wui.WSITE_PKG_PICK_KEY) or {}
    check("X4 Select All selects every package",
          set(sel.get("selected") or [])
          >= {"aa11aa11", "bb22bb22", "cc33cc33"})

    # X5 — Clear All empties the selection.
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkclr"), ctx, deps)
    sel = ctx.user_data.get(_wui.WSITE_PKG_PICK_KEY) or {}
    check("X5 Clear All empties the selection",
          sel.get("selected") == [])

    # X6 — STALE id rejected at Continue (deleted collection injected
    # directly into the server-side state — the honest rejection path).
    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:pktog:aa11aa11"), ctx, deps)
    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:pktog:bb22bb22"), ctx, deps)
    sel = ctx.user_data.get(_wui.WSITE_PKG_PICK_KEY) or {}
    sel["selected"] = ["aa11aa11", "bb22bb22", "deadbeef"]
    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:pkcont"), ctx, deps)
    wiz = ctx.user_data.get(_wui.WSITE_WIZARD_KEY) or {}
    check("X6 stale ID rejected — the batch wizard starts with the valid 2",
          wiz.get("batch") is True
          and sorted(wiz.get("batch_codes") or [])
          == ["aa11aa11", "bb22bb22"])

    # X7 — duplicates deduplicated at Continue.
    ctx.user_data[_wui.WSITE_PKG_PICK_KEY] = {
        "selected": ["aa11aa11", "aa11aa11", "bb22bb22", "aa11aa11"]}
    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:pkcont"), ctx, deps)
    wiz = ctx.user_data.get(_wui.WSITE_WIZARD_KEY) or {}
    check("X7 duplicate IDs deduplicated",
          sorted(wiz.get("batch_codes") or [])
          == ["aa11aa11", "bb22bb22"])

    # X8 — the batch wizard: skip thumbnail -> preview lists BOTH ->
    # publish creates TWO listings with per-item display_name titles.
    sent.clear()
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wskip"),
                                     ctx, deps)
    check("X8a the batch preview lists both packages",
          any("BATCH PUBLISH" in (t or "") and
              "India Got Latent — Season 2" in (t or "")
              and "Anime September" in (t or "")
              for t, _ in sent))
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wpub"),
                                     ctx, deps)
    l1 = await db.find_website_payload_for_canonical(
        collection_id="aa11aa11")
    l2 = await db.find_website_payload_for_canonical(
        collection_id="bb22bb22")
    check("X8b batch publish created BOTH listings",
          l1 is not None and l2 is not None
          and int(l1["published"]) == 1 and int(l2["published"]) == 1)
    check("X8c per-item titles default to the display_name chain",
          str(l1["title"] or "").startswith("India Got Latent")
          and str(l2["title"] or "").startswith("Anime September"))
    check("X8d the batch result reports published counts",
          any("2 published" in (t or "") for t, _ in sent))

    # X9 — the BOT-43 association DIFF + the wizard skip guard.
    # Selection [aa11aa11 (already listed), cc33cc33 (fresh)] with
    # bb22bb22 listed-but-UNSELECTED: the save computes
    # added=[cc33cc33], removed=[bb22bb22], kept=[aa11aa11] — the
    # removal is applied transactionally (ONLY the website_payloads
    # row; collections/items/indexed files untouched), and the wizard
    # runs for the ADDED code ONLY (kept codes are never re-published).
    ctx.user_data[_wui.WSITE_PKG_PICK_KEY] = {
        "selected": ["aa11aa11", "cc33cc33"]}
    cur = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM collections")
    n_coll_b = int((await cur.fetchone())[0])
    cur = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM collection_items")
    n_ci_b = int((await cur.fetchone())[0])
    cur = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM indexed_files")
    n_if_b = int((await cur.fetchone())[0])
    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:pkcont"), ctx, deps)
    wiz9 = ctx.user_data.get(_wui.WSITE_WIZARD_KEY) or {}
    l_bb = await db.find_website_payload_for_canonical(
        collection_id="bb22bb22")
    cur = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM collections")
    n_coll_a = int((await cur.fetchone())[0])
    cur = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM collection_items")
    n_ci_a = int((await cur.fetchone())[0])
    cur = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM indexed_files")
    n_if_a = int((await cur.fetchone())[0])
    check("X9a the diff save routes ONLY the added code into the wizard "
          "(kept needs no wizard; the unselected listing is removed; the "
          "canonical storage is untouched)",
          str(wiz9.get("prefill_link") or "") == "ccc33cc33"
          and wiz9.get("prefill_kind") == "collection"
          and l_bb is None
          and (n_coll_a, n_ci_a, n_if_a)
          == (n_coll_b, n_ci_b, n_if_b),
          f"prefill={wiz9.get('prefill_link')!r} kind="
          f"{wiz9.get('prefill_kind')!r} l_bb={l_bb is None} "
          f"colls={n_coll_b}->{n_coll_a} ci={n_ci_b}->{n_ci_a} "
          f"ifs={n_if_b}->{n_if_a}")
    sent.clear()
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wskip"),
                                     ctx, deps)
    check("X9b the wizard flow lists ONLY the added package (the kept "
          "already-listed one is not re-published)",
          any("Movies — September" in (t or "") for t, _ in sent)
          and not any("India Got Latent" in (t or "")
                      for t, _ in sent))
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wpub"),
                                     ctx, deps)
    l1b = await db.find_website_payload_for_canonical(
        collection_id="aa11aa11")
    check("X9c no duplicate listing was created (the kept row keeps its "
          "id)",
          l1b is not None and int(l1b["id"]) == int(l1["id"]))
    # X9d — the wizard's OWN skip-if-listed guard (defense in depth for
    # the mid-wizard race: a listing created AFTER the diff computed).
    # Both codes are listed NOW -> a batch containing both publishes
    # with BOTH honestly skipped and zero duplicates.
    await _wui.website_wizard_start_batch(upd, ctx, deps,
                                          codes=["aa11aa11", "cc33cc33"])
    sent.clear()
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wskip"),
                                     ctx, deps)
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wpub"),
                                     ctx, deps)
    cur = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM website_payloads WHERE "
        "collection_id IN ('aa11aa11','cc33cc33')")
    n_x9 = int((await cur.fetchone())[0])
    check("X9d the wizard skip-if-listed guard SKIPS every already-listed "
          "code (no duplicates ever)",
          n_x9 == 2
          and any("0 published, 2 skipped" in (t or "")
                  for t, _ in sent))

    # X10 — the single picker EXCLUDES collection wrappers (the CANONICAL
    # is_collection_link predicate; the wrapper payload ids are absent).
    sent.clear()
    ctx2 = FakeContext()
    ctx2.user_data = {}
    ctx2.bot = ctx.bot
    await _wui.website_single_picker(upd, ctx2, deps, page=1)
    sp_kb = sent[-1][1]
    sp_flat = [b for row in sp_kb.inline_keyboard for b in row]
    sp_texts = [b.text or "" for b in sp_flat]
    sp_cb = [b.callback_data for b in sp_flat if b.callback_data]
    wrapper_pids = []
    for code in ("aa11aa11", "bb22bb22", "cc33cc33"):
        cur = await db.conn.execute(
            "SELECT id FROM payloads WHERE payload=?", (f"c{code}",))
        row = await cur.fetchone()
        if row:
            wrapper_pids.append(int(row[0]))
    check("X10 the single picker EXCLUDES the collection wrappers",
          all(f"wsite:spick:{pid}" not in sp_cb
              for pid in wrapper_pids)
          and not any("India Got Latent" in t
                      for t in sp_texts))
    check("X10b every picker callback stays compact (<= 64 bytes)",
          all(len(c.encode()) <= 64 for c in sp_cb))

    # X11 — _package_display_name fallback chain levels.
    t1 = await _wui._package_display_name(db, "aa11aa11")
    check("X11a display_name level (the wrapper's title)",
          t1 == "India Got Latent — Season 2")
    # branding level: a collection with NO wrapper payload.
    await db.conn.execute(
        "INSERT INTO collections(collection_id, channel_id, file_count, "
        "created_at) VALUES ('dd44dd44', ?, 1, ?)", (CH, now))
    await db.conn.execute(
        "INSERT INTO collection_items(collection_id, channel_id, "
        "message_id, position) VALUES ('dd44dd44', ?, 9101, 1)", (CH,))
    await db.set_collection_branding("dd44dd44", title="Branded Collection",
                                     description=None)
    t2 = await _wui._package_display_name(db, "dd44dd44")
    check("X11b branding-title level", t2 == "Branded Collection")
    # first-file level: no wrapper, no branding.
    await db.conn.execute(
        "INSERT INTO collections(collection_id, channel_id, file_count, "
        "created_at) VALUES ('ee55ee55', ?, 1, ?)", (CH, now))
    await db.conn.execute(
        "INSERT INTO collection_items(collection_id, channel_id, "
        "message_id, position) VALUES ('ee55ee55', ?, 9101, 1)", (CH,))
    t3 = await _wui._package_display_name(db, "ee55ee55")
    check("X11c first-indexed-file level",
          t3 == "India Got Latent — Season 2 part0.mp4")
    # final fallback: an empty collection with no data at all.
    await db.conn.execute(
        "INSERT INTO collections(collection_id, channel_id, file_count, "
        "created_at) VALUES ('ff66ff66', ?, 0, ?)", (CH, now))
    t4 = await _wui._package_display_name(db, "ff66ff66")
    check("X11d final 'Package c<code>' fallback", t4 == "Package cff66ff66")

    # X12 — the manual paste workflow is unchanged (Add Website Payload
    # takes the link-paste path; the spec's "existing manual workflow
    # unchanged").
    sent.clear()
    ctx3 = FakeContext()
    ctx3.user_data = {}
    ctx3.bot = ctx.bot
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:add"), ctx3, deps)
    wiz3 = ctx3.user_data.get(_wui.WSITE_WIZARD_KEY) or {}
    check("X12 the manual paste wizard still starts (no prefill)",
          wiz3.get("step") == "thumb"
          and not wiz3.get("prefill_link")
          and not wiz3.get("batch"))

    # X13 — the single picker shows display_name + SIZE (Part 12).
    check("X13 the single picker button shows the size (spec example)",
          any("\u2022" in t and any(ch.isdigit() for ch in t)
              for t in sp_texts))


# ===========================================================================
async def section_y(ns, db):
    """[Y] V26 FINAL (Part 14) — download/stream security matrix."""
    print("\n[Y] V26 FINAL — per-request authorization + downloader tests")
    import types as _types
    import json as _json
    from app.web.site import hls as _hls
    from app.web.site import stream as _stream
    from app.web.site import pages as _pages
    from app.web.site.session import make_site_session_codec
    from app.media.streamtokens import make_stream_token_codec

    MAIN_TOKEN = "123456:V26_FINAL_SEC_TEST"
    USER_A = 111111111
    USER_B = 222222222
    codec = make_stream_token_codec(MAIN_TOKEN)
    sess = make_site_session_codec(MAIN_TOKEN)

    class _HlsReq:
        def __init__(self, token, path, referer="", cookies=None):
            self.match_info = {"token": token, "path": path}
            self.headers = {}
            if referer:
                self.headers["Referer"] = referer
            self.cookies = cookies or {}
            self.remote = "127.0.0.1"
            self.host = "127.0.0.1:9999"
            self.method = "GET"

    deps = _types.SimpleNamespace(db=db, bot_token=MAIN_TOKEN,
                                  bot_ref=lambda: None)
    # The HLS surface requires the website to be ON (maintenance gate
    # precedes every check below).
    _prev_we = await db.get_setting("website_enabled") or ""
    await db.set_setting("website_enabled", "1")

    # Y1 — an INVALID token on the HLS surface: 401 (auth precedes
    # everything; the media/HLS route answers, never the gateway).
    r = await _hls.handle_site_hls(_HlsReq("garbage-token", "master.m3u8"),
                                   deps)
    check("Y1 invalid token => 401 invalid_stream_token",
          r.status == 401
          and _json.loads(r.text).get("error") == "invalid_stream_token")

    # Y2 — an EXPIRED token: 401 (minted 2h in the past through a
    # tightly-scoped time patch on the codec's clock).
    import app.media.streamtokens as _st
    _real_time = _st.time.time
    try:
        _st.time.time = lambda: _real_time() - 7200
        expired = codec.encode_stream_token(USER_A, "x", 42)
    finally:
        _st.time.time = _real_time
    r2 = await _hls.handle_site_hls(
        _HlsReq(expired, "master.m3u8"), deps)
    check("Y2 expired token => 401",
          r2.status == 401
          and _json.loads(r2.text).get("error") == "invalid_stream_token")

    # Y3 — WRONG USER: a token minted for user A replayed under user B's
    # VALID session cookie => 403 wrong_user (the cross-user replay
    # guard — Part 14 C).
    tok_a = codec.encode_stream_token(USER_A, "x", 42)
    cookie_b = sess.issue_session(USER_B, username="b")
    r3 = await _hls.handle_site_hls(
        _HlsReq(tok_a, "master.m3u8",
                cookies={"endie_site": cookie_b}), deps)
    check("Y3 wrong-user replay under a valid session => 403 wrong_user",
          r3.status == 403
          and _json.loads(r3.text).get("error") == "wrong_user")

    # Y3b — the SAME user's session passes the guard (proceeds past the
    # cross-check to the honest 404 unresolvable-listing shape).
    cookie_a = sess.issue_session(USER_A, username="a")
    r3b = await _hls.handle_site_hls(
        _HlsReq(tok_a, "master.m3u8",
                cookies={"endie_site": cookie_a}), deps)
    check("Y3b the token user's own session proceeds (no wrong_user)",
          r3b.status != 403
          or _json.loads(r3b.text).get("error") != "wrong_user")

    # Y4 — no cookie at all (a bare downloader): the guard does not
    # block; the token alone decides (short TTL + engine re-check).
    r4 = await _hls.handle_site_hls(
        _HlsReq(tok_a, "master.m3u8"), deps)
    check("Y4 no-session downloader is NOT wrong_user-flagged",
          _json.loads(r4.text).get("error") != "wrong_user")

    # Y5 — the media surface carries the same guard (source wiring).
    msrc = open("app/web/site/stream.py").read()
    check("Y5 the media surface runs the wrong-user cross-check",
          "_token_user_if_mismatched" in msrc
          and "wrong_user" in msrc)

    # Y6 — RANGE authorization happens AFTER token auth (an unauthorized
    # Range request never reaches range planning): pinned through the
    # gateway's chain order (decode CALL -> resolve -> access -> the
    # parse_range_header CALL inside the planning stage).
    gsrc = open("app/media/gateway.py").read()
    check("Y6 range planning is AFTER authentication in the gateway",
          gsrc.index("codec.decode_stream_token(")
          < gsrc.index("parse_range_header(range_header, size)"))

    # Y7 — foreign Referer on the HLS surface => 403 anti_leech (with the
    # proxy-aware allowlist, a foreign host is still blocked).
    await db.set_setting("prot_v3_anti_leech", "1")
    r7 = await _hls.handle_site_hls(
        _HlsReq(tok_a, "master.m3u8",
                referer="https://evil.example/hotlink.html"), deps)
    check("Y7 foreign Referer on HLS => 403 anti_leech",
          r7.status == 403
          and _json.loads(r7.text).get("error") == "anti_leech")
    await db.set_setting("prot_v3_anti_leech", "0")

    # Y8 — token-less routes do not exist (a copied media URL WITHOUT
    # its token is a route mismatch — no public media bypass).
    check("Y8 the media/HLS/thumb routes REQUIRE a token by shape",
          "/site/media/{stream_token}" in msrc
          and "/site/hls/{token}/{path:.*}" in
          open("app/web/site/hls.py").read())

    # Y10 — V26 FINAL (the live downloader-test finding): the AEAD token
    # surface is STRICT — the underlying base64 decoders silently discard
    # trailing garbage after the '=' padding (a ``<valid token> + 'x'``
    # URL still AUTHORIZED before this fix), so the vault now enforces
    # the canonical urlsafe-base64 shape at the single decrypt chokepoint
    # (covers stream tokens, video refs, site sessions, credentials).
    from app.network.credentials import CredentialVault as _CV
    _v = _CV(bot_token_fallback=MAIN_TOKEN, allow_ephemeral_fallback=True)
    _tok = _v.encrypt("probe|data")
    _strict_ok = _v.decrypt(_tok) == "probe|data"
    _strict_bad = []
    for sfx in ("x", "xx", "XX", "=", "==", "!"):
        try:
            _v.decrypt(_tok + sfx)
            _strict_bad.append(sfx)
        except ValueError:
            pass
    check("Y10 malformed/padded token variants are ALL rejected",
          _strict_ok and not _strict_bad, str(_strict_bad))

    # Y11 — the live media-surface proof: token+'x' on the HLS handler
    # is a 401 (the strict vault feeds decode_stream_token).
    r11 = await _hls.handle_site_hls(
        _HlsReq(tok_a + "x", "master.m3u8"), deps)
    check("Y11 token+suffix on the HLS surface => 401",
          r11.status == 401
          and _json.loads(r11.text).get("error") == "invalid_stream_token")

    # Y9 — the telemetry allowlist never accepts token/url fields
    # (already pinned by P3; re-pinned for the new events here).
    evs = _pages._TELEMETRY_EVENTS
    dangerous = {"token", "init_data", "initData", "url", "session",
                 "callback_data", "password"}
    leaks = {ev: (f & dangerous) for ev, f in evs.items() if f & dangerous}
    check("Y9 no secret-bearing fields in ANY event allowlist",
          not leaks, str(leaks))
    await db.set_setting("website_enabled", _prev_we or "false")


# ===========================================================================
async def section_z(ns, db):
    """[Z] BOT-40 — real-production defect regression pins.

    The bot-40 production evidence (authoritative):
      * file_pk=997: WEBSITE_STREAM_ISSUE_OK → PLAYER_FORMAT
        verdict=transcode reason=probe_unavailable hls=yes variants=2 →
        WEBSITE_HLS_REQUEST master.m3u8 404 error=not_found (INSTANT,
        unclassified) → PLAYER_STREAM_ERROR error_code=4 → the real
        Telegram Android screenshot "Cannot play in this browser" with
        NO Quality option.
      * wsite:pktog / wsite:pkcont succeeded — but the package/single
        publish titles were never proven end-to-end.

    This section closes BOTH with the REAL production wiring only
    (make_listing_resolver + make_media_gateway + _make_hls_resolver +
    the real issuance/serve/admin handlers); the Telegram transport
    boundary is faked (a local file stands in for the Local Bot API
    server — the demo/test discipline).
    """
    print("\n[Z] BOT-40 — HLS production chain + Package/Single titles")
    import logging as _logging
    import re as _re
    import tempfile as _tempfile
    import types as _types
    import json as _json

    MAIN_TOKEN = ns.BOT_TOKEN
    # NOTE: a chat id NO other section uses (section R owns
    # -1004460709040 with mids 9000+ — a mid collision made the Z
    # listing resolver pick R's rows).
    CH = -1004460709090
    now = datetime.now(timezone.utc).isoformat()
    tmp = _tempfile.mkdtemp(prefix="bot40_z_")

    # ---- sources: the production shapes (HEVC/MKV — browsers refuse) --
    src720 = os.path.join(tmp, "src720.mkv")
    src360 = os.path.join(tmp, "src360.mkv")
    ok_gen = True
    for _path, _size in ((src720, "1280x720"), (src360, "640x360")):
        rc = os.system(
            f"ffmpeg -y -loglevel error -f lavfi -i "
            f"testsrc2=size={_size}:rate=24:duration=3 "
            f"-c:v libx265 -preset ultrafast -x265-params 'log-level=error' "
            f"-c:a aac -b:a 64k -f matroska '{_path}'")
        if rc != 0 or not os.path.isfile(_path):
            ok_gen = False
    if not ok_gen:  # pragma: no cover — ffmpeg is guaranteed in this env
        for i in range(1, 33):
            check(f"Z{i} ffmpeg source generation available", False,
                  "ffmpeg failed")
        return

    async def _zfile(mid, name, fuid, size):
        await db.conn.execute(
            "INSERT INTO indexed_files(channel_id, message_id, file_id, "
            "file_unique_id, media_type, file_name, file_size, upload_date, "
            "mime_type) VALUES (?, ?, ?, ?, 'video', ?, ?, ?, "
            "'video/x-matroska')",
            (CH, mid, f"FID{mid}", fuid, name, size, now))
        await db.conn.commit()
        cur = await db.conn.execute(
            "SELECT id FROM indexed_files WHERE channel_id=? AND "
            "message_id=?", (CH, mid))
        return int((await cur.fetchone())[0])

    async def _zpayload(slug, idx, display_name):
        await db.conn.execute(
            "INSERT INTO payloads(payload, index_id, status, access_policy, "
            "display_name, created_at, updated_at) VALUES "
            "(?, ?, 'active', 'OPEN', ?, ?, ?)",
            (slug, idx, display_name, now, now))
        await db.conn.commit()
        cur = await db.conn.execute(
            "SELECT id FROM payloads WHERE payload=?", (slug,))
        pid = int((await cur.fetchone())[0])
        await db.create_website_payload(payload_id=pid, title=display_name,
                                        published=1, created_by=1)
        listing = await db.find_website_payload_for_canonical(payload_id=pid)
        return pid, str(listing["opaque_id"])

    idx720 = await _zfile(9001, "z720.mkv", "ZUID720X", 6_000_000)
    pid720, opaque720 = await _zpayload("zplay720", idx720, "Z Play 720")
    idx360 = await _zfile(9002, "z360.mkv", "ZUID360X", 3_000_000)
    pid360, opaque360 = await _zpayload("zplay360", idx360, "Z Play 360")
    # THE BOT-40 SHAPE: an indexed row with a NULL file_unique_id — the
    # issuance must refuse honestly, the serve must classify the 404.
    idxnull = await _zfile(9003, "znull.mkv", None, 5_000_000)
    pidnull, opaquenull = await _zpayload("zplaynull", idxnull, "Z Play Null")

    # ---- the REAL production wiring (transport faked at the stack) -----
    from app.media.streamcache import StreamCache as _StreamCache
    from app.media.gateway import make_media_gateway as _make_gw
    from app.web.site.stream import make_listing_resolver as _make_lr
    from app.media.transcode import get_transcode_manager as _get_tm
    from app.services.container import _make_hls_resolver as _make_hr

    _paths = {"ZUID720X": src720, "ZUID360X": src360}

    class _ZStack:
        def __init__(self):
            self.config = _types.SimpleNamespace(
                local_mode=True, auto_mode=False,
                cloud_download_limit_bytes=20 * 1024 * 1024)
            self.selector = None
            self.resolver = None

        async def resolve(self, row):
            from app.media.resolver import handle_from_mapping
            return handle_from_mapping(row)

        async def size(self, handle):
            p = _paths.get(str(handle.file_unique_id))
            return os.path.getsize(p) if p else None

        def open(self, handle):
            p = _paths.get(str(handle.file_unique_id))

            async def _g():
                with open(p, "rb") as fh:
                    while True:
                        c = fh.read(256 * 1024)
                        if not c:
                            break
                        yield c
            return _g()

    cache = _StreamCache(os.path.join(tmp, "stream_cache"))  # EMPTY
    hls_mgr = _get_tm(os.path.join(tmp, "transcode"))

    async def _access_engine(bot, user_id, payload_id=None, **kw):
        return _types.SimpleNamespace(authorized=True, reason="open",
                                      payload_id=payload_id)

    gw = _make_gw(db, stack=_ZStack(), listing_resolver=_make_lr(db),
                 access_check=_access_engine, bot_token=MAIN_TOKEN,
                 cache=cache)
    _ns_gw = _types.SimpleNamespace(_website_media_gateway=gw, db=db,
                                    logger=_logging.getLogger("payload-bot"))
    zdeps = _types.SimpleNamespace(
        db=db, bot_token=MAIN_TOKEN, media_gateway=gw,
        bot_ref=lambda: None, access_engine=_access_engine,
        network_tokens=None, hls_resolver=_make_hr(_ns_gw),
        hls_manager=hls_mgr)
    from app.web.site import pages as _pages
    _prev_factory = _pages._deps_factory
    _prev_we = await db.get_setting("website_enabled") or ""
    await db.set_setting("website_enabled", "1")
    _pages._deps_factory = lambda: zdeps

    cap: list = []

    class _ZCap(_logging.Handler):
        def emit(self, record):
            cap.append(record.getMessage())

    _lg = _logging.getLogger("payload-bot")
    _prev_lvl = _lg.level
    _lg.setLevel(_logging.INFO)  # the INFO telemetry must reach the handler
    _h = _ZCap()
    _lg.addHandler(_h)

    class _ZIssReq:
        def __init__(self, body):
            self._body = body
            self.cookies = {}
            self.headers = {"Content-Type": "application/json"}
            self.remote = "104.23.175.20"

        async def json(self):
            return self._body

    class _ZHlsReq:
        def __init__(self, token, path, referer="", cookies=None,
                     rng=""):
            self.match_info = {"token": token, "path": path}
            self.headers = {}
            if referer:
                self.headers["Referer"] = referer
            if rng:
                self.headers["Range"] = rng
            self.cookies = cookies or {}
            self.remote = "104.23.175.21"
            self.host = "shy-leaf-cac1.kyahuyaphirse.workers.dev"
            self.method = "GET"

    from app.web.site import stream as _stream
    from app.web.site.hls import handle_site_hls as _hls_handle
    from app.web.site.tokens import make_video_token_codec as _vcodec
    _vc = _vcodec(MAIN_TOKEN)

    async def _issue(opaque, fpk):
        return _json.loads((await _stream.handle_site_api_stream(
            _ZIssReq({"init_data": sign_init_data(MAIN_TOKEN, 8922807758),
                      "video_ref": _vc.encode_video_ref(opaque, fpk)}))).text)

    def _token_of(body):
        return str(body.get("hls_url") or "").split(
            "/site/hls/")[1].rsplit("/", 1)[0]

    WORKER_REF = ("https://shy-leaf-cac1.kyahuyaphirse.workers.dev/"
                  "site/payload/xxx/video/yyy")

    # ================= HLS (Z1-Z10) =====================================
    cap.clear()
    b720 = await _issue(opaque720, idx720)
    check("Z1 probe-unavailable VIDEO receives the HLS plan "
          "(source_available=yes)",
          b720.get("codec_verdict") == "transcode"
          and b720.get("codec_reason") == "probe_unavailable"
          and bool(b720.get("hls_url"))
          and any("WEBSITE_HLS_SOURCE" in m
                  and "source_available=yes" in m for m in cap),
          str(b720.get("unavailable_reason")))
    tok720 = _token_of(b720)

    # V26.2-bot42 (TASK C1): the master request is NEVER held open for the
    # transcoding — the FIRST request answers 503 hls_preparing (the
    # background job STARTS), the tree becomes READY, the NEXT request
    # serves the real master. This is the exact contract the player's
    # bounded ensureMasterReady poll implements.
    r = await _hls_handle(_ZHlsReq(tok720, "master.m3u8",
                                   referer=WORKER_REF), zdeps)
    b_prep = _json.loads(r.text) if r.text else {}
    check("Z2a first master request answers 503 hls_preparing (async "
          "preparation started; the request is NOT held open)",
          r.status == 503 and b_prep.get("error") == "hls_preparing"
          and any("WEBSITE_HLS_RESOLVE" in m
                  and "listing_resolved=yes" in m for m in cap)
          and any("WEBSITE_HLS_ENSURE" in m and "ok=no" in m
                  and "reason=hls_preparing" in m for m in cap),
          f"status={r.status} body={b_prep}")
    prep = await hls_mgr.wait_for_preparation("ZUID720X", timeout=240.0)
    check("Z2b the background preparation completes "
          "(HLS_PREPARE_START -> HLS_PREPARE_READY)",
          prep is not None and bool(prep.ok)
          and any("HLS_PREPARE_START" in m for m in cap)
          and any("HLS_PREPARE_READY" in m for m in cap),
          str(getattr(prep, "error", None)))
    r = await _hls_handle(_ZHlsReq(tok720, "master.m3u8",
                                   referer=WORKER_REF), zdeps)
    m720 = r.body.decode("utf-8", "replace") if r.status == 200 else ""
    check("Z2c the master serves 200 after preparation "
          "(ENSURE ok=yes + SERVE + REQUEST telemetry)",
          r.status == 200
          and any("WEBSITE_HLS_ENSURE" in m and "ok=yes" in m
                  and "master_exists=yes" in m for m in cap)
          and any("WEBSITE_HLS_SERVE" in m and "status=200" in m for m in cap)
          and any("WEBSITE_HLS_REQUEST" in m and "status=200" in m for m in cap),
          f"status={r.status}")

    renditions = _re.findall(r"^(\d+p)/index\.m3u8$", m720, _re.M)
    check("Z3 master 200 carries the REAL multi-rendition ladder "
          "(720p/480p/360p)", renditions == ["720p", "480p", "360p"],
          str(renditions))

    r4 = await _hls_handle(_ZHlsReq(tok720, "480p/index.m3u8",
                                    referer=WORKER_REF), zdeps)
    check("Z4 variant playlist 200", r4.status == 200
          and "#EXTINF" in r4.body.decode("utf-8", "replace"))

    seg = (_re.search(r"^(\d+p/seg\d+\.ts)$",
                      r4.body.decode("utf-8", "replace"), _re.M) or [None])[0]
    seg = (seg.group(1) if hasattr(seg, "group") else None) or "480p/seg00000.ts"
    r5 = await _hls_handle(_ZHlsReq(tok720, seg, referer=WORKER_REF),
                           zdeps)
    _hr_req = _ZHlsReq(tok720, seg, referer=WORKER_REF,
                       rng="bytes=0-99")
    _hr_req.method = "HEAD"  # HEAD: the 206 + Content-Range without a
                             # live aiohttp payload writer (same headers)
    r5b = await _hls_handle(_hr_req, zdeps)
    check("Z5 segment 200 + Range 206", r5.status == 200
          and r5b.status == 206
          and r5b.headers.get("Content-Range", "").startswith("bytes 0-99/"),
          f"200={r5.status} 206={r5b.status}")

    cap.clear()
    bnull = await _issue(opaquenull, idxnull)
    check("Z6 NO raw fallback for an unresolvable identity (honest refusal)",
          bnull.get("streamable") is False
          and bnull.get("unavailable_reason")
          == "media_identity_unresolvable"
          and not bnull.get("hls_url")
          and "stream_url" not in bnull
          and any("WEBSITE_STREAM_ISSUE_HLS_UNAVAILABLE" in m for m in cap)
          and not any("WEBSITE_PLAYER_FORMAT" in m for m in cap),
          str(bnull.get("unavailable_reason")))

    r7 = await _hls_handle(_ZHlsReq("garbage", "master.m3u8",
                                    referer=WORKER_REF), zdeps)
    check("Z7 wrong token => 401", r7.status == 401)

    from app.media.streamtokens import make_stream_token_codec as _stc
    from app.web.site.session import make_site_session_codec as _sessc
    _sc = _stc(MAIN_TOKEN)
    _sess = _sessc(MAIN_TOKEN)
    tok_a = _sc.encode_stream_token(111111111, "x", 42)
    r8 = await _hls_handle(_ZHlsReq(
        tok_a, "master.m3u8", referer=WORKER_REF,
        cookies={"endie_site": _sess.issue_session(222222222,
                                                   username="b")}), zdeps)
    check("Z8 wrong user (cross-user replay) => 403 wrong_user",
          r8.status == 403
          and _json.loads(r8.text).get("error") == "wrong_user")

    await db.set_setting("prot_v3_anti_leech", "1")
    r9 = await _hls_handle(_ZHlsReq(
        tok720, "master.m3u8",
        referer="https://evil.example/hotlink.html"), zdeps)
    check("Z9 foreign Referer => 403 anti_leech (Anti-Leech NOT weakened)",
          r9.status == 403
          and _json.loads(r9.text).get("error") == "anti_leech")
    await db.set_setting("prot_v3_anti_leech", "0")

    cap.clear()
    # Z10 runs WITH Anti-Leech ON (the production posture — the toggle
    # defaults ON; a legit Worker referer must still pass).
    await db.set_setting("prot_v3_anti_leech", "1")
    r10 = await _hls_handle(_ZHlsReq(tok720, "master.m3u8",
                                     referer=WORKER_REF), zdeps)
    check("Z10 the REAL production Worker Referer serves 200 "
          "(Anti-Leech ON, proxy-aware)",
          r10.status == 200
          and any("WEBSITE_ANTI_LEECH_ALLOWED" in m
                  and "shy-leaf-cac1.kyahuyaphirse.workers.dev" in m
                  for m in cap),
          f"status={r10.status}")
    await db.set_setting("prot_v3_anti_leech", "0")

    # ================= QUALITY (Z11-Z15) ================================
    check("Z11 the 720p ladder is the REAL multi-rendition set",
          renditions == ["720p", "480p", "360p"]
          and all(f"{rid}/index.m3u8" in m720 for rid in renditions))

    from app.web.site import html as _html
    _hsrc = open("app/web/site/html.py").read()
    check("Z12 Quality is visible only from REAL master renditions "
          "(no fabricated entries)",
          "function parseMasterRenditions" in _hsrc
          and "ctl.qBtn.hidden = false" in _hsrc
          and len(renditions) >= 2)

    ok13 = True
    for rid in renditions:
        rv = await _hls_handle(_ZHlsReq(tok720, f"{rid}/index.m3u8",
                                        referer=WORKER_REF), zdeps)
        ok13 = ok13 and rv.status == 200
    check("Z13 every actual rendition switch target resolves (3 variants)",
          ok13 and "function switchNativeVariant" in _hsrc
          and "variantUrl(" in _hsrc)

    check("Z14 QUALITY_CHANGE carries the position and the switch "
          "restores currentTime",
          "position_s: t" in _hsrc and "el.currentTime = t" in _hsrc
          and 'QUALITY_CHANGE' in _hsrc)

    b360 = await _issue(opaque360, idx360)
    tok360 = _token_of(b360)
    r15p = await _hls_handle(_ZHlsReq(tok360, "master.m3u8",
                                      referer=WORKER_REF), zdeps)
    await hls_mgr.wait_for_preparation("ZUID360X", timeout=240.0)
    r15 = await _hls_handle(_ZHlsReq(tok360, "master.m3u8",
                                     referer=WORKER_REF), zdeps)
    check("Z15a the single-rendition source also prepares asynchronously "
          "(503 hls_preparing first)",
          r15p.status == 503
          and _json.loads(r15p.text).get("error") == "hls_preparing",
          f"status={r15p.status}")
    m360 = r15.body.decode("utf-8", "replace") if r15.status == 200 else ""
    rend360 = _re.findall(r"^(\d+p)/index\.m3u8$", m360, _re.M)
    check("Z15 a single-rendition master keeps Quality hidden",
          r15.status == 200 and len(rend360) == 1
          and "renditions.length <= 1" in _hsrc,
          str(rend360))

    # ================= PACKAGE + SINGLE (Z16-Z32) =======================
    from app.presentation.telegram import website_ui as _wui

    sent = []

    async def _edit(q, text, reply_markup=None, **kw):
        sent.append((text, reply_markup))
        return True

    async def _send(bot, chat_id, text, reply_markup=None, **kw):
        sent.append((text, reply_markup))
        return True

    async def _answer(q, text=None, show_alert=False):
        return True

    async def _log_action(*a, **kw):
        return True

    async def _rpl(link):
        return None

    wdeps = _types.SimpleNamespace(db=db, safe_edit_text=_edit,
                                   safe_send_text=_send,
                                   safe_answer_callback=_answer,
                                   log_admin_action=_log_action,
                                   resolve_payload_link=_rpl)
    upd = FakeUpdate()

    async def _zmk_file(mid, name):
        await db.conn.execute(
            "INSERT INTO indexed_files(channel_id, message_id, file_id, "
            "file_unique_id, media_type, file_name, file_size, upload_date) "
            "VALUES (?, ?, ?, ?, 'video', ?, 1000, ?)",
            (CH, mid, f"ZFID{mid}", f"ZFUID{mid}", name, now))
        await db.conn.commit()
        cur = await db.conn.execute(
            "SELECT id FROM indexed_files WHERE channel_id=? AND "
            "message_id=?", (CH, mid))
        return int((await cur.fetchone())[0])

    zidx1 = await _zmk_file(9101, "zpart1.mp4")
    zidx2 = await _zmk_file(9102, "zpart2.mp4")
    zidx3 = await _zmk_file(9103, "zpart3.mp4")
    zidx4 = await _zmk_file(9104, "zsingle_standalone.mp4")

    # Two packages + a THIRD fresh one, each with its OWN wrapper
    # display_name (BOT-43: the Z24 batch needs TWO genuinely-ADDED
    # packages — ab11cd is already listed after Z21, so a selection of
    # all three yields added=[bb22ef, cb33fg] and kept=[ab11cd]).
    zidx5 = await _zmk_file(9105, "zpart5.mp4")
    for code, dn, mids, fidx in (
            ("ab11cd", "Zeta Pack One", (9101,), zidx1),
            ("bb22ef", "Zeta Pack Two", (9102, 9103), zidx2),
            ("cd44ef", "Zeta Pack Three", (9105,), zidx5)):
        await db.conn.execute(
            "INSERT INTO collections(collection_id, channel_id, file_count, "
            "created_at) VALUES (?, ?, ?, ?)",
            (code, CH, len(mids), now))
        for pos, mid in enumerate(mids, start=1):
            await db.conn.execute(
                "INSERT INTO collection_items(collection_id, channel_id, "
                "message_id, position) VALUES (?, ?, ?, ?)",
                (code, CH, mid, pos))
        first_idx = fidx
        await db.conn.execute(
            "INSERT INTO payloads(payload, index_id, status, access_policy, "
            "display_name, created_at, updated_at) VALUES "
            "(?, ?, 'active', 'OPEN', ?, ?, ?)",
            (f"c{code}", first_idx, dn, now, now))
    # A standalone SINGLE payload with its own display_name.
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "display_name, created_at, updated_at) VALUES "
        "(?, ?, 'active', 'OPEN', 'Zeta Single One', ?, ?)",
        ("zsingle111", zidx4, now, now))
    await db.conn.commit()

    from app.web.site.service import make_website_service as _wsvc
    wsvc = _wsvc(db)

    # ---- Z16-Z20: the SINGLE-package picker flow (the title bug) ------
    sent.clear()
    cap.clear()
    ctx = FakeContext()
    ctx.user_data = {}
    ctx.bot = _types.SimpleNamespace()
    await _wui.website_package_picker(upd, ctx, wdeps, page=1)
    pk_kb = sent[-1][1]
    pk_flat = [b for row in pk_kb.inline_keyboard for b in row]
    check("Z16 the package picker shows the HUMAN package title",
          any("Zeta Pack One" in (b.text or "") for b in pk_flat))

    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:pktog:ab11cd"), ctx, wdeps)
    sel_state = ctx.user_data.get(_wui.WSITE_PKG_PICK_KEY) or {}
    check("Z17 selection is server-side + WEBSITE_PACKAGE_SELECT telemetry",
          sel_state.get("selected") == ["ab11cd"]
          and any("WEBSITE_PACKAGE_SELECT" in m
                  and "canonical_id=ab11cd" in m for m in cap))

    sent.clear()
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkcont"), ctx,
                                     wdeps)
    wiz = ctx.user_data.get(_wui.WSITE_WIZARD_KEY) or {}
    check("Z18 Continue (one selection) starts the prefilled single wizard",
          wiz.get("prefill_link") == "cab11cd"
          and wiz.get("prefill_kind") == "collection")

    canon = await wsvc.resolve_canonical_for_wizard("cab11cd")
    check("Z19 the canonical resolver keeps the collection identity",
          canon and canon["kind"] == "collection"
          and canon["collection_id"] == "ab11cd")

    sent.clear()
    cap.clear()
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wskip"), ctx,
                                     wdeps)
    preview_text = "\n".join(t or "" for t, _ in sent)
    _title_line = next((ln for ln in preview_text.splitlines()
                        if ln.startswith("Title:")), "")
    check("Z20 THE TITLE FIX: the preview shows the package's OWN "
          "display_name (never the raw code)",
          _title_line == "Title: Zeta Pack One"
          and "Zeta Pack One" in preview_text
          and any("WEBSITE_PACKAGE_RESOLVE" in m
                  and "source_display_name=Zeta Pack One" in m for m in cap),
          repr(_title_line))

    sent.clear()
    cap.clear()
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wpub"), ctx,
                                     wdeps)
    zlisting1 = await db.find_website_payload_for_canonical(
        collection_id="ab11cd")
    check("Z21 publish creates the listing with the package's OWN title",
          zlisting1 is not None and int(zlisting1["published"]) == 1
          and str(zlisting1["title"] or "") == "Zeta Pack One"
          and any("WEBSITE_PACKAGE_PUBLISH_COMPLETE" in m for m in cap))
    check("Z22 the DB listing title is the human display_name",
          zlisting1 is not None
          and str(zlisting1["title"] or "") == "Zeta Pack One")
    detail1 = await wsvc.get_listing_detail(str(zlisting1["opaque_id"]))
    check("Z23 the Website displays the human title (eff_title)",
          str(detail1.get("eff_title") or "") == "Zeta Pack One")

    # ---- Z24/Z25: the MULTI-package batch flow ------------------------
    sent.clear()
    cap.clear()
    ctx2 = FakeContext()
    ctx2.user_data = {}
    ctx2.bot = ctx.bot
    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:pktog:ab11cd"), ctx2, wdeps)
    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:pktog:bb22ef"), ctx2, wdeps)
    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:pktog:cd44ef"), ctx2, wdeps)
    sel2 = ctx2.user_data.get(_wui.WSITE_PKG_PICK_KEY) or {}
    check("Z24a three packages selected (count + telemetry)",
          sorted(sel2.get("selected") or [])
          == ["ab11cd", "bb22ef", "cd44ef"]
          and any("WEBSITE_PACKAGE_SELECT" in m
                  and "selected_count=3" in m for m in cap))
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkcont"), ctx2,
                                     wdeps)
    sent.clear()
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wskip"), ctx2,
                                     wdeps)
    batch_preview = "\n".join(t or "" for t, _ in sent)
    check("Z24b the batch preview shows every ADDED package with its OWN "
          "title (the kept one needs no wizard)",
          "Zeta Pack Two" in batch_preview
          and "Zeta Pack Three" in batch_preview
          and any("WEBSITE_PACKAGE_PREVIEW" in m for m in cap),
          repr(batch_preview[:400]))
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wpub"), ctx2,
                                     wdeps)
    zl_a = await db.find_website_payload_for_canonical(collection_id="ab11cd")
    zl_b = await db.find_website_payload_for_canonical(collection_id="bb22ef")
    zl_c = await db.find_website_payload_for_canonical(collection_id="cd44ef")
    check("Z24c the selected packages become their own canonical "
          "listings with their OWN titles",
          zl_a is not None and zl_b is not None and zl_c is not None
          and str(zl_a["title"] or "") == "Zeta Pack One"
          and str(zl_b["title"] or "") == "Zeta Pack Two"
          and str(zl_c["title"] or "") == "Zeta Pack Three"
          and zl_a["opaque_id"] != zl_b["opaque_id"])

    cur = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM website_payloads WHERE "
        "collection_id IN ('ab11cd','bb22ef','cd44ef')")
    n_before = int((await cur.fetchone())["c"])
    sent.clear()
    cap.clear()
    ctx3 = FakeContext()
    ctx3.user_data = {}
    ctx3.bot = ctx.bot
    # BOT-43: re-selecting EXACTLY the listed set is the honest NO-OP
    # save — added=0, removed=0, kept=3; NO wizard starts (the old
    # re-publish-then-skip shape is gone; dedup is now structural).
    for _zcode in ("ab11cd", "bb22ef", "cd44ef"):
        await _wui.handle_wsite_callback(
            _fake_cb(upd, f"wsite:pktog:{_zcode}"), ctx3, wdeps)
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkcont"), ctx3,
                                     wdeps)
    cur = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM website_payloads WHERE "
        "collection_id IN ('ab11cd','bb22ef','cd44ef')")
    n_after = int((await cur.fetchone())["c"])
    check("Z25 re-selecting the listed set is the honest NO-OP save "
          "(kept=3, no wizard, no duplicates)",
          n_before == 3 and n_after == 3
          and any("WEBSITE_PACKAGE_SELECTION_SAVE" in m
                  and "added_count=0 removed_count=0 kept_count=3" in m
                  for m in cap)
          and any("already matches the Website" in (t or "")
                  for t, _ in sent))

    # ---- Z26: stale/unauthorized selection rejection -------------------
    sent.clear()
    ctx4 = FakeContext()
    ctx4.user_data = {}
    ctx4.bot = ctx.bot
    await _wui.handle_wsite_callback(
        _fake_cb(upd, "wsite:pktog:dead404"), ctx4, wdeps)
    sel4 = ctx4.user_data.get(_wui.WSITE_PKG_PICK_KEY) or {}
    check("Z26a a stale package code never enters the selection",
          "dead404" not in (sel4.get("selected") or []))
    _wui._pkg_sel(ctx4)["selected"] = ["dead404"]
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkcont"), ctx4,
                                     wdeps)
    sel4b = ctx4.user_data.get(_wui.WSITE_PKG_PICK_KEY) or {}
    check("Z26b pkcont rejects a stale selection honestly (no wizard)",
          (sel4b.get("selected") or []) == []
          and not ctx4.user_data.get(_wui.WSITE_WIZARD_KEY))

    # ---- Z27-Z32: the SINGLE payload flow ------------------------------
    sent.clear()
    cap.clear()
    ctx5 = FakeContext()
    ctx5.user_data = {}
    ctx5.bot = ctx.bot
    await _wui.website_single_picker(upd, ctx5, wdeps, page=1)
    sp_kb = sent[-1][1]
    sp_flat = [b for row in sp_kb.inline_keyboard for b in row]
    check("Z27 the single picker shows the payload display_name "
          "(collection wrappers excluded)",
          any("Zeta Single One" in (b.text or "") for b in sp_flat)
          and not any("Zeta Pack One" in (b.text or "") for b in sp_flat))
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload='zsingle111'")
    zspid = int((await cur.fetchone())[0])
    await _wui.handle_wsite_callback(
        _fake_cb(upd, f"wsite:spick:{zspid}"), ctx5, wdeps)
    wiz5 = ctx5.user_data.get(_wui.WSITE_WIZARD_KEY) or {}
    check("Z28 the single canonical resolves with its display_name",
          wiz5.get("prefill_link") == "zsingle111"
          and any("WEBSITE_SINGLE_SELECT" in m
                  and "source_display_name=Zeta Single One" in m
                  for m in cap))
    sent.clear()
    cap.clear()
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wskip"), ctx5,
                                     wdeps)
    single_preview = "\n".join(t or "" for t, _ in sent)
    check("Z29 the single preview shows the payload's own title",
          "Zeta Single One" in single_preview
          and any("WEBSITE_SINGLE_PREVIEW" in m for m in cap))
    sent.clear()
    cap.clear()
    await _wui.handle_wsite_callback(_fake_cb(upd, "wsite:wpub"), ctx5,
                                     wdeps)
    zsingle = await db.find_website_payload_for_canonical(payload_id=zspid)
    check("Z30 the single DB listing title is the payload display_name",
          zsingle is not None
          and str(zsingle["title"] or "") == "Zeta Single One"
          and any("WEBSITE_SINGLE_PUBLISH_COMPLETE" in m
                  and "final_title=Zeta Single One" in m for m in cap))
    detail5 = await wsvc.get_listing_detail(str(zsingle["opaque_id"]))
    check("Z31 the Website displays the single's canonical title",
          str(detail5.get("eff_title") or "") == "Zeta Single One")
    from app.core.payload.service import is_collection_link as _iscl
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload IN ('cab11cd','cbb22ef')")
    wrapper_ids = {int(r["id"]) for r in await cur.fetchall()}
    sp_cbs = [str(b.callback_data or "") for b in sp_flat]
    sp_ids = {int(c.rsplit(":", 1)[1]) for c in sp_cbs
              if c.startswith("wsite:spick:")}
    check("Z32 collection wrapper payloads are excluded from the singles "
          "picker (canonical predicate, never a name filter)",
          wrapper_ids and not (wrapper_ids & sp_ids)
          and all(not _iscl(pc) for pc in
                  [str(r["payload"]) for r in
                   (await db.list_payloads(limit=200, offset=0))
                   if int(r["id"]) in sp_ids]))

    # ---- restore --------------------------------------------------------
    _lg.removeHandler(_h)
    _lg.setLevel(_prev_lvl)
    _pages._deps_factory = _prev_factory
    await db.set_setting("website_enabled", _prev_we or "false")


# ===========================================================================
# V26.2 (bot-41) — §16-§24 Force-Join progressive batching
# ===========================================================================
async def section_aa(ns, db):
    """[AA] V26.2 — bot-41 §16-§24: per-gate progressive Force-Join batching.

    The operator's contract: pressing Play on ONE gated video shows ONLY the
    current configured batch; after a successful Verify the NEXT gated video
    shows the NEXT batch; completed channels never reappear; the state
    survives refresh / reopen / restart; future batches are NEVER delivered;
    the admin batch size is authoritative; Website and FDB share the ONE
    global requirement state without resetting each other.
    """
    print("\n[AA] V26.2 — Force-Join progressive batching (per-gate pins)")
    UID = 88100
    UID2 = 88101
    UID3 = 88102
    # Clean channel slate (AA runs last; earlier sections' FJ state is
    # per-user so nothing else is affected).
    for row in await db.list_force_channels():
        await db.remove_force_channel(int(row["channel_id"]))
    CHS = [-(2000000 + i) for i in range(1, 11)]  # 10 fresh channels
    for i, cid in enumerate(CHS):
        await db.add_force_channel(cid, f"aachan{i + 1}")
    await db.set_setting("force_join_enabled", "1")
    await db.set_setting("fj_mode", "fixed_order")
    await db.set_setting("fj_batch_size", "2")
    svc = _make_fj(db)
    bot = _FakeFJBot()

    def _ids(view):
        return [int(r["channel_id"]) for r in view.get("channels") or []]

    # AA1 — the FIRST gated video exposes ONLY the current batch (2 of 10).
    with _LogCap() as cap1:
        v1 = await svc.fj_gate_view(UID, "w|l1|1", bot=bot)
    check("AA1 first gated video exposes ONLY the current batch (2)",
          _ids(v1) == CHS[:2] and v1["satisfied"] is False,
          f"got {_ids(v1)}")
    check("AA1b FJ_PLAY_GATE telemetry at pin time",
          cap1.has("FJ_PLAY_GATE") and cap1.has("FJ_STATE"))

    # AA2 — the future 8 channels are ABSENT from the response payload.
    check("AA2 future 8 channels absent from the gate view payload",
          not (set(_ids(v1)) & set(CHS[2:])) and len(_ids(v1)) == 2)

    # AA3 — a successful Verify of the first batch SATISFIES that gate.
    bot.joined |= set(CHS[:2])
    v1b = await svc.fj_gate_view(UID, "w|l1|1", bot=bot)
    check("AA3 batch-1 verify satisfies the gate (progressive unlock)",
          v1b["satisfied"] is True and _ids(v1b) == [])

    # AA4 — the NEXT gated video exposes only channels 3-4.
    v2 = await svc.fj_gate_view(UID, "w|l1|2", bot=bot)
    check("AA4 next video exposes only channels 3-4",
          _ids(v2) == CHS[2:4], f"got {_ids(v2)}")

    # AA5 — the third video (after verify 2) exposes only 5-6.
    bot.joined |= set(CHS[2:4])
    v2b = await svc.fj_gate_view(UID, "w|l1|2", bot=bot)
    check("AA5a batch-2 verify satisfies gate 2",
          v2b["satisfied"] is True)
    v3 = await svc.fj_gate_view(UID, "w|l1|3", bot=bot)
    check("AA5b third video exposes only channels 5-6",
          _ids(v3) == CHS[4:6], f"got {_ids(v3)}")

    # AA6 — completed channels NEVER return (reopen video 1 -> no channels).
    v1c = await svc.fj_gate_view(UID, "w|l1|1", bot=bot)
    check("AA6a completed channels never reappear (video 1 reopen)",
          v1c["satisfied"] is True and _ids(v1c) == []
          and not (set(_ids(v3)) & set(CHS[:4])))

    # AA7 — refresh (re-evaluation) preserves the same pending batch.
    v3b = await svc.fj_gate_view(UID, "w|l1|3", bot=bot)
    check("AA7 refresh preserves the pending batch (same 5-6)",
          _ids(v3b) == CHS[4:6])

    # AA8 — a simulated process RESTART preserves the pending batch.
    svc_r = _make_fj(db)
    v3c = await svc_r.fj_gate_view(UID, "w|l1|3", bot=bot)
    check("AA8 restart preserves the pending batch (same 5-6)",
          _ids(v3c) == CHS[4:6])

    # AA9 — reopening a previous video does NOT reset the cursor: a NEW
    # video still sees the SAME pending batch (5-6).
    v4 = await svc.fj_gate_view(UID, "w|l1|4", bot=bot)
    check("AA9 reopening a previous video does not reset the cursor",
          _ids(v4) == CHS[4:6], f"got {_ids(v4)}")

    # AA10 — progressive_random: the sequence is generated ONCE per identity.
    await db.set_setting("fj_mode", "progressive_random")
    svc2 = _make_fj(db)
    await svc2.fj_gate_view(UID2, "w|rl|1", bot=bot)
    r2 = await db.get_fj_progress_row(UID2)
    import json as _json_aa
    ord2 = _json_aa.loads(r2["channel_order"])
    check("AA10 progressive_random sequence generated ONCE (a permutation)",
          sorted(ord2) == sorted(CHS), f"got {ord2}")
    await svc2.fj_gate_view(UID2, "w|rl|2", bot=bot)
    r2b = await db.get_fj_progress_row(UID2)
    check("AA10b the random order never reshuffles on the next gate",
          _json_aa.loads(r2b["channel_order"]) == ord2)
    await db.set_setting("fj_mode", "fixed_order")

    # AA11 — fixed order remains fixed (the batch slices follow the
    # persisted admin order — v1/v2/v3 above ARE the proof; pin the order).
    row_u1 = await db.get_fj_progress_row(UID)
    ord_u1 = _json_aa.loads(row_u1["channel_order"])
    check("AA11 fixed order remains fixed (persisted admin order)",
          ord_u1 == CHS)

    # AA12 — a duplicate active batch is IMPOSSIBLE (one progress row per
    # user; one presentation row per gate).
    rows_u = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM fj_progress WHERE user_id=?", (UID,))
    check("AA12a one global requirement row per user",
          int((await rows_u.fetchone())[0]) == 1)
    rows_g = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM fj_gate_presentations WHERE user_id=? "
        "AND gate_key='w|l1|1'", (UID,))
    check("AA12b one presentation row per gate (no duplicate active batch)",
          int((await rows_g.fetchone())[0]) == 1)

    # AA13 — a requirement identity change follows the EXISTING deterministic
    # rules: the stale pin re-arms; the new pending batch is derived from
    # the new config (live membership preserved — 1-4 still completed).
    id_before = await svc.force_join_requirement_identity()
    await db.add_force_channel(-2000099, "aanew")
    id_after = await svc.force_join_requirement_identity()
    check("AA13a adding a channel changes the requirement identity",
          id_after != id_before)
    v3d = await svc.fj_gate_view(UID, "w|l1|3", bot=bot)
    check("AA13b the stale pin re-arms to the NEW deterministic pending "
          "batch (completed 1-4 never re-asked)",
          _ids(v3d) == CHS[4:6] and not (set(_ids(v3d)) & set(CHS[:4])),
          f"got {_ids(v3d)}")
    await db.remove_force_channel(-2000099)
    check("AA13c removing it restores the prior identity",
          await svc.force_join_requirement_identity() == id_before)

    # AA14 — the ADMIN batch size is authoritative (3 -> batches of 3).
    # (bot3: a SEPARATE membership fake — UID3 is a DIFFERENT Telegram
    # user; the shared single-membership fake must not leak UID's joins.)
    await db.set_setting("fj_batch_size", "3")
    svc3 = _make_fj(db)
    bot3 = _FakeFJBot()
    w1 = await svc3.fj_gate_view(UID3, "w|b3|1", bot=bot3)
    check("AA14 admin batch_size=3 is authoritative (first gate = 3)",
          _ids(w1) == CHS[:3], f"got {_ids(w1)}")

    # AA15 — FDB first gated file exposes ONLY the current batch (the same
    # service call the Access Engine's gate-key path makes — "b|p|{id}").
    fdb1 = await svc3.fj_gate_unjoined(UID3, "b|p|501", payload_id=501,
                                       bot=bot3)
    check("AA15 FDB first gated file exposes only the current batch",
          [int(r["channel_id"]) for r in fdb1] == _ids(w1))

    # AA16 — the FDB NEXT gated file advances correctly (batch 2 of 3).
    bot3.joined |= set(_ids(w1))
    fdb1b = await svc3.fj_gate_unjoined(UID3, "b|p|501", payload_id=501,
                                        bot=bot3)
    check("AA16a FDB batch-1 verify delivers the first gated file",
          fdb1b == [])
    fdb2 = await svc3.fj_gate_unjoined(UID3, "b|p|502", payload_id=502,
                                       bot=bot3)
    _fdb2_ids = [int(r["channel_id"]) for r in fdb2]
    check("AA16b FDB next gated file presents batch 2 (next 3, no repeats)",
          _fdb2_ids == CHS[3:6], f"got {_fdb2_ids}")

    # AA17 — Website and FDB share the ONE requirement state: a Website
    # verification advances the shared cursor (never resets the FDB to
    # batch 1). A website gate pins the SAME pending batch while pending,
    # then completes it, and the FDB's NEXT gated file continues at batch 3.
    w_b2 = await svc3.fj_gate_view(UID3, "w|web|1", bot=bot3)
    check("AA17a the website gate pins the SAME shared pending batch",
          _ids(w_b2) == _fdb2_ids, f"got {_ids(w_b2)}")
    bot3.joined |= set(_fdb2_ids)
    w_b2b = await svc3.fj_gate_view(UID3, "w|web|1", bot=bot3)
    check("AA17b website verify of the shared batch satisfies the gate",
          w_b2b["satisfied"] is True and _ids(w_b2b) == [])
    fdb3 = await svc3.fj_gate_unjoined(UID3, "b|p|503", payload_id=503,
                                       bot=bot3)
    _fdb3_ids = [int(r["channel_id"]) for r in fdb3]
    check("AA17c FDB continues at batch 3 (website verify did NOT reset it)",
          _fdb3_ids == CHS[6:9], f"got {_fdb3_ids}")

    # AA18 — a client-forged gate key CANNOT override the server cursor: it
    # pins the CURRENT pending batch (server-derived), never a chosen one.
    evil = await svc3.fj_gate_view(UID3, "w|evil|999", bot=bot3)
    check("AA18 client gate-key cannot override the server cursor",
          _ids(evil) == _fdb3_ids, f"got {_ids(evil)}")

    # AA22 — (before the completion cleanup) different payloads keep
    # independent presentation rows.
    for key in ("b|p|501", "b|p|502", "b|p|503"):
        cur = await db.conn.execute(
            "SELECT pinned_batch FROM fj_gate_presentations WHERE user_id=? "
            "AND gate_key=?", (UID3, key))
        row = await cur.fetchone()
        check(f"AA22 independent presentation row kept per payload "
              f"({key})", row is not None)

    # AA19 — nothing client-side can fabricate completion (fail-closed).
    bot_cold = _FakeFJBot()  # a cold user: nothing joined
    cold = await svc3.fj_gate_view(88199, "w|cold|1", bot=bot_cold)
    check("AA19 client completed_channels cannot override server state",
          cold["satisfied"] is False and len(_ids(cold)) == 3)
    nonly = await svc3.fj_gate_view(88199, "w|cold|1", bot=None)
    check("AA19b bot=None fails CLOSED (never a fabricated ALLOW)",
          nonly["satisfied"] is False)

    # AA20 — future batches never leak from ANY response (forged keys too):
    # only the channels of batches 1-3 (9 of 10) were EVER delivered — the
    # last channel belongs to a future batch nobody has seen.
    seen = set(_ids(w1)) | set(_fdb2_ids) | set(_fdb3_ids) | set(_ids(evil))
    check("AA20 future batch channels never leak (all responses)",
          not (seen & set(CHS[9:])) and seen == set(CHS[:9]),
          f"leaked {seen & set(CHS[9:])}")

    # AA21 — the FINAL batch emits FJ_COMPLETE; afterwards no gate at all.
    bot3.joined |= set(CHS)  # everything joined
    with _LogCap() as cap_done:
        done = await svc3.fj_gate_view(UID3, "w|b3|9", bot=bot3)
    check("AA21a the final batch emits FJ_COMPLETE",
          cap_done.has("FJ_COMPLETE"))
    check("AA21b completed payload requires no further FJ",
          done["satisfied"] is True and _ids(done) == [])
    after = await svc3.fj_gate_view(UID3, "w|b3|1", bot=bot3)
    check("AA21c previously-gated video 1 needs no further FJ",
          after["satisfied"] is True)

    # AA23 — different users have independent state.
    cur = await db.conn.execute(
        "SELECT COUNT(DISTINCT user_id) AS c FROM fj_gate_presentations")
    distinct = int((await cur.fetchone())[0])
    check("AA23 different users have independent state",
          distinct >= 2, f"got {distinct}")

    # AA24 — show_all mode ALSO obeys the configured batch size at the
    # gate (§19: never render all future channels in the current response).
    await db.set_setting("fj_mode", "show_all")
    await db.set_setting("fj_batch_size", "2")
    svc4 = _make_fj(db)
    sa = await svc4.fj_gate_view(88198, "w|sa|1", bot=bot_cold)
    check("AA24 show_all obeys the configured batch size (2 of 10)",
          len(_ids(sa)) == 2, f"got {len(_ids(sa))}")
    # restore the suite's defaults
    await db.set_setting("fj_mode", "fixed_order")
    await db.set_setting("fj_batch_size", "2")


# ===========================================================================
# V26.2 (bot-41) — §3-§6 HLS wiring root cause + safe identity repair
# ===========================================================================
async def section_bb(ns, db):
    """[BB] V26.2 — bot-41 root causes: the HLS facade-shape resolver + the
    guarded media-identity repair.

    bot-41 evidence: WEBSITE_STREAM_ISSUE_OK → WEBSITE_HLS_SOURCE
    file_unique_id=- source_available=no → STREAM_ISSUE_HLS_UNAVAILABLE
    media_identity_unresolvable (file_pk=997 AND 1172). The V26.1 fix
    correctly refused to mint a doomed URL — the remaining production
    defect was the RESOLVER WIRING: ns._website_media_gateway is a
    zero-arg FACADE FUNCTION in the real runtime (the issuance path
    tolerates both shapes; the HLS resolver required the singleton shape
    and returned None for EVERY file, identity intact).
    """
    print("\n[BB] V26.2 — HLS facade resolver + identity repair")
    import types as _types
    import logging as _logging
    import tempfile as _tempfile

    MAIN_TOKEN = ns.BOT_TOKEN
    CH = -1004460709091
    now = datetime.now(timezone.utc).isoformat()
    tmp = _tempfile.mkdtemp(prefix="bot41_bb_")

    async def _bbfile(mid, name, fuid):
        await db.conn.execute(
            "INSERT INTO indexed_files(channel_id, message_id, file_id, "
            "file_unique_id, media_type, file_name, file_size, upload_date, "
            "mime_type) VALUES (?, ?, ?, ?, 'video', ?, 400000, ?, "
            "'video/x-matroska')",
            (CH, mid, f"FID{mid}", fuid, name, now))
        await db.conn.commit()
        cur = await db.conn.execute(
            "SELECT id FROM indexed_files WHERE channel_id=? AND "
            "message_id=?", (CH, mid))
        return int((await cur.fetchone())[0])

    # the bot-37-proven identity shape: file_pk=997, AgADyB8AAnV00FA
    idx997 = await _bbfile(9201, "video_997.mp4", "AgADyB8AAnV00FA")
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "created_at, updated_at) VALUES ('bbplay', ?, 'active', 'OPEN', "
        "?, ?)", (idx997, now, now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload='bbplay'")
    pid = int((await cur.fetchone())[0])
    await db.create_website_payload(payload_id=pid, title="BB Play 997",
                                    published=1, created_by=1)
    listing = await db.find_website_payload_for_canonical(payload_id=pid)
    opaque = str(listing["opaque_id"])

    from app.media.streamcache import StreamCache as _StreamCache
    from app.media.gateway import make_media_gateway as _make_gw
    from app.web.site.stream import make_listing_resolver as _make_lr
    from app.services.container import _make_hls_resolver as _make_hr

    async def _access_engine(bot, user_id, payload_id=None, **kw):
        return _types.SimpleNamespace(authorized=True, reason="open",
                                      payload_id=payload_id)

    gw = _make_gw(db, stack=None, listing_resolver=_make_lr(db),
                  access_check=_access_engine, bot_token=MAIN_TOKEN,
                  cache=_StreamCache(os.path.join(tmp, "cache")))

    # BB1 — THE PRODUCTION SHAPE: ns._website_media_gateway is a zero-arg
    #       FACADE FUNCTION. The V26.1 resolver returned None for EVERY
    #       file in this wiring (the bot-41 signature); V26.2 resolves.
    ns_prod = _types.SimpleNamespace(
        _website_media_gateway=lambda: gw, db=db,
        logger=_logging.getLogger("payload-bot"))
    resolver_prod = _make_hr(ns_prod)
    info_prod = await resolver_prod(opaque, idx997)
    check("BB1 production FACADE shape resolves (bot-41 root cause fixed)",
          bool(info_prod and info_prod.get("file_unique_id")
               == "AgADyB8AAnV00FA"
               and callable(info_prod.get("source_path_fn"))),
          f"got {info_prod and info_prod.get('file_unique_id')}")

    # BB2 — the singleton shape still resolves (legacy/test wiring).
    ns_test = _types.SimpleNamespace(_website_media_gateway=gw, db=db,
                                     logger=_logging.getLogger("payload-bot"))
    resolver_test = _make_hr(ns_test)
    info_test = await resolver_test(opaque, idx997)
    check("BB2 singleton gateway shape still resolves",
          bool(info_test and info_test.get("file_unique_id")
               == "AgADyB8AAnV00FA"))

    # BB3 — a broken facade (raises) fails CLOSED (honest None).
    def _raising_facade():
        raise RuntimeError("boom")

    ns_broken = _types.SimpleNamespace(
        _website_media_gateway=_raising_facade,
        db=db, logger=_logging.getLogger("payload-bot"))
    resolver_broken = _make_hr(ns_broken)
    info_broken = await resolver_broken(opaque, idx997)
    check("BB3 a raising facade fails closed (honest None)",
          info_broken is None)

    # BB4 — the issuance refusal reason is now CLASSIFIED: an unwired
    #       gateway is hls_resolver_unwired, a NULL identity stays
    #       media_identity_unresolvable (never conflated again).
    cap: list = []

    class _BBCap(_logging.Handler):
        def emit(self, record):
            cap.append(record.getMessage())

    _lg = _logging.getLogger("payload-bot")
    _prev_lvl = _lg.level
    _lg.setLevel(_logging.INFO)
    _h = _BBCap()
    _lg.addHandler(_h)
    zdeps = _types.SimpleNamespace(
        db=db, bot_token=MAIN_TOKEN, media_gateway=gw,
        bot_ref=lambda: None, access_engine=_access_engine,
        network_tokens=None, hls_resolver=resolver_prod)
    from app.web.site import pages as _pages
    from app.web.site import stream as _stream_mod
    _prev_factory = _pages._deps_factory
    _prev_we = await db.get_setting("website_enabled") or ""
    await db.set_setting("website_enabled", "1")
    _pages._deps_factory = lambda: zdeps
    try:
        # NULL identity row -> media_identity_unresolvable (classified)
        idxnull = await _bbfile(9202, "video_null.mp4", None)
        await db.conn.execute(
            "INSERT INTO payloads(payload, index_id, status, access_policy, "
            "created_at, updated_at) VALUES ('bbnull', ?, 'active', 'OPEN', "
            "?, ?)", (idxnull, now, now))
        await db.conn.commit()
        cur = await db.conn.execute(
            "SELECT id FROM payloads WHERE payload='bbnull'")
        pidnull = int((await cur.fetchone())[0])
        await db.create_website_payload(payload_id=pidnull,
                                        title="BB Null", published=1,
                                        created_by=1)
        lnull = await db.find_website_payload_for_canonical(
            payload_id=pidnull)
        opaquenull = str(lnull["opaque_id"])

        class _BBReq:
            def __init__(self, body):
                self._body = body
                self.cookies = {}
                self.headers = {"Content-Type": "application/json"}
                self.remote = "104.23.175.20"

            async def json(self):
                return self._body

        # signed initData for the issuance path
        uid_bb = 8922807758
        init = sign_init_data(MAIN_TOKEN, uid_bb, "bbtester")
        from app.web.site.tokens import make_video_token_codec as _mkc
        codec = _mkc(MAIN_TOKEN)
        ref_null = codec.encode_video_ref(opaquenull, idxnull)
        cap.clear()
        resp_null = await _stream_mod.handle_site_api_stream(_BBReq({
            "init_data": init, "video_ref": ref_null}))
        import json as _json_bb
        null_json = _json_bb.loads(resp_null.text)
        check("BB4a NULL identity -> honest refusal (no stream/hls URL)",
              null_json.get("unavailable_reason")
              == "media_identity_unresolvable"
              and "hls_url" not in null_json and "stream_url" not in null_json,
              resp_null.text[:200])
        check("BB4b classified reason=media_identity_unresolvable",
              any("WEBSITE_STREAM_ISSUE_HLS_UNAVAILABLE" in ln
                  and "reason=media_identity_unresolvable" in ln
                  for ln in cap))
        # unwired gateway -> hls_resolver_unwired (distinctly classified)
        zdeps_unwired = _types.SimpleNamespace(
            db=db, bot_token=MAIN_TOKEN, media_gateway=gw,
            bot_ref=lambda: None, access_engine=_access_engine,
            network_tokens=None, hls_resolver=lambda *a, **k: None)
        _pages._deps_factory = lambda: zdeps_unwired
        ref_ok = codec.encode_video_ref(opaque, idx997)
        cap.clear()
        resp_unw = await _stream_mod.handle_site_api_stream(_BBReq({
            "init_data": init, "video_ref": ref_ok}))
        unw_json = _json_bb.loads(resp_unw.text)
        check("BB4c unwired resolver -> reason=hls_resolver_unwired "
              "(distinctly classified)",
              unw_json.get("unavailable_reason") == "hls_resolver_unwired"
              and any("reason=hls_resolver_unwired" in ln for ln in cap),
              resp_unw.text[:200])
    finally:
        _pages._deps_factory = _prev_factory
        await db.set_setting("website_enabled", _prev_we or "0")
        _lg.removeHandler(_h)
        _lg.setLevel(_prev_lvl)

    # ---- BB5-BB10: the SAFE media identity repair (spec §5-§6) -----------
    # BB5 — list_indexed_files_missing_identity finds the NULL row (and
    #       only NULL/empty rows).
    missing = await db.list_indexed_files_missing_identity(100)
    missing_pks = {int(r["id"]) for r in missing}
    check("BB5 the missing-identity scan finds exactly the NULL rows",
          idxnull in missing_pks and idx997 not in missing_pks)

    # BB6 — update_indexed_file can NEVER null an existing identity (the
    #       latent full-row-writer hazard, hardened).
    await db.update_indexed_file(idx997, {
        "file_id": "FID-NEW", "file_name": "renamed_by_edit.mp4",
        "caption": None, "media_type": "video", "file_size": 400000,
        "duration": None, "mime_type": "video/mp4", "width": None,
        "height": None, "thumb_file_id": None,
        "thumb_file_unique_id": None})
    row997 = await db.get_indexed_file_by_id(idx997)
    check("BB6 update_indexed_file preserves the identity on a partial "
          "info dict (filename/caption edits never null identity)",
          str(row997["file_unique_id"]) == "AgADyB8AAnV00FA"
          and str(row997["file_name"]) == "renamed_by_edit.mp4")

    # BB7 — the guarded repair: fills ONLY a missing identity, never
    #       overwrites an existing one.
    st = await db.repair_indexed_file_identity(idx997, "FAKEID123")
    check("BB7a the guarded write REFUSES to overwrite an existing identity",
          st == "identity_divergent", f"got {st}")
    row997b = await db.get_indexed_file_by_id(idx997)
    check("BB7b the existing identity is untouched",
          str(row997b["file_unique_id"]) == "AgADyB8AAnV00FA")
    st2 = await db.repair_indexed_file_identity(idxnull, "AgADNULLFIX01")
    check("BB7c the guarded write FILLS the missing identity",
          st2 == "repaired")
    row_null = await db.get_indexed_file_by_id(idxnull)
    check("BB7d the repaired row now carries the identity",
          str(row_null["file_unique_id"]) == "AgADNULLFIX01")

    # BB8 — the repair service: conflict discipline (never steal another
    #       row's identity) + the guarded write through the transport.
    from app.media.repair import make_media_repair_service as _mk_repair

    # a row owning identity X that the repair would try to give to row Y
    idx_own = await _bbfile(9203, "video_own.mp4", "AgADOWNED001")
    idx_victim = await _bbfile(9204, "video_victim.mp4", None)

    async def _fetch_conflict(admin, channel, message):
        # the source message actually hosts a DIFFERENT file (owned by
        # another row) — the identity conflict path.
        return {"file_unique_id": "AgADOWNED001", "file_id": "FX",
                "media_type": "video"}, None

    async def _resolve_admin():
        return 555

    svc_rp = _mk_repair(db, fetch_source_media=_fetch_conflict,
                        resolve_admin_chat_id=_resolve_admin)
    report = await svc_rp.repair_missing_identities(50)
    vic_row = await db.get_indexed_file_by_id(idx_victim)
    check("BB8 the repair REFUSES an identity owned by a different row "
          "(conflict discipline)",
          str(vic_row["file_unique_id"] or "") == ""
          and any(r.get("result") == "identity_conflict"
                  for r in report["rows"]))

    # BB9 — the happy path: a NULL row whose OWN source provides its
    #       identity — repaired through the existing transport discipline.
    async def _fetch_ok(admin, channel, message):
        if int(message) == 9204:
            return {"file_unique_id": "AgADVICTIMOK1", "file_id": "FV",
                    "media_type": "video"}, None
        return None, None

    svc_rp2 = _mk_repair(db, fetch_source_media=_fetch_ok,
                         resolve_admin_chat_id=_resolve_admin)
    report2 = await svc_rp2.repair_missing_identities(50)
    vic2 = await db.get_indexed_file_by_id(idx_victim)
    check("BB9a the repair fills the row from its OWN source message",
          str(vic2["file_unique_id"]) == "AgADVICTIMOK1"
          and report2["repaired"] >= 1)
    row_own = await db.get_indexed_file_by_id(idx_own)
    check("BB9b the already-complete rows are untouched",
          str(row_own["file_unique_id"]) == "AgADOWNED001")

    # BB10 — transport unavailable: the honest report, NOTHING fabricated.
    async def _fetch_none(admin, channel, message):
        return None, None

    idx_unreach = await _bbfile(9205, "video_unreach.mp4", None)
    svc_rp3 = _mk_repair(db, fetch_source_media=_fetch_none,
                         resolve_admin_chat_id=_resolve_admin)
    report3 = await svc_rp3.repair_missing_identities(50)
    unreach = await db.get_indexed_file_by_id(idx_unreach)
    check("BB10 transport unavailable -> honest failure, no fabrication",
          str(unreach["file_unique_id"] or "") == ""
          and report3["failed"] >= 1
          and any(r.get("result") == "source_fetch_failed"
                  for r in report3["rows"]))
    # and the row stays honestly unstreamable (resolver honesty)
    rl = _make_lr(db)
    t_unreach = await rl(opaque, idx_unreach)
    check("BB10b an unrepaired row stays out of this listing (404 shape)",
          t_unreach is None or not t_unreach.get("file_unique_id"))


# ===========================================================================
# V26.2 (bot-41) — §9-§11 package child display labels
# ===========================================================================
async def section_cc(ns, db):
    """[CC] V26.2 — bot-41 §9-§11: PACKAGE children render subordinate
    labels ("Video 1..N"); the raw original Telegram filenames become
    internal metadata only (preserved in the DB, never the surfaced
    identity); single payloads keep their canonical file_name label.
    """
    print("\n[CC] V26.2 — package child display labels")
    CH = -1004460709092
    now = datetime.now(timezone.utc).isoformat()
    # a package whose children carry the EXACT bot-41 production shapes:
    # raw filenames that must NOT become the user-facing identity.
    RAW_NAMES = [
        "@OnlyHotNet - Rachel Gets A+ (onlyfans).mp4",
        "a93c8e2cba30f5d913b4c8e7f2a1d0b3c.mp4",
        "Telegram @OnlyHotNet channel rip 001.mp4",
        "VID_20260921_134522_full_quality.mp4",
    ]
    fuids = ["CCUIDAA1", "CCUIDBB2", "CCUIDCC3", "CCUIDDD4"]
    pks = []
    for i, (name, fuid) in enumerate(zip(RAW_NAMES, fuids), start=1):
        await db.conn.execute(
            "INSERT INTO indexed_files(channel_id, message_id, file_id, "
            "file_unique_id, media_type, file_name, file_size, upload_date, "
            "mime_type) VALUES (?, ?, ?, ?, 'video', ?, 1000000, ?, "
            "'video/mp4')",
            (CH, 9300 + i, f"FID930{i}", fuid, name, now))
        await db.conn.commit()
        cur = await db.conn.execute(
            "SELECT id FROM indexed_files WHERE channel_id=? AND "
            "message_id=?", (CH, 9300 + i))
        pks.append(int((await cur.fetchone())[0]))

    COLL = "cc41pack"
    await db.conn.execute(
        "INSERT INTO collections(collection_id, channel_id, file_count, "
        "created_at) VALUES (?, ?, 4, ?)", (COLL, CH, now))
    await db.conn.commit()
    for i, pk in enumerate(pks, start=1):
        cur = await db.conn.execute(
            "SELECT channel_id, message_id FROM indexed_files WHERE id=?",
            (pk,))
        r = await cur.fetchone()
        await db.conn.execute(
            "INSERT INTO collection_items(collection_id, channel_id, "
            "message_id, position) VALUES (?, ?, ?, ?)",
            (COLL, r["channel_id"], r["message_id"], i))
    await db.conn.commit()
    await db.create_website_payload(collection_id=COLL,
                                    title="#MarieDee", published=1,
                                    created_by=1)
    listing = await db.find_website_payload_for_canonical(
        collection_id=COLL)
    opaque = str(listing["opaque_id"])

    # a single payload with its own file (label stays the canonical name)
    await db.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date, "
        "mime_type) VALUES (?, 9401, 'FID9401', 'CCUIDSINGLE', 'video', "
        "'My Single Video Final.mp4', 900000, ?, 'video/mp4')",
        (CH, now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM indexed_files WHERE channel_id=? AND message_id=?",
        (CH, 9401))
    idx_single = int((await cur.fetchone())[0])
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "display_name, created_at, updated_at) VALUES "
        "('ccsingle', ?, 'active', 'OPEN', 'My Single Video', ?, ?)",
        (idx_single, now, now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload='ccsingle'")
    pid_single = int((await cur.fetchone())[0])
    await db.create_website_payload(payload_id=pid_single,
                                    title="My Single Video", published=1,
                                    created_by=1)
    l_single = await db.find_website_payload_for_canonical(
        payload_id=pid_single)
    opaque_single = str(l_single["opaque_id"])

    from app.web.site.service import make_website_service as _mk_svc
    from app.web.site import html as _html_mod
    svc = _mk_svc(db)

    # CC1 — get_listing_detail: package children carry display_label
    #       "Video 1..4"; the raw file_name stays intact in the SAME dict.
    detail = await svc.get_listing_detail(opaque)
    files = detail.get("files") or []
    labels = [str(f.get("display_label") or "") for f in files]
    names = [str(f.get("file_name") or "") for f in files]
    check("CC1a package children get subordinate labels Video 1..4",
          labels == ["Video 1", "Video 2", "Video 3", "Video 4"],
          f"got {labels}")
    check("CC1b the raw original filenames stay INTERNAL (preserved "
          "verbatim in the detail dict)",
          names == RAW_NAMES, f"got {names}")
    check("CC1c the package title stays the canonical display_name",
          str(detail.get("eff_title")) == "#MarieDee")

    # CC2 — detail_page HTML: the rendered rows show ONLY the subordinate
    #       labels — the raw filenames NEVER reach the markup.
    html_out = _html_mod.detail_page(
        detail, video_hrefs={pk: f"/site/payload/{opaque}/video/REF{i}"
                             for i, pk in enumerate(pks, start=1)},
        back_href="/site")
    leaks = [n for n in RAW_NAMES if n in html_out]
    check("CC2a the rendered detail shows the subordinate labels",
          all(f"Video {i}" in html_out for i in (1, 2, 3, 4)))
    check("CC2b NO raw original filename leaks into the package HTML",
          not leaks, f"leaked {leaks}")
    check("CC2c the package identity #MarieDee is the page title",
          "#MarieDee" in html_out)

    # CC3 — a SINGLE payload keeps its canonical file_name label (no
    #       display_label injected — its own name IS the identity).
    d_single = await svc.get_listing_detail(opaque_single)
    f_single = (d_single.get("files") or [])[0]
    check("CC3a single payload row keeps the file_name label",
          str(f_single.get("display_label") or "") == ""
          and str(f_single.get("file_name") or "")
          == "My Single Video Final.mp4")
    html_single = _html_mod.detail_page(
        d_single, video_hrefs={idx_single: "/site/payload/"
                               f"{opaque_single}/video/REF1"},
        back_href="/site")
    check("CC3b the single detail still shows its own canonical name",
          "My Single Video Final.mp4" in html_single)

    # CC4 — the stream resolver/issuance carries display_name for package
    #       children (the player's now-playing identity).
    from app.web.site.stream import make_listing_resolver as _mk_lr
    rl = _mk_lr(db)
    t = await rl(opaque, pks[1])
    check("CC4a the listing resolver target carries display_name",
          str(t.get("display_name")) == "Video 2")
    check("CC4b the raw file_name stays available server-side "
          "(content-type sniffing)",
          str(t.get("file_name")) == RAW_NAMES[1])
    t_single = await rl(opaque_single, idx_single)
    check("CC4c the single target has no display_name (legacy behavior)",
          not t_single.get("display_name"))

    # CC5 — the internal metadata surfaces are NOT broken: the indexed
    #       rows keep their raw filenames in the DB (admin/dedup/reindex).
    for pk, name in zip(pks, RAW_NAMES):
        row = await db.get_indexed_file_by_id(pk)
        check(f"CC5 internal metadata preserved (file_pk={pk})",
              str(row["file_name"]) == name)



# ===========================================================================
# V26.2-bot42 — /api/stream 500 root cause + async HLS + player contract
# ===========================================================================
async def section_dd(ns, db):
    """[DD] V26.2-bot42 — the REAL production engine path through the
    assembled namespace (the /api/stream HTTP 500 root cause), safe engine
    telemetry, the async HLS preparation contract, and the player-side
    error-classification / engine-order / lifecycle rules.

    The production 500 (bot-42): FJ_PLAY_GATE decision=pass -> POST
    /site/api/stream -> HTTP 500 engine_error for EVERY non-admin user
    with Force Join active. Root cause (reproduced in repro/ before the
    fix): the V26.2 helper ``_fj_slice_for`` was defined in the access
    section module but NOT registered in the namespace manifest, so the
    REBOUND ``access_engine`` raised NameError at call time. The V/Z/AA
    batteries all bypassed the real path (fake access_engine / direct
    service calls) — this section pins the real wiring.
    """
    print("\n[DD] V26.2-bot42 — engine 500 root cause + async HLS + player")
    import ast
    import re as _re
    import inspect as _inspect
    from app.presentation.telegram import _manifest as _mf
    from app.services import container as _container
    from app.web.site import stream as _stream
    from app.web.site import pages as _pages
    from app.web.site.tokens import make_video_token_codec as _vc2
    from app.media.streamtokens import make_stream_token_codec as _stc2

    now = datetime.now(timezone.utc).isoformat()
    CH = -1004460709020
    USER_OK = 88300
    USER_NO = 88301
    MAIN_TOKEN = ns.BOT_TOKEN

    # ---- the manifest registration (the surgical root-cause fix) -------
    check("DD1 the V26.2 per-gate FJ slice resolver is registered in the "
          "namespace manifest (the /api/stream 500 root cause)",
          "_fj_slice_for" in _mf.SECTION_MEMBERS["access"])

    # ---- the whole-tree audit: NO other unregistered module-level def ---
    missing = {}
    for sec, mod in dict(_ns_mod_ref()._SECTION_MODULES).items():
        try:
            tree = ast.parse(open(mod.__file__).read())
        except Exception:
            continue
        top_defs = {n.name for n in tree.body
                    if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef,
                                      ast.ClassDef))}
        manifest_names = set()
        for _s, _n2 in _mf.SECTION_MEMBERS.items():
            manifest_names.update(_n2)
        manifest_names.update(_mf.STATE_NAMES)
        for name in sorted(top_defs - manifest_names):
            missing.setdefault(sec, []).append(name)
    check("DD2 every module-level section def is manifest-registered "
          "(no other NameError-shaped landmine in the tree)",
          not missing, str(missing))

    # ---- the REAL production wiring (namespace + container deps) --------
    class _MiniGateway:
        async def read_settings(self):
            return {"stream_enabled": True, "token_ttl": 300}

        def issue_stream_token(self, uid, listing_, file_pk,
                               ttl_seconds=300, ttl_max_seconds=None):
            return _stc2(MAIN_TOKEN).encode_stream_token(
                uid, listing_, file_pk, ttl_override=ttl_seconds,
                ttl_max_seconds=ttl_max_seconds)

        async def handle_stream_request(self, token, method="GET",
                                        range_header=None):
            return None
        cache = None
    _gw = _MiniGateway()
    _gw.listing_resolver = _stream.make_listing_resolver(db)

    _prev_gw = getattr(ns, "_website_media_gateway", None)
    _prev_bot = getattr(ns, "_mini_app_bot", None)
    ns._website_media_gateway = lambda: _gw   # the FACADE shape (bot-41)
    ns._mini_app_bot = _FakeFJBot()           # joined nowhere by default

    deps = _container.website_deps_factory(ns)
    _prev_factory = _pages._deps_factory
    _pages._deps_factory = lambda: deps
    _prev_we = await db.get_setting("website_enabled") or ""
    await db.set_setting("website_enabled", "1")

    # seed a payload-kind listing through the REAL production tables
    await db.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date, "
        "mime_type) VALUES (?, 9801, 'FIDDD01', 'DUIDD01', 'video', "
        "'dd_engine_video.mp4', 571600000, ?, 'video/mp4')", (CH, now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM indexed_files WHERE channel_id=? AND message_id=?",
        (CH, 9801))
    idx_dd = int((await cur.fetchone())[0])
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "display_name, created_at, updated_at) VALUES "
        "('dd_engine_pkg', ?, 'active', 'FORCE_JOIN', 'DD Engine Pkg', "
        "?, ?)", (idx_dd, now, now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload='dd_engine_pkg'")
    pid_dd = int((await cur.fetchone())[0])
    await db.create_website_payload(payload_id=pid_dd, title="DD Engine Pkg",
                                    published=1, created_by=1)
    listing_dd = await db.find_website_payload_for_canonical(
        payload_id=pid_dd)
    opaque_dd = str(listing_dd["opaque_id"])

    _vc = _vc2(MAIN_TOKEN)
    video_ref = _vc.encode_video_ref(opaque_dd, idx_dd)

    class _IssReq:
        def __init__(self, body):
            self._body = body
            self.cookies = {}
            self.headers = {"Content-Type": "application/json"}
            self.remote = "104.23.175.20"

        async def json(self):
            return self._body

    # ---- DD3/DD14: the joined user ISSUES (200), the unjoined user is ----
    # ---- DENIED (force_join_required — never a 500, never a bypass) ------
    ns._mini_app_bot = _FakeFJBot()
    ns._mini_app_bot.joined = set()          # joined NOTHING -> live deny
    with _LogCap() as cap_deny:
        r_deny = await _stream.handle_site_api_stream(_IssReq({
            "init_data": sign_init_data(MAIN_TOKEN, USER_NO),
            "video_ref": video_ref}))
    b_deny = json.loads(r_deny.text)
    check("DD3 Force-Join stays ENFORCED on the REAL engine path "
          "(unjoined user denied, reason=force_join_required, NOT 500)",
          r_deny.status == 200 and b_deny.get("ok") is True
          and b_deny.get("authorized") is False
          and b_deny.get("reason") == "force_join_required"
          and (b_deny.get("not_joined") or []),
          f"status={r_deny.status} reason={b_deny.get('reason')}")

    _bot_joined = _FakeFJBot()
    _bot_joined.joined = {int(r["channel_id"])
                          for r in await db.list_force_channels()}
    ns._mini_app_bot = _bot_joined            # joined EVERYTHING -> allow
    with _LogCap() as cap_ok:
        r_ok = await _stream.handle_site_api_stream(_IssReq({
            "init_data": sign_init_data(MAIN_TOKEN, USER_OK),
            "video_ref": video_ref}))
    b_ok = json.loads(r_ok.text)
    check("DD4 THE BOT-42 ROOT-CAUSE PIN: the joined user issues through "
          "the REAL namespace engine (200 authorized + the HLS plan — "
          "the former NameError->500 path)",
          r_ok.status == 200 and b_ok.get("ok") is True
          and b_ok.get("authorized") is True
          and b_ok.get("codec_verdict") == "transcode"
          and bool(b_ok.get("hls_url"))
          and any("WEBSITE_STREAM_ISSUE_OK" in m for m in cap_ok.lines),
          f"status={r_ok.status}")
    check("DD4b no engine-error telemetry on the healthy path",
          not any("WEBSITE_ACCESS_ENGINE_ERROR" in m for m in cap_ok.lines))

    # ---- DD5: an engine exception -> 500 engine_error + SAFE telemetry ---
    # BOT-45/46 Task A isolation: DD4's successful pass minted an FJ auth
    # session (the 120s website playback session cache). Clear it so the
    # boom engine below is ACTUALLY invoked (a cache HIT would short-circuit
    # the engine call and mask the exception path under test).
    from app.web.site.authz import fj_auth_session_cache as _fj_cache
    _fj_cache.clear(cause="test_isolation")
    _orig_engine = deps.access_engine

    async def _boom_engine(bot, user_id, payload_id=None, **kw):
        raise NameError("name '_fj_slice_for' is not defined")

    deps.access_engine = _boom_engine
    with _LogCap() as cap_boom:
        r_boom = await _stream.handle_site_api_stream(_IssReq({
            "init_data": sign_init_data(MAIN_TOKEN, USER_OK),
            "video_ref": video_ref}))
    b_boom = json.loads(r_boom.text)
    _err_lines = [m for m in cap_boom.lines
                  if m.startswith("WEBSITE_ACCESS_ENGINE_ERROR")]
    check("DD5 engine exception => honest 500 engine_error + ERROR-level "
          "WEBSITE_ACCESS_ENGINE_ERROR telemetry (exception class + stage)",
          r_boom.status == 500 and b_boom.get("error") == "engine_error"
          and len(_err_lines) == 1
          and "exception=NameError" in _err_lines[0]
          and "surface=stream_issuance" in _err_lines[0]
          and "failure_stage=" in _err_lines[0],
          f"status={r_boom.status} lines={_err_lines[:1]}")
    check("DD5b the telemetry carries ONLY safe fields (no token shapes, "
          "no initData, no Authorization material)",
          not any(("init_data" in m or "Bearer" in m
                   or _re.search(r"\b\d{8,12}:[A-Za-z0-9_-]{30,}\b", m))
                  for m in cap_boom.lines),
          str(_err_lines[:1]))

    async def _boom_runtime(bot, user_id, payload_id=None, **kw):
        raise RuntimeError("membership subsystem exploded")

    deps.access_engine = _boom_runtime
    _fj_cache.clear(cause="test_isolation")
    with _LogCap() as cap_rt:
        r_rt = await _stream.handle_site_api_stream(_IssReq({
            "init_data": sign_init_data(MAIN_TOKEN, USER_OK),
            "video_ref": video_ref}))
    _rt_lines = [m for m in cap_rt.lines
                 if m.startswith("WEBSITE_ACCESS_ENGINE_ERROR")]
    check("DD5c a RuntimeError engine failure is classified too "
          "(exception=RuntimeError, honest 500)",
          r_rt.status == 500 and _rt_lines
          and "exception=RuntimeError" in _rt_lines[0])
    deps.access_engine = _orig_engine

    # ---- DD6-DD8: the async HLS preparation contract --------------------
    from app.media.transcode import get_transcode_manager as _gtm
    import tempfile as _tf
    _dd_tmp = _tf.mkdtemp(prefix="dd_hls_")
    _mgr = _gtm(_dd_tmp)

    async def _never_source():
        raise RuntimeError("should never be called by a snapshot")

    snap0 = await _mgr.hls_preparation_snapshot("DDUIDXXX")
    check("DD6 the preparation snapshot is a PURE READ (nothing running, "
          "nothing ready, no job started)",
          snap0.get("ready") is False and snap0.get("running") is False
          and snap0.get("failed") is False)

    # a REAL tiny source so the job completes (real ffmpeg)
    src_dd = os.path.join(_dd_tmp, "src.mp4")
    _gen_tiny_mp4(src_dd)
    from app.media.transcode import variant_ladder  # noqa: F401

    async def _dd_source():
        return src_dd

    with _LogCap() as cap_prep:
        s1 = await _mgr.start_hls_preparation("DDUIDREAL", _dd_source)
        s2 = await _mgr.start_hls_preparation("DDUIDREAL", _dd_source)
        check("DD7 concurrent preparation STARTS are COALESCED (one job, "
              "one ffmpeg — the second caller joins)",
              s1.get("started") is True and s2.get("started") is False
              and s2.get("already_live") is True)
        res = await _mgr.wait_for_preparation("DDUIDREAL", timeout=120.0)
        snap1 = await _mgr.hls_preparation_snapshot("DDUIDREAL")
        check("DD8 after the background job the tree is READY (snapshot "
              "ready=True with servable coordinates + the "
              "HLS_PREPARE_START->HLS_PREPARE_READY telemetry)",
              res is not None and bool(res.ok)
              and snap1.get("ready") is True
              and str(snap1.get("master") or "") == "master.m3u8"
              and any(m.startswith("HLS_PREPARE_START")
                      for m in cap_prep.lines)
              and any(m.startswith("HLS_PREPARE_READY")
                      for m in cap_prep.lines),
              str(snap1))
    check("DD8b exactly ONE ffmpeg run for the identity (no duplicate jobs)",
          _mgr.stats_runs == 1 and _mgr.stats_prepare_started == 1
          and _mgr.stats_prepare_coalesced == 1,
          f"runs={_mgr.stats_runs} started={_mgr.stats_prepare_started} "
          f"coalesced={_mgr.stats_prepare_coalesced}")

    # a permanently failing source -> honest failure + backoff snapshot
    _fail_tmp = _tf.mkdtemp(prefix="dd_fail_")

    async def _bad_source():
        return os.path.join(_fail_tmp, "does_not_exist.mp4")

    with _LogCap() as cap_fail:
        await _mgr.start_hls_preparation("DDUIDBAD", _bad_source)
        await _mgr.wait_for_preparation("DDUIDBAD", timeout=30.0)
        snap_bad = await _mgr.hls_preparation_snapshot("DDUIDBAD")
    check("DD9 a failed preparation records the honest failure "
          "(HLS_PREPARE_FAILED + snapshot failed/backoff)",
          snap_bad.get("failed") is True
          and float(snap_bad.get("backoff_remaining_s") or 0) > 0
          and any(m.startswith("HLS_PREPARE_FAILED") for m in cap_fail.lines),
          str(snap_bad))

    # ---- DD10-DD13: the player-side contract (source-level pins) --------
    _hsrc = open("app/web/site/html.py").read()
    check("DD10 HTTP 500 NEVER renders AUTH_EXPIRED: the issuance mapper "
          "classifies explicitly (500->PLAYBACK_ERROR, 503 "
          "hls_preparing->PREPARING, network->NETWORK_ERROR)",
          "function issuanceStateFromResponse" in _hsrc
          and 'if(status === 500){' in _hsrc
          and 'return "PLAYBACK_ERROR";' in _hsrc
          and 'code === "hls_preparing"){ return "PREPARING"; }' in _hsrc
          and 'showState("NETWORK_ERROR");' in _hsrc
          and '? "NETWORK_INTERRUPTED" : "AUTH_EXPIRED");' not in _hsrc)
    check("DD11 the ANDROID HLS ENGINE ORDER: hls.js/MSE is evaluated "
          "FIRST inside attachHls; canPlayType only in the native fallback",
          "function attachHls(el, j){" in _hsrc
          and _hsrc.index("loadHlsJs(function(Hls){")
          < _hsrc.index("function attachNativeHls(el, j, url){")
          and _hsrc.count("!!el.canPlayType(") == 1
          and _hsrc.index("loadHlsJs(function(Hls){")
          < _hsrc.index("function attachNativeHls(el, j, url){")
          < _hsrc.index("!!el.canPlayType("))
    check("DD12 the hls.js quality switch emits QUALITY_CHANGE only AFTER "
          "the REAL level switch (LEVEL_SWITCHED, never at intent time)",
          "Hls.Events.LEVEL_SWITCHED" in _hsrc
          and "V26.2-bot42: the telemetry moved to LEVEL_SWITCHED" in _hsrc)
    check("DD13 the player lifecycle cleanup: teardownMedia cancels the "
          "preparation retry timer + destroys the HLS instance; Retry "
          "Stream re-issues in place (NO location.reload anywhere)",
          "cancelPrepTimer();" in _hsrc
          and "__prepAttempts = 0;" in _hsrc
          and "function destroyHls(){" in _hsrc
          and "location.reload(" not in _hsrc)

    # restore the production-shaped wiring
    _pages._deps_factory = _prev_factory
    await db.set_setting("website_enabled", _prev_we or "false")
    ns._website_media_gateway = _prev_gw
    ns._mini_app_bot = _prev_bot


def _ns_mod_ref():
    import app.presentation.telegram.namespace as _nsm
    return _nsm


def _gen_tiny_mp4(path):
    """A real tiny mp4 with a video stream (ffmpeg, ~0.4s)."""
    import subprocess as _sp
    _sp.run([
        "ffmpeg", "-y", "-nostdin", "-hide_banner", "-loglevel", "error",
        "-f", "lavfi", "-i", "testsrc=size=320x180:rate=12:duration=1",
        "-pix_fmt", "yuv420p", "-c:v", "libx264", "-preset", "ultrafast",
        path], check=True, timeout=60)


async def main() -> int:
    ns, db = await build_env()
    await section_a(ns, db)
    await section_b(ns, db)
    await section_c(ns, db)
    await section_d(ns, db)
    await section_e(ns, db)
    await section_f(ns, db)
    await section_g(ns, db)
    await section_h(ns, db)
    await section_i(ns, db)
    await section_j(ns, db)
    await section_k(ns, db)
    await section_l(ns, db)
    await section_m(ns, db)
    await section_n(ns, db)
    await section_o(ns, db)
    await section_p(ns, db)
    await section_q(ns, db)
    await section_r(ns, db)
    await section_s(ns, db)
    await section_t(ns, db)
    await section_u(ns, db)
    await section_v(ns, db)
    await section_w(ns, db)
    await section_x(ns, db)
    await section_y(ns, db)
    await section_z(ns, db)
    await section_aa(ns, db)
    await section_bb(ns, db)
    await section_cc(ns, db)
    await section_dd(ns, db)
    await db.close()
    total = RESULTS["pass"] + RESULTS["fail"]
    print(f"\n{'=' * 60}\nV26 SUITE: {RESULTS['pass']}/{total} passed, "
          f"{RESULTS['fail']} failed")
    if RESULTS["failures"]:
        print("FAILURES:")
        for f in RESULTS["failures"]:
            print("  -", f)
    return 1 if RESULTS["fail"] else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
