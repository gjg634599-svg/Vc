#!/usr/bin/env python3
"""BOT-45/46 PRODUCTION VERIFICATION SUITE — payload-delivery-bot.

Run:  python3 tests/test_bot45_46_production.py

Every check runs against the REAL production code (the runtime namespace,
the real Database/schema v47, the real repositories and service/engine
functions) on a throwaway SQLite file. Nothing is mocked except the
Telegram transport boundary (the same class of mocked verification the
project's existing suites use — the live Telegram API is unreachable
from this environment).

Sections (master prompt §36 — the 69 required regression areas)
  A. FORCE JOIN auth session cache (§36 1-7): one initial membership
     verification mints a short-lived authorized playback session;
     following HLS master/variant/segment requests validate the session
     with ZERO engine calls / ZERO repeated Telegram membership sweeps;
     bounded TTL revalidation; invalidation causes revalidation;
     identity re-keying; fail-closed cache errors; denials never cached.
  B. AUTO DELETE consistency (Task B): relay_open excludes settled rows;
     the TTL pass settles ONLY after a confirmed delete
     (DELIVERY_TTL_SETTLE_DEFERRED on failure) with bounded backoff;
     pending_deletions.attempts/last_error; the classified delete
     (ok/retry/permanent) path + AUTO_DELETE_* telemetry; restart
     recovery through the SAME classified path.
  C. MAIN MINI APP link (§36 43-49): the canonical t.me/<bot>?startapp
     form, the configured direct form, None when unresolvable,
     MINI_APP_LINK_BUILD telemetry, no t.me/undefined, the Worker URL
     never the Telegram destination, admin/runtime resolution tiers.
  D. STORAGE canonical filename (§36 15-19): display_name_origin
     provenance (source vs admin_override), origin-aware propagation,
     the LIVE source re-resolve at SINGLE_SOURCE_RESOLVE, and
     STORAGE_MESSAGE_SKIP with reason codes from the allowed set.
  E. SOURCE MEDIA REPLACEMENT (§36 20-25): same (channel, message) +
     new file_unique_id -> guarded IN-PLACE replacement through the
     verification engine (Phase D step 5), file_pk + payload FKs +
     website associations preserved, FAILED on missing/conflicting
     identity (never fabricated), per-record payloads_on_unavailable
     diagnostics, INDEX_REINDEX_METADATA_CHANGED/UNCHANGED.
  F. WIZARD terminals (§36 26-30): every wizard attempt terminates
     (WIZARD_COMPLETE with source identity / WIZARD_FAILED classified /
     WIZARD_CANCELLED), Telegram timeout / DNS / validation vs publish
     classification, retryable -> [ Retry ].
  G. PLAYER (§36 31-42): fullscreen hides site chrome (the rendered
     template's body-state CSS rules), the end screen ONLY at 'ended'
     (no last-20s timeupdate trigger), Replay + Next Part controls,
     PLAYER_END_SCREEN/PLAYER_NEXT_PART/PLAYER_REPLAY/
     PLAYER_FULLSCREEN_ENTER/EXIT telemetry, one video element / one
     HLS lifecycle / one control surface.
  H. NETWORK BOT setup wizard (§36 8-14): the 6-step wizard text, the
     8 telemetry events, classified error states with next actions,
     the network_ui setup/verify callback routing, the attach path.
  I. MINI APP + WEBSITE integration: the pages.py telemetry allowlist
     entries for the new player events, the FJ verify endpoint
     invalidation wiring, the DD2-style namespace registration of the
     new text_input/wizard functions, and the schema v47 columns.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import sys
import time
import types
import urllib.parse

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

os.environ.setdefault("BOT_TOKEN", "123456:V26_MAIN_TEST_TOKEN")
os.environ.setdefault("ADMIN_IDS", "8370454312")
os.environ["DATABASE_FILE"] = os.path.join(
    _ROOT, "tests", "_bot45_46_test.db")

import logging  # noqa: E402

logging.basicConfig(level=logging.WARNING)

RESULTS = {"pass": 0, "fail": 0, "failures": []}


def check(name: str, cond: bool, detail: str = "") -> None:
    if cond:
        RESULTS["pass"] += 1
        print(f"  ✓ {name}")
    else:
        RESULTS["fail"] += 1
        RESULTS["failures"].append(f"{name} {detail}")
        print(f"  ✗ FAIL {name} {detail}")


class _LogCap:
    """Capture structured log lines from the payload-bot (+managed bots)
    loggers — the same harness class the V26 suite uses."""

    def __init__(self, *names):
        self.names = names or ("payload-bot",)
        self.lines = []
        self._h = logging.Handler()
        self._h.emit = lambda rec: self.lines.append(rec.getMessage())  # type: ignore[method-assign]
        self._h.setLevel(logging.INFO)

    def __enter__(self):
        for n in self.names:
            lg = logging.getLogger(n)
            lg.addHandler(self._h)
            if lg.level > logging.INFO or lg.level == 0:
                lg.setLevel(logging.INFO)
        return self

    def __exit__(self, *a):
        for n in self.names:
            logging.getLogger(n).removeHandler(self._h)

    def has(self, prefix):
        return any(ln.startswith(prefix) for ln in self.lines)

    def grab(self, prefix):
        return [ln for ln in self.lines if ln.startswith(prefix)]


CAPTURED = {}


async def _fake_safe_edit_text(q, text, reply_markup=None, **kw):
    CAPTURED["edit"] = (text, reply_markup)
    return True


async def _fake_safe_send_text(bot, chat_id, text, reply_markup=None, **kw):
    CAPTURED["send"] = (text, reply_markup)
    return True


async def build_env():
    """Fresh DB + namespace with the production code loaded."""
    if os.path.exists(os.environ["DATABASE_FILE"]):
        os.remove(os.environ["DATABASE_FILE"])
    from app.presentation.telegram import namespace as _ns_mod
    from app.storage.schema import Database
    NS = _ns_mod.NS
    db = Database(os.environ["DATABASE_FILE"])
    await db.connect()
    await db.init_schema()
    NS.db = db
    NS.safe_edit_text = _fake_safe_edit_text
    NS.safe_send_text = _fake_safe_send_text
    return NS, db


async def _seed_indexed(db, channel_id, message_id, uid, fid, name, *,
                        media_type="video", status="available",
                        size=111222, mime="video/mp4"):
    await db.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date, "
        "mime_type, source_status) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (channel_id, message_id, fid, uid, media_type, name, size,
         "2025-01-01T00:00:00+00:00", mime, status))
    await db.conn.commit()
    row = await db.get_indexed_file_by_channel_message(channel_id,
                                                       message_id)
    return int(row["id"])


# ===========================================================================
# [A] FORCE JOIN — the auth session cache at the website playback
#     chokepoint (master prompt §3 / §36 1-7)
# ===========================================================================
async def section_a(ns, db):
    print("\n[A] FJ auth session cache — one sweep per playback session")
    from app.web.site import authz as _authz
    from app.core.access.engine import AccessResult
    from app.core.force_join.service import make_force_join_service

    authorize = _authz.authorize_website_playback
    cache = _authz.fj_auth_session_cache

    UID = 77045
    CHS = [-100111, -100222, -100333, -100444]
    for cid in CHS:
        await db.add_force_channel(cid, f"chan{abs(cid)}")
    await db.set_setting("force_join_enabled", "1")
    await db.set_setting("fj_mode", "fixed_order")
    await db.set_setting("fj_batch_size", "2")

    # ---- the faithful Access-Engine stand-in: every call performs the
    # LIVE membership sweep over the configured FJ channels (exactly the
    # 6-channel get_chat_member sweep the production engine runs). ----
    class _SweepEngine:
        def __init__(self, db, mode="pass"):
            self.db = db
            self.calls = 0
            self.mode = mode

        async def __call__(self, bot, user_id, payload_id=None,
                           gate_key=None):
            self.calls += 1
            if bot is None:
                return AccessResult(authorized=True, policy="OPEN",
                                    reason="open")
            rows = await self.db.list_force_channels()
            not_joined = []
            for r in rows:
                m = await bot.get_chat_member(int(r["channel_id"]),
                                              int(user_id))
                if getattr(m, "status", "left") != "member":
                    not_joined.append({"channel_id": int(r["channel_id"])})
            if not_joined and self.mode == "deny":
                return AccessResult(authorized=False, policy="FORCE_JOIN",
                                    reason="force_join_required",
                                    not_joined=not_joined)
            if self.mode == "watch_ad":
                return AccessResult(authorized=False, policy="FORCE_JOIN",
                                    reason="watch_ad_required")
            return AccessResult(authorized=True, policy="FORCE_JOIN",
                                payload_id=payload_id, reason="unlocked")

    class _SweepBot:
        def __init__(self, joined=True):
            self.joined = joined
            self.gcm_calls = 0

        async def get_chat_member(self, channel_id, user_id):
            self.gcm_calls += 1
            return types.SimpleNamespace(
                status="member" if self.joined else "left")

    async def _ident():
        # mirrors authz._fj_auth_cache_context / the service fingerprint
        # (mode|batch_size|sorted channel ids) from the CURRENT settings —
        # so a config change genuinely yields a different identity (the
        # A7 re-key scenario; A1b separately proves the byte-for-byte
        # match against the real service).
        rows = await db.list_force_channels()
        mode = str(await db.get_setting("fj_mode", "show_all")
                   or "show_all")
        if mode not in ("progressive_random", "fixed_order", "show_all"):
            mode = "show_all"
        try:
            batch = int(await db.get_setting_int("fj_batch_size", 2) or 0)
        except (TypeError, ValueError):
            batch = 0
        if batch <= 0:
            batch = 2
        raw = "%s|%d|%s" % (mode, batch, ",".join(
            str(i) for i in sorted(int(r["channel_id"]) for r in rows)))
        return hashlib.sha256(raw.encode()).hexdigest()[:12]

    GK = "w|list45g001|854"
    engine = _SweepEngine(db)
    bot = _SweepBot(joined=True)
    deps = types.SimpleNamespace(db=db, access_engine=engine)

    # A1 — the initial verification: cache MISS, live sweep, session minted.
    cache.clear(cause="test_reset")
    with _LogCap() as cap:
        v0 = await authorize(deps, bot, UID, payload_id=42, gate_key=GK)
    idA = await _ident()
    st = cache.stats()
    check("A1 initial verification -> FJ_AUTH_CACHE_MISS + session minted "
          "(identity = the canonical service fingerprint)",
          v0.authorized and cap.has("FJ_AUTH_CACHE_MISS")
          and "reason=no_session" in cap.grab("FJ_AUTH_CACHE_MISS")[0]
          and st["entries"] == 1 and st["live"] == 1
          and cap.grab("FJ_AUTH_CACHE_MISS")[0].count(idA) == 1,
          f"entries={st['entries']}")
    svc = make_force_join_service(
        db=db, ENABLE_FORCE_JOIN=True,
        get_join_request_policy=_async_const("request"),
        _consume_join_request=lambda *a: None,
        _has_pending_join_request=lambda *a: False,
        _prune_join_requests=lambda: None,
        PENDING_JOIN_REQUESTS={})
    check("A1b the cache identity matches force_join_requirement_identity "
          "byte-for-byte (config changes re-key exactly)",
          await svc.force_join_requirement_identity() == idA)

    # A2/A3 — the whole playback session: 1 master + 4 variants + 5
    # segments = 10 HLS requests -> 10 HITs, ZERO engine calls, ZERO
    # repeated Telegram membership sweeps.
    calls0, sweeps0 = engine.calls, bot.gcm_calls
    all_auth = True
    with _LogCap() as cap2:
        for i in range(10):
            v = await authorize(deps, bot, UID, payload_id=42, gate_key=GK)
            all_auth = all_auth and v.authorized
    hits = cap2.grab("FJ_AUTH_CACHE_HIT")
    check("A2 10 following HLS requests (master/variant/segment) -> 10 "
          "FJ_AUTH_CACHE_HITs with ZERO engine calls",
          len(hits) == 10 and engine.calls == calls0 and all_auth,
          f"hits={len(hits)} engine_delta={engine.calls - calls0}")
    check("A3 no repeated six-channel membership sweep "
          "(get_chat_member count stays at the ONE initial sweep = 4)",
          bot.gcm_calls == sweeps0 == len(CHS),
          f"gcm={bot.gcm_calls}")

    # A4 — a HIT replays the EQUIVALENT verdict (same reason fields).
    v_live = v0
    v_hit = await authorize(deps, bot, UID, payload_id=42, gate_key=GK)
    check("A4 the HIT replays the live engine's own PASS verdict "
          "(authorized/reason/engine_reason/waived_reason preserved)",
          v_hit.authorized is True
          and v_hit.reason == v_live.reason
          and v_hit.engine_reason == v_live.engine_reason
          and v_hit.waived_reason == v_live.waived_reason)

    # A5 — TTL expiry -> FJ_AUTH_REVALIDATE cause=expired + live re-check.
    scope = _authz.FjAuthSessionCache.scope_for(42, GK)
    key = _authz.FjAuthSessionCache.key_for(UID, scope, idA)
    entry = cache._entries.get(key)
    entry.expires_monotonic = time.monotonic() - 1.0
    calls1 = engine.calls
    with _LogCap() as cap5:
        v5 = await authorize(deps, bot, UID, payload_id=42, gate_key=GK)
    rel = cap5.grab("FJ_AUTH_REVALIDATE")
    check("A5 TTL expiry -> FJ_AUTH_REVALIDATE cause=expired + a LIVE "
          "re-check re-mints the session",
          v5.authorized and len(rel) == 1
          and "cause=expired" in rel[0] and engine.calls == calls1 + 1
          and cache.stats()["live"] == 1,
          f"rel={rel[:1]}")

    # A6 — the exported invalidation hook -> re-check (cause=invalidated).
    removed = _authz.invalidate_fj_auth_sessions(
        user_id=UID, payload_id=42, cause="live_recheck")
    calls6 = engine.calls
    with _LogCap() as cap6:
        v6 = await authorize(deps, bot, UID, payload_id=42, gate_key=GK)
    rel6 = cap6.grab("FJ_AUTH_REVALIDATE")
    check("A6 invalidation (the pages.py FJ verify hook) -> "
          "FJ_AUTH_INVALIDATE removed=1 + FJ_AUTH_REVALIDATE "
          "cause=invalidated + live re-check",
          removed == 1 and v6.authorized and len(rel6) == 1
          and "cause=invalidated" in rel6[0]
          and engine.calls == calls6 + 1,
          f"removed={removed} rel={rel6[:1]}")

    # A7 — a Force Join CONFIG change re-keys every session immediately.
    await db.set_setting("fj_mode", "progressive_random")
    idB = await _ident()
    cache.clear(cause="test_reset")
    await authorize(deps, bot, UID, payload_id=42, gate_key=GK)
    await db.set_setting("fj_mode", "fixed_order")   # restore identity idA
    calls7 = engine.calls
    with _LogCap() as cap7:
        v7 = await authorize(deps, bot, UID, payload_id=42, gate_key=GK)
    miss7 = cap7.grab("FJ_AUTH_CACHE_MISS")
    check("A7 a FJ config change re-keys the cache (the idA session is "
          "NOT replayed: MISS + live engine verdict)",
          idB != idA and v7.authorized and len(miss7) == 1
          and idA in miss7[0] and engine.calls == calls7 + 1,
          f"idA={idA} idB={idB} miss={miss7[:1]}")

    # A8 — fail-closed on a cache error: the issue is logged, the cache
    # bypassed, the LIVE engine decides (never fail-open).
    cache.clear(cause="test_reset")
    await authorize(deps, bot, UID, payload_id=42, gate_key=GK)
    calls8 = engine.calls

    def _boom_lookup(*a, **k):
        raise RuntimeError("cache exploded")

    cache.lookup = _boom_lookup  # instance shadow of the method
    try:
        with _LogCap() as cap8:
            v8 = await authorize(deps, bot, UID, payload_id=42, gate_key=GK)
        issue = cap8.grab("FJ_AUTH_SESSION_ISSUE")
    finally:
        del cache.lookup          # restore the class method
    cache.clear(cause="test_reset")
    check("A8 a cache error is FAIL-CLOSED (FJ_AUTH_SESSION_ISSUE op="
          "lookup; the live engine verdict decides)",
          v8.authorized is True and len(issue) == 1
          and "op=lookup" in issue[0]
          and "exception=RuntimeError" in issue[0]
          and engine.calls == calls8 + 1,
          f"issue={issue[:1]}")

    # A9 — DENIED verdicts are never cached (an immediate live re-check).
    engine_deny = _SweepEngine(db, mode="deny")
    bot_left = _SweepBot(joined=False)
    deps_d = types.SimpleNamespace(db=db, access_engine=engine_deny)
    cache.clear(cause="test_reset")
    with _LogCap() as cap9:
        d1 = await authorize(deps_d, bot_left, UID, payload_id=42,
                             gate_key=GK)
        d2 = await authorize(deps_d, bot_left, UID, payload_id=42,
                             gate_key=GK)
    check("A9 denials are NEVER cached (every request re-runs the live "
          "engine; no session minted)",
          d1.authorized is False and d2.authorized is False
          and engine_deny.calls == 2 and cache.stats()["live"] == 0
          and not cap9.has("FJ_AUTH_CACHE_HIT"))

    # A10 — session ownership + per-gate scope isolation.
    engine2 = _SweepEngine(db)
    deps2 = types.SimpleNamespace(db=db, access_engine=engine2)
    cache.clear(cause="test_reset")
    await authorize(deps, bot, UID, payload_id=42, gate_key=GK)
    calls10 = engine2.calls
    with _LogCap() as cap10:
        await authorize(deps2, bot, 77046, payload_id=42, gate_key=GK)
        await authorize(deps2, bot, UID, payload_id=42,
                        gate_key="w|list45g001|855")
    m10 = cap10.grab("FJ_AUTH_CACHE_MISS")
    check("A10 session ownership + per-gate scope isolation "
          "(another user / another gate -> MISS + live check, never a "
          "cross-gate HIT)",
          len(m10) == 2 and engine2.calls == calls10 + 2
          and not cap10.has("FJ_AUTH_CACHE_HIT"),
          f"miss={len(m10)}")

    # A11 — the non-storing gates: FJ inactive / OPEN policy / no
    # verifier, plus the documented TTL + entry bounds.
    engine_o = _SweepEngine(db)
    deps_o = types.SimpleNamespace(db=db, access_engine=engine_o)
    cache.clear(cause="test_reset")
    await db.set_setting("force_join_enabled", "0")
    await authorize(deps_o, bot, UID, payload_id=42, gate_key=GK)
    n_inactive = cache.stats()["entries"]
    await db.set_setting("force_join_enabled", "1")
    cache.clear(cause="test_reset")

    class _OpenEngine:
        def __init__(self):
            self.calls = 0

        async def __call__(self, bot_, uid_, payload_id=None,
                           gate_key=None):
            self.calls += 1
            return AccessResult(authorized=True, policy="OPEN",
                                reason="open")

    eng_open = _OpenEngine()
    await authorize(types.SimpleNamespace(db=db, access_engine=eng_open),
                    bot, UID, payload_id=42, gate_key=GK)
    n_open = cache.stats()["entries"]
    cache.clear(cause="test_reset")
    cache.store(user_id=UID, payload_id=42, gate_key=GK, scope=scope,
                requirement_identity=idA, reason="unlocked",
                engine_reason="unlocked",
                result=AccessResult(authorized=True, reason="unlocked"))
    c_before = eng_open.calls
    await authorize(types.SimpleNamespace(db=db, access_engine=eng_open),
                    None, UID, payload_id=42, gate_key=GK)
    check("A11 the non-storing gates hold (FJ-inactive pass, OPEN-policy "
          "pass, and a no-verifier request never consume/mint a session) "
          "+ TTL=120s / max 1024 entries",
          n_inactive == 0 and n_open == 0
          and eng_open.calls == c_before + 1
          and _authz.FJ_AUTH_SESSION_TTL == 120
          and _authz.FJ_AUTH_SESSION_MAX_ENTRIES == 1024
          and cache.stats()["ttl_s"] == 120.0,
          f"inactive={n_inactive} open={n_open}")
    cache.clear(cause="test_reset")

    # A12 — the watch-ad waiver path also mints an authorized session
    # (the website rule rides on a BASE-policy pass).
    engine_w = _SweepEngine(db, mode="watch_ad")
    deps_w = types.SimpleNamespace(db=db, access_engine=engine_w)
    cache.clear(cause="test_reset")
    w1 = await authorize(deps_w, bot, UID, payload_id=42, gate_key=GK)
    w_calls = engine_w.calls
    w2 = await authorize(deps_w, bot, UID, payload_id=42, gate_key=GK)
    check("A12 the watch-ad waiver verdict mints an authorized session "
          "(waived_reason replayed on the HIT; no second engine call)",
          w1.authorized and w1.waived_reason == "watch_ad_required"
          and w2.authorized
          and w2.waived_reason == "watch_ad_required"
          and engine_w.calls == w_calls,
          f"calls={engine_w.calls}")
    cache.clear(cause="test_reset")


def _async_const(value):
    async def _fn():
        return value
    return _fn


# ===========================================================================
# [B] AUTO DELETE consistency (Task B — master prompt §2)
# ===========================================================================
async def section_b(ns, db):
    print("\n[B] Auto Delete — settled rows, deferred TTL, classified retry")
    from app.network.file_delivery import DeliveryJobEngine
    from app.network.file_delivery import (
        TTL_SETTLE_DEFER_MARKER, TTL_SETTLE_DEFER_BASE,
        TTL_SETTLE_DEFER_MAX)
    from app.storage.repositories.delivery import JOB_DELIVERED
    from telegram.error import BadRequest, Forbidden, TimedOut, NetworkError

    GID = -10045678001
    now5h = "2020-01-01T00:00:00+00:00"
    # seed one network_bots row (delivery_jobs.network_bot_id is a real FK)
    await db.conn.execute(
        "INSERT INTO network_bots (id, owner_user_id, telegram_bot_id, "
        "username, display_name, status, health, created_at, updated_at) "
        "VALUES (7, 991, 45001, 'b45bot', 'B45 Bot', 'ACTIVE', 'HEALTHY', "
        "?, ?)", (now5h, now5h))
    await db.conn.commit()

    class _FakeFDB:
        def __init__(self, ok=True):
            self.ok = ok
            self.calls = 0

        async def delete_relay_message(self, gid, mid):
            self.calls += 1
            return self.ok

    async def _job(status=JOB_DELIVERED, *, rmid=55, deleted_at=None,
                   user_mid=77, last_error=None, next_retry=None):
        jid = await db.insert_delivery_job(
            user_id=991, network_bot_id=7, payload_id=1,
            payload_code="b45", file_pk=1, storage_chat_id=GID,
            storage_message_id=1, delivery_group_chat_id=GID)
        await db.update_delivery_job(
            jid, status=status, relay_message_id=rmid,
            delivery_group_chat_id=GID, relay_created_at=now5h,
            user_message_id=user_mid, deleted_at=deleted_at,
            last_error=last_error, next_retry_at=next_retry)
        return jid

    # B1 — relay_open excludes settled rows (deleted_at set) but still
    # lists rows whose relay deletion is genuinely owed.
    j_settled = await _job(deleted_at="2025-01-01T00:00:00+00:00")
    j_open = await _job()
    rows = await db.list_delivery_jobs(relay_open=True, limit=200)
    ids = [int(r["id"]) for r in rows]
    check("B1 relay_open EXCLUDES settled rows (deleted_at set) and keeps "
          "the genuinely-owed ones (the zombie re-delete root cause)",
          j_settled not in ids and j_open in ids,
          f"settled_in={j_settled in ids}")

    # B2 — the TTL pass settles ONLY after a CONFIRMED delete.
    fdb_ok = _FakeFDB(ok=True)
    eng = DeliveryJobEngine(db, fdb_ok)
    with _LogCap() as capB2:
        stats = await eng.sweep_once()
    row = await db.get_delivery_job(j_open)
    check("B2 a confirmed delete settles the row (deleted_at recorded, "
          "DELIVERED-with-user_message_id preserved, ttl_deleted=1, and "
          "the row leaves relay_open)",
          stats["ttl_deleted"] == 1 and stats["ttl_deferred"] == 0
          and row["deleted_at"] is not None
          and str(row["status"]) == JOB_DELIVERED
          and row["user_message_id"] == 77
          and not capB2.has("DELIVERY_TTL_SETTLE_DEFERRED")
          and j_open not in [int(r["id"]) for r in
                             await db.list_delivery_jobs(relay_open=True)],
          f"stats={stats}")

    # B3 — an UNCONFIRMED delete (RELAY_DELETE_FAILED class) defers:
    # DELIVERY_TTL_SETTLE_DEFERRED + the row stays relay-open.
    fdb_no = _FakeFDB(ok=False)
    eng_no = DeliveryJobEngine(db, fdb_no)
    j_fail = await _job(rmid=66)
    with _LogCap() as capB3:
        stats3 = await eng_no.sweep_once()
    row3 = await db.get_delivery_job(j_fail)
    defer_lines = capB3.grab("DELIVERY_TTL_SETTLE_DEFERRED")
    check("B3 an unconfirmed delete NEVER silently settles "
          "(DELIVERY_TTL_SETTLE_DEFERRED + the row stays relay-open with "
          "the durable marker + bounded next_retry_at)",
          stats3["ttl_deleted"] == 0 and stats3["ttl_deferred"] == 1
          and len(defer_lines) == 1 and "tries=1" in defer_lines[0]
          and row3["deleted_at"] is None
          and str(row3["last_error"]).startswith(TTL_SETTLE_DEFER_MARKER)
          and row3["next_retry_at"] is not None
          and j_fail in [int(r["id"]) for r in
                         await db.list_delivery_jobs(relay_open=True)],
          f"stats={stats3}")

    # B4 — a deferred row WAITS OUT its backoff (no re-attempt before
    # next_retry_at).
    calls_before = fdb_no.calls
    stats4 = await eng_no.sweep_once()
    check("B4 the deferred row waits out its bounded backoff (the sweep "
          "skips it before next_retry_at — no delete re-attempt)",
          stats4["ttl_deferred"] == 0 and fdb_no.calls == calls_before,
          f"stats={stats4} fdb_delta={fdb_no.calls - calls_before}")

    # B5 — once the backoff elapses the delete IS retried and the
    # backoff doubles (tries=2).
    past = "2020-01-01T00:00:00+00:00"
    await db.update_delivery_job(j_fail, next_retry_at=past)
    calls5 = fdb_no.calls
    with _LogCap() as capB5:
        stats5 = await eng_no.sweep_once()
    row5 = await db.get_delivery_job(j_fail)
    d5 = capB5.grab("DELIVERY_TTL_SETTLE_DEFERRED")
    check("B5 backoff expiry -> the delete is retried and the marker "
          "doubles (tries=2, ~2x base delay)",
          fdb_no.calls == calls5 + 1 and stats5["ttl_deferred"] == 1
          and len(d5) == 1 and "tries=2" in d5[0]
          and str(row5["last_error"]) == f"{TTL_SETTLE_DEFER_MARKER}:2",
          f"d={d5[:1]}")

    # B6 — the backoff is BOUNDED (capped at TTL_SETTLE_DEFER_MAX).
    await db.update_delivery_job(
        j_fail, last_error=f"{TTL_SETTLE_DEFER_MARKER}:6",
        next_retry_at=past)
    from datetime import datetime, timedelta, timezone as _tz
    t0 = datetime.now(_tz.utc)
    with _LogCap() as capB6:
        await eng_no.sweep_once()
    row6 = await db.get_delivery_job(j_fail)
    d6 = capB6.grab("DELIVERY_TTL_SETTLE_DEFERRED")
    nra = datetime.fromisoformat(row6["next_retry_at"])
    cap_delay = (nra - t0).total_seconds()
    check("B6 the deferred backoff is bounded (tries=7 -> delay capped at "
          f"{int(TTL_SETTLE_DEFER_MAX)}s, never exponential runaway)",
          len(d6) == 1 and "tries=7" in d6[0]
          and TTL_SETTLE_DEFER_BASE == 60.0
          and 0 <= cap_delay <= TTL_SETTLE_DEFER_MAX + 5,
          f"delay={cap_delay:.0f}s")

    # B7 — retry_pending_deletion records attempts + last_error durably
    # (schema v47) with a bounded exponential schedule.
    from app.presentation.telegram.state import (
        AUTO_DELETE_MAX_ATTEMPTS, AUTO_DELETE_RETRY_BASE_DELAY,
        AUTO_DELETE_RETRY_MAX_DELAY)
    rid = await db.add_pending_deletion(-10045678002, 4242,
                                        int(time.time()) - 10, "delivery")
    r1 = await db.retry_pending_deletion(rid, error="timeout")
    cur = await db.conn.execute(
        "SELECT attempts, last_error, delete_at FROM pending_deletions "
        "WHERE id = ?", (rid,))
    prow = await cur.fetchone()
    delay1 = int(r1["delay"])
    r2 = await db.retry_pending_deletion(rid, error="network")
    delay2 = int(r2["delay"])
    check("B7 retry_pending_deletion records attempts + last_error "
          "durably (v47) with a doubling, capped backoff",
          r1["ok"] and r1["attempts"] == 1
          and prow["attempts"] == 1 and prow["last_error"] == "timeout"
          and prow["delete_at"] is not None
          and delay1 == AUTO_DELETE_RETRY_BASE_DELAY
          and r2["attempts"] == 2
          and delay2 == AUTO_DELETE_RETRY_BASE_DELAY * 2
          and AUTO_DELETE_RETRY_MAX_DELAY == 3600,
          f"delays={delay1}/{delay2}")

    # B8 — the bounded give-up (max attempts -> the row is removed).
    keep = True
    while keep:
        rr = await db.retry_pending_deletion(rid, error="timeout")
        keep = not rr.get("gave_up")
    gone = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM pending_deletions WHERE id = ?", (rid,))
    check("B8 the bounded give-up fires at AUTO_DELETE_MAX_ATTEMPTS "
          "(the row is removed — a dead target can never spin forever)",
          rr["gave_up"] is True and rr["attempts"] == AUTO_DELETE_MAX_ATTEMPTS
          and int((await gone.fetchone())["c"]) == 0,
          f"attempts={rr.get('attempts')}")

    # B9 — the classified delete: ok + the idempotent already-gone verdict.
    ns._pending_deletion_tasks.clear()
    rid_ok = await db.add_pending_deletion(-10045678003, 5001,
                                           int(time.time()) - 10,
                                           "delivery")
    with _LogCap() as capB9:
        out_ok = await ns._execute_pending_deletion(
            _DelBot(), rid_ok, -10045678003, 5001, "delivery")
    rid_gone = await db.add_pending_deletion(-10045678003, 5002,
                                             int(time.time()) - 10,
                                             "delivery")
    with _LogCap() as capB9b:
        out_gone = await ns._execute_pending_deletion(
            _DelBot(BadRequest("message to delete not found")), rid_gone,
            -10045678003, 5002, "delivery")
    left = await db.count_pending_deletions()
    check("B9 the classified delete: ok and the idempotent "
          "already-gone verdict both settle (AUTO_DELETE_SETTLED, "
          "idempotent=1 for already-gone)",
          out_ok == "settled" and out_gone == "settled"
          and capB9.has("AUTO_DELETE_SETTLED")
          and "idempotent=1" in capB9b.grab("AUTO_DELETE_SETTLED")[0]
          and "reason=already_gone" in capB9b.grab(
              "AUTO_DELETE_SETTLED")[0] and left == 0,
          f"out={out_ok}/{out_gone}")

    # B10 — the classified RETRY (TimedOut): the row STAYS pending with
    # attempts/last_error + AUTO_DELETE_RETRY_SCHEDULED.
    ns._pending_deletion_tasks.clear()
    rid_t = await db.add_pending_deletion(-10045678004, 6001,
                                          int(time.time()) - 10, "delivery")
    with _LogCap() as capB10:
        out_t = await ns._execute_pending_deletion(
            _DelBot(TimedOut()), rid_t, -10045678004, 6001, "delivery")
    cur = await db.conn.execute(
        "SELECT attempts, last_error FROM pending_deletions WHERE id = ?",
        (rid_t,))
    trow = await cur.fetchone()
    sched = capB10.grab("AUTO_DELETE_RETRY_SCHEDULED")
    task = ns._pending_deletion_tasks.get((-10045678004, 6001))
    check("B10 the classified RETRY (TimedOut): the row stays pending "
          "with attempts=1 + last_error=timeout and a fresh bounded timer "
          "(AUTO_DELETE_RETRY_SCHEDULED)",
          out_t == "deferred" and len(sched) == 1
          and "reason=timeout" in sched[0]
          and trow["attempts"] == 1 and trow["last_error"] == "timeout"
          and task is not None and not task.done())
    if task is not None:
        task.cancel()
    # fixture hygiene: B10 proved the row STAYS pending on the classified
    # retry plane; remove the fixture row now so B12/B13 below measure
    # ONLY the restart-recovery scenario (the suite recreates the DB per
    # run — this is cleanup of the shared throwaway DB, not a behavior
    # pin).
    await db.remove_pending_deletion_by_id(rid_t)

    # B11 — the classified PERMANENT (Forbidden): gave up immediately.
    rid_f = await db.add_pending_deletion(-10045678004, 6002,
                                          int(time.time()) - 10, "delivery")
    with _LogCap() as capB11:
        out_f = await ns._execute_pending_deletion(
            _DelBot(Forbidden("bot was kicked from the group")), rid_f,
            -10045678004, 6002, "delivery")
    check("B11 the classified PERMANENT (Forbidden): "
          "AUTO_DELETE_GAVE_UP + the row is removed (a retry can never "
          "succeed)",
          out_f == "gave_up" and capB11.has("AUTO_DELETE_GAVE_UP")
          and "reason=forbidden" in capB11.grab("AUTO_DELETE_GAVE_UP")[0],
          f"out={out_f}")

    # B12 — restart recovery routes through the SAME classified path.
    ns._pending_deletion_tasks.clear()
    rid_r1 = await db.add_pending_deletion(-10045678005, 7001,
                                           int(time.time()) - 10,
                                           "delivery")
    rid_r2 = await db.add_pending_deletion(-10045678005, 7002,
                                           int(time.time()) - 10,
                                           "delivery")

    class _MixedBot:
        def __init__(self):
            self.fail_once = True

        async def delete_message(self, chat_id, message_id):
            if self.fail_once and message_id == 7002:
                self.fail_once = False
                raise NetworkError("dns resolution failed")
            return True

    with _LogCap() as capB12:
        immediate, resched = await ns.recover_pending_deletions(_MixedBot())
    cur = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM pending_deletions WHERE id = ?",
        (rid_r1,))
    gone_r1 = int((await cur.fetchone())["c"]) == 0
    cur = await db.conn.execute(
        "SELECT attempts, last_error FROM pending_deletions WHERE id = ?",
        (rid_r2,))
    r2row = await cur.fetchone()
    task2 = ns._pending_deletion_tasks.get((-10045678005, 7002))
    if task2 is not None:
        task2.cancel()
    check("B12 restart recovery uses the CLASSIFIED path (a due row with "
          "a transient DNS failure STAYS pending + "
          "AUTO_DELETE_RETRY_SCHEDULED; a confirmed one settles)",
          immediate == 1 and resched == 0 and gone_r1
          and r2row["attempts"] == 1
          and r2row["last_error"] == "network"
          and capB12.has("AUTO_DELETE_RETRY_SCHEDULED")
          and task2 is not None,
          f"immediate={immediate} resched={resched}")
    ns._pending_deletion_tasks.clear()

    # B13 — pending_deletion_stats: the safe aggregate diagnostic.
    stx = await db.pending_deletion_stats()
    check("B13 pending_deletion_stats aggregates the retry health (safe "
          "counters only)",
          isinstance(stx, dict)
          and set(stx) == {"total", "due", "upcoming", "failed",
                           "exhausted", "max_attempts_seen"}
          and stx["total"] == 1 and stx["failed"] == 1
          and stx["max_attempts_seen"] == 1, f"stats={stx}")


class _DelBot:
    def __init__(self, exc=None):
        self.exc = exc
        self.calls = 0

    async def delete_message(self, chat_id, message_id):
        self.calls += 1
        if self.exc is not None:
            raise self.exc
        return True


# ===========================================================================
# [C] MAIN MINI APP — the one canonical link (master prompt §14 / §36 43-49)
# ===========================================================================
async def section_c(ns, db):
    print("\n[C] Main Mini App — canonical t.me link construction")
    from app.network import bot_miniapp as _bm

    # C1 — the canonical MAIN form.
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_BOT_USERNAME,
                         "CfgMainBot")
    with _LogCap() as capC1:
        link = await _bm.build_main_mini_app_link(db, None)
    b1 = capC1.grab("MINI_APP_LINK_BUILD")
    check("C1 the canonical main form: https://t.me/<configured "
          "bot>?startapp (startapp present, no path segment)",
          link == "https://t.me/CfgMainBot?startapp"
          and len(b1) == 1 and "link_type=main" in b1[0]
          and "bot_username=CfgMainBot" in b1[0]
          and "destination=https://t.me/CfgMainBot?startapp" in b1[0],
          f"link={link}")

    # C2 — the DIRECT form exists ONLY where actually configured.
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_DIRECT_SHORT_NAME,
                         "app")
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_DIRECT_STARTAPP,
                         "pay_load/1")
    link_d = await _bm.build_main_mini_app_link(db, None)
    # a whitespace-bearing parameter is refused HONESTLY (the parameter
    # is dropped + MINI_APP_LINK_CONFIG_INVALID — the link still opens
    # the Mini App; never a broken URL)
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_DIRECT_STARTAPP,
                         "pay load/1")
    with _LogCap() as capC2b:
        link_ws = await _bm.build_main_mini_app_link(db, None)
    ws_bad = capC2b.grab("MINI_APP_LINK_CONFIG_INVALID")
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_DIRECT_SHORT_NAME, "")
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_DIRECT_STARTAPP, "")
    link_m = await _bm.build_main_mini_app_link(db, None)
    check("C2 the named-direct form only when configured "
          "(t.me/<bot>/<short>?startapp=<percent-encoded param>; without "
          "the short name the main form returns; a whitespace parameter "
          "is dropped honestly, never rendered broken)",
          link_d == "https://t.me/CfgMainBot/app?startapp=pay_load%2F1"
          and link_ws == "https://t.me/CfgMainBot/app?startapp"
          and any("reason=bad_startapp_param" in m for m in ws_bad)
          and link_m == "https://t.me/CfgMainBot?startapp",
          f"direct={link_d} ws={link_ws}")

    # C3 — None when unresolvable (NEVER a guessed username).
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_BOT_USERNAME, "")
    prev_un, prev_me = getattr(ns, "BOT_USERNAME", None), \
        getattr(ns, "_MAIN_BOT_ME", None)
    ns.BOT_USERNAME = ""
    ns._MAIN_BOT_ME = None
    with _LogCap() as capC3:
        none_link = await _bm.build_main_mini_app_link(db, ns)
    ns.BOT_USERNAME = prev_un
    ns._MAIN_BOT_ME = prev_me
    check("C3 unresolvable -> None (MINI_APP_LINK_UNRESOLVED; the caller "
          "shows the admin configuration error — never a fabricated link)",
          none_link is None and capC3.has("MINI_APP_LINK_UNRESOLVED"),
          f"link={none_link}")

    # C4 — the runtime MAIN-bot identity tier (network workers share the
    # namespace: this is the MAIN bot's username, never a worker's).
    ns.BOT_USERNAME = "RuntimeMainBot"
    try:
        link_rt = await _bm.build_main_mini_app_link(db, ns)
    finally:
        ns.BOT_USERNAME = prev_un
    check("C4 the runtime main-bot identity tier resolves "
          "(t.me/<MAIN bot>?startapp)",
          link_rt == "https://t.me/RuntimeMainBot?startapp",
          f"link={link_rt}")

    # C5 — an explicit-but-garbage config is refused honestly.
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_BOT_USERNAME,
                         "not a bot username!!")
    ns.BOT_USERNAME = "RuntimeMainBot"
    with _LogCap() as capC5:
        link_bad = await _bm.build_main_mini_app_link(db, ns)
    ns.BOT_USERNAME = prev_un
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_BOT_USERNAME, "")
    check("C5 a malformed explicit config is refused honestly "
          "(MINI_APP_LINK_CONFIG_INVALID + fall-through to the runtime "
          "identity — never used verbatim)",
          link_bad == "https://t.me/RuntimeMainBot?startapp"
          and capC5.has("MINI_APP_LINK_CONFIG_INVALID"),
          f"link={link_bad}")

    # C6 — the sentinel-shaped usernames NEVER produce a t.me link
    # (no t.me/undefined).
    for sentinel in ("undefined", "your_bot", "placeholder"):
        await db.set_setting(_bm.SETTING_MAIN_MINI_APP_BOT_USERNAME,
                             sentinel)
        ns.BOT_USERNAME = ""
        s_link = await _bm.build_main_mini_app_link(db, ns)
        if s_link is not None:
            break
    ns.BOT_USERNAME = prev_un
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_BOT_USERNAME, "")
    check("C6 sentinel-shaped usernames never produce a link "
          "(no https://t.me/undefined?startapp — §14)",
          s_link is None, f"link={s_link}")

    # C7 — the Worker URL is NEVER the Telegram destination.
    await db.set_setting("website_public_base_url",
                         "https://worker.bot45.example.workers.dev")
    worker_url = await _bm.canonical_main_app_url(db)
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_BOT_USERNAME,
                         "CfgMainBot")
    t_link = await _bm.build_main_mini_app_link(db, None)
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_BOT_USERNAME, "")
    await db.set_setting("website_public_base_url", "")
    check("C7 the Worker URL stays the internal browser fallback "
          "(canonical <base>/site) and is NEVER the Telegram destination",
          worker_url == "https://worker.bot45.example.workers.dev/site"
          and t_link == "https://t.me/CfgMainBot?startapp"
          and t_link != worker_url
          and "workers.dev" not in t_link,
          f"worker={worker_url}")

    # C8 — describe_main_mini_app_link: the safe telemetry fields.
    f_main = _bm.describe_main_mini_app_link(
        "https://t.me/CfgMainBot?startapp")
    f_dir = _bm.describe_main_mini_app_link(
        "https://t.me/CfgMainBot/app?startapp=x")
    check("C8 describe_main_mini_app_link derives the safe fields "
          "(bot_username/link_type/startapp_present/destination for BOTH "
          "forms)",
          f_main["bot_username"] == "CfgMainBot"
          and f_main["link_type"] == "main"
          and f_main["startapp_present"] == "true"
          and f_dir["link_type"] == "direct"
          and f_dir["destination"] == "https://t.me/CfgMainBot/app"
          "?startapp=x",
          f"main={f_main}")

    # C9 — the namespace facade (the surface every user-facing button
    # uses): MAIN_APP_OPEN on success, MAIN_APP_OPEN_UNRESOLVED otherwise.
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_BOT_USERNAME, "")
    ns.BOT_USERNAME = ""
    ns._MAIN_BOT_ME = None
    with _LogCap() as capC9a:
        no_link = await ns._net_main_app_link(12345, "probe_panel")
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_BOT_USERNAME,
                         "CfgMainBot")
    with _LogCap() as capC9b:
        yes_link = await ns._net_main_app_link(12345, "probe_panel")
    await db.set_setting(_bm.SETTING_MAIN_MINI_APP_BOT_USERNAME, "")
    ns.BOT_USERNAME = prev_un
    open_l = capC9b.grab("MAIN_APP_OPEN")
    check("C9 the _net_main_app_link facade: MAIN_APP_OPEN (safe fields) "
          "when resolvable, MAIN_APP_OPEN_UNRESOLVED + None when not",
          no_link is None and capC9a.has("MAIN_APP_OPEN_UNRESOLVED")
          and yes_link == "https://t.me/CfgMainBot?startapp"
          and len(open_l) == 1 and "surface=probe_panel" in open_l[0]
          and "bot_username=CfgMainBot" in open_l[0],
          f"open={open_l[:1]}")


# ===========================================================================
# [D] STORAGE — the canonical CURRENT source filename (Task D / §36 15-19)
# ===========================================================================
async def section_d(ns, db):
    print("\n[D] Storage — display_name provenance + live source resolve")
    from app.storage.repositories.payloads import (
        DISPLAY_NAME_ORIGIN_SOURCE, DISPLAY_NAME_ORIGIN_ADMIN_OVERRIDE,
        normalize_display_name_origin)
    from app.core.payload.service import sanitize_slug
    from app.presentation.telegram import text_input as _ti

    CH = -1005551001

    # D1 — create_payload marks the provenance (v47 vocabulary only).
    pk1 = await _seed_indexed(db, CH, 11, "DUID_D1", "FID_D1",
                              "d_one.mp4")
    p_src = await db.create_payload("b45_d_src", pk1,
                                    display_name="d_one",
                                    display_name_origin="source")
    p_adm = await db.create_payload("b45_d_adm", pk1,
                                    display_name="Admin Title",
                                    display_name_origin="ADMIN_OVERRIDE")
    p_leg = await db.create_payload("b45_d_legacy", pk1)
    check("D1 create_payload marks display_name_origin (source / "
          "admin_override normalized; unknown -> NULL; legacy callers "
          "stay NULL)",
          await db.get_payload_display_name_origin(p_src) == "source"
          and await db.get_payload_display_name_origin(p_adm) \
          == "admin_override"
          and await db.get_payload_display_name_origin(p_leg) is None
          and normalize_display_name_origin("ADMIN_OVERRIDE")
          == DISPLAY_NAME_ORIGIN_ADMIN_OVERRIDE
          and normalize_display_name_origin("bogus") is None
          and normalize_display_name_origin(None) is None)

    # D2 — the origin round-trip setter.
    await db.set_payload_display_name_origin(p_leg, "admin_override")
    o2 = await db.get_payload_display_name_origin(p_leg)
    await db.set_payload_display_name_origin(p_leg, "nonsense")
    o2b = await db.get_payload_display_name_origin(p_leg)
    await db.set_payload_display_name_origin(p_leg, None)
    check("D2 set_payload_display_name_origin round-trips (vocabulary-"
          "normalized; unknown stores NULL)",
          o2 == "admin_override" and o2b is None
          and await db.get_payload_display_name_origin(p_leg) is None)

    # D3/D4/D5 — ORIGIN-AWARE propagation through the repo surface.
    pk2 = await _seed_indexed(db, CH, 12, "DUID_D2", "FID_D2",
                              "old clip name.mp4")
    p_kept = await db.create_payload(
        "b45_d_kept", pk2, display_name=sanitize_slug("old clip name.mp4"))
    p_over = await db.create_payload(
        "b45_d_over", pk2, display_name="Curated Keep",
        display_name_origin="admin_override")
    p_custom = await db.create_payload(
        "b45_d_custom", pk2, display_name="custom source value",
        display_name_origin="source")
    await db.create_website_payload(payload_id=p_kept,
                                    title="old clip name.mp4",
                                    published=1, created_by=1)
    await db.create_collection("b45_d_coll", CH, [13])
    await db.create_website_payload(collection_id="b45_d_coll",
                                    title="Curated Package Title",
                                    published=1, created_by=1)
    with _LogCap() as capD3:
        prop = await db.refresh_source_derived_display_name(
            pk2, "new clip name.mp4", old_name="old clip name.mp4")
    kept_row = await db.get_payload_by_id(p_kept)
    over_row = await db.get_payload_by_id(p_over)
    custom_row = await db.get_payload_by_id(p_custom)
    wl = await db.find_website_payload_for_canonical(payload_id=p_kept)
    cl = await db.find_website_payload_for_canonical(
        collection_id="b45_d_coll")
    check("D3 origin-aware propagation: NULL/'source' rows still carrying "
          "the source-derived default are refreshed + stamped "
          "display_name_origin='source' (PAYLOAD_DISPLAY_NAME_RESOLVE)",
          prop["payload_ids"] == [p_kept]
          and str(kept_row["display_name"]) \
          == sanitize_slug("new clip name.mp4")
          and str(kept_row["display_name_origin"]) == \
          DISPLAY_NAME_ORIGIN_SOURCE
          and capD3.has("PAYLOAD_DISPLAY_NAME_RESOLVE")
          and "display_name_origin=source" in capD3.grab(
              "PAYLOAD_DISPLAY_NAME_RESOLVE")[0],
          f"prop={prop}")
    check("D4 'admin_override' rows are preserved VERBATIM (and a "
          "non-default 'source' value is never clobbered)",
          str(over_row["display_name"]) == "Curated Keep"
          and str(over_row["display_name_origin"]) \
          == DISPLAY_NAME_ORIGIN_ADMIN_OVERRIDE
          and str(custom_row["display_name"]) == "custom source value")
    check("D5 the single-payload listing title follows the rename "
          "(raw old -> raw new) and the COLLECTION listing is never "
          "touched",
          str(wl["title"]) == "new clip name.mp4"
          and prop["listing_ids"] == [int(wl["id"])]
          and str(cl["title"]) == "Curated Package Title",
          f"title={wl['title']}")

    # D6 — the LIVE re-resolve: same identity -> refreshed (the wizard's
    # "Selected File" shows the CURRENT source filename).
    pk3 = await _seed_indexed(db, CH, 14, "DUID_D3", "FID_D3",
                              "stale edited name.mp4")
    await db.create_payload("b45_d_live", pk3,
                            display_name=sanitize_slug(
                                "stale edited name.mp4"))

    async def _fetch_same(bot, admin, ch, mid):
        return ({"file_unique_id": "DUID_D3", "file_id": "FID_D3",
                 "media_type": "video", "file_name":
                 "current edited name.mp4", "file_size": 999,
                 "mime_type": "video/mp4"}, None)

    fr = {"id": pk3, "file_unique_id": "DUID_D3",
          "file_name": "stale edited name.mp4", "media_type": "video"}
    with _LogCap() as capD6:
        res = await _ti._live_refresh_source_identity(
            None, 8370454312, CH, 14, fr, db=db,
            fetch_media=_fetch_same)
    row3 = await db.get_indexed_file_by_id(pk3)
    prow3 = await db.get_payload_by_id(
        (await db.find_single_payload_by_channel_message(CH, 14))["id"])
    check("D6 same-identity live resolve -> outcome=refreshed "
          "(STORAGE_SOURCE_RESOLVE_START/RESULT + STORAGE_FILENAME_SOURCE "
          "+ the CURRENT filename on the canonical row + origin-gated "
          "display refresh)",
          res["outcome"] == "refreshed"
          and capD6.has("STORAGE_SOURCE_RESOLVE_START")
          and capD6.has("STORAGE_SOURCE_RESOLVE_RESULT")
          and capD6.has("STORAGE_FILENAME_SOURCE")
          and str(row3["file_name"]) == "current edited name.mp4"
          and str(prow3["display_name"]) == sanitize_slug(
              "current edited name.mp4")
          and res["source_filename"] == "current edited name.mp4",
          f"outcome={res['outcome']}")

    # D7 — NEW identity at the same (channel, message): the guarded
    # in-place replacement.
    pk4 = await _seed_indexed(db, CH, 15, "DUID_D4_OLD", "FID_D4",
                              "replaced old name.mp4")
    await db.create_payload("b45_d_rep", pk4,
                            display_name=sanitize_slug(
                                "replaced old name.mp4"))
    await db.create_website_payload(payload_id=(await db.get_payload(
        "b45_d_rep"))["id"], title="replaced old name.mp4",
        published=1, created_by=1)

    async def _fetch_new(bot, admin, ch, mid):
        return ({"file_unique_id": "DUID_D4_NEW", "file_id": "FID_D4B",
                 "media_type": "video", "file_name":
                 "replaced new name.mp4", "file_size": 5555,
                 "mime_type": "video/mp4"}, None)

    fr4 = {"id": pk4, "file_unique_id": "DUID_D4_OLD",
           "file_name": "replaced old name.mp4", "media_type": "video"}
    with _LogCap() as capD7:
        res4 = await _ti._live_refresh_source_identity(
            None, 8370454312, CH, 15, fr4, db=db,
            fetch_media=_fetch_new)
    row4 = await db.get_indexed_file_by_id(pk4)
    prow4 = await db.get_payload("b45_d_rep")
    wl4 = await db.find_website_payload_for_canonical(
        payload_id=int(prow4["id"]))
    check("D7 a NEW file_unique_id at the same (channel, message) -> "
          "outcome=replaced (INDEX_REPLACE_SOURCE_MEDIA_START/_COMPLETE, "
          "file_pk + payload FK + listing preserved, the CURRENT source "
          "filename propagates)",
          res4["outcome"] == "replaced"
          and capD7.has("INDEX_REPLACE_SOURCE_MEDIA_START")
          and capD7.has("INDEX_REPLACE_SOURCE_MEDIA_COMPLETE")
          and int(row4["id"]) == pk4
          and str(row4["file_unique_id"]) == "DUID_D4_NEW"
          and str(row4["file_name"]) == "replaced new name.mp4"
          and int(prow4["index_id"]) == pk4
          and str(prow4["display_name"]) == sanitize_slug(
              "replaced new name.mp4")
          and str(wl4["title"]) == "replaced new name.mp4"
          and res4["source_filename"] == "replaced new name.mp4",
          f"outcome={res4['outcome']}")

    # D8/D9/D10 — the classified skips (STORAGE_MESSAGE_SKIP with a
    # reason_code from the allowed set — NEVER silent).
    async def _fetch_none(bot, admin, ch, mid):
        return (None, None)

    async def _fetch_raise(bot, admin, ch, mid):
        raise RuntimeError("transport exploded")

    def _probe(verdict):
        # probe_exists takes the FUNCTION (bot, admin, ch, mid) ->
        # True/False — NOT a coroutine: _live_refresh_source_identity
        # calls it directly, so the helper must be sync.
        async def _p(bot, admin, ch, mid):
            return verdict
        return _p

    pk8 = await _seed_indexed(db, CH, 16, "DUID_D8", "FID_D8", "s8.mp4")
    fr8 = {"id": pk8, "file_unique_id": "DUID_D8", "file_name": "s8.mp4",
           "media_type": "video"}
    with _LogCap() as capD8:
        res8 = await _ti._live_refresh_source_identity(
            None, 8370454312, CH, 16, fr8, db=db,
            fetch_media=_fetch_none, probe_exists=_probe(False))
    skip8 = capD8.grab("STORAGE_MESSAGE_SKIP")
    check("D8 a GONE source message -> skipped with reason_code=NO_MESSAGE "
          "(from the allowed set; never silent)",
          res8["outcome"] == "skipped"
          and res8["reason_code"] == "NO_MESSAGE"
          and len(skip8) == 1 and "reason_code=NO_MESSAGE" in skip8[0],
          f"skip={skip8[:1]}")

    with _LogCap() as capD9:
        res9 = await _ti._live_refresh_source_identity(
            None, 8370454312, CH, 16, fr8, db=db,
            fetch_media=_fetch_none, probe_exists=_probe(True))
        res9b = await _ti._live_refresh_source_identity(
            None, 8370454312, CH, 16, fr8, db=db, fetch_media=_fetch_raise)
    check("D9 a message with NO media -> NO_MEDIA; a transport failure -> "
          "TELEGRAM_ERROR (both classified, allowed vocabulary)",
          res9["reason_code"] == "NO_MEDIA"
          and res9b["reason_code"] == "TELEGRAM_ERROR"
          and any("reason_code=NO_MEDIA" in m
                  for m in capD9.grab("STORAGE_MESSAGE_SKIP"))
          and any("reason_code=TELEGRAM_ERROR" in m
                  for m in capD9.grab("STORAGE_MESSAGE_SKIP")),
          f"codes={res9['reason_code']}/{res9b['reason_code']}")

    async def _fetch_no_fid(bot, admin, ch, mid):
        return ({"file_unique_id": "DUID_X", "media_type": "video",
                 "file_name": "x.mp4"}, None)

    async def _fetch_no_uid(bot, admin, ch, mid):
        return ({"file_id": "FID_Y", "media_type": "video",
                 "file_name": "y.mp4"}, None)

    with _LogCap() as capD10:
        res_a = await _ti._live_refresh_source_identity(
            None, 8370454312, CH, 16, fr8, db=db,
            fetch_media=_fetch_no_fid)
        res_b = await _ti._live_refresh_source_identity(
            None, 8370454312, CH, 16, fr8, db=db,
            fetch_media=_fetch_no_uid)
    codes = {res_a["reason_code"], res_b["reason_code"]}
    check("D10 a fresh fetch missing its Telegram identity is refused "
          "(MISSING_FILE_ID / MISSING_FILE_UNIQUE_ID — a phantom is never "
          "indexed)",
          codes == {"MISSING_FILE_ID", "MISSING_FILE_UNIQUE_ID"}
          and any("reason_code=MISSING_FILE" in m
                  for m in capD10.grab("STORAGE_MESSAGE_SKIP")),
          f"codes={codes}")

    # D11 — the reason vocabulary is COERCED (an internal caller can
    # never invent a free-form reason) + the honest admin notice lines.
    capD11 = []
    lh = logging.Handler()
    lh.emit = lambda rec: capD11.append(rec.getMessage())
    lg = logging.getLogger("payload-bot")
    lg.addHandler(lh)
    try:
        _ti._log_storage_message_skip(lg, CH, 99, "TOTALLY_BOGUS")
        _ti._log_storage_message_skip(lg, CH, 99, None)
    finally:
        lg.removeHandler(lh)
    notice_rep = _ti._live_refresh_notice(res4)
    notice_skip = _ti._live_refresh_notice(res8)
    notice_quiet = _ti._live_refresh_notice({"outcome": "unchanged"})
    check("D11 the skip vocabulary is coerced (unknown -> OTHER) and "
          "_live_refresh_notice renders the honest one-line admin notices",
          all("reason_code=OTHER" in m for m in capD11)
          and "replaced in place" in notice_rep
          and "no longer exists" in notice_skip
          and notice_quiet is None,
          f"lines={capD11[:1]}")

    # D12 — a duplicate canonical identity is detected, not replaced.
    pk12 = await _seed_indexed(db, CH, 17, "DUID_D12", "FID_D12",
                               "dup12.mp4")

    async def _fetch_dup(bot, admin, ch, mid):
        return ({"file_unique_id": "DUID_D4_NEW", "file_id": "FID_DUP",
                 "media_type": "video", "file_name": "dup new.mp4",
                 "file_size": 5, "mime_type": "video/mp4"}, None)

    fr12 = {"id": pk12, "file_unique_id": "DUID_D12",
            "file_name": "dup12.mp4", "media_type": "video"}
    with _LogCap() as capD12:
        res12 = await _ti._live_refresh_source_identity(
            None, 8370454312, CH, 17, fr12, db=db,
            fetch_media=_fetch_dup)
    row12 = await db.get_indexed_file_by_id(pk12)
    check("D12 a fresh identity already owned by another canonical row -> "
          "DUPLICATE_CANONICAL_MEDIA (UNIQUE(file_unique_id) semantics "
          "intact, the row is untouched)",
          res12["outcome"] == "skipped"
          and res12["reason_code"] == "DUPLICATE_CANONICAL_MEDIA"
          and any("reason_code=DUPLICATE_CANONICAL_MEDIA" in m
                  for m in capD12.grab("STORAGE_MESSAGE_SKIP"))
          and str(row12["file_unique_id"]) == "DUID_D12",
          f"code={res12['reason_code']}")


# ===========================================================================
# [E] SOURCE MEDIA REPLACEMENT — the verification engine (Task E / §36 20-25)
# ===========================================================================
async def section_e(ns, db):
    print("\n[E] Verification engine — in-place replacement + diagnostics")
    from app.core.verification.engine import Deps, run_verification
    from app.core.payload.service import sanitize_slug

    ADMIN = 8370454312
    log = logging.getLogger("payload-bot")
    LIVE: dict = {}        # channel_id -> {message_id: info}

    async def _fetch(bot, admin, ch, mid):
        live = LIVE.get(int(ch)) or {}
        if mid in live:
            return (dict(live[mid]), None)
        return (None, None)

    async def _probe(bot, admin, ch, mid):
        live = LIVE.get(int(ch)) or {}
        return mid in live

    async def _latest(bot, admin, ch):
        live = LIVE.get(int(ch)) or {}
        return max(live.keys()) if live else None

    async def _index_one(bot, admin, ch, mid):
        return ("indexed", None)

    deps = Deps(db=db, logger=log, fetch_channel_media=_fetch,
                index_one_message=_index_one,
                probe_message_exists=_probe, determine_latest=_latest)
    bot = types.SimpleNamespace()

    # ---- E1/E2: the guarded IN-PLACE replacement (Phase D step 5) -----
    CH1 = -1005552001
    await db.add_storage_channel(CH1, "E One", None)
    pk = await _seed_indexed(db, CH1, 3, "UID_E1_OLD", "FID_E1_OLD",
                             "old_name_e1.mp4", status="unavailable")
    p_src = await db.create_payload(
        "b45_e_src", pk, display_name=sanitize_slug("old_name_e1.mp4"))
    p_adm = await db.create_payload(
        "b45_e_adm", pk, display_name="Admin Kept E1",
        display_name_origin="admin_override")
    await db.create_website_payload(payload_id=p_src,
                                    title="old_name_e1.mp4",
                                    published=1, created_by=1)
    LIVE[CH1] = {3: {"file_unique_id": "UID_E1_NEW", "file_id": "FID_E1_NEW",
                     "media_type": "video", "file_name": "new_name_e1.mp4",
                     "file_size": 2222, "mime_type": "video/mp4"}}
    with _LogCap() as capE1:
        rep = await run_verification(deps, bot, ADMIN, CH1,
                                     reconcile=True)
    row = await db.get_indexed_file_by_id(pk)
    p_src_row = await db.get_payload_by_id(p_src)
    p_adm_row = await db.get_payload_by_id(p_adm)
    wl = await db.find_website_payload_for_canonical(payload_id=p_src)
    cur = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM indexed_files WHERE file_unique_id=?",
        ("UID_E1_NEW",))
    dup_new = int((await cur.fetchone())["c"])
    check("E1 same (channel, message) + NEW file_unique_id -> the guarded "
          "IN-PLACE replacement (report source_replaced=1; "
          "INDEX_VERIFY_COMPLETE source_replaced=1; START/COMPLETE lines)",
          rep["source_replaced"] == 1
          and rep["source_changed_identity"] == 1
          and any(m.startswith("INDEX_VERIFY_COMPLETE")
                  and "source_replaced=1" in m for m in capE1.lines)
          and capE1.has("INDEX_REPLACE_SOURCE_MEDIA_START")
          and capE1.has("INDEX_REPLACE_SOURCE_MEDIA_COMPLETE"),
          f"rep={rep['source_replaced']}")
    check("E2 the replacement preserves file_pk + payload FKs + the "
          "website association (no second canonical row; the source-"
          "derived display follows, admin_override verbatim; a "
          "previously-unavailable row is honestly recovered)",
          int(row["id"]) == pk
          and str(row["file_unique_id"]) == "UID_E1_NEW"
          and str(row["file_name"]) == "new_name_e1.mp4"
          and dup_new == 1
          and int(p_src_row["index_id"]) == pk
          and str(p_src_row["display_name"]) == sanitize_slug(
              "new_name_e1.mp4")
          and str(p_adm_row["display_name"]) == "Admin Kept E1"
          and str(p_adm_row["display_name_origin"]) == "admin_override"
          and str(wl["title"]) == "new_name_e1.mp4"
          and str(row["source_status"]) == "available",
          f"status={row['source_status']}")
    start_line = capE1.grab("INDEX_REPLACE_SOURCE_MEDIA_START")[0]
    h_old = hashlib.sha256(b"UID_E1_OLD").hexdigest()[:16]
    h_new = hashlib.sha256(b"UID_E1_NEW").hexdigest()[:16]
    check("E3 the replacement telemetry carries ONLY hashed identities "
          "(sha256[:16] old/new — the raw file ids NEVER logged)",
          f"old_file_unique_id_hash={h_old}" in start_line
          and f"new_file_unique_id_hash={h_new}" in start_line
          and "UID_E1_OLD" not in start_line
          and "UID_E1_NEW" not in start_line
          and "FID_E1" not in start_line,
          start_line[:120])

    # ---- E4: FAILED on a missing fresh identity (never fabricated) ----
    CH4 = -1005552004
    await db.add_storage_channel(CH4, "E Four", None)
    pk4 = await _seed_indexed(db, CH4, 4, "UID_E4_OLD", "FID_E4",
                              "keep_me_e4.mp4", media_type="video")
    LIVE[CH4] = {4: {"file_id": "FID_E4B", "media_type": "document",
                     "file_name": "no_identity_e4.bin", "file_size": 9}}
    with _LogCap() as capE4:
        rep4 = await run_verification(deps, bot, ADMIN, CH4,
                                      reconcile=True)
    row4 = await db.get_indexed_file_by_id(pk4)
    fail4 = [m for m in capE4.grab("INDEX_REPLACE_SOURCE_MEDIA_FAILED")]
    check("E4 a missing fresh identity -> FAILED (the canonical row keeps "
          "its identity — NEVER fabricated; reconcile_failed recorded)",
          rep4["source_replaced"] == 0
          and rep4["reconcile_failed"] >= 1
          and any("missing_fresh_identity" in m for m in fail4)
          and str(row4["file_unique_id"]) == "UID_E4_OLD",
          f"fails={fail4[:1]}")

    # ---- E5: FAILED on an identity conflict (UNIQUE preserved) --------
    CH5 = -1005552005
    await db.add_storage_channel(CH5, "E Five", None)
    pk5a = await _seed_indexed(db, CH5, 5, "UID_E5_A", "FID_E5A",
                               "conflict_a.mp4")
    pk5b = await _seed_indexed(db, CH5, 6, "UID_E5_NEW", "FID_E5B",
                               "conflict_b.mp4")
    LIVE[CH5] = {5: {"file_unique_id": "UID_E5_NEW", "file_id": "FID_X",
                     "media_type": "video", "file_name": "conflict_x.mp4",
                     "file_size": 1, "mime_type": "video/mp4"},
                 6: {"file_unique_id": "UID_E5_NEW", "file_id": "FID_E5B",
                     "media_type": "video", "file_name": "conflict_b.mp4",
                     "file_size": 1, "mime_type": "video/mp4"}}
    with _LogCap() as capE5:
        rep5 = await run_verification(deps, bot, ADMIN, CH5,
                                      reconcile=True)
    row5a, row5b = await db.get_indexed_file_by_id(pk5a), \
        await db.get_indexed_file_by_id(pk5b)
    conflict = [m for m in capE5.grab("INDEX_REPLACE_SOURCE_MEDIA_FAILED")
                if "identity_conflict" in m]
    check("E5 an identity conflict (the new uid already owned by another "
          "row) -> FAILED, both canonical rows intact",
          rep5["source_replaced"] == 0
          and len(conflict) == 1
          and str(row5a["file_unique_id"]) == "UID_E5_A"
          and str(row5b["file_unique_id"]) == "UID_E5_NEW"
          and int(row5b["id"]) == pk5b,
          f"conflict={conflict[:1]}")

    # ---- E6: payloads_on_unavailable PER-RECORD diagnostics ----------
    CH6 = -1005552006
    await db.add_storage_channel(CH6, "E Six", None)
    pk6 = await _seed_indexed(db, CH6, 5, "UID_E6", "FID_E6",
                              "gone_e6.mp4", status="unavailable")
    await db.create_payload("b45_e_gone", pk6,
                            display_name="gone payload")
    # The channel itself must be ALIVE (a NEWER live message 9 — the walk
    # + determine_latest must succeed or run_verification aborts at
    # reason=latest_unknown), while the indexed row's message 5 is GONE:
    # this pass then CONFIRMS it missing (the §8 per-record evidence).
    LIVE[CH6] = {9: {"file_unique_id": "UID_E6_NEWER", "file_id":
                     "FID_E6_NEWER", "media_type": "video",
                     "file_name": "newer_e6.mp4", "file_size": 77,
                     "mime_type": "video/mp4"}}
    with _LogCap() as capE6:
        rep6 = await run_verification(deps, bot, ADMIN, CH6,
                                      reconcile=True)
    diag = capE6.grab("PAYLOAD_ON_UNAVAILABLE")
    check("E6 payloads_on_unavailable carries PER-RECORD diagnostics "
          "(PAYLOAD_ON_UNAVAILABLE with payload/file/message identity + "
          "the exact reason derived from THIS pass's evidence)",
          rep6["payloads_on_unavailable"] == 1
          and len(diag) == 1
          and "payload=b45_e_gone" in diag[0]
          and f"file_pk={pk6}" in diag[0]
          and "reason=" in diag[0]
          and any("confirmed missing" in d for d in rep6[
              "payloads_on_unavailable_detail"]),
          f"diag={diag[:1]}")

    # ---- E7/E8: INDEX_REINDEX_METADATA_CHANGED / _UNCHANGED ----------
    # The §8 EDITED FILENAME TEST: the ONLY edit is the filename — the
    # seeded sizes match the live source so pk7a is the TRULY unchanged
    # row and pk7b the filename-edited one (fields=file_name exactly).
    CH7 = -1005552007
    await db.add_storage_channel(CH7, "E Seven", None)
    pk7a = await _seed_indexed(db, CH7, 6, "UID_E7A", "FID_E7A",
                               "same_name_e7.mp4", size=10)
    pk7b = await _seed_indexed(db, CH7, 7, "UID_E7B", "FID_E7B",
                               "edited_before_e7.mp4", size=20)
    LIVE[CH7] = {6: {"file_unique_id": "UID_E7A", "file_id": "FID_E7A",
                     "media_type": "video", "file_name": "same_name_e7.mp4",
                     "file_size": 10, "mime_type": "video/mp4"},
                 7: {"file_unique_id": "UID_E7B", "file_id": "FID_E7B",
                     "media_type": "video", "file_name":
                     "edited_after_e7.mp4", "file_size": 20,
                     "mime_type": "video/mp4"}}
    with _LogCap() as capE7:
        rep7 = await run_verification(deps, bot, ADMIN, CH7,
                                      reconcile=True)
    ch_lines = capE7.grab("INDEX_REINDEX_METADATA_CHANGED")
    un_lines = capE7.grab("INDEX_REINDEX_METADATA_UNCHANGED")
    row7b = await db.get_indexed_file_by_id(pk7b)
    check("E7 an EDITED filename (same identity) -> "
          "INDEX_REINDEX_METADATA_CHANGED fields=file_name with the "
          "file_pk/payload pin, refreshed in place",
          rep7["reindex_metadata_changed"] == 1
          and len(ch_lines) == 1 and "fields=file_name" in ch_lines[0]
          and "file_pk_preserved=1" in ch_lines[0]
          and "payload_preserved=1" in ch_lines[0]
          and str(row7b["file_name"]) == "edited_after_e7.mp4",
          f"ch={ch_lines[:1]}")
    check("E8 an unchanged row -> INDEX_REINDEX_METADATA_UNCHANGED with "
          "the pin (identity-immutable columns never touched)",
          rep7["reindex_metadata_unchanged"] == 1
          and len(un_lines) == 1
          and "file_pk_preserved=1" in un_lines[0]
          and "payload_preserved=1" in un_lines[0]
          and str((await db.get_indexed_file_by_id(pk7a))[
              "file_unique_id"]) == "UID_E7A",
          f"un={un_lines[:1]}")

    # ---- E9: the read-only pass emits the SAME telemetry, NO writes ---
    CH9 = -1005552009
    await db.add_storage_channel(CH9, "E Nine", None)
    pk9 = await _seed_indexed(db, CH9, 8, "UID_E9", "FID_E9",
                              "ro_before_e9.mp4")
    LIVE[CH9] = {8: {"file_unique_id": "UID_E9", "file_id": "FID_E9",
                     "media_type": "video", "file_name": "ro_after_e9.mp4",
                     "file_size": 30, "mime_type": "video/mp4"}}
    with _LogCap() as capE9:
        rep9 = await run_verification(deps, bot, ADMIN, CH9,
                                      reconcile=False)
    row9 = await db.get_indexed_file_by_id(pk9)
    ro = capE9.grab("INDEX_REINDEX_METADATA_CHANGED")
    check("E9 a read-only pass: the comparison telemetry is emitted but "
          "NOTHING is written (the row keeps its stored filename; "
          "Reconcile applies the refresh)",
          rep9["reindex_metadata_changed"] == 1
          and len(ro) == 1 and "read-only pass" in ro[0]
          and str(row9["file_name"]) == "ro_before_e9.mp4",
          f"ro={ro[:1]}")


# ===========================================================================
# [F] WIZARD TERMINALS (Task F / §36 26-30)
# ===========================================================================
async def section_f(ns, db):
    print("\n[F] Wizard — every attempt terminates, classified failures")
    from app.presentation.telegram import wizard as _wz
    from app.presentation.telegram.state import (
        WIZARD_TERMINAL_REASONS, WIZARD_RETRYABLE_REASONS)

    # F1 — the terminal vocabulary is exactly the §9 set.
    check("F1 the WIZARD terminal vocabulary is the exact classified set "
          "(SUCCESS + 8 failure classes; retryable = timeout/DNS/publish)",
          set(WIZARD_TERMINAL_REASONS) == {
              "SUCCESS", "TELEGRAM_TIMEOUT", "TELEGRAM_DNS_ERROR",
              "SOURCE_NOT_FOUND", "MEDIA_INVALID", "INDEX_MISSING",
              "DUPLICATE_SOURCE", "VALIDATION_ERROR", "PUBLISH_ERROR"}
          and set(WIZARD_RETRYABLE_REASONS) == {
              "TELEGRAM_TIMEOUT", "TELEGRAM_DNS_ERROR", "PUBLISH_ERROR"})

    # F2/F3/F4/F5 — the classification (pure functions).
    class TimedOut(Exception):
        pass

    class NetworkError(Exception):
        pass

    class IntegrityError(Exception):
        pass

    class OperationalError(Exception):
        pass

    for cls in (TimedOut, NetworkError, IntegrityError, OperationalError):
        cls.__module__ = "telegram.error" if cls in (
            TimedOut, NetworkError) else "aiosqlite"

    r_t, i_t, k_t = _wz._pcw_classify_wizard_failure(TimedOut())
    r_d, i_d, k_d = _wz._pcw_classify_wizard_failure(
        NetworkError("getaddrinfo failed: Name or service not known"))
    r_i, i_i, k_i = _wz._pcw_classify_wizard_failure(
        IntegrityError("UNIQUE constraint failed: indexed_files"))
    r_p, i_p, k_p = _wz._pcw_classify_wizard_failure(
        OperationalError("database is locked"))
    r_m, i_m, k_m = _wz._pcw_classify_wizard_failure(
        KeyError("file_unique_id"))
    check("F2 Telegram timeout classification (TELEGRAM_TIMEOUT, "
          "retryable, preserved-state instruction)",
          r_t == "TELEGRAM_TIMEOUT" and k_t is True
          and "Retry" in i_t, f"r={r_t}")
    check("F3 Telegram DNS/network classification (TELEGRAM_DNS_ERROR, "
          "retryable, DNS-check instruction)",
          r_d == "TELEGRAM_DNS_ERROR" and k_d is True
          and "DNS" in i_d, f"r={r_d}")
    check("F4 publication vs duplicate classification "
          "(IntegrityError -> DUPLICATE_SOURCE permanent; "
          "sqlite/OperationalError -> PUBLISH_ERROR retryable)",
          r_i == "DUPLICATE_SOURCE" and k_i is False
          and r_p == "PUBLISH_ERROR" and k_p is True
          and "rolled back" in i_p, f"r={r_i}/{r_p}")
    check("F5 media/index classification (a media identity defect -> "
          "MEDIA_INVALID permanent with the reindex instruction)",
          r_m == "MEDIA_INVALID" and k_m is False
          and "Reindex" in i_m, f"r={r_m}")

    # F6 — the validation-error classifier.
    v_dup = _wz._pcw_classify_validation_errors(
        ["A payload with this name already exists."])
    v_idx = _wz._pcw_classify_validation_errors(
        ["File no longer exists in the index — reindex required."])
    v_med = _wz._pcw_classify_validation_errors(
        ["media identity missing or invalid"])
    v_plain = _wz._pcw_classify_validation_errors(["Name too short."])
    check("F6 the pre-create validation classifier maps to the same "
          "vocabulary (DUPLICATE_SOURCE / INDEX_MISSING / MEDIA_INVALID / "
          "VALIDATION_ERROR)",
          v_dup == "DUPLICATE_SOURCE" and v_idx == "INDEX_MISSING"
          and v_med == "MEDIA_INVALID" and v_plain == "VALIDATION_ERROR",
          f"{v_dup}/{v_idx}/{v_med}/{v_plain}")

    # F7/F8 — the terminal emitter against the REAL db row.
    CH = -1005553001
    pk = await _seed_indexed(db, CH, 21, "UID_F7", "FID_F7", "f7_file.mp4")
    ctx = types.SimpleNamespace(user_data={})
    state = {"owner_id": 555, "mode": "single", "step": "confirm",
             "index_id": pk}
    uid_hash = hashlib.sha256(b"UID_F7").hexdigest()[:16]
    with _LogCap() as capF7:
        await ns._pcw_wizard_terminal(ctx, "complete", "SUCCESS",
                                      state=state, payload_id=901,
                                      db=db)
    wc = capF7.grab("WIZARD_COMPLETE")
    check("F7 WIZARD_COMPLETE carries the SOURCE IDENTITY fields "
          "(channel/message/file_pk/file_unique_id_hash from the REAL "
          "canonical row)",
          len(wc) == 1
          and f"channel_id={CH}" in wc[0]
          and "message_id=21" in wc[0]
          and f"file_pk={pk}" in wc[0]
          and f"file_unique_id_hash={uid_hash}" in wc[0]
          and "reason=SUCCESS" in wc[0],
          wc[:1])
    with _LogCap() as capF8:
        await ns._pcw_wizard_terminal(ctx, "failed", "TELEGRAM_TIMEOUT",
                                      state=state, db=db)
        await ns._pcw_wizard_terminal(ctx, "failed", "NOT_A_REAL_REASON",
                                      state=state, db=db)
    wf = capF8.grab("WIZARD_FAILED")
    check("F8 WIZARD_FAILED emits the classified reason (an unknown "
          "reason is coerced into the vocabulary — never free-form)",
          len(wf) == 2
          and "reason=TELEGRAM_TIMEOUT" in wf[0]
          and "reason=PUBLISH_ERROR" in wf[1],
          wf[:2])

    # F9 — the CANCEL terminal + no double event after a terminal.
    ctx2 = types.SimpleNamespace(
        user_data={"pcw": {"owner_id": 556, "mode": "single",
                           "step": "awaiting"}})
    with _LogCap() as capF9:
        ns._pcw_maybe_cancel_terminal(ctx2, "navigation")
        ns._pcw_maybe_cancel_terminal(ctx2, "pcw_clear")
    wcan = capF9.grab("WIZARD_CANCELLED")
    check("F9 WIZARD_CANCELLED fires exactly ONCE for a live wizard being "
          "cleared (via=navigation; a terminal state never double-fires)",
          len(wcan) == 1 and "via=navigation" in wcan[0],
          wcan[:1])

    # F10 — the failure screen: retryable -> [ Retry ]; permanent -> the
    # precise corrective instruction only.
    class _Q:
        async def answer(self, text=None, show_alert=False):
            return True

    upd = types.SimpleNamespace(
        callback_query=_Q(),
        effective_chat=types.SimpleNamespace(id=42))

    async def _noop_answer(q, *a, **k):
        return None
    ns.safe_answer_callback = _noop_answer
    CAPTURED.pop("edit", None)
    await ns._pcw_wizard_failure_screen(
        upd, ctx, "TELEGRAM_TIMEOUT", i_t, True)
    txt_r, kb_r = CAPTURED.get("edit") or ("", None)
    retry_cbs = []
    for row in (getattr(kb_r, "inline_keyboard", None) or []):
        for btn in row:
            retry_cbs.append(str(btn.callback_data or ""))
    CAPTURED.pop("edit", None)
    await ns._pcw_wizard_failure_screen(
        upd, ctx, "MEDIA_INVALID", i_m, False)
    txt_p, kb_p = CAPTURED.get("edit") or ("", None)
    perm_cbs = []
    for row in (getattr(kb_p, "inline_keyboard", None) or []):
        for btn in row:
            perm_cbs.append(str(btn.callback_data or ""))
    src = open(_wz.__file__.replace("__init__", "wizard")).read() \
        if _wz.__file__.endswith("__init__.py") else open(
            _wz.__file__).read()
    check("F10 the classified failure screen: retryable errors render a "
          "[ Retry ] button (pcw:create), permanent errors the precise "
          "instruction — and the create/save call sites emit the "
          "terminals (source pins)",
          "pcw:create" in retry_cbs and "pcw:create" not in perm_cbs
          and "TELEGRAM_TIMEOUT" in txt_r and "MEDIA_INVALID" in txt_p
          and "No partial data was written." in txt_r
          and src.count("await _pcw_wizard_terminal(") >= 6,
          f"retry={retry_cbs}")


# ===========================================================================
# [G] PLAYER — fullscreen chrome + the ended-only end screen (Task G)
# ===========================================================================
async def section_g(ns, db):
    print("\n[G] Player — fullscreen chrome-hide + end screen at 'ended'")
    import re as _re
    from app.web.site import html as H

    files_pkg = [
        {"file_pk": 854, "display_label": "Video 1",
         "file_name": "bot45_probe.mp4", "mime_type": "video/mp4",
         "href": "#"},
        {"file_pk": 855, "display_label": "Video 2",
         "file_name": "bot45_probe2.mp4", "mime_type": "video/mp4",
         "href": "#"},
    ]
    detail = {
        "listing": {"opaque_id": "bot45face01", "title": "BOT-45 Probe"},
        "file": {"file_pk": 854, "display_name": "bot45_probe.mp4",
                 "file_name": "bot45_probe.mp4", "mime_type": "video/mp4",
                 "media_type": "video", "size": 1234567},
        "files": files_pkg,
        "user": {"id": 8922807758, "username": "bot45probe"},
    }
    hrefs = {854: "/site/payload/bot45face01/video/f1:T1",
             855: "/site/payload/bot45face01/video/f2:T2"}
    page = H.video_page(
        detail, 1, "site/payload/bot45face01/video/f1:BOT45TOKEN",
        video_hrefs=hrefs, poster_url="/site/thumb/BOT45THUMB",
        current_file_pk=854,
        user={"id": 8922807758, "username": "bot45probe"})

    scripts = _re.findall(r"<script>(.*?)</script>", page, _re.S)
    pjs = ""
    for s in scripts:
        if "function mountPlayer" in s and "function requestStream" in s:
            pjs = s
            break
    check("G0 the rendered player script exists (mountPlayer + "
          "requestStream in one block)",
          bool(pjs), f"blocks={len(scripts)}")

    # G1 — the fullscreen chrome-hide CSS in the RENDERED page.
    css_sel = ["#bnav", "#mini", ".partpill", ".sheet", ".toast",
               "#navprog"]
    rules_ok = all(
        f"body.fsfake-scroll-lock {sel}" in page for sel in css_sel)
    check("G1 fullscreen hides ALL site chrome (the body-state CSS rules "
          "in the rendered template: #bnav/#mini/.partpill/.sheet/.toast/"
          "#navprog -> display:none!important — the z-index inversion "
          "root cause)",
          rules_ok
          and "body.fsfake-scroll-lock .sheetbak" in page
          and "display:none!important}" in page,
          f"sel_ok={rules_ok}")

    # G2 — __fsChromeSync mirrors the state class + runs on every icon
    # refresh (both fullscreen surfaces).
    sync_pos = pjs.find("function __fsChromeSync(){")
    icon_pos = pjs.find("function updateFsIcon(){")
    call_pos = pjs.find("__fsChromeSync();", icon_pos)
    check("G2 __fsChromeSync mirrors fsfake-scroll-lock onto <html>/"
          "<body> for BOTH fullscreen surfaces and runs from "
          "updateFsIcon (every enter/exit/fullscreenchange)",
          sync_pos > 0 and 0 < call_pos
          and 'document.body.classList.toggle("fsfake-scroll-lock", on)'
          in pjs
          and 'document.documentElement.classList.toggle(' in pjs
          and call_pos < pjs.find("function __syncFsHistory(){"),
          f"sync={sync_pos} call={call_pos}")

    # The end-screen implementation (armEndScreen + showEnd/hideEnd +
    # the Replay/Next Part controls) lives in the _PLAYER_UX_JS block —
    # the UX overlay script that armAll() arms and __uxPlayerRebind
    # re-binds after every in-place media rebuild; the player TRANSPORT
    # script (mountPlayer/requestStream, pjs) owns the media/HLS
    # lifecycle. Assert every end-screen contract against the block that
    # actually carries it (G12 pins the split: armEndScreen in the UX
    # block, .endscr teardown in the transport block).
    uxjs = ""
    for s in scripts:
        if "function armEndScreen" in s:
            uxjs = s
            break
    m = _re.search(r"function armEndScreen\(\)\{(.*?)\n\}", uxjs, _re.S)
    body = m.group(1) if m else ""

    # G3 — NO last-20-seconds timeupdate end-screen trigger anywhere.
    check("G3 NO last-20-seconds timeupdate trigger (the armEndScreen "
          "body — and the whole UX overlay script — bind NO timeupdate "
          "listener; the old 'dur - v.currentTime <= 20' overlay logic "
          "is gone from the whole page)",
          bool(body) and 'addEventListener("timeupdate"' not in uxjs
          and "dur - v.currentTime" not in page,
          f"armEndScreen_len={len(body)}")

    # G4 — the ONLY trigger is the media 'ended' event; the overlay
    # starts hidden.
    check("G4 the end screen appears ONLY at 'ended' (the single "
          "showEnd binding) and starts hidden (the hidden attribute)",
          'v.addEventListener("ended", showEnd);' in uxjs
          and uxjs.count("showEnd)") == 1
          and 'scr.setAttribute("hidden", "");' in uxjs,
          "")

    # G5 — any return to ACTIVE playback hides it again.
    check("G5 play/playing/seeking/seeked hide the overlay again (Next "
          "Part never covers active video)",
          '["play", "playing", "seeking", "seeked"].forEach(function(n)'
          in uxjs and "hideEnd" in uxjs)

    # G6/G7 — the Replay + Next Part controls, constructed ONLY inside
    # the .endscr overlay's markup (never over active video).
    check("G6 the Replay control exists with PLAYER_REPLAY telemetry "
          "(data-end=replay resets currentTime=0 and plays)",
          'data-end="replay"' in body
          and 'window.__siteTel("PLAYER_REPLAY")' in body
          and "v.currentTime = 0;" in body,
          "")
    check("G7 the Next Part control exists on the PACKAGE player with "
          "PLAYER_NEXT_PART telemetry (constructed ONLY inside the end "
          "screen markup, guarded by hasNext — never over active video)",
          'data-end="next"' in body
          and 'window.__siteTel("PLAYER_NEXT_PART")' in body
          and 'btns += \'<button type="button" class="endbtn go" '
          'data-end="next">\'' in body
          and "if(hasNext){" in body,
          "")
    # single-file render: Replay ONLY (the §11 'no next part' rule is a
    # RUNTIME gate — hasNext = !!UX.nextHref — so pin BOTH the hasNext
    # gate around the Next Part construction AND the single render's
    # EMPTY nextHref: the gated construction can never run for a single
    # payload, so its end screen carries [ Replay ] only)
    single = H.video_page(
        {**detail, "files": files_pkg[:1]}, 0,
        "site/payload/bot45face01/video/f1:BOT45TOKEN",
        video_hrefs={854: hrefs[854]}, poster_url="/site/thumb/T",
        current_file_pk=854, user={"id": 8922807758})
    suxjs, sdata = "", {}
    for s in _re.findall(r"<script>(.*?)</script>", single, _re.S):
        if "function armEndScreen" in s:
            suxjs = s
        if s.startswith("window.__UXDATA__"):
            try:
                sdata = json.loads(
                    s.split("=", 1)[1].strip().rstrip(";"))
            except ValueError:
                sdata = {}
    check("G8 a SINGLE payload gets Replay only (NO Next Part control "
          "when there is no next part — the single render ships an "
          "EMPTY nextHref so the hasNext-gated Next Part construction "
          "never runs)",
          'data-end="replay"' in suxjs
          and sdata.get("nextHref") == ""
          and "if(hasNext){" in suxjs,
          f"nextHref={sdata.get('nextHref')!r}")

    # G9 — the end-screen title + PLAYER_END_SCREEN telemetry.
    check("G9 the end screen renders 'Playback complete' + "
          "PLAYER_END_SCREEN {next} telemetry at show time",
          '<div class="endtitle">Playback complete</div>' in body
          and 'window.__siteTel("PLAYER_END_SCREEN", {next: hasNext ? '
          '1 : 0});' in body,
          "")

    # G10 — the fullscreen enter/exit pair with the surface mode.
    check("G10 PLAYER_FULLSCREEN_ENTER/PLAYER_FULLSCREEN_EXIT carry the "
          "active surface mode (api|fsfake|miniapp via __fsModeLast) "
          "alongside the preserved PLAYER_FULLSCREEN",
          'var __fsModeLast = "none";' in pjs
          and '__fsNow ? "PLAYER_FULLSCREEN_ENTER"' in pjs
          and ': "PLAYER_FULLSCREEN_EXIT"' in pjs
          and 'window.__siteTel("PLAYER_FULLSCREEN",' in pjs
          and 'if(fsElement()){ __fmode = "api"; }' in pjs
          and 'else if(fsFakeActive()){ __fmode = "fsfake"; }' in pjs
          and 'else if(tgIsFullscreen()){ __fmode = "miniapp"; }' in pjs,
          "")

    # G11 — one video element / one HLS lifecycle / one control surface.
    check("G11 ONE video element, ONE HLS lifecycle, ONE control surface "
          "(the bot-43 architecture pins hold on the BOT-45 template)",
          pjs.count('el = document.createElement("video");') == 1
          and pjs.count("function attachHls(") == 1
          and pjs.count("function destroyHls(") == 1
          and pjs.count("function setupControls(") == 1
          and 'var SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];' in pjs,
          f"video={pjs.count('el = document.createElement(')}")

    # G12 — the player UI JS block (not the transport script) carries
    # the same contracts (armEndScreen lives there).
    ux_ok = any("armEndScreen" in s for s in scripts)
    check("G12 the UX script block carries armEndScreen (the end screen "
          "is armed on the player surface, teardown-safe)",
          ux_ok and '".endscr"' in pjs,
          "")


# ===========================================================================
# [H] NETWORK BOT — the 6-step setup wizard (Task H / §36 8-14)
# ===========================================================================
async def section_h(ns, db):
    print("\n[H] Network Bot — the 6-step setup wizard")
    import inspect as _inspect
    from app.network import managed_bots as _mb

    # H1 — the 6-step structure.
    txt = _mb.build_setup_wizard_text(
        username="TestWizardBot", bot_id=999, state="created",
        network_bot_id=7, channel_name="My Channel",
        channel_id=-100123, bot_status="ACTIVE",
        membership_status="member", verification_state="pending",
        membership_ready=False)
    steps = ["1️⃣ CREATED", "2️⃣ ADD TO CHANNEL",
             "3️⃣ REQUIRED PERMISSIONS", "4️⃣ SERVER VERIFICATION",
             "5️⃣ CHANNEL CONFIGURATION", "6️⃣ MEMBERSHIP TEST"]
    check("H1 the 6-step wizard structure (identity, add-to-channel, "
          "permissions, server verification states, channel "
          "configuration, membership test) within Telegram's 4096 bound",
          all(s in txt for s in steps) and len(txt) <= 4096
          and "@TestWizardBot" in txt and "Bot ID 999" in txt
          and "Network Bot #7" in txt,
          f"len={len(txt)}")

    # H2 — STEP 3 lists EXACTLY the implemented permission requirements.
    check("H2 STEP 3 permissions are exactly the implemented set "
          "(broadcast channel; FDB Administrator + Delete Messages; "
          "Network Bot present) — nothing invented",
          "broadcast channel" in txt and "groups are not accepted" in txt
          and "Administrator + Delete Messages" in txt
          and "Network Bot: present in the channel" in txt)

    # H3 — the 8 telemetry events.
    check("H3 the 8 NETWORK_BOT_SETUP_* telemetry events are defined "
          "(OPEN/CREATED/ATTACHED/VERIFY_START/VERIFY_RESULT/"
          "CHANNEL_TEST/SETUP_COMPLETE/SETUP_ERROR)",
          set(_mb.NETWORK_BOT_SETUP_TELEMETRY_EVENTS) == {
              "NETWORK_BOT_SETUP_OPEN", "NETWORK_BOT_CREATED",
              "NETWORK_BOT_ATTACHED", "NETWORK_BOT_VERIFY_START",
              "NETWORK_BOT_VERIFY_RESULT", "NETWORK_BOT_CHANNEL_TEST",
              "NETWORK_BOT_SETUP_COMPLETE", "NETWORK_BOT_SETUP_ERROR"}
          and len(_mb.NETWORK_BOT_SETUP_TELEMETRY_EVENTS) == 8)

    # H4/H5 — the Telegram error classification.
    class TimedOut(Exception):
        pass

    TimedOut.__module__ = "telegram.error"

    class NetworkError(Exception):
        pass

    NetworkError.__module__ = "telegram.error"
    st_t, k_t = _mb.classify_setup_telegram_error(TimedOut())
    st_d, k_d = _mb.classify_setup_telegram_error(
        NetworkError("dns lookup failure"))
    st_c, k_c = _mb.classify_setup_telegram_error(
        NetworkError("chat not found"))
    st_f, k_f = _mb.classify_setup_telegram_error(
        NetworkError("bot was kicked from the group"))
    st_p, k_p = _mb.classify_setup_telegram_error(
        NetworkError("not enough rights to manage"))
    check("H4 timeout / DNS-network are told apart (timeout state + "
          "telegram_timeout key vs telegram_network_failure)",
          st_t == _mb.SETUP_STATE_TIMEOUT and k_t == "telegram_timeout"
          and st_d == _mb.SETUP_STATE_TELEGRAM_ERROR
          and k_d == "telegram_network_failure",
          f"{st_t}/{k_t} {st_d}/{k_d}")
    check("H5 not-found vs permission are told apart (ChatNotFound / "
          "kicked -> not_found; not-enough-rights -> permission_missing)",
          st_c == _mb.SETUP_STATE_NOT_FOUND
          and st_f == _mb.SETUP_STATE_NOT_FOUND
          and st_p == _mb.SETUP_STATE_PERMISSION_MISSING
          and k_p == "bot_not_administrator",
          f"{st_c}/{st_p}")

    # H6 — every error state carries title + message + next action.
    states = _mb.NETWORK_BOT_SETUP_ERROR_STATES
    bad = [k for k, v in states.items()
           if not (v.get("title") and v.get("message")
                   and v.get("next_action"))]
    rendered = _mb.render_setup_error_state("telegram_timeout")
    check("H6 every classified error state renders title + message + a "
          "NEXT ACTION (12 §4 states — never a bare 'Failed')",
          len(states) >= 12 and not bad
          and "Telegram timeout" in rendered
          and "Tap Verify again" in rendered,
          f"bad={bad}")

    # H7 — the wizard keyboard: the setup/verify sub-actions.
    kb = _mb.build_setup_wizard_keyboard(7, "TestWizardBot")
    cbs = []
    for row in kb.inline_keyboard:
        for b in row:
            cbs.append(str(b.callback_data or ""))
            if getattr(b, "copy_text", None) is not None:
                cbs.append("COPY")
    check("H7 the wizard keyboard routes through the nbot sub-actions "
          "(nbot:7:setup / nbot:7:verify + the native CopyTextButton)",
          "nbot:7:setup" in cbs and "nbot:7:verify" in cbs
          and "COPY" in cbs, f"cbs={cbs}")

    # H8 — network_ui routes setup/verify to the coordinator (source).
    src_nu = open(os.path.join(_ROOT, "app/presentation/telegram/",
                               "network_ui.py")).read()
    check("H8 the network_ui nbot dispatcher routes setup/verify to "
          "managed_bots.handle_setup_wizard_callback (after the owner + "
          "stale-bot gates)",
          'if action in ("setup", "verify"):' in src_nu
          and "handle_setup_wizard_callback(" in src_nu
          and "NETWORK_BOT_STALE_CALLBACK" in src_nu)

    # H9 — the attach path sends the SAME wizard (source).
    check("H9 the ATTACH path sends the 6-step wizard after the "
          "registration card (send_setup_wizard state='attached', "
          "best-effort — never blocks the registration)",
          'send_setup_wizard(' in src_nu
          and 'state="attached"' in src_nu
          and "NETWORK_BOT_SETUP_WIZARD_SEND_FAILED" in src_nu)

    # H10 — the telemetry whitelist: token material can NEVER appear.
    with _LogCap("app.network.managed_bots") as capH10:
        _mb.log_network_bot_setup_telemetry(
            "NETWORK_BOT_SETUP_ERROR", network_bot_id=7, bot_id=999,
            bot_token="999888:SECRETTOKEN1234567890",
            token="999888:ANOTHERSECRET", state="error",
            reason="probe_failed")
    line = capH10.grab("NETWORK_BOT_SETUP_ERROR")[0]
    check("H10 the setup telemetry whitelist DROPS token-named fields "
          "(safe fields only: ids/state/reason)",
          "SECRETTOKEN" not in line and "token" not in line.lower()
          and "network_bot_id=7" in line and "reason=probe_failed"
          in line, line[:110])

    # H11 — the membership test states are honest (never a fabricated
    # PASS).
    ready = _mb.build_setup_wizard_text(
        username="TestWizardBot", bot_id=999, state="created",
        network_bot_id=7, verification_state="connected",
        membership_ready=True)
    pend = txt
    check("H11 the membership test states are honest (a real pass "
          "renders '✓ Network Bot Ready' from the live own-client probe; "
          "a pending state says exactly what to do next)",
          "✓ Network Bot Ready" in ready
          and "membership test passed" in ready
          and "⏳ Not run yet" in pend
          and "tap Verify" in pend)


# ===========================================================================
# [I] MINI APP + WEBSITE integration (the coordination pins)
# ===========================================================================
async def section_i(ns, db):
    print("\n[I] Mini App + Website — allowlist + wiring + registration")
    from app.web.site import pages as _pages

    # I1 — the telemetry allowlist accepts the 5 new player events with
    # the exact field sets the client emits.
    ev = _pages._TELEMETRY_EVENTS
    check("I1 the pages.py telemetry allowlist accepts the 5 TASK G "
          "player events with the exact field sets",
          ev.get("PLAYER_END_SCREEN") == frozenset({"next"})
          and ev.get("PLAYER_NEXT_PART") == frozenset()
          and ev.get("PLAYER_REPLAY") == frozenset()
          and ev.get("PLAYER_FULLSCREEN_ENTER") == frozenset(
              {"mode", "position_s"})
          and ev.get("PLAYER_FULLSCREEN_EXIT") == frozenset(
              {"mode", "position_s"}),
          f"player_end_screen={ev.get('PLAYER_END_SCREEN')}")

    # I2 — every pre-existing entry preserved (no allowlist regression).
    # The ORIGINAL V26.2.2 allowlist is exactly these 33 entries (the
    # pre-BOT-45/46 dict — AGE_GATE_CONFIRM/AGE_GATE_CANCEL never
    # existed; the gate lifecycle uses AGE_GATE_CLICK / _REQUEST_*),
    # pinned byte-for-byte by the V26 suite's P1/P2 set.
    required_pre = [
        "PLAYER_OPEN", "PLAYER_READY", "PLAYER_PLAY", "PLAYER_PAUSE",
        "QUALITY_CHANGE", "PLAYER_BACK", "PLAYER_DESTROY",
        "PLAYER_STREAM_ERROR", "PLAYER_REAUTH", "PLAYER_CLOSE",
        "PLAYER_CONTROL_MODE", "PLAYER_SPEED_CHANGE",
        "PLAYER_QUALITY_CHANGE", "PLAYER_FULLSCREEN",
        "AGE_GATE_RENDER", "AGE_GATE_HANDLER_ATTACHED",
        "AGE_GATE_IDENTITY_WAIT", "AGE_GATE_CLICK",
        "AGE_GATE_IDENTITY_READY", "AGE_GATE_REQUEST_START",
        "AGE_GATE_REQUEST_RESULT", "AGE_GATE_STATE_UPDATED",
        "AGE_GATE_TRANSITION_COMPLETE", "AGE_GATE_ERROR",
        "SITE_NAV_PUSH", "SITE_NAV_REPLACE", "SITE_NAV_POP",
        "SITE_NAV_BACK", "SITE_NAV_FALLBACK", "SITE_NAV_ERROR",
        "SITE_ACTION_START", "SITE_ACTION_SUCCESS",
        "SITE_ACTION_FAILED"]
    missing = [k for k in required_pre if k not in ev]
    check("I2 the pre-existing telemetry entries are preserved (the 33 "
          "ORIGINAL V26.2.2 entries intact + the 5 TASK G additions = 38; "
          "no secret-bearing field allowlisted)",
          not missing and len(ev) == 33 + 5
          and "token" not in json.dumps(sorted(ev)).lower(),
          f"missing={missing} n={len(ev)}")

    # I3 — the FJ verify endpoint invalidation wiring (source).
    src_pg = open(_pages.__file__).read()
    check("I3 the FJ verify endpoint invalidates the user's cached FJ "
          "sessions on a CONFIRMED live re-check (invalidate_fj_auth_"
          "sessions cause=live_recheck, guarded by joined)",
          "invalidate_fj_auth_sessions" in src_pg
          and 'cause="live_recheck"' in src_pg
          and "if joined:" in src_pg
          and "FJ_AUTH_INVALIDATE_HOOK_FAILED" in src_pg)

    # I4 — the namespace registration (the DD2-class late-binding
    # contract for the new Task D/F helpers).
    names = ["_live_refresh_source_identity", "_live_refresh_notice",
             "_log_storage_message_skip", "_STORAGE_SKIP_REASONS",
             "_pcw_wizard_terminal", "_pcw_maybe_cancel_terminal",
             "_pcw_classify_wizard_failure",
             "_pcw_wizard_failure_screen", "WIZARD_TERMINAL_REASONS",
             "WIZARD_RETRYABLE_REASONS"]
    missing_ns = [n for n in names if not hasattr(ns, n)]
    check("I4 the new Task D/F helpers are registered on the runtime "
          "namespace (the late-binding contract — monkey-patching "
          "runtime.<name> keeps working)",
          not missing_ns, f"missing={missing_ns}")

    # I5 — the My Network panel uses the canonical link helper (never a
    # Worker URL as the Telegram destination).
    src_nu = open(os.path.join(
        _ROOT, "app/presentation/telegram/network_ui.py")).read()
    check("I5 the network_ui My Network panel uses the canonical link "
          "facade (no Worker URL, no _net_main_app_url as the Telegram "
          "destination)",
          "_net_main_app_link_safe" in src_nu
          and "workers.dev" not in src_nu
          and "_net_main_app_url" not in src_nu)

    # I6 — the schema v47 columns + the version stamp. The version is
    # stamped in the schema_meta TABLE (key='version') — the codebase's
    # authoritative carrier since v9; PRAGMA user_version is a SEPARATE
    # SQLite mechanism this codebase never sets (0 is expected there).
    cols_p = await db.conn.execute("PRAGMA table_info(payloads)")
    p_cols = {r[1] for r in await cols_p.fetchall()}
    cols_d = await db.conn.execute("PRAGMA table_info(pending_deletions)")
    d_cols = {r[1] for r in await cols_d.fetchall()}
    cur = await db.conn.execute(
        "SELECT value FROM schema_meta WHERE key='version';")
    vrow = await cur.fetchone()
    ver = int(vrow[0]) if vrow else 0
    check("I6 schema v47: payloads.display_name_origin + pending_"
          "deletions.attempts/last_error exist (the Task B/D storage "
          "contract; version stamped in schema_meta)",
          "display_name_origin" in p_cols
          and "attempts" in d_cols and "last_error" in d_cols
          and ver == 47, f"schema_meta_version={ver}")


# ===========================================================================
async def main() -> int:
    ns, db = await build_env()
    await section_a(ns, db)
    await section_b(ns, db)
    await section_c(ns, db)
    await section_d(ns, db)
    await section_e(ns, db)
    await section_f(ns, db)
    await section_g(ns, db)
    await section_h(ns, db)
    await section_i(ns, db)
    await db.close()
    total = RESULTS["pass"] + RESULTS["fail"]
    print(f"\n{'=' * 60}\nBOT-45/46 SUITE: {RESULTS['pass']}/{total} "
          f"passed, {RESULTS['fail']} failed")
    if RESULTS["failures"]:
        print("FAILURES:")
        for f in RESULTS["failures"]:
            print("  -", f)
    return 1 if RESULTS["fail"] else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
