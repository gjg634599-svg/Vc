#!/usr/bin/env python3
"""BOT-43 PLAYER + FJ-FRONTEND VERIFICATION SUITE — payload-delivery-bot.

Run:  python3 tests/test_bot43_player.py

Every check runs against the REAL rendered player page (the production
``app/web/site/html.py`` video_page renderer on a throwaway context) —
the assertions inspect the EXACT JavaScript/HTML the production site
ships to Telegram Android, not internal helpers. The Telegram transport
boundary stays mocked exactly as in the main V26 suite.
"""
from __future__ import annotations

import asyncio
import os
import re as _re
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

os.environ.setdefault("BOT_TOKEN", "123456:V26_MAIN_TEST_TOKEN")
os.environ.setdefault("ADMIN_IDS", "8370454312")
os.environ["DATABASE_FILE"] = os.path.join(_ROOT, "tests",
                                           "_bot43_player_test.db")

import logging  # noqa: E402

logging.basicConfig(level=logging.WARNING)

RESULTS = {"pass": 0, "fail": 0, "failures": []}


def check(name: str, cond: bool, detail: str = "") -> None:
    if cond:
        RESULTS["pass"] += 1
        print(f"  ✓ {name}")
    else:
        RESULTS["fail"] += 1
        RESULTS["failures"].append(f"{name} {detail}")
        print(f"  ✗ FAIL {name} {detail}")


# ---------------------------------------------------------------------------
async def main() -> int:
    from app.web.site import html as H

    detail = {
        "listing": {"opaque_id": "bot43face01", "title": "BOT-43 Probe"},
        "file": {"file_pk": 854, "display_name": "bot43_probe.mp4",
                 "file_name": "bot43_probe.mp4", "mime_type": "video/mp4",
                 "media_type": "video", "size": 1234567},
        "files": [{"file_pk": 854, "display_label": "Video 1",
                   "file_name": "bot43_probe.mp4",
                   "mime_type": "video/mp4", "href": "#"}],
        "user": {"id": 8922807758, "username": "bot43probe"},
    }
    page = H.video_page(
        detail, 0, "site/payload/bot43face01/video/f1:BOT43TOKEN",
        poster_url="/site/thumb/BOT43THUMB", current_file_pk=854,
        user={"id": 8922807758, "username": "bot43probe"})

    # The PLAYER script (the biggest inline block containing the player
    # state machine) — find it by its anchors.
    scripts = _re.findall(r"<script>(.*?)</script>", page, _re.S)
    player_js = ""
    for s in scripts:
        if "function mountPlayer" in s and "function requestStream" in s:
            player_js = s
            break
    check("B1 the rendered player script exists (mountPlayer + "
          "requestStream in one block)",
          bool(player_js), f"blocks={len(scripts)}")

    # ---- Section 1: ONE control system (no native/custom duplication) --
    # 1a: the VIDEO creation branch must NOT set the native controls
    # attribute anywhere between createElement("video") and el.id.
    video_branch = ""
    m = _re.search(
        r'el = document\.createElement\("video"\);\s*(.*?)el\.id = "pmedia"',
        player_js, _re.S)
    if m:
        video_branch = m.group(1)
    check("B2 the video is created WITHOUT native controls (no "
          "controls attribute in the video branch — the "
          "two-play/pause root cause)",
          bool(video_branch)
          and 'setAttribute("controls"' not in video_branch
          and "el.controls = false" in video_branch,
          repr(video_branch[:200]))
    # 1b: the ONLY setAttribute("controls") sites are the AUDIO branch
    # (audio keeps native chrome by design) and the setupControls
    # FAILURE fallback — never both surfaces on one <video>.
    ctl_sites = [mm.start() for mm in
                 _re.finditer(r'setAttribute\("controls"', player_js)]
    audio_ctx = player_js.find('el = document.createElement("audio")')
    fallback_ctx = player_js.find("player_controls_fallback")
    ok_sites = all(
        (abs(pos - audio_ctx) < 400) or (abs(pos - fallback_ctx) < 700)
        for pos in ctl_sites)
    check("B3 native controls appear ONLY in the audio branch + the "
          "setupControls failure fallback (never on a live video + "
          "custom bar simultaneously)",
          len(ctl_sites) == 2 and ok_sites,
          f"sites={len(ctl_sites)}")
    # 1c: the fallback is genuinely the catch of the custom install.
    check("B4 the fallback enables native controls ONLY inside the "
          "setupControls catch (PLAYER_CONTROL_MODE native + "
          "setAttribute in the catch)",
          "catch(e){\n        __ctlMode = \"native\";" in player_js
          and 'try{ el.setAttribute("controls",""); }catch(e2){}'
          in player_js)
    # 1d: PLAYER_CONTROL_MODE custom on the normal path.
    check("B5 PLAYER_CONTROL_MODE is emitted (custom on success, native "
          "on fallback)",
          'window.__siteTel("PLAYER_CONTROL_MODE", {mode: __ctlMode});'
          in player_js
          and 'var __ctlMode = "custom";' in player_js)
    # 1e: exactly ONE CONTENT <video> creation site (the pre-roll ad
    # stage owns its own separate layered adEl video by design — the
    # CONTENT element is never duplicated).
    check("B6 exactly ONE content-video creation site in the player "
          "script (the ad layer's adEl is the intentional separate "
          "surface)",
          player_js.count('el = document.createElement("video");') == 1
          and player_js.count('adEl = document.createElement("video");')
          == 1)

    # ---- Section 2: the cinematic Mini App stage -----------------------
    check("B7 the TOP overlay (Back + now-playing title) is constructed "
          "in setupControls",
          'top.className = "ptop"' in player_js
          and 'backBtn.id = "pback"' in player_js
          and 'ttl.id = "ptitle"' in player_js
          and 'ttl.textContent = String(j.display_name || j.file_name || "")'
          in player_js)
    check("B8 the top Back button emits PLAYER_BACK and takes the "
          "marked-backlink walk",
          'window.__siteTel("PLAYER_BACK", {from: "player"})'
          in player_js
          and 'document.querySelector(".backlink")' in player_js)
    check("B9 teardownMedia removes the top overlay with the bar/menu "
          "(no orphan chrome across rebuilds)",
          '".ptop"' in player_js)
    check("B10 the ad observer hides BOTH bars while a pre-roll runs",
          'top.classList.toggle("adshidden", adOn);' in player_js)
    css = page  # the CSS is emitted in the same document
    check("B11 .ptop CSS: top gradient + shared ctl-idle auto-hide + "
          "44px touch targets",
          ".ptop{position:absolute;left:0;right:0;top:0" in css
          and ".playerbox.ctl-idle .ptop{opacity:0" in css
          and ".ptopbtn{" in css
          and "min-width:44px;min-height:44px" in css.split(".ptopbtn{")[1]
          if ".ptopbtn{" in css else False)
    check("B12 mobile (<=640px) .ptop sizing exists (no horizontal "
          "overflow, compact paddings)",
          ".ptop{padding:6px 6px 6px 2px;gap:4px}" in css
          and ".ptoptitle{font-size:12.5px}" in css)
    check("B13 the poster is rendered on the video (cinematic "
          "before-playback surface)",
          'el.setAttribute("poster"' in player_js
          and "BOT43THUMB" in page)
    check("B14 the centered big-play button + buffering spinner + bottom "
          "gradient bar all exist",
          '"pbigplay"' in player_js and '"pwait"' in player_js
          and ".pctl{position:absolute;left:0;right:0;bottom:0" in css)

    # ---- Section 3: lifecycle + the new telemetry -----------------------
    check("B15 PLAYER_DESTROY/PLAYER_CLOSE fire ONCE per lifecycle "
          "(the __destroyReported sentinel; mountPlayer re-arms)",
          "var __destroyReported = false;" in player_js
          and "if(!__destroyReported){" in player_js
          and "__destroyReported = true;" in player_js
          and "__destroyReported = false;\n" in player_js)
    check("B16 PLAYER_SPEED_CHANGE fires on USER changes only (menu "
          "onSelect passes userInitiated; the boot restore does not)",
          "function applySpeed(el, rate, userInitiated)" in player_js
          and "applySpeed(el, r, true);" in player_js
          and 'window.__siteTel("PLAYER_SPEED_CHANGE"' in player_js
          and player_js.count("applySpeed(el, savedRate);") == 1)
    check("B17 PLAYER_FULLSCREEN is transition-gated (state enter/exit, "
          "no re-emit on refresh)",
          "var __fsLastState = null;" in player_js
          and 'window.__siteTel("PLAYER_FULLSCREEN"' in player_js
          and 'state: __fsNow ? "enter" : "exit"' in player_js)
    check("B18 PLAYER_QUALITY_CHANGE fires at BOTH real-switch sites "
          "(hls.js LEVEL_SWITCHED + native variant swap)",
          player_js.count('window.__siteTel("PLAYER_QUALITY_CHANGE"')
          == 2)
    check("B19 the SPEEDS ladder is exactly the spec set "
          "(0.5/0.75/1/1.25/1.5/2)",
          "var SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];" in player_js)
    check("B20 the Quality menu stays honest (real master renditions "
          "only; hidden when a single rendition)",
          "function parseMasterRenditions" in player_js
          and "ctl.qBtn.hidden = false" in player_js)

    # ---- Section 4: the FJ stale-rejoin fix -----------------------------
    check("B21 clearFjGateUI exists and removes the gate + the gated "
          "class",
          "function clearFjGateUI()" in player_js
          and 'pbox.querySelectorAll("#fjgate")' in player_js
          and 'pbox.classList.remove("gated")' in player_js)
    # requestStream must clear BEFORE the fetch (a completed gate can
    # never survive a re-issue).
    rs = player_js.find("function requestStream(){")
    clear_pos = player_js.find("clearFjGateUI();", rs)
    fetch_pos = player_js.find("fetch(API_STREAM", rs)
    check("B22 requestStream clears the stale gate BEFORE the fetch "
          "(the bot-43 stale-rejoin root cause)",
          0 <= clear_pos < fetch_pos,
          f"clear={clear_pos} fetch={fetch_pos}")
    check("B23 the Verify success branch clears the gate + shows the "
          "preparing spinner + accepts the explicit complete flag",
          "v.ok && (v.joined || v.complete === true)" in player_js
          and player_js.find("clearFjGateUI();",
                             player_js.find("v.complete === true"))
          < player_js.find("requestStream();",
                           player_js.find("v.complete === true")))
    check("B24 handleStreamJson ends the preparing spinner on EVERY "
          "resolved response",
          player_js.find("hideLoading();",
                         player_js.find("function handleStreamJson"))
          < player_js.find("if(!j || !j.ok){",
                           player_js.find("function handleStreamJson")))
    check("B25 the Verify partial branch re-renders ONLY the fresh "
          "not_joined rows (never a completed channel)",
          "list.innerHTML = v.not_joined.map(fjRowHtml).join(\"\");"
          in player_js)
    check("B26 the audio surface keeps its native controls (regression)",
          'el = document.createElement("audio");' in player_js)

    # ---- the FJ server contract the frontend now relies on --------------
    from app.storage.schema import Database
    db = Database(os.environ["DATABASE_FILE"])
    await db.connect()
    await db.init_schema()
    codes = await db.list_website_collection_codes()
    check("B27 the authoritative listing read used by the picker exists "
          "(repo contract)",
          isinstance(codes, list))
    await db.close()

    total = RESULTS["pass"] + RESULTS["fail"]
    print(f"\n{'=' * 60}\nBOT-43 PLAYER SUITE: {RESULTS['pass']}/{total} "
          f"passed, {RESULTS['fail']} failed")
    if RESULTS["failures"]:
        print("FAILURES:")
        for f in RESULTS["failures"]:
            print("  -", f)
    return 1 if RESULTS["fail"] else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
