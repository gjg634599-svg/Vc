#!/usr/bin/env python3
"""BOT-43 WORK-STREAM C — the Force-Join verify-endpoint completed-state
contract + the presentation telemetry + the player control-surface
telemetry allowlist.

Run:  python3 tests/test_bot43_fj.py

Every check runs against the REAL production code (the runtime namespace,
the real container deps factory, the real Force-Join domain service, the
real aiohttp handlers) on a throwaway SQLite file. Nothing is mocked
except the Telegram transport boundary (the same canned-membership
_FakeFJBot the V26 suite's AA section uses).

The BOT-43 §4 authoritative contract under test:
  * POST /site/api/forcejoin/verify success MUST answer the unambiguous
    completed state {"ok": true, "joined": true, "remaining": [],
    "complete": true} — partial responses keep not_joined (== remaining)
    listing ONLY this gate's still-unjoined channels;
  * WEBSITE_FJ_VERIFY gains complete=/remaining_count= fields;
  * FJ_PRESENTATION (user_id, gate_key, state, remaining_count,
    payload_id) is emitted by the verify endpoint AND by the canonical
    service (complete fast-path + fresh-pin branch) in ONE field order;
  * the verify endpoint threads the resolved payload_id into the FJ gate
    (the play-gate resolution) so the satisfied-path unlock bookkeeping
    (BOT6_FJ_PAYLOAD_UNLOCK) records THIS payload;
  * the telemetry allowlist accepts the new PLAYER_CONTROL_MODE /
    PLAYER_SPEED_CHANGE / PLAYER_QUALITY_CHANGE / PLAYER_FULLSCREEN
    events with the exact field sets, strips unknown fields, and still
    rejects unknown events with a controlled 400.
"""
from __future__ import annotations

import asyncio
import hashlib
import hmac as _hmac
import json
import os
import sys
import time
import urllib.parse
from datetime import datetime, timezone

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

os.environ.setdefault("BOT_TOKEN", "123456:V26_MAIN_TEST_TOKEN")
os.environ.setdefault("ADMIN_IDS", "8370454312")
DB_PATH = os.path.join(_ROOT, "tests", "_bot43_fj_test.db")
os.environ["DATABASE_FILE"] = DB_PATH

import logging  # noqa: E402

logging.basicConfig(level=logging.WARNING)

RESULTS = {"pass": 0, "fail": 0, "failures": []}


def check(name: str, cond: bool, detail: str = "") -> None:
    if cond:
        RESULTS["pass"] += 1
        print(f"  ✓ {name}")
    else:
        RESULTS["fail"] += 1
        RESULTS["failures"].append(f"{name} {detail}")
        print(f"  ✗ FAIL {name} {detail}")


# ---------------------------------------------------------------------------
# Telegram WebApp initData signer (the OFFICIAL model — same as the
# canonical validator: secret = HMAC_SHA256("WebAppData", bot_token))
# ---------------------------------------------------------------------------
def sign_init_data(bot_token: str, user_id: int, username: str = "tester",
                   age: int = 60) -> str:
    pairs = {
        "auth_date": str(int(time.time()) - age),
        "query_id": "AAF" + os.urandom(4).hex(),
        "user": json.dumps({"id": user_id, "username": username,
                            "first_name": "T"}),
    }
    dcs = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret = _hmac.new(b"WebAppData", bot_token.encode(),
                       hashlib.sha256).digest()
    sig = _hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest()
    return urllib.parse.urlencode({**pairs, "hash": sig})


class _LogCap:
    """Capture structured log lines from the payload-bot logger."""

    def __init__(self):
        self.lines = []
        self._h = logging.Handler()
        self._h.emit = lambda rec: self.lines.append(rec.getMessage())  # type: ignore[method-assign]
        self._h.setLevel(logging.INFO)

    def __enter__(self):
        logging.getLogger("payload-bot").addHandler(self._h)
        logging.getLogger("payload-bot").setLevel(logging.INFO)
        return self

    def __exit__(self, *a):
        logging.getLogger("payload-bot").removeHandler(self._h)

    def has(self, prefix):
        return any(ln.startswith(prefix) for ln in self.lines)

    def lines_with(self, prefix):
        return [ln for ln in self.lines if ln.startswith(prefix)]


class _FakeMember:
    def __init__(self, status):
        self.status = status


class _FakeFJBot:
    """Canned live-membership bot: get_chat_member returns member/left."""

    def __init__(self):
        self.joined = set()

    async def get_chat_member(self, channel_id, user_id):
        return _FakeMember("member" if int(channel_id) in self.joined
                           else "left")


def _make_fj(db):
    """The REAL FJ domain service on the suite DB (minimal port fakes —
    the same class of transport-boundary faking the AA section uses)."""
    from app.core.force_join.service import make_force_join_service

    async def _policy():
        return "request"

    return make_force_join_service(
        db=db, ENABLE_FORCE_JOIN=True,
        get_join_request_policy=_policy,
        _consume_join_request=lambda *a: None,
        _has_pending_join_request=lambda *a: False,
        _prune_join_requests=lambda: None,
        PENDING_JOIN_REQUESTS={})


class _FJReq:
    """The fake aiohttp request the site API handlers accept (the same
    shape the V26 suite's _IssReq/_BBReq fake request uses)."""

    def __init__(self, body, cookies=None):
        self._body = body
        self.cookies = dict(cookies or {})
        self.headers = {"Content-Type": "application/json"}
        self.remote = "104.23.175.21"

    async def json(self):
        return self._body


async def main() -> int:
    # ---- fresh throwaway DB ------------------------------------------------
    for suffix in ("", "-wal", "-shm"):
        p = DB_PATH + suffix
        if os.path.exists(p):
            os.remove(p)

    from app.presentation.telegram import namespace as _ns_mod
    from app.storage.schema import Database
    from app.services import container as _container
    from app.web.site import pages as _pages
    from app.web.site import ratelimit
    from app.web.site.session import make_site_session_codec as _sessc

    print("[BOT-43 C] FJ verify completed-state contract + telemetry")
    ns = _ns_mod.NS
    db = Database(DB_PATH)
    await db.connect()
    await db.init_schema()
    ns.db = db

    # ---- the AA-section machinery: REAL namespace FJ wiring + fake bots --
    CHS = [-(3000000 + i) for i in range(1, 5)]  # 4 fresh channels
    for i, cid in enumerate(CHS):
        await db.add_force_channel(cid, f"fj43chan{i + 1}")
    await db.set_setting("force_join_enabled", "1")
    await db.set_setting("fj_mode", "fixed_order")
    await db.set_setting("fj_batch_size", "2")

    # ---- a published payload-kind listing (the gate_key resolution target)
    now = datetime.now(timezone.utc).isoformat()
    CH_FILE = -1004460709020
    await db.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date, "
        "mime_type) VALUES (?, 7701, 'FIDFJ43', 'FUIDFJ43', 'video', "
        "'fj43_video.mp4', 400000, ?, 'video/mp4')", (CH_FILE, now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM indexed_files WHERE channel_id=? AND message_id=?",
        (CH_FILE, 7701))
    idx = int((await cur.fetchone())[0])
    await db.conn.execute(
        "INSERT INTO payloads(payload, index_id, status, access_policy, "
        "created_at, updated_at) VALUES ('fj43play', ?, 'active', "
        "'FORCE_JOIN', ?, ?)", (idx, now, now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload='fj43play'")
    pid = int((await cur.fetchone())[0])
    await db.create_website_payload(payload_id=pid, title="FJ43 Play",
                                    published=1, created_by=1)
    listing = await db.find_website_payload_for_canonical(payload_id=pid)
    opaque = str(listing["opaque_id"])
    GATE_KEY = f"w|{opaque}|{idx}"
    MAIN_TOKEN = ns.BOT_TOKEN

    # ---- the REAL container deps snapshot + the pages factory swap -------
    _prev_gw = getattr(ns, "_website_media_gateway", None)
    _prev_bot = getattr(ns, "_mini_app_bot", None)
    _prev_factory = _pages._deps_factory
    _prev_we = await db.get_setting("website_enabled") or ""
    ns._website_media_gateway = lambda: None  # unused by the FJ surfaces
    bot_cold = _FakeFJBot()                    # joined NOTHING
    bot_all = _FakeFJBot()
    bot_all.joined = set(CHS)                 # joined EVERYTHING
    bot_half = _FakeFJBot()
    bot_half.joined = {CHS[0]}                # joined only channel 1
    ns._mini_app_bot = bot_cold
    deps = _container.website_deps_factory(ns)
    _pages._deps_factory = lambda: deps
    await db.set_setting("website_enabled", "1")

    async def _verify(uid, gate_key, init=True):
        ratelimit.reset_all()
        body = {} if gate_key is None else {"gate_key": gate_key}
        if init:
            body["init_data"] = sign_init_data(MAIN_TOKEN, uid)
        with _LogCap() as cap:
            r = await _pages.handle_site_api_fj_verify(_FJReq(body))
        return r, json.loads(r.text), cap

    def _view_ids(body):
        return [int(v.get("channel_id")) for v in (body.get("remaining")
                                                   or [])]

    try:
        # =============================================================
        # F1 — the COMPLETE case: the authoritative completed state.
        # =============================================================
        ns._mini_app_bot = bot_all
        UID_C = 88440
        r1, b1, cap1 = await _verify(UID_C, GATE_KEY)
        check("F1 complete case: ok=true joined=true complete=true "
              "remaining=[] not_joined=[] (the authoritative contract)",
              r1.status == 200 and b1.get("ok") is True
              and b1.get("joined") is True and b1.get("complete") is True
              and b1.get("remaining") == [] and b1.get("not_joined") == [],
              f"status={r1.status} body={json.dumps(b1)[:220]}")

        # F4 — the extended WEBSITE_FJ_VERIFY line (complete case).
        _vf = [ln for ln in cap1.lines_with("WEBSITE_FJ_VERIFY")]
        check("F4 WEBSITE_FJ_VERIFY now carries complete= and "
              "remaining_count= (complete case: complete=True "
              "remaining_count=0)",
              bool(_vf) and "complete=True" in _vf[0]
              and "remaining_count=0" in _vf[0]
              and "joined=True" in _vf[0] and "gate_key=%s" % GATE_KEY
              in _vf[0],
              f"line={_vf[:1]}")

        # F5a — the verify endpoint's OWN FJ_PRESENTATION on success.
        _fp_ok = f"FJ_PRESENTATION user_id={UID_C} gate_key={GATE_KEY} " \
                 f"state=complete remaining_count=0 payload_id={pid}"
        check("F5a FJ_PRESENTATION from the verify endpoint on success: "
              "state=complete remaining_count=0 (payload_id resolved)",
              _fp_ok in cap1.lines, f"want={_fp_ok!r}")

        # =============================================================
        # F2 — the PARTIAL case: remaining == not_joined, ONLY the
        #      still-unjoined channels of this gate's pinned batch.
        # =============================================================
        ns._mini_app_bot = bot_cold
        UID_P = 88441
        r2, b2, cap2 = await _verify(UID_P, GATE_KEY)
        check("F2 partial case: complete=false joined=false and remaining "
              "== not_joined (ONLY the pinned batch, no future batch)",
              r2.status == 200 and b2.get("ok") is True
              and b2.get("complete") is False and b2.get("joined") is False
              and b2.get("remaining") == b2.get("not_joined")
              and _view_ids(b2) == CHS[:2]
              and not (set(_view_ids(b2)) & set(CHS[2:]))
              and bool(b2.get("verify_hint")),
              f"ids={_view_ids(b2)} complete={b2.get('complete')}")

        # F2b — a partially-joined user: completed channels NEVER appear.
        ns._mini_app_bot = bot_half
        UID_P2 = 88442
        r2b, b2b, _cap2b = await _verify(UID_P2, GATE_KEY)
        check("F2b partial case (some joined): remaining lists ONLY the "
              "unjoined channels — NO completed channel inside",
              r2b.status == 200 and b2b.get("complete") is False
              and _view_ids(b2b) == CHS[1:3]
              and CHS[0] not in _view_ids(b2b),
              f"ids={_view_ids(b2b)}")

        # F4b — the extended WEBSITE_FJ_VERIFY line (partial case).
        _vp = [ln for ln in cap2.lines_with("WEBSITE_FJ_VERIFY")]
        check("F4b WEBSITE_FJ_VERIFY partial case: complete=False "
              "remaining_count=2 (existing fields kept)",
              bool(_vp) and "complete=False" in _vp[0]
              and "remaining_count=2" in _vp[0]
              and "joined=False" in _vp[0] and "remaining=2" in _vp[0],
              f"line={_vp[:1]}")

        # F5b — the verify endpoint's FJ_PRESENTATION on partial.
        _fp_part = f"FJ_PRESENTATION user_id={UID_P} gate_key={GATE_KEY} " \
                   f"state=remaining remaining_count=2 payload_id={pid}"
        check("F5b FJ_PRESENTATION from the verify endpoint on partial: "
              "state=remaining remaining_count=N",
              _fp_part in cap2.lines, f"want={_fp_part!r}")

        # F7 — the SERVICE fresh-pin branch FJ_PRESENTATION (driven here
        #      through the REAL verify endpoint → ns facade → service).
        _fp_pin = f"FJ_PRESENTATION user_id={UID_P} gate_key={GATE_KEY} " \
                  f"state=remaining remaining_count=4 payload_id={pid}"
        check("F7 FJ_PRESENTATION from the service fresh-pin branch "
              "(state=remaining, remaining_count = the overall "
              "un-joined count)",
              _fp_pin in cap2.lines
              and any(ln.startswith("FJ_PLAY_GATE") and
                      "decision=DENY reason=batch_pinned" in ln
                      for ln in cap2.lines),
              f"want={_fp_pin!r}")

        # F8a — the payload_id IS threaded into the gate on verify (the
        #       service-side FJ logs carry payload_id={pid}, not '-').
        check("F8a payload_id threaded into the gate on verify (the "
              "service FJ_PRESENTATION/FJ_PLAY_GATE lines carry the "
              "resolved payload_id, never '-')",
              _fp_pin.endswith(f"payload_id={pid}")
              and any(ln.startswith("FJ_PLAY_GATE")
                      and f"payload_id={pid}" in ln
                      for ln in cap2.lines),
              "service lines still show payload_id=-")

        # =============================================================
        # F3 — the verify_failed case: honest, fail-closed, never joined.
        # =============================================================
        UID_VF = 88443
        _orig_gate = deps.fj_gate_unjoined

        async def _boom_gate(*a, **k):
            raise RuntimeError("fj check exploded mid-verify")

        deps.fj_gate_unjoined = _boom_gate
        try:
            r3, b3, cap3 = await _verify(UID_VF, GATE_KEY)
        finally:
            deps.fj_gate_unjoined = _orig_gate
        check("F3 verify_failed case: joined=false complete=false honest "
              "verify_hint + not_joined field present (fail-closed)",
              r3.status == 200 and b3.get("ok") is True
              and b3.get("joined") is False and b3.get("complete") is False
              and "not_joined" in b3 and b3.get("remaining") == []
              and b3.get("verification") == "unavailable"
              and "unavailable" in str(b3.get("verify_hint") or ""),
              f"body={json.dumps(b3)[:220]}")
        check("F3b the failed check is TELEMETRY-visible "
              "(WEBSITE_FJ_GATE_ERROR) — never a silent bypass",
              cap3.has("WEBSITE_FJ_GATE_ERROR"))

        # =============================================================
        # F6 — the SERVICE complete fast-path FJ_PRESENTATION (the
        #      AA-machinery direct drive: every channel joined).
        # =============================================================
        svc = _make_fj(db)
        UID_S = 88450
        with _LogCap() as cap6:
            v6 = await svc.fj_gate_view(UID_S, "w|fj43svc|9",
                                        payload_id=pid, bot=bot_all)
        _fp_fast = f"FJ_PRESENTATION user_id={UID_S} gate_key=w|fj43svc|9 " \
                   f"state=complete remaining_count=0 payload_id={pid}"
        check("F6 FJ_PRESENTATION from the service COMPLETE fast-path "
              "(after FJ_COMPLETE; view satisfied, no channels)",
              v6.get("satisfied") is True and (v6.get("channels") or []) == []
              and _fp_fast in cap6.lines and cap6.has("FJ_COMPLETE"),
              f"want={_fp_fast!r} satisfied={v6.get('satisfied')}")

        # F7b — the SERVICE fresh-pin branch driven directly (some
        #       unjoined; separate user so the pins stay independent).
        UID_S2 = 88451
        with _LogCap() as cap7:
            v7 = await svc.fj_gate_view(UID_S2, "w|fj43svc2|9",
                                        payload_id=pid, bot=bot_cold)
        _fp_fresh = f"FJ_PRESENTATION user_id={UID_S2} " \
                    f"gate_key=w|fj43svc2|9 state=remaining " \
                    f"remaining_count=4 payload_id={pid}"
        check("F7b FJ_PRESENTATION from the service fresh-pin branch "
              "(direct drive; state=remaining remaining_count=4)",
              v7.get("satisfied") is False and _fp_fresh in cap7.lines
              and any(ln.startswith("FJ_STATE") for ln in cap7.lines),
              f"want={_fp_fresh!r}")

        # =============================================================
        # F8b — the payload_id reaches the STATE MACHINE through the
        #       verify endpoint's satisfied path: the pinned batch
        #       completes → the engine drive carries the threaded
        #       payload_id (BOT6_FJ_BATCH_COMPLETE) + the persisted
        #       completed_batches bookkeeping, while the GATE answers
        #       the authoritative completed state.
        # =============================================================
        ns._mini_app_bot = bot_cold
        UID_U = 88460
        _r_u1, _b_u1, _cap_u1 = await _verify(UID_U, GATE_KEY)
        bot_pin = _FakeFJBot()
        bot_pin.joined = set(CHS[:2])  # joined exactly the pinned batch
        ns._mini_app_bot = bot_pin
        r_u2, b_u2, cap_u2 = await _verify(UID_U, GATE_KEY)
        _batch = [ln for ln in cap_u2.lines_with("BOT6_FJ_BATCH_COMPLETE")]
        row_u = await db.get_fj_progress_row(UID_U)
        _completed = json.loads(row_u["completed_batches"]) if row_u and \
            row_u["completed_batches"] else []
        check("F8b the satisfied-path verify drive carries the threaded "
              "payload_id into the state machine (BOT6_FJ_BATCH_COMPLETE "
              "payload_id=N + persisted completed_batches) while the GATE "
              "answers the completed state",
              _r_u1.status == 200 and _b_u1.get("complete") is False
              and r_u2.status == 200 and b_u2.get("joined") is True
              and b_u2.get("complete") is True
              and b_u2.get("remaining") == []
              and bool(_batch) and f"payload_id={pid}" in _batch[0]
              and any(ln.startswith("FJ_PLAY_GATE")
                      and "decision=ALLOW reason=pinned_batch_complete" in ln
                      and f"payload_id={pid}" in ln
                      for ln in cap_u2.lines)
              and [CHS[0], CHS[1]] in _completed,
              f"batch={_batch[:1]} completed={_completed}")

        # F8c — what the payload_id ENABLES (the access engine's canonical
        #       no-gate-key slice on the SAME payload): the full
        #       requirement completing records BOT6_FJ_PAYLOAD_UNLOCK for
        #       THIS payload + the persisted unlocked_payload_ids.
        UID_Z = 88461
        ns._mini_app_bot = bot_all
        with _LogCap() as cap_u3:
            _slice = await ns._unjoined_for_access(UID_Z, payload_id=pid,
                                                   bot=bot_all)
        _unlock = [ln for ln in cap_u3.lines_with("BOT6_FJ_PAYLOAD_UNLOCK")]
        row_z = await db.get_fj_progress_row(UID_Z)
        _unlocked_ids = json.loads(
            row_z["unlocked_payload_ids"]) if row_z and \
            row_z["unlocked_payload_ids"] else []
        check("F8c the payload_id bookkeeping: the full-requirement "
              "completion records BOT6_FJ_PAYLOAD_UNLOCK for THIS payload "
              "(+ persisted unlocked_payload_ids)",
              _slice == [] and bool(_unlock)
              and f"payload_id={pid}" in _unlock[0]
              and "decision=UNLOCKED" in _unlock[0]
              and int(pid) in [int(x) for x in _unlocked_ids],
              f"unlock={_unlock[:1]} unlocked_ids={_unlocked_ids}")

        # =============================================================
        # F9-F14 — the telemetry allowlist additions (session-authed).
        # =============================================================
        UID_T = 88470
        _sess = _sessc(MAIN_TOKEN)
        _cookie = {"endie_site": _sess.issue_session(UID_T,
                                                     username="fj43t")}

        async def _tel(body):
            ratelimit.reset_all()
            with _LogCap() as cap:
                r = await _pages.handle_site_api_telemetry(
                    _FJReq(body, cookies=_cookie))
            return r, json.loads(r.text), cap

        r9, b9, cap9 = await _tel({"event": "PLAYER_CONTROL_MODE",
                                   "mode": "custom"})
        _t9 = [ln for ln in cap9.lines_with("WEBSITE_TELEMETRY")]
        check("F9 PLAYER_CONTROL_MODE accepted ({mode}) — 200 + "
              "WEBSITE_TELEMETR logged",
              r9.status == 200 and b9.get("ok") is True and bool(_t9)
              and "event=PLAYER_CONTROL_MODE" in _t9[0]
              and "mode=custom" in _t9[0]
              and f"user_id={UID_T}" in _t9[0],
              f"status={r9.status} line={_t9[:1]}")

        r10, b10, cap10 = await _tel({"event": "PLAYER_SPEED_CHANGE",
                                      "to": "1.5", "position_s": 12})
        _t10 = [ln for ln in cap10.lines_with("WEBSITE_TELEMETRY")]
        check("F10 PLAYER_SPEED_CHANGE accepted ({to, position_s}) — 200 "
              "+ coerced fields logged",
              r10.status == 200 and b10.get("ok") is True and bool(_t10)
              and "event=PLAYER_SPEED_CHANGE" in _t10[0]
              and "to=1.5" in _t10[0] and "position_s=12" in _t10[0],
              f"status={r10.status} line={_t10[:1]}")

        r11, b11, cap11 = await _tel({"event": "PLAYER_QUALITY_CHANGE",
                                      "to": "720p", "level": 1,
                                      "position_s": 3})
        _t11 = [ln for ln in cap11.lines_with("WEBSITE_TELEMETRY")]
        check("F11 PLAYER_QUALITY_CHANGE accepted ({to, level, "
              "position_s}) — 200 + coerced fields logged",
              r11.status == 200 and b11.get("ok") is True and bool(_t11)
              and "event=PLAYER_QUALITY_CHANGE" in _t11[0]
              and "to=720p" in _t11[0] and "level=1" in _t11[0]
              and "position_s=3" in _t11[0],
              f"status={r11.status} line={_t11[:1]}")

        r12, b12, cap12 = await _tel({"event": "PLAYER_FULLSCREEN",
                                      "state": "enter", "position_s": 0})
        _t12 = [ln for ln in cap12.lines_with("WEBSITE_TELEMETRY")]
        check("F12 PLAYER_FULLSCREEN accepted ({state, position_s}) — 200 "
              "+ coerced fields logged",
              r12.status == 200 and b12.get("ok") is True and bool(_t12)
              and "event=PLAYER_FULLSCREEN" in _t12[0]
              and "state=enter" in _t12[0] and "position_s=0" in _t12[0],
              f"status={r12.status} line={_t12[:1]}")

        r13, b13, cap13 = await _tel({"event": "PLAYER_CONTROL_MODE",
                                      "mode": "custom",
                                      "token": "SECRETTOKEN123",
                                      "url": "https://evil.example/x"})
        _t13 = [ln for ln in cap13.lines_with("WEBSITE_TELEMETRY")]
        check("F13 unknown fields still STRIPPED (PLAYER_CONTROL_MODE + "
              "bogus token/url fields → never in the log line)",
              r13.status == 200 and b13.get("ok") is True and bool(_t13)
              and "mode=custom" in _t13[0]
              and "token=" not in _t13[0] and "url=" not in _t13[0]
              and not any("SECRETTOKEN123" in ln for ln in cap13.lines),
              f"line={_t13[:1]}")

        r14, b14, _cap14 = await _tel({"event": "PLAYER_BOGUS_EVENT",
                                       "mode": "x"})
        check("F14 unknown event still a controlled 400 (unknown_event)",
              r14.status == 400 and b14.get("ok") is False
              and b14.get("error") == "unknown_event",
              f"status={r14.status} body={json.dumps(b14)[:120]}")

    finally:
        # restore the production-shaped wiring
        _pages._deps_factory = _prev_factory
        await db.set_setting("website_enabled", _prev_we or "false")
        ns._website_media_gateway = _prev_gw
        ns._mini_app_bot = _prev_bot
        await db.close()

    total = RESULTS["pass"] + RESULTS["fail"]
    print(f"\n{'=' * 60}\nBOT-43 FJ SUITE: {RESULTS['pass']}/{total} passed, "
          f"{RESULTS['fail']} failed")
    if RESULTS["failures"]:
        print("FAILURES:")
        for f in RESULTS["failures"]:
            print("  -", f)
    return 1 if RESULTS["fail"] else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
