PAYLOAD BOT — B18/B23 + PROMPT B UX (on top of ZIP A)

The PROMPT A FIXED release (bot-25 production fixes) with the website
UX upgrade applied ON TOP: vanilla JS + CSS + server-rendered HTML only
(NO framework), the server stays the authorization authority.

PILLARS: 1) Player — ambient mode (5s canvas sampler, reduced-motion +
fullscreen aware, CORS-taint fallback), theater mode (session-persisted
toggle), mini-player (same <video> element docked, queue consumption
with Playing-next/Queue-finished pills + staleness handling), double-tap
seek (+/-10s ripple; single tap toggles controls once), long-press 2x,
chapters (description timestamps only). 2) Discovery — home SHELVES
(Continue Watching client-hydrated from plresume, Trending 7-day views,
New in most-viewed category, Recently added), media SIDEBAR >=1024px
(related >=2 shared tags preferred + trending; horizontal shelves
below), end screen (Next part + Related cards in the last 20s),
autoplay-next toggle (off by default, localStorage), session queue
(sessionStorage, max 50, dedupe by file_pk, add/remove/reorder/clear),
access-aware cards (lock badges; every card still routes through the
server pipeline). 3) Router — the SPA-lite layer completed to the full
vanilla contract (title + meta description only from fetched docs,
data-no-router/download/modifier guards, manual scrollRestoration,
shelf-scroll restore, 2px progress bar, 30s hover prefetch consumed by
the router, Telegram BackButton). 4) Personalization — because-you-
watched, watched checkmark state (plwatched), resume progress bars.
5) Performance — skeletons (shimmer only when motion allowed), first-4
image priority + hero poster preload, prefetch skip on saveData/2G/3G.
6) Mobile — bottom nav <=640px (48px targets, visualViewport keyboard
hide), bottom sheets (drag handle, backdrop, swipe-dismiss, Escape),
edge-swipe More + mini-player swipe-down (with visible equivalents),
500ms card long-press menu. 7) Details — toasts (stack 3, 3s, Escape),
card progress bars (5-95%), hover zoom + accent ring, desktop card
overflow menu (Open / Copy link / Add to queue), queue empty state.

QA: full battery 48/48 ALL GREEN on this tree (updated pins: phase3
A-series + phase3_ux UXB/UXC/UXE/UXF + phase5 OBS2 on the shared search
renderer per B.2.4; bot11 6d allowlist extended for the new in-site
navigations; b22/b23 hybrid pins unchanged and passing). NO framework
introduced; NO authorization moved client-side.

The test/QA archive ships separately as payload-bot_TEST_B18_B23_UX.zip.
