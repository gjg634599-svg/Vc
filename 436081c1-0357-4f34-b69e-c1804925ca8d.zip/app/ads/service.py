"""CENTRALIZED ADS PLATFORM service (GAP-CLOSURE spec §35-§56).

The ONE AdsManager. No ad is ever hard-coded into an individual page —
every ad decision flows through :func:`get_ad_for_placement`:

    Admin → Campaign → Creative → Placement → Ads API →
    Frontend AdsManager → Placement component

CRITICAL INVARIANTS:
  * ADS NEVER BLOCK CONTENT (spec §44): every failure path degrades to
    "no ad" (None) — logged, never raised into the content path.
  * AD / ACCESS SEPARATION (spec §45): the ad decision happens AFTER
    authentication/Force-Join/Access-Engine authorization. Ads can never
    GRANT access and never bypass stream-token authorization; the caller
    only asks for an ad once the content is already authorized.
  * Ad-free users are BACKEND-controlled (spec §46): admins + the
    ``ads_exempt_user_ids`` list; never localStorage.
  * Frequency is stored server-side keyed by the AUTHENTICATED Telegram
    identity (spec §52) — session caps, cooldowns, daily caps.
  * Creative URLs validated on write AND at render (HTTPS only);
    ``html`` creatives render through a strict whitelist sanitizer —
    arbitrary JavaScript injection is impossible (spec §36/§48).
"""
from __future__ import annotations

import html as _html
import logging
import random
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from types import SimpleNamespace
from typing import Any, Dict, List, Optional

logger = logging.getLogger("payload-bot")

# Placement vocabulary (mirrors the repo registry).
PLACEMENTS = (
    "AD_TOP", "AD_HOME_HERO", "AD_HOME_BETWEEN_CONTENT",
    "AD_CATEGORY_TOP", "AD_CATEGORY_BETWEEN", "AD_PAYLOAD_DETAIL",
    "AD_VIDEO_BEFORE", "AD_VIDEO_MIDROLL", "AD_VIDEO_END",
    "AD_SIDEBAR", "AD_FOOTER",
)

# Video-ad placements share one frequency family (a pre-roll, mid-roll and
# post-roll are all "video ads" for cooldown/cap purposes).
_VIDEO_PLACEMENTS = frozenset({
    "AD_VIDEO_BEFORE", "AD_VIDEO_MIDROLL", "AD_VIDEO_END"})

# Creative kinds renderable in DISPLAY slots (spec §36/§37): a video
# creative never renders in a display placement (it would collapse into an
# empty "Advertisement" box — spec §37 forbids exactly that). Video slots
# accept banners as a degraded-but-valid ad (the ad stage renders them).
_DISPLAY_KINDS = frozenset({
    "banner_image", "banner_responsive", "html", "provider"})


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _parse_dt(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value))
    except Exception:  # noqa: BLE001
        return None


# ------------------------------------------------------------- sanitizer
_ALLOWED_TAGS = {
    "a": {"href", "target", "rel"},
    "b": set(), "strong": set(), "i": set(), "em": set(),
    "u": set(), "br": set(), "p": set(), "div": set(), "span": set(),
    "img": {"src", "alt", "width", "height"},
    "small": set(), "center": set(),
}
_TAG_RE = re.compile(r"<\s*(/?)\s*([a-zA-Z0-9]+)([^>]*)>")
_ATTR_RE = re.compile(r"([a-zA-Z0-9-]+)\s*=\s*[\"']([^\"']*)[\"']")


def sanitize_ad_html(raw: str, *, max_len: int = 20000) -> str:
    """STRICT whitelist sanitizer for ``html`` creatives (spec §36/§48).

    Only whitelisted tags survive; only whitelisted attributes survive;
    href/src attribute values pass ad-URL validation (HTTPS only);
    everything else (scripts, iframes, event handlers, styles, unknown
    tags) is dropped. Text content is HTML-escaped at rebuild — the
    output is a FIXED, safe tree, never a passthrough."""
    if not raw:
        return ""
    out: List[str] = []
    pos = 0
    text = str(raw)[:max_len]
    for m in _TAG_RE.finditer(text):
        # escape the text before this tag
        out.append(_html.escape(text[pos:m.start()]))
        pos = m.end()
        closing, tag, attrs_raw = m.group(1), m.group(2).lower(), m.group(3)
        if tag not in _ALLOWED_TAGS:
            continue  # drop the tag entirely (content survives escaped)
        allowed_attrs = _ALLOWED_TAGS[tag]
        if closing:
            out.append(f"</{tag}>")
            continue
        attrs: List[str] = []
        for am in _ATTR_RE.finditer(attrs_raw):
            name, value = am.group(1).lower(), am.group(2)
            if name not in allowed_attrs:
                continue
            if name in ("href", "src"):
                from app.storage.repositories.ads import validate_ad_url
                val = validate_ad_url(value)
                if val is None:
                    continue
                if name == "href":
                    attrs.append(
                        'href="{}" rel="noopener noreferrer" '
                        'target="_blank"'.format(
                            _html.escape(val, quote=True)))
                    continue
            attrs.append('{}="{}"'.format(
                name, _html.escape(value, quote=True)))
        attr_s = (" " + " ".join(attrs)) if attrs else ""
        if tag in ("br", "img"):
            out.append(f"<{tag}{attr_s}>")
        else:
            out.append(f"<{tag}{attr_s}>")
    out.append(_html.escape(text[pos:]))
    return "".join(out)


@dataclass
class AdCreativeView:
    """A SAFE render view of one creative (never raw DB rows)."""
    creative_id: int
    campaign_id: int
    kind: str
    title: str
    click_url: Optional[str]
    alt_text: str
    duration_seconds: int
    skip_enabled: bool
    skip_after_seconds: int
    video_url: Optional[str] = None
    image_desktop_url: Optional[str] = None
    image_mobile_url: Optional[str] = None
    html_safe: Optional[str] = None
    provider_zone: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "creative_id": self.creative_id,
            "campaign_id": self.campaign_id,
            "kind": self.kind,
            "title": self.title,
            "click_url": self.click_url,
            "alt_text": self.alt_text,
            "duration": self.duration_seconds,
            "skip_enabled": self.skip_enabled,
            "skip_after": self.skip_after_seconds,
            "video_url": self.video_url,
            "image_desktop": self.image_desktop_url,
            "image_mobile": self.image_mobile_url,
            "html": self.html_safe,
            "provider_zone": self.provider_zone,
        }


def make_ads_service(db: Any, *, is_admin=None) -> Any:
    """Compose the AdsManager over the repositories (container pattern —
    ONE service factory, no module globals)."""

    async def _setting(key: str, default: str = "") -> str:
        try:
            val = await db.get_setting(key)
            return str(val) if val is not None else default
        except Exception:  # noqa: BLE001
            return default

    async def _setting_bool(key: str, default: bool = False) -> bool:
        raw = await _setting(key, "true" if default else "false")
        return str(raw).strip().lower() in ("1", "true", "yes", "on")

    async def _setting_int(key: str, default: int = 0) -> int:
        try:
            return int(str(await _setting(key, str(default))).strip())
        except Exception:  # noqa: BLE001
            return default

    async def is_ads_exempt(user_id: Optional[int]) -> bool:
        """BACKEND-controlled exemption (spec §46): admins + the explicit
        ads_exempt list. Never client-side."""
        if user_id is None:
            return False
        try:
            if is_admin is not None and await is_admin(int(user_id)):
                return True
        except Exception:  # noqa: BLE001
            pass
        try:
            return int(user_id) in await db.list_ad_exempt_users()
        except Exception:  # noqa: BLE001
            return False

    def _window_key_daily() -> str:
        return "D" + _now_utc().strftime("%Y%m%d")

    def _campaign_active_now(row: Any) -> bool:
        try:
            if str(row["status"]) != "active" or not int(row["enabled"]):
                return False
            now = _now_utc()
            start = _parse_dt(row["start_at"]) if "start_at" in row.keys() else None
            end = _parse_dt(row["end_at"]) if "end_at" in row.keys() else None
            if start is not None and now < start:
                return False
            if end is not None and now > end:
                return False
            return True
        except Exception:  # noqa: BLE001
            return False

    def _campaign_matches(camp: Any, placement: str,
                          category_slug: Optional[str],
                          device: Optional[str]) -> bool:
        import json as _json

        def _list(raw) -> Optional[List[str]]:
            if raw is None or str(raw).strip() == "":
                return None
            try:
                val = _json.loads(str(raw))
                return [str(x) for x in val] if isinstance(val, list) else None
            except Exception:  # noqa: BLE001
                return None
        placements = _list(camp["placements"]) if "placements" in camp.keys() else None
        if placements is not None and placement not in placements:
            return False
        categories = _list(camp["categories"]) if "categories" in camp.keys() else None
        if categories is not None:
            if not category_slug or category_slug not in categories:
                return False
        devices = _list(camp["devices"]) if "devices" in camp.keys() else None
        if devices is not None:
            if not device or device not in devices:
                return False
        return True

    async def _frequency_allows(placement: str, user_id: Optional[int],
                                session_key: Optional[str]) -> bool:
        """The server-side frequency gates (spec §42/§52). Anonymous
        (user_id None) renders skip frequency tracking entirely — they
        simply do not consume caps (honest, never fabricated)."""
        if user_id is None:
            return True
        try:
            uid = int(user_id)
            # video-ad shared family: cooldown + caps apply across the
            # AD_VIDEO_* placements
            family = "AD_VIDEO" if placement in _VIDEO_PLACEMENTS else placement
            cooldown_min = await _setting_int("ads_video_cooldown_minutes", 10)
            daily_cap = await _setting_int("ads_video_daily_cap", 20)
            session_cap = await _setting_int("ads_video_session_cap", 3)
            if placement in _VIDEO_PLACEMENTS:
                # cooldown: last shown within cooldown window?
                row = await db.ad_frequency_get(uid, family, "S")
                if row is not None and row["last_shown_at"]:
                    last = _parse_dt(row["last_shown_at"])
                    if last is not None:
                        age = (_now_utc() - last).total_seconds() / 60.0
                        if cooldown_min > 0 and age < cooldown_min:
                            return False
                # daily cap
                if daily_cap > 0:
                    row = await db.ad_frequency_get(uid, family,
                                                    _window_key_daily())
                    if row is not None and int(row["count"]) >= daily_cap:
                        return False
                # session cap (per browser session key)
                if session_cap > 0 and session_key:
                    row = await db.ad_frequency_get(
                        uid, family, "B" + str(session_key)[:40])
                    if row is not None and int(row["count"]) >= session_cap:
                        return False
            return True
        except Exception as exc:  # noqa: BLE001 — frequency failures NEVER block
            logger.warning("ADS_FREQUENCY_ERROR placement=%s err=%s",
                           placement, type(exc).__name__)
            return True

    async def _record_serve(placement: str, user_id: Optional[int],
                            session_key: Optional[str]) -> None:
        if user_id is None:
            return
        try:
            family = "AD_VIDEO" if placement in _VIDEO_PLACEMENTS else placement
            await db.ad_frequency_bump(int(user_id), family, "S")
            await db.ad_frequency_bump(int(user_id), family,
                                       _window_key_daily())
            if session_key:
                await db.ad_frequency_bump(
                    int(user_id), family, "B" + str(session_key)[:40])
        except Exception as exc:  # noqa: BLE001
            logger.warning("ADS_SERVE_RECORD_ERROR placement=%s err=%s",
                           placement, type(exc).__name__)

    async def _creative_view(row: Any) -> Optional[AdCreativeView]:
        """DB row → SAFE view with render-time URL re-validation."""
        from app.storage.repositories.ads import validate_ad_url

        def _col(name: str) -> Any:
            return row[name] if name in row.keys() else None
        v_video = validate_ad_url(_col("video_url"))
        v_desktop = validate_ad_url(_col("image_desktop_url"))
        v_mobile = validate_ad_url(_col("image_mobile_url"))
        v_click = validate_ad_url(_col("click_url"))
        # Render-time honesty: a creative whose URL has become invalid
        # (or was forged) serves NOTHING rather than a broken ad.
        kind = str(_col("kind") or "")
        if kind == "video" and not v_video:
            return None
        if kind == "banner_image" and not (v_desktop or v_mobile):
            return None
        html_safe = None
        if kind == "html":
            html_safe = sanitize_ad_html(str(_col("html_content") or ""))
            if not html_safe.strip():
                return None
        if kind == "provider" and not (_col("provider_zone") or "").strip():
            return None
        return AdCreativeView(
            creative_id=int(_col("id")),
            campaign_id=int(_col("campaign_id")),
            kind=kind,
            title=str(_col("title") or ""),
            click_url=v_click,
            alt_text=str(_col("alt_text") or ""),
            duration_seconds=int(_col("duration_seconds") or 0),
            skip_enabled=bool(int(_col("skip_enabled") or 0)),
            skip_after_seconds=int(_col("skip_after_seconds") or 0),
            video_url=v_video,
            image_desktop_url=v_desktop,
            image_mobile_url=v_mobile,
            html_safe=html_safe,
            provider_zone=str(_col("provider_zone") or "") or None,
        )

    async def get_ad_for_placement(
            placement: str, *,
            user_id: Optional[int] = None,
            session_key: Optional[str] = None,
            category_slug: Optional[str] = None,
            device: Optional[str] = None,
            record_impression: bool = True,
    ) -> Optional[Dict[str, Any]]:
        """THE ad decision (spec §35). Returns a safe creative view dict or
        None (slot collapses completely — spec §37). NEVER raises: an ads
        failure can never block content delivery (spec §44)."""
        try:
            if placement not in PLACEMENTS:
                return None
            if not await _setting_bool("ads_enabled", False):
                return None
            if not await db.get_ad_placement_enabled(placement):
                return None
            if await is_ads_exempt(user_id):
                return None
            if not await _frequency_allows(placement, user_id, session_key):
                return None
            # eligible campaigns: active + targeting match, priority order
            camps = await db.list_ad_campaigns(include_disabled=False)
            eligible = [c for c in camps
                        if _campaign_active_now(c)
                        and _campaign_matches(c, placement, category_slug,
                                              device)]
            if not eligible:
                return None
            eligible.sort(key=lambda c: int(c["priority"]), reverse=True)
            # per-user campaign frequency caps
            chosen_camp = None
            for camp in eligible:
                cap = int(camp["frequency_cap_per_user"] or 0)
                if cap > 0 and user_id is not None:
                    hours = max(1, int(camp["frequency_cap_hours"] or 24))
                    key = "C{}-{}".format(int(camp["id"]), hours)
                    row = await db.ad_frequency_get(int(user_id),
                                                    placement, key)
                    if row is not None and int(row["count"]) >= cap:
                        continue
                    chosen_camp = camp
                    await db.ad_frequency_bump(int(user_id), placement, key)
                    break
                chosen_camp = camp
                break
            if chosen_camp is None:
                return None
            creatives = await db.list_ad_creatives(int(chosen_camp["id"]),
                                                   include_disabled=False)
            if not creatives:
                return None
            # GAP-CLOSURE (spec §36/§37): the creative KIND must fit the
            # placement family. Display slots only serve display kinds;
            # video slots prefer video creatives and accept banners as a
            # degraded ad (the player's ad stage renders both).
            if placement in _VIDEO_PLACEMENTS:
                ordered = ([c for c in creatives
                            if str(c["kind"] or "") == "video"]
                           + [c for c in creatives
                              if str(c["kind"] or "") != "video"])
            else:
                ordered = [c for c in creatives
                           if str(c["kind"] or "") in _DISPLAY_KINDS]
            view = None
            for c in ordered:
                view = await _creative_view(c)
                if view is not None:
                    break
            if view is None:
                return None
            if record_impression:
                await db.log_ad_event(view.creative_id, view.campaign_id,
                                      placement, user_id, "impression")
                await _record_serve(placement, user_id, session_key)
            return view.to_dict()
        except Exception as exc:  # noqa: BLE001 — NEVER block content
            logger.warning("ADS_DECISION_ERROR placement=%s err=%s",
                           placement, type(exc).__name__)
            return None

    async def should_show_video_ad(
            *, user_id: Optional[int] = None,
            session_key: Optional[str] = None,
            video_count_in_session: int = 0,
            first_video_only: Optional[bool] = None,
    ) -> bool:
        """The video pre-roll decision (spec §42): cooldown + session cap +
        daily cap + first-video-only + every-N + probability. The decision
        is SERVER-side; the client only ASKS."""
        try:
            if not await _setting_bool("ads_enabled", False):
                return False
            if not await db.get_ad_placement_enabled("AD_VIDEO_BEFORE"):
                return False
            if await is_ads_exempt(user_id):
                return False
            first_only = (first_video_only if first_video_only is not None
                          else await _setting_bool("ads_video_first_only",
                                                   False))
            if first_only and int(video_count_in_session) > 0:
                return False
            every_n = await _setting_int("ads_video_every_n", 0)
            if every_n > 0:
                n = int(video_count_in_session)
                if n % every_n != 0:
                    return False
            prob = await _setting_int("ads_video_probability", 100)
            if prob < 100 and random.randint(1, 100) > prob:
                return False
            return await _frequency_allows("AD_VIDEO_BEFORE", user_id,
                                           session_key)
        except Exception as exc:  # noqa: BLE001
            logger.warning("ADS_VIDEO_DECISION_ERROR err=%s",
                           type(exc).__name__)
            return False

    async def record_event(creative_id: int, placement: str,
                           user_id: Optional[int], event: str) -> None:
        """Bounded event recording (spec §51) — never raises."""
        try:
            row = await db.get_ad_creative(int(creative_id))
            if row is None:
                return
            await db.log_ad_event(int(creative_id),
                                  int(row["campaign_id"]),
                                  str(placement), user_id, event)
        except Exception as exc:  # noqa: BLE001
            logger.warning("ADS_EVENT_ERROR creative=%s err=%s",
                           creative_id, type(exc).__name__)

    async def analytics_summary(days: int = 7) -> Dict[str, Any]:
        try:
            return await db.ad_analytics_summary(days=days)
        except Exception as exc:  # noqa: BLE001
            logger.warning("ADS_ANALYTICS_ERROR err=%s", type(exc).__name__)
            return {"days": days, "error": type(exc).__name__}

    return SimpleNamespace(
        get_ad_for_placement=get_ad_for_placement,
        should_show_video_ad=should_show_video_ad,
        record_event=record_event,
        is_ads_exempt=is_ads_exempt,
        analytics_summary=analytics_summary,
        sanitize_ad_html=sanitize_ad_html,
    )
