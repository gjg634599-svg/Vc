"""Application composition root (ARCHITECTURE PROPER BREAKDOWN).

THE single authoritative production composition path:

``run.py → run_production() → build_application(runtime)
        → app/presentation/telegram (handlers/state sections)
        → app/services/container.py (service composition)
        → app/core/* domain services
        → app/storage/* persistence (schema v32)
        → app/media/*, app/network/*, app/web/* infrastructure``

``run_production(runtime=None)`` loads the Telegram presentation runtime
(app/presentation/telegram — the assembled namespace object) when not
explicitly supplied, then runs the polling loop. The token/admin
fail-closed guards are preserved VERBATIM from the Phase 5
``build_application``.

This module owns composition MECHANICS only — no business logic, no
repositories, no Telegram handler implementations. It may import every
layer (composition root privilege); business modules never import it.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional, Sequence

logger = logging.getLogger("app.bootstrap")


def ptb_local_api_endpoints() -> Optional[Dict[str, str]]:
    """GAP-CLOSURE spec §15: PTB base_url/base_file_url for Local mode.

    When ``TELEGRAM_API_MODE=local`` is ACTUALLY used, the python-telegram-bot
    Application must be pointed at the Local Bot API server (base_url for
    API methods, base_file_url for file downloads) — for the MAIN bot AND
    every network worker. Cloud and auto modes keep the normal Telegram
    API URL (AUTO shifts media traffic at the media layer only, runtime
    PTB traffic stays on the cloud API so a flapping local server can
    never take the bot itself down).

    Returns {"base_url": ..., "base_file_url": ...} or None (cloud).
    PURE stdlib — importable by the network lifecycle without cycles.
    """
    try:
        from app.media.config import MediaTransportConfig, MODE_LOCAL
        cfg = MediaTransportConfig.from_env()
    except Exception:  # noqa: BLE001 — media env invalid → cloud PTB URLs
        return None
    if cfg.api_mode != MODE_LOCAL or not cfg.local_api_url:
        return None
    base = str(cfg.local_api_url).rstrip("/")
    return {"base_url": base, "base_file_url": f"{base}/file"}


def create_application(builder: Any, config: Dict[str, Any],
                       handlers: Dict[str, Sequence[Any]],
                       error_handler: Optional[Callable] = None,
                       post_init: Optional[Callable] = None,
                       post_shutdown: Optional[Callable] = None) -> Any:
    """Compose a PTB Application.

    ``handlers`` maps a kind ("command", "message", "callback",
    "chat_join_request") to a list of (args..., handler) registration
    entries — exactly the registration grammar used by the presentation
    runtime, expressed as data.

    GAP-CLOSURE spec §15: in Local mode the builder is pointed at the
    Local Bot API server via ``base_url``/``base_file_url`` (the correct
    PTB mechanism — PTB appends ``/bot<token>/<method>`` itself).
    """
    endpoints = ptb_local_api_endpoints()
    if endpoints is not None:
        builder = builder.base_url(endpoints["base_url"])
        builder = builder.base_file_url(endpoints["base_file_url"])
        logger.info(
            "PTB_LOCAL_API_WIRING main bot -> local Bot API server "
            "(base_url/base_file_url configured per spec §15)")
    app = (
        builder
        .token(config["bot_token"])
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .concurrent_updates(True)
        .build()
    )
    for kind, entries in handlers.items():
        for entry in entries:
            app.add_handler(entry)
    if error_handler is not None:
        app.add_error_handler(error_handler)
    return app


def load_runtime() -> Any:
    """Load the Telegram presentation runtime (the assembled namespace).

    The single handler-provider object: state + every section function
    rebound into one late-binding namespace
    (app/presentation/telegram/namespace.py). NEVER bot.py — that module
    no longer exists.
    """
    from app.presentation.telegram import runtime  # composition privilege
    return runtime


def build_application(runtime: Any = None) -> Any:
    """Build the production PTB Application from the presentation runtime.

    Fail-closed guards preserved verbatim from the Phase 5
    ``build_application``:

    * BOT_TOKEN sentinel → RuntimeError (never start unconfigured);
    * missing ADMIN_IDS → RuntimeError (Admin Security Hardening — the
      bot refuses to start without explicit admins).

    Handler registration order is preserved exactly via
    ``app/presentation/telegram/registration.py``.
    """
    if runtime is None:
        runtime = load_runtime()
    if not runtime.BOT_TOKEN or runtime.BOT_TOKEN == "PUT_YOUR_BOT_TOKEN_HERE":
        raise RuntimeError(
            "BOT_TOKEN is not configured. Set the BOT_TOKEN environment variable."
        )
    # Issue: Admin Security Hardening — refuse to start without explicit admins.
    if not runtime.ADMIN_IDS:
        raise RuntimeError(
            "ADMIN_IDS environment variable is required. "
            "Set it to a comma-separated list of Telegram user IDs (e.g. '123456789,987654321'). "
            "The bot refuses to start without explicit admin configuration for security."
        )

    from telegram.ext import ApplicationBuilder  # local: Telegram layer only

    from app.presentation.telegram.registration import build_handler_registry

    entries: List[Any] = build_handler_registry(runtime)
    return create_application(
        ApplicationBuilder(),
        {"bot_token": runtime.BOT_TOKEN},
        {"handlers": entries},
        error_handler=runtime.on_error,
        post_init=runtime.post_init,
        post_shutdown=runtime.post_shutdown,
    )


def run_production(runtime: Any = None) -> None:
    """Run the production polling loop.

    Loads the presentation runtime (app/presentation/telegram) unless one
    is explicitly injected (tests). Behavior is identical to the Phase 5
    ``main()``: the same startup log line, the same construction path,
    the same ``run_polling(allowed_updates=...)``.
    """
    from telegram import Update  # local: Telegram layer only

    if runtime is None:
        runtime = load_runtime()
    runtime.logger.info(
        "Starting Telegram Payload Delivery Bot (BOTV13 — Phase 7 Hotfix)...")
    app = build_application(runtime)
    app.run_polling(allowed_updates=Update.ALL_TYPES)
