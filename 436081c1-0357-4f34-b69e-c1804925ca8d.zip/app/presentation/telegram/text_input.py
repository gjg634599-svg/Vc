"""Text & media input — text_handler and on_media_input.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations

# BOT-45/46 (Task D): module-local imports for the live source-identity
# helpers defined at the bottom of this module. These are NOT namespace
# names — the manifest-owned (rebound) functions above keep resolving
# every collaborator through the shared namespace; the helpers below are
# plain module-level functions whose collaborators are either passed in
# explicitly (by the rebound text_handler) or resolved through the
# registered runtime namespace at call time.
import hashlib as _ti_hashlib
import logging as _ti_logging
import sys as _ti_sys
from typing import Any as _TiAny, Dict as _TiDict, Optional as _TiOptional

_ti_log = _ti_logging.getLogger("payload-bot")


def _ti_runtime_ns():
    """Resolve the shared presentation runtime namespace at CALL time.

    The runtime module is registered by namespace.py before any handler
    fires, so event-time lookups always succeed; a None return (direct
    import during assembly) leaves the caller on its explicit-argument
    path.
    """
    return _ti_sys.modules.get("app.presentation.telegram.runtime")



# ============================================================
# TEXT / MEDIA INPUT HANDLER  (admin editing states + user password)
# ============================================================
async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not user:
        return
    # BOTV13 Phase 3 (Group Safety): ignore ordinary group/supergroup messages.
    # The bot only operates in private chats for text input. This prevents group
    # messages from triggering admin states, password capture, or fallback
    # replies. Callback queries (inline buttons) are NOT affected — they use a
    # separate handler and are allowed in any chat type.
    chat_type = update.effective_chat.type if update.effective_chat else None
    if chat_type in ("group", "supergroup"):
        return
    text = update.message.text.strip() if update.message else ""

    # ---- v36: single-active-conversation guard (defense in depth) ----
    # on_callback purges stale input states on every non-entry callback;
    # this additionally reconciles any multi-state situation at TEXT time
    # (e.g. states persisted across a mid-version upgrade): only the MOST
    # RECENT conversation survives, expired states are dropped.
    _surviving_conv = reconcile_conversation_input_states(context)

    # ---- NETWORK PLATFORM (v29): registration token capture ----
    # Checked FIRST: a submitted bot token must NEVER fall through to any
    # other text path (search / broadcast / echo) — it is a secret.
    _net_state = context.user_data.get(_NET_REG_STATE_KEY)
    # b10 §1 (B10-B2): the DURABLE per-user token-input intent gates the
    # capture — the wizard state may have been purged by unrelated
    # callback navigation (the bot-10.log root cause) while the user is
    # still looking at the "Send the Bot Token" prompt. The intent
    # survives that purge; the token is accepted ONLY while it is live.
    _token_intent = get_pending_token_intent(int(user.id))
    if _net_state and str(_net_state.get("step")) in ("await_token",
                                                      "await_consent"):
        await handle_network_registration_text(update, context, user, text)
        return
    if not _net_state and _token_intent \
            and _token_intent.get("flow") == "net_reg" \
            and str(_token_intent.get("step")) == "await_token":
        await handle_network_registration_text(update, context, user, text)
        return

    # ---- FILE DELIVERY v34 → MANAGED BOTS v37 (Task 8): the ONLY token
    # capture left on the create surface is the ADMIN-ONLY legacy manual
    # import (nleg_state — spec §27) + Control Bot credential inputs
    # (spec §25/§64) — same secret-first discipline as the registration
    # wizard. The primary create path (ncreate:) is the managed-bot flow
    # and never asks for text.
    if await handle_nleg_text(update, context, user, text):
        return
    if await handle_control_owner_text(update, context, user, text):
        return
    if await handle_control_text(update, context, user, text):
        return

    # ---- b10 §1 (B10-B2): token-shaped text with NO active token input ----
    # The bot-10.log §1 failure class: the user pastes a bot token while
    # NO token-input intent is live (stale prompt, expired flow, or a
    # plain mistake) and the secret fell through to the GENERIC admin
    # fallback ("Use the admin panel (/start)..."). A pasted token is a
    # SECRET: it is never registered without intent, never echoed and
    # never falls through to any other text path — the user gets ONE
    # honest notice. Only fires when NO other conversation input state
    # owns the text (those handlers above already ran).
    if not _surviving_conv and _net_token_format_ok(text):
        logger.info(
            "BOT_TOKEN_FLOW_FAILED user_id=%s flow=- "
            "reason=no_active_token_input (token-shaped text ignored; "
            "content never logged)", int(user.id))
        await safe_send_text(
            context.bot, update.effective_chat.id,
            "ℹ️ No bot-token input is active right now — nothing was "
            "saved.\n\n"
            "To register a bot: /network → Add Existing Bot → I have the "
            "token.\n"
            "To import an existing bot (admins): /network → Create "
            "Network Bot → Legacy Manual Import.")
        return

    # ---- NETWORK PLATFORM (v29): broadcast wizard content ----
    _bcast_state = context.user_data.get("net_bcast_state")
    if _bcast_state and str(_bcast_state.get("step")) == "await_content":
        if await is_admin(user.id):
            await handle_network_broadcast_text(update, context, user, text)
            return

    # ---- user password capture ----
    awaiting = context.user_data.get("awaiting_password")
    if awaiting:
        if not rate_limiter.check(user.id):
            await reply_protected(update, "\u23F3 Too many attempts. Wait a bit.")
            return
        context.user_data.pop("awaiting_password", None)
        row = await db.get_payload(awaiting)
        if row and row["password"] and verify_password(text, row["password"]):
            # H3 Fix: if the stored password is legacy plaintext, upgrade it.
            if not is_password_hashed(row["password"]):
                await db.update_payload_field(row["id"], "password", hash_password(text))
            verified: Set[str] = set(context.user_data.get("pw_verified", []))
            verified.add(awaiting)
            context.user_data["pw_verified"] = verified
            await reply_protected(update, "\u2705 Password accepted.")
            await finalize_delivery(update, context, awaiting, user)
        else:
            await reply_protected(update, "\u274C Incorrect password. Access denied.")
        return

    # ---- Access Engine V1: Payload Creation Wizard text inputs ----
    # Handles: name entry, file (message ID) entry, custom required referrals,
    # and preview description. All admin-only (state is never set for non-admins).
    # BOT7 FIX (DB-admin): use the canonical async is_admin() instead of the raw
    # ADMIN_IDS membership test so DB-created active admins can drive the wizard.
    pcw_state = _pcw_get(context)
    if pcw_state and await is_admin(user.id):
        # Wizard ownership: state is per-user via context.user_data, but we
        # also stamp owner_id for defense-in-depth and reject foreign owners.
        _wiz_owner = pcw_state.get("owner_id")
        if _wiz_owner is not None and int(_wiz_owner) != int(user.id):
            logger.warning(
                "BOT6_ADMIN_WIZARD_CANCEL wizard=pcw user_id=%s owner_id=%s "
                "reason=owner_mismatch action=rejected",
                user.id, _wiz_owner,
            )
            await reply_protected(update,
                "❌ This action has expired or is no longer valid.")
            _pcw_clear(context)
            return
        step = pcw_state.get("step", "name")
        if step == "name" or step == "awaiting_name":
            # BOTV13 Part 1: Accept human-readable display names (spaces, mixed case).
            # The display_name is stored as-is (sanitized). The routing ID
            # (slug) is a random 8-char hex token — NEVER derived from the
            # display name — so renaming the display name never breaks links
            # and multiple payloads can share the same display name.
            # Collections override this with c<code> at create time.
            display_name = sanitize_display_name(text)
            if not validate_display_name(display_name):
                await reply_protected(update,
                    "\u274C Could not generate a valid name from that input.\n"
                    "Use letters, digits, spaces, or hyphens (max 128).")
                # Stay on name step.
                pcw_state["step"] = "name"
                await pcw_show_name_step(update, context)
                return
            # Generate a unique random routing ID (8-char hex).
            # In edit mode, keep the existing routing ID (it's immutable).
            if pcw_state.get("mode") == "edit":
                slug = pcw_state.get("name") or ""
            else:
                slug = generate_routing_id()
                # Ensure uniqueness (extremely unlikely to collide, but safe).
                for _ in range(5):
                    if not await db.get_payload(slug):
                        break
                    slug = generate_routing_id()
                if await db.get_payload(slug):
                    await reply_protected(update,
                        "\u274C Could not generate a unique routing ID. Please try again.")
                    pcw_state["step"] = "name"
                    await pcw_show_name_step(update, context)
                    return
            # Store BOTH: display_name (human-readable) + slug (routing ID).
            pcw_state["display_name"] = display_name
            pcw_state["name"] = slug
            # If no file pre-selected (and not a collection / not edit mode),
            # go to file step; else go to policy.
            if _pcw_has_file(pcw_state):
                await pcw_show_policy_step(update, context)
            else:
                await pcw_show_file_step(update, context)
            return
        if step == "file":
            # Accept a message ID. Resolve to indexed_files row.
            try:
                msg_id = int(text.strip())
            except ValueError:
                await reply_protected(update,
                    "\u274C Send a numeric Message ID, or forward a file "
                    "from a storage channel.")
                return
            frow = await db.get_indexed_file_by_message_id(msg_id)
            if not frow:
                await reply_protected(update,
                    f"\u274C No indexed file found for Message ID {msg_id}.")
                return
            pcw_state["index_id"] = int(frow["id"])
            await safe_send_text(context.bot, update.effective_chat.id,
                f"\u2705 File selected: {truncate(frow['file_name'], 60) or '(unnamed)'}")
            await pcw_show_policy_step(update, context)
            return
        if step == "reqcustom":
            try:
                n = max(0, int(text.strip()))
            except ValueError:
                await reply_protected(update,
                    "\u274C Must be a number (0 = instant unlock). Cancelled.")
                return
            pcw_state["required_referrals"] = n
            await safe_send_text(context.bot, update.effective_chat.id,
                f"\u2705 Required referrals set to {n}.")
            await pcw_show_referrals_step(update, context)
            return
        if step == "prevdesc":
            desc = truncate(text, limit=1024)
            pcw_state["preview_description"] = desc
            await safe_send_text(context.bot, update.effective_chat.id,
                "\u2705 Preview text saved.")
            await pcw_show_preview_step(update, context)
            return
        # step == "prevmedia" is handled in on_media_input (media upload).
        # Other steps have no text input — fall through to admin states below.

    # ---- WATCH_AD (v25): admin text inputs (Mini App URL / Monetag SDK) ----
    # Cancel restores the previous state; a FAILED validation never overwrites
    # the existing working value — only successful validation persists.
    if context.user_data.get("awaiting_wad_template") and await is_admin(user.id):
        # BOTV13 PHASE 6 (§2): the Ads Unlock Message template editor.
        context.user_data.pop("awaiting_wad_template", None)
        if text.lower() in ("/cancel", "cancel"):
            await reply_protected(update,
                "\u274C Cancelled. The unlock template was not changed.")
            return
        normalized, err = validate_watch_ads_unlock_template(text)
        if err:
            # Failed validation: the working template is NOT overwritten.
            logger.info("WATCH_AD_TEMPLATE_INVALID admin=%s reason=%s",
                        user.id, err[:80])
            await safe_send_text(context.bot, update.effective_chat.id,
                f"\u274C {err}\n\nSend a corrected template, or send cancel "
                "to keep the current value.")
            context.user_data["awaiting_wad_template"] = True
            return
        await db.set_setting(WATCH_AD_TEMPLATE_SETTING_KEY, normalized)
        await log_admin_action(user.id, "set_watch_ads_template", "setting",
                               None, f"length={len(normalized)}")
        unknown = _watch_ads_template_unknown_placeholders(normalized)
        logger.info("WATCH_AD_TEMPLATE_SAVE admin=%s length=%d "
                    "placeholders_known=%d placeholders_unknown=%d",
                    user.id, len(normalized),
                    len(_WATCH_AD_TEMPLATE_FIELDS),
                    len(unknown))
        warn_line = ""
        if unknown:
            warn_line = ("\n\n\u26A0\uFE0F Unknown placeholders: "
                         + ", ".join(unknown)
                         + "\n(they will render literally.)")
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u2705 Ads Unlock Message saved.\n\n"
            "Every Watch Ads access screen now uses this wording."
            + warn_line,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001F3AC Back to Ads Unlock Message",
                                      callback_data="wadcfg:tpl")],
                [InlineKeyboardButton("\u2B05\uFE0F Back to Watch Ads Settings",
                                      callback_data="panel:wadsettings")],
            ]))
        return
    if context.user_data.get("awaiting_wad_url") and await is_admin(user.id):
        context.user_data.pop("awaiting_wad_url", None)
        if text.lower() in ("/cancel", "cancel"):
            await reply_protected(update, "\u274C Cancelled. The website URL was not changed.")
            return
        normalized, err = validate_watch_ads_mini_app_url(text)
        if err:
            # Failed validation: keep the OLD value untouched, re-offer input.
            await safe_send_text(context.bot, update.effective_chat.id,
                f"\u274C {err}\n\nSend a valid HTTPS URL, or send cancel to keep "
                "the current value.")
            context.user_data["awaiting_wad_url"] = True
            return
        await db.set_setting("watch_ads_mini_app_url", normalized)
        await log_admin_action(user.id, "set_watch_ads_url", "setting", None,
                                f"url={normalized}")
        logger.info("Watch Ads Mini App URL configured (admin=%s).", user.id)
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u2705 Mini App Website saved.\n\n"
            f"{normalized}\n\n"
            "New Watch Ad sessions will use this URL.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back to Watch Ads Settings",
                                      callback_data="panel:wadsettings")],
            ]))
        return
    if context.user_data.get("awaiting_wad_sdk") and await is_admin(user.id):
        context.user_data.pop("awaiting_wad_sdk", None)
        if text.lower() in ("/cancel", "cancel"):
            await reply_protected(update, "\u274C Cancelled. The Monetag SDK was not changed.")
            return
        accepted, err = validate_watch_ads_sdk_code(text)
        if err:
            # Failed validation: the existing working SDK is NOT overwritten.
            await safe_send_text(context.bot, update.effective_chat.id,
                f"\u274C {err}\n\nPaste the SDK/ad-tag code copied from your Monetag "
                "dashboard, or send cancel to keep the current value.")
            context.user_data["awaiting_wad_sdk"] = True
            return
        await db.set_setting("watch_ads_monetag_sdk", accepted)
        await log_admin_action(user.id, "set_watch_ads_sdk", "setting", None,
                                f"length={len(accepted)}")
        # NEVER log the SDK contents.
        logger.info("Watch Ads Monetag SDK configured (admin=%s, %d chars, "
                    "contents not logged).", user.id, len(accepted))
        await safe_send_text(context.bot, update.effective_chat.id,
            "\U0001F4DC Monetag SDK saved.\n\n"
            "The SDK is securely stored and will be used by\n"
            "the Watch Ads Mini App.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back to Watch Ads Settings",
                                      callback_data="panel:wadsettings")],
            ]))
        return

    # ---- v36 §18A: Monetag WEBSITE SDK / ad-tag paste (admin) — the
    # NORMAL Website surface, validated with the website tag rules and
    # stored in the DEDICATED website_monetag_ad_tag setting (never the
    # TMA SDK key, never echoed, never logged in full).
    if context.user_data.get("awaiting_wsdk") and await is_admin(user.id):
        _wsdk_state = context.user_data.pop("awaiting_wsdk", None)
        if text.lower() in ("/cancel", "cancel"):
            await reply_protected(update, "\u274C Cancelled. The Website SDK "
                                         "was not changed.")
            return
        if _conversation_state_expired(_wsdk_state):
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u23F3 The Website SDK input timed out (10 min) — nothing "
                "was changed.")
            return
        accepted, err = _validate_website_ad_tag(text)
        if err:
            # Failed validation: the existing working tag is NOT overwritten.
            await safe_send_text(context.bot, update.effective_chat.id,
                f"\u274C {err}\n\nPaste the exact Website SDK/ad-tag code "
                "supplied by Monetag for the website surface, or send "
                "cancel to keep the current value.")
            context.user_data["awaiting_wsdk"] = stamp_conversation_state(
                {"step": "await_tag"})
            return
        await db.set_setting("website_monetag_ad_tag", accepted)
        await log_admin_action(user.id, "set_website_monetag_sdk", "setting",
                               None, f"length={len(accepted)}")
        # NEVER log the tag contents.
        logger.info("Website Monetag SDK configured (admin=%s, %d chars, "
                    "contents not logged).", user.id, len(accepted))
        await safe_send_text(context.bot, update.effective_chat.id,
            "\U0001F310 Website Monetag SDK saved.\n\n"
            "The ad tag is securely stored and will be injected\n"
            "into the /site Website pages only (never into the\n"
            "Mini App, never into Telegram bot messages).",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Website SDK",
                                      callback_data="wadcfg:wsdk")],
            ]))
        return

    # ---- WEBSITE PHASE 3: Website wizard text inputs (Add Website Payload
    # link step + listing field editors) — app/presentation/telegram/website_ui.py.
    # Checked here so the wsite states capture text BEFORE the generic
    # admin/search/broadcast fallbacks below.
    if context.user_data.get("wsite_wizard") or context.user_data.get("wsite_edit"):
        if await _handle_wsite_text(update, context, user, text):
            return

    # ---- GAP-CLOSURE: Website Categories + Ads admin panels text inputs
    # (new-category wizard, per-category editors, new campaign / new
    # creative wizards, campaign editors, exempt-user add) —
    # app/presentation/telegram/website_gap_ui.py. Checked right after the
    # wsite states, BEFORE the generic admin/search/broadcast fallbacks.
    if any(context.user_data.get(_gap_key) for _gap_key in
           ("wsitecat_wizard", "wsitecat_edit", "wsad_wizard", "wsad_edit")):
        if await _handle_gap_text(update, context, user, text):
            return

    # ---- Task 9: VIDEO PRE-ROLL ADS URL text inputs (wspr: panel) —
    # app/presentation/telegram/website_preroll_ui.py, consumed through the
    # _handle_wspr_text facade (cancel/timeout/invalid keep the old value;
    # only a validated https URL is ever saved). Checked BEFORE the generic
    # admin/search/broadcast fallbacks.
    if context.user_data.get("awaiting_wspr_src") \
            or context.user_data.get("awaiting_wspr_vast"):
        if await _handle_wspr_text(update, context, user, text):
            return

    # ---- PHASE 6 §12: Force-Join custom join link (text input) ----
    # Must run BEFORE the admin gate / generic fallback. Non-admins never
    # have this state set.
    _fj_link_cid = context.user_data.get("awaiting_fj_custom_link")
    if _fj_link_cid and await is_admin(user.id):
        context.user_data.pop("awaiting_fj_custom_link", None)
        if text.lower() in ("/cancel", "cancel"):
            await reply_protected(update,
                "\u274C Cancelled. The join link was not changed.")
            return
        normalized, err = _fj_validate_custom_link(text)
        if err:
            # Failed validation: the working link is NOT overwritten.
            await safe_send_text(context.bot, update.effective_chat.id,
                f"\u274C {err}\n\nSend a valid Telegram invite link, or send "
                "cancel to keep the current one.")
            context.user_data["awaiting_fj_custom_link"] = _fj_link_cid
            return
        old_link = await db.get_force_invite_link(int(_fj_link_cid))
        # B18: custom links are stored with provenance='custom' (schema
        # v39) — the Bot API has NO getChatInviteLink, so provenance is the
        # only durable distinction from bot-created links (which are
        # provably valid until our own rotation revokes them).
        await db.set_force_invite_link(int(_fj_link_cid), normalized,
                                       provenance="custom")
        await log_admin_action(user.id, "set_fj_custom_link", "channel",
                               int(_fj_link_cid),
                               f"old={_fj_invite_prefix(old_link)} "
                               f"new={_fj_invite_prefix(normalized)}")
        logger.info("FORCE_JOIN_INVITE_SET channel_id=%s old_link=%s "
                    "new_link=%s source=custom",
                    int(_fj_link_cid), _fj_invite_prefix(old_link),
                    _fj_invite_prefix(normalized))
        # PHASE 8 (§15) + B18: custom links are VERIFIED against the
        # intended channel where the Bot API permits it — a syntactically
        # valid t.me link proves nothing about ownership. B18's verifier
        # no longer depends on the nonexistent getChatInviteLink: public
        # links are proven by username resolution (id match), invite
        # links by the channel evidence (bot admin + trusted hash — the
        # Bot API cannot introspect invite hashes at all).
        _cid_int = int(_fj_link_cid)
        _kind = _fj_health.link_syntax_kind(normalized)
        _verdict = "syntax_valid"
        _verdict_note = ("Syntax validated. Telegram cannot verify public "
                         "username links — the channel must actually own "
                         "this @username.")
        if _kind == "public":
            try:
                _verify = await _fj_health.verify_invite_link(
                    context.bot, _cid_int, normalized, channel_accessible=True)
                if _verify.state == _fj_health.LINK_HEALTHY:
                    _verdict = "telegram_verified"
                    _verdict_note = ("Telegram VERIFIED this @username "
                                     "resolves to this channel.")
                elif _verify.state == _fj_health.LINK_INVALID:
                    _verdict = "unverifiable"
                    _verdict_note = ("The @username resolves to a DIFFERENT "
                                     "chat (or to nothing). The link is "
                                     "stored but NOT confirmed — verify "
                                     "the username.")
                else:
                    _verdict = "unverifiable"
                    _verdict_note = ("Username resolution hit a transient "
                                     "Telegram error — the link is stored; "
                                     "run Test Channel later to verify it.")
            except Exception as e:  # noqa: BLE001 — verification is advisory
                _verdict = "unverifiable"
                _verdict_note = f"Verification failed ({type(e).__name__})."
        elif _kind == "invite":
            try:
                _verify = await _fj_health.verify_invite_link(
                    context.bot, _cid_int, normalized, channel_accessible=True)
                if _verify.state == _fj_health.LINK_HEALTHY:
                    _verdict = "channel_verified"
                    _verdict_note = ("Channel verified (bot administrator). "
                                     "The Bot API cannot introspect invite "
                                     "hashes — the link is stored as "
                                     "trusted; users joining will prove it "
                                     "definitively.")
                elif _verify.state == _fj_health.BOT_PERMISSION:
                    _verdict = "unverifiable"
                    _verdict_note = ("The bot is not an administrator in "
                                     "this channel — the link is stored "
                                     "but NOT confirmed. Grant the bot "
                                     "admin rights, then run Test Channel.")
                elif _verify.state == _fj_health.CHANNEL_INVALID:
                    _verdict = "unverifiable"
                    _verdict_note = ("The channel is not accessible to the "
                                     "bot — the link is stored but NOT "
                                     "confirmed.")
                else:
                    _verdict = "unverifiable"
                    _verdict_note = ("Verification hit a temporary Telegram "
                                     "error — the link is stored; run Test "
                                     "Channel later to verify it.")
            except Exception as e:  # noqa: BLE001 — verification is advisory
                _verdict = "unverifiable"
                _verdict_note = f"Verification failed ({type(e).__name__})."
        await db.update_force_link_validation(_cid_int, _verdict)
        _FJ_LINK_HEALTH_CACHE.invalidate(_cid_int)
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u2705 Custom join link saved.\n\n"
            f"Validation: {_verdict}\n{_verdict_note}\n\n"
            "The Force-Join dashboard and every user Join button\n"
            "now use this link.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001F517 Back to Change Join Link",
                                      callback_data=f"fjlink:{int(_fj_link_cid)}")],
                [InlineKeyboardButton("\u2B05\uFE0F Back to Channel",
                                      callback_data=f"fjedit:{int(_fj_link_cid)}")],
            ]))
        return
    # ---- Issue 25: Force-Join Add wizard (text input: ID or @username) ----
    # Must run BEFORE the admin gate / generic fallback so the wizard captures
    # the next message. Non-admins never have this state set.
    # BOT7 FIX (DB-admin): is_admin() instead of raw ADMIN_IDS membership.
    if context.user_data.get("awaiting_fj_add") and await is_admin(user.id):
        context.user_data.pop("awaiting_fj_add", None)
        cid, uname, title = await _fj_resolve_input(context.bot, text, None)
        if cid is None:
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Could not resolve that input.\n\n"
                "Send a Channel ID, @username, or forward a channel post.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:fj")],
                ]),
            )
            return
        ok = await db.add_force_channel(cid, uname, title=title or uname)
        if ok:
            ctype = "Public" if (uname or "").startswith("@") else "Private"
            display = title or uname or str(cid)
            await safe_send_text(
                context.bot, update.effective_chat.id,
                f"\u2705 Force Join Channel Added\n\n"
                f"Name: {display}\n"
                f"Type: {ctype}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:fj")],
                ]),
            )
        else:
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u26A0\uFE0F That channel is already in the force-join list.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:fj")],
                ]),
            )
        return

    # ---- Issue 25: Force-Join Edit wizard (rename) ----
    if context.user_data.get("awaiting_fj_edit") is not None and await is_admin(user.id):
        cid = context.user_data.pop("awaiting_fj_edit")
        new_name = text.strip() or None
        if new_name:
            await db.update_force_channel(cid, channel_name=new_name, title=new_name)
            await safe_send_text(
                context.bot, update.effective_chat.id,
                f"\u2705 Force-join channel renamed to: {new_name}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="fj:list")],
                ]),
            )
        else:
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Name cannot be empty. Cancelled.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="fj:list")],
                ]),
            )
        return

    # ---- admin editing states (only admins reach here for these) ----
    if not await is_admin(user.id):
        await reply_protected(update, 
            "\U0001F44B Welcome.\n\n"
            "Open a valid file link to receive your content.\n\n"
            "If you received a link from someone,\n"
            "tap it to continue."
        )
        return

    # broadcast composition (text-only broadcast)
    if context.user_data.get("awaiting_broadcast"):
        await send_broadcast_now(update, context)
        return

    # ---- Single File Link wizard ----
    # Resolves the Message ID to an indexed file, then transitions directly
    # into the Payload Configuration Wizard Step 1 (no extra "Launching" message).
    if context.user_data.get("awaiting_single_msgid"):
        context.user_data.pop("awaiting_single_msgid", None)
        raw = text.strip()
        channel_id: Optional[int] = None
        message_id: Optional[int] = None
        # V25 FINAL §12: accept the EXACT identity forms
        # "<channel_id>:<message_id>" / "<channel_id> <message_id>" /
        # bare "<message_id>" (legacy). The exact pair is the stable
        # source identity — no title/filename guessing ever substitutes.
        for sep in (":", " ", ","):
            if sep in raw:
                parts = [p for p in raw.replace(sep, " ").split() if p]
                if len(parts) == 2:
                    try:
                        channel_id = int(parts[0])
                        message_id = int(parts[1])
                    except ValueError:
                        channel_id = message_id = None
                break
        if message_id is None:
            try:
                message_id = int(raw)
            except ValueError:
                # BOT-43 (§C): the single-source resolution lifecycle
                # telemetry — every rejection is classified.
                logger.info(
                    "SINGLE_SOURCE_RESOLVE_REJECT channel_id=- message_id=- "
                    "reason=invalid_number media_type=- (the Single File "
                    "Link wizard needs a numeric message id or the exact "
                    "channel_id:message_id pair)")
                await reply_protected(update,
                    "\u274C Message ID must be a number (or the exact "
                    "`channel_id:message_id` pair). Cancelled.")
                return
        # BOT-43 (§C): the single-source resolution lifecycle telemetry
        # (channel_id=- when the admin sent the bare legacy message id;
        # raw file ids are NEVER logged — identities are hashed).
        logger.info("SINGLE_SOURCE_RESOLVE_START channel_id=%s message_id=%s",
                    (int(channel_id) if channel_id is not None else "-"),
                    int(message_id))
        file_row = None
        if channel_id is not None:
            file_row = await db.get_indexed_file_by_channel_message(
                int(channel_id), int(message_id))
            if not file_row:
                logger.info(
                    "SINGLE_SOURCE_RESOLVE_REJECT channel_id=%s "
                    "message_id=%s reason=exact_pair_not_found media_type=-",
                    int(channel_id), int(message_id))
                await reply_protected(update,
                    f"\u274C No indexed file found for the exact "
                    f"channel/message pair {md_code_span(f'{channel_id}:{message_id}')}.\n\n"
                    f"Reindex the storage channel first, or send just the "
                    f"message id to see every channel that has it.")
                return
        else:
            # V25 FINAL §12 (bot-35.log message 872): a bare message id that
            # exists in MULTIPLE channels is AMBIGUOUS — the admin picks the
            # exact channel from the candidate list; NEVER a silent heuristic
            # substitution (the wrong-bot/wrong-payload link root cause).
            candidates = await db.get_indexed_file_candidates_by_message(
                int(message_id))
            if not candidates:
                logger.info(
                    "SINGLE_SOURCE_RESOLVE_REJECT channel_id=- "
                    "message_id=%s reason=not_indexed media_type=-",
                    int(message_id))
                await reply_protected(update,
                    f"\u274C No indexed file found for Message ID {md_code_span(message_id)}.\n\n"
                    f"Reason: This file may not have been indexed yet.\n"
                    f"Try reindexing the storage channel first.",
                    parse_mode=ParseMode.MARKDOWN,
                )
                return
            if len(candidates) > 1:
                logger.info(
                    "SINGLE_SOURCE_RESOLVE_REJECT channel_id=- "
                    "message_id=%s reason=ambiguous media_type=- (the bare "
                    "message id exists in %s channels — the admin picks "
                    "the exact source)",
                    int(message_id), len(candidates))
                logger.warning(
                    "BOT6_LINK_SINGLE_AMBIGUOUS message_id=%s channels=%s "
                    "(the same message id exists in multiple channels — the "
                    "admin must pick the exact channel; no heuristic "
                    "substitution)", int(message_id),
                    [int(c["channel_id"]) for c in candidates])
                lines = ["\u26a0\ufe0f This Message ID exists in "
                         f"{len(candidates)} channels.\nPick the EXACT "
                         "source channel:"]
                kb_rows = []
                for i, c in enumerate(candidates[:8]):
                    title = str(c.get("channel_title") or "").strip()
                    label = (f"{title[:24]} \u00b7 {c['channel_id']}"
                             if title else str(c["channel_id"]))
                    kb_rows.append([InlineKeyboardButton(
                        f"{label} ({c['media_type']}, file #{c['id']})",
                        callback_data=f"pcwmsg:{int(c['channel_id'])}:"
                                      f"{int(message_id)}")])
                kb_rows.append([InlineKeyboardButton(
                    "\u274C Cancel", callback_data="panel:links")])
                await reply_protected(update,
                    "\n".join(lines),
                    reply_markup=InlineKeyboardMarkup(kb_rows))
                return
            file_row = await db.get_indexed_file_by_message_id(message_id)
        # BOT-43 (§C): success — the exact source identity resolved (the
        # file_unique_id is hashed for telemetry; raw ids never logged).
        _ssr_uid = str(file_row["file_unique_id"] or "")
        logger.info(
            "SINGLE_SOURCE_RESOLVE_RESULT channel_id=%s message_id=%s "
            "file_pk=%s media_type=%s file_unique_id_hash=%s "
            "outcome=resolved",
            int(file_row["channel_id"]), int(message_id),
            int(file_row["id"]), (str(file_row["media_type"] or "-")),
            (hashlib.sha256(
                _ssr_uid.encode("utf-8", "replace")).hexdigest()[:16]
                if _ssr_uid else "-"))
        # BOT-45/46 (Task D): LIVE Telegram source re-resolve at the exact
        # source-identity point. indexed_files.file_name is FROZEN at scan
        # time — the current Telegram source may have been edited (new
        # filename) or its media replaced (new file_unique_id) since. The
        # refresh updates the indexed row + payload display name (when the
        # origin allows) so the wizard below shows the CURRENT source
        # identity. A refresh failure NEVER breaks the wizard (telemetry
        # only — STORAGE_MESSAGE_SKIP classifies every unusable source).
        try:
            _lir = await _live_refresh_source_identity(
                context.bot, user.id, int(file_row["channel_id"]),
                int(file_row["message_id"]), file_row,
                db=db, log=logger,
                fetch_media=fetch_channel_media,
                probe_exists=_probe_message_exists)
            if _lir.get("file_pk"):
                _fresh_row = await db.get_indexed_file_by_id(
                    int(_lir["file_pk"]))
                if _fresh_row:
                    file_row = _fresh_row
            _lir_note = _live_refresh_notice(_lir)
            if _lir_note:
                await safe_send_text(
                    context.bot, update.effective_chat.id, _lir_note)
        except Exception as _lir_exc:  # noqa: BLE001 — never blocks the wizard
            logger.info(
                "STORAGE_MESSAGE_SKIP channel_id=%s message_id=%s "
                "reason_code=%s media_type=%s has_file_id=- "
                "has_file_unique_id=- file_pk=%s (live refresh raised: %s)",
                int(file_row["channel_id"]), int(file_row["message_id"]),
                "OTHER", (str(file_row["media_type"] or "-")),
                int(file_row["id"]), type(_lir_exc).__name__)
        # Transition directly into the wizard (edit the same message where
        # possible — pcw_show_name_step handles callback_query vs send).
        clear_wizard_states(context)
        state = _pcw_new_state(index_id=int(file_row["id"]))
        state["owner_id"] = user.id
        context.user_data[PCW_KEY] = state
        logger.info("BOT6_ADMIN_WIZARD_START wizard=pcw user_id=%s "
                    "mode=create_single_msgid channel_id=%s message_id=%s "
                    "file_pk=%s (exact channel+message identity)",
                    user.id, int(file_row["channel_id"]), int(message_id),
                    int(file_row["id"]))
        await pcw_log_wizard_event("wizard_started")
        await pcw_show_name_step(update, context)
        return

    # ---- Search Message ID wizard ----
    if context.user_data.get("awaiting_search_msgid"):
        context.user_data.pop("awaiting_search_msgid", None)
        try:
            message_id = int(text.strip())
        except ValueError:
            await reply_protected(update, 
                "Message ID must be a number. Cancelled."
            )
            return
        file_row = await db.get_indexed_file_by_message_id(message_id)
        if not file_row:
            await reply_protected(update, 
                f"\u274C No indexed file found for message_id {md_code_span(message_id)}.",
                parse_mode=ParseMode.MARKDOWN,
            )
            return
        # Show file detail with link + Copy/Preview/Delete/Back.
        direct_link = build_msg_link(message_id)
        text_out = (
            f"{media_emoji(file_row['media_type'])} *File Found*\n\n"
            f"*File Name:* {md_code_span(file_row['file_name'])}\n"
            f"*Message ID:* {md_code_span(message_id)}\n"
            f"*Type:* {file_row['media_type']}\n"
            f"*Size:* {format_size(file_row['file_size'])}\n\n"
            f"*\U0001F517 Direct Link:*\n{md_code_span(direct_link)}"
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("\U0001F4CB Copy Link", callback_data=f"mlinkcopy:{message_id}"),
             InlineKeyboardButton("\U0001F441 Preview", callback_data=f"filepreview:{file_row['id']}")],
            [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:links")],
        ])
        await reply_protected(update, 
            text_out, parse_mode=ParseMode.MARKDOWN, reply_markup=kb
        )
        return

    # ---- Recent Files: search by name ----
    if context.user_data.get("awaiting_file_search"):
        context.user_data.pop("awaiting_file_search", None)
        rows = await db.search_files_by_name(text.strip(), limit=10)
        if not rows:
            await reply_protected(update, 
                "No files found matching that name.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:recent")]]
                ),
            )
            return
        buttons: List[List[InlineKeyboardButton]] = []
        for r in rows:
            name = (r["file_name"] or f"file_{r['id']}")[:32]
            buttons.append([InlineKeyboardButton(
                f"{media_emoji(r['media_type'])} m{r['message_id']} {name}",
                callback_data=f"file:{r['id']}",
            )])
        buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:recent")])
        await reply_protected(update, 
            f"*Search results for {md_code_span(text.strip())}*",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
        return

    # ---- Collection Link wizard: start ID (Issue 2: creates explicit collection) ----
    if context.user_data.get("awaiting_range_start"):
        try:
            start_id = int(text.strip())
        except ValueError:
            await reply_protected(update, "Start Message ID must be a number. Cancelled.")
            context.user_data.pop("awaiting_range_start", None)
            return
        context.user_data["awaiting_range_end"] = start_id
        context.user_data.pop("awaiting_range_start", None)
        await reply_protected(update, 
            f"*Start ID:* {md_code_span(start_id)}\n\nNow send the *End Message ID* "
            f"(e.g. `8625`).",
            parse_mode=ParseMode.MARKDOWN,
        )
        return
    # ---- Collection Link wizard: end ID ----
    # Resolves the range, shows a "Collection Found" summary, then enters the
    # Payload Configuration Wizard (no immediate collection/link creation).
    if context.user_data.get("awaiting_range_end") is not None:
        start_id = context.user_data.pop("awaiting_range_end")
        try:
            end_id = int(text.strip())
        except ValueError:
            await reply_protected(update, "\u274C End Message ID must be a number. Cancelled.")
            return
        if start_id > end_id:
            await reply_protected(update,
                "\u274C Start ID must be less than or equal to End ID. Cancelled."
            )
            return
        # Show loading feedback (range resolution may take a moment for large ranges).
        status_msg = await safe_send_text(context.bot, update.effective_chat.id,
            f"\U0001F50D Validating collection (range {start_id}\u2013{end_id})...")
        # Resolve the files in the range WITHOUT creating a collection yet.
        channel_id = await db.resolve_channel_for_range(start_id, end_id)
        if channel_id is None:
            if status_msg:
                await safe_edit_text(status_msg,
                    f"\u274C Unable to locate the collection.\n\n"
                    f"Reason: No indexed files found in range {start_id}\u2013{end_id}.\n"
                    f"Try reindexing the storage channel first.")
            return
        files = await db.files_in_message_range(start_id, end_id, channel_id=channel_id)
        if not files:
            if status_msg:
                await safe_edit_text(status_msg,
                    f"\u274C No indexed files found in range {start_id}\u2013{end_id}.")
            return
        msg_ids = [int(f["message_id"]) for f in files]
        # Update the status message with the collection summary (no IDs exposed).
        if status_msg:
            await safe_edit_text(status_msg,
                f"\U0001F4E6 Collection Found\n\n"
                f"Files: {len(msg_ids)}\n"
                f"Ready for delivery.\n"
                f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
                f"Tap Continue to configure this payload.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2705 Continue", callback_data=f"colsum:continue:{channel_id}"),
                     InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="link:range"),
                     InlineKeyboardButton("\u274C Cancel", callback_data="colsum:cancel")],
                ]))
        # Stash the resolved message_ids for the continue callback.
        context.user_data["colsum_msg_ids"] = msg_ids
        context.user_data["colsum_channel_id"] = channel_id
        return

    # start text editing
    if context.user_data.get("awaiting_start_text"):
        variant = context.user_data.get("sm_variant", "first")
        # BOTV13 Phase B (wired): serialize the Telegram entities from the
        # incoming message so bold/italic/text_link/code/etc. survive the
        # EDIT → SAVE → PREVIEW → SEND cycle. Use update.message.entities
        # (text messages carry entities on .entities).
        ent_json = serialize_entities(update.message.entities) if update.message else None
        await db.set_start_message(variant, message_type="text", file_id=None,
                                   caption=text, entities=ent_json)
        context.user_data.pop("awaiting_start_text", None)
        await reply_protected(update,
            f"\u2705 Start message text saved for *{variant}*.",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    # start buttons editing
    if context.user_data.get("awaiting_start_buttons"):
        variant = context.user_data.get("sm_variant", "first")
        rows = parse_start_buttons(text)
        await db.set_start_message(variant, buttons_json=json.dumps(rows))
        context.user_data.pop("awaiting_start_buttons", None)
        await reply_protected(update, 
            f"\u2705 Start message buttons saved ({len(rows)} row(s)) for *{variant}*.",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    # Issue #63: FJ text editors — join text, verify button, channel button.
    # BOT7 FIX (DB-admin): is_admin() instead of raw ADMIN_IDS membership.
    if context.user_data.get("awaiting_fj_editjoin") is not None and await is_admin(user.id):
        cid = context.user_data.pop("awaiting_fj_editjoin")
        # BOTV13 Phase B (wired): serialize Telegram entities from the incoming
        # message so bold/italic/text_link/code/etc. in the FJ join text survive
        # SAVE → PREVIEW → SEND. Stored in join_text_entities (v22 column).
        ent_json = serialize_entities(update.message.entities) if update.message else None
        await db.update_force_join_text(cid, join_text=text.strip() or None,
                                        join_text_entities=ent_json)
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u2705 Join text updated.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"fjedit:{cid}")],
            ]))
        return
    if context.user_data.get("awaiting_fj_editverify") is not None and await is_admin(user.id):
        cid = context.user_data.pop("awaiting_fj_editverify")
        await db.update_force_join_text(cid, verify_text=text.strip() or None)
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u2705 Verify button text updated.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"fjedit:{cid}")],
            ]))
        return
    if context.user_data.get("awaiting_fj_editchanbtn") is not None and await is_admin(user.id):
        cid = context.user_data.pop("awaiting_fj_editchanbtn")
        await db.update_force_join_text(cid, channel_text=text.strip() or None)
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u2705 Channel button text updated.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"fjedit:{cid}")],
            ]))
        return

    # ---- Issue #84: Retrieve message text editor ----
    if context.user_data.get("awaiting_retrieve_text") and await is_admin(user.id):
        context.user_data.pop("awaiting_retrieve_text", None)
        if text.strip().lower() == "/skip":
            await db.set_setting("retrieve_message_text", DEFAULT_RETRIEVE_TEXT)
        else:
            await db.set_setting("retrieve_message_text", text.strip())
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u2705 Retrieve text updated.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:retrieve")],
            ]))
        return

    # ---- Issue #84: Retrieve button label editor ----
    if context.user_data.get("awaiting_retrieve_button") and await is_admin(user.id):
        context.user_data.pop("awaiting_retrieve_button", None)
        await db.set_setting("retrieve_message_button", text.strip() or DEFAULT_RETRIEVE_BUTTON)
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u2705 Retrieve button updated.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:retrieve")],
            ]))
        return

    # ---- Issue #50: Retrieve limit / window editors ----
    if context.user_data.get("awaiting_retrieve_limit") and await is_admin(user.id):
        context.user_data.pop("awaiting_retrieve_limit", None)
        try:
            val = max(0, int(text.strip()))
        except ValueError:
            await reply_protected(update, "\u274C Must be a number (0 = unlimited). Cancelled.")
            return
        await db.set_setting("retrieve_limit", str(val))
        await safe_send_text(context.bot, update.effective_chat.id,
            f"\u2705 Retrieve limit set to {val} (0 = unlimited).",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:retrieve")],
            ]))
        return
    if context.user_data.get("awaiting_retrieve_window") and await is_admin(user.id):
        context.user_data.pop("awaiting_retrieve_window", None)
        try:
            val = max(0, int(text.strip()))
        except ValueError:
            await reply_protected(update, "\u274C Must be a number (hours, 0 = none). Cancelled.")
            return
        await db.set_setting("retrieve_window_hours", str(val))
        await safe_send_text(context.bot, update.effective_chat.id,
            f"\u2705 Retrieve window set to {val} hours (0 = none).",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:retrieve")],
            ]))
        return

    # ---- Issue #94: Referral Gate required referrals editor (legacy path) ----
    if context.user_data.get("awaiting_refgate_req") and await is_admin(user.id):
        pid = context.user_data.pop("awaiting_refgate_req")
        try:
            val = max(0, int(text.strip()))
        except ValueError:
            await reply_protected(update, "\u274C Must be a number (0 = instant unlock). Cancelled.")
            return
        campaign = await db.get_referral_campaign_by_payload(pid)
        if campaign:
            await db.update_referral_campaign(campaign["id"], required_referrals=val)
        await safe_send_text(context.bot, update.effective_chat.id,
            f"\u2705 Required referrals set to {val}.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"plgate:{pid}")],
            ]))
        return

    # ---- Access Engine V1: custom required referrals editor ----
    if context.user_data.get("awaiting_refgate_reqcustom") and await is_admin(user.id):
        pid = context.user_data.pop("awaiting_refgate_reqcustom")
        try:
            val = max(0, int(text.strip()))
        except ValueError:
            await reply_protected(update, "\u274C Must be a number (0 = instant unlock). Cancelled.")
            return
        campaign = await db.get_referral_campaign_by_payload(pid)
        if campaign:
            await db.update_referral_campaign(campaign["id"], required_referrals=val)
        else:
            prow = await db.get_payload_by_id(pid)
            if prow:
                await db.create_referral_campaign(pid, prow["payload"], required_referrals=val)
        await safe_send_text(context.bot, update.effective_chat.id,
            f"\u2705 Required referrals set to {val}.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"plgsetreq:{pid}")],
            ]))
        return

    # ---- Access Engine V1: preview description editor ----
    if context.user_data.get("awaiting_refgate_prevdesc") and await is_admin(user.id):
        pid = context.user_data.pop("awaiting_refgate_prevdesc")
        desc = truncate(text, limit=1024)
        campaign = await db.get_referral_campaign_by_payload(pid)
        if campaign:
            await db.update_referral_campaign(campaign["id"], preview_description=desc)
            await safe_send_text(context.bot, update.effective_chat.id,
                "\u2705 Preview description saved.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"plgpreview:{pid}")],
                ]))
        else:
            await reply_protected(update, "\u274C No campaign for this payload. Set policy to REFERRAL first.")
        return

    # ---- V11: Dashboard Editor — single template text input (auto-save) ----
    # The admin sends the complete dashboard template. It saves immediately to
    # the `dashboard_template` setting, refreshes the single live preview
    # message in-place, and returns to the Dashboard Editor. No Save button,
    # no confirmation page.
    if context.user_data.get("dash_edit_template") and await is_admin(user.id):
        context.user_data.pop("dash_edit_template", None)
        template = truncate(text, limit=4096)
        await _dash_save_setting("dashboard_template", template)
        # Refresh the single live preview message (edits in-place, no spam).
        try:
            settings = await _dash_load_settings(context)
            settings["dashboard_template"] = template
            await _dash_refresh_preview(context.bot, update.effective_chat.id,
                                        context, settings)
        except Exception as e:  # noqa: BLE001
            logger.debug("Dash preview refresh failed: %s", e)
        # Confirm + return to the Dashboard Editor.
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u2705 Dashboard template saved.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back to Editor", callback_data="panel:dashedit")],
            ]))
        return

    # Issue #48: Reindex From File — admin forwarded a file from the channel.
    if context.user_data.get("awaiting_reidx_fromfile"):
        cid = context.user_data.pop("awaiting_reidx_fromfile")
        msg = update.effective_message
        if not msg:
            return
        # Extract channel_id + message_id from the forwarded message.
        ch_id, msg_id = extract_forward_origin(msg)
        if ch_id and msg_id:
            # Issue #85: validate the forwarded file actually belongs to the
            # selected storage channel. If ch_id != cid, the admin forwarded
            # from the wrong channel — abort with a clear error.
            if ch_id != cid:
                await reply_protected(update,
                    f"\u274C Channel mismatch.\n\n"
                    f"The forwarded file is from a different channel than the "
                    f"selected storage channel.\n"
                    f"Forward the latest file directly from the correct channel.")
                return
            # Issue #85: repair the cursor automatically. Set last_scanned to
            # msg_id - 1 so the normal (forward) scan picks up from msg_id.
            # This is a FULL recovery: reset cursor to 0, then set it to
            # msg_id-1 so _run_reindex_inner does a forward scan 1..msg_id-1
            # is NOT what we want — we want to scan everything up to msg_id.
            # The correct approach: reset cursor to NULL (forces first-scan
            # backward mode), but cap the scan at msg_id (the forwarded file
            # is the known latest). We achieve this by setting the cursor to
            # msg_id and letting a forward incremental scan run from there —
            # but that only scans NEW messages. Instead, do a full reindex
            # (reset cursor) which scans backwards from the REAL latest. The
            # forwarded file just confirms the channel mapping is correct.
            ch_title = str(cid)
            try:
                chat_info = await context.bot.get_chat(cid)
                if chat_info and chat_info.title:
                    ch_title = chat_info.title
            except TelegramError:
                pass
            status_msg = await safe_send_text(context.bot, update.effective_chat.id,
                f"\U0001F504 Reindex From File: {ch_title}\n"
                f"Validated: message {msg_id} belongs to this channel.\n"
                f"Resetting cursor and rescanning entire channel...")
            # Issue #85: run_full_reindex resets the cursor to NULL, which
            # triggers a backward first-scan from the real latest message.
            # The forwarded file's message_id is used ONLY for validation
            # (confirming channel mapping) — the actual scan uses
            # determine_latest_message_id() (now fixed with forward fallback).
            asyncio.create_task(
                run_full_reindex(context.bot, user.id, cid, status_msg, ch_title)
            )
        else:
            await reply_protected(update,
                "\u274C Cannot identify the source file.\n"
                "Forward a file directly from the storage channel.")
        return

    # BOT6 P16: Manage Files → Add File. Admin forwards a file to add to an
    # existing collection. Validates: indexed, same channel, not already in the
    # collection. Appends to collection_items + updates file_count.
    if context.user_data.get("awaiting_mf_add"):
        # V25 FINAL §15: the shared consumer (text route and media route
        # are behaviorally identical — see _mf_consume_forwarded_add).
        await _mf_consume_forwarded_add(update, context)
        return

    # storage channel add (awaiting channel id)
    if context.user_data.get("awaiting_storage_add"):
        context.user_data.pop("awaiting_storage_add", None)
        import uuid as _uuid
        _trace_id = _uuid.uuid4().hex[:12]
        _admin_id = update.effective_user.id if update.effective_user else 0
        try:
            channel_id = int(text)
        except ValueError:
            await reply_protected(update, "CHANNEL_ID must be a number. Cancelled.")
            logger.info("BOT6_STORAGE_ADD trace_id=%s admin_id=%s result=invalid_id input=%s",
                        _trace_id, _admin_id, text[:40])
            return
        try:
            chat = await context.bot.get_chat(channel_id)
            title = chat.title
        except TelegramError:
            title = None
        ok = await db.add_storage_channel(channel_id, title, None)
        logger.info("BOT6_STORAGE_ADD trace_id=%s admin_id=%s channel_id=%s result=%s",
                    _trace_id, _admin_id, channel_id, "added" if ok else "already_exists")
        await reply_protected(update,
            f"\u2705 Storage channel {channel_id} added.\n\n"
            f"\U0001F4E1 Title: {title or '(unknown)'}\n"
            f"\U0001F194 ID: {channel_id}\n"
            f"\U0001F916 Bot access: \u2705\n"
            f"\U0001F4DA Indexing: Ready" if ok
            else "That channel is already registered."
        )
        return

    # create payload (awaiting "INDEX_ID PAYLOAD")
    if context.user_data.get("awaiting_create_payload"):
        context.user_data.pop("awaiting_create_payload", None)
        parts = text.split()
        if len(parts) < 2:
            await reply_protected(update, "Usage: INDEX_ID PAYLOAD")
            return
        try:
            index_id = int(parts[0])
        except ValueError:
            await reply_protected(update, "INDEX_ID must be a number.")
            return
        payload = parts[1].lower()
        if not validate_payload(payload):
            await reply_protected(update, "Invalid payload format.")
            return
        file_row = await db.get_indexed_file_by_id(index_id)
        if not file_row:
            await reply_protected(update, f"File #{index_id} not found.")
            return
        if await db.get_payload(payload):
            await reply_protected(update, f"Payload {md_code_span(payload)} already exists.",
                                                      parse_mode=ParseMode.MARKDOWN)
            return
        one_time = await one_time_default()
        # BOT-45/46 (Task D): the admin typed this payload name explicitly —
        # display_name defaults to that admin slug, so the provenance is
        # 'admin_override' (a later source refresh never overwrites it).
        await db.create_payload(payload, index_id, status="active",
                                one_time=one_time,
                                display_name_origin="admin_override")
        await send_payload_created_message(update, payload)
        return

    # find payload
    if context.user_data.get("awaiting_find_payload"):
        context.user_data.pop("awaiting_find_payload", None)
        await _payload_manager_search(update, context, text)
        return

    # BOTV13 Phase 2: add admin by user ID
    if context.user_data.get("awaiting_admin_add"):
        context.user_data.pop("awaiting_admin_add", None)
        if not await has_permission(user.id, PERM_MANAGE_ADMINS):
            await reply_protected(update, "\u274C You don't have permission to add admins.")
            return
        try:
            target_id = int(text.strip())
        except ValueError:
            await reply_protected(update, "\u274C Invalid user ID. Send a numeric Telegram user ID.")
            return
        if target_id == user.id:
            await reply_protected(update, "\u274C You cannot add yourself.")
            return
        if target_id == _get_owner_id():
            await reply_protected(update, "\u274C That user is already the owner.")
            return
        # Check if already an admin.
        cur = await db.conn.execute("SELECT 1 FROM admins WHERE user_id = ? OR user_id = ?",
                                    (target_id, str(target_id)))
        if await cur.fetchone():
            await reply_protected(update, "\u274C That user is already an admin.")
            return
        # Look up the user's info from the users table (they must have started the bot).
        cur = await db.conn.execute("SELECT username, first_name FROM users WHERE user_id = ?", (target_id,))
        u = await cur.fetchone()
        username = u["username"] if u and u["username"] else None
        first_name = u["first_name"] if u and u["first_name"] else None
        now_iso = _now_iso()
        # BOT7: new admins start with an EMPTY permission set ({}). They are
        # recognized as ACTIVE admins (is_active=1) everywhere in the bot, but
        # every admin action still requires its specific permission, so a
        # freshly added admin can do nothing dangerous until the owner grants
        # access. The follow-up screen below makes the choice explicit.
        await db.conn.execute(
            """INSERT INTO admins (user_id, username, first_name, permissions, is_owner, is_active, added_by, created_at, updated_at)
               VALUES (?, ?, ?, '{}', 0, 1, ?, ?, ?)""",
            (target_id, username, first_name, user.id, now_iso, now_iso),
        )
        await db.conn.commit()
        await log_admin_action(user.id, "add_admin", "admin", target_id,
                              f"username={username}")
        logger.info("BOT6_ADMIN_ADD actor=%s target=%s username=%s "
                    "is_active=1 permissions=none", user.id, target_id, username)
        # BOT7 UX (spec §9): explicit post-add screen so the owner chooses
        # what the new admin can access — configure / recommended / full /
        # disable — instead of a bare "configure from dashboard" note.
        await admin_added_screen(update, context, target_id)
        return

    # rename payload
    if context.user_data.get("awaiting_payload_rename"):
        pid = context.user_data.pop("awaiting_payload_rename")
        # BOTV13: Rename now edits ONLY the display_name. The routing slug
        # (payload column) is NEVER modified — so /start links, referral tokens,
        # collection c<code> routing, and retrieve records all keep working.
        # Collection payloads CAN be renamed (the c<code> slug stays untouched).
        existing_row = await db.get_payload_by_id(pid)
        if not existing_row:
            await reply_protected(update, "\u274C Payload no longer exists.")
            return
        # Sanitize the new display name (allows spaces, mixed case).
        new_display = sanitize_display_name(text)
        if not validate_display_name(new_display):
            await reply_protected(update,
                "\u274C Could not generate a valid name.\n"
                "Use letters, digits, spaces, or hyphens (max 128).")
            return
        # Update ONLY the display_name column. The routing slug is immutable.
        old_name = existing_row["display_name"] if "display_name" in existing_row.keys() else None
        await db.update_payload_field(pid, "display_name", new_display)
        # BOT-45/46 (Task D): an admin rename is an EXPLICIT override — mark
        # the provenance so any later source-filename refresh preserves it.
        try:
            await db.update_payload_field(
                pid, "display_name_origin", "admin_override")
        except Exception:  # noqa: BLE001 — origin marking is best-effort
            logger.debug("rename: display_name_origin marking failed",
                         exc_info=True)
        await log_admin_action(user.id, "rename_payload", "payload", pid,
                              f"old={old_name} new={new_display}")
        await reply_protected(update, f"\u2705 Renamed to: {new_display}")
        # Refresh the Payload Details page so the admin sees the new name.
        nav_set(context, "payload_details", payload_id=pid)
        try:
            row = await db.get_payload_by_id(pid)
            if row:
                from telegram import InlineKeyboardMarkup as _IKM
                # BOTV13 Part 1: use the human-friendly link (new display name).
                share_url = f"https://t.me/share/url?url={build_link(row['payload'], display_name=new_display)}"
                kb = _IKM([
                    [InlineKeyboardButton("\U0001F4CB Copy Link", callback_data=f"copy_id:{row['id']}"),
                     InlineKeyboardButton("\U0001F4E4 Share", url=share_url)],
                    [InlineKeyboardButton("\u2B05\uFE0F Back to Payload", callback_data=f"pldetail:{pid}")],
                ])
                await safe_send_text(context.bot, update.effective_chat.id,
                    f"\u2705 Renamed to: {new_display}", reply_markup=kb)
        except Exception:  # noqa: BLE001
            logger.debug("Rename: detail refresh failed.", exc_info=True)
        return

    # ---- Delivery message builder: edit text states ----
    if context.user_data.get("awaiting_dm_single"):
        context.user_data.pop("awaiting_dm_single", None)
        await db.set_setting("delivery_message_text", text)
        await reply_protected(update, 
            "\u2705 Delivery message text saved.",
        )
        return
    if context.user_data.get("awaiting_dm_coll"):
        context.user_data.pop("awaiting_dm_coll", None)
        await db.set_setting("collection_delivery_message_text", text)
        await reply_protected(update, 
            "\u2705 Collection delivery message text saved.",
        )
        return
    if context.user_data.get("awaiting_dm_buttons"):
        context.user_data.pop("awaiting_dm_buttons", None)
        rows = parse_start_buttons(text)
        await db.set_setting("delivery_message_buttons", json.dumps(rows))
        await reply_protected(update,
            f"\u2705 Delivery message buttons saved ({len(rows)} row(s)).",
        )
        return
    # BOTV13 Phase 3 fix: configurable FJ batch size (numeric input 1-50).
    if context.user_data.get("awaiting_fj_batch_size"):
        context.user_data.pop("awaiting_fj_batch_size", None)
        try:
            val = int(text.strip())
        except ValueError:
            await reply_protected(update, "\u274C Invalid input. Send a number between 1 and 50.")
            return
        if val < 1 or val > 50:
            await reply_protected(update, "\u274C Batch size must be between 1 and 50.")
            return
        await db.set_setting("fj_batch_size", str(val))
        await reply_protected(update, f"\u2705 Batch size set to {val}.")
        return
    # BOTV13 Phase 4: custom delete timer (numeric input 1-86400, 0=never).
    if context.user_data.get("awaiting_custom_timer"):
        pid = context.user_data.pop("awaiting_custom_timer")
        try:
            val = int(text.strip())
        except ValueError:
            await reply_protected(update, "\u274C Invalid input. Send a number (1\u201386400 or 0 for never).")
            return
        if val < 0:
            await reply_protected(update, "\u274C Negative values are not allowed.")
            return
        if val > 86400:
            await reply_protected(update, "\u274C Maximum is 86400 seconds (24 hours).")
            return
        await db.update_payload_field(pid, "delete_after", val)
        label = "never" if val == 0 else f"{val}s"
        await log_admin_action(user.id, "set_custom_timer", "payload", pid, f"timer={val}")
        await reply_protected(update, f"\u2705 Custom delete timer set to {label}.")
        return

    # V8: The fallback message is admin-only. Non-admins (especially users who
    # just opened a referral/payload link and then typed something) must never
    # see "Use the admin panel (/start)" — they don't have one. For non-admins
    # we stay silent to avoid confusion after a referral dashboard is shown.
    # BOT7 FIX (DB-admin): is_admin() instead of raw ADMIN_IDS membership.
    if await is_admin(user.id):
        await reply_protected(update,
            "Use the admin panel (/start) to manage the bot. "
            "All actions are available through inline buttons."
        )
    # Non-admin: no response — avoids confusing follow-ups after referral/payload links.
    return



async def _mf_consume_forwarded_add(update: Update,
                                    context: ContextTypes.DEFAULT_TYPE) -> None:
    """V25 FINAL §15 (Manage Files — Add, SHARED consumer): consume a
    forwarded message while the ``awaiting_mf_add`` state is armed —
    from EITHER route: ``text_handler`` (forwarded text posts) OR
    ``on_media_input`` (forwarded photo/video/document/audio/voice/
    animation — PTB delivers those to the MEDIA handler, which
    previously had no awaiting_mf_add branch and silently dropped the
    add, the §11 silent-no-op defect). The exact source identity
    (channel_id + message_id) is captured from the forward origin;
    honest rejections: no-origin / channel-mismatch / not-indexed /
    duplicate."""
    context.user_data.pop("awaiting_mf_add", None)
    coll_code = context.user_data.get("_mf_coll_code", "")
    if not coll_code:
        await reply_protected(update, "\u274C No collection selected. Cancelled.")
        return
    coll = await db.get_collection(coll_code)
    if not coll:
        await reply_protected(update, "\u274C Collection not found.")
        return
    channel_id = int(coll["channel_id"])
    # Resolve the forwarded file's source message_id (works for text AND
    # media forwards — the forward origin metadata is identical).
    fwd_origin = extract_forward_origin(update.message)
    src_channel = fwd_origin[0]
    src_msg_id = fwd_origin[1]
    if src_channel is None or src_msg_id is None:
        await reply_protected(update,
            "\u274C Cannot identify the source file.\n"
            "Forward a file directly from the storage channel.")
        return
    # Validate: file must be from the same channel as the collection.
    if int(src_channel) != channel_id:
        await reply_protected(update,
            f"\u274C Channel mismatch.\n\n"
            f"Collection channel: {channel_id}\n"
            f"Forwarded file channel: {src_channel}\n\n"
            f"All files in a collection must come from the same channel.")
        return
    # Validate: file must be indexed.
    row = await db.get_indexed_file_by_channel_msg(channel_id, src_msg_id)
    if not row:
        await reply_protected(update,
            "\u274C File not indexed.\n\n"
            "This file is in a storage channel but hasn't been indexed yet.")
        return
    # Validate: not already in the collection.
    cur = await db.conn.execute(
        "SELECT 1 FROM collection_items WHERE collection_id = ? AND message_id = ?",
        (coll_code, src_msg_id))
    existing = await cur.fetchone()
    if existing:
        await reply_protected(update,
            "\u26A0\uFE0F This file is already in the collection.")
        return
    # Append to collection_items (position = current count).
    cur2 = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM collection_items WHERE collection_id = ?",
        (coll_code,))
    r = await cur2.fetchone()
    position = int(r["c"]) if r else 0
    await db.conn.execute(
        "INSERT INTO collection_items (collection_id, channel_id, message_id, position) "
        "VALUES (?, ?, ?, ?)",
        (coll_code, channel_id, src_msg_id, position))
    new_count = position + 1
    await db.conn.execute(
        "UPDATE collections SET file_count = ? WHERE collection_id = ?",
        (new_count, coll_code))
    await db.conn.commit()
    logger.info("BOT6_PAYLOAD_FILES_ADD collection_id=%s message_id=%s new_count=%s",
                coll_code, src_msg_id, new_count)
    await reply_protected(update,
        f"\u2705 File added to collection.\n\n"
        f"Collection: {coll_code}\n"
        f"File: {src_msg_id}\n"
        f"Total files: {new_count}")


async def on_media_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle admin uploading/forwarding media: set start message media, send a
    broadcast, or generate links from a forwarded storage-channel file.

    Also handles multi-file forward detection (media groups / albums)."""
    user = update.effective_user
    if not user or not await is_admin(user.id):
        return
    # BOTV13 Phase 3 (Group Safety): ignore media in group/supergroup chats.
    chat_type = update.effective_chat.type if update.effective_chat else None
    if chat_type in ("group", "supergroup"):
        return
    msg = update.message

    # ---- Access Engine V1: Payload Creation Wizard media inputs ----
    # MUST run before the forward-batch logic so the wizard captures forwarded
    # files instead of treating them as link-generation forwards.
    pcw_state = _pcw_get(context)
    if pcw_state:
        step = pcw_state.get("step")
        if step == "prevmedia":
            # Admin is uploading preview media for the wizard.
            # Accept ONLY photo / video / animation. Reject documents, audio,
            # voice, stickers — they are not suitable as preview media.
            info = extract_media(msg)
            if not info:
                await safe_send_text(context.bot, update.effective_chat.id,
                    "\u274C No media detected. Send a photo, video, or animation.\n\n"
                    "Documents, audio, voice, and stickers are not accepted as preview media.")
                return
            mtype = info.get("media_type", "")
            if mtype not in ("photo", "video", "animation"):
                await safe_send_text(context.bot, update.effective_chat.id,
                    f"\u274C '{mtype}' is not accepted as preview media.\n\n"
                    f"Only photo, video, or animation are allowed.\n"
                    f"Please send a supported media type, or tap Back to return.")
                return
            # Media accepted — store it temporarily and show confirmation
            # with Use / Replace / Remove / Skip / Back buttons.
            pcw_state["preview_media_file_id"] = info["file_id"]
            pcw_state["preview_media_type"] = info["media_type"]
            await safe_send_text(context.bot, update.effective_chat.id,
                f"\U0001F3AC Preview Media Received\n\n"
                f"Type: {info['media_type']}\n\n"
                f"Choose an action:",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2705 Use", callback_data="pcw:prevmediause"),
                     InlineKeyboardButton("\U0001F504 Replace", callback_data="pcw:prevmedia")],
                    [InlineKeyboardButton("\u274C Remove", callback_data="pcw:prevmediaremove"),
                     InlineKeyboardButton("\u23ED\uFE0F Skip", callback_data="pcw:prevmediaskip")],
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="pcw:back")],
                ]))
            return
        if step == "file":
            # Admin forwarded a file to select it for the wizard.
            ch_id, msg_id, frow = await _resolve_forwarded_file_row(msg)
            if frow:
                pcw_state["index_id"] = int(frow["id"])
                await safe_send_text(context.bot, update.effective_chat.id,
                    f"\u2705 File selected: {truncate(frow['file_name'], 60) or '(unnamed)'}")
                await pcw_show_policy_step(update, context)
                return
            # Fall through with a clear error if the file couldn't be resolved.
            await safe_send_text(context.bot, update.effective_chat.id,
                "\u274C Could not identify that file. Forward it directly from "
                "a storage channel, or send its Message ID as text.")
            return
        # Other wizard steps have no media input — fall through to the normal
        # media handlers below so the wizard doesn't block unrelated uploads.

    # ---- WEBSITE PHASE 3: Website wizard thumbnail capture + per-listing
    # thumbnail replacement (app/presentation/telegram/website_ui.py). Runs before the
    # forward-batch logic for the same reason as the PCW block above.
    if context.user_data.get("wsite_wizard") or context.user_data.get("wsite_edit"):
        _wsite_info = extract_media(msg)
        if _wsite_info:
            _wsite_consumed = await _handle_wsite_media(update, context, _wsite_info)
            if _wsite_consumed:
                return

    # ---- V25 FINAL §15: Manage Files — Add (MEDIA route). PTB delivers
    # ---- forwarded photo/video/document/audio/voice/animation messages
    # ---- HERE (not to text_handler); without this branch the armed add
    # ---- state was a SILENT NO-OP (the §11 defect). The shared consumer
    # ---- captures the exact source identity (channel_id + message_id).
    if context.user_data.get("awaiting_mf_add"):
        await _mf_consume_forwarded_add(update, context)
        return

    # ---- Issue #63: Force Join media attachment ----
    if context.user_data.get("awaiting_fj_media") is not None:
        cid = context.user_data.pop("awaiting_fj_media")
        info = extract_media(msg)
        if info:
            await db.update_force_join_media(cid, info["file_id"], info["media_type"])
            await safe_send_text(context.bot, update.effective_chat.id,
                f"\u2705 Force Join media set ({info['media_type']}).",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"fjedit:{cid}")],
                ]))
        else:
            await safe_send_text(context.bot, update.effective_chat.id,
                "\u274C No media detected. Send a photo, video, animation, or document.")
        return

    # ---- V14: Dashboard Media banner upload ----
    if context.user_data.get("dash_media_upload"):
        context.user_data.pop("dash_media_upload", None)
        info = extract_media(msg)
        if not info:
            await safe_send_text(context.bot, update.effective_chat.id,
                "\u274C No media detected. Send a photo, video, or animation.")
            return
        mtype = info.get("media_type", "")
        if mtype not in ("photo", "video", "animation"):
            await safe_send_text(context.bot, update.effective_chat.id,
                f"\u274C '{mtype}' is not accepted as a banner.\n"
                f"Only photo, video, or animation are allowed.")
            return
        await _dash_save_setting("dashboard_media_file_id", info["file_id"])
        await _dash_save_setting("dashboard_media_type", info["media_type"])
        await safe_send_text(context.bot, update.effective_chat.id,
            f"\u2705 Dashboard banner saved ({info['media_type']}).",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back to Dashboard Editor", callback_data="dash:media")],
            ]))
        return

    # ---- Access Engine V1: referral preview media upload ----
    # Admin supplies a SEPARATE preview file (thumbnail/custom). The protected
    # payload file is NEVER used as preview. If no campaign exists yet, create
    # one so the media can be attached.
    if context.user_data.get("awaiting_refgate_prevmedia") is not None:
        pid = context.user_data.pop("awaiting_refgate_prevmedia")
        info = extract_media(msg)
        if not info:
            await safe_send_text(context.bot, update.effective_chat.id,
                "\u274C No media detected. Send a photo, video, animation, or document.")
            return
        campaign = await db.get_referral_campaign_by_payload(pid)
        if not campaign:
            prow = await db.get_payload_by_id(pid)
            if prow:
                campaign_id = await db.create_referral_campaign(pid, prow["payload"])
            else:
                await safe_send_text(context.bot, update.effective_chat.id,
                    "\u274C Payload not found.")
                return
        else:
            campaign_id = campaign["id"]
        await db.update_referral_campaign(campaign_id,
            preview_media_file_id=info["file_id"],
            preview_media_type=info["media_type"])
        await safe_send_text(context.bot, update.effective_chat.id,
            f"\u2705 Preview media saved ({info['media_type']}).",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"plgpreview:{pid}")],
            ]))
        return

    # (Issue #84: branding media wizards removed — branding UI is gone. The
    #  retrieve system is reply-based and uses only text + button, no media.)

    # ---- Issue 25: Force-Join Add wizard (Method 3: forwarded channel post) ----
    # Must run BEFORE the broadcast/forward-batch logic so the wizard captures
    # the forwarded message instead of treating it as a link-generation forward.
    if context.user_data.get("awaiting_fj_add"):
        context.user_data.pop("awaiting_fj_add", None)
        cid, uname, title = await _fj_resolve_input(context.bot, "", msg)
        if cid is None:
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Could not identify the channel from that forwarded message.\n\n"
                "Forward a post directly from the channel, or send a Channel ID / @username.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:fj")],
                ]),
            )
            return
        ok = await db.add_force_channel(cid, uname, title=title or uname)
        if ok:
            ctype = "Public" if (uname or "").startswith("@") else "Private"
            display = title or uname or str(cid)
            await safe_send_text(
                context.bot, update.effective_chat.id,
                f"\u2705 Force Join Channel Added\n\n"
                f"Name: {display}\n"
                f"Type: {ctype}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:fj")],
                ]),
            )
        else:
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u26A0\uFE0F That channel is already in the force-join list.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:fj")],
                ]),
            )
        return

    # ---- Multi-file forward / broadcast album detection ----
    # Issue 1: when admin is in awaiting_fwd_batch state, EVERY forwarded
    # message (album part OR standalone forward) is accumulated into a single
    # generic batch keyed "fwd_batch_multi". A debounce timer resets on each
    # new arrival so slightly-delayed forwards are all captured before
    # finalization (start=min / end=max -> rSTART_END).
    media_group_id = getattr(msg, "media_group_id", None)

    # Broadcast album: accumulate under a broadcast-specific key.
    if media_group_id and context.user_data.get("awaiting_broadcast"):
        bcast_key = f"bcast_batch_{media_group_id}"
        bbatch = context.user_data.get(bcast_key, [])
        bbatch.append(msg)
        context.user_data[bcast_key] = bbatch
        logger.info("Broadcast album batch: media_group_id=%s, count=%d",
                    media_group_id, len(bbatch))
        # (Re)start the delayed processor timer.
        context.user_data[f"{bcast_key}_timer"] = True
        asyncio.create_task(_process_broadcast_album_delayed(update, context, media_group_id))
        return

    # Multi-forward collection generation (awaiting_fwd_batch).
    if context.user_data.get("awaiting_fwd_batch"):
        # Use a single generic batch key so album parts AND standalone forwards
        # all land in the same list, then one finalize computes min/max.
        batch_key = "fwd_batch_multi"
        batch = context.user_data.get(batch_key, [])
        batch.append(msg)
        context.user_data[batch_key] = batch
        logger.info("Forward batch: +1 (total=%d, media_group_id=%s)",
                    len(batch), media_group_id)
        # Debounce: each new forward (re)sets the timer key, so only the last
        # arrival's _process_forward_batch_delayed actually fires.
        context.user_data[f"{batch_key}_timer"] = True
        asyncio.create_task(_process_forward_batch_delayed(update, context, batch_key))
        return

    # (awaiting_fwd_single removed — Issue 21 unified the forward button into
    #  link:fwd, which always uses the awaiting_fwd_batch path above. Single
    #  vs collection is auto-detected at finalize time in _finalize_forward_batch.)

    # ---- Forward-based Collection Link generation: first file ----
    if context.user_data.get("awaiting_fwd_range_first"):
        context.user_data.pop("awaiting_fwd_range_first", None)
        first_channel, first_msg = extract_forward_origin(msg)
        logger.info("Forward-range first: chat_id=%s resolved channel=%s msg_id=%s",
                     msg.chat.id, first_channel, first_msg)
        if not first_channel or not first_msg:
            await reply_protected(update, 
                "\u274C Cannot identify source file. Forward info may be stripped. Cancelled."
            )
            return
        context.user_data["awaiting_fwd_range_last"] = (first_channel, first_msg)
        await reply_protected(update, 
            f"\u2705 First file captured (msg {md_code_span(first_msg)}).\n\n"
            f"Now forward the *last* file of the collection.",
            parse_mode=ParseMode.MARKDOWN,
        )
        return
    # ---- Forward-based Collection Link generation: last file (Issue 2: explicit) ----
    if context.user_data.get("awaiting_fwd_range_last") is not None:
        first_channel, first_msg = context.user_data.pop("awaiting_fwd_range_last")
        last_channel, last_msg = extract_forward_origin(msg)
        logger.info("Forward-range last: chat_id=%s resolved channel=%s msg_id=%s",
                     msg.chat.id, last_channel, last_msg)
        if not last_channel or not last_msg:
            await reply_protected(update, 
                "\u274C Cannot identify source file. Forward info may be stripped. Cancelled."
            )
            return
        if first_channel != last_channel:
            await reply_protected(update, 
                "\u274C Both files must come from the same storage channel. Cancelled."
            )
            return
        start_id = min(first_msg, last_msg)
        end_id = max(first_msg, last_msg)
        logger.info("Forward-range resolved: start=%s end=%s channel=%s", start_id, end_id, last_channel)
        # Show loading feedback, then resolve the range WITHOUT creating a collection.
        status_msg = await safe_send_text(context.bot, update.effective_chat.id,
            f"\U0001F50D Validating collection (range {start_id}\u2013{end_id})...")
        files = await db.files_in_message_range(start_id, end_id, channel_id=last_channel)
        if not files:
            if status_msg:
                await safe_edit_text(status_msg,
                    f"\u274C No indexed files found in range {start_id}\u2013{end_id}.")
            return
        msg_ids = [int(f["message_id"]) for f in files]
        if status_msg:
            await safe_edit_text(status_msg,
                f"\U0001F4E6 Collection Found\n\n"
                f"Files: {len(msg_ids)}\n"
                f"Ready for delivery.\n"
                f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
                f"Tap Continue to configure this payload.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2705 Continue", callback_data=f"colsum:continue:{last_channel}"),
                     InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="link:range"),
                     InlineKeyboardButton("\u274C Cancel", callback_data="colsum:cancel")],
                ]))
        context.user_data["colsum_msg_ids"] = msg_ids
        context.user_data["colsum_channel_id"] = last_channel
        return
    # Broadcast takes priority (admin is composing a broadcast message).
    if context.user_data.get("awaiting_broadcast"):
        await send_broadcast_now(update, context)
        return
    state = context.user_data.get("awaiting_media")
    if not state:
        return
    variant = context.user_data.get("sm_variant", "first")
    caption = update.message.caption or None
    # BOTV13 Phase B (wired): serialize caption_entities so bold/italic/
    # text_link/code/etc. in the media caption survive SAVE → PREVIEW → SEND.
    cap_ent_json = serialize_entities(update.message.caption_entities) if update.message else None
    if state in ("photo", "any") and update.message.photo:
        photo = update.message.photo[-1]
        await db.set_start_message(variant, message_type="photo", file_id=photo.file_id,
                                    caption=caption, entities=cap_ent_json)
        await reply_protected(update,
            f"\u2705 Start message photo saved for *{variant}*.",
            parse_mode=ParseMode.MARKDOWN,
        )
    elif state in ("video", "any") and update.message.video:
        await db.set_start_message(variant, message_type="video",
                                    file_id=update.message.video.file_id, caption=caption,
                                    entities=cap_ent_json)
        await reply_protected(update,
            f"\u2705 Start message video saved for *{variant}*.",
            parse_mode=ParseMode.MARKDOWN,
        )
    else:
        await reply_protected(update, "No matching media received. Cancelled.")
    context.user_data.pop("awaiting_media", None)


# ============================================================
# BOT-45/46 (Task D): LIVE STORAGE SOURCE-IDENTITY RESOLUTION
# ============================================================
# The wizard's "Selected File" line used indexed_files.file_name — FROZEN
# at scan time. The CURRENT Telegram source (edited message / replaced
# media) is authoritative for the filename (and the media identity), so
# the SINGLE_SOURCE_RESOLVE flow re-resolves the live source HERE, right
# before the wizard opens, and refreshes the indexed row + the derived
# display layers (origin-aware: payloads.display_name_origin gates every
# overwrite; 'admin_override' rows are preserved verbatim).
#
# Allowed STORAGE_MESSAGE_SKIP reason codes (master prompt §6 — a skipped
# message is NEVER silent):
_STORAGE_SKIP_REASONS = frozenset({
    "NO_MESSAGE", "NO_MEDIA", "UNSUPPORTED_MEDIA", "MISSING_FILE_ID",
    "MISSING_FILE_UNIQUE_ID", "DUPLICATE_CANONICAL_MEDIA", "STALE_INDEX",
    "SOURCE_REPLACEMENT", "TELEGRAM_ERROR", "PERMISSION_ERROR",
    "INVALID_REFERENCE", "OTHER",
})


def _storage_uid_hash16(uid: _TiAny) -> str:
    """sha256(file_unique_id)[:16] — the telemetry-safe identity hash.

    Raw file ids are NEVER logged (the existing SINGLE_SOURCE_RESOLVE /
    INDEX_REPLACE_SOURCE_MEDIA discipline).
    """
    val = str(uid or "").strip()
    if not val:
        return "-"
    return _ti_hashlib.sha256(
        val.encode("utf-8", "replace")).hexdigest()[:16]


def _log_storage_message_skip(log, channel_id, message_id, reason_code,
                              media_type=None, has_file_id=None,
                              has_file_unique_id=None, file_pk=None,
                              detail="") -> None:
    """Emit STORAGE_MESSAGE_SKIP (safe fields only, per master prompt §6).

    ``reason_code`` is coerced into the allowed vocabulary so an internal
    caller can never invent a free-form reason. ``detail`` must be a short
    pre-sanitized explanation (exception TYPE names only — never message
    bodies, tokens or file ids).
    """
    code = str(reason_code or "OTHER").strip().upper()
    if code not in _STORAGE_SKIP_REASONS:
        code = "OTHER"
    _b = lambda v: "1" if v else ("0" if v is not None else "-")  # noqa: E731
    (log or _ti_log).info(
        "STORAGE_MESSAGE_SKIP channel_id=%s message_id=%s "
        "reason_code=%s media_type=%s has_file_id=%s "
        "has_file_unique_id=%s file_pk=%s%s",
        (int(channel_id) if channel_id is not None else "-"),
        (int(message_id) if message_id is not None else "-"),
        code, (str(media_type or "-")),
        _b(has_file_id), _b(has_file_unique_id),
        (int(file_pk) if file_pk is not None else "-"),
        (f" ({detail})" if detail else ""))


def _live_refresh_notice(result: _TiDict) -> _TiOptional[str]:
    """The one-line honest admin notice for a live source re-resolve.

    Pure function of the result dict (testable): returns None when the
    live source matched the index (nothing noteworthy happened), else a
    short line describing the refresh / replacement / skip so the admin
    NEVER wonders which identity the wizard below is using.
    """
    if not result:
        return None
    outcome = result.get("outcome")
    if not outcome or outcome in ("unchanged", "refreshed"):
        return None
    ch = result.get("channel_id")
    mid = result.get("message_id")
    where = f"{ch}:{mid}"
    reason = result.get("reason_code")
    if outcome == "replaced":
        name = result.get("source_filename") or "(unnamed)"
        return (f"\u267B\uFE0F Source media at {where} was replaced in place "
                f"(same file #{result.get('file_pk')}).\n"
                f"Current source filename: {name}")
    if outcome == "skipped":
        if reason == "NO_MESSAGE":
            return (f"\u26A0\uFE0F Storage source {where} no longer exists "
                    f"on Telegram \u2014 the indexed file is stale.\n"
                    f"Reindex the storage channel to repair it.")
        if reason == "NO_MEDIA":
            return (f"\u26A0\uFE0F Message {where} exists but carries no "
                    f"media anymore \u2014 the indexed file is stale.\n"
                    f"Reindex the storage channel to repair it.")
        if reason == "DUPLICATE_CANONICAL_MEDIA":
            return (f"\u26A0\uFE0F The current media at {where} is already "
                    f"indexed under another file row.\n"
                    f"The wizard continues with the existing indexed row.")
        if reason in ("SOURCE_REPLACEMENT", "STALE_INDEX"):
            return (f"\u26A0\uFE0F The source media at {where} changed "
                    f"identity and could not be replaced in place.\n"
                    f"Reindex the storage channel, then restart the wizard.")
        if reason == "PERMISSION_ERROR":
            return (f"\u26A0\uFE0F The bot cannot access {where} anymore "
                    f"\u2014 the indexed identity could not be verified.")
        if reason in ("MISSING_FILE_ID", "MISSING_FILE_UNIQUE_ID"):
            return (f"\u26A0\uFE0F The current media at {where} is missing "
                    f"its Telegram file identity ({reason}).")
        return (f"\u26A0\uFE0F Live source check for {where} failed "
                f"({reason or 'OTHER'}) \u2014 using the indexed identity.")
    return None


async def _live_refresh_source_identity(
        bot, admin_id, channel_id, message_id, file_row, *,
        db=None, log=None, fetch_media=None, probe_exists=None
        ) -> _TiDict:
    """BOT-45/46 (Task D): LIVE Telegram source re-resolve for the payload
    creation wizard's SINGLE_SOURCE_RESOLVE flow.

    Performs a live fetch of the CURRENT source message (the codebase's
    existing ``fetch_channel_media`` copy/forward transport — the same
    helper the verification engine uses), then:

      * same (channel_id, message_id) + same file_unique_id  -> refresh the
        MUTABLE metadata (file_name & friends) on the canonical row and
        propagate the new filename into the derived display layers
        (payloads.display_name + website_payloads.title), ORIGIN-AWARE:
        only NULL/'source' provenance rows are refreshed;
        'admin_override' rows are PRESERVED verbatim;
      * same (channel_id, message_id) + NEW file_unique_id -> the guarded
        in-place source-media replacement (``attempt_source_media_replacement``:
        file_id, file_unique_id, file_name, size, MIME, media type,
        duration, dimensions — file_pk and ALL foreign keys preserved),
        then the same origin-aware propagation;
      * any unusable source -> STORAGE_MESSAGE_SKIP with a classified
        reason_code from the allowed set — NEVER a silent skip.

    Telemetry (safe fields only — raw file ids never logged):
      STORAGE_SOURCE_RESOLVE_START / STORAGE_SOURCE_RESOLVE_RESULT /
      STORAGE_FILENAME_SOURCE / STORAGE_MESSAGE_SKIP (+ the repo's
      INDEX_REPLACE_SOURCE_MEDIA_START/_COMPLETE/_FAILED events).

    Returns a result dict (``outcome`` in
    refreshed|unchanged|replaced|skipped|error, plus channel_id,
    message_id, file_pk, file_unique_id_hash, source_filename,
    payload_display_name, display_name_origin). NEVER raises — the caller
    keeps the existing wizard flow on any internal failure.
    """
    log = log or _ti_log
    if db is None or fetch_media is None:
        ns = _ti_runtime_ns()
        if ns is not None:
            db = db or getattr(ns, "db", None)
            fetch_media = fetch_media or getattr(ns, "fetch_channel_media",
                                                 None)
            probe_exists = probe_exists or getattr(
                ns, "_probe_message_exists", None)
    channel_id = int(channel_id)
    message_id = int(message_id)
    file_pk = int(file_row["id"])
    stored_uid = str(_ti_row_value(file_row, "file_unique_id", "") or "")
    stored_name = _ti_row_value(file_row, "file_name")
    result: _TiDict = {
        "outcome": "error", "reason_code": None,
        "channel_id": channel_id, "message_id": message_id,
        "file_pk": file_pk,
        "file_unique_id_hash": _storage_uid_hash16(stored_uid),
        "source_filename": None, "payload_display_name": None,
        "display_name_origin": None, "file_name": stored_name,
    }
    log.info(
        "STORAGE_SOURCE_RESOLVE_START channel_id=%s message_id=%s "
        "file_pk=%s file_unique_id_hash=%s",
        channel_id, message_id, file_pk,
        result["file_unique_id_hash"])

    async def _finish(outcome, reason_code=None):
        result["outcome"] = outcome
        result["reason_code"] = reason_code
        # The payload display layer (for the RESULT telemetry + the wizard
        # echo): the single-file payload bound to this EXACT source, when
        # one exists (create mode usually has none yet — "-").
        try:
            prow = await db.find_single_payload_by_channel_message(
                channel_id, message_id)
            result["payload_display_name"] = (
                _ti_row_value(prow, "display_name") or "-") \
                if prow is not None else "-"
            result["display_name_origin"] = (
                _ti_row_value(prow, "display_name_origin") or "-") \
                if prow is not None else "-"
        except Exception:  # noqa: BLE001 — telemetry field is best-effort
            result["payload_display_name"] = "-"
            result["display_name_origin"] = "-"
        log.info(
            "STORAGE_SOURCE_RESOLVE_RESULT channel_id=%s message_id=%s "
            "file_pk=%s file_unique_id_hash=%s source_filename=%r "
            "payload_display_name=%r display_name_origin=%s outcome=%s%s",
            channel_id, message_id, file_pk,
            result["file_unique_id_hash"], result["source_filename"],
            result["payload_display_name"], result["display_name_origin"],
            outcome, (f" reason_code={reason_code}" if reason_code else ""))
        return result

    try:
        # 1) LIVE fetch of the CURRENT source message (copy first, forward
        #    fallback — the standard transport; the temp copy is deleted).
        info, fwd_mid = None, None
        try:
            info, fwd_mid = await fetch_media(bot, admin_id, channel_id,
                                              message_id)
        except Exception as exc:  # noqa: BLE001 — transport failure
            _log_storage_message_skip(
                log, channel_id, message_id, "TELEGRAM_ERROR", None,
                None, None, file_pk,
                f"fetch raised {type(exc).__name__}")
            return await _finish("skipped", "TELEGRAM_ERROR")
        finally:
            if fwd_mid:
                try:
                    await bot.delete_message(int(admin_id), int(fwd_mid))
                except Exception:  # noqa: BLE001 — cleanup is best-effort
                    pass

        # 2) No usable media from the live source -> classify the skip
        #    (message gone vs no media vs access/transport), never silent.
        if not info:
            probe = None
            if probe_exists is not None:
                try:
                    probe = await probe_exists(bot, admin_id, channel_id,
                                               message_id)
                except Exception:  # noqa: BLE001
                    probe = None
            if probe is False:
                reason = "NO_MESSAGE"
            elif probe is True:
                reason = "NO_MEDIA"
            else:
                # Existence unknown — distinguish permission from transport
                # with the one cheap channel-level call.
                try:
                    await bot.get_chat(channel_id)
                    reason = "TELEGRAM_ERROR"
                except Exception as exc:  # noqa: BLE001
                    reason = "PERMISSION_ERROR" if _is_forbidden(exc) \
                        else "TELEGRAM_ERROR"
            _log_storage_message_skip(
                log, channel_id, message_id, reason,
                _ti_row_value(file_row, "media_type"),
                None, None, file_pk,
                "probe=%s" % ("missing" if probe is False
                              else ("exists" if probe is True else "unknown")))
            return await _finish("skipped", reason)

        media_type = str(info.get("media_type") or "-")
        fresh_fid = str(info.get("file_id") or "").strip()
        fresh_uid = str(info.get("file_unique_id") or "").strip()
        fresh_name = info.get("file_name")

        # 3) Identity sanity on the fresh media (never index a phantom).
        if not fresh_fid:
            _log_storage_message_skip(
                log, channel_id, message_id, "MISSING_FILE_ID",
                media_type, False, bool(fresh_uid), file_pk)
            return await _finish("skipped", "MISSING_FILE_ID")
        if not fresh_uid:
            _log_storage_message_skip(
                log, channel_id, message_id, "MISSING_FILE_UNIQUE_ID",
                media_type, True, False, file_pk)
            return await _finish("skipped", "MISSING_FILE_UNIQUE_ID")

        # 4) Identity comparison — the canonical decision.
        if not stored_uid or fresh_uid == stored_uid:
            # SAME identity (or a legacy NULL identity): refresh the
            # MUTABLE metadata only (file_name/caption/size/... — never
            # file_id/file_unique_id on this path).
            changes = await db.refresh_indexed_file_mutable_metadata(
                file_pk, info)
            if "file_name" in changes:
                old_name, new_name = changes["file_name"]
                result["source_filename"] = new_name
                result["file_name"] = new_name
                _prop = await db.refresh_source_derived_display_name(
                    file_pk, new_name, old_name=old_name)
                log.info(
                    "STORAGE_FILENAME_SOURCE channel_id=%s message_id=%s "
                    "file_pk=%s source_filename=%r "
                    "payload_display_name=%r display_name_origin=%s "
                    "payloads_refreshed=%s listings_refreshed=%s "
                    "(display name re-derived from the CURRENT source "
                    "filename, origin-gated)",
                    channel_id, message_id, file_pk, new_name,
                    result["payload_display_name"],
                    result["display_name_origin"],
                    len(_prop.get("payload_ids") or []),
                    len(_prop.get("listing_ids") or []))
                return await _finish("refreshed")
            result["source_filename"] = fresh_name or stored_name
            return await _finish("unchanged")

        # 5) NEW identity at the SAME (channel_id, message_id): the guarded
        #    in-place source-media replacement (preserves file_pk + every
        #    foreign key; emits INDEX_REPLACE_SOURCE_MEDIA_* telemetry).
        owner = await db.get_indexed_file_by_unique_id(fresh_uid)
        if owner is not None and int(owner["id"]) != file_pk:
            _log_storage_message_skip(
                log, channel_id, message_id, "DUPLICATE_CANONICAL_MEDIA",
                media_type, True, True, file_pk,
                "the current file_unique_id is already owned by file_pk=%s"
                % int(owner["id"]))
            return await _finish("skipped", "DUPLICATE_CANONICAL_MEDIA")
        replaced = await db.attempt_source_media_replacement(
            channel_id, message_id, info)
        if replaced:
            fresh_row = await db.get_indexed_file_by_id(file_pk)
            new_name = (fresh_row["file_name"] if fresh_row
                        else fresh_name) or stored_name
            result["source_filename"] = new_name
            result["file_name"] = new_name
            result["file_unique_id_hash"] = _storage_uid_hash16(fresh_uid)
            _prop = await db.refresh_source_derived_display_name(
                file_pk, new_name, old_name=stored_name)
            log.info(
                "STORAGE_FILENAME_SOURCE channel_id=%s message_id=%s "
                "file_pk=%s source_filename=%r "
                "payload_display_name=%r display_name_origin=%s "
                "payloads_refreshed=%s listings_refreshed=%s "
                "(display name re-derived from the REPLACED source media)",
                channel_id, message_id, file_pk, new_name,
                result["payload_display_name"],
                result["display_name_origin"],
                len(_prop.get("payload_ids") or []),
                len(_prop.get("listing_ids") or []))
            return await _finish("replaced")
        # Replacement refused (repo already logged the precise
        # INDEX_REPLACE_SOURCE_MEDIA_FAILED/_SKIPPED reason) — the index
        # stays authoritative; classify honestly.
        _log_storage_message_skip(
            log, channel_id, message_id, "SOURCE_REPLACEMENT",
            media_type, True, True, file_pk,
            "in-place replacement refused — the canonical indexed row "
            "stays authoritative; reindex to reconcile")
        return await _finish("skipped", "SOURCE_REPLACEMENT")
    except Exception as exc:  # noqa: BLE001 — live refresh never raises
        _log_storage_message_skip(
            log, channel_id, message_id, "OTHER",
            _ti_row_value(file_row, "media_type"),
            None, None, file_pk,
            f"live refresh raised {type(exc).__name__}")
        return await _finish("error", "OTHER")


def _ti_row_value(row, key, default=None):
    """Index an aiosqlite.Row OR a plain dict defensively.

    A missing key returns ``default`` (never raises, never fabricates) —
    both row types expose ``keys()`` so one path covers them.
    """
    if row is None:
        return default
    try:
        keys = row.keys()
    except Exception:  # noqa: BLE001 — non-mapping
        keys = None
    if keys is not None:
        try:
            return row[key] if key in keys else default
        except Exception:  # noqa: BLE001
            return default
    try:
        return row.get(key, default)
    except Exception:  # noqa: BLE001
        return default


def _is_forbidden(exc: _TiAny) -> bool:
    """True when the exception is Telegram Forbidden (access revoked)."""
    name = type(exc).__name__.lower()
    return "forbidden" in name or "forbidden" in str(exc or "").lower()


# ------------------------------------------------------------------
# BOT-45/46: namespace registration of the new module-local helpers.
# namespace.py copies vars(state) into the shared runtime namespace
# (step 1) and only rebinds MANIFEST-listed section names (step 2). The
# manifest is the frozen authoritative bot.py AST table, so these new
# Task-D names are registered onto the STATE foundation at import time
# instead — they become ordinary namespace names before _assemble() runs,
# which keeps the late-binding contract exactly: the rebound text_handler
# resolves them through the namespace globals, and monkey-patching
# runtime.<name> keeps working everywhere.
# ------------------------------------------------------------------
from app.presentation.telegram import state as _ti_state_reg  # noqa: E402

_ti_state_reg._storage_uid_hash16 = _storage_uid_hash16
_ti_state_reg._log_storage_message_skip = _log_storage_message_skip
_ti_state_reg._live_refresh_notice = _live_refresh_notice
_ti_state_reg._live_refresh_source_identity = _live_refresh_source_identity
_ti_state_reg._is_forbidden = _is_forbidden
_ti_state_reg._ti_row_value = _ti_row_value
_ti_state_reg._STORAGE_SKIP_REASONS = _STORAGE_SKIP_REASONS
# The module-private SUPPORT names the rebound manifest functions resolve
# through the namespace globals (the DD2 landmine class this architecture
# exists to prevent): the logger + hashlib module + sys module + the
# runtime-ns resolver used by _live_refresh_source_identity /
# _log_storage_message_skip / _storage_uid_hash16 / _ti_runtime_ns.
_ti_state_reg._ti_log = _ti_log
_ti_state_reg._ti_hashlib = _ti_hashlib
_ti_state_reg._ti_logging = _ti_logging
_ti_state_reg._ti_sys = _ti_sys
_ti_state_reg._ti_runtime_ns = _ti_runtime_ns
