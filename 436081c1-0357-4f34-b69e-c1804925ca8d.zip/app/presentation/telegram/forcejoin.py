"""Force Join — progressive FJ, join requests, link health, panels.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



def _fj_verify_debounced(user_id: int) -> bool:
    """§11: True when a Verify tap for this user arrived too soon after the
    previous accepted one (debounce window). The window never blocks the
    FIRST tap and never persists a denial — the next tap after the window
    runs a full fresh check."""
    now = time.monotonic()
    last = _FJ_VERIFY_LAST_TAP.get(int(user_id))
    if last is not None and (now - last) < FJ_VERIFY_DEBOUNCE_SECONDS:
        return True
    _FJ_VERIFY_LAST_TAP[int(user_id)] = now
    # Prune stale entries (bounded memory).
    if len(_FJ_VERIFY_LAST_TAP) > 512:
        cutoff = now - FJ_VERIFY_DEBOUNCE_SECONDS
        for k in [k for k, v in _FJ_VERIFY_LAST_TAP.items() if v < cutoff]:
            _FJ_VERIFY_LAST_TAP.pop(k, None)
    return False



def _store_join_request(user_id: int, channel_id: int) -> None:
    """Record a pending join request in memory with the current timestamp."""
    PENDING_JOIN_REQUESTS[(user_id, channel_id)] = time.time()
    logger.debug("JoinRequest stored: user=%s channel=%s (cache size=%d)",
                 user_id, channel_id, len(PENDING_JOIN_REQUESTS))



def _consume_join_request(user_id: int, channel_id: int) -> bool:
    """Check + remove a pending join request. Returns True if a valid
    (non-expired) request existed, False otherwise. Expired entries are removed."""
    _prune_join_requests()
    key = (user_id, channel_id)
    ts = PENDING_JOIN_REQUESTS.pop(key, None)
    if ts is None:
        return False
    if time.time() - ts > JOIN_REQUEST_TTL:
        logger.debug("JoinRequest expired (TTL): user=%s channel=%s", user_id, channel_id)
        return False
    logger.debug("JoinRequest consumed: user=%s channel=%s", user_id, channel_id)
    return True



def _has_pending_join_request(user_id: int, channel_id: int) -> bool:
    """Check (without removing) if a valid pending join request exists."""
    _prune_join_requests()
    ts = PENDING_JOIN_REQUESTS.get((user_id, channel_id))
    if ts is None:
        return False
    if time.time() - ts > JOIN_REQUEST_TTL:
        PENDING_JOIN_REQUESTS.pop((user_id, channel_id), None)
        return False
    return True



def _prune_join_requests() -> None:
    """Remove expired entries from the pending join request cache."""
    if not PENDING_JOIN_REQUESTS:
        return
    now = time.time()
    expired = [k for k, ts in PENDING_JOIN_REQUESTS.items() if now - ts > JOIN_REQUEST_TTL]
    for k in expired:
        PENDING_JOIN_REQUESTS.pop(k, None)
    if expired:
        logger.debug("JoinRequest pruned %d expired entries (cache size=%d)",
                     len(expired), len(PENDING_JOIN_REQUESTS))



async def _channel_is_request_to_join(bot, channel_id: int) -> bool:
    """Check if a channel is a Request-to-Join channel (has pending join requests
    enabled). Returns True if the channel's chat type uses join requests."""
    try:
        chat = await bot.get_chat(channel_id)
        # A Request-to-Join channel has chat.type == "channel" and
        # linked_chat_id set, OR it's a group with join_request enabled.
        # Telegram exposes this via ChatJoinRequest updates — if we've received
        # one for this channel, _store_join_request was called. Otherwise we
        # check the chat's permissions/properties.
        # Simplest reliable check: if chat.type == "channel" and the bot has
        # received a join request for it, the cache has an entry.
        return True  # optimistic — actual policy decision happens in is_member
    except TelegramError:
        return False



async def build_force_join_block_message(bot, user_id: int, payload: str,
                                         *, gate_channels: Optional[list] = None
                                         ) -> Tuple[str, InlineKeyboardMarkup, Optional[list]]:
    """BOT6 redesigned Force-Join user screen.

    Renders a PER-CHANNEL status list (✅ Joined / 🔒 Not joined) so the user
    always sees EXACTLY which channels remain — never a generic
    'please join required channels' when the system knows what is missing.
    Each not-joined channel gets its own Join button; a single Verify button
    sits at the bottom.

    Format (per spec):
        🔐 JOIN REQUIRED CHANNELS
        To continue, join all required channels below.
        📊 Progress: 2/3 joined
        ⏳ Remaining: 1

        📢 Channel A — ✅ Joined
        📢 Channel B — ✅ Joined
        📢 Channel C — 🔒 Not joined

        [ 📢 Join Channel C ]
        [ 🔄 VERIFY MEMBERSHIP ]

    Bot-fault channels (BOT_NOT_ADMIN / CHANNEL_NOT_FOUND / …) render a
    diagnostic so the user is never blamed for the bot's misconfiguration.

    V26.2 (bot-41 §16-§20): ``gate_channels`` — the Access Engine's
    PER-GATE slice (the pinned batch for THIS gated delivery, from
    fj_gate_unjoined). When provided the page renders EXACTLY that slice:
    the current batch only, never a future batch (the show_all-mode
    future-channel leak is closed on the bot surface too), and the
    completed members of earlier batches never reappear. UI == AUTH by
    construction (the engine computed the slice).

    Returns (text, keyboard, entities).
    """
    all_channels = await db.list_force_channels()
    # No channels configured — no FJ requirement.
    if not all_channels:
        text = "\u2705 No required channels. You can continue."
        return text, InlineKeyboardMarkup([]), None

    # b11 §2 — MAIN BOT VERIFIER: when the FJ screen renders inside a
    # NETWORK worker context, every per-channel membership check runs
    # through the MAIN bot's identity (the network bot needs NO channel
    # admin rights). The page itself (send/edit) still goes through the
    # serving bot below — only the VERIFICATION identity changes.
    _verifier = _fj_verifier_bot(bot)
    if _verifier is not bot:
        logger.info("FORCE_JOIN_MAIN_VERIFIER_START user_id=%s "
                    "context=fj_page_render serving=network_worker",
                    user_id)

    if gate_channels is not None:
        # V26.2: the ENGINE's per-gate slice IS the UI batch (identical by
        # construction — no recompute, no future-batch leak, no
        # double-drive of the state machine).
        ui_not_joined = list(gate_channels)
        ui_batch_ids = {int(ch["channel_id"]) for ch in ui_not_joined}
        display_channels = list(gate_channels)
        logger.info(
            "BOT6_FJ_BATCH_UI_VS_AUTH user_id=%s payload=%s mode=gate_slice "
            "ui_batch_ids=%s identical=True (V26.2 per-gate pinned batch — "
            "future batches never delivered)",
            user_id, (payload or "-")[:40], sorted(ui_batch_ids),
        )
    else:
        # BOT6 P3: UI and authorization MUST use the SAME batch. We call
        # _get_fj_batch(for_access=True) — the EXACT same path as
        # _unjoined_for_access — to determine which channels the UI should
        # show. This guarantees the displayed batch == the
        # authorization-checked batch.
        ui_not_joined = await _get_fj_batch(user_id, payload, for_access=True,
                                            access_payload_id=None, bot=_verifier)
        ui_batch_ids = {int(ch["channel_id"]) for ch in ui_not_joined}
        # Also get the full active batch (joined + unjoined) for display.
        progress = await _get_fj_progress(user_id)
        active_ids = _parse_json_list(
            progress["active_batch"] if progress and "active_batch" in progress.keys() else None, [])
        mode = await get_fj_mode()
        if mode == FJ_MODE_SHOW_ALL:
            # SHOW_ALL: display ALL channels (joined + unjoined).
            display_channels = all_channels
        else:
            # Progressive/Fixed: display the active batch channels.
            chan_map = {int(ch["channel_id"]): ch for ch in all_channels}
            display_channels = [chan_map[cid] for cid in active_ids if cid in chan_map]
            if not display_channels:
                # No active batch yet — use the unjoined set (just-created batch).
                display_channels = ui_not_joined

    # Fresh per-channel live check (authoritative) for DISPLAY channels only.
    # b11 §2: the MAIN bot performs each check in a network-worker context.
    statuses: List[Tuple[aiosqlite.Row, MemberCheckResult]] = []
    for ch in display_channels:
        cid = _safe_row_get(ch, "channel_id")
        if cid is None:
            continue
        res = await check_membership(_verifier, user_id, int(cid))
        statuses.append((ch, res))

    required = len(statuses)
    joined = sum(1 for _, r in statuses if r.is_joined())
    remaining = required - joined
    bot_fault_channels = [(ch, r) for ch, r in statuses if r.is_bot_fault]

    if _verifier is not bot:
        logger.info("FORCE_JOIN_MAIN_VERIFIER_RESULT user_id=%s "
                    "context=fj_page_render joined=%s remaining=%s "
                    "bot_fault=%s",
                    user_id, joined, remaining, len(bot_fault_channels))

    # BOT6 P3: log that UI batch == authorization batch.
    # BOT7 FIX (comparison semantics): the previous code compared the DISPLAYED
    # batch (joined + unjoined channels of the active batch) against the
    # UNJOINED-ONLY subset returned by _get_fj_batch(for_access=True). When a
    # user had partially joined the batch, that comparison reported
    # identical=False even though UI and authorization used the SAME batch.
    # The authorization-enforced set for progressive/fixed modes IS the active
    # batch (every channel in it must be joined before access is granted);
    # the UI displays exactly that batch with per-channel ✅/🔒 status. For
    # show_all mode every configured channel is both displayed and enforced.
    # (V26.2: the gate_channels path logs its own identical=True line above —
    # the slice IS the engine's authorization batch by construction.)
    if gate_channels is None:
        display_ids = sorted({int(_safe_row_get(ch, "channel_id")) for ch in display_channels})
        _configured_ids = {int(ch["channel_id"]) for ch in all_channels}
        if mode == FJ_MODE_SHOW_ALL:
            enforced_ids = sorted(_configured_ids)
        else:
            # Enforced set = persisted active batch ∪ any batch just created by
            # the _get_fj_batch(for_access=True) call above (restricted to
            # currently configured channels — removed channels are skipped by
            # the state machine, so they are not enforced either).
            enforced_ids = sorted(({int(x) for x in active_ids} | ui_batch_ids) & _configured_ids)
        _identical = display_ids == enforced_ids
        logger.info(
            "BOT6_FJ_BATCH_UI_VS_AUTH user_id=%s payload=%s mode=%s "
            "ui_batch_ids=%s auth_batch_ids=%s identical=%s",
            user_id, payload, mode,
            display_ids,
            enforced_ids,
            _identical,
        )
        if not _identical:
            # Genuine divergence between what is displayed and what is enforced —
            # this must never happen; log loudly for diagnosis.
            logger.error(
                "BOT6_FJ_BATCH_UI_VS_AUTH user_id=%s payload=%s mode=%s "
                "MISMATCH displayed=%s enforced=%s unjoined=%s active=%s",
                user_id, payload, mode, display_ids, enforced_ids,
                sorted(ui_batch_ids), active_ids,
            )
    logger.info(
        "BOT6_FJ_DECISION user_id=%s payload=%s required=%s joined=%s remaining=%s "
        "decision=%s bot_fault=%s",
        user_id, payload, required, joined, remaining,
        "ALLOW" if remaining == 0 else "DENY",
        len(bot_fault_channels),
    )

    # Build per-channel status lines.
    lines = [
        "\U0001F510 JOIN REQUIRED CHANNELS",
        "",
        "To continue, join all required channels below.",
        f"\U0001F4CA Progress: {joined}/{required} joined",
        f"\u23F3 Remaining: {remaining}",
        "",
    ]
    for ch, res in statuses:
        label = _force_channel_label(ch)
        if res == MemberCheckResult.MEMBER:
            lines.append(f"\U0001F4E2 {label} — \u2705 Joined")
        elif res == MemberCheckResult.ADMINISTRATOR:
            lines.append(f"\U0001F4E2 {label} — \u2705 Joined (admin)")
        elif res == MemberCheckResult.CREATOR:
            lines.append(f"\U0001F4E2 {label} — \u2705 Joined (creator)")
        elif res == MemberCheckResult.REQUEST_PENDING:
            # PHASE 6 §10: the join-request experience — the user already
            # submitted a request; never re-tell them to Join.
            lines.append(f"\U0001F4E2 {label} — \u23F3 Join request submitted")
            lines.append("   Your request is waiting for approval.")
            lines.append("   Once approved, tap Verify.")
        elif res == MemberCheckResult.NOT_MEMBER:
            lines.append(f"\U0001F4E2 {label} — \U0001F512 Not joined")
        elif res == MemberCheckResult.BOT_NOT_ADMIN:
            lines.append(f"\u26A0\uFE0F {label} — \u274C Bot is not admin here")
        elif res == MemberCheckResult.CHANNEL_NOT_FOUND:
            lines.append(f"\u26A0\uFE0F {label} — \u274C Channel not found")
        elif res == MemberCheckResult.PRIVATE_CHANNEL_UNAVAILABLE:
            lines.append(f"\u26A0\uFE0F {label} — \u274C Private channel unavailable")
        else:  # TELEGRAM_ERROR — §9: NEVER blame the user for a Telegram failure
            lines.append(f"\u26A0\uFE0F {label} — couldn't verify right now.")
            lines.append("   Please tap Verify again in a moment.")

    # Custom join text support (issue #47): if the FIRST not-joined channel has
    # custom join_text, prepend it. We still render the per-channel status list
    # so the user always sees what's missing.
    custom_text = None
    custom_entities_json = None
    for ch, res in statuses:
        if not res.is_joined():
            custom_text = _safe_row_get(ch, "join_text")
            custom_entities_json = _safe_row_get(ch, "join_text_entities")
            break

    entities_out: Optional[list] = None
    if custom_text:
        # Prepend the custom text, then the status list. Entities carry over.
        entities_out = deserialize_entities(custom_entities_json)
        body = "\n".join(lines)
        text = f"{custom_text}\n\n{body}"
    else:
        text = "\n".join(lines)

    if remaining == 0:
        # All joined — shouldn't reach here (caller checks first) but guard.
        text = ("\u2705 Membership verified!\n\nAll required channels have been "
                "joined. You can continue now.")
        return text, InlineKeyboardMarkup([]), None

    if bot_fault_channels:
        # PHASE 6 §9: distinguish config faults (bot not admin / channel
        # gone) from TRANSIENT Telegram failures — never blame the user.
        _config_faults = [(ch, r) for ch, r in bot_fault_channels
                          if r in (MemberCheckResult.BOT_NOT_ADMIN,
                                   MemberCheckResult.CHANNEL_NOT_FOUND,
                                   MemberCheckResult.PRIVATE_CHANNEL_UNAVAILABLE)]
        _transient_faults = [(ch, r) for ch, r in bot_fault_channels
                              if r not in (MemberCheckResult.BOT_NOT_ADMIN,
                                           MemberCheckResult.CHANNEL_NOT_FOUND,
                                           MemberCheckResult.PRIVATE_CHANNEL_UNAVAILABLE)]
        if _config_faults:
            text += ("\n\n\u26A0\uFE0F One or more channels could not be verified because the "
                     "bot is not admin there. Please ask the admin to fix the configuration.")
        if _transient_faults:
            text += ("\n\n\u26A0\uFE0F We couldn't verify some channels right now "
                     "(Telegram is rate-limiting us). Please tap Verify again "
                     "in a moment — your joined status is NOT affected.")

    # PHASE 8: build the keyboard FIRST — its per-channel link resolution
    # (health-checked, auto-repairing) populates the health cache that the
    # dead-link notice below reads.
    # b11 §2: the JOIN-BUTTON machinery (invite-link health checks,
    # export_chat_invite_link — channel-admin operations) runs through
    # the MAIN bot verifier too: a NETWORK worker has no channel admin
    # rights, so the serving bot would produce dead Join buttons. The
    # keyboard layout itself is bot-independent.
    kb = await build_force_join_keyboard(_verifier, payload,
                                         statuses=statuses)

    # PHASE 8 (§17): friendly state for channels whose Join link is known
    # unusable (after the auto-repair attempt inside the keyboard build).
    # Users must NEVER be handed a dead Join button or a raw Telegram error.
    # The keyboard builder omits the button for these channels; here we say
    # WHY, in plain, non-blaming words.
    _dead_link_labels: List[str] = []
    for ch, res in statuses:
        if res != MemberCheckResult.NOT_MEMBER:
            continue
        cid = _safe_row_get(ch, "channel_id")
        if cid is None:
            continue
        cached = _FJ_LINK_HEALTH_CACHE.get(int(cid))
        if cached is None:
            continue
        if cached.state in (_fj_health.LINK_EXPIRED, _fj_health.LINK_REVOKED,
                            _fj_health.LINK_INVALID):
            # Public channels fell back to their permanent t.me link in the
            # keyboard builder — only private dead links need the notice.
            uname = _safe_row_get(ch, "channel_name")
            if not (uname and str(uname).lstrip("@").strip()):
                _dead_link_labels.append(_force_channel_label(ch))
    if _dead_link_labels:
        for _lbl in _dead_link_labels:
            text += ("\n\n" + _fj_health.user_unavailable_line(_lbl))
    return text, kb, entities_out



async def send_force_join_page(bot, chat_id: int, user_id: int, payload: str,
                                *, trace_id: Optional[str] = None,
                                edit_message_id: Optional[int] = None,
                                gate_channels: Optional[list] = None) -> Optional[int]:
    """BOT6: send the force join page with optional media + text + buttons.

    Phase 8 edit-in-place: when `edit_message_id` is provided, the bot EDITS the
    existing FJ message instead of sending a new one. This fulfills the rule
    'STATE CHANGE -> UPDATE DB -> RENDER -> EDIT EXISTING MESSAGE'. Only sends a
    new message when there is no existing one to edit (or Telegram confirms it
    can't be edited). Returns the message_id used (for tracking).

    Logs BOT6_FJ_USER_UI action=CREATE|EDIT|RECREATE so the user FJ message
    lifecycle is reconstructable from logs.

    V26.2 (bot-41 §16-§20): ``gate_channels`` — the Access Engine's per-gate
    slice for THIS gated delivery (the pinned batch); the page renders
    exactly that batch (never a future batch — the show_all leak closed).
    """
    text, kb, entities_list = await build_force_join_block_message(
        bot, user_id, payload, gate_channels=gate_channels)
    # Check if any channel has media attached.
    channels = await db.list_force_channels()
    media_file_id = None
    media_type = None
    for ch in channels:
        mf = _safe_row_get(ch, "media_file_id")
        mt = _safe_row_get(ch, "media_type")
        if mf and mt:
            media_file_id = mf
            media_type = mt
            break
    media_kwargs: Dict[str, Any] = {}
    text_kwargs: Dict[str, Any] = {}
    if entities_list:
        media_kwargs["caption_entities"] = entities_list
        text_kwargs["entities"] = entities_list
    # Phase 8: EDIT the existing message if we have one. Try edit first; on
    # failure (message gone / can't edit), fall through to CREATE.
    if edit_message_id:
        try:
            if media_file_id and media_type:
                # Editing a media message with new media is unreliable; edit text only.
                await bot.edit_message_text(text, chat_id=chat_id,
                                            message_id=edit_message_id, reply_markup=kb)
            else:
                if entities_list:
                    await bot.edit_message_text(text, chat_id=chat_id,
                                                message_id=edit_message_id,
                                                reply_markup=kb, entities=entities_list)
                else:
                    await bot.edit_message_text(text, chat_id=chat_id,
                                                message_id=edit_message_id, reply_markup=kb)
            logger.info(
                "BOT6_FJ_USER_UI action=EDIT trace_id=%s user_id=%s chat_id=%s "
                "message_id=%s",
                trace_id or "-", user_id, chat_id, edit_message_id,
            )
            logger.info(
                "BOT6_FJ_MESSAGE_ACTION user_id=%s payload=%s action=EDIT "
                "chat_id=%s message_id=%s reason=verify_edit_in_place",
                user_id, (payload or "-")[:40], chat_id, edit_message_id,
            )
            return edit_message_id
        except TelegramError as e:
            err = str(e).lower()
            if "not modified" in err:
                logger.info(
                    "BOT6_FJ_USER_UI action=EDIT trace_id=%s message_id=%s reason=no_change",
                    trace_id or "-", edit_message_id,
                )
                return edit_message_id
            # Message gone or can't edit -> fall through to CREATE.
            logger.warning(
                "BOT6_FJ_EDIT_FALLBACK message_id=%s error=%s decision=CREATE",
                edit_message_id, err[:80],
            )
            logger.warning(
                "BOT6_FJ_USER_UI action=RECREATE trace_id=%s old_message_id=%s "
                "reason=%s",
                trace_id or "-", edit_message_id, err[:80],
            )
            logger.info(
                "BOT6_FJ_MESSAGE_ACTION user_id=%s payload=%s action=RECREATE "
                "chat_id=%s old_message_id=%s reason=%s",
                user_id, (payload or "-")[:40], chat_id, edit_message_id,
                err[:80],
            )
    # CREATE a new FJ message.
    sent_msg = None
    if media_file_id and media_type:
        sent_msg = await send_bot_media(bot, chat_id, media_type, media_file_id,
                                        caption=text, reply_markup=kb, **media_kwargs)
        if not sent_msg:
            logger.warning("ForceJoin: media send failed, falling back to text")
    if not sent_msg:
        if entities_list:
            sent_msg = await safe_send_text(bot, chat_id, text, reply_markup=kb, **text_kwargs)
        else:
            sent_msg = await safe_send_text(bot, chat_id, text, reply_markup=kb)
    new_mid = getattr(sent_msg, "message_id", None) if sent_msg else None
    # P7: record the canonical FJ message_id for this (chat, user) so the next
    # Verify EDITS this message instead of creating a new one.
    if new_mid:
        _fj_user_msg_set(chat_id, user_id, new_mid)
    logger.info(
        "BOT6_FJ_USER_UI action=CREATE trace_id=%s user_id=%s chat_id=%s new_message_id=%s",
        trace_id or "-", user_id, chat_id, new_mid,
    )
    logger.info(
        "BOT6_FJ_MESSAGE_ACTION user_id=%s payload=%s action=CREATE "
        "chat_id=%s message_id=%s reason=%s",
        user_id, (payload or "-")[:40], chat_id, new_mid,
        "fresh_start" if not edit_message_id else "edit_unavailable",
    )
    return new_mid



async def _fj_link_cache_ttl() -> float:
    """Health-cache TTL from settings (default 300s; spec §18)."""
    try:
        return float(await db.get_setting_int("fj_link_health_cache_ttl", 300))
    except Exception:  # noqa: BLE001
        return 300.0



async def _fj_check_link_health(bot, channel_id: int, *,
                                force: bool = False
                                ) -> _fj_health.LinkHealthResult:
    """Combined channel+link health for one force-join channel (cached).

    Cache semantics (spec §18): entries live for the configured TTL and are
    invalidated explicitly on admin link change / rotation / join-request
    events / Telegram API errors / the manual Test button. `force=True`
    bypasses the cache (Test button, startup pass, admin refresh).
    """
    _FJ_LINK_HEALTH_CACHE.ttl = await _fj_link_cache_ttl()
    if not force:
        cached = _FJ_LINK_HEALTH_CACHE.get(channel_id)
        if cached is not None:
            return _fj_health.LinkHealthResult(
                state=cached.state, detail=cached.detail,
                expires_at=cached.expires_at, verified_at=_now_iso())
    # Channel access first (tri-state, PHASE 6 §9 semantics unchanged).
    access = await classify_channel_access(bot, channel_id)
    if access == ChannelAccessStatus.INVALID_NOT_FOUND:
        result = _fj_health.LinkHealthResult(
            _fj_health.CHANNEL_INVALID, "chat not found", verified_at=_now_iso())
    elif access == ChannelAccessStatus.INVALID_FORBIDDEN:
        result = _fj_health.LinkHealthResult(
            _fj_health.CHANNEL_INVALID, "bot removed / no access",
            verified_at=_now_iso())
    elif access == ChannelAccessStatus.INVALID_BAD_REQUEST:
        result = _fj_health.LinkHealthResult(
            _fj_health.CHANNEL_INVALID, "bad request", verified_at=_now_iso())
    elif access in (ChannelAccessStatus.TRANSIENT_ERROR, ChannelAccessStatus.UNKNOWN):
        # Transient channel-level failure — the LINK is not concluded dead;
        # a stored t.me link keeps working for users regardless of bot access.
        stored = await db.get_force_invite_link(channel_id)
        if stored:
            result = _fj_health.LinkHealthResult(
                _fj_health.TEMPORARY_ERROR,
                f"channel unverified ({access.value}) — stored link KEPT",
                verified_at=_now_iso())
        else:
            result = _fj_health.LinkHealthResult(
                _fj_health.TEMPORARY_ERROR, f"channel unverified ({access.value})",
                verified_at=_now_iso())
    else:
        # Channel OK — verify the LINK itself (the piece the old code never
        # checked: expired / revoked / wrong-chat links).
        # B18: the link PROVENANCE (schema v39) distinguishes bot-created
        # links (provably valid until our own rotation revokes them) from
        # admin-supplied custom ones (trusted — the Bot API has NO
        # getChatInviteLink to introspect invite hashes; bot-19.log's
        # "bot API lacks get_chat_invite_link" every-channel-temporary
        # loop is gone).
        stored = await db.get_force_invite_link(channel_id)
        provenance = None
        try:
            ch_row = await db.get_force_channel(channel_id)
            if ch_row is not None and "link_provenance" in ch_row.keys():
                provenance = ch_row["link_provenance"]
        except Exception:  # noqa: BLE001 — provenance is best-effort
            provenance = None
        result = await _fj_health.verify_invite_link(
            bot, channel_id, stored, channel_accessible=True,
            link_provenance=provenance)
    _FJ_LINK_HEALTH_CACHE.store(
        channel_id, result.state, expires_at=result.expires_at,
        detail=result.detail)
    # Persist state changes (v28 columns) — best-effort, never fatal.
    try:
        prev = None
        row = await db.get_force_channel(channel_id)
        if row is not None:
            prev = _safe_row_get(row, "link_health")
        if prev != result.state:
            logger.info("FORCE_JOIN_LINK_HEALTH channel_id=%s state=%s "
                        "prev=%s detail=%s", channel_id, result.state,
                        prev or "-", result.detail[:80])
            await db.set_force_link_health(
                channel_id, result.state, expires_at=result.expires_at,
                error=result.detail if result.is_dead_link else None,
                link_type=_fj_health.link_syntax_kind(
                    await db.get_force_invite_link(channel_id)))
    except Exception as e:  # noqa: BLE001 — health persistence is best-effort
        logger.debug("FORCE_JOIN_LINK_HEALTH_PERSIST_FAILED channel_id=%s: %s",
                     channel_id, e)
    return result



async def _fj_auto_repair_link(bot, channel_id: int,
                               health: "_fj_health.LinkHealthResult"
                               ) -> Optional[str]:
    """PHASE 8 (§14): auto-repair a confirmed-dead invite link.

    Only runs when the policy allows it (fj_link_auto_rotate, default ON) and
    only for Telegram-CONFIRMED dead links — a transient error NEVER triggers
    rotation. The rotation itself is transactional (rotate_force_join_invite_
    link: create -> verify -> atomic store -> revoke old), so a failure
    leaves the previous state untouched. Returns the new working link or
    None (caller then renders the friendly 'temporarily unavailable' state).
    """
    if not health.is_dead_link:
        return None
    try:
        enabled = await db.get_setting_bool("fj_link_auto_rotate", True)
    except Exception:  # noqa: BLE001
        enabled = True
    if not enabled:
        logger.info("FORCE_JOIN_LINK_AUTO_REPAIR channel_id=%s skipped "
                    "reason=policy_disabled", channel_id)
        return None
    logger.info("FORCE_JOIN_LINK_AUTO_REPAIR channel_id=%s reason=%s",
                channel_id, health.state)
    ok, _msg = await rotate_force_join_invite_link(bot, channel_id)
    _FJ_LINK_HEALTH_CACHE.invalidate(channel_id)
    if ok:
        new_link = await db.get_force_invite_link(channel_id)
        await db.set_force_link_health(channel_id, _fj_health.LINK_HEALTHY,
                                        link_type="invite")
        return new_link
    return None



async def _get_or_create_invite_link(bot, channel_id: int) -> Optional[str]:
    """Issue #47 + PHASE 6 §9 + PHASE 8 (§14/§17): get a WORKING invite link.

    The PHASE 8 upgrade: the stored link itself is now HEALTH-CHECKED
    (cached, app/core/fj_link_health.py) — the old code only verified the
    CHANNEL, so an expired/revoked link kept producing dead Join buttons for
    users. Flow:

    1. Health-check the channel + stored link (TTL cache).
    2. HEALTHY / UNVERIFIABLE (public) / TEMPORARY — reuse the stored link
       (a transient Telegram error NEVER destroys a working configuration).
    3. Telegram-CONFIRMED dead link (expired / revoked / invalid) — attempt
       AUTO-REPAIR (policy fj_link_auto_rotate): create a new link, store it
       atomically, revoke the old bot-created one. A repair failure returns
       None so the user UI renders the friendly 'temporarily unavailable'
       state instead of a dead Join button (spec §17).
    4. Confirmed CHANNEL_INVALID — clear the stored link (unchanged v6
       semantics) and return None.
    5. No stored link — create ONE new link and store it.

    This eliminates the create/revoke/create/revoke loop AND the
    transient-error link destruction AND the dead-link Join buttons.
    """
    health = await _fj_check_link_health(bot, channel_id)
    stored = await db.get_force_invite_link(channel_id)

    if health.state == _fj_health.CHANNEL_INVALID:
        # Confirmed channel invalid — clear stored link (v6 semantics kept).
        await db.clear_force_invite_link(channel_id)
        _FJ_LINK_HEALTH_CACHE.invalidate(channel_id)
        return None

    if stored:
        if health.state in (_fj_health.LINK_HEALTHY, _fj_health.UNVERIFIABLE,
                            _fj_health.TEMPORARY_ERROR):
            # Usable (or unverifiable-permanent, or temporarily unverified —
            # a stored t.me link keeps working for users regardless).
            if health.state != _fj_health.TEMPORARY_ERROR:
                await db.verify_force_invite_link(channel_id)
            return stored
        # Telegram-CONFIRMED dead link — try the transactional auto-repair.
        repaired = await _fj_auto_repair_link(bot, channel_id, health)
        if repaired:
            return repaired
        # Repair impossible (bot lacks rights / policy off / Telegram
        # refused): return None — the user UI shows the friendly unavailable
        # state, never a dead Join button.
        return None

    # No stored link — create ONE new link and store it (B18: with
    # provenance='bot_created' — provably valid until our own rotation
    # revokes it; the NO_LINK state of a freshly re-added channel row
    # self-heals HERE, exactly the bot-19.log remove/re-add sequence).
    try:
        link = await bot.export_chat_invite_link(channel_id)
        if link:
            await db.set_force_invite_link(channel_id, link,
                                           provenance="bot_created")
            _FJ_LINK_HEALTH_CACHE.invalidate(channel_id)
            await db.set_force_link_health(channel_id, _fj_health.LINK_HEALTHY,
                                            link_type=_fj_health.link_syntax_kind(link))
            logger.info("ForceJoin: created persistent invite link for channel %s", channel_id)
        return link
    except RetryAfter as e:
        logger.warning("ForceJoin: invite link creation for %s hit flood control "
                       "(retry in %ss) — nothing changed",
                       channel_id, getattr(e, "retry_after", "?"))
        return None
    except BadRequest as e:
        if "not found" in str(e).lower():
            logger.warning("ForceJoin: channel %s invalid, cannot create invite link", channel_id)
            return None
        logger.warning("ForceJoin: export invite link failed for %s: %s", channel_id, e)
        return None
    except Forbidden:
        logger.warning("ForceJoin: bot is not admin in %s, cannot create invite link", channel_id)
        return None
    except (NetworkError, TimedOut) as e:
        logger.warning("ForceJoin: invite link creation for %s hit a transient "
                       "error (%s) — nothing changed", channel_id, type(e).__name__)
        return None
    except TelegramError as e:
        logger.warning("ForceJoin: invite link creation failed for %s: %s", channel_id, e)
        return None



# ============================================================
# ISSUE 7: ChatJoinRequest handler (Request-to-Join channels)
# ============================================================
async def on_chat_join_request(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle ChatJoinRequest updates from Request-to-Join channels.

    Issue 7: stores the (user_id, channel_id) pair in memory so the verify
    callback can grant access (policy=request) or show a pending message
    (policy=approval). Does NOT auto-approve — the bot never calls
    approve_chat_join_request().

    PHASE 6 §10: after storing the request, the user's tracked force-join
    dashboard message is refreshed IN PLACE (edit) so they immediately see
    "Join request submitted — waiting for approval" instead of being
    repeatedly told to Join. Best-effort (guarded); a failure never breaks
    the handler.
    """
    cjr = update.chat_join_request
    if not cjr:
        return
    user = cjr.from_user
    chat = cjr.chat
    if not user or not chat:
        return
    # Only track requests for channels that are configured as force-join channels.
    force_channels = await db.list_force_channels()
    force_cids = {int(ch["channel_id"]) for ch in force_channels}
    if int(chat.id) not in force_cids:
        return  # not a force-join channel, ignore
    _store_join_request(user.id, chat.id)
    logger.info("JoinRequest received: user=%s channel=%s (%s)",
                user.id, chat.id, chat.title or chat.username or "")
    # PHASE 6 §10: refresh the user's existing FJ dashboard in place so the
    # pending-request state is visible immediately (never a duplicate send:
    # send_force_join_page EDITS the tracked message when it exists).
    try:
        tracked_mid = _fj_user_msg_get(int(user.id), int(user.id))
        if tracked_mid:
            asyncio.get_event_loop().create_task(
                send_force_join_page(context.bot, int(user.id), int(user.id),
                                     "", edit_message_id=tracked_mid,
                                     trace_id="joinreq_refresh"))
            logger.info("BOT6_FJ_JOINREQ_REFRESH user_id=%s channel=%s "
                        "message_id=%s (pending state now visible)",
                        user.id, chat.id, tracked_mid)
    except Exception:  # noqa: BLE001 — dashboard refresh is best-effort
        logger.debug("JoinRequest dashboard refresh failed (non-fatal).",
                     exc_info=True)



# ---------- FORCE JOIN PANEL (Issue 25: fully GUI-driven) ----------
def _fj_channel_type_label(ch: aiosqlite.Row) -> str:
    """Public if it has a @username, Private otherwise.

    Issue 37: safe access — uses _safe_row_get to avoid IndexError on
    missing columns."""
    name = _safe_row_get(ch, "channel_name") or ""
    return "Public" if name.startswith("@") else "Private"



async def _fj_schedule_timeout(update: Update, context: ContextTypes.DEFAULT_TYPE,
                               state_key: str) -> None:
    """Issue 25: auto-cancel a force-join wizard after 5 minutes of inactivity."""
    await asyncio.sleep(FORCE_JOIN_WIZARD_TIMEOUT)
    if context.user_data.get(state_key):
        context.user_data.pop(state_key, None)
        try:
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "Force-Join wizard cancelled (5 minute timeout).",
            )
        except Exception:  # noqa: BLE001
            pass



async def _fj_resolve_input(bot, raw_text: str, forwarded_msg: Optional[Message]) -> Tuple[Optional[int], Optional[str], Optional[str]]:
    """BOT6: resolve admin input to (channel_id, username, title).

    Accepts:
      • numeric channel id (e.g. -1001234567890)
      • @username
      • https://t.me/channelusername
      • https://t.me/+invite_link
      • https://t.me/c/1234567890
      • a forwarded channel post (extracts the origin chat)
    Returns (channel_id, username_or_None, title_or_None). On failure returns
    (None, None, None).
    """
    # Method 3: forwarded channel post.
    if forwarded_msg is not None:
        # Try forward_origin first.
        ch_id, _ = extract_forward_origin(forwarded_msg)
        if ch_id:
            title = None
            try:
                chat = await bot.get_chat(ch_id)
                title = getattr(chat, "title", None)
                uname = getattr(chat, "username", None)
                if uname:
                    return ch_id, "@" + uname, title
            except TelegramError:
                pass
            return ch_id, None, title
        # Fallback: try forward_from_chat.
        ffc = getattr(forwarded_msg, "forward_from_chat", None)
        if ffc:
            ch_id = getattr(ffc, "id", None)
            if ch_id:
                title = getattr(ffc, "title", None)
                uname = getattr(ffc, "username", None)
                return ch_id, ("@" + uname if uname else None), title

    text = (raw_text or "").strip()
    if not text:
        return None, None, None

    # BOT5 FIX + B18: handle https://t.me/ URLs (and the telegram.me /
    # telegram.dog mirrors + bare t.me/… forms that all normalize to the
    # same thing).
    _low = text.lower()
    _tme_hosts = ("t.me", "telegram.me", "telegram.dog")
    _is_tme = any(_low.startswith(p) for p in (
        "https://t.me/", "http://t.me/", "t.me/",
        "https://telegram.me/", "http://telegram.me/", "telegram.me/",
        "https://telegram.dog/", "http://telegram.dog/", "telegram.dog/"))
    if _is_tme:
        _body = text.split("://", 1)[-1] if "://" in text else text
        _host = _body.split("/", 1)[0].lower()
        _host = _host[4:] if _host.startswith("www.") else _host
        path = _body.split("/", 1)[1] if "/" in _body else ""
        path = path.strip("/")
        if "/" in path:
            path = path.split("/", 1)[0]
        if not path:
            return None, None, None
        if path.startswith("+"):
            try:
                chat = await bot.get_chat(text)
                if chat:
                    uname = getattr(chat, "username", None)
                    return chat.id, ("@" + uname if uname else None), getattr(chat, "title", None)
            except TelegramError:
                return None, None, None
            return None, None, None
        if path.startswith("c/"):
            cid_str = path[2:].split("/")[0]
            try:
                cid = int("-100" + cid_str)
                try:
                    chat = await bot.get_chat(cid)
                    uname = getattr(chat, "username", None)
                    return cid, ("@" + uname if uname else None), getattr(chat, "title", None)
                except TelegramError:
                    pass
                return cid, None, None
            except ValueError:
                return None, None, None
        text = "@" + path

    # Method 2: @username.
    if text.startswith("@"):
        uname = text.lstrip("@")
        try:
            chat = await bot.get_chat("@" + uname)
            if chat:
                return chat.id, "@" + uname, getattr(chat, "title", None)
        except TelegramError:
            return None, None, None
        return None, None, None

    # Method 1: numeric channel id.
    try:
        cid = int(text)
        title = None
        try:
            chat = await bot.get_chat(cid)
            title = getattr(chat, "title", None)
            uname = getattr(chat, "username", None)
            if uname:
                return cid, "@" + uname, title
        except TelegramError:
            pass
        return cid, None, title
    except ValueError:
        return None, None, None



async def _fj_dashboard_render_async(bot=None) -> Tuple[str, InlineKeyboardMarkup]:
    """BOT6 + PHASE 6 §15 + PHASE 8 (§16): FJ dashboard — status, mode/batch
    info, and a HEALTH SUMMARY per channel (channel + LINK health, cached).

    When `bot` is supplied, each channel gets the combined channel+link
    health classification (a Telegram rate limit is 'Temporary', NEVER
    'Needs attention' / invalid; an expired/revoked LINK is shown as its own
    state — the channel may be perfectly healthy). When bot is None, the
    persisted link_health column (v28) is displayed instead (safe
    display-only fallback).
    """
    channels = await db.list_force_channels()
    mode = await get_fj_mode()
    batch_size = await get_fj_batch_size()
    mode_labels = {
        FJ_MODE_SHOW_ALL: "\U0001F7E2 Show All",
        FJ_MODE_PROGRESSIVE_RANDOM: "\U0001F535 Progressive Random",
        FJ_MODE_FIXED_ORDER: "\U0001F7E3 Fixed Order",
    }
    mode_label = mode_labels.get(mode, mode)
    # PHASE 6 §15 + PHASE 8 §16: per-channel health (cached — no per-render
    # Telegram hammering; the spec §18 health cache applies here too).
    healthy = 0
    attention = 0
    unverified = 0
    dead_links = 0
    invalid = 0
    permission = 0
    health_lines = ""
    if channels:
        for ch in channels:
            cid = _safe_row_get(ch, "channel_id")
            state = None
            if bot is not None and cid is not None:
                result = await _fj_check_link_health(bot, int(cid))
                state = result.state
            else:
                state = _safe_row_get(ch, "link_health") or None
            if state == _fj_health.LINK_HEALTHY:
                healthy += 1
            elif state in (_fj_health.LINK_EXPIRED, _fj_health.LINK_REVOKED,
                           _fj_health.LINK_INVALID):
                attention += 1
                dead_links += 1
            elif state == _fj_health.CHANNEL_INVALID:
                invalid += 1
            elif state == _fj_health.BOT_PERMISSION:
                permission += 1
            elif state == _fj_health.UNVERIFIABLE:
                healthy += 1  # public permanent link — fine by definition
            else:
                unverified += 1
        # B17 FINAL VERIFICATION: the admin health quadruple 🟢🟡🔴🟠 —
        # 🟢 Healthy, 🟡 Needs attention (expired/revoked/invalid LINK —
        # replaceable), 🔴 Invalid (the CHANNEL itself is dead),
        # 🟠 Bot permission (the bot's own rights problem), plus the
        # ⚠️ Unverified (temporary/rate-limited) line.
        health_lines = (
            f"\U0001F7E2 Healthy: {healthy}\n"
            f"\U0001F7E1 Needs attention: {attention}"
            + (f" ({dead_links} link problem(s))" if dead_links else "") + "\n"
            f"\U0001F534 Invalid: {invalid}\n"
            f"\U0001F7E0 Bot permission: {permission}\n"
        )
        if unverified:
            health_lines += f"\u26A0\uFE0F Unverified (rate limit): {unverified}\n"
        health_lines += "\n"
    batch_applicable = mode != FJ_MODE_SHOW_ALL
    batch_text = f"{batch_size}" if batch_applicable else "N/A (Show All)"
    text = (
        f"\U0001F4E2 FORCE JOIN\n\n"
        f"\u26A1 Status: ENABLED\n"
        f"\U0001F4E1 Channels: {len(channels)}\n"
        f"{health_lines}"
        f"\U0001F3AF Mode: {mode_label}\n"
        f"\U0001F4E6 Batch Size: {batch_text}\n\n"
        f"\U0001F9E9 BATCH BEHAVIOR\n"
        f"\u2022 Mode: {mode_label}\n"
        f"\u2022 Batch size: {batch_text}\n"
        f"\u2022 Order: {'Randomized' if mode == FJ_MODE_PROGRESSIVE_RANDOM else 'Fixed' if mode == FJ_MODE_FIXED_ORDER else 'All channels'}\n"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u2795 Add Channel", callback_data="fj:add"),
         InlineKeyboardButton("\U0001F4CB Manage Channels", callback_data="fj:list")],
        [InlineKeyboardButton("\u2699\uFE0F Verification Rules", callback_data="fj:mode"),
         InlineKeyboardButton("\U0001F4E6 Batch Size", callback_data="fj:batch")],
        [InlineKeyboardButton("\U0001F4CA Status", callback_data="panel:fj"),
         InlineKeyboardButton("\U0001F504 Refresh", callback_data="panel:fj")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:settings")],
    ])
    return text, kb



async def fj_dashboard_record(admin_chat_id: int, message_id: int) -> None:
    """Record/refresh the canonical FJ dashboard message_id for an admin chat."""
    await db.set_fj_dashboard(admin_chat_id, message_id)
    logger.info("BOT6_FJ_DASHBOARD action=RECORD chat_id=%s message_id=%s",
                admin_chat_id, message_id)



async def fj_dashboard_refresh(bot, admin_chat_id: int) -> None:
    """Re-render the canonical FJ dashboard into its persisted message.

    Called after any FJ config change (add / remove / edit channel, change
    mode / batch / policy) so the dashboard the admin is looking at reflects
    the new state. LOADs dashboard_message_id -> EDITs it. If Telegram
    confirms the old message no longer exists (MessageNotModified /
    message-not-found), the row is cleared so the next fj_panel() call
    re-creates it.
    """
    row = await db.get_fj_dashboard(admin_chat_id)
    if not row:
        return  # no persisted dashboard to refresh
    message_id = int(row["dashboard_message_id"])
    # PHASE 6 §15: pass the live bot so the health summary is real.
    text, kb = await _fj_dashboard_render_async(bot=bot)
    try:
        await bot.edit_message_text(text, chat_id=admin_chat_id, message_id=message_id,
                                    reply_markup=kb)
        logger.info("BOT6_FJ_DASHBOARD action=EDIT chat_id=%s message_id=%s reason=refresh",
                    admin_chat_id, message_id)
    except TelegramError as e:
        err = str(e).lower()
        if "not modified" in err:
            logger.info("BOT6_FJ_DASHBOARD action=EDIT chat_id=%s message_id=%s reason=no_change",
                        admin_chat_id, message_id)
        elif "not found" in err or "message to edit not found" in err:
            # Old message no longer exists — clear so next fj_panel recreates.
            await db.clear_fj_dashboard(admin_chat_id)
            logger.warning("BOT6_FJ_DASHBOARD action=RECREATE_NEEDED chat_id=%s "
                           "message_id=%s reason=gone", admin_chat_id, message_id)
        else:
            logger.warning("BOT6_FJ_DASHBOARD action=EDIT_FAILED chat_id=%s message_id=%s "
                           "error=%s", admin_chat_id, message_id, e)



async def fj_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """BOT6 Force-Join dashboard — ONE persistent message per admin chat.

    Edits the current callback message in place (so the same message_id is
    reused across navigation), then RECORDS that message_id as the canonical
    FJ dashboard for this admin chat. Subsequent config changes call
    fj_dashboard_refresh() which edits this exact message. Only recreated
    if Telegram confirms the old message no longer exists.
    """
    text, kb = await _fj_dashboard_render_async(bot=context.bot)
    await safe_edit_text(update.callback_query, text, reply_markup=kb)
    # Record the canonical dashboard message_id for later refresh.
    q = update.callback_query
    if q and q.message and q.message.message_id:
        chat_id = q.message.chat_id
        try:
            await fj_dashboard_record(chat_id, q.message.message_id)
        except Exception:  # noqa: BLE001
            logger.debug("BOT6_FJ_DASHBOARD record failed (non-fatal).", exc_info=True)



async def fj_mode_selector_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """BOT6 explicit mode selector — shows all 3 modes with the active one marked."""
    cur_mode = await get_fj_mode()
    modes_info = [
        (FJ_MODE_SHOW_ALL, "\U0001F7E2 Show All", "All configured channels are shown together."),
        (FJ_MODE_PROGRESSIVE_RANDOM, "\U0001F535 Progressive Random", "Users receive channels in randomized batches."),
        (FJ_MODE_FIXED_ORDER, "\U0001F7E3 Fixed Order", "Users receive channels in configured order."),
    ]
    lines = ["\U0001F3AF FORCE-JOIN MODE", "", "Choose how channels are presented to users:", ""]
    for mode, label, desc in modes_info:
        active = "\u2705 Active" if mode == cur_mode else ""
        lines.append(f"{label} {active}")
        lines.append(f"  {desc}")
        lines.append("")
    text = "\n".join(lines)
    kb_rows: List[List[InlineKeyboardButton]] = []
    for mode, label, desc in modes_info:
        mark = "\u2705 " if mode == cur_mode else ""
        kb_rows.append([InlineKeyboardButton(f"{mark}{label}",
                                             callback_data=f"fjsetmode::{mode}")])
    kb_rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:fj")])
    await safe_edit_text(update.callback_query, text, reply_markup=InlineKeyboardMarkup(kb_rows))



async def fj_list_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Issue 25/37: list force-join channels with Name / Username / Status.

    Issue 37: shows ❌ Invalid Channel for channels the bot cannot access.
    Uses safe row access everywhere — never crashes on missing columns.
    """
    channels = await db.list_force_channels()
    if not channels:
        await safe_edit_text(
            update.callback_query,
            "\U0001F4CB Force-Join Channels\n\nNone configured.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2795 Add Channel", callback_data="fj:add")],
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:fj")],
            ]),
        )
        return
    # Issue 37 + PHASE 6 §9 + PHASE 8 §16: per-channel health uses the
    # combined channel+LINK health service (cached) — the row shows the
    # channel state AND the link state (an expired link is NOT 'channel
    # invalid'; a rate limit is NOT either).
    bot = context.bot
    health_states: Dict[int, str] = {}
    for ch in channels:
        cid = _safe_row_get(ch, "channel_id")
        result = await _fj_check_link_health(bot, int(cid))
        health_states[cid] = result.state
    lines = ["\U0001F4CB Force-Join Channels", ""]
    for ch in channels:
        cid = _safe_row_get(ch, "channel_id")
        name = _force_channel_label(ch)
        uname = _safe_row_get(ch, "channel_name") or "-"
        ctype = _fj_channel_type_label(ch)
        state = health_states.get(cid, "")
        status_icon = _fj_health.health_badge(state)
        lines.append(f"\u2022 {name}\n  Username: {uname}  |  Type: {ctype}\n  {status_icon}")
    if any(s in (_fj_health.LINK_EXPIRED, _fj_health.LINK_REVOKED,
                 _fj_health.LINK_INVALID) for s in health_states.values()):
        lines.append("\n\u26A0\uFE0F One or more join LINKS are expired/revoked/invalid. "
                     "Open the channel \u2192 Change Join Link \u2192 Auto Change Link.")
    if any(s == _fj_health.CHANNEL_INVALID for s in health_states.values()):
        lines.append("\n\u274C One or more channels are invalid. The bot cannot access them.")
    if any(s == _fj_health.TEMPORARY_ERROR for s in health_states.values()):
        lines.append("\n\u26A0\uFE0F Some channels could not be verified right now "
                     "(Telegram rate limit).\nThey were NOT marked invalid — re-check later.")
    buttons: List[List[InlineKeyboardButton]] = []
    for ch in channels:
        cid = _safe_row_get(ch, "channel_id")
        name = _force_channel_label(ch)
        # WS-C callback-integrity fix (spec §5): the pre-PHASE-8 panel read a
        # ``valid_flags`` dict that NO LONGER EXISTS anywhere — a NameError
        # that crashed fj:list the moment any channel was configured (the
        # same at-render crash class as the production _svc_make_control_ui
        # incident). The per-button prefix now derives from the SAME combined
        # channel+link health computed for the rows above: ❌ channel invalid,
        # ⚠️ temporarily unverifiable, ✏️ otherwise.
        state = health_states.get(cid, _fj_health.NO_LINK)
        if state == _fj_health.CHANNEL_INVALID:
            prefix = "\u274C"
        elif state == _fj_health.TEMPORARY_ERROR:
            prefix = "\u26A0\uFE0F"
        else:
            prefix = "\u270F\uFE0F"
        buttons.append([
            InlineKeyboardButton(f"{prefix} {name}", callback_data=f"fjedit:{cid}"),
            InlineKeyboardButton("\u274C", callback_data=f"fjrem:{cid}"),
        ])
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:fj")])
    await safe_edit_text(update.callback_query, "\n".join(lines),
                         reply_markup=InlineKeyboardMarkup(buttons))



async def fj_edit_pick_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Issue 25: pick a channel to edit."""
    channels = await db.list_force_channels()
    if not channels:
        await safe_edit_text(
            update.callback_query,
            "\u270F\uFE0F Edit Channel\n\nNone configured.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:fj")],
            ]),
        )
        return
    buttons = [[InlineKeyboardButton(_force_channel_label(ch),
                                     callback_data=f"fjedit:{ch['channel_id']}")]
               for ch in channels]
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:fj")])
    await safe_edit_text(update.callback_query, "\u270F\uFE0F Edit Channel\n\nSelect a channel:",
                         reply_markup=InlineKeyboardMarkup(buttons))



async def fj_remove_pick_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Issue 25: pick a channel to remove (shows list, then confirm)."""
    channels = await db.list_force_channels()
    if not channels:
        await safe_edit_text(
            update.callback_query,
            "\U0001F5D1 Remove Channel\n\nNone configured.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:fj")],
            ]),
        )
        return
    buttons = [[InlineKeyboardButton(f"\u274C {_force_channel_label(ch)}",
                                     callback_data=f"fjrem:{ch['channel_id']}")]
               for ch in channels]
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:fj")])
    await safe_edit_text(update.callback_query, "\U0001F5D1 Remove Channel\n\nSelect a channel:",
                         reply_markup=InlineKeyboardMarkup(buttons))



async def fj_detail_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                          channel_id: int) -> None:
    """Issue #63 + PHASE 6 §12/§15/§16: Force Join channel detail.

    Shows: channel info, join text, verify button text, channel button text,
    media status, invite link status (three-state — a transient Telegram
    error is NEVER 'Invalid'), plus:
      [🔗 Change Join Link] — Set Custom Link / Auto Change Link (§12)
      [🧪 Test Channel]     — full diagnostic (§16)
    """
    ch = await db.get_force_channel(channel_id)
    if not ch:
        await safe_answer_callback(update.callback_query, "Channel not found.", show_alert=True)
        return
    name = _force_channel_label(ch)
    uname = _safe_row_get(ch, "channel_name") or "-"
    ctype = _fj_channel_type_label(ch)
    join_text = _safe_row_get(ch, "join_text") or "(default)"
    verify_text = _safe_row_get(ch, "verify_button_text") or "(default)"
    channel_text = _safe_row_get(ch, "channel_button_text") or "(default)"
    media_fid = _safe_row_get(ch, "media_file_id")
    media_type = _safe_row_get(ch, "media_type")
    media_label = f"{media_type}" if media_fid else "None"
    invite_link = _safe_row_get(ch, "invite_link") or "Not created"
    # PHASE 6 §9: three-state validity — flood control is NOT 'Invalid'.
    valid = await _check_force_channel_valid(context.bot, channel_id)
    status_line = _channel_validity_label(valid)
    # Public/private detection (§14): a public username channel cannot use
    # automatic invite rotation.
    is_public = False
    if uname and str(uname).lstrip("@").strip():
        is_public = True
    _member_check_icon = "\u2705" if valid is not False else "\u274C"
    _joinreq_label = "Public channel" if is_public else "Auto-detect"
    text = (
        f"\U0001F4E2 {name}\n\n"
        f"Username: {uname}\n"
        f"Type: {ctype}\n"
        f"Status: {status_line}\n"
        f"Membership check: {_member_check_icon}\n"
        f"Join requests: {_joinreq_label}\n\n"
        f"\U0001F4DD Join Text: {join_text[:50]}\n"
        f"\u2705 Verify Button: {verify_text[:30]}\n"
        f"\U0001F4E2 Channel Button: {channel_text[:30]}\n"
        f"\U0001F5BC Media: {media_label}\n"
        f"\U0001F517 Invite: {'Cached' if invite_link != 'Not created' else 'Not created'}"
    )
    kb_rows: List[List[InlineKeyboardButton]] = [
        [InlineKeyboardButton("\U0001F517 Change Join Link", callback_data=f"fjlink:{channel_id}"),
         InlineKeyboardButton("\U0001F9EA Test Channel", callback_data=f"fjtest:{channel_id}")],
        [InlineKeyboardButton("\u270F\uFE0F Edit Name", callback_data=f"fjeditname:{channel_id}")],
        [InlineKeyboardButton("\u270F\uFE0F Edit Join Text", callback_data=f"fjeditjoin:{channel_id}"),
         InlineKeyboardButton("\u270F\uFE0F Edit Verify Button", callback_data=f"fjeditverify:{channel_id}")],
        [InlineKeyboardButton("\u270F\uFE0F Edit Channel Button", callback_data=f"fjeditchanbtn:{channel_id}")],
        [InlineKeyboardButton("\U0001F5BC Set Media", callback_data=f"fjsetmedia:{channel_id}"),
         InlineKeyboardButton("\U0001F5D1 Remove Media", callback_data=f"fjdelmedia:{channel_id}")],
        [InlineKeyboardButton("\U0001F441 Preview Force Join", callback_data=f"fjpreview:{channel_id}")],
    ]
    if valid is not True:
        kb_rows.append([InlineKeyboardButton("\U0001F501 Revalidate",
                                              callback_data=f"fjrevalidate:{channel_id}")])
    kb_rows.append([InlineKeyboardButton("\U0001F5D1 Remove Channel", callback_data=f"fjrem:{channel_id}")])
    kb_rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="fj:list")])
    await safe_edit_text(update.callback_query, text, reply_markup=InlineKeyboardMarkup(kb_rows))



# ============================================================
# BOTV13 PHASE 6 (§12-§14): FORCE-JOIN JOIN-LINK MANAGEMENT
# ============================================================
def _fj_invite_prefix(link: Optional[str]) -> str:
    """§21 log hygiene: never log full invite URLs — prefix only."""
    if not link or not isinstance(link, str):
        return "-"
    # Show scheme+host and the first 6 chars of the path — enough to
    # identify the link class (t.me/..., t.me/joinchat/..., t.me/+...).
    try:
        from urllib.parse import urlparse
        p = urlparse(link)
        path = (p.path or "/").lstrip("/")[:6]
        return f"{p.netloc}/{path}…"
    except Exception:  # noqa: BLE001
        return link[:12] + "…"



async def _fj_channel_is_public(bot, channel_id: int) -> bool:
    """§14: is this a public (username) channel? Auto invite rotation is not
    applicable to public channels — their t.me/<username> link is permanent."""
    try:
        chat = await bot.get_chat(channel_id)
        return bool(getattr(chat, "username", None))
    except TelegramError:
        # Cannot verify — assume NOT public so rotation can still attempt
        # (create_chat_invite_link will fail honestly if unsupported).
        return False



def _fj_validate_custom_link(text: str) -> Tuple[Optional[str], Optional[str]]:
    """Validate an admin-supplied custom join link. B18 accepts the FULL
    Telegram join-link vocabulary (normalized to the canonical
    https://t.me/… form):
      https://t.me/<username> | https://t.me/joinchat/<hash> |
      https://t.me/+<hash>   | http/https/bare-domain variants |
      telegram.me / telegram.dog mirrors | tg://join?invite=<hash> |
      tg://resolve?domain=<username>     | @<username>
    Returns (normalized, None) or (None, error)."""
    t = (text or "").strip()
    if not t:
        return None, "The link is empty."
    canonical, _kind = _fj_health.normalize_join_link(t)
    if canonical is None:
        return None, ("Send a Telegram invite link (https://t.me/joinchat/…, "
                      "https://t.me/+…, https://t.me/<username>, a tg:// "
                      "deep link, or @<username>).")
    return canonical, None



async def fj_link_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                        channel_id: int) -> None:
    """§12 + PHASE 8 (§16): Change Join Link — with the LIVE link-health
    state (channel + link verified) so the admin immediately understands the
    row: Healthy / Link Expired / Link Revoked / Link Invalid / Temporary."""
    ch = await db.get_force_channel(channel_id)
    if not ch:
        await safe_answer_callback(update.callback_query, "Channel not found.", show_alert=True)
        return
    name = _force_channel_label(ch)
    stored = await db.get_force_invite_link(channel_id)
    link_line = _fj_invite_prefix(stored) if stored else "(none stored)"
    uname = _safe_row_get(ch, "channel_name") or "-"
    is_public = bool(uname and str(uname).lstrip("@").strip())
    # PHASE 8: fresh combined health (force — this is an explicit admin view).
    health = await _fj_check_link_health(context.bot, int(channel_id), force=True)
    badge = _fj_health.health_badge(health.state)
    health_line = f"Link health: {badge}"
    if health.expires_at:
        health_line += f" (expires {str(health.expires_at)[:19]})"
    if health.detail:
        health_line += f"\nDetail: {health.detail[:120]}"
    validation = _safe_row_get(ch, "link_validation_status")
    if validation:
        health_line += f"\nCustom-link validation: {validation}"
    text = (
        f"\U0001F517 Change Join Link — {name}\n\n"
        f"Current link: {link_line}\n"
        f"{health_line}\n\n"
        "\U0001F517 Set Custom Link — paste your own invite\n"
        "  link (t.me/joinchat/…, t.me/+…, or t.me/<username>).\n"
        "  Verified against this channel where Telegram permits.\n\n"
        "\U0001F504 Auto Change Link — the bot creates a NEW\n"
        "  invite link, verifies it, stores it atomically, and\n"
        "  only then revokes the old bot-created link\n"
        "  (transactional — a failure never destroys the\n"
        "  working link)."
    )
    if is_public:
        text += ("\n\n\u26A0\uFE0F This looks like a public channel (has a "
                 "@username).\nAutomatic rotation isn't available for it — its "
                 "t.me link is\npermanent. Use Set Custom Link if you want a "
                 "specific link.")
    rows: List[List[InlineKeyboardButton]] = [
        [InlineKeyboardButton("\U0001F517 Set Custom Link",
                              callback_data=f"fjlinkcustom:{channel_id}")],
    ]
    if health.is_dead_link:
        # §16: the primary action for a dead link is generating a new one.
        rows.insert(0, [InlineKeyboardButton("\u267B\uFE0F Generate New Link (link is dead)",
                                             callback_data=f"fjlinkauto:{channel_id}")])
    else:
        rows.append([InlineKeyboardButton("\U0001F504 Auto Change Link",
                                          callback_data=f"fjlinkauto:{channel_id}")])
    rows.append([InlineKeyboardButton("\U0001F9EA Test Channel",
                                      callback_data=f"fjtest:{channel_id}")])
    rows.append([InlineKeyboardButton("\u2B05\uFE0F Back",
                                      callback_data=f"fjedit:{channel_id}")])
    await safe_edit_text(update.callback_query, text,
                         reply_markup=InlineKeyboardMarkup(rows))



async def fj_link_custom_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                channel_id: int) -> None:
    """§12: prompt for the custom link (text-input state)."""
    context.user_data["awaiting_fj_custom_link"] = channel_id
    await safe_answer_callback(update.callback_query)
    await safe_send_text(context.bot, update.effective_chat.id,
        "\U0001F517 Set Custom Join Link\n\n"
        "Send the new invite link.\n\n"
        "Accepted formats:\n"
        "  https://t.me/joinchat/<hash>\n"
        "  https://t.me/+<hash>\n"
        "  https://t.me/<username>\n\n"
        "Send cancel to keep the current link.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u274C Cancel", callback_data=f"fjlinkcancel:{channel_id}")],
        ]))



async def rotate_force_join_invite_link(bot, channel_id: int) -> Tuple[bool, str]:
    """§13: TRANSACTIONAL invite rotation.

    Order of operations (a failure at any step leaves the OLD working link
    untouched):
      1. Verify the bot can access the channel (three-state — a transient
         error aborts honestly, never marks anything invalid).
      2. Public-channel check (§14) — auto rotation isn't applicable.
      3. Create the NEW link (create_chat_invite_link — needs admin +
         invite rights; a failure aborts BEFORE anything is changed).
      4. Persist the new link (only after successful creation).
      5. Revoke the OLD bot-created link (best-effort — links created by
         other admins cannot be revoked by this bot; the new link is
         already active either way).
      6. The caller refreshes the FJ dashboard.
      7. Every step logs (prefixes only — never full URLs).
    Returns (success, human_message).
    """
    old_link = await db.get_force_invite_link(channel_id)
    logger.info("FORCE_JOIN_INVITE_ROTATE channel_id=%s old_link=%s step=start",
                channel_id, _fj_invite_prefix(old_link))
    # Step 1: channel access (three-state).
    status = await classify_channel_access(bot, channel_id)
    if status.is_transient:
        logger.info("FORCE_JOIN_INVITE_ROTATE_RESULT channel_id=%s "
                    "result=aborted reason=transient_error", channel_id)
        return False, ("\u26A0\uFE0F Couldn't verify the channel right now "
                       "(Telegram rate limit / network).\nNothing was changed — "
                       "please try again in a moment.")
    if status.is_invalid:
        logger.info("FORCE_JOIN_INVITE_ROTATE_RESULT channel_id=%s "
                    "result=aborted reason=channel_invalid", channel_id)
        return False, ("\u274C The channel is not accessible to the bot "
                       "(deleted / removed / wrong ID).\nNothing was changed.")
    # Step 2: public-channel check (§14).
    if await _fj_channel_is_public(bot, channel_id):
        logger.info("FORCE_JOIN_INVITE_ROTATE_RESULT channel_id=%s "
                    "result=aborted reason=public_channel", channel_id)
        return False, ("\u26A0\uFE0F Automatic link rotation isn't available for "
                       "this channel (public @username channel — its t.me link "
                       "is permanent).\nUse \u0001F517 Set Custom Link to provide "
                       "a specific link manually.")
    # Step 3: create the NEW link FIRST (nothing changed on failure).
    try:
        new_link = await bot.create_chat_invite_link(
            channel_id, name="bot6-rotated", creates_join_request=True)
    except RetryAfter as e:
        logger.info("FORCE_JOIN_INVITE_ROTATE_RESULT channel_id=%s "
                    "result=aborted reason=flood_control retry_after=%ss",
                    channel_id, getattr(e, "retry_after", "?"))
        return False, ("\u26A0\uFE0F Telegram rate limit — nothing was changed. "
                       "Please try again in a moment.")
    except Forbidden:
        logger.info("FORCE_JOIN_INVITE_ROTATE_RESULT channel_id=%s "
                    "result=aborted reason=bot_not_admin", channel_id)
        return False, ("\u274C The bot is not an admin (or lacks invite "
                       "permissions) in this channel.\nNothing was changed — "
                       "grant the bot the right to invite users.")
    except BadRequest as e:
        logger.info("FORCE_JOIN_INVITE_ROTATE_RESULT channel_id=%s "
                    "result=aborted reason=bad_request error=%s",
                    channel_id, type(e).__name__)
        return False, (f"\u274C Telegram rejected the link creation ({e}).\n"
                       "Nothing was changed.")
    except (NetworkError, TimedOut) as e:
        logger.info("FORCE_JOIN_INVITE_ROTATE_RESULT channel_id=%s "
                    "result=aborted reason=network error=%s",
                    channel_id, type(e).__name__)
        return False, ("\u26A0\uFE0F Network error — nothing was changed. "
                       "Please try again in a moment.")
    except TelegramError as e:
        logger.info("FORCE_JOIN_INVITE_ROTATE_RESULT channel_id=%s "
                    "result=aborted reason=telegram error=%s",
                    channel_id, type(e).__name__)
        return False, (f"\u26A0\uFE0F Unclassified Telegram error "
                       f"({type(e).__name__}) — nothing was changed.\n"
                       "Please try again in a moment.")
    if not new_link or not getattr(new_link, "invite_link", None):
        logger.info("FORCE_JOIN_INVITE_ROTATE_RESULT channel_id=%s "
                    "result=aborted reason=empty_link", channel_id)
        return False, ("\u274C Telegram returned no link. Nothing was changed.")
    new_url = new_link.invite_link
    # PHASE 8 (§14 step: VERIFY the new link BEFORE storing): Telegram
    # returning the ChatInviteLink object IS the confirmation — but we still
    # inspect it defensively (a revoked/expired anomaly aborts BEFORE any
    # stored state changes, so the old working link survives untouched).
    if getattr(new_link, "is_revoked", False):
        logger.info("FORCE_JOIN_INVITE_ROTATE_RESULT channel_id=%s "
                    "result=aborted reason=new_link_already_revoked", channel_id)
        return False, ("\u274C Telegram returned an already-revoked link. "
                       "Nothing was changed.")
    _new_exp = getattr(new_link, "expired_at", None) or getattr(
        new_link, "expires_at", None)
    if _new_exp is not None:
        try:
            from datetime import datetime as _dt, timezone as _tz
            _exp_dt = _new_exp if isinstance(_new_exp, _dt) else _dt.fromisoformat(
                str(_new_exp))
            if _exp_dt.tzinfo is None:
                _exp_dt = _exp_dt.replace(tzinfo=_tz.utc)
            if _exp_dt <= _dt.now(_tz.utc):
                logger.info("FORCE_JOIN_INVITE_ROTATE_RESULT channel_id=%s "
                            "result=aborted reason=new_link_already_expired",
                            channel_id)
                return False, ("\u274C Telegram returned an already-expired "
                               "link. Nothing was changed.")
        except (TypeError, ValueError):
            pass
    # Step 4: persist the new link ONLY after successful creation+verification.
    # B18: provenance='bot_created' — the new link is provably valid until
    # OUR next rotation revokes it (the Bot API has NO getChatInviteLink;
    # provenance is the only durable trust basis for invite hashes).
    await db.set_force_invite_link(channel_id, new_url,
                                   provenance="bot_created")
    # PHASE 8: refresh health state + invalidate the cache atomically with
    # the store, so users immediately get the new working link.
    _FJ_LINK_HEALTH_CACHE.invalidate(channel_id)
    _FJ_LINK_HEALTH_CACHE.store(channel_id, _fj_health.LINK_HEALTHY,
                                expires_at=(str(_new_exp) if _new_exp else None),
                                detail="rotated")
    await db.set_force_link_health(
        channel_id, _fj_health.LINK_HEALTHY,
        expires_at=(str(_new_exp) if _new_exp else None),
        link_type="invite")
    logger.info("FORCE_JOIN_INVITE_ROTATE channel_id=%s new_link=%s step=stored",
                channel_id, _fj_invite_prefix(new_url))
    # Step 5: revoke the OLD link — only now that the new one is live.
    revoke_note = ""
    if old_link and old_link != new_url:
        # Only bot-created join links can be revoked by this bot.
        revocable = ("/joinchat/" in old_link or "/+" in old_link)
        if revocable:
            try:
                await bot.revoke_chat_invite_link(channel_id, old_link)
                revoke_note = " Old link revoked."
                logger.info("FORCE_JOIN_INVITE_ROTATE channel_id=%s "
                            "old_link=%s step=revoked", channel_id,
                            _fj_invite_prefix(old_link))
            except TelegramError as e:
                # Non-fatal: the new link is already active and stored.
                revoke_note = " (Old link could not be revoked — it will expire.)"
                logger.warning("FORCE_JOIN_INVITE_ROTATE channel_id=%s "
                               "old_link=%s revoke_failed=%s",
                               channel_id, _fj_invite_prefix(old_link),
                               type(e).__name__)
        else:
            revoke_note = " (Old link was not bot-created — left untouched.)"
    logger.info("FORCE_JOIN_INVITE_ROTATE_RESULT channel_id=%s "
                "old_link=%s new_link=%s result=success",
                channel_id, _fj_invite_prefix(old_link),
                _fj_invite_prefix(new_url))
    return True, ("\u2705 New invite link created and stored." + revoke_note +
                  "\nThe Force-Join dashboard now uses the new link.")



async def fj_startup_health_pass(bot, *, app_bot=None
                                    ) -> Dict[str, object]:
    """B18 — the STARTUP Force-Join health pass as ONE testable unit.

    Extracted verbatim from post_init's inline loop (bot-19.log Phase-5
    reproduce-and-verify: the remove/re-add sequence must be drivable
    against a real DB + a fake bot without booting a whole Application).

    Per channel:
      * full channel+link health (force=True — bypasses the cache, state
        changes persist + log once);
      * NO_LINK self-heal (B18, bot-19.log 03:33:55): a freshly (re-)
        added channel row has invite_link=NULL; when the auto-repair
        policy allows it the bot MINTS a fresh link (export_chat_invite_
        link — admin + invite rights required), stores it with
        provenance='bot_created' and the channel becomes healthy — no
        manual remove/re-add workaround;
      * the bot's own admin check (join-request capability) — skipped for
        invalid/transient channels, RetryAfter never marks anything
        invalid.

    Returns the aggregate dict: {channels, healthy, unverifiable,
    temporary, dead_links, dead_link_channels, channel_invalid, no_link,
    rtj_unavailable}.
    """
    force_channels = await db.list_force_channels()
    rtj_unavailable = []
    health_counts: Dict[str, int] = {}
    dead_link_channels = []
    for ch in force_channels:
        cid = _safe_row_get(ch, "channel_id")
        health = await _fj_check_link_health(bot, int(cid), force=True)
        health_counts[health.state] = health_counts.get(health.state, 0) + 1
        if health.is_dead_link:
            dead_link_channels.append(cid)
        if health.state == _fj_health.NO_LINK:
            try:
                _auto = await db.get_setting_bool(
                    "fj_link_auto_rotate", True)
            except Exception:  # noqa: BLE001
                _auto = True
            if _auto:
                try:
                    new_link = await bot.export_chat_invite_link(int(cid))
                    if new_link:
                        await db.set_force_invite_link(
                            int(cid), new_link, provenance="bot_created")
                        await db.set_force_link_health(
                            int(cid), _fj_health.LINK_HEALTHY,
                            link_type=_fj_health.link_syntax_kind(new_link))
                        _FJ_LINK_HEALTH_CACHE.invalidate(int(cid))
                        health_counts[_fj_health.NO_LINK] -= 1
                        health_counts[_fj_health.LINK_HEALTHY] = \
                            health_counts.get(_fj_health.LINK_HEALTHY, 0) + 1
                        logger.info(
                            "FORCE_JOIN_LINK_AUTO_CREATED channel_id=%s "
                            "provenance=bot_created (startup self-heal: "
                            "the re-added channel had NO stored link — "
                            "no manual workaround needed)", cid)
                except Exception as e:  # noqa: BLE001 — best-effort
                    logger.info(
                        "FORCE_JOIN_LINK_AUTO_CREATE_SKIPPED "
                        "channel_id=%s reason=%s (NO_LINK stays honest "
                        "— the link is created lazily on the next Join "
                        "button render)", cid, type(e).__name__)
        if health.state in (_fj_health.CHANNEL_INVALID,):
            continue  # skip admin check — channel is invalid
        if health.state in (_fj_health.TEMPORARY_ERROR,):
            continue  # transient — NOT invalid, honest 'unverified'
        try:
            me = await bot.get_me()
            member = await bot.get_chat_member(cid, me.id)
            if member.status not in (ChatMemberStatus.ADMINISTRATOR,
                                     ChatMemberStatus.OWNER):
                rtj_unavailable.append(cid)
        except RetryAfter as e:
            logger.warning("FORCE_JOIN_TRANSIENT_ERROR channel_id=%s "
                           "error=RetryAfter retry_after=%ss (startup admin "
                           "check — NOT marked invalid)",
                           cid, getattr(e, "retry_after", "?"))
        except TelegramError as e:
            logger.warning("Startup validation: cannot verify bot admin "
                           "status in %s: %s", cid, e)
            rtj_unavailable.append(cid)
    logger.info(
        "FORCE_JOIN_STARTUP_HEALTH channels=%s healthy=%s unverifiable=%s "
        "temporary=%s dead_links=%s(%s) channel_invalid=%s no_link=%s",
        len(force_channels),
        health_counts.get(_fj_health.LINK_HEALTHY, 0),
        health_counts.get(_fj_health.UNVERIFIABLE, 0),
        health_counts.get(_fj_health.TEMPORARY_ERROR, 0),
        sum(health_counts.get(s, 0) for s in (
            _fj_health.LINK_EXPIRED, _fj_health.LINK_REVOKED,
            _fj_health.LINK_INVALID)),
        dead_link_channels,
        health_counts.get(_fj_health.CHANNEL_INVALID, 0),
        health_counts.get(_fj_health.NO_LINK, 0))
    return {
        "channels": len(force_channels),
        "healthy": health_counts.get(_fj_health.LINK_HEALTHY, 0),
        "unverifiable": health_counts.get(_fj_health.UNVERIFIABLE, 0),
        "temporary": health_counts.get(_fj_health.TEMPORARY_ERROR, 0),
        "dead_links": sum(health_counts.get(s, 0) for s in (
            _fj_health.LINK_EXPIRED, _fj_health.LINK_REVOKED,
            _fj_health.LINK_INVALID)),
        "dead_link_channels": dead_link_channels,
        "channel_invalid": health_counts.get(_fj_health.CHANNEL_INVALID, 0),
        "no_link": health_counts.get(_fj_health.NO_LINK, 0),
        "rtj_unavailable": rtj_unavailable,
    }



async def fj_channel_test_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                channel_id: int) -> None:
    """§16: Test Channel — full diagnostic. NEVER marks a channel invalid
    because of a temporary Telegram rate limit."""
    ch = await db.get_force_channel(channel_id)
    if not ch:
        await safe_answer_callback(update.callback_query, "Channel not found.", show_alert=True)
        return
    name = _force_channel_label(ch)
    bot = context.bot
    user = update.effective_user
    lines = [f"\U0001F9EA Channel Test — {name}", ""]
    overall_ok = True
    # 1. Channel accessible.
    status = await classify_channel_access(bot, channel_id)
    if status == ChannelAccessStatus.VALID:
        lines.append("\u2705 Channel accessible")
    elif status.is_transient:
        lines.append("\u26A0\uFE0F Channel access: couldn't verify right now "
                     "(rate limit / network) — NOT an error")
        overall_ok = False  # inconclusive, not failed
    else:
        lines.append("\u274C Channel NOT accessible — fix the configuration")
        overall_ok = False
    # 2. Bot permissions (admin + invite + join-request rights).
    bot_id = (await bot.get_me()).id
    perms_ok = True
    can_invite = False
    can_join_requests = False
    try:
        member = await bot.get_chat_member(channel_id, bot_id)
        if member.status in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER):
            lines.append("\u2705 Bot is admin")
            can_invite = bool(getattr(member, "can_invite_users", False))
            can_join_requests = bool(getattr(member, "can_manage_join_requests", False))
            lines.append(f"{'\u2705' if can_invite else '\u26A0\uFE0F'} Invite links: "
                         f"{'OK' if can_invite else 'missing (can_invite_users)'}")
            lines.append(f"{'\u2705' if can_join_requests else '\u26A0\uFE0F'} Join requests: "
                         f"{'OK' if can_join_requests else 'missing (can_manage_join_requests)'}")
            if not can_invite:
                perms_ok = False
        else:
            lines.append(f"\u26A0\uFE0F Bot is a plain member (status={member.status}) — "
                         "invite links + join-request approval unavailable")
            perms_ok = False
    except RetryAfter as e:
        lines.append(f"\u26A0\uFE0F Bot permission check hit rate limit "
                     f"({getattr(e, 'retry_after', '?')}s) — try again later")
        overall_ok = False
    except TelegramError as e:
        lines.append(f"\u26A0\uFE0F Bot permission check failed: {type(e).__name__}")
        overall_ok = False
    # 3. Membership lookup — a REAL get_chat_member for the requesting admin.
    lookup_ok = False
    if user and user.id:
        try:
            m = await bot.get_chat_member(channel_id, user.id)
            lines.append(f"\u2705 Membership lookup OK (you: {m.status})")
            lookup_ok = True
        except RetryAfter as e:
            lines.append(f"\u26A0\uFE0F Membership lookup hit rate limit "
                         f"({getattr(e, 'retry_after', '?')}s) — NOT a failure")
        except TelegramError as e:
            lines.append(f"\u274C Membership lookup failed: {type(e).__name__}")
    # 4. Stored invite link — PHASE 8: REAL verification (get_chat_invite_link:
    #    expired / revoked / belongs-to-this-channel), not just 'is stored'.
    stored = await db.get_force_invite_link(channel_id)
    _FJ_LINK_HEALTH_CACHE.invalidate(channel_id)  # §18: manual Test invalidates
    link_result = await _fj_check_link_health(bot, channel_id, force=True)
    if stored is None:
        lines.append("\U0001F517 Invite link: not stored yet")
    else:
        lines.append(f"\U0001F517 Invite link: {_fj_health.health_badge(link_result.state)}"
                     f" — {_fj_invite_prefix(stored)}")
        if link_result.expires_at:
            lines.append(f"   Expires: {str(link_result.expires_at)[:19]}")
        if link_result.detail:
            lines.append(f"   Detail: {link_result.detail[:100]}")
        if link_result.is_dead_link:
            lines.append("   \u2192 Users currently see a friendly 'temporarily "
                         "unavailable' notice (no dead Join button).")
            lines.append("   \u2192 Use Change Join Link \u2192 Generate New Link.")
    # 5. Join-request configuration.
    is_public = await _fj_channel_is_public(bot, channel_id)
    if is_public:
        lines.append("\U0001F517 Public channel (t.me link — no join requests)")
    else:
        lines.append("\U0001F512 Private channel — join requests handled via invite links")
    # Summary.
    lines.append("")
    if overall_ok and lookup_ok and perms_ok:
        lines.append("\u2705 Overall: channel healthy")
    elif status.is_transient:
        lines.append("\u26A0\uFE0F Overall: INCONCLUSIVE — Telegram is rate-limiting "
                     "right now. The channel was NOT marked invalid.")
    else:
        lines.append("\u26A0\uFE0F Overall: needs attention (see above)")
    logger.info("FORCE_JOIN_CHANNEL_TEST channel_id=%s admin=%s "
                "accessible=%s perms=%s lookup=%s link=%s",
                channel_id, (user.id if user else 0),
                status.value, 1 if perms_ok else 0, 1 if lookup_ok else 0,
                1 if stored else 0)
    await safe_answer_callback(update.callback_query, "\U0001F9EA Test complete.")
    sent = await safe_send_text(context.bot, update.effective_chat.id,
                                "\n".join(lines),
                                reply_markup=InlineKeyboardMarkup([
                                    [InlineKeyboardButton("\U0001F9EA Test Again",
                                                          callback_data=f"fjtest:{channel_id}")],
                                    [InlineKeyboardButton("\u2B05\uFE0F Back",
                                                          callback_data=f"fjedit:{channel_id}")],
                                ]))
    # §18: temporary test result — auto-delete; the channel panel stays.
    if sent and getattr(sent, "message_id", None):
        try:
            await schedule_admin_preview_delete(
                context.bot, update.effective_chat.id, [int(sent.message_id)])
        except Exception:  # noqa: BLE001
            pass
