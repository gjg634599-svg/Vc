"""Access panels — manage files, payload detail, access policy.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



# ============================================================
# BOT6 P14-18: MANAGE FILES PANEL (for existing collections)
# ============================================================
async def manage_files_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              coll_code: str) -> None:
    """P15: Show the Manage Files panel for a collection. Lists files, with
    Add/Remove/Preview/Refresh/Back controls. Operates on the actual persisted
    collection_items — never fakes the file count."""
    if not coll_code:
        await safe_answer_callback(update.callback_query, "No collection specified.", show_alert=True)
        return
    context.user_data["_mf_coll_code"] = coll_code
    coll = await db.get_collection(coll_code)
    if not coll:
        await safe_answer_callback(update.callback_query, "Collection not found.", show_alert=True)
        return
    items = await db.get_collection_items(coll_code)
    channel_id = int(coll["channel_id"])
    file_count = int(coll["file_count"] or 0)
    lines = [f"\U0001F4C1 Manage Files", ""]
    lines.append(f"Collection: {coll_code}")
    lines.append(f"Channel: {channel_id}")
    lines.append(f"Files: {file_count}")
    lines.append("")
    if not items:
        lines.append("(no files — collection is empty)")
    else:
        for i, item in enumerate(items, 1):
            mid = item["message_id"] if "message_id" in item.keys() else "?"
            fname = _safe_row_get(item, "file_name") or f"msg_{mid}"
            lines.append(f"{i}. {truncate(fname, 40)}")
    text = "\n".join(lines)
    kb_rows: List[List[InlineKeyboardButton]] = [
        [InlineKeyboardButton("\u2795 Add File", callback_data=f"mfadd:{coll_code}"),
         InlineKeyboardButton("\U0001F441 Preview Files", callback_data=f"linkpreview:c:{coll_code}")],
    ]
    if items:
        # Per-file rows: reorder (up/down) + remove — position-keyed
        # (V25 FINAL §15: Add / Remove / REORDER, each a real persisted op).
        n = len(items)
        for pos, item in enumerate(items):
            mid = item["message_id"] if "message_id" in item.keys() else 0
            fname = _safe_row_get(item, "file_name") or f"msg_{mid}"
            frow: List[InlineKeyboardButton] = []
            if pos > 0:
                frow.append(InlineKeyboardButton(
                    "\u2b06", callback_data=f"mfup:{coll_code}:{pos}"))
            if pos < n - 1:
                frow.append(InlineKeyboardButton(
                    "\u2b07", callback_data=f"mfdown:{coll_code}:{pos}"))
            frow.append(InlineKeyboardButton(
                f"\u2796 {truncate(fname, 28)}",
                callback_data=f"mfremove:{coll_code}:{mid}"))
            kb_rows.append(frow)
    kb_rows.append([InlineKeyboardButton("\U0001F504 Refresh", callback_data=f"managefiles:{coll_code}")])
    kb_rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:payloads")])
    await safe_edit_text(update.callback_query, text, reply_markup=InlineKeyboardMarkup(kb_rows))


async def manage_files_move(update: Update, context: ContextTypes.DEFAULT_TYPE,
                             coll_code: str, position: int,
                             direction: str) -> None:
    """V25 FINAL §15 (Manage Files — Reorder): swap the member at
    ``position`` with its neighbor via the repo primitive (positions stay
    dense + deterministic); the panel re-renders with the NEW order."""
    moved = await db.collection_move_item(coll_code, int(position), direction)
    if moved:
        logger.info("BOT6_PAYLOAD_FILES_MOVE collection_id=%s position=%s "
                    "direction=%s (order persisted — the website and "
                    "delivery read the same order)",
                    coll_code, position, direction)
        await safe_answer_callback(update.callback_query,
                                   "\u2705 Order updated.")
    else:
        await safe_answer_callback(update.callback_query,
                                   "Already at the edge — nothing to move.")
    await manage_files_panel(update, context, coll_code)



async def manage_files_add_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                   coll_code: str) -> None:
    """P16: prompt admin to forward/select a file to add to the collection."""
    context.user_data["_mf_coll_code"] = coll_code
    context.user_data["awaiting_mf_add"] = True
    await safe_send_text(context.bot, update.effective_chat.id,
        "\u2795 Add File to Collection\n\n"
        f"Collection: {coll_code}\n\n"
        "Forward a file from a storage channel to add it to this collection.\n"
        "The file must already be indexed.")
    await safe_answer_callback(update.callback_query)



async def manage_files_remove_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                       coll_code: str, msg_id: int) -> None:
    """P17: confirm file removal from collection."""
    items = await db.get_collection_items(coll_code)
    fname = None
    for item in items:
        if item["message_id"] == msg_id:
            fname = _safe_row_get(item, "file_name") or f"msg_{msg_id}"
            break
    text = (
        f"\u26A0\uFE0F Remove File?\n\n"
        f"{fname or f'msg_{msg_id}'}\n\n"
        f"This will remove the file from this payload collection.\n"
        f"The underlying storage-channel file is NOT deleted."
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u2705 Remove", callback_data=f"mfremoveyes:{coll_code}:{msg_id}"),
         InlineKeyboardButton("\u274C Cancel", callback_data=f"managefiles:{coll_code}")],
    ])
    await safe_edit_text(update.callback_query, text, reply_markup=kb)



async def manage_files_remove_execute(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                       coll_code: str, msg_id: int) -> None:
    """P17 + V25 FINAL §15: execute file removal from collection_items
    + update file_count + RENUMBER the remaining positions (the order
    stays dense — the website and delivery read the same order)."""
    try:
        cur = await db.conn.execute(
            "SELECT position FROM collection_items WHERE collection_id = ? "
            "AND message_id = ?",
            (coll_code, msg_id))
        prow = await cur.fetchone()
        if prow is None:
            await safe_answer_callback(update.callback_query,
                                       "File not in the collection.", show_alert=True)
            return
        removed = await db.collection_remove_item(
            coll_code, int(prow["position"]))
        if not removed:
            await safe_answer_callback(update.callback_query,
                                       "\u274C Remove failed.", show_alert=True)
            return
        cur = await db.conn.execute(
            "SELECT COUNT(*) AS c FROM collection_items WHERE collection_id = ?",
            (coll_code,),
        )
        r = await cur.fetchone()
        new_count = int(r["c"]) if r else 0
        logger.info("BOT6_PAYLOAD_FILES_REMOVE collection_id=%s message_id=%s new_count=%s "
                    "(positions renumbered — the website updates on its next "
                    "request: listings render straight from the DB)",
                    coll_code, msg_id, new_count)
    except Exception as e:  # noqa: BLE001
        logger.error("Manage files remove failed: %s", e, exc_info=True)
        await safe_answer_callback(update.callback_query, "\u274C Remove failed.", show_alert=True)
        return
    await safe_answer_callback(update.callback_query, "\u2705 File removed from collection.")
    await manage_files_panel(update, context, coll_code)



async def pm_payload_detail(update: Update, context: ContextTypes.DEFAULT_TYPE,
                            payload_id: int,
                            list_page: Optional[int] = None,
                            search_qid: Optional[str] = None) -> None:
    """Payload Manager (detail) — grouped sections, Markdown-safe.

    Rendered as PLAIN TEXT (no parse_mode) so payload names, links, and
    filenames with underscores/asterisks/backticks never crash the render.
    Falls back to safe_send_text if the edit fails entirely.

    PHASE 6 §7: `list_page` (from pldetail:<pid>:<page>) is the originating
    Payload List page. Resolution order: explicit callback page → preserved
    nav context → the payload's deterministic list page (position-based).
    Back returns to that EXACT page (plback:<page>), never page 1.
    PHASE 7 (Task 3): `search_qid` (from plsdetail:<qid>:<pid>:<page>) marks
    a SEARCH-MODE entry — Back returns to that exact SEARCH RESULT page via
    the deterministic plsback:<qid>:<page> callback (the query is persisted
    in bot_settings under pl_search:<qid> — restart-safe).
    """
    row = await db.get_payload_by_id(payload_id)
    if not row:
        await safe_answer_callback(update.callback_query,
            "Payload no longer exists. It may have been deleted.", show_alert=True)
        await payload_list_panel(update, context)
        return
    file_row = await db.get_indexed_file_by_id(row["index_id"])
    stats = await db.payload_view_stats(row["id"])
    da = row["delete_after"]
    if da is None:
        da_label = "inherit global"
    elif da == 0:
        da_label = "never"
    else:
        da_label = f"{da}s"
    # BOTV13 Phase 4: per-payload forward blocking label.
    fb = row["forward_blocking"] if "forward_blocking" in row.keys() else None
    global_protect = await resolve_delivery_protection()
    if fb is None:
        fb_label = f"Inherit ({'ON' if global_protect else 'OFF'})"
    elif fb:
        fb_label = "ON"
    else:
        fb_label = "OFF"
    # Plain-text safe filename (no Markdown escaping needed — plain text).
    fname = (file_row['file_name'] if file_row else 'missing') or 'missing'
    # Access Engine: read policy + referral campaign.
    policy = row["access_policy"] if "access_policy" in row.keys() else None
    if not policy:
        policy = await db.get_access_policy(row["id"])
    campaign = await db.get_referral_campaign_by_payload(row["id"])
    policy_emoji = {
        ACCESS_POLICY_OPEN: "\U0001F7E2",
        ACCESS_POLICY_FORCE_JOIN: "\U0001F6E1",
        ACCESS_POLICY_FORCE_JOIN_REFERRAL: "\U0001F512",
    }.get(policy, "\u2753")
    policy_label = {
        ACCESS_POLICY_OPEN: "Open",
        ACCESS_POLICY_FORCE_JOIN: "Force Join",
        ACCESS_POLICY_FORCE_JOIN_REFERRAL: "Force Join + Referral",
    }.get(policy, policy or "Unknown")
    SEP = "\u2501" * 20
    # Referral section.
    if campaign:
        ref_line = (f"\u2705 req {campaign['required_referrals']} "
                    f"({'enabled' if campaign['enabled'] else 'disabled'})")
        try:
            analytics = await db.campaign_full_analytics(campaign["id"])
            ref_stats = (f"Qualified: {analytics['qualified_referrals']} | "
                         f"Unlocks: {analytics['unlocks']} | "
                         f"Rate: {analytics['unlock_rate']}%")
        except Exception as e:  # noqa: BLE001
            logger.warning("pm_payload_detail: analytics fetch failed: %s", e)
            ref_stats = ""
    else:
        ref_line = "\u2014 none"
        ref_stats = ""
    # Preview section.
    if campaign:
        pm = campaign["preview_mode"] or PREVIEW_MODE_DISABLED
        has_media = bool(_safe_row_get(campaign, "preview_media_file_id"))
        has_desc = bool(_safe_row_get(campaign, "preview_description"))
        preview_line = pm
        if has_media:
            preview_line += " (media)"
        if has_desc:
            preview_line += " (text)"
    else:
        preview_line = "\u2014"
    # BOT-13 §57 → BOT-16: per-payload Get File ON/OFF (kept). The
    # per-payload "delivery mode" (Bot / Website Ads / None) selector is
    # REMOVED — ad behavior is now SURFACE-BASED: Telegram Watch Ads follow
    # the Telegram Watch Ads settings; the website pre-roll follows the
    # WEBSITE ad settings (website_videoad_provider + website_preroll_*).
    # The payloads.video_ad_destination column is deprecated (kept for
    # migration compatibility, inert at runtime).
    show_get_file = bool(_safe_row_get(row, "show_get_file")
                         if _safe_row_get(row, "show_get_file") is not None
                         else True)
    # Website ads state (surface-based, read-only here — manage it in
    # Website Settings → Video Pre-Roll Ads).
    try:
        website_ads_on = bool(await db.get_setting_bool(
            "website_preroll_enabled", False))
    except Exception:  # noqa: BLE001 — display-only
        website_ads_on = False
    wad_line_on = bool(_safe_row_get(row, "watch_ads_enabled"))
    # PLAIN TEXT — no parse_mode. All dynamic values inserted raw (safe in
    # plain text: no Markdown specials to break).
    # BOTV13: Display Name FIRST (human-readable title), Routing ID below
    # (admin-only, never shown to end users). File THIRD.
    stored_display = row["display_name"] if "display_name" in row.keys() else None
    display_name = get_payload_display_name(row["payload"], fname, display_name=stored_display)
    routing_slug = row["payload"]
    text = (
        f"{SEP}\n"
        f"\U0001F4CB {display_name}\n"
        f"\U0001F194 Routing ID: {routing_slug}\n"
        f"\U0001F4C4 {fname}"
        f" ({file_row['media_type'] if file_row else '-'})\n"
        f"{SEP}\n"
        f"Status: {row['status'].title()}\n"
        f"{SEP}\n"
        f"\U0001F510 Access: {policy_emoji} {policy_label}\n"
        f"\U0001F3AC Telegram Ads: {'Enabled' if wad_line_on else 'Disabled'}\n"
        f"\U0001F465 Referral: {ref_line}\n"
        + (f"   {ref_stats}\n" if ref_stats else "")
        + f"{SEP}\n"
        f"\U0001F4CA Views: {stats['total']} total | {stats['unique']} unique\n"
        f"{SEP}\n"
        f"\u23F1 Delivery: {da_label} | One-time: {'ON' if row['one_time'] else 'OFF'}\n"
        f"\U0001F6E1 Forward Blocking: {fb_label}\n"
        f"\U0001F3AC Preview: {preview_line}\n"
        f"{SEP}\n"
        f"\U0001F310 WEBSITE\n"
        f"\U0001F4E5 Get File: {'\U0001F7E2 ON' if show_get_file else '\U0001F534 OFF'}\n"
        f"\U0001F310 Website Ads: {'Enabled' if website_ads_on else 'Disabled'}"
        " (Website Settings)\n"
        f"{SEP}\n"
        f"\U0001F517 {build_link(row['payload'], display_name=stored_display)}"
    )
    # Buttons grouped: primary / config / analytics / danger / back.
    share_url = f"https://t.me/share/url?url={build_link(row['payload'], display_name=stored_display)}"
    wad_on = wad_line_on
    buttons: List[List[InlineKeyboardButton]] = [
        [InlineKeyboardButton("\U0001F4CB Copy Link", callback_data=f"copy_id:{row['id']}"),
         InlineKeyboardButton("\U0001F4E4 Share", url=share_url)],
        [InlineKeyboardButton("\u270F\uFE0F Edit", callback_data=f"pcw:edit:{row['id']}"),
         InlineKeyboardButton("\u2699\uFE0F Access", callback_data=f"plgate:{row['id']}")],
    ]
    # V25 FINAL §15 (Manage Files): a FIRST-CLASS Files button on the
    # payload detail — collections open the full Add/Remove/Reorder panel;
    # single-file payloads show the file with the collection note.
    # V26 (bot-37.log message-872 identity fix): the CANONICAL collection
    # predicate (is_collection_link — 'c' + hex-only body, the SAME
    # predicate every /start routing path uses) replaces the naive
    # startswith('c'). A single-file payload whose auto-generated name
    # begins with 'c' (payload 787 'clipmatezone_indias_got_latent_2026_
    # bonus_s02e03_1080p', created from message 872) was misdetected as a
    # collection → 'managefiles:lipmatezone_…' = 65 bytes > Telegram's
    # 64-byte callback_data limit → BadRequest Button_data_invalid on BOTH
    # the edit AND the fallback send — the Payload Manager could NEVER
    # render (the admin tapped pcw:create 5+ times staring at a stale
    # screen). The canonical predicate matches the routing truth: only a
    # real c<hex> collection slug is a collection.
    if is_collection_link(routing_slug):
        real_code = parse_collection_link(routing_slug) or ""
        # Defense in depth: a managefiles callback can NEVER exceed the
        # 64-byte Telegram limit (collection codes are short hex; a
        # corrupt/legacy long code degrades to the file-preview button
        # instead of an unsendable keyboard).
        if real_code and len(f"managefiles:{real_code}") <= 64:
            try:
                _coll = await db.get_collection(real_code)
                _n = int(_coll["file_count"]) if _coll else 0
            except Exception:  # noqa: BLE001 — display-only
                _n = 0
            buttons.append([InlineKeyboardButton(
                f"\U0001F4C1 Files ({_n}) — Add / Remove / Reorder",
                callback_data=f"managefiles:{real_code}")])
        else:
            buttons.append([InlineKeyboardButton(
                "\U0001F4C1 Files (1)", callback_data=f"filepreview:{row['index_id']}")])
    else:
        buttons.append([InlineKeyboardButton(
            "\U0001F4C1 Files (1)", callback_data=f"filepreview:{row['index_id']}")])
    buttons.extend([
        # BOT-16: clean surface-based controls — Telegram Ads (this
        # payload's Watch Ads toggle) + Get File ON/OFF. The obsolete
        # Bot / Website Ad / None ad-destination selector is REMOVED
        # (website ads follow the Website ad settings; the literal-string
        # label bug — "Watch Ads: {'ON' if wad_on else 'OFF'}" rendered
        # verbatim from the PDF page-1 screenshot — is fixed with it).
        [InlineKeyboardButton(
            f"\U0001F3AC Telegram Ads: {'Enabled' if wad_on else 'Disabled'}",
            callback_data=f"plgwad:{row['id']}")],
        [InlineKeyboardButton(
            f"\U0001F4E5 Get File: {'ON' if show_get_file else 'OFF'}",
            callback_data=f"plgf:{row['id']}")],
        [InlineKeyboardButton("\U0001F465 Referral", callback_data=f"plgreferral:{row['id']}"),
         InlineKeyboardButton("\U0001F3AC Preview", callback_data=f"plgpreview:{row['id']}")],
        [InlineKeyboardButton("\u23F1 Delivery", callback_data=f"pltimer:{row['id']}"),
         InlineKeyboardButton("\U0001F4CA Analytics", callback_data=f"plganalytics:{row['id']}")],
        [InlineKeyboardButton("\u270F\uFE0F Rename", callback_data=f"plrename:{row['id']}"),
         InlineKeyboardButton("\u23F8 Disable" if row['status'] == 'active' else "\u2705 Enable",
                              callback_data=f"pltoggle:{row['id']}")],
        [InlineKeyboardButton("\u267B\uFE0F Reset", callback_data=f"plgresetconfirm:{row['id']}"),
         InlineKeyboardButton("\U0001F5D1 Delete", callback_data=f"pldel:{row['id']}")],
        [InlineKeyboardButton("\U0001F3E0 Home", callback_data="panel:main"),
         InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:payloads")],
    ])
    # V15/PHASE 6 §7: set navigation context so every submenu's Back/Cancel
    # returns here, AND preserve the originating Payload List page so the
    # detail's Back returns to that exact page (never page 1).
    if list_page is None:
        list_page = _nav_list_page(context)
    if list_page is None:
        list_page = await _page_for_payload(int(row["id"]))
    try:
        list_page = max(0, int(list_page))
    except (TypeError, ValueError):
        list_page = 0
    # PHASE 7 (Task 3): search mode — resolve the qid from the callback OR
    # the preserved nav context (child screens re-enter the detail without
    # the qid; the nav ctx keeps it).
    if not search_qid:
        _ctx = nav_get(context) or {}
        _sq = _ctx.get("search_qid")
        if _sq and re.fullmatch(r"[0-9a-f]{8}", str(_sq)):
            search_qid = str(_sq)
        else:
            search_qid = None
    nav_set(context, "payload_details", payload_id=int(row["id"]),
            list_page=list_page)
    if search_qid:
        # Keep it in the nav ctx so nested child screens (which return via
        # pldetail:<pid> without the qid) still land in search mode.
        context.user_data[NAV_KEY]["search_qid"] = search_qid
    logger.info("PAYLOAD_DETAIL_OPEN payload_id=%s page=%s search_qid=%s",
                int(row["id"]), list_page + 1, search_qid or "-")
    # PHASE 6 §7: Back returns to the SAME Payload List page via the
    # deterministic plback:<page> callback (restart-safe: the page number is
    # in the callback data itself). PHASE 7 (Task 3): search mode returns to
    # the SAME search result page (plsback:<qid>:<page> — the query persists
    # in bot_settings, restart-safe).
    _back_cb = (f"plsback:{search_qid}:{list_page}" if search_qid
                else f"plback:{list_page}")
    for brow in buttons:
        for i, b in enumerate(brow):
            if b.callback_data == "panel:payloads":
                brow[i] = InlineKeyboardButton("\u2B05\uFE0F Back",
                                               callback_data=_back_cb)
    kb = InlineKeyboardMarkup(buttons)
    # Try to edit the current message. If that fails, send a new plain-text
    # message so the admin is never left staring at the old screen.
    sent = await safe_edit_text(update.callback_query, text, reply_markup=kb)
    if not sent:
        try:
            await safe_send_text(context.bot, update.effective_chat.id, text, reply_markup=kb)
        except Exception as e:  # noqa: BLE001
            logger.error("pm_payload_detail: fallback send failed: %s", e)



# ============================================================
# ACCESS ENGINE V1 — ADMIN PANEL (per-payload Access Policy)
# ============================================================
# Replaces the old "Referral Gate" panel. The Access Engine is the single
# authorization layer; this panel lets the admin choose the policy
# (OPEN / FORCE_JOIN / FORCE_JOIN_REFERRAL) and, for the referral policy,
# configure required referrals, preview mode/media, view analytics, and
# perform Reset Progress / Reset Campaign / Disable Campaign.
#
# Destructive actions ALWAYS require a confirmation step. referral_history is
# NEVER deleted by any of these actions (it is permanent).
# ============================================================

def _policy_short_label(policy: str) -> str:
    return {
        ACCESS_POLICY_OPEN: "\U0001F7E2 OPEN",
        ACCESS_POLICY_FORCE_JOIN: "\U0001F6E1 FORCE_JOIN",
        ACCESS_POLICY_FORCE_JOIN_REFERRAL: "\U0001F512 REFERRAL",
    }.get(policy, policy)



async def referral_gate_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                               payload_id: int) -> None:
    """Access Engine V1 entry panel (kept under the legacy name for callback
    routing). Delegates to access_policy_panel."""
    await access_policy_panel(update, context, payload_id)



async def access_policy_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                               payload_id: int) -> None:
    """Main Access Policy panel for a payload."""
    row = await db.get_payload_by_id(payload_id)
    if not row:
        await safe_answer_callback(update.callback_query, "Payload not found.", show_alert=True)
        return
    policy = row["access_policy"] if "access_policy" in row.keys() else None
    if not policy:
        policy = await db.get_access_policy(payload_id)
    campaign = await db.get_referral_campaign_by_payload(payload_id)

    # 1. Define the status string outside the f-string first
    is_ads_enabled = _safe_row_get(row, 'watch_ads_enabled')
    ads_status = '\u2705 Enabled' if is_ads_enabled else '\u274C Disabled'

    # 2. Pass the variable into the f-string cleanly
    # v26 CRITICAL FIX: the uploaded production copy renamed this variable to
    # `Text` while every later reference used lowercase `text` — a NameError
    # on EVERY render path that silently killed the Access Policy callback
    # (the reported "Access Policy does nothing / UI stuck" bug). Restored to
    # the single lowercase `text` used by the rest of the function.
    # b10 §28 (B10-W3): the label text renders via md_code_span — the runtime
    # escape_md form used to emit an escaped underscore inside the policy
    # label, and while an escaped marker OUTSIDE an entity is a literal, the
    # §28 evidence (byte 177) proved the parser's entity handling unreliable
    # around escapes; the emoji stays outside the span, the text inside it.
    _lbl = _policy_short_label(policy)
    _emo, _, _rest = _lbl.partition(" ")
    _label_md = (f"{_emo} {md_code_span(_rest)}" if _rest
                 else md_code_span(_lbl))
    text = (
        f"*\U0001F510 Access Policy*\n\n"
        f"*Payload:* {md_code_span(row['payload'])}\n"
        f"*Current Policy:* {_label_md}\n"
        f"*Watch Ads:* {ads_status}\n"
        f"*Unlock:* Referral OR Watch Ads (whichever completes first)\n"
    )
    
    buttons: List[List[InlineKeyboardButton]] = [
        [InlineKeyboardButton("\u2699\uFE0F Change Policy", callback_data=f"plgpolicy:{payload_id}")],
        [InlineKeyboardButton("\U0001F3AC Watch Ads", callback_data=f"plgwad:{payload_id}")],
    ]

    if policy == ACCESS_POLICY_FORCE_JOIN_REFERRAL:
        if campaign:
            enabled = bool(campaign["enabled"])
            required = int(campaign["required_referrals"])
            preview_mode = campaign["preview_mode"] or PREVIEW_MODE_DISABLED
            analytics = await db.campaign_full_analytics(campaign["id"])
            avg_t = analytics.get("avg_unlock_seconds")
            avg_label = f"{int(avg_t)}s" if avg_t is not None else "n/a"
            status = "\U0001F7E2 Enabled" if enabled else "\U0001F534 Disabled"
            text += (
                f"*Campaign:* #{campaign['id']} ({status})\n"
                f"*Required Referrals:* {required}\n"
                f"*Preview Mode:* {escape_md(preview_mode)}\n\n"
                f"*Analytics:*\n"
                f"  Campaign views: {analytics['campaign_views']}\n"
                f"  Payload opens: {analytics['payload_opens']}\n"
                f"  Preview views: {analytics['preview_views']}\n"
                f"  Referral link opens: {analytics['ref_link_opens']}\n"
                f"  Qualified referrals: {analytics['qualified_referrals']}\n"
                f"  Unlocks: {analytics['unlocks']}\n"
                f"  Participants: {analytics['total_participants']}\n"
                f"  Unlock rate: {analytics['unlock_rate']}%\n"
                f"  Avg unlock time: {avg_label}\n"
            )
            top_refs = await db.top_referrers(campaign["id"], limit=5)
            if top_refs:
                text += "\n*Top Referrers:*\n"
                for i, r in enumerate(top_refs, 1):
                    text += f"  {i}. {md_code_span(r['inviter_user_id'])} \u2014 {r['qualified_count']}\n"
            toggle_label = "\U0001F7E2 Disable Campaign" if enabled else "\U0001F534 Enable Campaign"
            buttons += [
                [InlineKeyboardButton("\U0001F522 Required Referrals",
                                      callback_data=f"plgsetreq:{payload_id}")],
                [InlineKeyboardButton("\U0001F441 Preview Mode",
                                      callback_data=f"plgpreview:{payload_id}")],
                [InlineKeyboardButton("\U0001F4CA Analytics",
                                      callback_data=f"plganalytics:{payload_id}")],
                [InlineKeyboardButton(toggle_label, callback_data=f"plgtoggle:{payload_id}")],
                [InlineKeyboardButton("\u267B\uFE0F Reset Progress",
                                      callback_data=f"plgreset:{payload_id}"),
                 InlineKeyboardButton("\u267B\uFE0F Reset Campaign",
                                      callback_data=f"plgresetall:{payload_id}")],
                [InlineKeyboardButton("\U0001F6AB Disable Campaign",
                                      callback_data=f"plgdisable:{payload_id}")],
            ]
        else:
            # b10 §28 (B10-W3): the label renders via md_code_span — the
            # legacy-Markdown backslash escape proved unreliable (see the
            # FORCE_JOIN tail note below), so no escaped markers remain in
            # panel text.
            text += (
                "\nNo referral campaign yet. Select \u201cChange Policy \u2192 "
                + md_code_span("FORCE_JOIN_REFERRAL")
                + "\u201d to create one.\n"
            )
    elif policy == ACCESS_POLICY_OPEN:
        # `_OPEN_` is a BALANCED raw pair (2 underscores, no internals) — the
        # v26 form that already parses (kept italic by design).
        text += "\n_OPEN_: anyone with the link receives the file. No gate.\n"
    else:  # FORCE_JOIN
        # b10 §28 (B10-W3) ROOT CAUSE (bot-10.log byte-exact): Telegram's
        # legacy-Markdown entity scan does NOT honor backslash escapes while
        # hunting the italic closer — the old FORCE_JOIN italic tail (raw
        # opener + escaped middle + raw closer) left the FINAL underscore
        # dangling → "Can't parse entities: can't find end of the entity
        # starting at byte offset 177" (payload 783: Watch Ads ✅ Enabled +
        # FORCE_JOIN + routing id b5287f04). md_code_span renders the label
        # as an unbreakable code span (the same discipline as the *Payload:*
        # line above) — NO underscore entity at all, so the plain-text
        # fallback never fires on this panel again.
        text += ("\n" + md_code_span("FORCE_JOIN")
                 + ": users must join required channels first.\n")

    # NETWORK (v29, spec §17): Global Payload Link management on the payload
    # detail — the network-level link (opaque signed code, health-aware
    # routing through ANY active network bot).
    try:
        _glinks = await db.get_global_links_for_payload(int(payload_id))
        _gactive = [g for g in _glinks if int(g["active"] or 0)]
        buttons.append([InlineKeyboardButton(
            "\U0001F517 Global Link: "
            + (f"{len(_gactive)} active" if _gactive else "Create"),
            callback_data=f"{NET_GPL_CB}gen:{payload_id}")])
    except Exception:  # noqa: BLE001 — never break the detail panel
        pass

    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"pldetail:{payload_id}")])
    await safe_edit_text(update.callback_query, text,
                         parse_mode=ParseMode.MARKDOWN, reply_markup=InlineKeyboardMarkup(buttons))



async def access_policy_select_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                      payload_id: int) -> None:
    """Policy chooser: OPEN / FORCE_JOIN / FORCE_JOIN_REFERRAL."""
    row = await db.get_payload_by_id(payload_id)
    if not row:
        await safe_answer_callback(update.callback_query, "Payload not found.", show_alert=True)
        return
    policy = row["access_policy"] if "access_policy" in row.keys() else None
    if not policy:
        policy = await db.get_access_policy(payload_id)
    rows: List[List[InlineKeyboardButton]] = []
    for p in (ACCESS_POLICY_OPEN, ACCESS_POLICY_FORCE_JOIN, ACCESS_POLICY_FORCE_JOIN_REFERRAL):
        mark = "\u2713 " if p == policy else ""
        rows.append([InlineKeyboardButton(f"{mark}{_policy_short_label(p)}",
                                          callback_data=f"plgsetpolicy:{payload_id}:{p}")])
    rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"plgate:{payload_id}")])
    # b10 §28 (B10-W3): policy labels render as md_code_span code spans —
    # the legacy parser ignores `\_` escapes inside entity scans, and this
    # list previously carried an ODD number of escaped underscores
    # (FORCE\_JOIN + FORCE\_JOIN\_REFERRAL = 3), a latent dangling-entity
    # under the same proven-broken model. Code spans are unbreakable.
    await safe_edit_text(update.callback_query,
        "*\u2699\uFE0F Access Policy*\n\nChoose the authorization policy for this payload.\n\n"
        "\u2022 OPEN \u2014 no gate\n"
        "\u2022 " + md_code_span("FORCE_JOIN") + " \u2014 require channels\n"
        "\u2022 " + md_code_span("FORCE_JOIN_REFERRAL")
        + " \u2014 channels + referral unlock",
        parse_mode=ParseMode.MARKDOWN, reply_markup=InlineKeyboardMarkup(rows))



async def access_required_referrals_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                           payload_id: int) -> None:
    """Required-referrals chooser (presets + custom)."""
    campaign = await db.get_referral_campaign_by_payload(payload_id)
    required = int(campaign["required_referrals"]) if campaign else REFERRAL_REQUIRED_DEFAULT
    rows: List[List[InlineKeyboardButton]] = []
    for n in REFERRAL_REQUIRED_PRESETS:
        mark = "\u2713 " if n == required else ""
        rows.append([InlineKeyboardButton(f"{mark}{n}", callback_data=f"plgsetreqn:{payload_id}:{n}")])
    rows.append([InlineKeyboardButton("\u2328\uFE0F Custom Number",
                                      callback_data=f"plgsetreqcustom:{payload_id}")])
    rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"plgate:{payload_id}")])
    await safe_edit_text(update.callback_query,
        "*\U0001F522 Required Referrals*\n\n"
        "0 = instant unlock (no referrals needed).\n"
        f"Current: {required}",
        parse_mode=ParseMode.MARKDOWN, reply_markup=InlineKeyboardMarkup(rows))



async def access_preview_mode_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                     payload_id: int) -> None:
    """Preview mode chooser — offers the SAME 6 modes as the wizard.

    The protected payload file is NEVER used as the preview. Auto Preview
    auto-detects compatible media (photo/video/animation) from the payload's
    files; Select lets the admin choose a specific collection file; Custom
    uploads arbitrary media; Description is text-only; Disabled shows nothing.
    """
    campaign = await db.get_referral_campaign_by_payload(payload_id)
    payload_row = await db.get_payload_by_id(payload_id)
    # V26 (message-872 identity fix): the CANONICAL collection predicate —
    # a single-file payload whose name begins with 'c' is NOT a collection
    # (the naive startswith produced a phantom "Select Collection File"
    # mode + an oversize managefiles callback for exactly those payloads).
    is_collection = bool(payload_row and is_collection_link(
        str(payload_row["payload"])))
    cur_mode = campaign["preview_mode"] if campaign else PREVIEW_MODE_DISABLED
    has_desc = bool(campaign and _safe_row_get(campaign, "preview_description"))
    # V5: Show the RESOLVED preview (not the raw stored mode) so the admin sees
    # the effective state, including auto-preview self-healing results.
    resolved_text = "\u2014 none"
    if campaign:
        r = await _resolve_campaign_preview(campaign, payload_row)
        if r["file_id"]:
            resolved_text = f"{r['source'].title()} \u2014 {r['media_type']}"
        elif r["mode"] == PREVIEW_MODE_DESCRIPTION:
            resolved_text = "Description Only"
        elif r["mode"] == PREVIEW_MODE_DISABLED:
            resolved_text = "\u2014 none"
    # Build the mode chooser (mirrors the wizard order).
    mode_labels = {
        PREVIEW_MODE_AUTO: "\U0001F50D Auto Preview",
        PREVIEW_MODE_SELECT: "\U0001F4C2 Select Collection File",
        PREVIEW_MODE_CUSTOM: "\U0001F4E4 Custom Preview Media",
        PREVIEW_MODE_DESCRIPTION: "\U0001F4DD Preview Text",
        PREVIEW_MODE_DISABLED: "\u26D4 Disabled",
    }
    rows: List[List[InlineKeyboardButton]] = []
    for m in (PREVIEW_MODE_AUTO, PREVIEW_MODE_SELECT, PREVIEW_MODE_CUSTOM,
              PREVIEW_MODE_DESCRIPTION, PREVIEW_MODE_DISABLED):
        if m == PREVIEW_MODE_SELECT and not is_collection:
            continue  # Select only applies to collections.
        mark = "\u2713 " if m == cur_mode else ""
        rows.append([InlineKeyboardButton(f"{mark}{mode_labels[m]}",
                                          callback_data=f"plgsetprev:{payload_id}:{m}")])
    media_label = "\u2705 Media set" if campaign and _safe_row_get(campaign, "preview_media_file_id") else "\U0001F4E4 Upload Preview Media"
    desc_label = "\u2705 Text set" if has_desc else "\U0001F4DD Set Preview Text"
    rows.append([InlineKeyboardButton(media_label, callback_data=f"plgprevmedia:{payload_id}")])
    rows.append([InlineKeyboardButton(desc_label, callback_data=f"plgprevdesc:{payload_id}")])
    # BOT6 P6: Add Manage Files button for collection payloads. This is the
    # entry point the admin reported missing from the Preview screen.
    # V26: canonical predicate + the 64-byte callback guard (same fix as
    # the Payload Manager detail panel).
    if is_collection and payload_row:
        coll_code = payload_row["payload"]  # e.g. "c7f3a9b2"
        real_code = parse_collection_link(str(coll_code)) or ""
        if real_code and len(f"managefiles:{real_code}") <= 64:
            rows.append([InlineKeyboardButton("\U0001F4C1 Manage Files",
                                              callback_data=f"managefiles:{real_code}")])
    rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"plgate:{payload_id}")])
    await safe_edit_text(update.callback_query,
        "*\U0001F441 Preview Mode*\n\n"
        f"*Current:* {md_code_span(cur_mode)}\n"
        f"*Resolved:* {escape_md(resolved_text)}\n\n"
        "Choose how users see the locked screen preview.\n"
        "Auto Preview picks the best compatible media automatically.",
        parse_mode=ParseMode.MARKDOWN, reply_markup=InlineKeyboardMarkup(rows))



async def access_analytics_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                  payload_id: int,
                                  back_to: str = "plgate") -> None:
    """Detailed analytics for a referral campaign (SINGLE renderer).

    v26 fixes:
      * `back_to` selects the correct parent panel for the ⬅️ Back button:
          "plgate"     -> Access Policy  (from access_policy_panel / payload
                          details — the legacy `plganalytics:<pid>` route,
                          which remains fully compatible)
          "plgreferral" -> Referral Settings (from referral_settings_panel —
                          the new `plgrefanalytics:<pid>` route)
        Back always returns to the SAME parent the user came from (never a
        dead end, never home).
      * Analytics are BEST-EFFORT: a query failure logs the exception, falls
        back to safe zero values, and STILL renders the panel + Back button
        (an analytics failure can never freeze navigation).
    """
    campaign = await db.get_referral_campaign_by_payload(payload_id)
    if not campaign:
        await safe_answer_callback(update.callback_query, "No campaign for this payload.", show_alert=True)
        return
    # Best-effort analytics (never break the panel on a query failure).
    try:
        analytics = await db.campaign_full_analytics(campaign["id"])
    except Exception as e:  # noqa: BLE001
        logger.warning("Campaign analytics query failed (campaign=%s): %s "
                       "— rendering safe fallback values.", campaign["id"], e)
        analytics = {}
    analytics.setdefault("campaign_views", 0)
    analytics.setdefault("payload_opens", 0)
    analytics.setdefault("preview_views", 0)
    analytics.setdefault("ref_link_opens", 0)
    analytics.setdefault("qualified_referrals", 0)
    analytics.setdefault("unlocks", 0)
    analytics.setdefault("total_participants", 0)
    analytics.setdefault("unlock_rate", 0)
    try:
        top_refs = await db.top_referrers(campaign["id"], limit=10)
    except Exception as e:  # noqa: BLE001
        logger.warning("Top referrers query failed (campaign=%s): %s", campaign["id"], e)
        top_refs = []
    avg_t = analytics.get("avg_unlock_seconds")
    avg_label = f"{int(avg_t)}s" if avg_t is not None else "n/a"
    text = (
        f"*\U0001F4CA Campaign Analytics*\n\n"
        f"*Campaign:* #{campaign['id']}\n"
        f"*Payload:* {md_code_span(campaign['payload_code'])}\n\n"
        f"\U0001F441 Campaign views: {analytics['campaign_views']}\n"
        f"\U0001F4C4 Payload opens: {analytics['payload_opens']}\n"
        f"\U0001F5BC Preview views: {analytics['preview_views']}\n"
        f"\U0001F517 Referral link opens: {analytics['ref_link_opens']}\n"
        f"\u2705 Qualified referrals: {analytics['qualified_referrals']}\n"
        f"\U0001F513 Unlocks: {analytics['unlocks']}\n"
        f"\U0001F465 Participants: {analytics['total_participants']}\n"
        f"\U0001F4C9 Unlock rate: {analytics['unlock_rate']}%\n"
        f"\u23F1 Avg unlock time: {avg_label}\n"
    )
    if top_refs:
        text += "\n*Top Referrers:*\n"
        for i, r in enumerate(top_refs, 1):
            text += f"  {i}. {md_code_span(r['inviter_user_id'])} \u2014 {r['qualified_count']}\n"
    back_cb = (f"plgreferral:{payload_id}" if back_to == "plgreferral"
               else f"plgate:{payload_id}")
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=back_cb)],
    ])
    await safe_edit_text(update.callback_query, text,
                         parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



async def referral_settings_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                   payload_id: int) -> None:
    """V15: Referral Settings panel for a payload — the dedicated Referral button target.

    Shows referral status, required referrals, qualified referrals, and links to
    Dashboard / Dashboard Media / Watch Preview / Share Settings / Statistics.
    Back returns to Payload Details (via navigation context).
    """
    row = await db.get_payload_by_id(payload_id)
    if not row:
        await safe_answer_callback(update.callback_query, "Payload not found.", show_alert=True)
        await payload_list_panel(update, context)
        return
    campaign = await db.get_referral_campaign_by_payload(payload_id)
    if campaign:
        try:
            analytics = await db.campaign_full_analytics(campaign["id"])
            qualified = analytics["qualified_referrals"]
            unlocks = analytics["unlocks"]
        except Exception:  # noqa: BLE001
            qualified = unlocks = 0
        status = "Enabled" if campaign["enabled"] else "Disabled"
        required = campaign["required_referrals"]
        pm = campaign["preview_mode"] or PREVIEW_MODE_DISABLED
        has_media = bool(_safe_row_get(campaign, "preview_media_file_id"))
    else:
        status = "No campaign"
        required = qualified = unlocks = 0
        pm = "—"
        has_media = False
    text = (
        f"*\U0001F465 Referral Settings*\n\n"
        f"*Payload:* {md_code_span(row['payload'])}\n\n"
        f"\u2022 Status: {escape_md(status)}\n"
        f"\u2022 Required Referrals: {required}\n"
        f"\u2022 Qualified Referrals: {qualified}\n"
        f"\u2022 Unlocks: {unlocks}\n"
        f"\u2022 Preview Mode: {escape_md(pm)}\n"
        f"\u2022 Preview Media: {'set' if has_media else 'none'}"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u2699\uFE0F Access Policy", callback_data=f"plgate:{payload_id}"),
         InlineKeyboardButton("\U0001F3AC Preview", callback_data=f"plgpreview:{payload_id}")],
        [InlineKeyboardButton("\U0001F4CA Statistics", callback_data=f"plgrefanalytics:{payload_id}"),
         InlineKeyboardButton("\U0001F510 Dashboard Editor", callback_data="panel:dashedit")],
        [InlineKeyboardButton("\u2B05\uFE0F Back to Payload", callback_data=f"pldetail:{payload_id}")],
    ])
    await safe_edit_text(update.callback_query, text,
                         parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



async def payload_reset_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                 payload_id: int) -> None:
    """V15: Reset confirmation for the Payload Details Reset button.

    Resets ONLY editable payload configuration (delete timer, one-time, access
    policy overrides). Does NOT delete files, analytics, referral history,
    payload link, or storage. Confirm returns to Payload Details; Cancel returns
    to Payload Details.
    """
    row = await db.get_payload_by_id(payload_id)
    if not row:
        await safe_answer_callback(update.callback_query, "Payload not found.", show_alert=True)
        await payload_list_panel(update, context)
        return
    await safe_edit_text(update.callback_query,
        "*\u26A0\uFE0F Reset Payload?*\n\n"
        "This will restore default settings for this payload:\n"
        "\u2022 Delete timer → inherit global\n"
        "\u2022 One-time → OFF\n\n"
        "This will NOT delete:\n"
        "\u2022 Files\n\u2022 Analytics\n\u2022 Referral History\n"
        "\u2022 Payload Link\n\u2022 Storage\n\n"
        "Are you sure?",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u2705 Confirm", callback_data=f"plgdopreset:{payload_id}")],
            [InlineKeyboardButton("\u274C Cancel", callback_data=f"pldetail:{payload_id}")],
        ]))



async def access_reset_confirm_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                      payload_id: int, action: str) -> None:
    """Confirmation screen for destructive campaign actions.

    action: 'progress' | 'campaign' | 'disable'
      - progress : reset unlock progress for ALL users (history preserved)
      - campaign : reset progress + disable campaign (history preserved)
      - disable  : disable campaign only (progress + history preserved)
    """
    labels = {
        "progress": "\u267B\uFE0F Reset Progress",
        "campaign": "\u267B\uFE0F Reset Campaign",
        "disable": "\U0001F6AB Disable Campaign",
    }
    desc = {
        "progress": "Reset completed_referrals to 0 for ALL users. "
                    "referral_history is PERMANENT and will NOT be deleted.",
        "campaign": "Reset progress to 0 AND disable the campaign. "
                    "referral_history is PERMANENT and will NOT be deleted.",
        "disable": "Disable the campaign (users can no longer unlock). "
                   "Progress and referral_history are preserved.",
    }
    await safe_edit_text(update.callback_query,
        f"*{labels.get(action, action)}*\n\n"
        f"{desc.get(action, '')}\n\n"
        f"Are you sure?",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u2705 Confirm", callback_data=f"plgdoreset:{payload_id}:{action}")],
            [InlineKeyboardButton("\u274C Cancel", callback_data=f"plgate:{payload_id}")],
        ]))
