"""Storage panels — storage channels + stats panels.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



# ---------- STORAGE DASHBOARD ----------
async def storage_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """PHASE 7 (Task 1): Admin Storage Center — the redesigned Storage Panel.

    Clear sections, one screen, every button wired end-to-end:
      📡 Storage Channels   → panel:channels (add/edit/remove/reindex/test)
      🔄 Index / Reindex    → panel:reindex (the 4 reindex modes)
      📊 Index Status       → sc:status (per-channel last-run counters,
                              live cursor, Stop button for the running job)
      📈 Statistics         → sc:stats (files by type, totals, top channel)
      👯 Duplicates         → sc:dups (EXACT duplicates skipped + similar-
                              but-distinct proof — display only, never deletes)
      🧪 Channel Test       → sc:test (per-channel health diagnostic)
      📄 Recent Files       → panel:recent (kept — useful)
    Obsolete/redundant controls are GONE (the old 6-button grid mixed
    Index Health into Reindex; integrity checks now live in Index Status
    per channel). The panel EDITS the existing message (single-dashboard
    standard — never re-sends).
    """
    channels = await db.list_storage_channels()
    active_channels = [c for c in channels if c["is_active"]]
    # Last reindex = most recent last_scan across channels.
    last_scan = None
    for ch in channels:
        ls = ch["last_scan"]
        if ls and (last_scan is None or ls > last_scan):
            last_scan = ls
    total_files = await db.count_indexed_files()
    # PHASE 8 (§10): the Storage Center must distinguish EXACTLY what its
    # numbers mean. 'Indexed files' below is the DB total; the new
    # available/unavailable split + last-verification line come from the
    # reconciliation state — a DB row whose source message is gone is NO
    # LONGER silently presented as an indexable file.
    total_unavailable = 0
    last_verify = None
    verify_issues = 0
    for ch in channels:
        _cid = ch["channel_id"]
        _avail, _unavail = await db.count_indexed_files_by_source_status(_cid)
        total_unavailable += _unavail
        _rep = await _index_load_verify_report(_cid)
        if _rep:
            fin = _rep.get("finished_at")
            if fin and (last_verify is None or fin > last_verify):
                last_verify = fin
            verify_issues += (
                int(_rep.get("source_missing_from_db", 0) or 0)
                + int(_rep.get("orphaned_records", 0) or 0)
                + int(_rep.get("stale_file_ids", 0) or 0)
                + int(_rep.get("broken_payload_refs", 0) or 0))
    # Live index job indicator: the global lock being held means a scan is
    # active right now (any channel).
    index_running = bool(INDEX_GLOBAL_LOCK is not None
                         and INDEX_GLOBAL_LOCK.locked())
    running_hint = ""
    if index_running:
        running_hint = "\n\u25B6\uFE0F An indexing job is running right now — see Index Status."
    health = "\U0001F7E2 Healthy" if active_channels else "\U0001F534 No active channels"
    warning = ""
    if not channels:
        warning = (
            "\n\u26A0\uFE0F *No storage channels configured.*\n"
            "Indexing is disabled. Add a channel to start.\n"
        )
    verify_line = f"\U0001F50D Last verification: {fmt_ts(last_verify)}"
    if last_verify is None:
        verify_line = "\U0001F50D Last verification: never (run Verify Index)"
    elif verify_issues:
        verify_line += f" — \u26A0\uFE0F {verify_issues} issue(s) open (Reconcile)"
    else:
        verify_line += " — \u2705 no issues"
    unavailable_line = ""
    if total_unavailable:
        unavailable_line = (f"\n\U0001F4E1 Unavailable (source gone): {total_unavailable} "
                            "(kept — marked by verification, never deleted)")
    text = (
        "\U0001F5C2 Storage Center\n\n"
        f"\U0001F4E2 Channels: {len(channels)} ({len(active_channels)} active)\n"
        f"\U0001F4C1 Indexed files in DB: {total_files}"
        f"{f' ({total_files - total_unavailable} available)' if total_unavailable else ''}\n"
        f"{unavailable_line}"
        f"\u23F1 Last reindex: {fmt_ts(last_scan)}\n"
        f"{verify_line}\n"
        f"\U0001F49E Health: {health}\n"
        f"\u26A1 Auto reindex: {'ON' if await auto_reindex_active() else 'OFF'} "
        f"(every {AUTO_REINDEX_INTERVAL}s)"
        f"{running_hint}"
        f"{warning}"
    )
    logger.info("STORAGE_CENTER_RENDER channels=%s active=%s files=%s "
                "unavailable=%s verify_issues=%s index_running=%s",
                len(channels), len(active_channels), total_files,
                total_unavailable, verify_issues, 1 if index_running else 0)
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\U0001F4E2 Storage Channels", callback_data="panel:channels")],
        [InlineKeyboardButton("\U0001F504 Index / Reindex", callback_data="panel:reindex")],
        [InlineKeyboardButton("\U0001F4CA Index Status", callback_data="sc:status")],
        [InlineKeyboardButton("\U0001F4C8 Statistics", callback_data="sc:stats")],
        [InlineKeyboardButton("\U0001F9AF Duplicates", callback_data="sc:dups")],
        [InlineKeyboardButton("\U0001F9EA Channel Test", callback_data="sc:test")],
        [InlineKeyboardButton("\U0001F4C4 Recent Files", callback_data="panel:recent")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:main")],
    ])
    await safe_edit_text(update.callback_query, text,
                         parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



async def storage_index_status_panel(update: Update,
                                     context: ContextTypes.DEFAULT_TYPE) -> None:
    """PHASE 7 (Task 1): Index Status / Progress — per channel.

    Shows the persisted last-run counters (indexed / duplicates / no_media /
    protected / missing / errors), the live incremental cursor vs the channel
    high-water message, and a Stop button while a job is running. Integrity
    verification (the old Index Health button) is reachable per channel.
    """
    channels = await db.list_storage_channels()
    lines = ["\U0001F4CA Index Status", ""]
    buttons: List[List[InlineKeyboardButton]] = []
    index_running = bool(INDEX_GLOBAL_LOCK is not None
                         and INDEX_GLOBAL_LOCK.locked())
    if not channels:
        lines.append("No storage channels configured.")
    for ch in channels:
        cid = ch["channel_id"]
        title = ch["title"] or f"Channel {cid}"
        stats = await _index_load_run_summary(cid)
        state = await db.get_reindex_state(cid)
        cursor = state["last_scanned_message_id"] if state else None
        max_msg = await db.max_message_id_for_channel(cid)
        indexed = await db.count_indexed_files_for_channel(cid)
        # PHASE 8 (§10): available/unavailable split + truthful scan status.
        avail, unavail = await db.count_indexed_files_by_source_status(cid)
        status_tag = stats.get("status", "-") if stats else "-"
        status_note = ""
        if stats and stats.get("status") == _idx_engine.SCAN_PARTIAL:
            status_note = " [PARTIAL — resumable]"
        elif stats and stats.get("status") == _idx_engine.SCAN_FAILED:
            status_note = " [FAILED]"
        elif stats and stats.get("status") == _idx_engine.SCAN_STOPPED:
            status_note = " [STOPPED — resumable]"
        unavail_note = f" | \U0001F4E1 {unavail} unavailable" if unavail else ""
        if stats:
            lines.append(
                f"\u2022 {title}\n"
                f"  Indexed in DB: {indexed} ({avail} available{unavail_note})\n"
                f"  Cursor: {cursor if cursor is not None else '—'}"
                f" / {max_msg or '—'}\n"
                f"  Last run: {stats.get('mode', '-')}"
                f" (processed {stats.get('processed', 0)}"
                f"{'/' + str(stats.get('total_range', 0)) if stats.get('total_range') else ''}:"
                f" {stats.get('indexed', 0)} new,"
                f" {stats.get('duplicates', 0)} dup,"
                f" {stats.get('file_ids_refreshed', 0)} id-refresh,"
                f" {stats.get('no_media', 0)} no-media,"
                f" {stats.get('errors', 0)} err)"
                f"{' [STOPPED]' if stats.get('stopped') else ''}{status_note}"
            )
        else:
            lines.append(
                f"\u2022 {title}\n"
                f"  Indexed in DB: {indexed} ({avail} available{unavail_note})\n"
                f"  Cursor: {cursor if cursor is not None else '—'}"
                f" / {max_msg or '—'}\n"
                f"  Last run: never"
            )
        row: List[InlineKeyboardButton] = [
            InlineKeyboardButton(f"\U0001F50D {title}", callback_data=f"sc:statusch:{cid}"),
            InlineKeyboardButton("\U0001F50D Verify", callback_data=f"reidxverify:{cid}")]
        if index_running:
            row.append(InlineKeyboardButton("\u23F9 Stop",
                                            callback_data=f"sc:stop:{cid}"))
        buttons.append(row)
    if index_running:
        lines.append("\n\u25B6\uFE0F Indexing is running — Stop is graceful "
                     "(cursor preserved; the job record makes it resumable).")
    buttons.append([InlineKeyboardButton("\U0001F504 Go to Reindex",
                                         callback_data="panel:reindex")])
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:storage")])
    logger.info("STORAGE_INDEX_STATUS_RENDER channels=%s running=%s",
                len(channels), 1 if index_running else 0)
    await safe_edit_text(update.callback_query, "\n".join(lines),
                         reply_markup=InlineKeyboardMarkup(buttons))



async def storage_stop_index(update: Update, context: ContextTypes.DEFAULT_TYPE,
                             channel_id: int) -> None:
    """PHASE 7 (Task 1): request a GRACEFUL stop of the channel's index job.

    The flag is checked at the next message boundary; the scan then flushes
    its batch, persists the run summary, and updates the cursor — nothing is
    lost, and Reindex resumes from the exact boundary."""
    index_cancel_request(int(channel_id))
    logger.info("BOT6_INDEX_STOP_REQUESTED channel_id=%s admin_id=%s",
                channel_id, update.effective_user.id if update.effective_user else 0)
    await safe_answer_callback(
        update.callback_query,
        "\u23F9 Stop requested — the scan halts at the next message "
        "(progress is preserved).")
    await storage_index_status_panel(update, context)



async def storage_stats_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """PHASE 7 (Task 1): Storage Statistics — indexed files by media type,
    totals, top channel, plus NULL-identity count (fallback safety)."""
    channels = await db.list_storage_channels()
    type_rows = await db.indexed_files_media_type_stats()
    total_files = await db.count_indexed_files()
    null_identity = await db.count_indexed_files_without_unique_id()
    lines = ["\U0001F4C8 Storage Statistics", ""]
    lines.append(f"\U0001F4C1 Total indexed files: {total_files}")
    lines.append(f"\U0001F4E2 Storage channels: {len(channels)}")
    top_channel = ""
    best = -1
    for ch in channels:
        cnt = await db.count_indexed_files_for_channel(ch["channel_id"])
        if cnt > best:
            best = cnt
            top_channel = ch["title"] or f"Channel {ch['channel_id']}"
    if top_channel and best >= 0:
        lines.append(f"\U0001F3C6 Top channel: {top_channel} ({best} files)")
    lines.append("")
    if type_rows:
        lines.append("By type:")
        for r in type_rows:
            mt = r["media_type"] or "unknown"
            lines.append(f"  {media_emoji(mt)} {media_type_label(mt)}: {r['cnt']}"
                         f" (dl {r['downloads']}, views {r['views']})")
    else:
        lines.append("No indexed files yet.")
    if null_identity:
        lines.append(f"\u2139\uFE0F {null_identity} legacy file(s) with NULL identity "
                     "(dedup falls back to channel+message — still exact).")
    # WEBSITE PHASE 2 (v30 part A): metadata coverage — how much of the index
    # can render website cards/players (NULL = legacy row or not provided by
    # the source; NEVER fabricated; a re-index backfills what exists).
    try:
        cov = await db.indexed_files_metadata_coverage()
        if cov["total"]:
            lines.append(
                f"\u2139\uFE0F Website metadata coverage: mime "
                f"{cov['with_mime']}/{cov['total']}, dimensions "
                f"{cov['with_dims']}/{cov['total']}, thumbnails "
                f"{cov['with_thumb']}/{cov['total']} "
                "(re-index a channel to backfill missing values).")
    except Exception as e:  # noqa: BLE001 — stats panel must always render
        logger.debug("metadata coverage stats unavailable: %s", e)
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\U0001F4CA Index Status", callback_data="sc:status")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:storage")],
    ])
    logger.info("STORAGE_STATS_RENDER files=%s channels=%s types=%s",
                total_files, len(channels), len(type_rows))
    await safe_edit_text(update.callback_query, "\n".join(lines), reply_markup=kb)



async def storage_duplicates_panel(update: Update,
                                   context: ContextTypes.DEFAULT_TYPE) -> None:
    """PHASE 7 (Task 1): Duplicate Detection — deterministic, display-only.

    Two sections, both derived from the SAME identity the indexer uses:
      1. EXACT duplicates: messages skipped during the last runs because
         their Telegram file_unique_id was ALREADY indexed (identical file
         content re-posted). Per-channel counters from the persisted run
         summaries + the DB-wide exact-identity guarantee.
      2. Similar but DISTINCT: files with the same type+size but DIFFERENT
         identities — listed to make it explicit that the indexer keeps ALL
         of them (similar is NOT duplicate).

    NOTHING is ever deleted, replaced or merged here — payload/file
    references are never touched. Duplicate decisions are deterministic
    (file_unique_id), logged (BOT6_INDEX_DUPLICATE / BOT6_INDEX_SKIP) and
    restart-safe (the UNIQUE constraint holds across restarts)."""
    channels = await db.list_storage_channels()
    lines = ["\U0001F9AF Duplicate Detection (exact identity only)", ""]
    total_exact = 0
    for ch in channels:
        stats = await _index_load_run_summary(ch["channel_id"])
        if stats:
            d = int(stats.get("duplicates", 0) or 0)
            total_exact += d
            lines.append(f"\u2022 {ch['title'] or ch['channel_id']}: {d} exact "
                         f"duplicate(s) skipped in last run")
    if total_exact == 0:
        lines.append("No exact duplicates encountered in the last runs.")
    lines.append("")
    like_pairs = await db.count_indexed_files_like_pairs(limit=10)
    lines.append("Similar but DISTINCT (kept — never merged):")
    if like_pairs:
        for p in like_pairs:
            lines.append(f"  \u2022 {p['cnt']} files, type={p['media_type']}, "
                         f"size={format_size(p['file_size'])} — "
                         f"{p['distinct_ids']} distinct identities")
        lines.append("\n\u2705 Same size/type NEVER counts as duplicate — "
                     "only exact file_unique_id identity does.")
    else:
        lines.append("  (none — no same-size/type groups with distinct "
                     "identities exist)")
    lines.append("\n\u2139\uFE0F Display only. No file is ever deleted or "
                 "replaced by duplicate detection.")
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\U0001F4CA Index Status", callback_data="sc:status")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:storage")],
    ])
    logger.info("STORAGE_DUPLICATES_RENDER exact_last_runs=%s similar_groups=%s",
                total_exact, len(like_pairs))
    await safe_edit_text(update.callback_query, "\n".join(lines), reply_markup=kb)



async def storage_channel_test_panel(update: Update,
                                     context: ContextTypes.DEFAULT_TYPE) -> None:
    """PHASE 7 (Task 1): Channel Test / Health picker — per-channel
    diagnostics (access, media count, cursor, last run)."""
    channels = await db.list_storage_channels()
    lines = ["\U0001F9EA Channel Test / Health", "",
             "Pick a channel to run the diagnostic:"]
    buttons: List[List[InlineKeyboardButton]] = []
    if not channels:
        lines.append("No storage channels configured.")
    for ch in channels:
        title = ch["title"] or f"Channel {ch['channel_id']}"
        status = "\u2705" if ch["is_active"] else "\u23F8"
        buttons.append([InlineKeyboardButton(
            f"{status} {title}",
            callback_data=f"sc:testch:{ch['channel_id']}")])
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:storage")])
    await safe_edit_text(update.callback_query, "\n".join(lines),
                         reply_markup=InlineKeyboardMarkup(buttons))



async def storage_channel_test_run(update: Update,
                                   context: ContextTypes.DEFAULT_TYPE,
                                   channel_id: int) -> None:
    """PHASE 7 (Task 1): the actual per-channel storage diagnostic.

    Checks (all read-only, no state changes):
      * get_chat accessibility + bot membership in the storage channel
      * latest message probe (reachable history)
      * DB side: indexed count, cursor, last-run summary
    Rendered as a persistent editable panel (admin diagnostics are never
    auto-deleted per the §18 auto-delete rules)."""
    bot = context.bot
    cid = int(channel_id)
    ch = await db.get_storage_channel(cid)
    title = (ch["title"] if ch else None) or f"Channel {cid}"
    lines = [f"\U0001F9EA Channel Test — {title}", ""]
    # 1) Accessibility.
    access = "\u2705 accessible"
    chat_kind = "-"
    try:
        chat = await bot.get_chat(cid)
        chat_kind = chat.type if chat else "-"
        if chat and chat.title and (not ch or not ch["title"]):
            lines.append(f"(title from Telegram: {chat.title})")
    except TelegramError as e:
        access = f"\u274C {type(e).__name__}: {str(e)[:80]}"
    except Exception as e:  # noqa: BLE001
        access = f"\u274C error: {type(e).__name__}"
    lines.append(f"Bot access: {access}")
    lines.append(f"Chat type: {chat_kind}")
    # 2) Latest message probe.
    latest_probe = "\u26A0\uFE0F skipped (no admin chat context)"
    admin_id = update.effective_user.id if update.effective_user else None
    if admin_id:
        try:
            latest = await determine_latest_message_id(bot, admin_id, cid)
            latest_probe = (f"\u2705 latest message = {latest}"
                            if latest is not None
                            else "\u26A0\uFE0F channel empty / not probeable")
        except TelegramError as e:
            latest_probe = f"\u274C probe failed: {type(e).__name__}"
        except Exception as e:  # noqa: BLE001
            latest_probe = f"\u274C probe error: {type(e).__name__}"
    lines.append(f"History probe: {latest_probe}")
    # 3) DB side.
    indexed = await db.count_indexed_files_for_channel(cid)
    state = await db.get_reindex_state(cid)
    cursor = state["last_scanned_message_id"] if state else None
    stats = await _index_load_run_summary(cid)
    lines.append(f"Indexed in DB: {indexed}")
    lines.append(f"Cursor: {cursor if cursor is not None else '—'}")
    if stats:
        lines.append(f"Last run: {stats.get('mode', '-')} at "
                     f"{str(stats.get('finished_at', '-'))[:19]}")
        if stats.get("errors"):
            lines.append(f"\u26A0\uFE0F last run had {stats['errors']} error(s)")
    lines.append("\n\u2139\uFE0F Read-only diagnostic — nothing changed.")
    logger.info("STORAGE_CHANNEL_TEST channel_id=%s access=%s kind=%s "
                "indexed=%s cursor=%s",
                cid, access.split(" ", 1)[0], chat_kind, indexed,
                cursor if cursor is not None else "-")
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\U0001F504 Reindex This Channel",
                              callback_data=f"reidxmode:{cid}")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="sc:test")],
    ])
    await safe_edit_text(update.callback_query, "\n".join(lines), reply_markup=kb)



# ---------- CHANNELS PANEL (storage channel management) ----------
async def channels_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    channels = await db.list_storage_channels()
    lines = ["*\U0001F4E2 Storage Channels*", ""]
    buttons: List[List[InlineKeyboardButton]] = []
    if channels:
        for ch in channels:
            status = "\u2705" if ch["is_active"] else "\u23F8"
            cnt = await db.count_indexed_files_for_channel(ch["channel_id"])
            label = f"{status} {ch['title'] or ch['channel_id']} ({cnt} files)"
            buttons.append([InlineKeyboardButton(label, callback_data=f"chdetail:{ch['channel_id']}")])
    else:
        lines.append("None configured.")
    buttons.append([InlineKeyboardButton("\u2795 Add Channel", callback_data="ch:add")])
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:storage")])
    await safe_edit_text(update.callback_query, 
        "\n".join(lines), parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(buttons)
    )



async def channel_detail_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                channel_id: int) -> None:
    ch = await db.get_storage_channel(channel_id)
    if not ch:
        await safe_answer_callback(update.callback_query, "Channel not found.", show_alert=True)
        return
    cnt = await db.count_indexed_files_for_channel(channel_id)
    status = "Active" if ch["is_active"] else "Disabled"
    # Use channel title as primary identifier, hide raw ID
    display_name = ch['title'] or f"Channel {channel_id}"
    text = (
        f"*\U0001F4E2 {display_name}*\n\n"
        f"*Status:* {status}\n"
        f"*Files indexed:* {cnt}\n"
        f"*Last scan:* {fmt_ts(ch['last_scan'])}\n"
        f"*Added:* {fmt_ts(ch['added_at'])}"
    )
    toggle_label = "\u23F8 Disable" if ch["is_active"] else "\u2705 Enable"
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\U0001F504 Reindex", callback_data=f"chreindex:{channel_id}")],
        [InlineKeyboardButton(toggle_label, callback_data=f"chtoggle:{channel_id}"),
         InlineKeyboardButton("\u274C Remove", callback_data=f"chrem:{channel_id}")],
        # Issue 23: Clear Indexed Files (channel-scoped). Confirmation step below.
        [InlineKeyboardButton("\U0001F5D1 Clear Indexed Files",
                              callback_data=f"chclearidx:{channel_id}")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:channels")],
    ])
    await safe_edit_text(update.callback_query, text,
                         parse_mode=ParseMode.MARKDOWN, reply_markup=kb)
