"""Broadcast — broadcast engine, scheduler, panels.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations

from app.presentation.telegram.guards import admin_only



# ============================================================
# BROADCAST SYSTEM  (merged + adapted from old bot's stable worker)
# ============================================================
async def _broadcast_send_one(bot, target_id: int, job: aiosqlite.Row) -> Optional[int]:
    """Send a single broadcast to one user. Returns sent message_id or None."""
    text = job["text_content"]
    media_id = job["media_id"]
    media_type = job["media_type"]
    protect = bool(job["protect_content"])
    kw = {"protect_content": protect} if protect else {}
    try:
        if media_id and media_type:
            if media_type == "photo":
                sent = await bot.send_photo(target_id, media_id, caption=text, **kw)
            elif media_type == "video":
                sent = await bot.send_video(target_id, media_id, caption=text, **kw)
            elif media_type == "document":
                sent = await bot.send_document(target_id, media_id, caption=text, **kw)
            elif media_type == "audio":
                sent = await bot.send_audio(target_id, media_id, caption=text, **kw)
            elif media_type == "voice":
                sent = await bot.send_voice(target_id, media_id, caption=text, **kw)
            elif media_type == "animation":
                sent = await bot.send_animation(target_id, media_id, caption=text, **kw)
            else:
                sent = await bot.send_document(target_id, media_id, caption=text, **kw)
        elif job["source_chat_id"] and job["source_message_id"]:
            sent = await bot.copy_message(
                target_id, job["source_chat_id"], job["source_message_id"], **kw
            )
        else:
            sent = await bot.send_message(target_id, text or "Broadcast", **kw)
        if sent and getattr(sent, "message_id", None):
            return sent.message_id
        return None
    except Forbidden:
        return None
    except RetryAfter as e:
        await asyncio.sleep(e.retry_after + 1)
        return None
    except (TimedOut, NetworkError):
        return None
    except TelegramError:
        return None



async def execute_broadcast(bot, job: aiosqlite.Row, recipient_ids: List[int],
                             status_msg: Optional[Message] = None) -> Tuple[int, int]:
    """Background broadcast worker with bounded concurrency (adapted from old bot).

    Returns (ok_count, fail_count). Non-blocking, race-safe, RetryAfter-aware.
    """
    total = len(recipient_ids)
    ok = 0
    fail = 0
    delete_after = int(job["delete_after"] or 0)
    deletion_batch: List[Tuple[int, int, str]] = []
    processed = 0
    last_status_update = 0.0

    sem = asyncio.Semaphore(BROADCAST_CONCURRENCY)
    counter_lock = asyncio.Lock()

    async def send_to_one(tgt: int) -> Tuple[Optional[int], Optional[str]]:
        async with sem:
            for attempt in range(BROADCAST_MAX_RETRIES):
                result = await _broadcast_send_one(bot, tgt, job)
                if result is not None:
                    return result, None
                # None result: could be transient. Retry once for non-Forbidden.
                if attempt < BROADCAST_MAX_RETRIES - 1:
                    await asyncio.sleep(2 ** attempt)
            return None, "Max retries exhausted"

    async def worker(queue: asyncio.Queue) -> None:
        nonlocal ok, fail, processed, last_status_update
        while True:
            tgt = await queue.get()
            if tgt is None:
                return
            try:
                result, _err = await send_to_one(tgt)
            except asyncio.CancelledError:
                raise
            batch_to_flush: Optional[List[Tuple[int, int, str]]] = None
            do_status_update = False
            snap_processed = 0
            snap_ok = 0
            snap_fail = 0
            async with counter_lock:
                processed += 1
                snap_processed = processed
                if result is not None:
                    ok += 1
                    snap_ok = ok
                    snap_fail = fail
                    if delete_after and delete_after > 0:
                        deletion_batch.append(
                            (tgt, result,
                             (datetime.now(timezone.utc) + timedelta(seconds=delete_after)).isoformat())
                        )
                        if len(deletion_batch) >= BROADCAST_BATCH_SIZE:
                            batch_to_flush = deletion_batch[:]
                            deletion_batch.clear()
                else:
                    fail += 1
                    snap_fail = fail
                    snap_ok = ok
                if (status_msg is not None and snap_processed > 0
                        and snap_processed % BROADCAST_PROGRESS_EVERY == 0
                        and (time.monotonic() - last_status_update) > 3):
                    last_status_update = time.monotonic()
                    do_status_update = True
            if batch_to_flush:
                try:
                    await db.bulk_save_pending_deletions(batch_to_flush)
                except Exception as e:  # noqa: BLE001
                    logger.error("Broadcast deletion flush failed: %s", e)
            if do_status_update:
                # BOT7 Broadcast UI upgrade: percentage + progress bar.
                _pct = int(snap_processed * 100 / total) if total else 0
                _bar = "▓" * (_pct // 10) + "░" * (10 - _pct // 10)
                try:
                    await safe_edit_text(bot, 
                        chat_id=status_msg.chat_id,
                        message_id=status_msg.message_id,
                        text=(f"📣 Broadcasting…\n\n[{_bar}] {_pct}%\n"
                              f"Processed: {snap_processed}/{total}\n"
                              f"✅ Sent: {snap_ok}   ❌ Failed: {snap_fail}"),
                    )
                except TelegramError:
                    pass
            await asyncio.sleep(BROADCAST_SEND_DELAY)

    queue: asyncio.Queue = asyncio.Queue()
    for tgt in recipient_ids:
        await queue.put(tgt)
    for _ in range(BROADCAST_CONCURRENCY):
        await queue.put(None)

    workers = [asyncio.create_task(worker(queue)) for _ in range(BROADCAST_CONCURRENCY)]
    try:
        await asyncio.gather(*workers, return_exceptions=True)
    except asyncio.CancelledError:
        for w in workers:
            if not w.done():
                w.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        raise
    finally:
        async with counter_lock:
            remaining = deletion_batch[:] if deletion_batch else []
            deletion_batch.clear()
        if remaining:
            try:
                await db.bulk_save_pending_deletions(remaining)
            except Exception as e:  # noqa: BLE001
                logger.error("Final flush of broadcast deletions failed: %s", e)

    if status_msg:
        # BOT7 Broadcast UI upgrade: completion text with success rate.
        _rate = int(ok * 100 / total) if total else 0
        try:
            await safe_edit_text(bot, 
                chat_id=status_msg.chat_id,
                message_id=status_msg.message_id,
                text=(f"✅ Broadcast Finished\n\n"
                      f"✅ Sent: {ok}\n❌ Failed: {fail}\n📈 Success rate: {_rate}%"),
            )
        except TelegramError:
            pass
            
    # FIX 1: Increment by 1 per broadcast campaign, not by the number of recipients
    await db.increment_stat("broadcast_count", 1)
    
    # FIX 2: Update the database status to 'Completed' so it reflects in stats and survives restarts
    await db.set_broadcast_status(job["id"], "Completed")
    
    logger.info("Broadcast %d completed: %d sent, %d failed out of %d",
                job["id"], ok, fail, total)
    return ok, fail



async def _broadcast_one_source(bot, source_chat_id: int, source_message_id: int,
                                recipients: List[int],
                                status_msg: Optional[Message], protect: int) -> Tuple[int, int]:
    """Create + execute one broadcast job that EXACT-copies a single source
    message to every recipient (via copy_message). Returns (ok, fail) counts.

    copy_message preserves all entities, captions, media types (text, photo,
    video, document, animation, audio, voice, sticker, video_note) and reply
    markup — a true exact copy (Issue 11).

    BOT7 Broadcast UI upgrade: the caller now aggregates per-part results to
    render a combined final summary. DB behavior is unchanged."""
    job_id = await db.create_scheduled_broadcast(
        send_at=_now_iso(),
        text_content=None,
        media_id=None,
        media_type=None,
        source_chat_id=source_chat_id,
        source_message_id=source_message_id,
        protect_content=protect,
        delete_after=0,
    )
    job_row = await db.get_scheduled_broadcast(job_id)
    await db.set_broadcast_status(job_id, "Processing")
    ok, fail = await execute_broadcast(bot, job_row, recipients, status_msg)
    return ok, fail



def _broadcast_kind_label(m) -> str:
    """Human label for a broadcast source message (BOT7 Broadcast UI upgrade)."""
    if getattr(m, "media_group_id", None):
        return "Album part"
    if getattr(m, "photo", None):
        return "Photo"
    if getattr(m, "video", None):
        return "Video"
    if getattr(m, "animation", None):
        return "Animation"
    if getattr(m, "document", None):
        return "Document"
    if getattr(m, "audio", None):
        return "Audio"
    if getattr(m, "voice", None):
        return "Voice"
    if getattr(m, "video_note", None):
        return "Video note"
    if getattr(m, "sticker", None):
        return "Sticker"
    if getattr(m, "text", None):
        return "Text"
    return "Message"



def _broadcast_preview_text(m, limit: int = 350) -> str:
    """Short plain-text preview of a broadcast source message."""
    txt = (getattr(m, "text", None) or getattr(m, "caption", None) or "").strip()
    if not txt:
        return "(no text / caption)"
    if len(txt) > limit:
        return txt[:limit] + "…"
    return txt



async def send_broadcast_now(update: Update, context: ContextTypes.DEFAULT_TYPE,
                             messages: Optional[List[Message]] = None) -> None:
    """Compose an immediate broadcast as an EXACT copy of the admin's message(s).

    Issue 11: the admin may send ANY Telegram message (text, photo, video,
    document, animation, audio, voice, sticker, video_note, captioned media).
    Albums (media groups) are copied part-by-part so the whole album is
    delivered.

    BOT7 Broadcast UI upgrade: instead of broadcasting instantly, this now
    shows a PREVIEW + CONFIRMATION card (recipient count, per-part preview,
    protection notice). The actual send happens in _bcast_confirm_execute()
    when the admin presses "Confirm" — reusing the exact same worker path
    (create_scheduled_broadcast → execute_broadcast) as before. No existing
    callback or DB behavior changed."""
    if not context.user_data.get("awaiting_broadcast"):
        return
    context.user_data.pop("awaiting_broadcast", None)
    if messages is None:
        msg = update.effective_message
        messages = [msg] if msg else []
    if not messages:
        return
    try:
        recipients = await db.all_user_ids()
    except Exception as e:  # noqa: BLE001
        logger.error("Broadcast recipient lookup failed: %s", e)
        recipients = []
    chat_id = update.effective_chat.id
    if not recipients:
        await safe_send_text(
            context.bot, chat_id,
            "❌ No users to broadcast to yet — nobody has started the bot.",
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("⬅️ Back", callback_data="panel:broadcast")]]),
        )
        return

    # Store the pending broadcast for the bcast:confirm callback.
    parts = []
    for m in messages:
        parts.append({
            "chat_id": m.chat_id,
            "message_id": m.message_id,
            "kind": _broadcast_kind_label(m),
            "preview": _broadcast_preview_text(m),
        })
    context.user_data["bcast_pending"] = parts

    n_users = len(recipients)
    protect = 1 if (await protect_internal_active()) else 0
    lines = [
        "📤 BROADCAST PREVIEW",
        "━━━━━━━━━━━━━━━━━━",
        f"📦 Content: {len(parts)} message(s)",
    ]
    for i, p in enumerate(parts[:3], 1):
        pv = p["preview"].replace("\n", " ")
        if len(pv) > 120:
            pv = pv[:120] + "…"
        lines.append(f"  {i}. {p['kind']}: {pv}")
    if len(parts) > 3:
        lines.append(f"  … and {len(parts) - 3} more message(s)")
    lines += [
        f"👥 Recipients: {n_users} user(s)",
        f"🛡 Protection: {'ON (copies cannot be forwarded/saved)' if protect else 'OFF'}",
        "━━━━━━━━━━━━━━━━━━",
        "Each recipient gets an exact copy of the message(s) above.",
        "",
        "Send this broadcast now?",
    ]
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton(f"✅ Confirm & Send to {n_users} users",
                              callback_data="bcast:confirm")],
        [InlineKeyboardButton("❌ Cancel", callback_data="bcast:cancel")],
    ])
    await safe_send_text(context.bot, chat_id, "\n".join(lines), reply_markup=kb)



async def _bcast_confirm_execute(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Execute the broadcast after the admin confirms the preview card.

    BOT7 Broadcast UI upgrade: same execution path as the previous
    instant-send flow (_broadcast_one_source → execute_broadcast), with
    aggregated per-part results in the final summary and explicit error
    handling. The confirmation card message becomes the progress/status
    message (edited in place)."""
    q = update.callback_query
    parts = context.user_data.pop("bcast_pending", None)
    if not parts:
        # Stale card (e.g. confirm pressed twice / state cleared by a restart).
        await safe_answer_callback(q, "This confirmation has expired.")
        await safe_edit_text(
            q, "❌ This broadcast confirmation has expired — nothing was sent.\n\n"
               "Use Send Broadcast Message to compose a new one.",
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("⬅️ Back", callback_data="panel:broadcast")]]),
        )
        return
    try:
        recipients = await db.all_user_ids()
    except Exception as e:  # noqa: BLE001
        logger.error("Broadcast recipient lookup failed at confirm: %s", e)
        await safe_answer_callback(q, "Database error — broadcast aborted.")
        await safe_edit_text(
            q, "❌ Broadcast aborted: could not load recipients. Please try again.",
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("⬅️ Back", callback_data="panel:broadcast")]]),
        )
        return
    if not recipients:
        await safe_answer_callback(q, "No users to broadcast to.")
        await safe_edit_text(
            q, "❌ No users to broadcast to yet — nobody has started the bot.",
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("⬅️ Back", callback_data="panel:broadcast")]]),
        )
        return

    await safe_answer_callback(q, "Broadcast starting…")
    protect = 1 if (await protect_internal_active()) else 0
    n_parts = len(parts)
    status = q.message  # edit the confirmation card in place
    await safe_edit_text(
        context.bot,
        chat_id=status.chat_id, message_id=status.message_id,
        text=(f"📣 Broadcasting {n_parts} message(s) to {len(recipients)} users…\n"
              f"Progress: 0/{len(recipients)}"),
    )
    total_ok = 0
    total_fail = 0
    failed_parts: List[int] = []
    for idx, p in enumerate(parts):
        st = status if idx == 0 else None
        try:
            ok, fail = await _broadcast_one_source(
                context.bot, p["chat_id"], p["message_id"],
                recipients, st, protect,
            )
            total_ok += ok
            total_fail += fail
            if ok == 0:
                failed_parts.append(idx + 1)
        except Exception as e:  # noqa: BLE001
            logger.error("Broadcast source %d failed: %s", idx, e)
            failed_parts.append(idx + 1)
    # Final summary (overwrites the per-job completion text for clarity).
    attempts = n_parts * len(recipients)
    rate = int(total_ok * 100 / attempts) if attempts else 0
    summary_lines = [
        "✅ BROADCAST COMPLETED",
        "━━━━━━━━━━━━━━━━━━",
        f"📦 Messages: {n_parts}",
        f"👥 Recipients: {len(recipients)}",
        f"✅ Delivered: {total_ok}",
        f"❌ Failed: {total_fail}",
        f"📈 Success rate: {rate}%",
    ]
    if failed_parts:
        summary_lines.append(
            f"\n⚠️ All deliveries failed for part(s) {failed_parts} — "
            "the source message may have been deleted."
        )
    summary_lines.append("\nFailed usually means the user blocked the bot.")
    await safe_edit_text(
        context.bot,
        chat_id=status.chat_id, message_id=status.message_id,
        text="\n".join(summary_lines),
    )



async def _process_broadcast_album_delayed(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                            media_group_id: str) -> None:
    """Wait for all album messages, then broadcast the whole album as exact
    copies (one copy per part per user)."""
    await asyncio.sleep(FORWARD_BATCH_WAIT)
    batch_key = f"bcast_batch_{media_group_id}"
    timer_key = f"{batch_key}_timer"
    if not context.user_data.get(timer_key):
        return  # a newer timer is running
    context.user_data.pop(timer_key, None)
    batch = context.user_data.pop(batch_key, [])
    if not batch:
        return
    logger.info("Processing broadcast album: %d parts, media_group_id=%s",
                len(batch), media_group_id)
    await send_broadcast_now(update, context, messages=batch)



@admin_only
async def schedule_broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/schedulebroadcast YYYY-MM-DD HH:MM TEXT...  (admin-only)"""
    args = context.args
    if len(args) < 2:
        await reply_protected(update, 
            "Usage: `/schedulebroadcast YYYY-MM-DD HH:MM Your message text`",
            parse_mode=ParseMode.MARKDOWN,
        )
        return
    date_str = args[0]
    time_str = args[1]
    text = " ".join(args[2:]) if len(args) > 2 else None
    try:
        dt = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc)
    except ValueError:
        await reply_protected(update, 
            "Invalid date/time. Use `YYYY-MM-DD HH:MM` (UTC).", parse_mode=ParseMode.MARKDOWN
        )
        return
    if dt < datetime.now(timezone.utc):
        await reply_protected(update, "\u274C Scheduled time is in the past.")
        return
    protect = 1 if (await protect_internal_active()) else 0
    bcast_id = await db.create_scheduled_broadcast(
        send_at=dt.strftime("%Y-%m-%d %H:%M"),
        text_content=text,
        protect_content=protect,
    )
    await reply_protected(update, 
        f"*\u23F3 Broadcast scheduled!*\n\n*ID:* {bcast_id}\n*Send at:* {dt.strftime('%Y-%m-%d %H:%M')} UTC\n"
        f"*Text:* {text or '(none)'}",
        parse_mode=ParseMode.MARKDOWN,
    )



@admin_only
async def cancelscheduled_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, 
            "Usage: `/cancelbroadcast ID`", parse_mode=ParseMode.MARKDOWN
        )
        return
    try:
        bcast_id = int(context.args[0])
    except ValueError:
        await reply_protected(update, "ID must be a number.")
        return
    ok = await db.cancel_scheduled_broadcast(bcast_id)
    if ok:
        await reply_protected(update, f"\u2705 Broadcast {bcast_id} cancelled.")
    else:
        await reply_protected(update, "Broadcast not found or not pending.")



@admin_only
async def broadcastlist_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    rows = await db.list_all_broadcasts(limit=20)
    if not rows:
        await reply_protected(update, "No broadcasts yet.")
        return
    lines = ["*Broadcasts*", ""]
    for r in rows:
        preview = (r["text_content"] or "(media only)")[:40]
        lines.append(f"\u2022 #{r['id']} [{r['status']}] {r['send_at']} - {preview}")
    await reply_protected(update, "\n".join(lines), parse_mode=ParseMode.MARKDOWN)



async def broadcast_scheduler_loop(bot) -> None:
    """Background loop that fires due scheduled broadcasts every minute."""
    logger.info("Broadcast scheduler loop started (interval=%ss).", SCHEDULED_BROADCAST_POLL_INTERVAL)
    while True:
        try:
            now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
            due = await db.due_scheduled_broadcasts(now_str)
            for job in due:
                await db.set_broadcast_status(job["id"], "Processing")
                recipients = await db.all_user_ids()
                if not recipients:
                    await db.set_broadcast_status(job["id"], "Completed")
                    continue
                asyncio.create_task(execute_broadcast(bot, job, recipients, None))
        except asyncio.CancelledError:
            logger.info("Broadcast scheduler loop cancelled.")
            break
        except Exception as e:  # noqa: BLE001
            logger.error("Broadcast scheduler loop error: %s", e)
        await asyncio.sleep(SCHEDULED_BROADCAST_POLL_INTERVAL)



# ============================================================
# BROADCAST PANEL
# ============================================================
async def broadcast_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Broadcast panel (Issue 11 + BOT7 Broadcast UI upgrade).

    A single "Send Broadcast Message" action: the admin sends ANY Telegram
    message (text / photo / video / document / animation / audio / voice /
    sticker / video_note / captioned media / album) and it is broadcast as an
    exact copy to every user. The old Text/Media/File sub-buttons are removed.

    BOT7: now shows the live recipient count and recent campaign outcomes.
    All callback data values are unchanged (bcast:send / bcast:scheduled /
    bcast:stats / panel:main)."""
    pending = await db.list_pending_broadcasts(limit=20)
    total = await db.get_stat("broadcast_count", 0)
    try:
        recipients = await db.all_user_ids()
        n_users = len(recipients)
    except Exception as e:  # noqa: BLE001
        logger.error("Broadcast panel recipient lookup failed: %s", e)
        n_users = 0
    try:
        all_b = await db.list_all_broadcasts(limit=100)
        completed = sum(1 for b in all_b if b["status"] == "Completed")
        failed = sum(1 for b in all_b if b["status"] == "Failed")
    except Exception:  # noqa: BLE001
        completed = failed = 0
    # Plain text — no Markdown, so nothing can crash parsing (Issue 1).
    text = (
        "\U0001F4E3 BROADCAST CENTER\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"\U0001F465 Recipients: {n_users} user(s)\n"
        f"\U0001F4E4 Campaigns sent (lifetime): {total}\n"
        f"\u2705 Completed: {completed}   \U0001F534 Failed: {failed}\n"
        f"\u23F0 Pending scheduled: {len(pending)}\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "Send any message type — text, photo, video, document, animation,\n"
        "audio, voice, sticker, video note or a whole album. Every user\n"
        "receives an exact copy. You'll see a preview and confirm before\n"
        "anything is sent."
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\U0001F4E3 Send Broadcast Message", callback_data="bcast:send")],
        [InlineKeyboardButton("\u23F0 Scheduled", callback_data="bcast:scheduled"),
         InlineKeyboardButton("\U0001F4CA Statistics", callback_data="bcast:stats")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:main")],
    ])
    await safe_edit_text(update.callback_query, text, reply_markup=kb)



async def broadcast_stats_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """BOT7 Broadcast UI upgrade: failed campaigns + success rate added.
    Back button callback unchanged (panel:broadcast)."""
    total = await db.get_stat("broadcast_count", 0)
    all_bcasts = await db.list_all_broadcasts(limit=100)
    completed = sum(1 for b in all_bcasts if b["status"] == "Completed")
    pending = sum(1 for b in all_bcasts if b["status"] == "Pending")
    cancelled = sum(1 for b in all_bcasts if b["status"] == "Cancelled")
    failed = sum(1 for b in all_bcasts if b["status"] == "Failed")
    finished = completed + failed
    rate = int(completed * 100 / finished) if finished else 100
    text = (
        "*\U0001F4CA BROADCAST STATISTICS*\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"\U0001F4E4 Campaigns sent (lifetime): {total}\n"
        f"\u2705 Completed: {completed}\n"
        f"\U0001F534 Failed: {failed}\n"
        f"\u23F0 Pending: {pending}\n"
        f"\u274C Cancelled: {cancelled}\n"
        f"\U0001F4C8 Success rate: {rate}%\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "Failed campaigns are marked automatically when the bot restarts\n"
        "mid-send — they are never resent on their own."
    )
    kb = InlineKeyboardMarkup(
        [[InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:broadcast")]]
    )
    await safe_edit_text(update.callback_query, 
        text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb
    )



async def broadcast_scheduled_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """BOT7 Broadcast UI upgrade: status emojis + exact-copy-aware preview.
    Cancel (bcastcancel:{id}) and Back (panel:broadcast) callbacks unchanged."""
    rows = await db.list_all_broadcasts(limit=15)
    status_emoji = {
        "Completed": "\u2705", "Pending": "\u23F0", "Cancelled": "\u274C",
        "Processing": "\U0001F504", "Failed": "\U0001F534",
    }
    lines = ["*\u23F0 SCHEDULED / RECENT BROADCASTS*", "\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501"]
    buttons: List[List[InlineKeyboardButton]] = []
    if not rows:
        lines.append("No broadcasts yet.")
    for r in rows:
        st = r["status"]
        emo = status_emoji.get(st, "\u2022")
        if r["text_content"]:
            preview = r["text_content"][:30]
        elif r["source_message_id"]:
            preview = "(exact-copy message)"
        else:
            preview = "(media only)"
        lines.append(f"{emo} #{r['id']} \u00B7 {st} \u00B7 {r['send_at']}\n    {preview}")
        if st == "Pending":
            buttons.append([InlineKeyboardButton(
                f"\u274C Cancel #{r['id']}",
                callback_data=f"bcastcancel:{r['id']}",
            )])
    lines += ["", "Only Pending broadcasts can be cancelled.",
              "Immediate broadcasts appear here as Completed."]
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:broadcast")])
    await safe_edit_text(update.callback_query, 
        "\n".join(lines), parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(buttons)
    )
