"""WEBSITE VIDEO ADS admin panel (B10-W1 §15/§34/§35) — the ``wspr:``
namespace.

A dedicated admin surface under Control Panel → Website Settings →
"Video Pre-Roll Ads" managing the WEBSITE VIDEO AD layer in the
EXISTING ``bot_settings`` store. app/web/site/video_ads.py owns the
provider-agnostic policy + the two NEW keys (website_videoad_provider,
website_videoad_timeout); app/web/site/preroll.py still owns the shared
v37 keys (enabled/mode/skip_delay/duration/source_url/vast_url/
frequency/session_frequency/cooldown/fallback) — this module is pure
presentation + writes, mirroring the §18A Website Monetag SDK panel
discipline: dedicated setting keys, validate → save, cancel restores,
per-action saves exactly like the other website panels.

§35 separation: this panel manages ONLY the Website video ad layer
(the VAST provider + the direct-media pre-roll). The TMA Watch Ads SDK
panel (watchads.py), the Website Monetag SDK panel (website_ui.py
wsite:) and sw.js are SEPARATE systems and are never touched here.

Integration pattern (identical to wsitecat:/wsad: in
website_gap_ui.py — this module is NOT part of the namespace rebind):
plain functions taking ``(update, context, deps)``; the facades live
in website_admin.py (``_handle_wspr_callback`` / ``_handle_wspr_text``),
registered in _manifest.py SECTION_MEMBERS['website_admin'] and
dispatched admin-gated from callbacks.py. The ``wspr:`` prefix was
verified collision-free (no other handler dispatches it).

Text-input states (v36 hygiene): ``awaiting_wspr_src`` /
``awaiting_wspr_vast`` are registered in state.py
CONVERSATION_INPUT_STATE_KEYS (stamp + 10-minute expiry + single-active
conversation + purge on every non-entry callback). Cancel restores the
previous state (nothing is saved until validation passes); an invalid
URL NEVER overwrites the working value.

Security invariants:
  * admin-only namespace (master admin gate in on_callback, like wsite:);
  * every URL write passes validate_preroll_source_url /
    validate_preroll_vast_url (https-only) BEFORE anything is saved;
  * URLs are NEVER logged (admin action logs carry lengths only);
  * the panel is TRUTHFUL (§34): with no VAST URL and no source URL the
    status line reads exactly "Video Ads: Not Configured" and the panel
    says video ads stay inactive — never a fake "active". No ad
    inventory is fabricated; the honest test verdict is that the ad
    feed itself is only testable in a real browser playback.
"""
from __future__ import annotations

import logging
from typing import Any, List

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from app.web.site.preroll import (
    PREROLL_COOLDOWN_KEY,
    PREROLL_DEFAULT_COOLDOWN,
    PREROLL_DEFAULT_DURATION,
    PREROLL_DEFAULT_SESSION_FREQUENCY,
    PREROLL_DEFAULT_SKIP_DELAY,
    PREROLL_DURATION_KEY,
    PREROLL_ENABLED_KEY,
    PREROLL_FALLBACK_KEY,
    PREROLL_FREQUENCY_KEY,
    PREROLL_MODE_KEY,
    PREROLL_SESSION_FREQUENCY_KEY,
    PREROLL_SKIP_DELAY_KEY,
    PREROLL_SOURCE_URL_KEY,
    PREROLL_VAST_URL_KEY,
    clamp_cooldown,
    clamp_duration,
    clamp_session_frequency,
    clamp_skip_delay,
    normalize_fallback,
    normalize_frequency,
    validate_preroll_source_url,
    validate_preroll_vast_url,
)
from app.web.site.video_ads import (
    PREROLL_PROVIDER_KEY,
    PREROLL_TIMEOUT_KEY,
    VIDEOAD_DEFAULT_PROVIDER,
    VIDEOAD_DEFAULT_TIMEOUT,
    DirectMediaProvider,
    VastAdProvider,
    VideoAdConfig,
    clamp_videoad_timeout,
    normalize_videoad_provider,
    resolve_videoad_mode,
)

logger = logging.getLogger("payload-bot")

# Conversation input state keys (registered in state.py
# ALL_WIZARD_STATES + CONVERSATION_INPUT_STATE_KEYS).
AWAITING_SOURCE_KEY = "awaiting_wspr_src"
AWAITING_VAST_KEY = "awaiting_wspr_vast"

# The parent panel: Website Settings (wsite:settings) — the panel the
# "Video Pre-Roll Ads" entry button lives on. Same dedicated
# parent-callback pattern the §18A Website SDK panel uses
# (panel:wadsettings for that surface).
_PARENT_PANEL_CB = "wsite:settings"

_FREQ_LABELS = {
    "every_video": "Every video",
    "session": "Per session",
    "cooldown": "Cooldown",
}
_MODE_LABELS = {
    "provider_controlled": "Provider-controlled",
    "skippable": "Skippable",
    "non_skippable": "Non-skippable",
}
_PROVIDER_LABELS = {
    "vast": "VAST (HilltopAds or any VAST tag)",
    "direct": "Direct media",
    "none": "None",
}

# §34 — the exact not-configured status wording.
_STATUS_NOT_CONFIGURED = "Video Ads: Not Configured"


def _kb(rows: List[List[InlineKeyboardButton]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(rows)


def _btn(label: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(label, callback_data=data)


def _state_helpers():
    """v36 state helpers — imported lazily (the control_ui pattern:
    state.py's import zone is heavy; the functions below run
    post-initialization only)."""
    from app.presentation.telegram.state import (
        clear_conversation_input_states,
        stamp_conversation_state,
        _conversation_state_expired,
    )
    return (clear_conversation_input_states,
            stamp_conversation_state,
            _conversation_state_expired)


async def _get(db: Any, key: str, default: str = "") -> str:
    try:
        val = await db.get_setting(key)
        return str(val) if val is not None else default
    except Exception:  # noqa: BLE001 — panels must never crash
        return default


async def _set(db: Any, key: str, value: str) -> None:
    await db.set_setting(key, str(value))


async def _read_config(db: Any) -> dict:
    """The live config (clamped exactly like the policy resolves it)."""
    provider = normalize_videoad_provider(
        await _get(db, PREROLL_PROVIDER_KEY, VIDEOAD_DEFAULT_PROVIDER))
    raw_mode = await _get(db, PREROLL_MODE_KEY, "")
    return {
        "provider": provider,
        "enabled": (await _get(db, PREROLL_ENABLED_KEY, "0")).strip()
                   .lower() in ("1", "true", "yes", "on"),
        "mode": resolve_videoad_mode(raw_mode, provider=provider),
        "skip_delay": clamp_skip_delay(
            await _get(db, PREROLL_SKIP_DELAY_KEY,
                       str(PREROLL_DEFAULT_SKIP_DELAY))),
        "duration": clamp_duration(
            await _get(db, PREROLL_DURATION_KEY,
                       str(PREROLL_DEFAULT_DURATION))),
        "source_url": (await _get(db, PREROLL_SOURCE_URL_KEY, "")).strip(),
        "vast_url": (await _get(db, PREROLL_VAST_URL_KEY, "")).strip(),
        "frequency": normalize_frequency(
            await _get(db, PREROLL_FREQUENCY_KEY, "every_video")),
        "session_frequency": clamp_session_frequency(
            await _get(db, PREROLL_SESSION_FREQUENCY_KEY,
                       str(PREROLL_DEFAULT_SESSION_FREQUENCY))),
        "cooldown": clamp_cooldown(
            await _get(db, PREROLL_COOLDOWN_KEY,
                       str(PREROLL_DEFAULT_COOLDOWN))),
        "fallback": normalize_fallback(
            await _get(db, PREROLL_FALLBACK_KEY, "release")),
        "timeout": clamp_videoad_timeout(
            await _get(db, PREROLL_TIMEOUT_KEY,
                       str(VIDEOAD_DEFAULT_TIMEOUT))),
    }


def _config_object(cfg: dict) -> VideoAdConfig:
    """The panel's live config as a VideoAdConfig (for the provider
    validators — §15 'Test configuration' runs the SAME checks the
    policy runs)."""
    return VideoAdConfig(
        provider=cfg.get("provider", VIDEOAD_DEFAULT_PROVIDER),
        vast_url=str(cfg.get("vast_url") or ""),
        source_url=str(cfg.get("source_url") or ""),
        enabled=bool(cfg.get("enabled")),
        mode=str(cfg.get("mode") or "skippable"),
        skip_delay=int(cfg.get("skip_delay") or PREROLL_DEFAULT_SKIP_DELAY),
        duration=int(cfg.get("duration") or PREROLL_DEFAULT_DURATION),
        frequency=str(cfg.get("frequency") or "every_video"),
        session_frequency=int(cfg.get("session_frequency")
                              or PREROLL_DEFAULT_SESSION_FREQUENCY),
        cooldown=int(cfg.get("cooldown") or PREROLL_DEFAULT_COOLDOWN),
        fallback=str(cfg.get("fallback") or "release"),
        timeout=int(cfg.get("timeout") or VIDEOAD_DEFAULT_TIMEOUT),
    )


def _fmt_secs(secs: int) -> str:
    if secs < 60:
        return f"{secs}s"
    if secs < 3600:
        return f"{secs // 60}m" if secs % 60 == 0 \
            else f"{secs // 60}m {secs % 60}s"
    return f"{secs // 3600}h" if secs % 3600 == 0 \
        else f"{secs // 3600}h {(secs % 3600) // 60}m"


def _fmt_url(url: str, max_len: int = 64) -> str:
    url = str(url or "")
    if not url:
        return "\u274C Not Configured"
    if len(url) <= max_len:
        return url
    return url[:max_len - 12] + "\u2026" + url[-12:]


def _status_line(cfg: dict) -> str:
    """The §34 status line (FIRST information line of the panel).

    Truthful in every state: no VAST URL and no source URL → the exact
    "Video Ads: Not Configured" wording (a VAST-selected provider with
    no URL is equally Not Configured); otherwise the configured
    provider + the enabled/disabled state."""
    provider = str(cfg.get("provider") or "none")
    enabled = bool(cfg.get("enabled"))
    state = " — enabled" if enabled else " — disabled"
    if provider == "vast" and not cfg.get("vast_url"):
        return _STATUS_NOT_CONFIGURED
    if not cfg.get("vast_url") and not cfg.get("source_url"):
        return _STATUS_NOT_CONFIGURED
    if provider == "vast":
        return "Video Ads: VAST (provider=vast)" + state
    return "Video Ads: Direct media" + state


# ============================================================
# Panel
# ============================================================
async def preroll_settings_panel(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE,
                                 deps: Any) -> None:
    """The Website Video Ads settings panel (truthful current values;
    every button writes its setting IMMEDIATELY, exactly like the other
    website panels, then re-renders)."""
    db = deps.db
    cfg = await _read_config(db)
    status = _status_line(cfg)
    enabled_line = ("\U0001F7E2 ON — pre-rolls play before website videos"
                    if cfg["enabled"]
                    else "\U0001F534 OFF — no pre-rolls")
    mode_note = ""
    if cfg["mode"] == "provider_controlled":
        mode_note = (" (the VAST skipoffset decides;\n"
                     "direct media degrades to skippable)")
    lines = [
        "\U0001F3AC VIDEO PRE-ROLL ADS (Website)",
        "",
        f"Status: {status}",
        f"Pre-roll: {enabled_line}",
        f"Provider: {_PROVIDER_LABELS.get(cfg['provider'], cfg['provider'])}",
        f"Ad mode: {_MODE_LABELS.get(cfg['mode'], cfg['mode'])}"
        + mode_note
        + (f" (skip after {cfg['skip_delay']}s)"
           if cfg["mode"] == "skippable" else
           f" (max {cfg['duration']}s)" if cfg["mode"] == "non_skippable"
           else ""),
        f"Skip delay: {cfg['skip_delay']}s (1..30)",
        f"Duration: {cfg['duration']}s (5..120, non-skippable max)",
        f"VAST URL: {_fmt_url(cfg['vast_url'])}",
        f"Ad source URL: {_fmt_url(cfg['source_url'])}",
        f"VAST timeout: {cfg['timeout']}s (2..30)",
        "",
        f"Frequency: {_FREQ_LABELS.get(cfg['frequency'], cfg['frequency'])}",
    ]
    if cfg["frequency"] == "session":
        lines.append(f"Session ads: {cfg['session_frequency']} (1..10)")
    elif cfg["frequency"] == "cooldown":
        lines.append(f"Cooldown: {_fmt_secs(cfg['cooldown'])} "
                     "(30s..24h between ads)")
    else:
        lines.append(f"Session ads: {cfg['session_frequency']} (1..10)")
        lines.append(f"Cooldown: {_fmt_secs(cfg['cooldown'])} "
                     "(30s..24h between ads)")
    lines += [
        "",
        "On ad failure: " + (
            "\u25B6\uFE0F Release the content video"
            if cfg["fallback"] == "release" else
            "\u26D4 Block (honest \u201Cad unavailable\u201D message)"),
        "",
        "The pre-roll plays in the website video player",
        "BEFORE the requested video. The decision and the",
        "frequency accounting are SERVER-side; the player",
        "never reports completion back for accounting.",
    ]
    if status == _STATUS_NOT_CONFIGURED:
        lines += [
            "",
            "Set a VAST URL and select the VAST provider,",
            "or set a direct ad source URL (absolute",
            "https:// link to a hosted .mp4/.webm), to",
            "activate video ads.",
        ]
    elif cfg["provider"] == "vast" and cfg["vast_url"]:
        lines += [
            "",
            "\u2139\uFE0F VAST mode: the player fetches the tag and",
            "the ad response decides skippability (mode",
            "Provider-controlled) unless you force a mode.",
        ]
    elif cfg["vast_url"] and cfg["provider"] != "vast":
        lines += [
            "",
            "\u2139\uFE0F A VAST URL is stored but the provider is",
            f"not VAST — switch the provider to VAST to",
            "serve VAST pre-rolls.",
        ]
    rows = [
        [_btn("\U0001F7E2 Disable Pre-Roll Ads" if cfg["enabled"]
              else "\U0001F534 Enable Pre-Roll Ads", "wspr:toggle"),
         _btn("\U0001F50D Preview", "wspr:preview"),
         _btn("\U0001F9EA Test", "wspr:test")],
        [_btn("\U0001F535 Provider: VAST" if cfg["provider"] == "vast"
              else "VAST", "wspr:prov:vast"),
         _btn("\U0001F535 Provider: Direct" if cfg["provider"] == "direct"
              else "Direct", "wspr:prov:direct"),
         _btn("\U0001F535 Provider: None" if cfg["provider"] == "none"
              else "None", "wspr:prov:none")],
        [_btn("\u23ED Mode: " + _MODE_LABELS.get(cfg["mode"], cfg["mode"]),
              "wspr:mode"),
         _btn("\U0001F916 Provider-controlled", "wspr:modeauto")],
        [_btn("\u2796 Skip delay", "wspr:skipdm"),
         _btn(f"\u23F1 {cfg['skip_delay']}s", "wspr:noop"),
         _btn("Skip delay \u2795", "wspr:skipdp")],
        [_btn("\u2796 Duration", "wspr:durm"),
         _btn(f"\u23F1 {cfg['duration']}s", "wspr:noop"),
         _btn("Duration \u2795", "wspr:durp")],
        [_btn("\U0001F4E1 Set/Replace VAST URL", "wspr:vast"),
         _btn("\U0001F5D1 Delete VAST URL", "wspr:vastdel")],
        [_btn("\U0001F517 Set Source URL", "wspr:src")],
        [_btn("\u2796 VAST timeout", "wspr:tm"),
         _btn(f"\u23F1 {cfg['timeout']}s", "wspr:noop"),
         _btn("Timeout \u2795", "wspr:tp")],
        [_btn("\U0001F501 Frequency: "
              + _FREQ_LABELS.get(cfg['frequency'], cfg['frequency']),
              "wspr:freq")],
        [_btn("\u2796 Session ads", "wspr:sessm"),
         _btn(f"\U0001F465 {cfg['session_frequency']}", "wspr:noop"),
         _btn("Session ads \u2795", "wspr:sessp")],
        [_btn("\u2796 Cooldown", "wspr:cdm"),
         _btn(f"\u23F3 {_fmt_secs(cfg['cooldown'])}", "wspr:noop"),
         _btn("Cooldown \u2795", "wspr:cdp")],
        [_btn("\U0001F6E1 On failure: "
              + ("Release" if cfg["fallback"] == "release" else "Block"),
              "wspr:fallback")],
        [_btn("\u274C Cancel", "wspr:cancel")],
        [_btn("\u2B05\uFE0F Back to Website Settings", _PARENT_PANEL_CB)],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


# ============================================================
# Actions (each writes its setting immediately, then re-renders)
# ============================================================
async def preroll_toggle(update: Update,
                         context: ContextTypes.DEFAULT_TYPE,
                         deps: Any) -> None:
    db = deps.db
    cfg = await _read_config(db)
    new = "0" if cfg["enabled"] else "1"
    await _set(db, PREROLL_ENABLED_KEY, new)
    await deps.log_admin_action(
        update.effective_user.id, "set_website_preroll_enabled", "setting",
        None, f"value={new}")
    logger.info("Website pre-roll %s (admin=%s).",
                "enabled" if new == "1" else "disabled",
                update.effective_user.id)
    await deps.safe_answer_callback(
        update.callback_query,
        "\u2705 Pre-roll ads enabled." if new == "1"
        else "\u274C Pre-roll ads disabled.")
    await preroll_settings_panel(update, context, deps)


async def preroll_provider_set(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any, provider: str) -> None:
    """§10/§15: select the video-ad provider (vast | direct | none).

    A CONFIG-only change (§16): the player, its PRE_ROLL_SLOT and its
    controls never move — only which adapter fills the slot."""
    db = deps.db
    value = normalize_videoad_provider(provider)
    await _set(db, PREROLL_PROVIDER_KEY, value)
    await deps.log_admin_action(
        update.effective_user.id, "set_website_videoad_provider", "setting",
        None, f"provider={value}")
    logger.info("Website video-ad provider set to %s (admin=%s).",
                value, update.effective_user.id)
    hint = {
        "vast": "\u2705 Provider: VAST. The player fetches the tag; "
                "set a VAST URL if none is stored yet.",
        "direct": "\u2705 Provider: Direct media (the v37 behavior).",
        "none": "\u2705 Provider: none — no VAST ads are served.",
    }.get(value, "\u2705 Provider set.")
    await deps.safe_answer_callback(update.callback_query, hint)
    await preroll_settings_panel(update, context, deps)


async def preroll_vast_delete(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any) -> None:
    """§15 'Delete/Remove': clears the stored VAST URL AND resets the
    provider to none (honest: without a tag URL the VAST layer is not
    configurable). Never touches the direct source URL."""
    db = deps.db
    old_len = len((await _get(db, PREROLL_VAST_URL_KEY, "")).strip())
    await _set(db, PREROLL_VAST_URL_KEY, "")
    await _set(db, PREROLL_PROVIDER_KEY, "none")
    await deps.log_admin_action(
        update.effective_user.id, "delete_website_preroll_vast", "setting",
        None, f"old_length={old_len} provider=none")
    # The URL itself is never logged (length only).
    logger.info("Website VAST URL deleted; provider reset to none "
                "(admin=%s, old_length=%d).",
                update.effective_user.id, old_len)
    await deps.safe_answer_callback(
        update.callback_query,
        "\U0001F5D1 VAST URL deleted and the provider was reset to "
        "none. The direct source URL (if any) is unchanged.")
    await preroll_settings_panel(update, context, deps)


async def preroll_mode_toggle(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any) -> None:
    """The skippable \u2194 non_skippable toggle (the v37 behavior —
    from Provider-controlled it steps to Skippable)."""
    db = deps.db
    cfg = await _read_config(db)
    new = "non_skippable" if cfg["mode"] == "skippable" else "skippable"
    await _set(db, PREROLL_MODE_KEY, new)
    await deps.log_admin_action(
        update.effective_user.id, "set_website_preroll_mode", "setting",
        None, f"mode={new}")
    await deps.safe_answer_callback(
        update.callback_query, f"\u2705 Mode: {_MODE_LABELS[new]}.")
    await preroll_settings_panel(update, context, deps)


async def preroll_mode_auto(update: Update,
                            context: ContextTypes.DEFAULT_TYPE,
                            deps: Any) -> None:
    """§12: set the NEW provider_controlled mode — the VAST response's
    skipoffset decides skippability (direct media degrades to the v37
    skippable default)."""
    db = deps.db
    await _set(db, PREROLL_MODE_KEY, "provider_controlled")
    await deps.log_admin_action(
        update.effective_user.id, "set_website_preroll_mode", "setting",
        None, "mode=provider_controlled")
    await deps.safe_answer_callback(
        update.callback_query,
        "\U0001F916 Mode: Provider-controlled — the VAST skipoffset "
        "decides skippability.")
    await preroll_settings_panel(update, context, deps)


async def preroll_timeout_step(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any, delta: int) -> None:
    """§12/§15: the player's VAST response timeout (default 8, 2..30)."""
    db = deps.db
    cur = clamp_videoad_timeout(await _get(db, PREROLL_TIMEOUT_KEY,
                                           str(VIDEOAD_DEFAULT_TIMEOUT)))
    new = clamp_videoad_timeout(cur + int(delta))
    await _set(db, PREROLL_TIMEOUT_KEY, str(new))
    await deps.log_admin_action(
        update.effective_user.id, "set_website_videoad_timeout", "setting",
        None, f"seconds={new}")
    await deps.safe_answer_callback(update.callback_query,
                                    f"\u23F1 VAST timeout: {new}s.")
    await preroll_settings_panel(update, context, deps)


async def preroll_skip_delay_step(update: Update,
                                  context: ContextTypes.DEFAULT_TYPE,
                                  deps: Any, delta: int) -> None:
    db = deps.db
    cur = clamp_skip_delay(await _get(db, PREROLL_SKIP_DELAY_KEY,
                                      str(PREROLL_DEFAULT_SKIP_DELAY)))
    new = clamp_skip_delay(cur + int(delta))
    await _set(db, PREROLL_SKIP_DELAY_KEY, str(new))
    await deps.log_admin_action(
        update.effective_user.id, "set_website_preroll_skip_delay",
        "setting", None, f"seconds={new}")
    await deps.safe_answer_callback(update.callback_query,
                                    f"\u23F1 Skip delay: {new}s.")
    await preroll_settings_panel(update, context, deps)


async def preroll_duration_step(update: Update,
                                context: ContextTypes.DEFAULT_TYPE,
                                deps: Any, delta: int) -> None:
    db = deps.db
    cur = clamp_duration(await _get(db, PREROLL_DURATION_KEY,
                                    str(PREROLL_DEFAULT_DURATION)))
    new = clamp_duration(cur + int(delta))
    await _set(db, PREROLL_DURATION_KEY, str(new))
    await deps.log_admin_action(
        update.effective_user.id, "set_website_preroll_duration", "setting",
        None, f"seconds={new}")
    await deps.safe_answer_callback(update.callback_query,
                                    f"\u23F1 Duration: {new}s.")
    await preroll_settings_panel(update, context, deps)


async def preroll_freq_cycle(update: Update,
                             context: ContextTypes.DEFAULT_TYPE,
                             deps: Any) -> None:
    db = deps.db
    cur = normalize_frequency(await _get(db, PREROLL_FREQUENCY_KEY,
                                         "every_video"))
    order = ("every_video", "session", "cooldown")
    new = order[(order.index(cur) + 1) % len(order)]
    await _set(db, PREROLL_FREQUENCY_KEY, new)
    await deps.log_admin_action(
        update.effective_user.id, "set_website_preroll_frequency",
        "setting", None, f"frequency={new}")
    await deps.safe_answer_callback(
        update.callback_query, f"\U0001F501 Frequency: {_FREQ_LABELS[new]}.")
    await preroll_settings_panel(update, context, deps)


async def preroll_session_freq_step(update: Update,
                                    context: ContextTypes.DEFAULT_TYPE,
                                    deps: Any, delta: int) -> None:
    db = deps.db
    cur = clamp_session_frequency(
        await _get(db, PREROLL_SESSION_FREQUENCY_KEY,
                   str(PREROLL_DEFAULT_SESSION_FREQUENCY)))
    new = clamp_session_frequency(cur + int(delta))
    await _set(db, PREROLL_SESSION_FREQUENCY_KEY, str(new))
    await deps.log_admin_action(
        update.effective_user.id, "set_website_preroll_session_frequency",
        "setting", None, f"count={new}")
    await deps.safe_answer_callback(update.callback_query,
                                    f"\U0001F465 Session ads: {new}.")
    await preroll_settings_panel(update, context, deps)


async def preroll_cooldown_step(update: Update,
                                context: ContextTypes.DEFAULT_TYPE,
                                deps: Any, delta: int) -> None:
    db = deps.db
    cur = clamp_cooldown(await _get(db, PREROLL_COOLDOWN_KEY,
                                    str(PREROLL_DEFAULT_COOLDOWN)))
    # comfortable step: 30s below 10 minutes, 5 minutes above
    step = 300 if (cur >= 600 or (delta > 0 and cur + 300 < 600)) else 30
    new = clamp_cooldown(cur + int(delta) * step)
    await _set(db, PREROLL_COOLDOWN_KEY, str(new))
    await deps.log_admin_action(
        update.effective_user.id, "set_website_preroll_cooldown", "setting",
        None, f"seconds={new}")
    await deps.safe_answer_callback(update.callback_query,
                                    f"\u23F3 Cooldown: {_fmt_secs(new)}.")
    await preroll_settings_panel(update, context, deps)


async def preroll_fallback_toggle(update: Update,
                                  context: ContextTypes.DEFAULT_TYPE,
                                  deps: Any) -> None:
    db = deps.db
    cur = normalize_fallback(await _get(db, PREROLL_FALLBACK_KEY,
                                        "release"))
    new = "block" if cur == "release" else "release"
    await _set(db, PREROLL_FALLBACK_KEY, new)
    await deps.log_admin_action(
        update.effective_user.id, "set_website_preroll_fallback", "setting",
        None, f"fallback={new}")
    await deps.safe_answer_callback(
        update.callback_query,
        "\u25B6\uFE0F On failure: release the content video."
        if new == "release" else
        "\u26D4 On failure: block (honest \u201Cad unavailable\u201D message).")
    await preroll_settings_panel(update, context, deps)


# ============================================================
# Text-input prompts (§18A Website SDK input pattern)
# ============================================================
async def preroll_source_prompt(update: Update,
                                context: ContextTypes.DEFAULT_TYPE,
                                deps: Any) -> None:
    """Prompt the admin for the pre-roll ad SOURCE media URL."""
    clear_states, stamp, _expired = _state_helpers()
    clear_states(context)
    context.user_data[AWAITING_SOURCE_KEY] = stamp({"step": "await_url"})
    await deps.safe_answer_callback(update.callback_query)
    await deps.safe_send_text(
        context.bot, update.effective_chat.id,
        "\U0001F517 PRE-ROLL AD SOURCE URL\n\n"
        "Send the ABSOLUTE https:// URL of the ad video "
        "(a hosted .mp4/.webm or any https URL the "
        "player can attempt — the player applies the "
        "configured failure fallback honestly if it "
        "cannot play).\n\n"
        "Example: https://cdn.example.com/ads/spot.mp4\n\n"
        "The URL is validated (https-only) and stored "
        "in the website settings. Send cancel or tap "
        "the button below to keep the current value.",
        reply_markup=_kb([[_btn("\u274C Cancel", "wspr:cancel")]]))


async def preroll_vast_prompt(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any) -> None:
    """Prompt the admin for the VAST/VMAP tag URL (§15 Add/Replace)."""
    clear_states, stamp, _expired = _state_helpers()
    clear_states(context)
    context.user_data[AWAITING_VAST_KEY] = stamp({"step": "await_url"})
    await deps.safe_answer_callback(update.callback_query)
    await deps.safe_send_text(
        context.bot, update.effective_chat.id,
        "\U0001F4E1 VIDEO AD VAST/VMAP URL\n\n"
        "Send the ABSOLUTE https:// URL of your VAST "
        "or VMAP tag endpoint (e.g. your HilltopAds "
        "video VAST tag).\n\n"
        "\u2139\uFE0F Scope: the URL is validated "
        "(https-only) and stored; the website player "
        "fetches the tag and the ad response decides "
        "skippability (Provider-controlled mode). "
        "Activate it by selecting the VAST provider.\n\n"
        "Send cancel or tap the button below to keep "
        "the current value.",
        reply_markup=_kb([[_btn("\u274C Cancel", "wspr:cancel")]]))


async def preroll_cancel(update: Update,
                         context: ContextTypes.DEFAULT_TYPE,
                         deps: Any) -> None:
    """Cancel: clears any pending input state (nothing was saved — the
    setting is only written after successful validation)."""
    context.user_data.pop(AWAITING_SOURCE_KEY, None)
    context.user_data.pop(AWAITING_VAST_KEY, None)
    await deps.safe_answer_callback(
        update.callback_query,
        "\u274C Cancelled. The pre-roll settings were not changed.")
    await preroll_settings_panel(update, context, deps)


# ============================================================
# Preview / Test (honest — no fake playback in Telegram)
# ============================================================
async def preroll_preview(update: Update,
                          context: ContextTypes.DEFAULT_TYPE,
                          deps: Any) -> None:
    db = deps.db
    cfg = await _read_config(db)
    lines = [
        "\U0001F50D PRE-ROLL PREVIEW / TEST (parameters summary)",
        "",
        f"Status: {_status_line(cfg)}",
        f"Provider: "
        f"{_PROVIDER_LABELS.get(cfg['provider'], cfg['provider'])}",
        f"Enabled: {'yes' if cfg['enabled'] else 'no'}",
        f"Mode: {_MODE_LABELS.get(cfg['mode'], cfg['mode'])}",
    ]
    if cfg["mode"] == "skippable":
        lines.append(f"Skip button appears after: {cfg['skip_delay']}s")
    elif cfg["mode"] == "provider_controlled":
        lines.append("Skippability: decided by the VAST skipoffset")
    lines.append(f"Non-skippable maximum: {cfg['duration']}s")
    lines.append(f"VAST URL: {_fmt_url(cfg['vast_url'], 96)}")
    lines.append(f"Ad source URL: {_fmt_url(cfg['source_url'], 96)}")
    lines.append(f"VAST timeout: {cfg['timeout']}s")
    lines.append(f"Frequency: "
                 f"{_FREQ_LABELS.get(cfg['frequency'], cfg['frequency'])}")
    if cfg["frequency"] == "session":
        lines.append(f"Ads per session: {cfg['session_frequency']}")
    elif cfg["frequency"] == "cooldown":
        lines.append(f"Cooldown between ads: {_fmt_secs(cfg['cooldown'])}")
    lines.append("On ad failure: "
                 + ("release the content video"
                    if cfg["fallback"] == "release" else
                    "block with an honest message"))
    lines += [
        "",
        "Telegram cannot play the website pre-roll here —",
        "this is the honest parameters summary. To test",
        "the real pre-roll, open a website video in the",
        "Mini App browser with these settings active.",
    ]
    if not cfg["source_url"] and not cfg["vast_url"]:
        lines += [
            "",
            "\u274C No ad source URL and no VAST URL configured —",
            "video ads are INACTIVE regardless of the other",
            "settings.",
        ]
    await deps.safe_answer_callback(update.callback_query)
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb([
                                  [_btn("\u2B05\uFE0F Back to Pre-Roll Ads",
                                        "wspr:main")]]))


async def preroll_test(update: Update,
                       context: ContextTypes.DEFAULT_TYPE,
                       deps: Any) -> None:
    """§15 'Test configuration' — VALIDATES the current configuration
    without persisting anything and WITHOUT touching frequency state.

    Honest scope (§34): the server can check the https URL grammar, the
    provider sanity and the clamps; the ad FEED itself (a real VAST
    response with real inventory) is only testable in a real browser
    playback — nothing is fabricated here."""
    db = deps.db
    cfg = await _read_config(db)
    config = _config_object(cfg)
    lines = [
        "\U0001F9EA VIDEO ADS — TEST CONFIGURATION",
        "",
        f"Status: {_status_line(cfg)}",
        f"Provider: "
        f"{_PROVIDER_LABELS.get(cfg['provider'], cfg['provider'])}",
        f"VAST timeout: {cfg['timeout']}s (clamp 2..30)",
        "",
    ]
    verdicts: List[str] = []

    if cfg["provider"] == "vast":
        ok, reason = await VastAdProvider().validate_config(config)
        if ok:
            verdicts.append(
                "\u2705 VAST URL is a valid https URL; the ad feed "
                "itself is only testable in a real browser playback.")
            if not cfg["enabled"]:
                verdicts.append(
                    "\u26A0\uFE0F Pre-roll ads are currently DISABLED — "
                    "enable them to serve VAST pre-rolls.")
        else:
            hint = {
                "not_configured": ("\u274C No VAST URL configured — "
                                   "video ads stay Not Configured."),
                "invalid_vast_url": ("\u274C The stored VAST URL no longer "
                                     "passes https validation — it serves "
                                     "nothing until replaced."),
                "provider_mismatch": ("\u274C Provider mismatch."),
            }.get(reason, f"\u274C Configuration problem: {reason}.")
            verdicts.append(hint)
    elif cfg["provider"] == "direct":
        ok, reason = await DirectMediaProvider().validate_config(config)
        if ok:
            verdicts.append(
                "\u2705 Direct media source URL is a valid https URL; "
                "actual playback is only testable in a real browser.")
            if not cfg["enabled"]:
                verdicts.append(
                    "\u26A0\uFE0F Pre-roll ads are currently DISABLED.")
        else:
            hint = {
                "not_configured": ("\u274C No ad source URL configured — "
                                   "video ads stay Not Configured."),
                "invalid_source": ("\u274C The stored source URL no longer "
                                   "passes https validation."),
            }.get(reason, f"\u274C Configuration problem: {reason}.")
            verdicts.append(hint)
    else:
        verdicts.append(
            "\u2139\uFE0F Provider is none — no VAST video ads are "
            "served. The legacy direct pre-roll (if enabled with a "
            "source URL) keeps working.")

    if cfg["vast_url"] and cfg["provider"] != "vast":
        verdicts.append(
            "\u26A0\uFE0F A VAST URL is stored but the provider is not "
            "VAST — the tag is not fetched in this state.")
    if cfg["source_url"] and cfg["provider"] == "vast":
        verdicts.append(
            "\u26A0\uFE0F A direct source URL is stored but the provider "
            "is VAST — the direct pre-roll is inactive in this state.")

    lines += verdicts
    lines += [
        "",
        "Nothing was persisted and no frequency state",
        "was touched by this test.",
    ]
    await deps.safe_answer_callback(update.callback_query)
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb([
                                  [_btn("\u2B05\uFE0F Back to Pre-Roll Ads",
                                        "wspr:main")]]))


# ============================================================
# Text input consumption (called from the _handle_wspr_text facade,
# which is invoked by text_input.py BEFORE the generic fallbacks)
# ============================================================
async def website_preroll_text(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any, text: str) -> bool:
    """Consume the pre-roll URL text inputs. Returns True when consumed.

    Cancel restores the previous state; the 10-minute expiry drops the
    input honestly; an INVALID URL never overwrites the working value
    (the input is re-offered)."""
    _clear, _stamp, expired = _state_helpers()
    text = str(text or "").strip()

    if context.user_data.get(AWAITING_SOURCE_KEY):
        state = context.user_data.pop(AWAITING_SOURCE_KEY, None)
        if text.lower() in ("/cancel", "cancel"):
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Cancelled. The ad source URL was not changed.")
            return True
        if expired(state):
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u23F3 The ad source URL input timed out (10 min) — "
                "nothing was changed.")
            return True
        url, err = validate_preroll_source_url(text)
        if url is None:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                f"\u274C {err}\n\nSend a valid absolute https:// URL, or "
                "send cancel to keep the current value.")
            context.user_data[AWAITING_SOURCE_KEY] = _stamp(
                {"step": "await_url"})
            return True
        await _set(deps.db, PREROLL_SOURCE_URL_KEY, url)
        await deps.log_admin_action(
            update.effective_user.id, "set_website_preroll_source",
            "setting", None, f"length={len(url)}")
        # The URL itself is never logged.
        logger.info("Website pre-roll source URL configured (admin=%s, "
                    "%d chars).", update.effective_user.id, len(url))
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u2705 Pre-roll ad source URL saved.\n\n"
            "Pre-rolls now play before website videos\n"
            "(when pre-roll ads are enabled and the\n"
            "frequency policy allows the next ad).",
            reply_markup=_kb([[_btn("\U0001F3AC Pre-Roll Ads", "wspr:main")]]))
        return True

    if context.user_data.get(AWAITING_VAST_KEY):
        state = context.user_data.pop(AWAITING_VAST_KEY, None)
        if text.lower() in ("/cancel", "cancel"):
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Cancelled. The VAST/VMAP URL was not changed.")
            return True
        if expired(state):
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u23F3 The VAST/VMAP URL input timed out (10 min) — "
                "nothing was changed.")
            return True
        url, err = validate_preroll_vast_url(text)
        if url is None:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                f"\u274C {err}\n\nSend a valid absolute https:// URL, or "
                "send cancel to keep the current value.")
            context.user_data[AWAITING_VAST_KEY] = _stamp(
                {"step": "await_url"})
            return True
        await _set(deps.db, PREROLL_VAST_URL_KEY, url)
        await deps.log_admin_action(
            update.effective_user.id, "set_website_preroll_vast", "setting",
            None, f"length={len(url)}")
        logger.info("Website VAST URL stored (admin=%s, %d chars).",
                    update.effective_user.id, len(url))
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u2705 VAST/VMAP URL saved.\n\n"
            "Select the VAST provider (and enable pre-roll\n"
            "ads) to serve VAST pre-rolls in the website\n"
            "video player. The tag URL is the ONLY thing\n"
            "stored server-side; the player fetches the tag.",
            reply_markup=_kb([[_btn("\U0001F3AC Pre-Roll Ads", "wspr:main")]]))
        return True

    return False


# ============================================================
# Dispatcher
# ============================================================
async def handle_wspr_callback(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any) -> None:
    """Dispatch every ``wspr:`` admin callback (called from on_callback —
    admin-gated there by the master admin gate, exactly like ``wsite:``;
    wspr: is NOT user-facing)."""
    data = str(update.callback_query.data or "")
    parts = data.split(":")
    action = parts[1] if len(parts) > 1 else ""

    if action in ("", "main"):
        await preroll_settings_panel(update, context, deps)
    elif action == "toggle":
        await preroll_toggle(update, context, deps)
    elif action == "prov" and len(parts) > 2:
        await preroll_provider_set(update, context, deps, parts[2])
    elif action == "mode":
        await preroll_mode_toggle(update, context, deps)
    elif action == "modeauto":
        await preroll_mode_auto(update, context, deps)
    elif action == "skipdm":
        await preroll_skip_delay_step(update, context, deps, -1)
    elif action == "skipdp":
        await preroll_skip_delay_step(update, context, deps, 1)
    elif action == "durm":
        await preroll_duration_step(update, context, deps, -5)
    elif action == "durp":
        await preroll_duration_step(update, context, deps, 5)
    elif action == "src":
        await preroll_source_prompt(update, context, deps)
    elif action == "vast":
        await preroll_vast_prompt(update, context, deps)
    elif action == "vastdel":
        await preroll_vast_delete(update, context, deps)
    elif action == "tm":
        await preroll_timeout_step(update, context, deps, -1)
    elif action == "tp":
        await preroll_timeout_step(update, context, deps, 1)
    elif action == "freq":
        await preroll_freq_cycle(update, context, deps)
    elif action == "sessm":
        await preroll_session_freq_step(update, context, deps, -1)
    elif action == "sessp":
        await preroll_session_freq_step(update, context, deps, 1)
    elif action == "cdm":
        await preroll_cooldown_step(update, context, deps, -1)
    elif action == "cdp":
        await preroll_cooldown_step(update, context, deps, 1)
    elif action == "fallback":
        await preroll_fallback_toggle(update, context, deps)
    elif action == "preview":
        await preroll_preview(update, context, deps)
    elif action == "test":
        await preroll_test(update, context, deps)
    elif action == "cancel":
        await preroll_cancel(update, context, deps)
    elif action == "noop":
        await deps.safe_answer_callback(update.callback_query,
                                        "Value unchanged.")
    else:
        await deps.safe_answer_callback(update.callback_query,
                                        "Unknown pre-roll action.")
