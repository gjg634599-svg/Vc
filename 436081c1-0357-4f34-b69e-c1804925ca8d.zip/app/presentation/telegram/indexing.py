"""Indexing engine — reindex scans, index jobs, channel posts, integrity.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



async def acquire_global_index_lock(timeout: float = 0.0) -> bool:
    """BOT6: acquire the single global indexing lock.

    Returns True if acquired, False if another indexing job is already running
    (logs BOT6_INDEX_ALREADY_RUNNING). This guarantees only ONE indexing op
    runs at a time across every channel, preventing duplicate full scans and
    Conflict-style races.
    """
    global INDEX_GLOBAL_LOCK
    if INDEX_GLOBAL_LOCK is None:
        INDEX_GLOBAL_LOCK = asyncio.Lock()
    try:
        if timeout > 0:
            try:
                await asyncio.wait_for(INDEX_GLOBAL_LOCK.acquire(), timeout=timeout)
                return True
            except asyncio.TimeoutError:
                logger.warning("BOT6_INDEX_ALREADY_RUNNING — global index lock busy, skipping.")
                return False
        else:
            acquired = INDEX_GLOBAL_LOCK.locked()
            if acquired:
                logger.warning("BOT6_INDEX_ALREADY_RUNNING — global index lock busy, skipping.")
                return False
            await INDEX_GLOBAL_LOCK.acquire()
            return True
    except Exception:  # noqa: BLE001
        logger.warning("BOT6_INDEX_ALREADY_RUNNING — lock acquire error.", exc_info=True)
        return False



def release_global_index_lock() -> None:
    global INDEX_GLOBAL_LOCK
    if INDEX_GLOBAL_LOCK is not None and INDEX_GLOBAL_LOCK.locked():
        INDEX_GLOBAL_LOCK.release()



def index_cancel_request(channel_id: int) -> None:
    """Request a graceful stop of the channel's active indexing job."""
    _INDEX_CANCEL_FLAGS.add(int(channel_id))



def index_cancel_requested(channel_id: int) -> bool:
    return int(channel_id) in _INDEX_CANCEL_FLAGS



def index_cancel_clear(channel_id: int) -> None:
    _INDEX_CANCEL_FLAGS.discard(int(channel_id))



async def _index_save_run_summary(channel_id: int, summary: Dict[str, Any]) -> None:
    """Persist the last indexing run's counters (bot_settings KV, idempotent
    upsert — no DDL, no schema change). Read by the Storage Center Index
    Status panel.

    PHASE 7 HOTFIX: `file_ids_refreshed` counts exact duplicates whose stale
    canonical file_id was refreshed in place (bot-token change repair)."""
    try:
        await db.set_setting(INDEX_RUN_STATS_KEY.format(channel_id=int(channel_id)),
                             json.dumps(summary))
        logger.info("BOT6_INDEX_RUN_SUMMARY channel_id=%s mode=%s processed=%s "
                    "indexed=%s duplicates=%s file_ids_refreshed=%s "
                    "replaced=%s "
                    "no_media=%s protected=%s "
                    "missing=%s errors=%s stopped=%s finished_at=%s",
                    int(channel_id), summary.get("mode", "-"),
                    summary.get("processed", 0), summary.get("indexed", 0),
                    summary.get("duplicates", 0),
                    summary.get("file_ids_refreshed", 0),
                    summary.get("replaced", 0),
                    summary.get("no_media", 0), summary.get("protected", 0),
                    summary.get("missing", 0), summary.get("errors", 0),
                    1 if summary.get("stopped") else 0,
                    summary.get("finished_at", "-"))
    except Exception as e:  # noqa: BLE001 — stats persistence is best-effort
        logger.warning("BOT6_INDEX_RUN_SUMMARY_SAVE_FAILED channel_id=%s exc=%s",
                       channel_id, e)



async def _index_load_run_summary(channel_id: int) -> Optional[Dict[str, Any]]:
    """Load the persisted last-run summary (None when never run)."""
    try:
        raw = await db.get_setting(INDEX_RUN_STATS_KEY.format(channel_id=int(channel_id)))
        if not raw:
            return None
        data = json.loads(raw)
        return data if isinstance(data, dict) else None
    except Exception:  # noqa: BLE001
        return None



async def _index_job_save(channel_id: int, job: Dict[str, Any]) -> None:
    """Persist the durable index-job record (idempotent KV upsert)."""
    try:
        await db.set_setting(INDEX_JOB_KEY.format(channel_id=int(channel_id)),
                             json.dumps(job))
    except Exception as e:  # noqa: BLE001 — job persistence is best-effort
        logger.warning("BOT6_INDEX_JOB_SAVE_FAILED channel_id=%s exc=%s",
                       channel_id, e)



async def _index_job_load(channel_id: int) -> Optional[Dict[str, Any]]:
    """Load the durable index-job record (None when never run)."""
    try:
        raw = await db.get_setting(INDEX_JOB_KEY.format(channel_id=int(channel_id)))
        if not raw:
            return None
        data = json.loads(raw)
        return data if isinstance(data, dict) else None
    except Exception:  # noqa: BLE001
        return None



async def _index_job_clear(channel_id: int) -> None:
    """Drop the durable job record (explicit Full Re-index starts fresh)."""
    try:
        await db.set_setting(INDEX_JOB_KEY.format(channel_id=int(channel_id)), "")
    except Exception as e:  # noqa: BLE001
        logger.warning("BOT6_INDEX_JOB_CLEAR_FAILED channel_id=%s exc=%s",
                       channel_id, e)



async def _index_save_verify_report(channel_id: int,
                                    report: Dict[str, Any]) -> None:
    """Persist the last verification report (Storage Center display)."""
    try:
        await db.set_setting(INDEX_VERIFY_KEY.format(channel_id=int(channel_id)),
                             json.dumps(report))
    except Exception as e:  # noqa: BLE001
        logger.warning("BOT6_INDEX_VERIFY_SAVE_FAILED channel_id=%s exc=%s",
                       channel_id, e)



async def _index_load_verify_report(channel_id: int) -> Optional[Dict[str, Any]]:
    """Load the last verification report (None when never verified)."""
    try:
        raw = await db.get_setting(INDEX_VERIFY_KEY.format(channel_id=int(channel_id)))
        if not raw:
            return None
        data = json.loads(raw)
        return data if isinstance(data, dict) else None
    except Exception:  # noqa: BLE001
        return None



def acquire_reindex_lock(channel_id: int) -> bool:
    """Try to acquire the reindex lock for a channel. Returns True if acquired,
    False if another worker is already running on this channel."""
    if channel_reindex_lock.get(channel_id):
        logger.warning("Reindex lock held for channel %s — skipping duplicate worker.", channel_id)
        return False
    channel_reindex_lock[channel_id] = True
    return True



def release_reindex_lock(channel_id: int) -> None:
    """Release the reindex lock for a channel."""
    channel_reindex_lock.pop(channel_id, None)



def is_reindex_running(channel_id: int) -> bool:
    """Check if a reindex is currently running on a channel."""
    return channel_reindex_lock.get(channel_id, False)



# ============================================================
# INDEXING + AUTO PAYLOAD GENERATION
# ============================================================


async def index_message(message: Message, edited: bool = False,
                        bot=None) -> None:
    """Index a single channel post (deduped by file_unique_id).

    Issue 5: structured logging — every outcome is logged as Indexed / Skipped
    / Failed so indexing never silently skips media.

    V25 (S2/S3 - bot-31.log Scenario B): an exact-identity duplicate is no
    longer an unconditional skip. The canonical row's OWN storage message is
    probed first: still live -> Scenario A (preserve the canonical record -
    genuine duplicate); CONFIRMED deleted -> the canonical row is RE-POINTED
    to this new storage message (the re-upload becomes the usable canonical
    reference; payload references are untouched; the old reference is
    preserved in prev_channel_id/prev_message_id). Unverifiable ->
    conservative preserve (never re-point on a transient verdict).
    """
    channel_id = message.chat.id
    message_id = message.message_id
    info = extract_media(message)
    if not info:
        logger.info("BOT6_INDEX_SKIP reason=no_media channel_id=%s message_id=%s",
                    channel_id, message_id)
        return  # not a media message we track

    existing = None
    if info.get("file_unique_id"):
        existing = await db.get_indexed_file_by_unique_id(info["file_unique_id"])

    if existing and not edited:
        # V25 S2/S3: Scenario B check FIRST — if the canonical source message
        # is dead, re-point the canonical row to THIS new storage message
        # (the file stays deliverable; a deleted old message can never block
        # the re-upload from becoming the canonical usable reference).
        _admin_for_probe = None
        try:
            # Late-binding: inside the composed runtime namespace ADMIN_IDS
            # resolves through the namespace globals (state.py). Direct
            # module-level calls (tests) fall back to the parent import.
            try:
                _admins = ADMIN_IDS  # noqa: F821 — namespace late binding
            except NameError:
                from app.presentation.telegram import runtime as _rt  # noqa: PLC0415
                _admins = _rt.ADMIN_IDS
            _admin_for_probe = _admins[0] if _admins else None
        except Exception:  # noqa: BLE001 — probe target lookup is best-effort
            _admin_for_probe = None
        if await _repoint_canonical_if_dead(bot, _admin_for_probe, existing,
                                            info, channel_id, message_id):
            return  # re-pointed — the canonical row now IS this message
        # Scenario A (or unverifiable): preserve + refresh stale file_id.
        # PHASE 7 HOTFIX: the live post carries a file_id freshly issued to
        # the CURRENT bot — validate + refresh the canonical row's file_id in
        # place when it is stale (bot-token change). Same identity discipline
        # as the re-index path (media-type context must match; the canonical
        # row is never replaced; file_unique_id never lands in file_id).
        await _repair_duplicate_file_id(existing, info, channel_id, message_id)
        # WEBSITE PHASE 2 (v30 part A): the fresh source values fill any
        # MISSING metadata columns of the canonical row (fill-missing only:
        # NULL columns + non-NULL fresh values; never clobbers captured
        # values; the canonical row is otherwise untouched).
        try:
            await db.backfill_indexed_file_metadata(int(existing["id"]), info)
        except Exception as e:  # noqa: BLE001 — metadata fill never breaks indexing
            logger.debug("metadata backfill failed for file #%s: %s",
                         existing["id"], e)
        logger.info("BOT6_INDEX_SKIP reason=already_indexed channel_id=%s message_id=%s "
                    "file_pk=%s name=%s",
                    channel_id, message_id, existing["id"], info.get("file_name"))
        return  # duplicate of already-indexed file
    if existing and edited:
        try:
            await db.update_indexed_file(existing["id"], info)
            logger.info("BOT6_INDEX_FILE action=update channel_id=%s message_id=%s file_pk=%s name=%s",
                        channel_id, message_id, existing["id"], info.get("file_name"))
        except Exception as e:  # noqa: BLE001
            logger.error("BOT6_INDEX_FILE action=update_failed file_pk=%s error=%s",
                         existing["id"], e)
        return

    # BOT-43 (SOURCE_MEDIA_REPLACEMENT — live edited-post path): the post
    # carries a DIFFERENT media object at the SAME (channel_id, message_id)
    # (the admin replaced the file). The lookup above was by file_unique_id
    # only — a NEW uid meant "insert", which silently created a SECOND row
    # for the same source message (only UNIQUE(file_unique_id) exists) while
    # every (channel, message) consumer kept serving the OLD identity. The
    # guarded repo path updates the canonical row IN PLACE instead (pk,
    # payload FKs and stats preserved; identity-conflict / missing-field
    # guards log the honest skip and fall through to the normal insert).
    if existing is None and await db.attempt_source_media_replacement(
            int(channel_id), int(message_id), info):
        return  # canonical row replaced in place — no second row

    try:
        file_pk = await db.add_indexed_file(channel_id, message_id, info)
    except Exception as e:  # noqa: BLE001
        logger.error("BOT6_INDEX_FILE action=index_failed channel_id=%s message_id=%s type=%s "
                     "name=%s error=%s",
                     channel_id, message_id, info["media_type"], info.get("file_name"), e)
        return
    logger.info(
        "BOT6_INDEX_NEW_FILE channel_id=%s message_id=%s file_pk=%s type=%s name=%s",
        channel_id, message_id, file_pk, info["media_type"], info.get("file_name"),
    )
    logger.info(
        "BOT6_INDEX_FILE action=index channel_id=%s message_id=%s file_pk=%s type=%s name=%s",
        channel_id, message_id, file_pk, info["media_type"], info.get("file_name"),
    )

    # Touch the storage channel's last_scan if it is registered.
    await db.touch_storage_channel(channel_id)

    # Issue #71: Auto-capture source branding for this indexed file.
    # Uses the media itself as the banner + caption as description.
    try:
        banner_fid = info.get("file_id")
        banner_type = info.get("media_type")
        source_caption = info.get("caption") or ""
        source_title = (info.get("file_name") or "")[:100]
        await db.set_source_branding(
            index_id=file_pk,
            source_message_id=message_id,
            banner_file_id=banner_fid,
            banner_type=banner_type,
            source_caption=source_caption,
            source_title=source_title,
        )
    except Exception as e:  # noqa: BLE001
        logger.debug("Source branding capture failed for file #%d: %s", file_pk, e)

    if await auto_payload_active() and info.get("file_name"):
        slug = sanitize_slug(info["file_name"])
        if slug:
            await create_unique_payload(slug, file_pk)



# ============================================================
# ISSUE 26: INCREMENTAL REINDEX SYSTEM
# ============================================================
# Old model (REMOVED): scan 1 → 500 / 1 → 1000 / 1 → latest every time.
# New model: per-channel cursor (last_scanned_message_id) so only NEW messages
# are scanned. First scan walks backwards to index existing content.
# ============================================================

async def _probe_message_exists(bot, admin_id: int, channel_id: int,
                                 message_id: int) -> Optional[bool]:
    """Quickly check if a message exists at the given message_id.

    Uses copy_message (fast, cleaned up immediately). Returns True if the
    message exists (even if it has no media or is protected), False if it
    does not exist.

    PHASE 8 (§1/§19 — transient ≠ missing): returns None when existence
    could NOT be determined (network glitch / timeout on BOTH transports,
    or the bot lost access). Callers MUST treat None as "unknown", never as
    "missing" — a transient Telegram failure must never become a permanent
    data verdict (the same rule the force-join classifier enforces).

    H1 Fix: explicitly handles RetryAfter by sleeping and retrying, instead
    of letting it fall through to 'except TelegramError' which treated it
    as a permanent failure (returning False = message doesn't exist).
    Issue #85 Fix: when copy_message fails with a NON-"not found" error
    (e.g. the bot can't copy from a restricted channel but the message
    still exists), fall back to forward_message before concluding the
    message is missing.
    """
    # Attempt 1: copy_message (fast).
    try:
        result = await bot.copy_message(admin_id, channel_id, message_id)
        mid = getattr(result, "message_id", None)
        if mid:
            try:
                await bot.delete_message(admin_id, mid)
            except TelegramError:
                pass
        return True
    except BadRequest as e:
        err_lower = str(e).lower()
        if "not found" in err_lower or "message to copy not found" in err_lower:
            return False
        # Protected / restricted / other BadRequest -> message exists.
        return True
    except RetryAfter as e:
        logger.debug("probe: RetryAfter %ss for msg %s, retrying", e.retry_after, message_id)
        await asyncio.sleep(e.retry_after)
        return await _probe_message_exists(bot, admin_id, channel_id, message_id)
    except Forbidden:
        # Bot is not a member / was kicked. Existence UNKNOWN (the message
        # may well exist — the bot just cannot see it). PHASE 8: None, not
        # False (the old False made determine_latest report a falsely-low
        # 'latest' and the scan silently skipped live history).
        return None
    except TelegramError as e:
        # Issue #85: copy_message failed with a non-BadRequest error (e.g.
        # network glitch, timed out, "message is not accessible"). Do NOT
        # conclude the message is missing — fall back to forward_message,
        # which uses a different code path and may succeed.
        logger.debug("probe: copy_message failed for msg %s (%s); trying forward", message_id, e)
    # Attempt 2: forward_message fallback (different API path).
    try:
        fwd = await bot.forward_message(chat_id=admin_id, from_chat_id=channel_id,
                                         message_id=message_id, disable_notification=True)
        mid = getattr(fwd, "message_id", None)
        if mid:
            try:
                await bot.delete_message(admin_id, mid)
            except TelegramError:
                pass
        return True
    except BadRequest as e:
        err_lower = str(e).lower()
        if "not found" in err_lower or "message to forward not found" in err_lower:
            return False
        return True  # protected/restricted -> exists
    except RetryAfter as e:
        logger.debug("probe fwd: RetryAfter %ss for msg %s, retrying", e.retry_after, message_id)
        await asyncio.sleep(e.retry_after)
        return await _probe_message_exists(bot, admin_id, channel_id, message_id)
    except Forbidden:
        return None
    except TelegramError:
        # Both transports failed with non-"not found" errors. PHASE 8: the
        # existence is UNKNOWN — report that honestly instead of a false
        # 'missing' (transient failures must never delete history from the
        # scan's point of view).
        return None



async def _walk_up_from_live_seed(bot, admin_id: int, channel_id: int,
                                  lo: int) -> Optional[int]:
    """V25 §12: the shared upward walk from a PROVEN-live seed id.

    ``lo`` is a message id whose existence was just confirmed by
    _probe_message_exists (either the live db_max seed, or — after a seed
    miss — the first live DB-recorded candidate below a dead maximum).
    Walks the exact bound-doubling + binary search the live-seed path has
    always used: ``hi = lo + 1`` doubling up to REINDEX_PROBE_CEILING,
    then a binary search between the last live id and the first dead one.

    Returns the resolved latest id, or None when any probe is
    unverifiable (BOT6_INDEX_PROBE_UNKNOWN — the honest-abort rule:
    a transient failure must NEVER conclude a false latest).
    """
    hi = max(lo + 1, 2)
    while hi <= REINDEX_PROBE_CEILING:
        res = await _probe_message_exists(bot, admin_id, channel_id, hi)
        if res is None:
            logger.warning("BOT6_INDEX_PROBE_UNKNOWN channel_id=%s "
                           "message_id=%s — existence unverifiable; "
                           "latest_message_id NOT concluded",
                           channel_id, hi)
            return None
        if res:
            lo = hi
            hi *= 2
        else:
            break
    if hi > REINDEX_PROBE_CEILING:
        hi = REINDEX_PROBE_CEILING
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        res = await _probe_message_exists(bot, admin_id, channel_id, mid)
        if res is None:
            logger.warning("BOT6_INDEX_PROBE_UNKNOWN channel_id=%s "
                           "message_id=%s — existence unverifiable; "
                           "latest_message_id NOT concluded",
                           channel_id, mid)
            return None
        if res:
            lo = mid
        else:
            hi = mid
    return lo


async def determine_latest_message_id(bot, admin_id: int,
                                      channel_id: int,
                                      db_max_message_id: Optional[int] = None,
                                      db_candidate_message_ids: Optional[List[int]] = None
                                      ) -> Optional[int]:
    """Find the latest existing message_id in a channel.

    Uses exponential probing + binary search for O(log n) efficiency so even
    channels with tens of thousands of messages resolve in ~30 probes.
    Returns the latest existing message_id, or None if the channel is empty
    OR the probes could not be verified right now (PHASE 8: a transient
    Telegram failure is logged loudly as PROBE_UNKNOWN — callers treat
    None honestly instead of silently scanning a truncated range).

    V25 §5 (bot-31.log forensics): the exponential search assumed "probe
    id X not found" means "no messages above X". That is FALSE in channels
    with deleted messages — Telegram ids leave gaps, and a gap at a probe
    point (2/4/8/16/…) truncated the whole upper history (production:
    latest=9 concluded while message 546 was live — messages_scanned=9
    against db_total=753). The `db_max_message_id` seed fixes the class:
    when the DB already indexes a message at id N, the search STARTS from
    that proven-existing id (never below it), so no gap below N can lie
    about the channel's extent. Callers pass the repository's
    max_message_id_for_channel() value.

    V25 §12 (bot-34.log forensics — the seed-MISS half of the class): the
    §5 seed only protects the case where db_max itself is LIVE. When the
    DB-max message is DEAD (a deleted orphan — bot-34.log: db_max 868,
    one of 14 dead orphans), the walk fell back to the GROUND-UP
    exponential probe from 1, hit the first deleted-message gap just
    above the low history and truncated there (production: latest=9,
    messages_scanned=9, coverage=partial while 730 live messages existed
    above — INDEX_VERIFY_WALK_TRUNCATED). `db_candidate_message_ids` (the
    repository's message_ids_desc_for_channel() list — newest first,
    dead rows deliberately included) closes that half: on a seed miss the
    newest DB-recorded ids are probed DESCENDING and the first LIVE one
    re-seeds the exact same upward walk as the live-db_max case. Only
    when every DB-recorded candidate is CONFIRMED dead does the ground-up
    search run (the true all-dead reconciliation case). The parameter is
    OPTIONAL — callers that pass no candidates get the legacy behavior
    unchanged.
    """
    # V25 §5: seed from the DB's own highest indexed message id when
    # available — it is PROVEN to exist (we indexed it), so the search can
    # never conclude a 'latest' below it.
    db_max = None
    try:
        db_max = int(db_max_message_id) if db_max_message_id else None
    except (TypeError, ValueError):
        db_max = None
    if db_max is not None and db_max >= 1:
        seed = await _probe_message_exists(bot, admin_id, channel_id, db_max)
        if seed is None:
            logger.warning("BOT6_INDEX_PROBE_UNKNOWN channel_id=%s "
                           "message_id=%s — existence unverifiable (db_max "
                           "seed); latest_message_id NOT concluded",
                           channel_id, db_max)
            return None
        if seed is True:
            lo = await _walk_up_from_live_seed(bot, admin_id, channel_id,
                                               db_max)
            if lo is None:
                return None
            if lo > db_max:
                logger.info(
                    "BOT6_INDEX_LATEST_RESOLVED channel_id=%s latest=%s "
                    "db_max=%s source=db_seed (walk starts at/above every "
                    "DB-recorded message id)", channel_id, lo, db_max)
            return lo
        # DB max itself not found (source deleted above the seed): fall
        # through to the ground-up search — logged for diagnostics.
        logger.info(
            "BOT6_INDEX_LATEST_SEED_MISS channel_id=%s db_max=%s "
            "result=not_found (falling back to the ground-up probe search)",
            channel_id, db_max)

        # V25 §12 (bot-34.log): before the ground-up fallback, probe the
        # DB's OTHER recorded ids — newest first. A dead maximum must not
        # truncate the channel below ids the DB itself indexes.
        _SEED_CANDIDATE_PROBE_BUDGET = 40  # bounded probe budget (repo sends 40)
        _raw_candidates = []
        try:
            _raw_candidates = list(db_candidate_message_ids or [])
        except (TypeError, ValueError):
            _raw_candidates = []
        _norm_candidates = set()
        for _raw in _raw_candidates:
            try:
                _cid = int(_raw)
            except (TypeError, ValueError):
                continue
            if _cid >= 1:
                _norm_candidates.add(_cid)
        _candidate_probes = 0
        for _cid in sorted(_norm_candidates, reverse=True):
            if _candidate_probes >= _SEED_CANDIDATE_PROBE_BUDGET:
                break
            if _cid >= db_max:
                continue  # the dead db_max itself was already probed above
            _candidate_probes += 1
            _verdict = await _probe_message_exists(bot, admin_id,
                                                   channel_id, _cid)
            if _verdict is None:
                logger.warning(
                    "BOT6_INDEX_PROBE_UNKNOWN channel_id=%s message_id=%s "
                    "— existence unverifiable (db seed candidate); "
                    "latest_message_id NOT concluded",
                    channel_id, _cid)
                return None
            if _verdict is True:
                # First LIVE DB-recorded candidate below the dead maximum:
                # re-seed the walk here — EXACTLY like the live-db_max
                # case (same upward bound walk + binary search).
                lo = await _walk_up_from_live_seed(bot, admin_id,
                                                   channel_id, _cid)
                if lo is None:
                    return None
                logger.info(
                    "BOT6_INDEX_LATEST_RESOLVED channel_id=%s latest=%s "
                    "db_max=%s source=db_candidate (seed candidate live — "
                    "walk starts at/above this DB-recorded id)",
                    channel_id, lo, db_max)
                return lo
            # _verdict is False — CONFIRMED dead: skip past it to the next
            # DB-recorded candidate (descending).
        if _candidate_probes:
            logger.info(
                "BOT6_INDEX_SEED_CANDIDATES_EXHAUSTED channel_id=%s "
                "tried=%s (all DB-recorded ids above the walk are "
                "confirmed dead — ground-up search)",
                channel_id, _candidate_probes)
    # Check if channel has any messages at all.
    first = await _probe_message_exists(bot, admin_id, channel_id, 1)
    if first is None:
        logger.warning("BOT6_INDEX_PROBE_UNKNOWN channel_id=%s message_id=1 — "
                       "existence unverifiable (transient Telegram error / bot "
                       "lost access); latest_message_id NOT concluded", channel_id)
        return None
    if first is False:
        return None
    # Exponential search: find an upper bound where messages stop existing.
    lo = 1
    hi = 2
    while hi <= REINDEX_PROBE_CEILING:
        res = await _probe_message_exists(bot, admin_id, channel_id, hi)
        if res is None:
            logger.warning("BOT6_INDEX_PROBE_UNKNOWN channel_id=%s message_id=%s — "
                           "existence unverifiable; latest_message_id NOT concluded",
                           channel_id, hi)
            return None
        if res:
            lo = hi
            hi *= 2
        else:
            break
    if hi > REINDEX_PROBE_CEILING:
        hi = REINDEX_PROBE_CEILING
    # Binary search between lo (exists) and hi (doesn't exist).
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        res = await _probe_message_exists(bot, admin_id, channel_id, mid)
        if res is None:
            logger.warning("BOT6_INDEX_PROBE_UNKNOWN channel_id=%s message_id=%s — "
                           "existence unverifiable; latest_message_id NOT concluded",
                           channel_id, mid)
            return None
        if res:
            lo = mid
        else:
            hi = mid
    return lo



async def _canonical_source_is_dead(bot, admin_id: int,
                                    canon: aiosqlite.Row) -> Optional[bool]:
    """V25 (§2/§3): is the canonical row's OWN storage message still live?

    Probes the canonical (channel_id, message_id) reference:
      True  — CONFIRMED deleted ("message to copy/forward not found");
      False — still exists (the duplicate is a genuine live duplicate);
      None  — unverifiable right now (no bot handle / transient Telegram
              failure / access loss). Callers MUST treat None as "do NOT
              re-point" (conservative: the canonical row is preserved).

    The probe uses the SAME transport the verification engine uses
    (_probe_message_exists): copy first, forward fallback, tri-state
    verdicts — a transient error never becomes a deletion verdict.
    """
    if bot is None:
        return None
    ch = _safe_row_get(canon, "channel_id")
    msg = _safe_row_get(canon, "message_id")
    if ch is None or msg is None:
        return None
    try:
        verdict = await _probe_message_exists(bot, admin_id, int(ch),
                                              int(msg))
    except Exception:  # noqa: BLE001 — probe failure = unknown, never dead
        return None
    if verdict is None:
        return None           # transient/unverifiable — NEVER a deletion
    # _probe_message_exists: True == message EXISTS, False == CONFIRMED
    # "not found". The dead-question is the INVERSE.
    return not verdict


async def _repoint_canonical_if_dead(bot, admin_id: int, canon,
                                    info: Dict[str, Any],
                                    channel_id: int, msg_id: int) -> bool:
    """V25 (§2/§3 — bot-31.log Scenario B): a duplicate identity arrived at
    a NEW storage message while the canonical row's OWN source message is
    dead → RE-POINT the canonical row to the new message.

    Scenario A (old message still exists): returns False — the existing
    canonical record is preserved (normal duplicate skip; the caller keeps
    the refresh-file_id behavior).
    Scenario B (old message CONFIRMED deleted): re-points the canonical row
    to the new storage message — pk, file_unique_id, upload_date, stats and
    every payload reference are UNTOUCHED; the new message becomes the
    canonical usable storage reference; the old reference is preserved in
    prev_channel_id/prev_message_id (schema v41) and the log.

    Unverifiable (transient/no-bot): returns False (conservative preserve).
    """
    try:
        file_pk = _safe_row_get(canon, "id")
        if file_pk is None:
            return False
        old_ch = _safe_row_get(canon, "channel_id")
        old_msg = _safe_row_get(canon, "message_id")
        # Same reference (an edited/re-fetched post): not a re-point case.
        if (old_ch is not None and old_msg is not None
                and int(old_ch) == int(channel_id)
                and int(old_msg) == int(msg_id)):
            return False
        # Identity discipline: the fresh media must carry the SAME exact
        # identity and media type as the canonical row (the caller resolved
        # the row BY identity, but the type guard catches anomalous pairs).
        if _safe_row_get(canon, "media_type") != info.get("media_type"):
            return False
        dead = await _canonical_source_is_dead(bot, admin_id, canon)
        if dead is not True:
            if dead is None:
                logger.info(
                    "BOT6_INDEX_REPOINT_SKIPPED file_pk=%s reason=source_unverifiable "
                    "(conservative preserve — the canonical row is untouched)",
                    file_pk)
            return False
        repointed = await db.repoint_indexed_file_source(
            int(file_pk), int(channel_id), int(msg_id), info)
        if repointed:
            logger.info(
                "BOT6_INDEX_CANONICAL_REPOINT file_pk=%s unique_id=%s "
                "old_channel_id=%s old_message_id=%s new_channel_id=%s "
                "new_message_id=%s source_status=available "
                "payload_refs_preserved=True (the old canonical storage "
                "message was CONFIRMED deleted and the SAME file identity "
                "was re-sent — the canonical row now points at the new "
                "usable message; the historical reference is preserved in "
                "prev_channel_id/prev_message_id)",
                file_pk, info.get("file_unique_id"), old_ch, old_msg,
                channel_id, msg_id)
        else:
            logger.info(
                "BOT6_INDEX_CANONICAL_REPOINT file_pk=%s result=already_current "
                "(row already points at message %s/%s — idempotent re-point)",
                file_pk, channel_id, msg_id)
        return bool(repointed)
    except Exception as e:  # noqa: BLE001 — re-point must never break indexing
        logger.error(
            "BOT6_INDEX_CANONICAL_REPOINT file_pk=%s result=error exc=%s.%s "
            "(canonical row untouched)",
            _safe_row_get(canon, "id"), type(e).__module__, type(e).__name__)
        return False


async def _repair_duplicate_file_id(canon, info: Dict[str, Any],
                                    channel_id: int, msg_id: int) -> bool:
    """PHASE 7 HOTFIX: an EXACT duplicate (same file_unique_id, or same
    channel+message for NULL-identity rows) was found while indexing — the
    freshly-fetched file_id (obtained by the CURRENT bot from the source
    message) is authoritative. If the canonical row holds a DIFFERENT
    file_id (e.g. issued to a previous bot token after a token change), the
    canonical row's file_id is refreshed IN PLACE:

      * the row is NEVER replaced or re-inserted (pk, source refs, payload
        references, stats all preserved — INDEX_CANONICAL_PRESERVED);
      * file_unique_id is NEVER written into the file_id column;
      * a media_type mismatch between the canonical row and the fresh info
        means the identity pair is anomalous — the canonical record is left
        completely untouched (anomaly logged).

    Idempotence: when the stored file_id already equals the fresh one the
    write is a no-op (result=current). Re-indexing the same messages any
    number of times converges to the same state.
    Returns True when a refresh actually happened.
    """
    try:
        file_pk = _safe_row_get(canon, "id")
        if file_pk is None:
            return False
        stored_type = _safe_row_get(canon, "media_type")
        fresh_type = info.get("media_type")
        stored_fid = _safe_row_get(canon, "file_id")
        fresh_fid = info.get("file_id")
        if stored_type != fresh_type:
            logger.warning(
                "BOT6_INDEX_IDENTITY_ANOMALY file_pk=%s channel_id=%s "
                "message_id=%s stored_type=%s fresh_type=%s unique_id=%s — "
                "same identity with different media types; canonical record "
                "preserved untouched, file_id NOT refreshed",
                file_pk, channel_id, msg_id, stored_type, fresh_type,
                info.get("file_unique_id"))
            logger.info(
                "BOT6_INDEX_CANONICAL_PRESERVED file_pk=%s channel_id=%s "
                "message_id=%s file_id_touched=False row_replaced=False "
                "reason=media_type_mismatch",
                file_pk, channel_id, msg_id)
            return False
        if not fresh_fid or fresh_fid == stored_fid:
            logger.info(
                "BOT6_INDEX_FILE_ID_VALIDATE file_pk=%s channel_id=%s "
                "message_id=%s result=current file_id_matches_source=True",
                file_pk, channel_id, msg_id)
            logger.info(
                "BOT6_INDEX_CANONICAL_PRESERVED file_pk=%s channel_id=%s "
                "message_id=%s file_id_touched=False row_replaced=False "
                "reason=already_current",
                file_pk, channel_id, msg_id)
            return False
        refreshed = await db.repair_indexed_file_file_id(
            int(file_pk), str(fresh_fid))
        if refreshed:
            logger.info(
                "BOT6_INDEX_FILE_ID_VALIDATE file_pk=%s channel_id=%s "
                "message_id=%s result=refreshed stored_file_id_stale=True "
                "fresh_source=current_bot",
                file_pk, channel_id, msg_id)
            logger.info(
                "BOT6_INDEX_CANONICAL_PRESERVED file_pk=%s channel_id=%s "
                "message_id=%s file_id_touched=True row_replaced=False "
                "references_kept=True (in-place file_id refresh only)",
                file_pk, channel_id, msg_id)
            # Signal the caller (scan counters / run summary) that this
            # duplicate ALSO repaired a stale file_id.
            info["_file_id_refreshed"] = True
            return True
        logger.warning(
            "BOT6_INDEX_FILE_ID_VALIDATE file_pk=%s channel_id=%s "
            "message_id=%s result=repair_write_failed (concurrent repair? "
            "canonical state wins)", file_pk, channel_id, msg_id)
        logger.info(
            "BOT6_INDEX_CANONICAL_PRESERVED file_pk=%s channel_id=%s "
            "message_id=%s file_id_touched=False row_replaced=False "
            "reason=repair_write_failed",
            file_pk, channel_id, msg_id)
        return False
    except Exception as e:  # noqa: BLE001 — repair must never break indexing
        logger.error(
            "BOT6_INDEX_FILE_ID_VALIDATE channel_id=%s message_id=%s "
            "result=error exc=%s.%s (canonical record untouched)",
            channel_id, msg_id, type(e).__module__, type(e).__name__)
        return False



async def _index_one_message(bot, admin_id: int, channel_id: int,
                              msg_id: int,
                              known_unique_ids: Optional[Set[str]] = None,
                              batch_queue: Optional[List[Tuple[int, int, dict]]] = None
                              ) -> Tuple[str, Optional[dict]]:
    """Fetch + index a single message. Returns (outcome, info).

    outcome is one of: 'indexed', 'duplicate', 'replaced', 'no_media',
    'missing', 'protected', 'error'. `info` is the media dict for
    indexed/duplicate/replaced.

    BOT-43 (SOURCE_MEDIA_REPLACEMENT): 'replaced' — the same source
    message (channel_id, message_id) now carries a DIFFERENT media object
    (NEW file_unique_id). The canonical row for the exact source pair is
    updated IN PLACE (pk, payload references, stats preserved) instead of
    silently inserting a SECOND row for the same source message.

    PHASE 7 (Task 1) performance upgrades (semantics UNCHANGED):
      * `known_unique_ids` — the preloaded exact-identity set; when supplied
        the duplicate check is an O(1) set lookup instead of a SELECT per
        message. Only EXACT Telegram file_unique_id identity counts —
        similar names/sizes/durations are NEVER duplicates.
      * `batch_queue` — when supplied (and auto-payload is inactive), the
        row is NOT inserted immediately; it is queued and the caller flushes
        the queue as ONE short write-locked transaction. When the queue is
        not used (or auto-payload needs per-row pks), the original per-row
        insert path runs unchanged.

    PHASE 7 HOTFIX: an exact duplicate is no longer a blind skip — the
    canonical row's file_id is validated against the freshly-fetched one and
    refreshed in place when stale (bot-token change), so re-indexing REPAIRS
    delivery instead of preserving the breakage (bot.log 22: reidxfull
    reported duplicates=8 indexed=0 while every delivery kept failing).
    """
    try:
        info, fwd_mid = await fetch_channel_media(bot, admin_id, channel_id, msg_id)
        try:
            if fwd_mid:
                await bot.delete_message(admin_id, fwd_mid)
        except TelegramError:
            pass
        if info is None and fwd_mid is None:
            return "missing", None
        if info is None:
            return "no_media", None
        # Has media -> check duplicate (EXACT identity only).
        # The preload set is the AUTHORITY in batched mode (it covers both
        # DB rows and rows queued-but-not-flushed in THIS scan); the DB row
        # is resolved ONLY to perform the in-place file_id refresh.
        canon = None
        if info.get("file_unique_id"):
            uid = info["file_unique_id"]
            if known_unique_ids is not None:
                if uid in known_unique_ids:
                    canon = await db.get_indexed_file_by_unique_id(uid)
                    if canon is None:
                        # In the preload set but not in the DB yet: queued
                        # earlier in THIS scan (batch not flushed). Still an
                        # EXACT duplicate — skip the insert; the queued row
                        # already carries an equally fresh current-bot id.
                        return "duplicate", info
                # else: O(1) fast path — definitely a NEW file, no lookup.
            else:
                canon = await db.get_indexed_file_by_unique_id(uid)
        else:
            canon = await db.get_indexed_file_by_channel_msg(channel_id, msg_id)
        if canon is not None:
            # V25 S2/S3 (Scenario B): the canonical row's OWN source message
            # may be dead (deleted after indexing; the SAME file identity was
            # re-sent at THIS message). Check BEFORE the plain duplicate skip:
            # a dead canonical reference must never block the new storage
            # message from becoming the canonical usable reference.
            if await _repoint_canonical_if_dead(bot, admin_id, canon,
                                                info, channel_id, msg_id):
                return "repointed", info
            # EXACT duplicate: skip the insert (the UNIQUE constraint would
            # reject it anyway) but REFRESH a stale canonical file_id in place.
            await _repair_duplicate_file_id(canon, info, channel_id, msg_id)
            # WEBSITE PHASE 2 (v30 part A): fill MISSING metadata columns
            # from the fresh source values (fill-missing only — see
            # MediaRepoMixin.backfill_indexed_file_metadata).
            try:
                await db.backfill_indexed_file_metadata(
                    int(_safe_row_get(canon, "id")), info)
            except Exception as e:  # noqa: BLE001 — never breaks indexing
                logger.debug("metadata backfill failed during scan: %s", e)
            # V26 Phase 8 — MUTABLE METADATA REFRESH: the exact-identity
            # duplicate is no longer a blind skip for an EDITED source
            # message. When THIS scan is the canonical row's OWN source
            # (channel_id, message_id), the fresh fetch is the AUTHORITY
            # for the mutable metadata (filename/caption/size/...) — the
            # production bug (filename X → message edited to Y → reindex
            # → the system still showed X) is fixed AT THE ROOT. Immutable
            # identity (pk / file_id / file_unique_id / the canonical
            # source refs) is never touched here; a DIFFERENT message
            # carrying the same file does NOT refresh the canonical row
            # (its own source message is the authority for its metadata,
            # and the guarded Scenario-B repoint above owns ref moves).
            _same_source = (
                int(_safe_row_get(canon, "channel_id") or 0) == int(channel_id)
                and int(_safe_row_get(canon, "message_id") or 0)
                == int(msg_id))
            if _same_source:
                _pk8 = int(_safe_row_get(canon, "id"))
                try:
                    _changes = await db.refresh_indexed_file_mutable_metadata(
                        _pk8, info)
                except Exception as e:  # noqa: BLE001 — never breaks indexing
                    logger.debug(
                        "metadata refresh failed during scan: %s", e)
                    _changes = {}
                if _changes:
                    logger.info(
                        "INDEX_REINDEX_METADATA_CHANGED file_pk=%s "
                        "channel_id=%s message_id=%s fields=%s "
                        "old_filename=%r new_filename=%r (the reindex "
                        "updated the mutable metadata from the edited "
                        "source message — the canonical identity is "
                        "preserved)",
                        _pk8, channel_id, msg_id,
                        ",".join(sorted(_changes)),
                        _safe_row_get(canon, "file_name"),
                        info.get("file_name"))
                    # BOT-43 (§B): an edited FILENAME propagates to the
                    # DERIVED display defaults (payloads.display_name and
                    # single-listing website_payloads.title) — ONLY where
                    # the derived value still equals the OLD-derived
                    # default; admin-curated values are NEVER overwritten.
                    _fn_change = _changes.get("file_name")
                    if _fn_change:
                        _old_fn, _new_fn = _fn_change
                        try:
                            _prop = await db.propagate_renamed_file_defaults(
                                _pk8, _old_fn, _new_fn)
                        except Exception as e:  # noqa: BLE001
                            logger.debug(
                                "rename propagation failed during scan: %s", e)
                            _prop = {"payload_ids": [], "listing_ids": []}
                        if _prop.get("payload_ids") or _prop.get("listing_ids"):
                            _pid_s = ",".join(
                                str(i) for i in
                                (_prop.get("payload_ids") or [])[:10]) or "-"
                            _lid_s = ",".join(
                                str(i) for i in
                                (_prop.get("listing_ids") or [])[:10]) or "-"
                            logger.info(
                                "INDEX_RENAME_PROPAGATED file_pk=%s "
                                "payload_ids=%s listing_ids=%s "
                                "old_filename=%r new_filename=%r (derived "
                                "defaults updated; curated values "
                                "preserved)",
                                _pk8, _pid_s, _lid_s, _old_fn, _new_fn)
                else:
                    logger.info(
                        "INDEX_REINDEX_METADATA_UNCHANGED file_pk=%s "
                        "channel_id=%s message_id=%s",
                        _pk8, channel_id, msg_id)
            return "duplicate", info
        # BOT-43 (SOURCE_MEDIA_REPLACEMENT): reached here => the fresh
        # file_unique_id is NEW (no exact-identity match). Before treating
        # the message as a NEW file, check whether its EXACT source pair
        # (channel_id, message_id) already has a canonical row — the admin
        # replaced the media in the edited post. The guarded repo path
        # updates that row IN PLACE (pk, payload FKs, stats preserved) and
        # maintains the preload set so the OLD uid re-inserts as a
        # genuinely new canonical row later in THIS scan while the NEW uid
        # dedups correctly. Guard failures log the honest skip and fall
        # through to the normal insert path below.
        if await db.attempt_source_media_replacement(
                int(channel_id), int(msg_id), info,
                known_unique_ids=known_unique_ids):
            return "replaced", info
        # Batched path (safe only when auto-payload is inactive — it needs
        # the per-row pk for payload creation).
        if batch_queue is not None and known_unique_ids is not None \
                and not await auto_payload_active():
            if info.get("file_unique_id"):
                known_unique_ids.add(info["file_unique_id"])
            batch_queue.append((channel_id, msg_id, info))
            return "indexed", info
        try:
            file_pk = await db.add_indexed_file(channel_id, msg_id, info)
            if info.get("file_unique_id") and known_unique_ids is not None:
                known_unique_ids.add(info["file_unique_id"])
            if await auto_payload_active() and info.get("file_name"):
                slug = sanitize_slug(info["file_name"])
                if slug:
                    await create_unique_payload(slug, file_pk)
            return "indexed", info
        except Exception as ie:  # noqa: BLE001
            logger.error("Reindex msg %s: Failed to index: %s", msg_id, ie)
            return "error", None
    except BadRequest as e:
        err_lower = str(e).lower()
        if "not found" in err_lower or "can't be forwarded" in err_lower or "message to copy not found" in err_lower:
            return "missing", None
        elif "protected" in err_lower or "restricted" in err_lower:
            return "protected", None
        logger.warning("Reindex msg %s: BadRequest: %s", msg_id, e)
        return "error", None
    except RetryAfter:
        raise  # caller handles
    except Forbidden:
        raise
    except TelegramError as e:
        logger.warning("Reindex msg %s error: %s", msg_id, e)
        return "error", None



async def _flush_index_batch(batch_queue: List[Tuple[int, int, dict]],
                             channel_id: int) -> int:
    """Flush the queued index rows in ONE transaction. Returns inserted count.
    The queue is flushed in-place (cleared) whether or not the insert
    succeeds — a failed flush is logged and the rows are NOT retried blindly
    (the cursor only advances past flushed messages when the flush succeeded,
    otherwise a rescan re-discovers them)."""
    if not batch_queue:
        return 0
    rows = list(batch_queue)
    batch_queue.clear()
    inserted = await db.add_indexed_files_batch(rows)
    if inserted > 0:
        logger.info("BOT6_INDEX_BATCH_INSERT channel_id=%s queued=%s inserted=%s "
                    "(one transaction)", channel_id, len(rows), inserted)
    else:
        logger.warning("BOT6_INDEX_BATCH_INSERT channel_id=%s queued=%s "
                       "inserted=0 (duplicates or failure — cursor not advanced "
                       "past these messages)", channel_id, len(rows))
    return inserted



async def run_reindex(bot, admin_id: int, channel_id: int, count: Optional[int],
                      status_msg: Message, channel_title: str = "",
                      resume: bool = False) -> None:
    """Issue 26 + PHASE 8: incremental reindex with DURABLE, RESUMABLE jobs.

    FIRST SCAN (last_scanned_message_id is NULL):
      - Determine latest_message_id (exponential + binary probe)
      - Scan BACKWARDS from latest to 1, indexing all content
      - Stop only at genuine history exhaustion (consecutive-missing gap)

    NORMAL SCAN (last_scanned_message_id is set):
      - Determine latest_message_id
      - If latest <= last_scanned -> "Already up to date"
      - Else scan FORWARDS from last_scanned+1 to latest (only NEW messages)

    PHASE 8 truthfulness + durability (spec §1-§9):
      * count=None (the default for manual scans now) means UNBOUNDED — the
        old REINDEX_DEFAULT_COUNT=500 cap silently truncated first scans on
        channels with more history and then reported "Reindex Complete"
        (the exact >9-messages production incident class). A huge runaway
        guard replaces it, and hitting it is a FAILURE, never a success.
      * A durable job record (bot_settings KV index_job:<channel_id>) is
        persisted every JOB_PERSIST_EVERY messages and at every flush
        boundary: a restart mid-scan resumes from the persisted point
        (backward scans resume DOWNWARD — their remaining work is below the
        interruption point), never from zero (unless the admin explicitly
        chooses Full Re-index).
      * Terminal states are honest: SCAN_COMPLETE only when the requested
        range was actually covered; SCAN_STOPPED (admin — resumable),
        SCAN_FAILED (channel inaccessible / fatal), SCAN_PARTIAL (gap /
        cap) are reported as such — the UI NEVER says "complete" for a
        partial scan.

    Issue 3 Critical Fix: acquires the per-channel reindex lock so only ONE
    worker runs per channel at any time. If a worker is already running, this
    call returns immediately without scanning.
    """
    # Issue 3: acquire lock — only ONE reindex worker per channel.
    if not acquire_reindex_lock(channel_id):
        try:
            await status_msg.edit_text(
                f"\u23F3 A reindex is already running on {channel_title}.\n\n"
                f"Please wait for it to complete."
            )
        except TelegramError:
            pass
        return
    try:
        # PHASE 8 §6: resume an interrupted scan unless the caller explicitly
        # requested a fresh pass. (run_full_reindex resets the cursor + job
        # record itself before calling the inner function.)
        resume_job = None
        if resume or count is None:
            job = await _index_job_load(channel_id)
            plan = _idx_engine.resume_plan(
                job, full_rescan=False, incremental=(count is None),
                resume_requested=resume)
            if plan["action"] == "resume":
                resume_job = plan["job"]
                logger.info("BOT6_INDEX_RESUME channel_id=%s job_id=%s "
                            "resume_msg_id=%s reason=%s",
                            channel_id, job.get("job_id"),
                            job.get("resume_msg_id"), plan["reason"])
        await _run_reindex_inner(bot, admin_id, channel_id, count, status_msg,
                                 channel_title, resume_job=resume_job)
    finally:
        # Issue 3: always release the lock, even on error.
        release_reindex_lock(channel_id)



async def _run_reindex_inner(bot, admin_id: int, channel_id: int,
                             count: Optional[int],
                             status_msg: Message, channel_title: str = "",
                             resume_job: Optional[Dict[str, Any]] = None) -> None:
    """Inner reindex logic (called by run_reindex after lock acquired).

    PHASE 8: count=None scans the ENTIRE requested range (bounded only by
    the runaway guard). resume_job continues an interrupted scan with its
    original direction/range/counters. Terminal status is computed honestly
    and persisted in the durable job record + run summary."""
    # V26 Phase 8 telemetry: the durable reindex scan lifecycle.
    logger.info("INDEX_REINDEX_START channel_id=%s mode=%s resuming=%s",
                channel_id, "resume" if resume_job is not None else "scan",
                bool(resume_job is not None))
    processed = indexed = duplicates = no_media = missing = protected = errors = 0
    file_ids_refreshed = 0  # PHASE 7 HOTFIX: duplicates whose stale file_id was repaired
    replaced = 0  # BOT-43: source-media replacements (guarded in-place swaps)
    last_action = "Starting..."
    current_filename = ""
    started_at = time.time()

    # Resolve channel title (never expose raw channel id in dashboard).
    if not channel_title:
        channel_title = str(channel_id)
        try:
            chat = await bot.get_chat(channel_id)
            if chat and chat.title:
                channel_title = chat.title
        except TelegramError:
            pass

    # ------------------------------------------------------------------
    # PHASE 8: resume an interrupted job (bot restart / admin stop).
    # ------------------------------------------------------------------
    job: Dict[str, Any]
    if resume_job is not None:
        job = resume_job
        counters = job.get("counters", {})
        processed = int(counters.get("processed", 0))
        indexed = int(counters.get("indexed", 0))
        duplicates = int(counters.get("duplicates", 0))
        file_ids_refreshed = int(counters.get("file_ids_refreshed", 0))
        replaced = int(counters.get("replaced", 0))  # BOT-43
        no_media = int(counters.get("no_media", 0))
        protected = int(counters.get("protected", 0))
        missing = int(counters.get("missing", 0))
        errors = int(counters.get("errors", 0))
        direction = int(job.get("direction", -1))
        scan_start = int(job.get("scan_start", 0))
        scan_end = int(job.get("scan_end", 1))
        latest = int(job.get("latest", scan_start))
        scan_mode = str(job.get("mode", "resumed"))
        is_first_scan = direction == -1
        max_missing = REINDEX_FIRST_SCAN_MAX_MISSING if is_first_scan \
            else REINDEX_MAX_CONSEC_MISSING
        msg_id = int(job.get("resume_msg_id", scan_start)) + direction
        consecutive_missing = int(job.get("consecutive_missing", 0))
        consecutive_no_media = int(job.get("consecutive_no_media", 0))
        last_scanned = None  # only used for forward-cursor floor; job carries it
        job["status"] = _idx_engine.SCAN_RUNNING
        logger.info("BOT6_INDEX_RESUME_CONTINUE channel_id=%s job_id=%s "
                    "resuming_at=%s direction=%s prior_processed=%s",
                    channel_id, job.get("job_id"), msg_id, direction,
                    processed)
        await _reindex_edit_status(status_msg, (
            "\U0001F504 Reindex Progress\n\n"
            f"\U0001F4E1 Channel: {channel_title}\n"
            f"\U0001F4CB Mode: {scan_mode} (RESUMED)\n"
            f"\U0001F4E4 Resuming at: {msg_id}\n"
            f"\U0001F50D Prior processed: {processed}\n"
        ))
    else:
        # Read the incremental cursor.
        state = await db.get_reindex_state(channel_id)
        last_scanned = None
        if state:
            last_scanned = state["last_scanned_message_id"]
        is_first_scan = last_scanned is None
        logger.debug("Reindex: channel=%s last_scanned=%s first_scan=%s",
                     channel_id, last_scanned, is_first_scan)

        # PHASE 8: distinguish "channel inaccessible" from "empty" BEFORE
        # probing (the probe cannot tell them apart). A scan on an
        # inaccessible channel FAILS honestly — it never reports 'empty'.
        # (Skipped when the transport has no get_chat — fully-mocked tests.)
        _get_chat = getattr(bot, "get_chat", None) if bot is not None else None
        if _get_chat is not None:
            try:
                await _get_chat(channel_id)
            except (BadRequest, Forbidden) as e:
                await _reindex_edit_status(status_msg, (
                    "\u274C Scan FAILED\n\n"
                    f"\U0001F4E1 Channel: {channel_title}\n"
                    f"\U0001F4CB Status: {_idx_engine.SCAN_FAILED}\n"
                    f"\u274C The bot cannot access this channel "
                    f"({type(e).__name__}).\n"
                    "Nothing was scanned and the cursor was NOT changed.\n"
                    "Fix the bot's membership in the channel, then reindex."
                ))
                job = _idx_engine.new_job_record(
                    channel_id, "failed_no_access", 0, 0, 1, 0)
                _idx_engine.finish(job, _idx_engine.SCAN_FAILED,
                                   "channel inaccessible to the bot")
                await _index_job_save(channel_id, job)
                return
            except TelegramError:
                pass  # transient — fall through to the probe honestly

        # Determine latest_message_id (needed for both first + normal scans).
        await _reindex_edit_status(status_msg, (
            "\U0001F504 Reindex Progress\n\n"
            f"\U0001F4E1 Channel: {channel_title}\n"
            f"\U0001F50D Determining latest message_id...\n"
        ))

        # V25 §5/§12: seed the latest-id search from the DB's own max indexed
        # message id + the newest DB-recorded candidate ids (gap-truncation
        # and dead-db_max immunity — see determine_latest_message_id).
        try:
            _db_max = await db.max_message_id_for_channel(channel_id)
        except Exception:  # noqa: BLE001 — repository read is best-effort
            _db_max = None
        try:
            _db_candidates = await db.message_ids_desc_for_channel(channel_id, 40)
        except Exception:  # noqa: BLE001 — repository read is best-effort
            _db_candidates = []
        latest = await determine_latest_message_id(
            bot, admin_id, channel_id, _db_max,
            db_candidate_message_ids=_db_candidates)
        logger.debug("Reindex: channel=%s latest=%s db_max=%s",
                     channel_id, latest, _db_max)
        if latest is None:
            # Channel is empty OR history could not be verified right now
            # (PHASE 8 probe tri-state). The scan does NOT guess.
            await _reindex_edit_status(status_msg, (
                "\u274C Scan FAILED\n\n"
                f"\U0001F4E1 Channel: {channel_title}\n"
                f"\U0001F4CB Status: {_idx_engine.SCAN_FAILED}\n"
                "\u274C Could not determine the channel\'s latest message "
                "(empty channel or transient Telegram failure).\n"
                "Nothing was scanned and the cursor was NOT changed.\n"
                "Run Channel Test, then retry."
            ))
            job = _idx_engine.new_job_record(
                channel_id, "failed_latest_unknown", 0, 0, 1, 0)
            _idx_engine.finish(job, _idx_engine.SCAN_FAILED,
                               "latest message could not be determined")
            await _index_job_save(channel_id, job)
            return

        # Decide scan range + direction.
        if is_first_scan:
            # FIRST SCAN: backwards from latest to 1.
            scan_start = latest
            scan_end = 1
            direction = -1
            max_missing = REINDEX_FIRST_SCAN_MAX_MISSING  # 100
            scan_mode = "First scan (backward)"
        else:
            # NORMAL SCAN: forwards from last_scanned+1 to latest.
            if latest <= last_scanned:
                # Already up to date — skip immediately (no scan, no worker).
                logger.debug("Reindex: channel=%s SKIPPED (latest=%s <= last_scanned=%s)",
                             channel_id, latest, last_scanned)
                summary = (
                    "\u2705 Reindex Complete\n\n"
                    f"\U0001F4E1 Channel: {channel_title}\n"
                    f"\U0001F4CB Status: Already up to date\n\n"
                    f"\U0001F50D Latest message: {latest}\n"
                    f"\U0001F4E1 Last scanned: {last_scanned}\n\n"
                    f"\U0001F4E6 Indexed: 0\n"
                    f"\u267B\uFE0F Duplicates: 0\n"
                    f"\u23ED No Media: 0\n"
                    f"\U0001F6AB Protected: 0\n"
                    f"\U0001F4ED Missing: 0\n"
                    f"\u274C Errors: 0\n\n"
                    f"\U0001F4C8 Progress: 100%"
                )
                await _reindex_edit_status(status_msg, summary)
                # Cursor unchanged (still up to date).
                await db.update_reindex_state(channel_id)
                return
            scan_start = last_scanned + 1
            scan_end = latest
            direction = 1
            max_missing = REINDEX_MAX_CONSEC_MISSING  # 50
            scan_mode = "Normal scan (forward)"

        job = _idx_engine.new_job_record(
            channel_id,
            "first_scan_backward" if direction == -1 else "incremental_forward",
            direction, scan_start, scan_end, latest)
        msg_id = scan_start
        consecutive_missing = 0
        consecutive_no_media = 0

    last_indexed_id = None
    last_media_id = None

    # PHASE 7 (Task 1): performance + cancellation + restart safety.
    # * ONE preload of the exact-identity set replaces a per-message SELECT.
    # * Batched inserts (one short write-locked transaction per <=50 rows)
    #   replace per-row INSERT+COMMIT when auto-payload is inactive.
    # * The cancel flag is checked every message (graceful stop at the next
    #   boundary; the cursor + flushed rows + JOB RECORD are preserved so a
    #   restart or re-press resumes exactly where the scan stopped).
    # Duplicate semantics are UNCHANGED and EXACT: a file is a duplicate ONLY
    # when its Telegram file_unique_id (or, for NULL identity, the same
    # channel+message) is already indexed — similar names/sizes/durations
    # are NEVER duplicates.
    index_cancel_clear(channel_id)
    if not resume_job:
        try:
            known_unique_ids = await db.all_indexed_unique_ids()
        except Exception as e:  # noqa: BLE001 — preload is an optimization only
            logger.warning("BOT6_INDEX_PRELOAD_FAILED channel_id=%s exc=%s — "
                           "falling back to per-message duplicate lookups",
                           channel_id, e)
            known_unique_ids = None
    else:
        # Resumed scan: rebuild the preload from the DB (rows flushed before
        # the interruption are already committed).
        try:
            known_unique_ids = await db.all_indexed_unique_ids()
        except Exception as e:  # noqa: BLE001
            logger.warning("BOT6_INDEX_PRELOAD_FAILED channel_id=%s exc=%s — "
                           "falling back to per-message duplicate lookups",
                           channel_id, e)
            known_unique_ids = None
    batch_queue: List[Tuple[int, int, dict]] = []
    batch_flush_fail_first_msg: Optional[int] = None
    was_cancelled = False
    fatal_error = False

    total_range = abs(scan_start - scan_end) + 1

    def _progress_pct() -> int:
        if total_range <= 0:
            return 100
        return min(100, int((processed / total_range) * 100))

    def _reindex_dashboard_text() -> str:
        # Plain text — no Markdown — so filenames / last_action can never crash
        # Telegram formatting. Issue 26 + PHASE 8: Current / Latest / N of M.
        return (
            "\U0001F504 Reindex Progress\n\n"
            f"\U0001F4E1 Channel: {channel_title}\n"
            f"\U0001F4CB Mode: {scan_mode}\n"
            f"\U0001F4E4 Current: {msg_id}\n"
            f"\U0001F50D Latest: {latest}\n"
            f"\U0001F4DA Scanned: {processed} / {total_range} messages\n"
            f"\U0001F4E6 Indexed: {indexed}\n"
            f"\u267B\uFE0F Duplicates: {duplicates}\n"
            f"\U0001F504 Replaced: {replaced}\n"
            f"\u23ED No Media: {no_media}\n"
            f"\U0001F6AB Protected: {protected}\n"
            f"\U0001F4ED Missing: {missing}\n"
            f"\u274C Errors: {errors}\n"
            f"\U0001F4C8 Progress: {_progress_pct()}%\n\n"
            f"\u2139\uFE0F Last: {last_action[:80]}"
        )

    # Main scan loop. PHASE 8: count=None -> UNBOUNDED (runaway guard only);
    # a bounded count remains honored (admin-requested limited scans) and is
    # reported truthfully as SCAN_PARTIAL when it truncates the range.
    while count is None or processed < count:
        if processed >= _idx_engine.SCAN_RUNAWAY_GUARD:
            fatal_error = True
            last_action = "runaway guard reached"
            logger.error("BOT6_INDEX_RUNAWAY channel_id=%s processed=%s — "
                         "scan aborted (this is a FAILURE, never 'complete')",
                         channel_id, processed)
            break
        # Stop: reached scan_end.
        if direction == 1 and msg_id > scan_end:
            break
        if direction == -1 and msg_id < scan_end:
            break
        # Stop: max consecutive missing.
        if consecutive_missing >= max_missing:
            break
        # Stop: 100 consecutive no-media (normal scan only).
        if not is_first_scan and consecutive_no_media >= REINDEX_MAX_CONSEC_NO_MEDIA:
            break
        # PHASE 7 (Task 1): graceful admin-requested stop.
        if index_cancel_requested(channel_id):
            was_cancelled = True
            last_action = "Stopped by admin (graceful)"
            break

        try:
            outcome, info = await _index_one_message(
                bot, admin_id, channel_id, msg_id,
                known_unique_ids=known_unique_ids,
                batch_queue=batch_queue)
            # V26 Phase 8 telemetry: the per-message reindex outcome.
            logger.info("INDEX_REINDEX_MESSAGE channel_id=%s message_id=%s "
                        "outcome=%s", channel_id, msg_id, outcome)
            _refreshed_flag = False
            if outcome == "indexed":
                indexed += 1
                consecutive_missing = 0
                consecutive_no_media = 0
                last_indexed_id = msg_id
                last_media_id = msg_id
                current_filename = (info or {}).get("file_name", "") or ""
                last_action = f"Indexed: {current_filename[:30]}"
                logger.info("Reindex msg %s: Indexed type=%s name=%s",
                            msg_id, (info or {}).get("media_type"), current_filename)
            elif outcome == "repointed":
                # V25 S2/S3: the canonical row was re-pointed to this NEW
                # storage message (its old source was CONFIRMED deleted and
                # the same identity was re-sent). Counted as an INDEXED
                # outcome — a new usable canonical reference was established.
                indexed += 1
                consecutive_missing = 0
                consecutive_no_media = 0
                last_indexed_id = msg_id
                last_media_id = msg_id
                current_filename = (info or {}).get("file_name", "") or ""
                last_action = f"Re-pointed: {current_filename[:30]}"
                logger.info(
                    "Reindex msg %s: Re-pointed canonical row to this message "
                    "(dead old source replaced by the re-upload)",
                    msg_id)
            elif outcome == "replaced":
                # BOT-43 (SOURCE_MEDIA_REPLACEMENT): the canonical row for
                # this EXACT (channel_id, message_id) was updated IN PLACE
                # to the admin's replacement media (NEW file_unique_id) —
                # pk, payload references and stats all preserved. Counted
                # as an INDEXED outcome (a new usable canonical identity
                # was established — the same treatment as "repointed"),
                # PLUS its own durable "replaced" job counter (additive
                # key inside the job's counters dict — engine.py untouched).
                indexed += 1
                replaced += 1
                consecutive_missing = 0
                consecutive_no_media = 0
                last_indexed_id = msg_id
                last_media_id = msg_id
                current_filename = (info or {}).get("file_name", "") or ""
                last_action = f"Replaced: {current_filename[:30]}"
                _job_counters = job.setdefault("counters", {})
                _job_counters["replaced"] = int(
                    _job_counters.get("replaced", 0)) + 1
                logger.info(
                    "Reindex msg %s: Source media replaced in place "
                    "(new file identity at the same channel+message — "
                    "payload references preserved)", msg_id)
            elif outcome == "duplicate":
                duplicates += 1
                consecutive_missing = 0
                consecutive_no_media = 0
                last_media_id = msg_id
                current_filename = (info or {}).get("file_name", "") or ""
                last_action = f"Skipped (dup): {current_filename[:30]}"
                # PHASE 7 HOTFIX: the duplicate may ALSO have repaired a
                # stale canonical file_id in place (bot-token change).
                _refreshed_flag = bool((info or {}).pop("_file_id_refreshed", False))
                if _refreshed_flag:
                    file_ids_refreshed += 1
                # Deterministic duplicate decision log (restart-safe: the
                # identity set is precomputed from the same table).
                logger.info("BOT6_INDEX_DUPLICATE channel_id=%s message_id=%s "
                            "identity=file_unique_id exact=True "
                            "file_id_refreshed=%s",
                            channel_id, msg_id, _refreshed_flag)
            elif outcome == "no_media":
                no_media += 1
                consecutive_missing = 0
                consecutive_no_media += 1
                last_action = f"Skipped (no media): msg {msg_id}"
            elif outcome == "missing":
                missing += 1
                consecutive_missing += 1
                last_action = f"Skipped (missing): msg {msg_id}"
            elif outcome == "protected":
                protected += 1
                consecutive_missing = 0
                consecutive_no_media += 1
                last_action = f"Skipped (protected): msg {msg_id}"
            elif outcome == "error":
                errors += 1
                consecutive_missing = 0
                last_action = f"Failed: msg {msg_id}"
            processed += 1
            _idx_engine.advance(job, msg_id,
                                "indexed" if outcome in ("repointed",
                                                          "replaced")
                                else outcome,
                                refreshed=_refreshed_flag)
        except RetryAfter as e:
            # Retry the SAME msg_id after flood wait. Do NOT increment processed.
            logger.warning("Reindex flood control: sleeping %ss", e.retry_after)
            await asyncio.sleep(e.retry_after)
            _idx_engine.touch(job)
            continue
        except Forbidden:
            logger.error("Reindex: bot blocked by admin %s", admin_id)
            errors += 1
            processed += 1
            last_action = "Error: blocked by admin"
            fatal_error = True
            break

        msg_id += direction
        await asyncio.sleep(REINDEX_DELAY)

        # PHASE 7 (Task 1): flush the batch at the threshold — one short
        # transaction per <=50 files instead of 50 individual commits.
        if len(batch_queue) >= INDEX_BATCH_FLUSH_SIZE:
            _first_batch_msg = batch_queue[0][1] if batch_queue else None
            inserted_now = await _flush_index_batch(batch_queue, channel_id)
            if inserted_now <= 0 and _first_batch_msg is not None:
                batch_flush_fail_first_msg = _first_batch_msg
            await _index_job_save(channel_id, job)

        # PHASE 8: durable mid-scan progress (survives restart; resumes here).
        if processed % _idx_engine.JOB_PERSIST_EVERY == 0:
            await _index_job_save(channel_id, job)

        # Progress every 10 messages.
        if processed % 10 == 0:
            await _reindex_edit_status(status_msg, _reindex_dashboard_text())

    # PHASE 7 (Task 1): final flush of the remaining queued rows.
    if batch_queue:
        _first_batch_msg = batch_queue[0][1] if batch_queue else None
        inserted_now = await _flush_index_batch(batch_queue, channel_id)
        if inserted_now <= 0 and _first_batch_msg is not None \
                and batch_flush_fail_first_msg is None:
            batch_flush_fail_first_msg = _first_batch_msg
    index_cancel_clear(channel_id)

    # Invariant verification (defensive).
    _sum_cats = indexed + duplicates + no_media + protected + missing + errors
    if _sum_cats != processed:
        logger.error("Reindex counter invariant BROKEN: processed=%d != sum=%d "
                     "(indexed=%d dup=%d no_media=%d protected=%d missing=%d errors=%d)",
                     processed, _sum_cats, indexed, duplicates, no_media,
                     protected, missing, errors)

    # Update the incremental cursor.
    # last_scanned = the furthest message we reached in this scan.
    # PHASE 7 (Task 1): NORMAL scans now persist the FURTHEST PROCESSED
    # message (not blindly `latest`) so a stopped/capped/failed scan never
    # skips unscanned messages — restart resumes exactly at the boundary.
    # A failed final batch flush additionally holds the cursor before the
    # first un-flushed message (nothing is ever lost silently).
    if is_first_scan:
        new_last_scanned = scan_start  # latest (we scanned from latest down)
    else:
        # Furthest message actually processed (msg_id points at the NEXT
        # unprocessed message after the loop increments).
        furthest_processed = msg_id - direction
        if direction == 1:
            furthest_processed = min(furthest_processed, latest)
            _floor = (last_scanned or 0)
            if _floor and furthest_processed < _floor:
                furthest_processed = _floor
        else:
            furthest_processed = max(min(furthest_processed, scan_start), 1)
        new_last_scanned = furthest_processed
        if batch_flush_fail_first_msg is not None:
            # Hold the cursor before the first un-flushed message.
            _safe_cursor = batch_flush_fail_first_msg - 1
            if direction == 1 and _safe_cursor < new_last_scanned:
                new_last_scanned = max((last_scanned or 0), _safe_cursor)
            logger.warning("BOT6_INDEX_CURSOR_HELD channel_id=%s cursor=%s "
                           "reason=batch_flush_failed first_unflushed=%s "
                           "(a rescan re-discovers these messages)",
                           channel_id, new_last_scanned, batch_flush_fail_first_msg)
    await db.update_reindex_state(
        channel_id,
        last_scanned_message_id=new_last_scanned,
        last_indexed_message_id=(last_indexed_id if last_indexed_id is not None else 0),
        last_media_message_id=(last_media_id if last_media_id is not None else 0),
    )

    # ------------------------------------------------------------------
    # PHASE 8: TRUTHFUL terminal status (spec §2 — never 'complete' when the
    # scan was partial). The old code always rendered "Reindex Complete".
    # ------------------------------------------------------------------
    if was_cancelled:
        scan_status = _idx_engine.SCAN_STOPPED
    elif fatal_error:
        scan_status = _idx_engine.SCAN_FAILED
    else:
        reached_end = (direction == 1 and msg_id > scan_end) or \
                      (direction == -1 and msg_id < scan_end)
        if reached_end and errors == 0:
            scan_status = _idx_engine.SCAN_COMPLETE
        elif reached_end and errors > 0:
            scan_status = _idx_engine.SCAN_PARTIAL
        elif errors > 0 and indexed == 0 and duplicates == 0:
            scan_status = _idx_engine.SCAN_FAILED
        else:
            scan_status = _idx_engine.SCAN_PARTIAL

    if is_first_scan:
        stopped_reason = f"first scan complete (scanned {processed} messages)"
        if consecutive_missing >= max_missing:
            stopped_reason = (f"first scan PARTIAL: {max_missing} consecutive "
                              f"missing (history gap at msg {msg_id}) — older "
                              f"history may exist below the gap")
        if was_cancelled:
            stopped_reason = "stopped by admin (resumes with Resume/Reindex — cursor + job preserved)"
        if fatal_error:
            stopped_reason = "fatal error (bot blocked / runaway guard)"
    else:
        stopped_reason = "latest reached"
        if consecutive_missing >= max_missing:
            stopped_reason = (f"{max_missing} consecutive missing (history gap "
                              f"at msg {msg_id}) — scan PARTIAL, resumable")
        elif consecutive_no_media >= REINDEX_MAX_CONSEC_NO_MEDIA:
            stopped_reason = (f"{REINDEX_MAX_CONSEC_NO_MEDIA} consecutive no-media — "
                              f"scan PARTIAL, resumable")
        elif count is not None and processed >= count:
            stopped_reason = f"safety cap reached ({count}) — scan PARTIAL, resumable"
        elif errors > 0 and indexed == 0 and duplicates == 0:
            stopped_reason = "blocked / fatal error"
        if was_cancelled:
            stopped_reason = (f"stopped by admin at message {new_last_scanned} "
                              "(cursor + job preserved — Resume continues here)")
        if fatal_error:
            stopped_reason = "fatal error (bot blocked / runaway guard)"

    duration_secs = max(0, int(time.time() - started_at))

    # PHASE 8: persist the terminal job record (durable resume state + the
    # Index Status panel reads its status/counters).
    _idx_engine.finish(job, scan_status, stopped_reason)
    job["cursor"] = new_last_scanned
    await _index_job_save(channel_id, job)

    # PHASE 7 (Task 1): persist the run counters for the Storage Center
    # Index Status panel (idempotent KV upsert; restart-safe).
    await _index_save_run_summary(channel_id, {
        "mode": scan_mode,
        "status": scan_status,
        "processed": processed,
        "total_range": total_range,
        "indexed": indexed,
        "duplicates": duplicates,
        "file_ids_refreshed": file_ids_refreshed,
        "replaced": replaced,
        "no_media": no_media,
        "protected": protected,
        "missing": missing,
        "errors": errors,
        "stopped": was_cancelled,
        "stopped_reason": stopped_reason,
        "cursor": new_last_scanned,
        "duration_secs": duration_secs,
        "finished_at": _now_iso(),
    })
    logger.info("BOT6_INDEX_SCAN_FINISHED channel_id=%s status=%s mode=%s "
                "processed=%s total_range=%s indexed=%s duplicates=%s "
                "file_ids_refreshed=%s errors=%s duration_secs=%s",
                channel_id, scan_status, scan_mode, processed, total_range,
                indexed, duplicates, file_ids_refreshed, errors, duration_secs)
    # V26 Phase 8 telemetry: the durable reindex scan terminal event
    # (the honest status — COMPLETE only when the range was covered).
    logger.info("INDEX_REINDEX_COMPLETE channel_id=%s status=%s mode=%s "
                "processed=%s indexed=%s duplicates=%s "
                "metadata_refreshed_during_scan=True errors=%s",
                channel_id, scan_status, scan_mode, processed, indexed,
                duplicates, errors)

    status_line = _idx_engine.scan_state_label(scan_status)
    summary = (
        f"{status_line}\n\n"
        f"\U0001F4E1 Channel: {channel_title}\n"
        f"\U0001F4CB Stopped: {stopped_reason}\n\n"
        f"\U0001F50D Processed: {processed}"
        f"{' / ' + str(total_range) if total_range else ''} messages\n\n"
        f"\U0001F4E6 Indexed: {indexed}\n"
        f"\u267B\uFE0F Duplicates (exact): {duplicates}\n"
        f"\U0001F504 Media replaced: {replaced}\n"
        f"\U0001F527 File IDs refreshed: {file_ids_refreshed}\n"
        f"\u23ED No Media: {no_media}\n"
        f"\U0001F6AB Protected: {protected}\n"
        f"\U0001F4ED Missing: {missing}\n"
        f"\u274C Errors: {errors}\n"
        f"\U0001F517 Cursor: {new_last_scanned}\n"
        f"\u23F1 Duration: {duration_secs}s\n\n"
        f"\U0001F4C8 Progress: {_progress_pct()}%"
    )
    if scan_status == _idx_engine.SCAN_STOPPED:
        summary += "\n\n\u23ED\uFE0F This scan is RESUMABLE — use Resume in the Index menu."
    elif scan_status == _idx_engine.SCAN_PARTIAL:
        summary += "\n\n\u26A0\uFE0F PARTIAL scan — the requested range was NOT fully covered. Use Resume to continue."
    elif scan_status == _idx_engine.SCAN_FAILED:
        summary += "\n\n\u274C FAILED — nothing further is claimed. Check Channel Test, then retry."
    await _reindex_edit_status(status_msg, summary)



async def _reindex_edit_status(status_msg: Message, text: str) -> None:
    """Best-effort edit of the reindex progress message; falls back to send."""
    try:
        await status_msg.edit_text(text)
    except TelegramError:
        pass



# ============================================================
# AUTO REINDEX BACKGROUND LOOP  (Issue 26: incremental)
# ============================================================
async def scan_channel_for_new(bot, channel_row: aiosqlite.Row,
                               admin_id: int) -> Tuple[int, int, int]:
    """BOT6 AUTO INDEX: scan only NEW messages (cursor-based), then return.

    Acquires the per-channel lock AND the GLOBAL indexing lock (non-blocking).
    If the global lock is busy (another manual/auto job is running), logs
    BOT6_INDEX_ALREADY_RUNNING and skips this cycle — the next cycle will pick
    up any new files. Dedup is by file_unique_id so no duplicate records are
    ever created even if two scans overlap.

    Returns (scanned, indexed, duplicates).
    """
    channel_id = channel_row["channel_id"]
    # Per-channel guard: skip if a manual reindex is already on this channel.
    if not acquire_reindex_lock(channel_id):
        logger.info("Auto-reindex: channel %s already has a worker; skipping.", channel_id)
        return 0, 0, 0
    # Global guard: only ONE indexing op at a time across all channels.
    if not await acquire_global_index_lock():
        logger.warning("BOT6_INDEX_ALREADY_RUNNING — auto-scan skipped for channel %s",
                        channel_id)
        release_reindex_lock(channel_id)
        return 0, 0, 0
    try:
        logger.info("BOT6_INDEX_START mode=auto channel_id=%s", channel_id)
        logger.info("INDEX_REINDEX_START channel_id=%s mode=auto", channel_id)
        result = await _scan_channel_for_new_inner(bot, channel_row, admin_id)
        scanned, indexed, duplicates = result
        logger.info("BOT6_INDEX_COMPLETE mode=auto channel_id=%s scanned=%s indexed=%s dup=%s",
                    channel_id, scanned, indexed, duplicates)
        logger.info("INDEX_REINDEX_COMPLETE channel_id=%s status=complete "
                    "mode=auto processed=%s indexed=%s duplicates=%s",
                    channel_id, scanned, indexed, duplicates)
        logger.info("BOT6_INDEX_IDLE")
        return result
    finally:
        release_global_index_lock()
        release_reindex_lock(channel_id)



async def _scan_channel_for_new_inner(bot, channel_row: aiosqlite.Row,
                                      admin_id: int) -> Tuple[int, int, int]:
    """Inner auto-scan logic (called by scan_channel_for_new after lock acquired)."""
    channel_id = channel_row["channel_id"]
    state = await db.get_reindex_state(channel_id)
    last_scanned = state["last_scanned_message_id"] if state else None

    # First scan (no cursor yet) -> delegate to full run_reindex logic.
    if last_scanned is None:
        # Perform a first scan: determine latest + scan backwards.
        # V25 §5/§12: seed from the DB max + the newest DB-recorded
        # candidate ids (gap-truncation and dead-db_max immunity).
        try:
            _db_max = await db.max_message_id_for_channel(channel_id)
        except Exception:  # noqa: BLE001 — repository read is best-effort
            _db_max = None
        try:
            _db_candidates = await db.message_ids_desc_for_channel(channel_id, 40)
        except Exception:  # noqa: BLE001 — repository read is best-effort
            _db_candidates = []
        latest = await determine_latest_message_id(
            bot, admin_id, channel_id, _db_max,
            db_candidate_message_ids=_db_candidates)
        if latest is None:
            await db.update_reindex_state(channel_id, last_scanned_message_id=0,
                                              last_indexed_message_id=0,
                                              last_media_message_id=0)
            return 0, 0, 0
        scanned = indexed = duplicates = 0
        replaced = 0  # BOT-43: source-media replacements (counted as indexed)
        msg_id = latest
        consecutive_missing = 0
        while consecutive_missing < REINDEX_FIRST_SCAN_MAX_MISSING and msg_id >= 1:
            try:
                outcome, info = await _index_one_message(bot, admin_id, channel_id, msg_id)
                logger.info("INDEX_REINDEX_MESSAGE channel_id=%s "
                            "message_id=%s outcome=%s",
                            channel_id, msg_id, outcome)
                if outcome == "indexed":
                    indexed += 1
                    consecutive_missing = 0
                elif outcome == "replaced":
                    # BOT-43: in-place source-media swap — a new usable
                    # canonical identity was established at this message.
                    indexed += 1
                    replaced += 1
                    consecutive_missing = 0
                elif outcome == "duplicate":
                    duplicates += 1
                    consecutive_missing = 0
                elif outcome == "missing":
                    consecutive_missing += 1
                else:
                    consecutive_missing = 0
                scanned += 1
            except RetryAfter as e:
                await asyncio.sleep(e.retry_after)
                continue
            except Forbidden:
                logger.warning("Auto-scan: admin %s blocked the bot; skipping.", admin_id)
                break
            msg_id -= 1
            await asyncio.sleep(REINDEX_DELAY)
        await db.update_reindex_state(channel_id, last_scanned_message_id=latest,
                                              last_indexed_message_id=latest)
        return scanned, indexed, duplicates

    # Normal incremental scan: determine latest.
    # V25 §5/§12: seed from the DB max + the newest DB-recorded candidate
    # ids (gap-truncation and dead-db_max immunity).
    try:
        _db_max = await db.max_message_id_for_channel(channel_id)
    except Exception:  # noqa: BLE001 — repository read is best-effort
        _db_max = None
    try:
        _db_candidates = await db.message_ids_desc_for_channel(channel_id, 40)
    except Exception:  # noqa: BLE001 — repository read is best-effort
        _db_candidates = []
    latest = await determine_latest_message_id(
        bot, admin_id, channel_id, _db_max,
        db_candidate_message_ids=_db_candidates)
    if latest is None:
        # PHASE 8: latest UNKNOWN (transient) or channel empty — the old code
        # reset the cursor to 0 unconditionally, which forced a FULL backward
        # rescan on the next cycle for what was often a transient glitch.
        # Only reset when the channel is confirmed EMPTY (probe said so via
        # a low latest of 0); otherwise leave the cursor untouched.
        await db.update_reindex_state(channel_id)
        logger.info("BOT6_AUTO_SCAN_LATEST_UNKNOWN channel_id=%s — cursor "
                    "NOT reset (transient probe failure or empty channel)",
                    channel_id)
        return 0, 0, 0

    # Issue 26: if latest <= last_scanned, SKIP.
    if latest <= last_scanned:
        logger.debug("Reindex: channel=%s AUTO-SKIP (latest=%s <= last_scanned=%s)",
                     channel_id, latest, last_scanned)
        return 0, 0, 0

    # Scan only NEW messages (last_scanned+1 → latest).
    scanned = indexed = duplicates = 0
    replaced = 0  # BOT-43: source-media replacements (counted as indexed)
    consecutive_missing = 0
    consecutive_no_media = 0
    msg_id = last_scanned + 1
    stopped_reason = "latest reached"
    while (scanned < AUTO_SCAN_LIMIT
           and msg_id <= latest
           and consecutive_missing < AUTO_SCAN_MAX_MISSING
           and consecutive_no_media < REINDEX_MAX_CONSEC_NO_MEDIA):
        try:
            outcome, info = await _index_one_message(bot, admin_id, channel_id, msg_id)
            logger.info("INDEX_REINDEX_MESSAGE channel_id=%s message_id=%s "
                        "outcome=%s", channel_id, msg_id, outcome)
            if outcome == "indexed":
                indexed += 1
                consecutive_missing = 0
                consecutive_no_media = 0
            elif outcome == "replaced":
                # BOT-43: in-place source-media swap — a new usable
                # canonical identity was established at this message.
                indexed += 1
                replaced += 1
                consecutive_missing = 0
                consecutive_no_media = 0
            elif outcome == "duplicate":
                duplicates += 1
                consecutive_missing = 0
                consecutive_no_media = 0
            elif outcome == "missing":
                consecutive_missing += 1
            elif outcome == "no_media":
                consecutive_no_media += 1
                consecutive_missing = 0
            else:
                consecutive_missing = 0
            scanned += 1
        except RetryAfter as e:
            await asyncio.sleep(e.retry_after)
            continue
        except Forbidden:
            logger.warning("Auto-scan: admin %s blocked the bot; skipping.", admin_id)
            stopped_reason = "forbidden (bot blocked)"
            break
        msg_id += 1
        await asyncio.sleep(REINDEX_DELAY)

    if scanned >= AUTO_SCAN_LIMIT and msg_id <= latest:
        stopped_reason = f"auto-scan per-cycle cap ({AUTO_SCAN_LIMIT})"
    if consecutive_missing >= AUTO_SCAN_MAX_MISSING and msg_id <= latest:
        stopped_reason = f"{AUTO_SCAN_MAX_MISSING} consecutive missing (gap)"
    if consecutive_no_media >= REINDEX_MAX_CONSEC_NO_MEDIA and msg_id <= latest:
        stopped_reason = f"{REINDEX_MAX_CONSEC_NO_MEDIA} consecutive no-media"

    # PHASE 8 CRITICAL FIX: the cursor is the FURTHEST MESSAGE ACTUALLY
    # PROCESSED — NEVER blindly `latest`. The old code wrote latest even
    # when the loop stopped early (per-cycle cap / history gap / Forbidden),
    # which PERMANENTLY SKIPPED every unscanned message between the stop
    # point and latest (the exact silent-truncation bug class the unified
    # specification §1 prohibits). The next cycle re-attempts from here.
    furthest_processed = msg_id - 1
    if furthest_processed > latest:
        furthest_processed = latest
    if last_scanned is not None and furthest_processed < int(last_scanned):
        furthest_processed = int(last_scanned)
    if furthest_processed < int(last_scanned or 0):
        furthest_processed = int(last_scanned or 0)
    await db.update_reindex_state(channel_id, last_scanned_message_id=furthest_processed,
                                              last_indexed_message_id=furthest_processed)
    if stopped_reason != "latest reached":
        logger.info("BOT6_AUTO_SCAN_PARTIAL channel_id=%s scanned=%s cursor=%s "
                    "latest=%s reason=%s (next cycle continues from cursor)",
                    channel_id, scanned, furthest_processed, latest, stopped_reason)
    # PHASE 8: persist truthful auto-run counters for the Index Status panel.
    await _index_save_run_summary(channel_id, {
        "mode": "Auto scan (forward)",
        "status": _idx_engine.SCAN_COMPLETE if stopped_reason == "latest reached"
        else _idx_engine.SCAN_PARTIAL,
        "processed": scanned,
        "indexed": indexed,
        "duplicates": duplicates,
        "file_ids_refreshed": 0,
        "replaced": replaced,
        "no_media": 0,
        "protected": 0,
        "missing": consecutive_missing,
        "errors": 0,
        "stopped": False,
        "stopped_reason": stopped_reason,
        "cursor": furthest_processed,
        "finished_at": _now_iso(),
    })
    return scanned, indexed, duplicates



async def auto_reindex_loop(bot) -> None:
    """Periodically scan all active storage channels for missed media."""
    logger.info("Auto-reindex loop started (interval=%ss).", AUTO_REINDEX_INTERVAL)
    admin_id = ADMIN_IDS[0] if ADMIN_IDS else None
    while True:
        try:
            if await auto_reindex_active() and admin_id is not None:
                channels = await db.list_storage_channels(active_only=True)
                for ch in channels:
                    try:
                        s, i, d = await scan_channel_for_new(bot, ch, admin_id)
                        if i or d:
                            logger.info("Auto-scan %s: scanned=%d indexed=%d dup=%d",
                                        ch["channel_id"], s, i, d)
                    except Exception as e:  # noqa: BLE001
                        logger.error("Auto-scan error for %s: %s", ch["channel_id"], e)
        except asyncio.CancelledError:
            logger.info("Auto-reindex loop cancelled.")
            break
        except Exception as e:  # noqa: BLE001
            logger.error("Auto-reindex loop error: %s", e)
        await asyncio.sleep(AUTO_REINDEX_INTERVAL)



# ============================================================
# CHANNEL POST HANDLERS  (auto indexing)
# ============================================================
async def on_channel_post(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.channel_post:
        await index_message(update.channel_post, edited=False,
                            bot=getattr(context, "bot", None))



async def on_edited_channel_post(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.edited_channel_post:
        await index_message(update.edited_channel_post, edited=True,
                            bot=getattr(context, "bot", None))



async def reindex_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Issue #48: Reindex V3 menu with 4 modes.

    1. Quick Sync (incremental from cursor)
    2. Full Reindex (rescan entire channel)
    3. Reindex From File (use forwarded file as scan boundary)
    4. Verify Index Integrity (compare channel vs DB)
    """
    channels = await db.list_storage_channels()
    text = (
        "\U0001F504 Reindex\n\n"
        "Select a channel and reindex mode."
    )
    buttons: List[List[InlineKeyboardButton]] = []
    if channels:
        for ch in channels:
            title = ch['title'] or 'Channel'
            buttons.append([InlineKeyboardButton(
                f"\U0001F504 {title}",
                callback_data=f"reidxmode:{ch['channel_id']}",
            )])
    else:
        text += "\n\nNo storage channels configured."
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:storage")])
    await safe_edit_text(update.callback_query, text, reply_markup=InlineKeyboardMarkup(buttons))



async def reindex_mode_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              channel_id: int) -> None:
    """Issue #48 + PHASE 8: reindex mode menu for a channel.

    Modes (spec §7 — Incremental / Full / Resume are clearly distinct):
      1. Quick Sync (incremental from cursor; auto-resumes interrupted jobs)
      2. Full Reindex (fresh complete history walk — resets cursor + job)
      3. Reindex From File (forwarded file as scan boundary)
      4. Verify Index (read-only source<->DB<->payload verification)
      5. Reconcile (verification + apply the SAFE repairs)
      6. Resume (only shown when an interrupted scan exists for the channel)
    """
    ch = await db.get_storage_channel(channel_id)
    title = ch['title'] if ch else f"Channel {channel_id}"
    job = await _index_job_load(channel_id)
    resumable = False
    if job is not None:
        resumable = job.get("status") in (
            _idx_engine.SCAN_RUNNING, _idx_engine.SCAN_STOPPED,
            _idx_engine.SCAN_PARTIAL)
        if job.get("status") == _idx_engine.SCAN_RUNNING:
            # A running record that is not stale belongs to a live worker.
            resumable = _idx_engine.job_is_stale(job)
    text = (
        f"\U0001F504 Reindex — {title}\n\n"
        f"1\uFE0F\u20E3 Quick Sync (incremental — fast)\n"
        f"2\uFE0F\u20E3 Full Reindex (fresh full-history rescan)\n"
        f"3\uFE0F\u20E3 Reindex From File (scan boundary)\n"
        f"4\uFE0F\u20E3 Verify Index (read-only integrity check)\n"
        f"5\uFE0F\u20E3 Reconcile (verify + safe repairs)\n"
    )
    kb_rows = [
        [InlineKeyboardButton("1\uFE0F\u20E3 Quick Sync", callback_data=f"reidxquick:{channel_id}")],
        [InlineKeyboardButton("2\uFE0F\u20E3 Full Reindex", callback_data=f"reidxfull:{channel_id}")],
        [InlineKeyboardButton("3\uFE0F\u20E3 Reindex From File", callback_data=f"reidxfromfile:{channel_id}")],
        [InlineKeyboardButton("4\uFE0F\u20E3 Verify Index", callback_data=f"reidxverify:{channel_id}")],
        [InlineKeyboardButton("5\uFE0F\u20E3 Reconcile", callback_data=f"reidxreconcile:{channel_id}")],
    ]
    if resumable:
        counters = job.get("counters", {})
        text += (
            "\n\u23ED\uFE0F Resume — an interrupted scan exists "
            f"({counters.get('processed', 0)} messages done, "
            f"resumes at msg {job.get('resume_msg_id')})\n"
        )
        kb_rows.insert(2, [InlineKeyboardButton(
            "\u23ED\uFE0F Resume Interrupted Scan",
            callback_data=f"reidxresume:{channel_id}")])
    kb_rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:reindex")])
    await safe_edit_text(update.callback_query, text,
                         reply_markup=InlineKeyboardMarkup(kb_rows))



async def run_full_reindex(bot, admin_id: int, channel_id: int,
                            status_msg: Message, channel_title: str = "") -> None:
    """BOT6 MANUAL INDEX + PHASE 8: scan the ENTIRE channel, then STOP.

    Acquires the single GLOBAL indexing lock so no other indexing job runs
    concurrently (spec: 'Only one indexing operation may run at once').
    Resets last_scanned_message_id to NULL AND drops any interrupted job
    record (the admin explicitly chose a FRESH full walk — spec §6/§7), then
    runs the backward first scan UNBOUNDED (count=None — the old 500-cap
    truncation that reported 'complete' after one batch is gone). Logs
    BOT6_INDEX_START / BOT6_INDEX_COMPLETE.
    """
    logger.info("BOT6_INDEX_START mode=manual channel_id=%s admin_id=%s",
                channel_id, admin_id)
    if not await acquire_global_index_lock():
        logger.warning("BOT6_INDEX_ALREADY_RUNNING — manual reindex skipped for channel %s",
                        channel_id)
        try:
            await safe_edit_text(status_msg,
                "\u23F3 Another indexing job is already running. Please wait for it to finish, then retry.")
        except TelegramError:
            pass
        return
    try:
        await db.reset_reindex_state(channel_id)
        await _index_job_clear(channel_id)  # explicit fresh walk (spec §6)
        await _run_reindex_inner(bot, admin_id, channel_id, None,
                                  status_msg, channel_title)
        logger.info("BOT6_INDEX_COMPLETE mode=manual channel_id=%s", channel_id)
        logger.info("BOT6_INDEX_IDLE")
    finally:
        release_global_index_lock()



async def verify_index_integrity(bot, admin_id: int, channel_id: int,
                                  status_msg: Message,
                                  reconcile: bool = False) -> None:
    """PHASE 8 (§3): REAL index verification (read-only unless reconcile).

    Runs the verification engine (app/core/verification.py): a full live
    source walk + targeted orphan probes + the DB cross-matrix (duplicate
    identities, broken payload refs, stale file ids, cross-channel orphans),
    then renders the honest report. With reconcile=True the SAFE repairs are
    applied (index missing media, atomic in-place file_id repair, mark
    unavailable, recover) — nothing is ever deleted and payload
    relationships are never modified.

    Acquires the global indexing lock (read-mostly scan, but serialised
    against write-index jobs to avoid racing on the cursor).
    Logs BOT6_INDEX_START/COMPLETE with mode=verification / reconcile.
    """
    mode = "reconcile" if reconcile else "verification"
    logger.info("BOT6_INDEX_START mode=%s channel_id=%s", mode, channel_id)
    if not await acquire_global_index_lock():
        logger.warning("BOT6_INDEX_ALREADY_RUNNING — %s skipped for channel %s",
                        mode, channel_id)
        try:
            await safe_edit_text(status_msg,
                "\u23F3 Another indexing job is running. Please retry the verification later.")
        except TelegramError:
            pass
        return
    try:
        await _verify_index_integrity_inner(bot, admin_id, channel_id,
                                            status_msg, reconcile=reconcile)
        logger.info("BOT6_INDEX_COMPLETE mode=%s channel_id=%s", mode, channel_id)
        logger.info("BOT6_INDEX_IDLE")
    finally:
        release_global_index_lock()



async def _determine_latest_seeded(bot, admin_id: int, channel_id: int):
    """V25 §5/§12: the verification engine's determine_latest — seeded with
    the DB's own max indexed message id (gap-truncation immunity) AND the
    newest DB-recorded candidate ids (bot-34.log seed-miss immunity: a
    DEAD db_max orphan must not truncate the walk below ids the DB itself
    indexes), so a Telegram history gap at a probe point can NEVER
    truncate the walk below messages the DB knows about
    (bot-31.log: latest=9 vs db message 546 — messages_scanned=9 against
    db_total=753 with a dishonest coverage=full)."""
    try:
        db_max = await db.max_message_id_for_channel(channel_id)
    except Exception:  # noqa: BLE001 — repository read is best-effort
        db_max = None
    try:
        db_candidates = await db.message_ids_desc_for_channel(channel_id, 40)
    except Exception:  # noqa: BLE001 — repository read is best-effort
        db_candidates = []
    return await determine_latest_message_id(
        bot, admin_id, channel_id, db_max,
        db_candidate_message_ids=db_candidates)


def _verification_deps() -> "_verification_engine.Deps":
    """Wire the standalone verification engine to this bot's runtime.

    Epoch info (current bot id vs the stored file_id owner) is filled in by
    the caller — it needs awaitable lookups."""
    return _verification_engine.Deps(
        db=db,
        logger=logger,
        fetch_channel_media=fetch_channel_media,
        index_one_message=_index_one_message,
        probe_message_exists=_probe_message_exists,
        determine_latest=_determine_latest_seeded,
    )



async def _verify_index_integrity_inner(bot, admin_id: int, channel_id: int,
                                         status_msg: Message,
                                         reconcile: bool = False) -> None:
    """Inner verification body (called by verify_index_integrity under the
    global index lock). Delegates to app/core/verification.py and renders the
    honest report + follow-up actions."""
    ch = await db.get_storage_channel(channel_id)
    title = ch['title'] if ch else f"Channel {channel_id}"

    async def _status_cb(text: str) -> None:
        try:
            await safe_edit_text(status_msg, text)
        except TelegramError:
            pass

    deps = _verification_deps()
    # PHASE 8: epoch info for the stale-file_id classification.
    try:
        owner_raw = await db.get_setting("file_id_owner_bot_id")
        deps.file_id_owner_bot_id = int(owner_raw) if owner_raw else None
    except Exception:  # noqa: BLE001
        deps.file_id_owner_bot_id = None
    try:
        me = await bot.get_me()
        deps.current_bot_id = int(me.id) if me else None
    except Exception:  # noqa: BLE001
        deps.current_bot_id = None

    report = await _verification_engine.run_verification(
        deps, bot, admin_id, channel_id, reconcile=reconcile,
        status_cb=_status_cb)
    await _index_save_verify_report(channel_id, report)

    text = _verification_engine.render_report(report, title, reconcile=reconcile)
    kb_rows: List[List[InlineKeyboardButton]] = []
    has_actionable = (
        report.get("source_missing_from_db", 0)
        + report.get("stale_file_ids", 0)
        + report.get("orphaned_records", 0)
        + report.get("reconcile_failed", 0) > 0
        or bool(report.get("epoch_stale"))
    )
    if not reconcile and has_actionable:
        kb_rows.append([InlineKeyboardButton(
            "\U0001F527 Reconcile (apply safe repairs)",
            callback_data=f"reidxreconcile:{channel_id}")])
    if report.get("status") == _verification_engine.VERIFY_STATUS_PARTIAL:
        kb_rows.append([InlineKeyboardButton(
            "\U0001F504 Full Reindex (refresh whole history)",
            callback_data=f"reidxfull:{channel_id}")])
    kb_rows.append([InlineKeyboardButton("\U0001F4CA Index Status",
                                         callback_data="sc:status")])
    kb_rows.append([InlineKeyboardButton("\u2B05\uFE0F Back",
                                         callback_data="panel:reindex")])
    try:
        await safe_edit_text(status_msg, text,
                             reply_markup=InlineKeyboardMarkup(kb_rows))
    except TelegramError:
        pass
