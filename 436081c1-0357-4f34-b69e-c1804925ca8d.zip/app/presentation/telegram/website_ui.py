"""WEBSITE PHASE 3 — Admin Website Control handlers (bot adapter layer).

Integrates into the EXISTING Admin Control Center via the FREE ``wsite:``
callback namespace and ``panel:website`` — NO second admin dashboard.

Implements the exact Add-Website-Payload wizard (spec §15):
  Add Website Payload → Send Thumbnail → Enter/select existing Payload
  link → Resolve canonical Payload → Validate → Preview → Confirm Publish
  → Website listing published.

Plus Website management (spec §18): list, preview, publish, unpublish, edit
metadata, replace thumbnail, enable/disable listing, delete listing
(presentation-layer ONLY — the canonical Payload / indexed media /
Collection / Telegram source always survive).

The module NEVER imports bot.py: every dependency (db, resolvers, safe
send/edit helpers, admin logger) is injected per call by bot.py facades.
"""
from __future__ import annotations

import logging
from types import SimpleNamespace
from typing import Any, Dict, List, Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from app.web.site.service import (
    make_website_service,
    parse_payload_link_input,
    WEBSITE_ENABLED_KEY,
    WEBSITE_PUBLIC_BASE_URL_KEY,
)
# BOT-11 (spec §2-§5): the Main Mini App panel reuses the network
# module's canonical URL builder + validation gate (never a second URL
# policy — presentation importing app/network is the established
# discipline, e.g. network_ui.py).
from app.network.bot_miniapp import (
    canonical_main_app_url,
    validate_main_app_url,
)

logger = logging.getLogger("payload-bot")

# Wizard / editor state keys (registered in bot.py ALL_WIZARD_STATES so
# clear_wizard_states purges them on any panel navigation).
WSITE_WIZARD_KEY = "wsite_wizard"
WSITE_EDIT_KEY = "wsite_edit"
# V26 FINAL (Part 9): the package multi-selection state (server-side,
# admin-scoped; registered for purging like the wizard states).
WSITE_PKG_PICK_KEY = "wsite_pkg_pick"

ADMIN_LIST_PAGE_SIZE = 8


def _kb(rows: List[List[InlineKeyboardButton]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(rows)


def _btn(label: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(label, callback_data=data)


def _wizard_get(context: ContextTypes.DEFAULT_TYPE) -> Optional[Dict[str, Any]]:
    st = context.user_data.get(WSITE_WIZARD_KEY)
    return st if isinstance(st, dict) and st.get("step") else None


def _wizard_clear(context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.pop(WSITE_WIZARD_KEY, None)


def _edit_state(context: ContextTypes.DEFAULT_TYPE) -> Optional[Dict[str, Any]]:
    st = context.user_data.get(WSITE_EDIT_KEY)
    return st if isinstance(st, dict) and st.get("field") else None


def _edit_clear(context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.pop(WSITE_EDIT_KEY, None)


# ============================================================
# Panels
# ============================================================

async def website_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                        deps: Any) -> None:
    """The Website Control panel (panel:website) — Website ON/OFF, listing
    stats, and the entries into the wizard / management / settings."""
    db = deps.db
    svc = make_website_service(db)
    enabled = await svc.website_enabled()
    total = await db.count_website_payloads()
    published = await db.count_website_payloads(published_only=True)
    status_line = ("\U0001F7E2 ON — the public website is live"
                   if enabled else
                   "\U0001F534 OFF — the public website shows maintenance")
    lines = [
        "\U0001F310 WEBSITE CONTROL",
        "",
        f"Status: {status_line}",
        f"Listings: {published} published / {total} total",
        "",
        "The Website is a Payload-level browsing platform: cards are "
        "Payloads,",
        "files are selected from inside the Payload detail page.",
        "Website OFF affects ONLY the public website — Telegram /start,",
        "payload links, Force Join, Watch Ads, Referral, Points, delivery,",
        "network, indexing, storage, broadcasts and admin keep working.",
    ]
    rows = [
        [_btn(("\U0001F7E2 Switch Website " + ("OFF" if enabled else "ON")),
              "wsite:toggle"),
         _btn("\u2699\uFE0F Website Settings", "wsite:settings")],
        [_btn("\u2795 Add Website Payload", "wsite:add")],
        # V26: the two explicit Upload workflows (picker-driven, the SAME
        # shared publication engine — never a second identity system).
        [_btn("\U0001F4E6 Upload Package Payload", "wsite:addpkg"),
         _btn("\U0001F4C4 Upload Single Payload", "wsite:addsingle")],
        [_btn("\U0001F4CB Manage Website Payloads", "wsite:list")],
        # GAP-CLOSURE: the category (§26-§29) and ads (§35-§56) admin
        # panels — dispatch through the wsitecat:/wsad: namespaces in
        # app/presentation/telegram/website_gap_ui.py (admin-gated by the
        # same master admin gate as wsite:).
        [_btn("\U0001F5C2 Categories", "wsitecat:main"),
         _btn("\U0001F4E2 Ads Management", "wsad:main")],
        [_btn("\u2B05\uFE0F Back", "panel:main")],
    ]
    q = update.callback_query
    await deps.safe_edit_text(q, "\n".join(lines), reply_markup=_kb(rows))


async def website_settings_panel(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE,
                                 deps: Any) -> None:
    db = deps.db
    svc = make_website_service(db)
    base = await svc.website_public_base_url()
    enabled = await svc.website_enabled()
    lines = [
        "\u2699\uFE0F WEBSITE SETTINGS",
        "",
        f"Website: {'ON' if enabled else 'OFF'}",
        f"Public base URL: {base or '(not set — links render relative)'}",
        "",
        "Thumbnail priority (automatic fallback chain):",
        "  1. configured Website thumbnail",
        "  2. payload image / indexed image",
        "  3. Telegram thumbnail",
        "  4. styled placeholder art",
        "",
        "Phase 4 serves real thumbnail bytes through the Media Gateway",
        "(/site/thumb/<token>, bounded); missing artwork degrades to the",
        "styled placeholder — never an error page.",
    ]
    rows = [
        [_btn("\U0001F517 Set Public Base URL", "wsite:seturl")],
        [_btn("\U0001F513 Thumbnail Policy", "wsite:thumbpolicy")],
        [_btn("\U0001F3A5 Streaming & Cache", "wsite:stream")],
        # BOT-11 (spec §2-§5): the MAIN MINI APP panel — next to the
        # website_public_base_url editing surface it depends on (the
        # canonical URL IS <base>/site). Dispatches through the wsmain:
        # namespace in THIS module (admin-gated by the same master gate
        # as wsite:).
        [_btn("\U0001F310 Main Mini App", "wsmain:main")],
        # Task 9: VIDEO PRE-ROLL ADS — dispatches through the wspr:
        # namespace in app/presentation/telegram/website_preroll_ui.py
        # (admin-gated by the same master admin gate as wsite:).
        [_btn("\U0001F3AC Video Pre-Roll Ads", "wspr:main")],
        [_btn("\u2B05\uFE0F Back to Website Control", "panel:website")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def website_stream_panel(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any) -> None:
    """WEBSITE PHASE 4 (spec §30): Streaming & Cache — REAL controls over
    the Media Gateway (live bot_settings; toggles take effect on the next
    request; the cache purge actually deletes cache objects)."""
    db = deps.db
    try:
        stream_on = await db.get_setting_bool("website_stream_enabled", True)
    except Exception:  # noqa: BLE001
        stream_on = False
    try:
        cache_on = await db.get_setting_bool("website_cache_enabled", True)
    except Exception:  # noqa: BLE001
        cache_on = False
    try:
        ttl = max(30, min(3600, await db.get_setting_int(
            "website_stream_token_ttl", 300)))
    except Exception:  # noqa: BLE001
        ttl = 300
    try:
        max_bytes = max(1024 * 1024, await db.get_setting_int(
            "website_cache_max_bytes", 2147483648))
    except Exception:  # noqa: BLE001
        max_bytes = 2147483648
    try:
        cache_ttl = max(1, await db.get_setting_int(
            "website_cache_ttl_seconds", 3600))
    except Exception:  # noqa: BLE001
        cache_ttl = 3600
    try:
        max_streams = max(1, await db.get_setting_int(
            "website_max_concurrent_streams", 32))
    except Exception:  # noqa: BLE001
        max_streams = 32

    def _mib(n: int) -> str:
        return f"{n / (1024 * 1024):.0f} MiB" if n < 1024 ** 3 \
            else f"{n / (1024 ** 3):.1f} GiB"

    # Transport + cache status through the REAL gateway singleton.
    gw = getattr(deps, "media_gateway", None)
    if callable(gw):
        try:
            gw = gw()
        except Exception:  # noqa: BLE001
            gw = None
    transport_lines = ["Transport: (media gateway unavailable)"]
    cache_lines = ["Cache: (media gateway unavailable)"]
    if gw is not None:
        ts = gw.transport_status()
        transport_lines = [
            f"Transport mode: {ts.get('mode', '?')}",
            f"Local Bot API: " + (
                f"READY ({ts.get('local_host') or 'private host'})"
                if ts.get("local_ready") else
                "not configured — cloud only (20 MB download cap)"),
            f"Stream chunk: {ts.get('chunk_bytes', 0) // 1024} KiB, "
            f"timeout {ts.get('timeout_seconds', '?')}s",
        ]
        stats = await gw.cache_stats()
        if stats.get("enabled"):
            cache_lines = [
                f"Cache: {'ON' if cache_on else 'OFF'} — "
                f"{stats.get('entries', 0)} entries, "
                f"{_mib(int(stats.get('bytes', 0)))}, "
                f"{stats.get('active_readers', 0)} active reader(s)",
                f"Hits {stats.get('hits', 0)} / misses "
                f"{stats.get('misses', 0)} / evictions "
                f"{stats.get('evictions', 0)} / fallbacks "
                f"{stats.get('fallbacks', 0)}",
            ]
        else:
            cache_lines = ["Cache: disabled (no cache object bound)"]
    # Playback readiness: published listings whose files carry a
    # streamable indexed MIME (video/*, audio/*, image/*).
    try:
        cur = await db.conn.execute(
            "SELECT COUNT(*) AS c FROM website_payloads WHERE published=1")
        row = await cur.fetchone()
        published = int(row["c"]) if row else 0
    except Exception:  # noqa: BLE001
        published = 0
    try:
        cur = await db.conn.execute(
            """SELECT COUNT(DISTINCT w.id) AS c FROM website_payloads w
               JOIN payloads p ON p.id = w.payload_id
               JOIN indexed_files i ON i.id = p.index_id
               WHERE w.published=1 AND (
                 i.mime_type LIKE 'video/%' OR i.mime_type LIKE 'audio/%'
                 OR i.mime_type LIKE 'image/%')""")
        row = await cur.fetchone()
        streamable = int(row["c"]) if row else 0
    except Exception:  # noqa: BLE001
        streamable = 0
    lines = [
        "\U0001F3A5 STREAMING & CACHE (Phase 4 Media Gateway)",
        "",
        f"Streaming: {'ON' if stream_on else 'OFF'} "
        f"(token TTL {ttl}s, max {max_streams} concurrent)",
        *transport_lines,
        "",
        *cache_lines,
        f"Cache limits: {_mib(max_bytes)}, TTL {cache_ttl // 60} min",
        "",
        f"Playback readiness: {streamable}/{published} published listing(s) "
        "have streamable media (video/audio/image MIME).",
        "",
        "Website OFF always shows maintenance first; Telegram is never",
        "gated by any streaming setting.",
    ]
    rows = [
        [_btn(("\U0001F7E2 Streaming ON — turn OFF" if stream_on
               else "\U0001F534 Streaming OFF — turn ON"),
              "wsite:streamtoggle"),
         _btn(("\U0001F4E6 Cache ON — turn OFF" if cache_on
               else "\U0001F4E4 Cache OFF — turn ON"), "wsite:cachetoggle")],
        [_btn("\u23F1 Token TTL", "wsite:sttl"),
         _btn("\U0001F4BE Cache Size", "wsite:csize"),
         _btn("\u23F3 Cache TTL", "wsite:cttl")],
        [_btn("\U0001F9F9 Purge Cache", "wsite:cachepurge")],
        [_btn("\u2B05\uFE0F Back to Website Settings", "wsite:settings")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def website_stream_toggle(update: Update,
                                context: ContextTypes.DEFAULT_TYPE,
                                deps: Any) -> None:
    """REAL toggle: website_stream_enabled (live on the next request)."""
    db = deps.db
    cur = await db.get_setting_bool("website_stream_enabled", True)
    await db.set_setting("website_stream_enabled",
                         "false" if cur else "true")
    await deps.log_admin_action(
        int(update.effective_user.id), "website_stream_toggle", "setting",
        None, f"streaming={'off' if cur else 'on'}")
    await deps.safe_answer_callback(
        update.callback_query,
        f"Streaming {'disabled' if cur else 'enabled'}.")
    await website_stream_panel(update, context, deps)


async def website_cache_toggle(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any) -> None:
    """REAL toggle: website_cache_enabled (live on the next request)."""
    db = deps.db
    cur = await db.get_setting_bool("website_cache_enabled", True)
    await db.set_setting("website_cache_enabled",
                         "false" if cur else "true")
    await deps.log_admin_action(
        int(update.effective_user.id), "website_cache_toggle", "setting",
        None, f"cache={'off' if cur else 'on'}")
    await deps.safe_answer_callback(
        update.callback_query,
        f"Cache {'disabled' if cur else 'enabled'}.")
    await website_stream_panel(update, context, deps)


async def website_cache_purge(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any) -> None:
    """REAL purge: deletes every non-active cache object (entries with
    active readers are doomed and removed when their readers finish —
    the active-reader protection rule)."""
    gw = getattr(deps, "media_gateway", None)
    if callable(gw):
        try:
            gw = gw()
        except Exception:  # noqa: BLE001
            gw = None
    if gw is None:
        await deps.safe_answer_callback(
            update.callback_query,
            "Media gateway unavailable — nothing purged.")
        return
    out = await gw.purge_cache()
    await deps.log_admin_action(
        int(update.effective_user.id), "website_cache_purge", "setting",
        None,
        f"removed={out.get('removed', 0)} doomed_active="
        f"{out.get('doomed_active', 0)}")
    await deps.safe_answer_callback(
        update.callback_query,
        f"Purged {out.get('removed', 0)} cache object(s)"
        + (f"; {out.get('doomed_active', 0)} finish first"
           " (active readers)" if out.get("doomed_active") else "."))
    await website_stream_panel(update, context, deps)


async def website_thumb_policy_panel(update: Update,
                                     context: ContextTypes.DEFAULT_TYPE,
                                     deps: Any) -> None:
    """Thumbnail Settings (spec §14): the fallback chain + per-listing
    thumbnail usage stats. Read-only policy view — replacing a thumbnail
    happens per-listing in Manage Website Payloads."""
    db = deps.db
    try:
        cur = await db.conn.execute(
            "SELECT COUNT(*) AS c FROM website_payloads "
            "WHERE thumb_file_unique_id IS NOT NULL OR thumb_file_id IS "
            "NOT NULL")
        row = await cur.fetchone()
        with_thumb = int(row["c"]) if row else 0
    except Exception:  # noqa: BLE001
        with_thumb = 0
    total = await db.count_website_payloads()
    lines = [
        "\U0001F513 THUMBNAIL SETTINGS",
        "",
        "Display priority (first match wins):",
        "  1. configured Website thumbnail (admin-supplied)",
        "  2. payload image / indexed image thumbnail",
        "  3. Telegram thumbnail reference",
        "  4. styled placeholder art (fallback)",
        "",
        f"Listings with a configured thumbnail: {with_thumb}/{total}",
        "",
        "Phase 4: thumbnails serve as BOUNDED bytes through the Media",
        "Gateway (/site/thumb/<token>, 2 MiB cap, AEAD token bound to the",
        "published listing). Telegram document/video thumbnails that the",
        "Bot API cannot serve degrade honestly to the placeholder art.",
        "",
        "Thumbnails are stored as identity references (file_unique_id) —",
        "internal Telegram file references are never exposed publicly.",
        "Replace a listing's thumbnail from Manage Website Payloads →",
        "a listing's view → Replace Thumbnail.",
    ]
    rows = [[_btn("\u2B05\uFE0F Back to Website Settings", "wsite:settings")]]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def website_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE,
                         deps: Any) -> None:
    """GLOBAL Website ON/OFF (presentation layer ONLY — spec §5)."""
    db = deps.db
    svc = make_website_service(db)
    enabled = await svc.website_enabled()
    await svc.set_website_enabled(not enabled)
    await deps.log_admin_action(
        int(update.effective_user.id), "website_toggle", "setting", None,
        f"website_enabled={'true' if not enabled else 'false'}")
    logger.info("WEBSITE_TOGGLE admin=%s website_enabled=%s",
                update.effective_user.id, not enabled)
    await website_panel(update, context, deps)


# ============================================================
# Management list / view
# ============================================================

async def website_list_panel(update: Update,
                             context: ContextTypes.DEFAULT_TYPE,
                             deps: Any, page: int = 1) -> None:
    db = deps.db
    page = max(1, int(page or 1))
    rows_data, total = await db.list_website_payloads_admin(
        page=page, page_size=ADMIN_LIST_PAGE_SIZE)
    lines = ["\U0001F4CB WEBSITE PAYLOADS (all listings)", ""]
    if not rows_data:
        lines.append("No Website listings yet.")
        lines.append("Use Add Website Payload to publish the first one.")
    for r in rows_data:
        pub = "\U0001F7E2 published" if r["published"] else \
            "\u26A0\uFE0F unpublished"
        alive = "" if int(r["canonical_alive"] or 0) else \
            "  \u274C canonical missing"
        title = str(r["eff_title"] or "(untitled)")
        lines.append(f"#{r['wdbid']} {title[:48]} — {r['file_count']} file"
                     + ("s" if int(r["file_count"] or 0) != 1 else "")
                     + f", {pub}{alive}")
    pages = max(1, (total + ADMIN_LIST_PAGE_SIZE - 1) // ADMIN_LIST_PAGE_SIZE)
    lines += ["", f"Page {min(page, pages)}/{pages} — {total} listing"
              + ("s" if total != 1 else "")]
    rows: List[List[InlineKeyboardButton]] = []
    for r in rows_data:
        rows.append([_btn(f"#{r['wdbid']} {(str(r['eff_title']) or '—')[:28]}",
                          f"wsite:view:{int(r['wdbid'])}")])
    nav = []
    if page > 1:
        nav.append(_btn("\u2190 Prev", f"wsite:lpage:{page-1}"))
    if page < pages:
        nav.append(_btn("Next \u2192", f"wsite:lpage:{page+1}"))
    if nav:
        rows.append(nav)
    rows += [
        [_btn("\u2795 Add Website Payload", "wsite:add")],
        [_btn("\U0001F4E6 Upload Package Payload", "wsite:addpkg"),
         _btn("\U0001F4C4 Upload Single Payload", "wsite:addsingle")],
        [_btn("\u2B05\uFE0F Back to Website Control", "panel:website")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def _listing_view_lines(db: Any, listing: Dict[str, Any]
                              ) -> List[str]:
    """Shared listing preview (wizard + management view — spec §15)."""
    svc = make_website_service(db)
    canonical_desc = ""
    file_count = "?"
    if listing.get("collection_id"):
        cnt = await db.count_collection_items(str(listing["collection_id"]))
        file_count = str(cnt)
        canonical_desc = f"Collection: c-link {listing['collection_id']}"
    elif listing.get("payload_id") is not None:
        prow = await db.get_payload_by_id(int(listing["payload_id"]))
        if prow:
            file_count = "1"
            code = prow["payload"] if "payload" in prow.keys() else "?"
            dn = prow["display_name"] if "display_name" in prow.keys() else None
            canonical_desc = f"Payload: {code}" + (f" ({dn})" if dn else "")
        else:
            file_count = "0"
            canonical_desc = "Payload: \u26A0\uFE0F canonical missing"
    thumb = ("\U0001F5BC custom thumbnail configured"
             if listing.get("thumb_file_unique_id") or
             listing.get("thumb_file_id")
             else "\U0001F5BC automatic fallback chain")
    eff_title = (listing.get("title")
                 or (canonical_desc.split(" (")[0].replace("Payload: ", "")
                     if canonical_desc.startswith("Payload:") else "")
                 or listing.get("collection_id") or "(untitled)")
    pub = "published \U0001F7E2" if int(listing.get("published") or 0) \
        else "unpublished \u26A0\uFE0F"
    lines = [
        "\U0001F4C4 WEBSITE LISTING PREVIEW",
        "",
        f"Title: {eff_title}",
        f"Description: {listing.get('description') or '(none)'}",
        f"Tags: {listing.get('tags') or '(none)'}",
        f"Thumbnail: {thumb}",
        f"Canonical reference: {canonical_desc or '?'}",
        f"Files/videos: {file_count}",
        f"State: {pub}",
        f"Ordering position: {int(listing.get('position') or 0)}",
    ]
    base = await svc.website_public_base_url()
    if listing.get("opaque_id"):
        url = svc.build_site_url(f"site/payload/{listing['opaque_id']}", base)
        lines += ["", f"Website URL: {url}"]
    return lines


async def website_view_listing(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any, dbid: int) -> None:
    db = deps.db
    listing = await db.get_website_payload_by_dbid(int(dbid))
    if listing is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Listing not found.")
        await website_list_panel(update, context, deps)
        return
    ld = dict(listing)
    lines = await _listing_view_lines(db, ld)
    rows = [
        [_btn("\U0001F512 Publish" if not ld.get("published")
              else "\U0001F513 Unpublish",
              f"wsite:{'pub' if not ld.get('published') else 'unpub'}:{dbid}")],
        [_btn("\u270F\uFE0F Title", f"wsite:etitle:{dbid}"),
         _btn("\u270F\uFE0F Description", f"wsite:edesc:{dbid}"),
         _btn("\u270F\uFE0F Tags", f"wsite:etags:{dbid}")],
        [_btn("\u2B06\uFE0F Position", f"wsite:epos:{dbid}"),
         _btn("\U0001F5BC Replace Thumbnail", f"wsite:rethumb:{dbid}")],
        [_btn("\U0001F9EA Check Readiness", f"wsite:check:{dbid}")],
        [_btn("\U0001F5D1 Delete Listing", f"wsite:del:{dbid}")],
        [_btn("\u2B05\uFE0F Back to List", "wsite:list")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def website_listing_action(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE,
                                 deps: Any, action: str, dbid: int) -> None:
    """Publish / unpublish / delete-confirm / readiness-check actions."""
    db = deps.db
    q = update.callback_query
    listing = await db.get_website_payload_by_dbid(int(dbid))
    if listing is None:
        await deps.safe_answer_callback(q, "Listing not found.")
        await website_list_panel(update, context, deps)
        return
    if action == "pub":
        await db.update_website_payload_fields(dbid, {"published": 1})
        await deps.log_admin_action(
            int(update.effective_user.id), "website_publish", "website_payload",
            dbid, None)
        await deps.safe_answer_callback(q, "Listing published.")
        await website_view_listing(update, context, deps, dbid)
        return
    if action == "unpub":
        await db.update_website_payload_fields(dbid, {"published": 0})
        await deps.log_admin_action(
            int(update.effective_user.id), "website_unpublish",
            "website_payload", dbid, None)
        await deps.safe_answer_callback(q, "Listing unpublished (canonical "
                                           "payload untouched).")
        await website_view_listing(update, context, deps, dbid)
        return
    if action == "delconfirm":
        # Presentation-layer deletion ONLY: the canonical Payload, indexed
        # media, Collection and Telegram source are NEVER touched (§18).
        await db.delete_website_payload(dbid)
        await deps.log_admin_action(
            int(update.effective_user.id), "website_delete_listing",
            "website_payload", dbid, "presentation-layer only")
        await deps.safe_answer_callback(q, "Listing deleted (the underlying "
                                           "Payload is untouched).")
        await website_list_panel(update, context, deps)
        return
    if action == "del":
        rows = [
            [_btn("\u274C YES, delete listing", f"wsite:delconfirm:{dbid}")],
            [_btn("\u2B05\uFE0F Cancel (keep listing)", f"wsite:view:{dbid}")],
        ]
        await deps.safe_edit_text(
            q,
            "\u26A0\uFE0F DELETE WEBSITE LISTING\n\n"
            "This deletes the Website LISTING only.\n"
            "The canonical Payload, indexed media, Collection and the\n"
            "Telegram source are NEVER deleted.\n\n"
            "Continue?",
            reply_markup=_kb(rows))
        return
    if action == "check":
        await _website_readiness_check(update, context, deps, dbid)
        return
    await deps.safe_answer_callback(q, "Unknown action.")
    await website_view_listing(update, context, deps, dbid)


async def _website_readiness_check(update: Update,
                                   context: ContextTypes.DEFAULT_TYPE,
                                   deps: Any, dbid: int) -> None:
    """Honest Phase 3 'readiness' diagnostics (spec §14 'Test Playback' —
    implemented as a REAL integrity check, not a fake playback test; actual
    playback arrives with the Phase 4 Media Gateway)."""
    db = deps.db
    q = update.callback_query
    listing = await db.get_website_payload_by_dbid(int(dbid))
    if listing is None:
        await deps.safe_answer_callback(q, "Listing not found.")
        return
    lines = ["\U0001F9EA LISTING READINESS CHECK", ""]
    ok = True
    if listing["collection_id"]:
        items = await db.get_collection_items(str(listing["collection_id"]))
        alive = [i for i in items
                 if (i["file_unique_id"] if "file_unique_id" in i.keys()
                     else None)]
        lines.append(f"Collection items: {len(items)} total, {len(alive)} "
                     "with live indexed files")
        if not alive:
            ok = False
            lines.append("\u274C no live files — listing renders the honest "
                         "unavailable state")
        mime_missing = sum(1 for i in alive
                           if not (i["mime_type"] if "mime_type" in i.keys()
                                   else None))
        if mime_missing:
            lines.append(f"\u2139\uFE0F {mime_missing} file(s) missing mime "
                         "metadata (re-index to backfill)")
    else:
        overview = await db.get_payload_file_overview(
            [int(listing["payload_id"])])
        if overview:
            f = overview[0]
            lines.append(f"File: alive, media_type={f['media_type']}, "
                         f"mime={'yes' if f['mime_type'] else 'no'}")
        else:
            ok = False
            lines.append("\u274C canonical file no longer indexed — "
                         "listing is hidden publicly")
    lines.append("")
    lines.append("\u2705 Listing is structurally sound." if ok
                 else "\u26A0\uFE0F Issues found above.")
    lines.append("Playback transport ships with the Phase 4 Media Gateway "
                 "(this check never fakes it).")
    rows = [[_btn("\u2B05\uFE0F Back", f"wsite:view:{dbid}")]]
    await deps.safe_edit_text(q, "\n".join(lines), reply_markup=_kb(rows))


# ============================================================
# Add Website Payload wizard (spec §15)
# ============================================================

async def _package_display_name(db: Any, code: str) -> str:
    """V26 FINAL (Part 11) — the HUMAN package title, from the EXISTING
    storage (NO new title column). Fallback chain, exactly per spec:

    1. the collection wrapper payload's canonical ``display_name``
       (``payloads.display_name`` of the ``c<code>`` routing row);
    2. the existing collection branding title;
    3. the first indexed file name;
    4. ``Package c<code>``.

    Every level is best-effort (a read failure falls to the next)."""
    code = str(code or "").strip()
    try:
        wp = await db.get_payload(f"c{code}")
        if wp is not None:
            dn = str(wp["display_name"] or "").strip()
            if dn:
                return dn
    except Exception:  # noqa: BLE001 — next fallback
        pass
    try:
        br = await db.get_collection_branding(code)
        if br is not None:
            bt = str(br["title"] or "").strip()
            if bt:
                return bt
    except Exception:  # noqa: BLE001 — next fallback
        pass
    try:
        items = await db.get_collection_items(code)
        if items:
            fn = str(items[0]["file_name"] or "").strip()
            if fn:
                return fn
    except Exception:  # noqa: BLE001 — final fallback
        pass
    return f"Package c{code}"


def _pkg_sel(context: ContextTypes.DEFAULT_TYPE) -> Dict[str, Any]:
    """V26 FINAL (Part 9) — the package multi-selection state (lives in
    ``context.user_data`` — the server-side, admin-scoped store; the
    CLIENT selection is never trusted, every ID is revalidated at
    Continue)."""
    st = context.user_data.get(WSITE_PKG_PICK_KEY)
    if not isinstance(st, dict):
        st = {"selected": [], "page": 1}
        context.user_data[WSITE_PKG_PICK_KEY] = st
    if not isinstance(st.get("selected"), list):
        st["selected"] = []
    return st


async def website_package_picker(update: Update,
                                    context: ContextTypes.DEFAULT_TYPE,
                                    deps: Any, page: int = 1) -> None:
    """V26 FINAL (Part 9) — Upload Package Payload Step 1: MULTI-SELECT.

    The admin toggles packages with ✅/⬜ checkboxes (``wsite:pktog``),
    Select All / Clear All, then Continue (``wsite:pkcont``) — the
    backend revalidates every selected ID (exists + has items,
    deduplicated, stale/deleted rejected) and saves the association
    DIFF: added codes take the EXISTING wizard (thumbnail -> preview ->
    publish; ONE selection takes the unchanged single-package wizard,
    MULTIPLE take the batch wizard), removed codes are deleted from
    website_payloads IMMEDIATELY, kept codes need nothing. Selection
    survives pagination and rerenders (server-side state).

    V26 FINAL (Part 11): every entry shows the HUMAN title
    (``_package_display_name`` fallback chain), never a bare
    ``c<collection_id>``. Callbacks stay compact
    (``wsite:pktog:<bare-code>`` ≈ 21 bytes).

    BOT-43 (spec §11 — work-stream B): the ✅ marks are AUTHORITATIVE —
    the selection is SEEDED from the website_payloads association rows
    on every OPEN (``wsite:addpkg``; the transient ``wsite_pkg_pick``
    state is purged by clear_wizard_states() on nearly every admin
    navigation, so the truth-on-open is what the admin sees), then
    maintained by the toggles. Every rerender (pagination / toggle)
    re-derives the marks from that server-side state and the
    "Selected: N" line shows the EFFECTIVE count.
    """
    db = deps.db
    page = max(1, int(page or 1))
    sel = _pkg_sel(context)
    sel["page"] = page
    selected = [str(c) for c in (sel.get("selected") or [])]
    rows, total = await db.list_collections_paged(page=page, page_size=8)
    # Part 11: the human title per listed package.
    titles: Dict[str, str] = {}
    for r in rows:
        code = str(r["collection_id"])
        titles[code] = await _package_display_name(db, code)
    lines = ["\U0001F4E6 UPLOAD PACKAGE PAYLOAD — Step 1/4: Package", ""]
    if not rows:
        lines.append("No packages (collections) yet.")
        lines.append("Forward files to the bot to build one first.")
    for r in rows:
        code = str(r["collection_id"])
        mark = "\u2611" if code in selected else "\u2610"
        lines.append(f"{mark} {titles[code]}")
        lines.append(f"    {int(r['file_count'] or 0)} file(s)")
    pages = max(1, (total + 7) // 8)
    lines += ["", f"Selected: {len(selected)}",
              f"Page {min(page, pages)}/{pages} — {total} package"
              + ("s" if total != 1 else ""),
              "", "Tap a package to toggle it, then Continue.",
              "\u2705 = listed on the Website — Continue saves the exact "
              "selection."]
    kb_rows: List[List[InlineKeyboardButton]] = []
    for r in rows:
        code = str(r["collection_id"])
        cb = f"wsite:pktog:{code}"
        if len(cb.encode()) > 64:
            continue  # Part 13: compact-callback guard (corrupt rows only)
        # BOT-43: the CLEAR green-check selected state on the BUTTONS
        # (same byte-safe label discipline — one BMP glyph + space).
        mark = "\u2705" if code in selected else "\u2b1c"
        kb_rows.append([_btn(
            f"{mark} {titles[code][:28]} ({int(r['file_count'] or 0)}f)",
            cb)])
    kb_rows.append([_btn("Select All", "wsite:pkall"),
                    _btn("Clear All", "wsite:pkclr")])
    kb_rows.append([_btn("Continue \u25B6", "wsite:pkcont")])
    nav = []
    if page > 1:
        nav.append(_btn("\u2190 Prev", f"wsite:pkpage:{page-1}"))
    if page < pages:
        nav.append(_btn("Next \u2192", f"wsite:pkpage:{page+1}"))
    if nav:
        kb_rows.append(nav)
    kb_rows += [
        [_btn("\u274C Cancel", "panel:website")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(kb_rows))


async def website_single_picker(update: Update,
                                context: ContextTypes.DEFAULT_TYPE,
                                deps: Any, page: int = 1) -> None:
    """V26 FINAL (Parts 10/12) — Upload Single Payload Step 1: PICK the
    single payload (SINGLE-SELECTION semantics preserved — tapping a
    payload starts the existing wizard immediately; no ambiguous batch).

    Part 12: every entry shows the existing ``payloads.display_name``
    (fallback: the routing slug) plus the file SIZE and file name (ONE
    batched ``get_payload_file_overview`` query). COLLECTION WRAPPER
    payloads (the ``c<code>`` routing rows) are EXCLUDED from the
    ordinary singles list by the CANONICAL ``is_collection_link``
    predicate — never a name filter, never a duplicated title store.
    """
    from app.core.payload.service import is_collection_link
    db = deps.db
    page = max(1, int(page or 1))
    per = 8
    rows = await db.list_payloads(limit=per, offset=(page - 1) * per)
    total = await db.count_payloads()
    # Part 12: collection wrappers are NOT ordinary singles.
    rows = [r for r in rows
            if not is_collection_link(str(r["payload"] or ""))]
    # The file facts (size + name) in ONE batched query.
    overview: Dict[int, Any] = {}
    try:
        _pids = [int(r["id"]) for r in rows if r["id"] is not None]
        ov = await db.get_payload_file_overview(_pids)
        for o in ov:
            overview[int(o["payload_id"])] = o
    except Exception:  # noqa: BLE001 — display-only enhancement
        overview = {}

    def _fmt_size(n: Any) -> str:
        try:
            n = float(n or 0)
        except (TypeError, ValueError):
            return ""
        if n <= 0:
            return ""
        units = ["B", "KB", "MB", "GB"]
        i = 0
        while n >= 1024 and i < 3:
            n /= 1024
            i += 1
        return (f"{n:.1f} {units[i]}" if i >= 2 else f"{int(n)} {units[i]}")

    lines = ["\U0001F4C4 UPLOAD SINGLE PAYLOAD — Step 1/4: Payload", ""]
    if not rows:
        lines.append("No single payloads yet.")
        lines.append("Forward a file to the bot to create one first.")
    for r in rows:
        _dn = str(r["display_name"] or r["payload"] or "?")
        o = overview.get(int(r["id"]))
        _size = _fmt_size(o["file_size"]) if o else ""
        _fn = str(o["file_name"] or "").strip() if o else ""
        _facts = " \u2022 ".join(x for x in (_size, _fn[:28]) if x)
        lines.append(_dn + (f"\n    {_facts}" if _facts else ""))
    pages = max(1, (total + per - 1) // per)
    lines += ["", f"Page {min(page, pages)}/{pages} — {total} payload"
              + ("s" if total != 1 else ""),
              "", "Pick the payload to publish to the Website."]
    kb_rows: List[List[InlineKeyboardButton]] = []
    for r in rows:
        pid = int(r["id"])
        _dn = str(r["display_name"] or r["payload"] or "?")
        o = overview.get(pid)
        _size = _fmt_size(o["file_size"]) if o else ""
        kb_rows.append([_btn(
            f"\U0001F4C4 {_dn[:24]}" + (f" \u2022 {_size}" if _size else ""),
            f"wsite:spick:{pid}")])
    nav = []
    if page > 1:
        nav.append(_btn("\u2190 Prev", f"wsite:spage:{page-1}"))
    if page < pages:
        nav.append(_btn("Next \u2192", f"wsite:spage:{page+1}"))
    if nav:
        kb_rows.append(nav)
    kb_rows += [
        [_btn("\u274C Cancel", "panel:website")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(kb_rows))


async def website_wizard_start(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any, *,
                               prefill_link: str = "",
                               prefill_kind: str = "") -> None:
    """Step 1 — Send Thumbnail (or skip).

    V26: ``prefill_link`` carries a PICKER selection (the Upload Package /
    Upload Single entry points) — the wizard's link step is then resolved
    automatically instead of asking the admin to paste a code. The paste
    path (Add Website Payload) passes no prefill and behaves exactly as
    before."""
    _wizard_clear(context)
    context.user_data[WSITE_WIZARD_KEY] = {
        "step": "thumb",
        "thumb_file_id": None,
        "thumb_file_unique_id": None,
        "canonical": None,
        "title": None, "description": None, "tags": None,
        "prefill_link": prefill_link or "",
        "prefill_kind": prefill_kind or "",
    }
    rows = [
        [_btn("\u23ED\uFE0F Skip (automatic fallback)", "wsite:wskip")],
        [_btn("\u274C Cancel", "wsite:wcancel")],
    ]
    # V26: the picker flows (Upload Package / Upload Single) show the
    # selection and resolve it automatically after this step.
    if prefill_link:
        _what = ("package c" + str(prefill_link)
                 if prefill_kind == "collection" else str(prefill_link))
        await deps.safe_edit_text(
            update.callback_query,
            "\u2795 UPLOAD WEBSITE PAYLOAD — Step 2/4: Thumbnail\n\n"
            f"Selected: {_what}\n\n"
            "Send a photo to use as the Website card thumbnail,\n"
            "or skip to use the automatic fallback chain\n"
            "(configured \u2192 payload image \u2192 indexed image \u2192 "
            "placeholder).\n\n"
            "Next: the selection is resolved automatically (no link to "
            "paste).",
            reply_markup=_kb(rows))
        return
    await deps.safe_edit_text(
        update.callback_query,
        "\u2795 ADD WEBSITE PAYLOAD — Step 1/3: Thumbnail\n\n"
        "Send a photo to use as the Website card thumbnail,\n"
        "or skip to use the automatic fallback chain\n"
        "(configured \u2192 payload image \u2192 indexed image \u2192 "
        "placeholder).\n\n"
        "Next: you'll paste an existing Payload link.",
        reply_markup=_kb(rows))


async def website_wizard_start_batch(update: Update,
                                     context: ContextTypes.DEFAULT_TYPE,
                                     deps: Any, *,
                                     codes: List[str]) -> None:
    """V26 FINAL (Part 9) — the BATCH wizard entry (multiple selected
    packages). The SAME wizard steps run (thumbnail -> preview ->
    publish) with the batch resolved server-side: every code is
    revalidated through the EXISTING canonical resolver, the preview
    shows EVERY item (with per-item already-published notes), and
    publish creates one listing per item through the EXISTING
    ``create_website_payload`` engine (per-item duplicate guard, honest
    per-item results). The optional shared Title/Description/Tags apply
    to ALL items; per-item titles default to each package's own
    display_name."""
    _wizard_clear(context)
    codes = [str(c).strip() for c in (codes or []) if str(c).strip()]
    context.user_data[WSITE_WIZARD_KEY] = {
        "step": "thumb",
        "thumb_file_id": None,
        "thumb_file_unique_id": None,
        "canonical": None,
        "title": None, "description": None, "tags": None,
        "batch": True,
        "batch_codes": codes,
    }
    names = []
    for c in codes[:10]:
        names.append("\u2022 " + (await _package_display_name(deps.db, c)))
    more = len(codes) - 10
    lines = ["\u2795 UPLOAD WEBSITE PAYLOADS — Step 2/4: Thumbnail", "",
             f"Selected {len(codes)} packages:", ""]
    lines += names
    if more > 0:
        lines.append(f"\u2026 +{more} more")
    lines += ["",
              "Send ONE photo to use as the SHARED thumbnail,",
              "or skip to use the automatic fallback chain",
              "(configured \u2192 payload image \u2192 indexed image \u2192 "
              "placeholder).",
              "",
              "Next: a preview of every selected package."]
    rows = [
        [_btn("\u23ED\uFE0F Skip (automatic fallback)", "wsite:wskip")],
        [_btn("\u274C Cancel", "wsite:wcancel")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def website_wizard_skip_thumb(update: Update,
                                    context: ContextTypes.DEFAULT_TYPE,
                                    deps: Any) -> None:
    st = _wizard_get(context)
    if not st:
        await website_wizard_start(update, context, deps)
        return
    # V26 FINAL (Part 9): the BATCH selection resolves every code —
    # no paste step.
    if st.get("batch"):
        await _wizard_resolve_batch(update, context, deps, st)
        return
    # V26: a PICKER selection (Upload Package / Upload Single) resolves
    # the canonical directly — no paste step.
    if st.get("prefill_link"):
        await _wizard_resolve_link(update, context, deps, st,
                                   str(st["prefill_link"]))
        return
    st["step"] = "link"
    await _wizard_ask_link(update, context, deps)


async def _wizard_resolve_batch(update: Update,
                                context: ContextTypes.DEFAULT_TYPE,
                                deps: Any,
                                st: Dict[str, Any]) -> None:
    """Resolve + revalidate EVERY selected package code through the
    EXISTING canonical resolver (never a client-trusted set): existence,
    item count, duplicate listings per item. Stale/deleted codes are
    rejected honestly; the wizard continues with the valid remainder."""
    db = deps.db
    svc = make_website_service(db)
    items: List[Dict[str, Any]] = []
    rejected: List[str] = []
    for code in st.get("batch_codes") or []:
        canon = await svc.resolve_canonical_for_wizard(
            f"c{code}", resolve_payload_link=deps.resolve_payload_link)
        if not canon or canon.get("kind") != "collection":
            rejected.append(code)
            continue
        existing = await db.find_website_payload_for_canonical(
            collection_id=canon["collection_id"])
        items.append({"canonical": canon, "existing": existing})
        # BOT-40 (Section J): the batch resolve telemetry — the FIRST point
        # where the human title is derived per selected package.
        logger.info(
            "WEBSITE_PACKAGE_RESOLVE admin_user_id=%s canonical_kind="
            "collection canonical_id=%s source_display_name=%s via=batch",
            update.effective_user.id if update.effective_user else 0,
            canon.get("collection_id"),
            (await _package_display_name(
                db, str(canon.get("collection_id") or "")))[:80])
    if not items:
        _wizard_clear(context)
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u274C None of the selected packages could be resolved "
            "(deleted or empty).\nNothing was saved.",
            reply_markup=_kb([[_btn("\U0001F4E6 Package picker",
                                    "wsite:addpkg")]]))
        return
    st["batch_canonicals"] = items
    st["step"] = "preview"
    if rejected:
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u26A0\uFE0F Skipped stale/empty packages: "
            + ", ".join("c" + str(c) for c in rejected[:8])
            + ("\u2026" if len(rejected) > 8 else ""))
    await _wizard_show_preview(update, context, deps)


async def _wizard_ask_link(update: Update, context: ContextTypes.DEFAULT_TYPE,
                           deps: Any) -> None:
    rows = [[_btn("\u274C Cancel", "wsite:wcancel")]]
    await deps.safe_send_text(
        context.bot, update.effective_chat.id,
        "\u2795 ADD WEBSITE PAYLOAD — Step 2/3: Payload link\n\n"
        "Send an EXISTING Payload link or code:\n"
        "  \u2022 https://t.me/<bot>?start=<payload>\n"
        "  \u2022 a payload code (e.g. movie_2eff1)\n"
        "  \u2022 a collection link (c7f3a9b2)\n\n"
        "The listing will REFERENCE the canonical Payload — media is\n"
        "never copied, and the Payload itself is never modified.\n"
        "(Copy codes from Payload Manager if needed.)",
        reply_markup=_kb(rows))


async def website_wizard_media(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any, info: Dict[str, Any]) -> bool:
    """on_media_input hook: thumbnail step capture. Returns True when the
    media was consumed by the wizard."""
    st = _wizard_get(context)
    if not st or st.get("step") != "thumb":
        # The thumbnail-replacement editor for an EXISTING listing.
        ed = _edit_state(context)
        if ed and ed.get("field") == "rethumb":
            _edit_clear(context)
            dbid = int(ed.get("dbid") or 0)
            await deps.db.update_website_payload_fields(dbid, {
                "thumb_file_id": info.get("file_id"),
                "thumb_file_unique_id": info.get("file_unique_id"),
            })
            await deps.log_admin_action(
                int(update.effective_user.id), "website_replace_thumbnail",
                "website_payload", dbid,
                f"media_type={info.get('media_type')}")
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u2705 Thumbnail replaced.",
                reply_markup=_kb([[_btn("\u2B05\uFE0F Back to listing",
                                        f"wsite:view:{dbid}")]]))
            return True
        return False
    if str(info.get("media_type") or "") != "photo":
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u274C Only a PHOTO is accepted as the Website thumbnail.\n"
            "Send a photo, or tap Skip to use the automatic fallback.")
        return True
    st["thumb_file_id"] = info.get("file_id")
    st["thumb_file_unique_id"] = info.get("file_unique_id")
    st["step"] = "link"
    # V26 FINAL (Part 9): the BATCH selection resolves after the shared
    # thumbnail (same flow as the single prefill).
    if st.get("batch"):
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\U0001F5BC Thumbnail received — resolving your selection\u2026")
        await _wizard_resolve_batch(update, context, deps, st)
        return True
    # V26: a PICKER selection resolves directly after the thumbnail.
    if st.get("prefill_link"):
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\U0001F5BC Thumbnail received — resolving your selection\u2026")
        await _wizard_resolve_link(update, context, deps, st,
                                   str(st["prefill_link"]))
        return True
    await deps.safe_send_text(
        context.bot, update.effective_chat.id,
        "\U0001F5BC Thumbnail received.\n\n"
        "\u2795 ADD WEBSITE PAYLOAD — Step 2/3: Payload link\n\n"
        "Send an EXISTING Payload link or code:\n"
        "  \u2022 https://t.me/<bot>?start=<payload>\n"
        "  \u2022 a payload code (e.g. movie_2eff1)\n"
        "  \u2022 a collection link (c7f3a9b2)",
        reply_markup=_kb([[_btn("\u274C Cancel", "wsite:wcancel")]]))
    return True


async def website_wizard_text(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any, text: str) -> bool:
    """text_handler hook: link step + field editors. Returns True when the
    text was consumed by the wizard/editors."""
    st = _wizard_get(context)
    if st and st.get("step") == "link":
        if text.lower() in ("/cancel", "cancel"):
            _wizard_clear(context)
            await deps.reply_protected(
                update, "\u274C Cancelled. No listing was created.")
            return True
        if text.lower() in ("/skip", "skip"):
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C The Payload link is required — a listing must "
                "reference a canonical Payload.")
            return True
        await _wizard_resolve_link(update, context, deps, st, text)
        return True
    if st and st.get("step") in ("edittitle", "editdesc", "edittags"):
        if text.lower() in ("/cancel", "cancel"):
            st["step"] = "preview"
            await _wizard_show_preview(update, context, deps)
            return True
        field = {"edittitle": "title", "editdesc": "description",
                 "edittags": "tags"}[st["step"]]
        st[field] = text.strip() or None
        st["step"] = "preview"
        await _wizard_show_preview(update, context, deps)
        return True
    # Per-listing editors on EXISTING listings.
    ed = _edit_state(context)
    if ed and ed.get("field"):
        return await _edit_listing_text(update, context, deps, ed, text)
    return False


async def _wizard_resolve_link(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any, st: Dict[str, Any],
                               text: str) -> None:
    """Resolve the admin's payload link through the EXISTING Payload
    system (spec §16). Invalid link → friendly error, NO partial DB
    record, wizard stays at the link step."""
    db = deps.db
    svc = make_website_service(db)
    canonical = await svc.resolve_canonical_for_wizard(
        text, resolve_payload_link=deps.resolve_payload_link)
    if canonical is None:
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u274C That doesn't resolve to an existing Payload or "
            "Collection.\n\n"
            "Check the link and send it again (a payload code, a full\n"
            "t.me start link, or a c-code collection link), or send\n"
            "cancel. Nothing was saved.",
            reply_markup=_kb([[_btn("\u274C Cancel", "wsite:wcancel")]]))
        return
    # Guard: an existing listing for the SAME canonical reference?
    existing = await db.find_website_payload_for_canonical(
        payload_id=(canonical["payload_id"]
                    if canonical["kind"] == "payload" else None),
        collection_id=(canonical["collection_id"]
                       if canonical["kind"] == "collection" else None))
    if existing is not None:
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u26A0\uFE0F That Payload already has a Website listing.\n\n"
            f"Existing listing: #{existing['id']} "
            f"({existing['opaque_id']})\n"
            "Manage it from Website Control \u2192 Manage Website Payloads,\n"
            "or send a different link.",
            reply_markup=_kb([[_btn("\U0001F4CB Open existing listing",
                                    f"wsite:view:{int(existing['id'])}")],
                              [_btn("\u274C Cancel", "wsite:wcancel")]]))
        return
    st["canonical"] = canonical
    if not st.get("title"):
        # BOT-40 (Section G/H) — THE PACKAGE TITLE ROOT CAUSE: the
        # collection canonical carries NO display_name, so the old
        # fallback chain landed on the RAW collection code (e.g.
        # "4f9965c6") as the listing title — while the PICKER had shown
        # the human name. A package listing now defaults to the package's
        # OWN display name through the SAME _package_display_name chain
        # the picker displayed (wrapper payload display_name → collection
        # branding → first file name → "Package c<code>"); a SINGLE
        # payload keeps its canonical display_name (unchanged semantics).
        # The admin's explicit ✏️ Title edit still overrides everything.
        if canonical.get("kind") == "collection":
            st["title"] = await _package_display_name(
                db, str(canonical.get("collection_id") or ""))
        else:
            st["title"] = (canonical.get("display_name")
                           or canonical.get("payload")
                           or canonical.get("collection_id"))
    st["step"] = "preview"
    # BOT-40 (Section I/J): the SINGLE resolve telemetry (the paste path
    # resolves through the same chokepoint — via= distinguishes them).
    _via = "prefill" if st.get("prefill_link") else "paste"
    if canonical.get("kind") == "collection":
        logger.info(
            "WEBSITE_PACKAGE_RESOLVE admin_user_id=%s canonical_kind="
            "collection canonical_id=%s source_display_name=%s via=%s",
            update.effective_user.id if update.effective_user else 0,
            canonical.get("collection_id"),
            str(st.get("title") or "-")[:80], _via)
    else:
        logger.info(
            "WEBSITE_SINGLE_RESOLVE admin_user_id=%s canonical_kind=payload "
            "canonical_id=%s source_display_name=%s via=%s",
            update.effective_user.id if update.effective_user else 0,
            canonical.get("payload_id"),
            str(st.get("title") or "-")[:80], _via)
    await _wizard_show_preview(update, context, deps)


async def _wizard_show_preview(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any) -> None:
    st = _wizard_get(context)
    if not st:
        await website_wizard_start(update, context, deps)
        return
    # V26 FINAL (Part 9): the BATCH preview — every selected package,
    # its own default title (or the shared title when set), per-item
    # already-published notes, one shared thumbnail/description/tags.
    if st.get("batch"):
        items = st.get("batch_canonicals") or []
        if not items:
            await website_wizard_start(update, context, deps)
            return
        # BOT-40 (Section J): the batch preview telemetry.
        logger.info(
            "WEBSITE_PACKAGE_PREVIEW admin_user_id=%s canonical_kind="
            "collection items=%s shared_title=%s",
            update.effective_user.id if update.effective_user else 0,
            len(items),
            (str(st.get("title") or "-")[:80]))
        lines = [f"\U0001F4E6 BATCH PUBLISH — {len(items)} package"
                 + ("s" if len(items) != 1 else ""), ""]
        for i, it in enumerate(items, 1):
            canon = it["canonical"]
            _title = (str(st.get("title") or "").strip()
                      or await _package_display_name(
                          deps.db, str(canon.get("collection_id"))))
            lines.append(f"{i}. {_title}")
            lines.append(f"    {int(canon.get('file_count') or 0)} file(s)")
            if it.get("existing"):
                lines.append(
                    f"    \u26A0\uFE0F already listed (#{it['existing']['id']})"
                    " — will be SKIPPED")
        lines += ["", "(wizard preview — not saved yet)"]
        if st.get("description"):
            lines.append(f"Shared description: {st['description']}")
        if st.get("tags"):
            lines.append(f"Shared tags: {st['tags']}")
        lines += ["",
                  "Title/Description/Tags (optional) apply to ALL packages."]
        rows = [
            [_btn("\u2705 Confirm Publish", "wsite:wpub")],
            [_btn("\u270F\uFE0F Title", "wsite:wtitle"),
             _btn("\u270F\uFE0F Description", "wsite:wdesc"),
             _btn("\u270F\uFE0F Tags", "wsite:wtags")],
            [_btn("\u274C Cancel", "wsite:wcancel")],
        ]
        await deps.safe_send_text(context.bot, update.effective_chat.id,
                                  "\n".join(lines), reply_markup=_kb(rows))
        return
    if not st.get("canonical"):
        await website_wizard_start(update, context, deps)
        return
    canonical = st["canonical"]
    # BOT-40 (Section I/J): the preview telemetry — the flow KIND follows
    # the canonical (a single-PACKAGE pick is a PACKAGE flow with ONE
    # item; a payload pick is the SINGLE flow).
    _is_pkg = canonical.get("kind") == "collection"
    if _is_pkg:
        logger.info(
            "WEBSITE_PACKAGE_PREVIEW admin_user_id=%s canonical_kind="
            "collection items=1 shared_title=%s",
            update.effective_user.id if update.effective_user else 0,
            (str(st.get("title") or "-")[:80]))
    else:
        logger.info(
            "WEBSITE_SINGLE_PREVIEW admin_user_id=%s canonical_kind=%s "
            "canonical_id=%s source_display_name=%s",
            update.effective_user.id if update.effective_user else 0,
            canonical.get("kind"),
            canonical.get("payload_id") or canonical.get("collection_id"),
            str(st.get("title") or "-")[:80])
    listing_preview: Dict[str, Any] = {
        "title": st.get("title"),
        "description": st.get("description"),
        "tags": st.get("tags"),
        "thumb_file_id": st.get("thumb_file_id"),
        "thumb_file_unique_id": st.get("thumb_file_unique_id"),
        "published": 0,
        "position": 0,
        "payload_id": (canonical["payload_id"]
                       if canonical["kind"] == "payload" else None),
        "collection_id": (canonical["collection_id"]
                          if canonical["kind"] == "collection" else None),
        "opaque_id": None,
    }
    lines = await _listing_view_lines(deps.db, listing_preview)
    lines.insert(1, "(wizard preview — not saved yet)")
    rows = [
        [_btn("\u2705 Confirm Publish", "wsite:wpub")],
        [_btn("\u270F\uFE0F Title", "wsite:wtitle"),
         _btn("\u270F\uFE0F Description", "wsite:wdesc"),
         _btn("\u270F\uFE0F Tags", "wsite:wtags")],
        [_btn("\u274C Cancel", "wsite:wcancel")],
    ]
    await deps.safe_send_text(context.bot, update.effective_chat.id,
                              "\n".join(lines), reply_markup=_kb(rows))


async def website_wizard_publish(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE,
                                 deps: Any) -> None:
    """Confirm Publish → the Website listing is created (published).

    V26 FINAL (Part 9): in BATCH mode one listing is created per selected
    package through the EXISTING ``create_website_payload`` engine —
    per-item duplicate guard (already-listed items are SKIPPED honestly,
    never duplicated), per-item admin-action log, per-item URL lines."""
    st = _wizard_get(context)
    if not st:
        await deps.safe_answer_callback(update.callback_query,
                                        "Wizard state lost — restart.")
        await website_wizard_start(update, context, deps)
        return
    # ---- BATCH MODE (Part 9) -------------------------------------------
    if st.get("batch"):
        items = st.get("batch_canonicals") or []
        if not items:
            await deps.safe_answer_callback(update.callback_query,
                                            "Wizard state lost — restart.")
            await website_wizard_start(update, context, deps)
            return
        db = deps.db
        created_rows, skipped, failed = [], [], []
        # BOT-40 (Section J): the batch publish lifecycle — START → per
        # ITEM → COMPLETE (every field safe: ids + titles only).
        logger.info(
            "WEBSITE_PACKAGE_PUBLISH_START admin_user_id=%s "
            "canonical_kind=collection items=%s shared_title=%s",
            update.effective_user.id if update.effective_user else 0,
            len(items), (str(st.get("title") or "-")[:80]))
        for it in items:
            canon = it["canonical"]
            if it.get("existing"):
                skipped.append(int(it["existing"]["id"]))
                # BOT-40 (Section J): per-item SKIPPED telemetry (the
                # duplicate guard fired — the existing listing wins).
                logger.info(
                    "WEBSITE_PACKAGE_PUBLISH_ITEM admin_user_id=%s "
                    "canonical_kind=collection canonical_id=%s "
                    "source_display_name=%s listing_id=%s "
                    "listing_opaque_id=%s final_title=%s result=skipped",
                    update.effective_user.id if update.effective_user else 0,
                    canon.get("collection_id"),
                    (await _package_display_name(
                        db, str(canon.get("collection_id") or "")))[:80],
                    int(it["existing"]["id"]),
                    it["existing"]["opaque_id"],
                    str(it["existing"]["title"] or "-")[:80])
                continue
            _title = (str(st.get("title") or "").strip()
                      or await _package_display_name(
                          db, str(canon.get("collection_id"))))
            try:
                created = await db.create_website_payload(
                    collection_id=canon["collection_id"],
                    title=_title,
                    description=st.get("description"),
                    tags=st.get("tags"),
                    thumb_file_id=st.get("thumb_file_id"),
                    thumb_file_unique_id=st.get("thumb_file_unique_id"),
                    published=1,
                    created_by=int(update.effective_user.id),
                )
            except Exception:  # noqa: BLE001 — honest per-item failure
                logger.warning("batch create failed collection=%s",
                               canon.get("collection_id"), exc_info=True)
                created = None
            if not created:
                failed.append(str(canon.get("collection_id")))
                # BOT-40 (Section J): per-item FAILED telemetry (honest
                # failure, never a partial DB record).
                logger.info(
                    "WEBSITE_PACKAGE_PUBLISH_ITEM admin_user_id=%s "
                    "canonical_kind=collection canonical_id=%s "
                    "source_display_name=%s listing_id=- listing_opaque_id=- "
                    "final_title=- result=failed",
                    update.effective_user.id if update.effective_user else 0,
                    canon.get("collection_id"),
                    (await _package_display_name(
                        db, str(canon.get("collection_id") or "")))[:80])
                continue
            created_rows.append(created)
            # BOT-40 (Section J): per-item publish telemetry — the EXACT
            # DB values that hit website_payloads (kind, canonical id,
            # source display name, listing id/opaque, final title).
            logger.info(
                "WEBSITE_PACKAGE_PUBLISH_ITEM admin_user_id=%s "
                "canonical_kind=collection canonical_id=%s "
                "source_display_name=%s listing_id=%s listing_opaque_id=%s "
                "final_title=%s result=created",
                update.effective_user.id if update.effective_user else 0,
                canon.get("collection_id"),
                (await _package_display_name(
                    db, str(canon.get("collection_id") or "")))[:80],
                int(created["id"]), created["opaque_id"],
                str(created["title"] or "-")[:80])
            await deps.log_admin_action(
                int(update.effective_user.id), "website_publish_listing",
                "website_payload", int(created["id"]),
                f"opaque_id={created['opaque_id']} canonical=collection:"
                f"{canon.get('collection_id')} batch=1")
        # BOT-40 (Section J): the batch completion telemetry.
        logger.info(
            "WEBSITE_PACKAGE_PUBLISH_COMPLETE admin_user_id=%s "
            "canonical_kind=collection created=%s skipped=%s failed=%s",
            update.effective_user.id if update.effective_user else 0,
            len(created_rows), len(skipped), len(failed))
        _wizard_clear(context)
        _pkg_sel(context)["selected"] = []
        svc = make_website_service(db)
        base = await svc.website_public_base_url()
        lines = [f"\u2705 Batch publish finished — {len(created_rows)} "
                 f"published, {len(skipped)} skipped, {len(failed)} failed.",
                 ""]
        for c in created_rows:
            url = svc.build_site_url(f"site/payload/{c['opaque_id']}", base)
            lines.append(f"\u2022 #{c['id']} {url}")
        if skipped:
            lines += ["", f"Skipped (already listed): "
                      + ", ".join(f"#{sid}" for sid in skipped[:10])]
        if failed:
            lines += ["", f"Failed: " + ", ".join("c" + f for f in failed[:10])]
        enabled = await svc.website_enabled()
        if not enabled:
            lines += ["", "\u2139\uFE0F The Website is currently OFF — enable "
                      "it from Website Control when ready."]
        pub_rows: List[List[InlineKeyboardButton]] = []
        if created_rows and base:
            pub_rows.append([InlineKeyboardButton(
                "\U0001F517 Open Website",
                url=svc.build_site_url("site", base))])
        pub_rows += [
            [_btn("\U0001F310 Website Control", "panel:website")],
            [_btn("\U0001F4CB Manage listings", "wsite:list")],
        ]
        await deps.safe_send_text(
            context.bot, update.effective_chat.id, "\n".join(lines),
            reply_markup=_kb(pub_rows))
        return
    if not st.get("canonical"):
        await deps.safe_answer_callback(update.callback_query,
                                        "Wizard state lost — restart.")
        await website_wizard_start(update, context, deps)
        return
    db = deps.db
    canonical = st["canonical"]
    # BOT-40 (Section I/J): the publish lifecycle telemetry — the flow
    # KIND follows the canonical: a single-PACKAGE pick emits the FULL
    # PACKAGE lifecycle (START → ITEM → COMPLETE with one item); a
    # payload pick emits the SINGLE lifecycle. Every field safe (ids +
    # titles only).
    _pkg_one = canonical.get("kind") == "collection"
    _admin_id = update.effective_user.id if update.effective_user else 0
    _canon_id = (canonical.get("collection_id")
                 if _pkg_one else canonical.get("payload_id"))
    _src_dn = str(st.get("title") or "-")[:80]
    if _pkg_one:
        logger.info(
            "WEBSITE_PACKAGE_PUBLISH_START admin_user_id=%s "
            "canonical_kind=collection items=1 shared_title=%s",
            _admin_id, _src_dn)
    else:
        logger.info(
            "WEBSITE_SINGLE_PUBLISH_START admin_user_id=%s "
            "canonical_kind=payload canonical_id=%s "
            "source_display_name=%s", _admin_id, _canon_id, _src_dn)
    created = await db.create_website_payload(
        payload_id=(canonical["payload_id"]
                    if canonical["kind"] == "payload" else None),
        collection_id=(canonical["collection_id"]
                       if canonical["kind"] == "collection" else None),
        title=st.get("title"),
        description=st.get("description"),
        tags=st.get("tags"),
        thumb_file_id=st.get("thumb_file_id"),
        thumb_file_unique_id=st.get("thumb_file_unique_id"),
        published=1,
        created_by=int(update.effective_user.id),
    )
    if not created:
        if _pkg_one:
            logger.info(
                "WEBSITE_PACKAGE_PUBLISH_ITEM admin_user_id=%s "
                "canonical_kind=collection canonical_id=%s "
                "source_display_name=%s listing_id=- listing_opaque_id=- "
                "final_title=- result=failed", _admin_id, _canon_id,
                _src_dn)
            logger.info(
                "WEBSITE_PACKAGE_PUBLISH_COMPLETE admin_user_id=%s "
                "canonical_kind=collection created=0 skipped=0 failed=1",
                _admin_id)
        else:
            logger.info(
                "WEBSITE_SINGLE_PUBLISH_COMPLETE admin_user_id=%s "
                "canonical_kind=payload canonical_id=%s listing_id=- "
                "listing_opaque_id=- final_title=- result=failed",
                _admin_id, _canon_id)
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u274C Could not create the listing (invalid canonical "
            "reference). Nothing was saved.")
        return
    if _pkg_one:
        logger.info(
            "WEBSITE_PACKAGE_PUBLISH_ITEM admin_user_id=%s "
            "canonical_kind=collection canonical_id=%s "
            "source_display_name=%s listing_id=%s listing_opaque_id=%s "
            "final_title=%s result=created", _admin_id, _canon_id,
            _src_dn, int(created["id"]), created["opaque_id"],
            str(created["title"] or "-")[:80])
        logger.info(
            "WEBSITE_PACKAGE_PUBLISH_COMPLETE admin_user_id=%s "
            "canonical_kind=collection created=1 skipped=0 failed=0",
            _admin_id)
    else:
        logger.info(
            "WEBSITE_SINGLE_PUBLISH_COMPLETE admin_user_id=%s "
            "canonical_kind=payload canonical_id=%s "
            "source_display_name=%s listing_id=%s listing_opaque_id=%s "
            "final_title=%s result=created", _admin_id, _canon_id,
            _src_dn, int(created["id"]), created["opaque_id"],
            str(created["title"] or "-")[:80])
    _wizard_clear(context)
    await deps.log_admin_action(
        int(update.effective_user.id), "website_publish_listing",
        "website_payload", int(created["id"]),
        f"opaque_id={created['opaque_id']} canonical="
        f"{canonical['kind']}:"
        f"{canonical.get('payload_id') or canonical.get('collection_id')}")
    svc = make_website_service(db)
    base = await svc.website_public_base_url()
    url = svc.build_site_url(f"site/payload/{created['opaque_id']}", base)
    enabled = await svc.website_enabled()
    note = ("" if enabled else
            "\n\n\u2139\uFE0F The Website is currently OFF — enable it from "
            "Website Control when ready.")
    # V26: the success message carries a TAPPABLE "Open Website" URL
    # button (the URL line alone was plain text — the admin had to copy
    # it manually to verify the publication).
    pub_rows: List[List[InlineKeyboardButton]] = []
    if url:
        pub_rows.append([InlineKeyboardButton("\U0001F517 Open Website", url=url)])
    pub_rows += [
        [_btn("\U0001F310 Website Control", "panel:website")],
        [_btn("\U0001F4CB Manage listings", "wsite:list")],
    ]
    await deps.safe_send_text(
        context.bot, update.effective_chat.id,
        "\u2705 Website listing published.\n\n"
        f"URL: {url}\n"
        f"Listing ID: {created['id']}\n"
        "The canonical Payload was not modified." + note,
        reply_markup=_kb(pub_rows))


async def website_wizard_cancel(update: Update,
                                context: ContextTypes.DEFAULT_TYPE,
                                deps: Any) -> None:
    _wizard_clear(context)
    await deps.safe_answer_callback(update.callback_query, "Wizard "
                                    "cancelled — nothing was saved.")
    await website_panel(update, context, deps)


# ============================================================
# Per-listing editors (existing listings)
# ============================================================

async def _edit_listing_text(update: Update,
                             context: ContextTypes.DEFAULT_TYPE,
                             deps: Any, ed: Dict[str, Any],
                             text: str) -> bool:
    dbid = int(ed.get("dbid") or 0)
    field = str(ed.get("field") or "")
    if text.lower() in ("/cancel", "cancel"):
        _edit_clear(context)
        await deps.reply_protected(update, "\u274C Cancelled — not changed.")
        return True
    value = text.strip()
    if field == "position":
        try:
            value = max(0, min(100000, int(value)))
        except ValueError:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Position must be a whole number (0+). Send again, "
                "or cancel.")
            return True
        ok = await deps.db.update_website_payload_fields(dbid, {
            "position": value})
    elif field == "baseurl":
        svc = make_website_service(deps.db)
        if value and value != "-" and not value.lower().startswith(
                "https://"):
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C The public base URL must be a valid HTTPS URL\n"
                "(e.g. https://site.example.com). Send again, or cancel.")
            return True
        await svc.set_website_public_base_url(
            "" if value == "-" else value.rstrip("/"))
        ok = True
    elif field == "mainappurl":
        # BOT-11 (spec §2-§5): the Main Mini App Change URL flow —
        # validate_main_app_url gates EVERY stored value (HTTPS only,
        # absolute, host present, no whitespace/control chars). An
        # invalid URL is NEVER stored: the precise reason is surfaced
        # and the edit state KEPT so the admin can retry or cancel.
        if value.lower() in ("/cancel", "cancel"):
            _edit_clear(context)
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Cancelled. The Main Mini App URL was not changed.")
            return True
        if value.strip() == "-":
            _edit_clear(context)
            await deps.db.set_setting(WEBSITE_PUBLIC_BASE_URL_KEY, "")
            await deps.log_admin_action(
                int(update.effective_user.id),
                "website_set_main_app_url", "setting", None, "cleared")
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u2705 Cleared — the Main Mini App URL is no longer "
                "configured (no link is applied until a base URL is "
                "set again).",
                reply_markup=_kb([[_btn("\U0001F310 Main Mini App",
                                        "wsmain:main")]]))
            return True
        ok_url, reason = validate_main_app_url(value)
        if not ok_url:
            reason_txt = {
                "empty": "the URL is empty",
                "whitespace": "the URL contains whitespace",
                "control_characters":
                    "the URL contains control characters",
                "scheme_not_https":
                    "the scheme is not HTTPS (only https:// URLs are "
                    "valid Mini App URLs)",
                "no_host": "the URL has no host",
                "malformed": "the URL is malformed",
            }.get(reason, f"invalid URL ({reason})")
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                f"\u274C Not stored — {reason_txt}.\n\n"
                "Send a valid HTTPS URL (e.g. "
                "https://site.example.com), or cancel.")
            return True
        _edit_clear(context)
        await deps.db.set_setting(WEBSITE_PUBLIC_BASE_URL_KEY,
                                  value.rstrip("/"))
        await deps.log_admin_action(
            int(update.effective_user.id), "website_set_main_app_url",
            "setting", None, "configured")
        canon = await canonical_main_app_url(deps.db)
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u2705 Saved. The Main Mini App URL is now:\n"
            + (canon or "(not configured — HTTPS validation failed)"),
            reply_markup=_kb([[_btn("\U0001F310 Main Mini App",
                                    "wsmain:main")]]))
        return True
    elif field == "streamttl":
        try:
            minutes = max(1, min(60, int(value)))
        except ValueError:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Token TTL must be whole minutes (1-60). Send again, "
                "or cancel.")
            return True
        await deps.db.set_setting("website_stream_token_ttl",
                                  str(minutes * 60))
        ok = True
    elif field == "cachesize":
        try:
            mib = max(64, min(4096, int(value)))
        except ValueError:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Cache size must be whole MiB (64-4096). Send again, "
                "or cancel.")
            return True
        await deps.db.set_setting("website_cache_max_bytes",
                                  str(mib * 1024 * 1024))
        ok = True
    elif field == "cachettl":
        try:
            minutes = max(1, min(1440, int(value)))
        except ValueError:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Cache TTL must be whole minutes (1-1440). Send "
                "again, or cancel.")
            return True
        await deps.db.set_setting("website_cache_ttl_seconds",
                                  str(minutes * 60))
        ok = True
    else:
        ok = await deps.db.update_website_payload_fields(
            dbid, {field: value or None})
    _edit_clear(context)
    if field == "baseurl":
        await deps.log_admin_action(
            int(update.effective_user.id), "website_set_base_url", "setting",
            None, "configured")
        await website_settings_panel(update, context, deps)
        return True
    if field in ("streamttl", "cachesize", "cachettl"):
        await deps.log_admin_action(
            int(update.effective_user.id), "website_stream_setting",
            "setting", None, f"field={field}")
        await website_stream_panel(update, context, deps)
        return True
    await deps.log_admin_action(
        int(update.effective_user.id), "website_edit_field",
        "website_payload", dbid, f"field={field}")
    await deps.safe_send_text(
        context.bot, update.effective_chat.id,
        "\u2705 Saved." if ok else "\u26A0\uFE0F Nothing changed.",
        reply_markup=_kb([[_btn("\u2B05\uFE0F Back to listing",
                                f"wsite:view:{dbid}")]]))
    return True


async def website_edit_prompt(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any, field: str, dbid: int) -> None:
    """Start a per-listing text editor (title/description/tags/position) or
    the thumbnail-replacement / base-URL editor."""
    prompts = {
        "title": "Send the new listing TITLE (or cancel):",
        "description": "Send the new listing DESCRIPTION (or cancel):",
        "tags": "Send the new TAGS, comma or space separated (or cancel):",
        "position": "Send the new ordering POSITION, whole number 0+ "
                    "(lower shows first; or cancel):",
    }
    if field == "rethumb":
        context.user_data[WSITE_EDIT_KEY] = {"field": "rethumb", "dbid": dbid}
        await deps.safe_edit_text(
            update.callback_query,
            "\U0001F5BC REPLACE THUMBNAIL\n\n"
            "Send the new photo now (or cancel). The old thumbnail\n"
            "reference is replaced; the Payload itself is untouched.",
            reply_markup=_kb([[_btn("\u274C Cancel",
                                    f"wsite:view:{dbid}")]]))
        return
    if field == "baseurl":
        context.user_data[WSITE_EDIT_KEY] = {"field": "baseurl", "dbid": 0}
        await deps.safe_edit_text(
            update.callback_query,
            "\U0001F517 SET PUBLIC BASE URL\n\n"
            "Send the HTTPS base URL of the public website\n"
            "(e.g. https://site.example.com), or send a single dash '-' to\n"
            "clear it (links then render relative), or cancel.",
            reply_markup=_kb([[_btn("\u274C Cancel", "wsite:settings")]]))
        return
    # WEBSITE PHASE 4: the streaming/cache numeric editors.
    if field in ("streamttl", "cachesize", "cachettl"):
        prompts = {
            "streamttl": (
                "\u23F1 STREAM TOKEN LIFETIME\n\n"
                "Send the lifetime in MINUTES (1-60; default 5).\n"
                "Short-lived tokens are the design — do not raise this\n"
                "for public deployments. Or cancel."),
            "cachesize": (
                "\U0001F4BE CACHE MAX SIZE\n\n"
                "Send the maximum total cache size in MiB\n"
                "(64-4096; default 2048). Eviction is deterministic and\n"
                "never removes objects with active readers. Or cancel."),
            "cachettl": (
                "\u23F3 CACHE TTL\n\n"
                "Send the cache entry TTL in MINUTES (1-1440; default 60).\n"
                "Or cancel."),
        }
        context.user_data[WSITE_EDIT_KEY] = {"field": field, "dbid": 0}
        await deps.safe_edit_text(
            update.callback_query, "\u270F\uFE0F " + prompts[field],
            reply_markup=_kb([[_btn("\u274C Cancel", "wsite:stream")]]))
        return
    if field not in prompts:
        await deps.safe_answer_callback(update.callback_query,
                                        "Unknown editor.")
        return
    context.user_data[WSITE_EDIT_KEY] = {"field": field, "dbid": dbid}
    await deps.safe_edit_text(update.callback_query,
                              "\u270F\uFE0F " + prompts[field],
                              reply_markup=_kb([[_btn(
                                  "\u274C Cancel", f"wsite:view:{dbid}")]]))


# ============================================================
# BOT-11 (spec §2-§5) — MAIN MINI APP admin panel (wsmain:)
# ============================================================

async def main_miniapp_panel(update: Update,
                             context: ContextTypes.DEFAULT_TYPE,
                             deps: Any) -> None:
    """The 🌐 Main Mini App panel: the CURRENT canonical URL (or the
    honest "Not configured" — never invented), the per-bot apply-state
    summary (X applied / Y failed / Z not applied, from the schema v35
    mini_app_* columns), and the Change URL / Apply to All / Refresh
    actions. The panel lives NEXT TO the website_public_base_url editing
    surface because the canonical URL IS <base>/site."""
    db = deps.db
    url = await canonical_main_app_url(db)
    applied = failed = not_applied = 0
    try:
        bots = await db.list_network_bots()
    except Exception:  # noqa: BLE001 — honest empty state
        bots = []
    for b in bots or []:
        status = str((b or {}).get("mini_app_last_apply_status") or "")
        if status == "applied":
            applied += 1
        elif status == "failed":
            failed += 1
        else:
            not_applied += 1
    url_line = (f"Current URL: {url}" if url
                else "Current URL: Not configured")
    lines = [
        "\U0001F310 MAIN MINI APP",
        "",
        url_line,
        f"Registered bots: {applied} applied / {failed} failed / "
        f"{not_applied} not applied",
        "",
        "The Main Mini App is the public Website's /site surface",
        "(website_public_base_url + /site, HTTPS-validated). Every",
        "registered bot's Telegram menu button launches it, and the",
        "link is reapplied automatically on every bot start.",
    ]
    if not url:
        lines[3:3] = [
            "\u26A0\uFE0F Set the public base URL first — the Mini App",
            "link cannot be applied without an https:// base.",
        ]
    rows = [
        [_btn("\u270F\uFE0F Change URL", "wsmain:change"),
         _btn("\U0001F310 Apply to All Registered Bots", "wsmain:apply")],
        [_btn("\U0001F504 Refresh", "wsmain:refresh")],
        [_btn("\u2B05\uFE0F Back to Website Settings", "wsite:settings")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def main_miniapp_apply_all(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE,
                                 deps: Any) -> None:
    """Apply to All Registered Bots → the §4 TRUTHFUL bulk result render
    (never "all updated" when one failed). Applies to the MAIN bot too
    via the live main bot client (context.bot) when reachable — the
    "Main Bot" line only appears when the main apply was attempted; an
    unreachable main bot renders under Failed with the reason."""
    q = update.callback_query
    await deps.safe_answer_callback(
        q, "\u23F3 Applying the Main Mini App link to all registered "
           "bots...")
    applier = getattr(deps, "main_app_apply_all", None)
    if not callable(applier):
        await deps.safe_edit_text(
            q, "\U0001F310 MAIN MINI APP UPDATE\n\n\u26A0\uFE0F The bulk "
            "apply is unavailable in this deployment.",
            reply_markup=_kb([[_btn("\u2B05\uFE0F Back", "wsmain:main")]]))
        return
    try:
        res = await applier(context.bot)
    except Exception:  # noqa: BLE001 — honest failure panel
        logger.error("MAIN MINI APP bulk apply failed", exc_info=True)
        await deps.safe_edit_text(
            q, "\U0001F310 MAIN MINI APP UPDATE\n\n\u274C The bulk apply "
            "action failed — nothing was reported as updated.",
            reply_markup=_kb([[_btn("\u2B05\uFE0F Back", "wsmain:main")]]))
        return
    url = str(res.get("url") or "")
    if not url:
        await deps.safe_edit_text(
            q,
            "\U0001F310 MAIN MINI APP UPDATE\n\n\u26A0\uFE0F The canonical "
            "Main Mini App URL is not configured (or is not HTTPS).\n\n"
            "Set the public base URL first — an https:// URL. "
            "Nothing was applied.",
            reply_markup=_kb([[_btn("\u2B05\uFE0F Back", "wsmain:main")]]))
        return
    applied_ids = [int(x) for x in (res.get("applied") or [])]
    failed_list = [(int(a), str(b)) for a, b in (res.get("failed") or [])]
    skipped_list = [(int(a), str(b)) for a, b in (res.get("skipped") or [])]
    outcomes = {int(o.get("network_bot_id") or 0): o
                for o in (res.get("outcomes") or [])}
    main_info = res.get("main") or {}
    lines = ["\U0001F310 MAIN MINI APP UPDATE", ""]
    updated = 0
    failed = 0
    # The MAIN bot line (only when the main apply was attempted).
    if main_info.get("attempted"):
        uname = str(main_info.get("username") or "")
        if main_info.get("applied"):
            updated += 1
            lines.append("\u2705 Main Bot" + (f" @{uname}" if uname else ""))
        else:
            failed += 1
            lines.append("\u274C Main Bot"
                         + (f" @{uname}" if uname else ""))
            lines.append(f"   Reason: {main_info.get('reason') or 'unknown'}")
    for nid in applied_ids:
        updated += 1
        o = outcomes.get(nid) or {}
        lines.append(f"\u2705 Network Bot #{nid} @{o.get('username') or '?'}")
    for nid, reason in failed_list:
        failed += 1
        o = outcomes.get(nid) or {}
        lines.append(f"\u274C Network Bot #{nid} @{o.get('username') or '?'}")
        lines.append(f"   Reason: {reason}")
    for nid, reason in skipped_list:
        o = outcomes.get(nid) or {}
        lines.append(f"\u23ED Network Bot #{nid} @{o.get('username') or '?'}"
                     f" — skipped ({reason})")
    if not (applied_ids or failed_list or skipped_list
            or main_info.get("attempted")):
        lines.append("(no ACTIVE registered bots)")
    lines += [
        "",
        f"Canonical URL: {url}",
        f"Updated: {updated}",
        f"Failed: {failed}",
    ]
    try:
        await deps.log_admin_action(
            int(getattr(getattr(update, "effective_user", None), "id", 0)
                or 0),
            "website_main_miniapp_apply_all", "setting", None,
            f"applied={updated} failed={failed} url_configured=true")
    except Exception:  # noqa: BLE001 — audit is best-effort
        pass
    await deps.safe_edit_text(
        q, "\n".join(lines),
        reply_markup=_kb([
            [_btn("\U0001F504 Apply Again", "wsmain:apply")],
            [_btn("\u2B05\uFE0F Main Mini App", "wsmain:main")],
        ]))


async def main_miniapp_change_prompt(update: Update,
                                     context: ContextTypes.DEFAULT_TYPE,
                                     deps: Any) -> None:
    """Change URL → the text-input state (the file's existing
    wsite_edit machinery — the WSITE_EDIT_KEY state + the
    text_input.py routing that already feeds wsite_edit fields)."""
    context.user_data[WSITE_EDIT_KEY] = {"field": "mainappurl", "dbid": 0}
    await deps.safe_edit_text(
        update.callback_query,
        "\u270F\uFE0F MAIN MINI APP — CHANGE URL\n\n"
        "Send the HTTPS BASE URL of the public website\n"
        "(e.g. https://site.example.com) — the Main Mini App URL\n"
        "becomes <base>/site. Send a single dash '-' to clear it,\n"
        "or cancel.\n\n"
        "Only a valid HTTPS URL is stored; an invalid one is\n"
        "refused with the exact reason.",
        reply_markup=_kb([[_btn("\u274C Cancel", "wsmain:main")]]))


async def handle_wsmain_callback(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE,
                                 deps: Any) -> None:
    """Dispatch every ``wsmain:`` admin callback (BOT-11 spec §2-§5;
    admin-gated by the master gate before the facade is reached)."""
    data = str(update.callback_query.data or "")
    parts = data.split(":")
    action = parts[1] if len(parts) > 1 else ""
    if action == "main":
        await main_miniapp_panel(update, context, deps)
    elif action == "change":
        await main_miniapp_change_prompt(update, context, deps)
    elif action == "apply":
        await main_miniapp_apply_all(update, context, deps)
    elif action == "refresh":
        await deps.safe_answer_callback(update.callback_query,
                                        "Refreshed.")
        await main_miniapp_panel(update, context, deps)
    else:
        await deps.safe_answer_callback(update.callback_query,
                                        "Unknown Main Mini App action.")


# ============================================================
# Dispatcher
# ============================================================

async def handle_wsite_callback(update: Update,
                                context: ContextTypes.DEFAULT_TYPE,
                                deps: Any) -> None:
    """Dispatch every ``wsite:`` admin callback (called from bot.py's
    on_callback — admin-gated there by the master admin gate)."""
    data = str(update.callback_query.data or "")
    q = update.callback_query
    parts = data.split(":")
    action = parts[1] if len(parts) > 1 else ""
    arg = parts[2] if len(parts) > 2 else ""

    def _int_arg() -> int:
        try:
            return int(arg)
        except (TypeError, ValueError):
            return 0

    if action == "toggle":
        await website_toggle(update, context, deps)
    elif action == "settings":
        await website_settings_panel(update, context, deps)
    elif action == "thumbpolicy":
        await website_thumb_policy_panel(update, context, deps)
    elif action == "stream":
        await website_stream_panel(update, context, deps)
    elif action == "streamtoggle":
        await website_stream_toggle(update, context, deps)
    elif action == "cachetoggle":
        await website_cache_toggle(update, context, deps)
    elif action == "cachepurge":
        await website_cache_purge(update, context, deps)
    elif action in ("sttl", "csize", "cttl"):
        field = {"sttl": "streamttl", "csize": "cachesize",
                 "cttl": "cachettl"}[action]
        await website_edit_prompt(update, context, deps, field, 0)
    elif action == "seturl":
        await website_edit_prompt(update, context, deps, "baseurl", 0)
    elif action == "list":
        await website_list_panel(update, context, deps)
    elif action == "lpage":
        await website_list_panel(update, context, deps, page=_int_arg())
    elif action == "add":
        await website_wizard_start(update, context, deps)
    elif action == "addpkg":
        # V26 Upload Package Payload: the multi-select collection picker.
        # BOT-43 (spec §11 — work-stream B): AUTHORITATIVE-STATE SEEDING
        # on OPEN. The transient wsite_pkg_pick state is purged by
        # clear_wizard_states() on nearly every admin navigation, so
        # deriving the checkmarks from it alone showed every package
        # unchecked — even when half of them were LIVE on the Website.
        # The open now re-seeds the selection from the AUTHORITATIVE
        # website_payloads association rows (fresh from the DB) UNION
        # any surviving in-session toggles (the admin's not-yet-saved
        # desired state is preserved).
        sel = _pkg_sel(context)
        try:
            auth = [str(c) for c in
                    await deps.db.list_website_collection_codes()]
        except Exception:  # noqa: BLE001 — degrade to the transient state
            logger.warning("package picker authoritative seeding failed",
                           exc_info=True)
            auth = []
        merged: List[str] = []
        for c in auth + [str(c) for c in (sel.get("selected") or [])]:
            if c and c not in merged:
                merged.append(c)
        sel["selected"] = merged
        logger.info(
            "WEBSITE_PACKAGE_SELECTION_OPEN admin_user_id=%s "
            "selected_count=%s authoritative_count=%s page=%s",
            update.effective_user.id if update.effective_user else 0,
            len(merged), len(auth), 1)
        await website_package_picker(update, context, deps)
    elif action == "pkpage":
        # BOT-43: pagination rerenders re-derive the visual state from
        # the (seeded) server-side selection — the STATE telemetry pins
        # that the selection survived the navigation.
        _pp = max(1, _int_arg())
        logger.info(
            "WEBSITE_PACKAGE_SELECTION_STATE admin_user_id=%s "
            "selected_count=%s page=%s",
            update.effective_user.id if update.effective_user else 0,
            len([str(c) for c in
                 (_pkg_sel(context).get("selected") or [])]),
            _pp)
        await website_package_picker(update, context, deps, page=_pp)
    elif action == "pktog" and arg:
        # V26 FINAL (Part 9): toggle ONE package's checkbox — the state
        # lives SERVER-side (user_data); the callback only names the code,
        # and the toggle itself revalidates that the collection EXISTS
        # (a stale/deleted id never enters the selection).
        # BOT-43: the toggles maintain the DESIRED association set (the
        # open seeded it from the authoritative rows) — ADD/REMOVE
        # telemetry fires per toggle, alongside the V26 SELECT line.
        sel = _pkg_sel(context)
        code = str(arg).strip().lower()
        try:
            exists = await deps.db.get_collection(code) is not None
        except Exception:  # noqa: BLE001 — treat as stale
            exists = False
        if not exists:
            await deps.safe_answer_callback(
                q, "That package no longer exists.", show_alert=False)
        else:
            cur = [str(c) for c in (sel.get("selected") or [])]
            if code in cur:
                cur = [c for c in cur if c != code]
                logger.info(
                    "WEBSITE_PACKAGE_SELECTION_REMOVE admin_user_id=%s "
                    "canonical_id=%s selected_count=%s",
                    update.effective_user.id
                    if update.effective_user else 0,
                    code, len(cur))
                await deps.safe_answer_callback(
                    q, f"Deselected — Selected: {len(cur)}")
            else:
                cur = cur + [code]
                # BOT-40 (Section J): the package selection telemetry —
                # fired on every ADD (the state is server-side, the code
                # was just revalidated against the collections table).
                logger.info(
                    "WEBSITE_PACKAGE_SELECT admin_user_id=%s "
                    "canonical_kind=collection canonical_id=%s "
                    "selected_count=%s",
                    update.effective_user.id if update.effective_user else 0,
                    code, len(cur))
                # BOT-43: the diff-aware toggle telemetry (REMOVE is the
                # deselect branch above).
                logger.info(
                    "WEBSITE_PACKAGE_SELECTION_ADD admin_user_id=%s "
                    "canonical_id=%s selected_count=%s",
                    update.effective_user.id
                    if update.effective_user else 0,
                    code, len(cur))
                await deps.safe_answer_callback(
                    q, f"Selected: {len(cur)}")
            sel["selected"] = cur
        await website_package_picker(update, context, deps,
                                     page=int(sel.get("page") or 1))
    elif action == "pkall":
        # V26 FINAL (Part 9): Select All — every existing collection
        # (bounded page fetch; deduplicated).
        # BOT-43: request page_size=100 — list_collections_paged CLAMPS
        # page_size to 100, so the previous request of 200 silently
        # fetched only the first 100 anyway. Ask for exactly the clamp
        # and document the cap in the toast when the catalog exceeds it.
        sel = _pkg_sel(context)
        _cap_note = ""
        try:
            rows_all, _t = await deps.db.list_collections_paged(
                page=1, page_size=100)
            sel["selected"] = sorted(
                {str(r["collection_id"]) for r in rows_all})
            if int(_t or 0) > len(sel["selected"]):
                _cap_note = (f" — capped at the first "
                             f"{len(sel['selected'])} of {_t}")
        except Exception:  # noqa: BLE001 — keep current selection
            logger.warning("pkall fetch failed", exc_info=True)
        await deps.safe_answer_callback(
            q, f"Selected: {len(sel['selected'])}{_cap_note}")
        await website_package_picker(update, context, deps,
                                     page=int(sel.get("page") or 1))
    elif action == "pkclr":
        # V26 FINAL (Part 9): Clear All — the DESIRED set becomes empty.
        # BOT-43: this is now a MEANINGFUL state, not an abort: Continue
        # with an empty selection saves the unselect-all diff (every
        # package association removed). CLEAR telemetry.
        sel = _pkg_sel(context)
        sel["selected"] = []
        logger.info(
            "WEBSITE_PACKAGE_SELECTION_CLEAR admin_user_id=%s "
            "selected_count=0",
            update.effective_user.id if update.effective_user else 0)
        await deps.safe_answer_callback(q, "Selection cleared.")
        await website_package_picker(update, context, deps,
                                     page=int(sel.get("page") or 1))
    elif action == "pkcont":
        # V26 FINAL (Part 9): Continue — the BACKEND revalidates every
        # selected ID (existence + items), deduplicates, rejects
        # stale/deleted codes honestly, then routes: ONE valid selection
        # -> the EXISTING single-package wizard (unchanged path);
        # MULTIPLE -> the batch wizard. The client selection is never
        # trusted as-is.
        #
        # BOT-43 (spec §11 — work-stream B) — THE DIFF SAVE: the picker
        # selection IS the desired Website association set for the picked
        # packages.
        #   current = the codes actually listed on the Website (fresh
        #             from website_payloads — the AUTHORITATIVE state);
        #   desired = the validated selection;
        #   added   = desired - current -> the EXISTING wizard runs for
        #             EXACTLY these (title/desc/policy steps unchanged —
        #             never half-configured rows behind the wizard's
        #             back; the wizard's own publish keeps its
        #             skip-if-listed guard);
        #   removed = current - desired -> applied IMMEDIATELY in ONE
        #             transactional update (apply_website_collection_diff
        #             touches ONLY website_payloads rows — never
        #             collections / collection_items / indexed_files /
        #             storage);
        #   kept    = intersection -> untouched rows, no wizard needed.
        # An EMPTY selection is a deliberate UNSELECT-ALL: every package
        # association is removed (added=0) — and the canonical storage
        # NEVER loses a single row.
        sel = _pkg_sel(context)
        codes: List[str] = []
        for c in (sel.get("selected") or []):
            c = str(c).strip().lower()
            if c and c not in codes:
                codes.append(c)
        admin_id = (int(update.effective_user.id)
                    if update.effective_user else 0)
        # The authoritative current set (fresh from the DB — never the
        # client's word for what is listed).
        try:
            current = [str(c) for c in
                       await deps.db.list_website_collection_codes()]
        except Exception:  # noqa: BLE001 — honest abort of the save
            logger.warning("pkcont: authoritative listing fetch failed",
                           exc_info=True)
            await deps.safe_answer_callback(
                q, "Could not read the Website listings — nothing was "
                "changed. Try again.")
            await website_package_picker(update, context, deps,
                                         page=int(sel.get("page") or 1))
            return
        if not codes and not current:
            await deps.safe_answer_callback(
                q, "Select at least one package first.")
            await website_package_picker(update, context, deps,
                                         page=int(sel.get("page") or 1))
            return
        valid: List[str] = []
        rejected: List[str] = []
        if codes:
            for code in codes:
                try:
                    coll = await deps.db.get_collection(code)
                    n = (await deps.db.count_collection_items(code)
                         if coll is not None else 0)
                except Exception:  # noqa: BLE001 — stale
                    coll, n = None, 0
                if coll is None or int(n or 0) <= 0:
                    rejected.append(code)
                else:
                    valid.append(code)
            if rejected:
                sel["selected"] = valid
                await deps.safe_answer_callback(
                    q, "Skipped stale/empty: "
                    + ", ".join("c" + c for c in rejected[:5])
                    + ("\u2026" if len(rejected) > 5 else ""),
                    show_alert=True)
            if not valid:
                # A fully-stale selection is a BROKEN state — never a
                # destructive unselect-all. Refuse honestly.
                await deps.safe_answer_callback(
                    q, "No valid packages remain — select again.")
                await website_package_picker(update, context, deps,
                                             page=int(sel.get("page") or 1))
                return
            sel["selected"] = valid
        # ---- the association diff --------------------------------------
        desired_set = set(valid)
        current_set = set(current)
        added = [c for c in valid if c not in current_set]
        removed = [c for c in current if c not in desired_set]
        kept = [c for c in current if c in desired_set]
        # The REMOVE side is applied IMMEDIATELY — ONE transactional
        # update; ONLY website_payloads rows change.
        if removed:
            try:
                await deps.db.apply_website_collection_diff(
                    added=[], removed=removed, created_by=admin_id)
            except Exception:  # noqa: BLE001 — honest failure, no partial save
                logger.warning("pkcont: diff save failed", exc_info=True)
                await deps.safe_answer_callback(
                    q, "Could not update the Website — nothing was "
                    "changed. Try again.")
                await website_package_picker(update, context, deps,
                                             page=int(sel.get("page") or 1))
                return
            for code in removed:
                # BOT-43: per-association removal telemetry — phase=save
                # distinguishes the APPLIED removal from a picker toggle.
                logger.info(
                    "WEBSITE_PACKAGE_SELECTION_REMOVE admin_user_id=%s "
                    "canonical_id=%s selected_count=%s phase=save",
                    admin_id, code, len(valid))
        # The SAVE lifecycle telemetry — the exact diff that was applied.
        logger.info(
            "WEBSITE_PACKAGE_SELECTION_SAVE admin_user_id=%s "
            "selected_count=%s added_count=%s removed_count=%s "
            "kept_count=%s",
            admin_id, len(valid), len(added), len(removed), len(kept))
        try:
            await deps.log_admin_action(
                admin_id, "website_package_diff_save", "website_payload",
                None, f"added={len(added)} removed={len(removed)} "
                      f"kept={len(kept)} selected={len(valid)}")
        except Exception:  # noqa: BLE001 — audit is best-effort
            pass
        if not added:
            # Pure removal / unselect-all / no-op: NO wizard — an honest
            # confirmation summary, then the picker state is cleared.
            summary = [f"\u2705 Website updated: +{len(added)} "
                       f"\u2212{len(removed)}", ""]
            if not valid:
                summary.append("All package associations were removed "
                               "from the Website.")
            elif removed:
                summary.append(f"Removed {len(removed)} package "
                               f"association(s); {len(kept)} kept.")
            else:
                summary.append(f"The selection already matches the "
                               f"Website — {len(kept)} kept, nothing "
                               "changed.")
            summary += ["",
                        "Collections, files and storage were NOT touched "
                        "— only the Website listings changed."]
            sel["selected"] = []
            await deps.safe_answer_callback(q, "Website updated.")
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\n".join(summary),
                reply_markup=_kb([
                    [_btn("\U0001F4E6 Package picker", "wsite:addpkg")],
                    [_btn("\U0001F310 Website Control", "panel:website")]]))
            return
        # added non-empty: a brief notice when removals were applied in
        # the same save, then the EXISTING wizard for the ADDED packages
        # ONLY (kept/removed need no wizard) — V26 behavior for adds.
        if removed:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                f"\u2705 Website updated: +0 \u2212{len(removed)}\n"
                "Removed: "
                + ", ".join("c" + c for c in removed[:8])
                + ("\u2026" if len(removed) > 8 else ""))
        if len(added) == 1:
            await website_wizard_start(update, context, deps,
                                       prefill_link=f"c{added[0]}",
                                       prefill_kind="collection")
        else:
            await website_wizard_start_batch(update, context, deps,
                                             codes=added)
    elif action == "addsingle":
        # V26 Upload Single Payload: the payload picker entry.
        await website_single_picker(update, context, deps)
    elif action == "spage":
        await website_single_picker(update, context, deps, page=_int_arg())
    elif action == "spick" and _int_arg():
        # V26: a single payload was PICKED — resolve its slug from the
        # compact id and start the prefilled wizard.
        _sp_row = None
        try:
            _sp_row = await deps.db.get_payload_by_id(_int_arg())
        except Exception:  # noqa: BLE001
            _sp_row = None
        if _sp_row is None:
            await deps.safe_answer_callback(
                q, "That payload no longer exists.", show_alert=True)
            await website_single_picker(update, context, deps)
            return
        # BOT-40 (Section I): the single selection telemetry — the
        # picker's display_name is the SOURCE the whole flow must keep.
        logger.info(
            "WEBSITE_SINGLE_SELECT admin_user_id=%s canonical_kind=payload "
            "canonical_id=%s source_display_name=%s",
            update.effective_user.id if update.effective_user else 0,
            int(_sp_row["id"]),
            str(_sp_row["display_name"] or _sp_row["payload"] or "-")[:80])
        await website_wizard_start(
            update, context, deps,
            prefill_link=str(_sp_row["payload"] or ""),
            prefill_kind="payload")
    elif action == "wskip":
        await website_wizard_skip_thumb(update, context, deps)
    elif action == "wtitle":
        await _wizard_edit_field(update, context, deps, "edittitle")
    elif action == "wdesc":
        await _wizard_edit_field(update, context, deps, "editdesc")
    elif action == "wtags":
        await _wizard_edit_field(update, context, deps, "edittags")
    elif action == "wpub":
        await website_wizard_publish(update, context, deps)
    elif action == "wcancel":
        await website_wizard_cancel(update, context, deps)
    elif action == "view" and _int_arg():
        await website_view_listing(update, context, deps, _int_arg())
    elif action == "pub" and _int_arg():
        await website_listing_action(update, context, deps, "pub", _int_arg())
    elif action == "unpub" and _int_arg():
        await website_listing_action(update, context, deps, "unpub",
                                     _int_arg())
    elif action == "del" and _int_arg():
        await website_listing_action(update, context, deps, "del", _int_arg())
    elif action == "delconfirm" and _int_arg():
        await website_listing_action(update, context, deps, "delconfirm",
                                     _int_arg())
    elif action == "check" and _int_arg():
        await website_listing_action(update, context, deps, "check",
                                     _int_arg())
    elif action in ("etitle", "edesc", "etags", "epos", "rethumb") \
            and _int_arg():
        field = {"etitle": "title", "edesc": "description", "etags": "tags",
                 "epos": "position", "rethumb": "rethumb"}[action]
        await website_edit_prompt(update, context, deps, field, _int_arg())
    else:
        await deps.safe_answer_callback(q, "Unknown website action.")


async def _wizard_edit_field(update: Update,
                             context: ContextTypes.DEFAULT_TYPE,
                             deps: Any, step: str) -> None:
    st = _wizard_get(context)
    if not st:
        await website_wizard_start(update, context, deps)
        return
    st["step"] = step
    prompts = {
        "edittitle": "Send the new TITLE (or cancel):",
        "editdesc": "Send the new DESCRIPTION (or cancel):",
        "edittags": "Send the new TAGS, comma or space separated (or cancel):",
    }
    await deps.safe_send_text(context.bot, update.effective_chat.id,
                              "\u270F\uFE0F " + prompts[step],
                              reply_markup=_kb([[_btn("\u274C Cancel",
                                                      "wsite:wcancel")]]))
