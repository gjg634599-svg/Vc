"""Payload search — manager search + results.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



# ============================================================
# PAYLOAD MANAGER SEARCH (Issue 11/18: supports all link types)
# ============================================================
async def _payload_manager_search(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                   query_text: str) -> None:
    """Unified search for the Payload Manager's Find Payload feature.

    Issue 11/18 Critical Fix: detects the link type and routes to the correct
    lookup. Previously only searched the payloads table by name, so collection
    links (cXXXXXXX) and message links (mXXXXXXX) were never found.

    Detection order (per spec):
      1. cXXXXXXX  -> collection lookup
      2. mXXXXXXX  -> message-id file lookup
      3. rSTART_END -> legacy range (auto-migrate to collection)
      4. alias search -> payload_aliases table
      5. name search  -> payloads table (LIKE)
    """
    text = query_text.strip()
    # Normalize: if the user pasted a full URL, extract the start= argument.
    if "start=" in text:
        text = text.split("start=", 1)[1].split("&", 1)[0].split("#", 1)[0].strip()
    arg = text.lower()

    logger.debug("PayloadManager: search query='%s' normalized='%s'", query_text, arg)

    # 1. Collection link (cXXXXXXX)
    if is_collection_link(arg):
        code = parse_collection_link(arg)
        logger.debug("PayloadManager: collection lookup code=%s", code)
        coll = await db.get_collection(code)
        if coll:
            count = coll["file_count"] or 0
            await reply_protected(update, 
                f"*\U0001F4E6 Collection Found*\n\n"
                f"Type: Collection\n"
                f"Files: {count}\n"
                f"Link: {md_code_span(build_collection_link(code))}",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\U0001F441 Preview", callback_data=f"linkpreview:c:{code}")],
                    [InlineKeyboardButton("\U0001F4CB Copy Link", callback_data=f"cocopy:{code}")],
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:payloads")],
                ]),
            )
            return
        await reply_protected(update, 
            "\u274C Collection not found.\n\nNo collection matches this link.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:payloads")],
            ]),
        )
        return

    # 2. Message link (mXXXXXXX)
    if is_msg_link(arg):
        msg_id = parse_msg_link(arg)
        logger.debug("PayloadManager: message-id lookup msg_id=%s", msg_id)
        file_row = await db.get_indexed_file_by_message_id(msg_id)
        if file_row:
            name = (file_row["file_name"] or "Unknown")[:40]
            mtype = media_type_label(file_row["media_type"])
            await reply_protected(update, 
                f"*\U0001F4C4 File Found*\n\n"
                f"Type: {mtype}\n"
                f"Name: {name}\n"
                f"Link: {md_code_span(build_msg_link(msg_id))}",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\U0001F441 Preview", callback_data=f"linkpreview:m:{msg_id}")],
                    [InlineKeyboardButton("\U0001F4CB Copy Link", callback_data=f"mlinkcopy:{msg_id}")],
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:payloads")],
                ]),
            )
            return
        await reply_protected(update, 
            "\u274C File not found.\n\nNo indexed file matches this message ID.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:payloads")],
            ]),
        )
        return

    # 3. Legacy range link (rSTART_END)
    if is_range_link(arg):
        start_id, end_id = parse_range_link(arg)
        logger.debug("PayloadManager: range lookup start=%s end=%s", start_id, end_id)
        # Migrate to collection for display.
        code = await _migrate_legacy_range_to_collection(start_id, end_id, user_id=update.effective_user.id)
        if code:
            coll = await db.get_collection(code)
            count = coll["file_count"] if coll else 0
            await reply_protected(update, 
                f"*\U0001F4E6 Collection Found (migrated from range)*\n\n"
                f"Type: Collection\n"
                f"Files: {count}\n"
                f"Link: {md_code_span(build_collection_link(code))}",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\U0001F441 Preview", callback_data=f"linkpreview:c:{code}")],
                    [InlineKeyboardButton("\U0001F4CB Copy Link", callback_data=f"cocopy:{code}")],
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:payloads")],
                ]),
            )
            return
        await reply_protected(update, 
            "\u274C Range not found.\n\nNo indexed files in this range.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:payloads")],
            ]),
        )
        return

    # 4. Alias search
    logger.debug("PayloadManager: alias lookup query='%s'", arg)
    alias_row = await db.alias_owner(arg)
    if alias_row:
        payload_row = await db.get_payload_by_id(alias_row["payload_id"])
        if payload_row:
            await _show_payload_search_result(update, payload_row, is_alias=True)
            return

    # 5. Name search — PHASE 7 (Task 3): real fuzzy database search with the
    #    SAME pagination + page-context preservation as the Payload Manager.
    #    Exact matches rank first, then prefix / substring / token matches;
    #    normalization is case-insensitive + whitespace/punctuation tolerant
    #    and hashtag-aware ('#movie' matches payloads named '#movie',
    #    'movie', 'My #Movie 2024', 'sonali_bhabhi_movie', ...).
    logger.debug("PayloadManager: fuzzy name search query='%s'", arg)
    query_clean = query_text.strip()[:PL_SEARCH_QUERY_MAX_LEN]
    rows, total = await db.search_payloads_fuzzy(query_clean,
                                                 limit=PAYLOADS_PER_PAGE, offset=0)
    if not rows:
        await reply_protected(update,
            "No matching payloads.\n\n"
            "Supported: collection links (cXXXXXXX), message links (mXXXXXXX), "
            "range links (rSTART_END), aliases, and payload names.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:payloads")],
            ]),
        )
        return
    # Persist the query (restart-safe navigation) and render the results
    # through the standard search panel — including the single-result case
    # (it keeps the same Back-to-search-page-N behaviour; a lone match still
    # gets the full detail with search context).
    qid = await _pl_search_store_query(query_clean)
    logger.info("PAYLOAD_SEARCH_QUERY qid=%s query_len=%s tokens=%s results=%s",
                qid, len(query_clean),
                len(db._search_tokens(query_clean)), total)
    if total == 1:
        # Single hit: open the detail directly, carrying the search context
        # so Back returns to the (single) search result page.
        await pm_payload_detail(update, context, int(rows[0]["id"]),
                                list_page=0, search_qid=qid)
        return
    await payload_search_results_panel(update, context, query_clean, page=0)



async def _show_payload_search_result(update: Update, row: aiosqlite.Row,
                                       is_alias: bool = False) -> None:
    """Display a single payload search result with details + actions."""
    name = row["payload"]  # routing slug (immutable)
    # BOTV13: show display_name as the title, routing slug below.
    stored_dn = row["display_name"] if "display_name" in row.keys() else None
    display = stored_dn if stored_dn else name
    status = row["status"]
    one_time = row["one_time"]
    aliases = await db.list_aliases(row["id"])
    alias_str = ", ".join(a["alias"] for a in aliases) if aliases else "None"
    label = " (via alias)" if is_alias else ""
    await reply_protected(update,
        f"*\U0001F517 Payload Found{label}*\n\n"
        f"Name: {escape_md(display)}\n"
        f"Routing ID: {md_code_span(name)}\n"
        f"Status: {escape_md(status)}\n"
        f"One-time: {'yes' if one_time else 'no'}\n"
        f"Aliases: {escape_md(alias_str)}\n"
        f"Link: {md_code_span(build_link(name))}",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:payloads")],
        ]),
    )
