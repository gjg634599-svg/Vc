"""Start & help — welcome messages, start/help commands.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



# ============================================================
# START MESSAGE SYSTEM
# ============================================================
def _default_first_welcome() -> str:
    """Built dynamically so BOT_USERNAME is the auto-detected value."""
    return (
        "\U0001F44B *Welcome!*\n\n"
        "I deliver files through special links.\n"
        "Tap a button below or open a delivery link like:\n"
        f"`{build_start_link('<payload>')}`\n\nto receive your file."
    )



async def send_start_message(bot, chat_id: int, variant: str) -> Optional[Message]:
    """Send the configured start message (or a default) for the given variant.

    Returns the sent Message (so admin previews can schedule a silent
    auto-delete) or None on failure.

    BOTV13 Phase B (wired): deserializes the stored `entities` column and
    passes them to Telegram as `entities` (text) or `caption_entities`
    (photo/video) so bold/italic/text_link/code/etc. survive SAVE → PREVIEW
    → SEND. Never falls back to Markdown parsing of the raw text — the
    original Telegram entities are the source of truth.
    """
    row = await db.get_start_message(variant)
    if not row or (not row["caption"] and row["message_type"] in (None, "text", "none")):
        text = DEFAULT_RETURNING_WELCOME if variant == "returning" else _default_first_welcome()
        # Issue #44: use safe_send_text for internal protection.
        return await safe_send_text(bot, chat_id, text,
                                    parse_mode=ParseMode.MARKDOWN,
                                    disable_web_page_preview=True)

    buttons = build_start_buttons(row["buttons_json"])
    mt = row["message_type"] or "text"
    cap = truncate(row["caption"], 1024)
    # BOTV13 Phase B: deserialize stored entities. Pass as caption_entities
    # for media, entities for plain text. Do NOT set parse_mode when entities
    # are present (Telegram rejects parse_mode + entities combo).
    ent_list = deserialize_entities(row["entities"] if "entities" in row.keys() else None)
    text_kwargs: Dict[str, Any] = {}
    media_kwargs: Dict[str, Any] = {}
    if ent_list:
        text_kwargs["entities"] = ent_list
        media_kwargs["caption_entities"] = ent_list
    try:
        if mt == "photo" and row["file_id"]:
            return await send_bot_photo(bot, chat_id, row["file_id"],
                                        caption=cap, reply_markup=buttons, **media_kwargs)
        elif mt == "video" and row["file_id"]:
            return await send_bot_video(bot, chat_id, row["file_id"],
                                        caption=cap, reply_markup=buttons, **media_kwargs)
        else:
            # Issue #44: use safe_send_text for internal protection. When
            # entities are present, do NOT use parse_mode (Telegram rejects the
            # combination). When no entities, keep the legacy MARKDOWN parse
            # for backward compat with old default-template sends.
            if ent_list:
                return await safe_send_text(bot, chat_id, cap or _default_first_welcome(),
                                            reply_markup=buttons,
                                            disable_web_page_preview=True, **text_kwargs)
            return await safe_send_text(bot, chat_id, cap or _default_first_welcome(),
                                        reply_markup=buttons, parse_mode=ParseMode.MARKDOWN,
                                        disable_web_page_preview=True)
    except TelegramError as e:
        logger.error("start message send failed: %s", e)
        text = DEFAULT_RETURNING_WELCOME if variant == "returning" else _default_first_welcome()
        return await safe_send_text(bot, chat_id, text,
                                    parse_mode=ParseMode.MARKDOWN,
                                    disable_web_page_preview=True)



# ============================================================
# /start  (payload entry point)
# ============================================================
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not user:
        return
    # BOTV13 Phase 3 (Group Safety): /start only works in private chats.
    # Groups/supergroups are ignored so the bot doesn't reply to /start in
    # group contexts (Telegram sometimes forwards /start to groups).
    chat_type = update.effective_chat.type if update.effective_chat else None
    if chat_type in ("group", "supergroup"):
        return

    # Detect returning user BEFORE upsert (upsert would create the row).
    is_returning = await db.user_exists(user.id)
    await db.upsert_user(user.id, user.username, user.first_name)

    args = context.args
    # NETWORK PLATFORM (v29): record the user↔bot reachability membership
    # when this /start is served by a NETWORK worker (spec §15). The main
    # bot needs no membership row (it is the routing fallback context).
    _net_bot_id = _net_context_id(context)
    if _net_bot_id is not None:
        await _network_record_start(_net_bot_id, user.id)
        try:
            await db.bump_network_bot_activity(_net_bot_id)
        except Exception:  # noqa: BLE001
            pass
    if not args:
        # No payload -> show start message (skip for admins who get the panel).
        # BOT7 FIX (DB-admin): use the canonical async is_admin() so admins
        # added via the Admin Dashboard (admins table, is_active=1) receive the
        # Admin Panel exactly like env-configured admins. Raw ADMIN_IDS checks
        # are no longer used as the runtime gate.
        if await is_admin(user.id):
            logger.info(
                "BOT6_ADMIN_AUTH user_id=%s entry_point=start source=%s "
                "result=granted action=show_admin_panel",
                user.id, "env" if user.id in ADMIN_IDS else "db",
            )
            clear_wizard_states(context)  # clear stale wizard states on panel open
            await show_admin_panel(update, context)
        else:
            if is_returning:
                if await welcome_returning_active():
                    await send_start_message(context.bot, user.id, "returning")
                else:
                    await reply_protected(update,
                        DEFAULT_RETURNING_WELCOME, parse_mode=ParseMode.MARKDOWN
                    )
            else:
                await send_start_message(context.bot, user.id, "first")
        # BOT-45/46 §14 (Task C): a REGISTERED network bot's /start carries
        # the visible "Open Main App" button pointing at the ONE canonical
        # Main Mini App TELEGRAM link — https://t.me/<MAIN_MINI_APP_BOT_
        # USERNAME>?startapp (or the configured Named Direct Mini App form)
        # — built by app/network/bot_miniapp.py build_main_mini_app_link()
        # through the _net_main_app_link facade (MAIN_APP_OPEN telemetry).
        # NEVER the Worker URL and NEVER a fabricated t.me/undefined link:
        # unresolvable → ADMINS get the honest configuration error; regular
        # users simply see no button (config-pending, least disruptive).
        # Only inside a network worker; one compact companion message (the
        # welcome message's own keyboard is admin-configured and untouched).
        if _net_bot_id is not None:
            try:
                _ma_link = await _net_main_app_link(
                    user_id=user.id, surface="start")
            except Exception:  # noqa: BLE001 — the link is optional UX
                _ma_link = None
            if _ma_link:
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "🌐 Open the platform's Main App:",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("🌐 Open Main App",
                                             url=_ma_link)]]))
            elif await is_admin(user.id):
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "\u26A0\uFE0F Main App button hidden — the Main Mini App "
                    "link is not configured.\n\nSet the platform's main bot "
                    "username (bot_settings key "
                    "'main_mini_app_bot_username') or rely on the running "
                    "main bot's auto-detected username, then restart. No "
                    "broken link was sent to users.")
        return

    # With payload -> deliver immediately, skip welcome.
    # v37 (bot-8 A6/A8): Global Payload Link codes are CASE-SENSITIVE
    # (base62 code + HMAC sig over the EXACT case). The historical
    # .lower() here corrupted the signature for virtually every minted
    # link ("Invalid or expired link" at click time). The raw argument
    # is used for the g-link path; everything else keeps the legacy
    # lowercased behavior (payload slugs are case-insensitive).
    arg_raw = args[0]
    arg = args[0].lower()

    # NETWORK PLATFORM (v29): Global Payload Link (/start g<code> — spec
    # §17-§20). Checked FIRST: the g-prefix never collides with ref_/c/m/r
    # link types, and the routing context (fallback counter) is carried in
    # the link itself.
    logger.info("GLOBAL_LINK_START_RECEIVED user_id=%s arg_len=%s "
                "case_mixed=%s", user.id, len(arg_raw),
                arg_raw != arg_raw.lower())
    if is_global_payload_link(arg_raw):
        await handle_global_payload_link(update, context, user, arg_raw)
        return

    # Issue #94: Referral links (/start ref_<token>). Must be checked BEFORE
    # other link types since the token is opaque and won't match m/c/r prefixes.
    # V8: ALWAYS return after a referral link — never fall through to the
    # welcome/admin panel, even if token parsing fails.
    if is_referral_link(arg):
        token = parse_referral_token(arg)
        if token:
            await handle_referral_start(update, context, token, user)
            return
        # Defensive: is_referral_link validated the format, so this is
        # unreachable. Still return to guarantee no fallthrough.
        await safe_send_text(context.bot, update.effective_chat.id,
                             "\u274C Invalid or expired referral link.")
        return

    # FEATURE: Collection links (/start c7f3a9b2). Issue 2 Critical Fix.
    # Takes priority over range links so new c<link> format works.
    if is_collection_link(arg):
        collection_code = parse_collection_link(arg)
        await deliver_collection(update, context, collection_code, user)
        return

    # FEATURE 1: Message-ID direct links (/start m8619).
    if is_msg_link(arg):
        message_id = parse_msg_link(arg)
        await deliver_message_file(update, context, message_id, user)
        return

    # FEATURE: Legacy range links (/start r8619_8625). Auto-migrated to an
    # explicit collection on first open (Issue 2 backward-compat).
    if is_range_link(arg):
        start_id, end_id = parse_range_link(arg)
        # Migrate the range to an explicit collection, then deliver it.
        admin_uid = user.id
        code = await _migrate_legacy_range_to_collection(start_id, end_id, user_id=admin_uid)
        if code:
            await deliver_collection(update, context, code, user)
        else:
            await safe_send_text(context.bot, update.effective_chat.id,
                                 "\u274C Invalid or expired link.")
        return

    # FEATURE: Incomplete range link (r29 without _end) -> invalid link.
    if arg.startswith(RANGE_LINK_PREFIX) and arg[1:].isdigit():
        await safe_send_text(context.bot, update.effective_chat.id,
                             "\u274C Invalid or expired link.")
        return

    # BOTV13 Part 1: Human-friendly payload links.
    # New format: <slugified_display_name>_<routing_id>
    # The routing_id is extracted from the end of the arg. Old-style links
    # (bare slug or bare c<code>) are handled as the "full" match.
    # First try the full arg as a collection link (old-style c<code>).
    if is_collection_link(arg):
        collection_code = parse_collection_link(arg)
        await deliver_collection(update, context, collection_code, user)
        return
    # Try the full arg as a named payload (old-style bare slug).
    payload_row = await db.get_payload(arg)
    if payload_row:
        await attempt_delivery(update, context, arg, user)
        return
    # New format: extract the routing ID from the end.
    routing_id, match_type = await _resolve_routing_id(arg, user_id=user.id if user else 0)
    if routing_id:
        logger.info("Start: resolved routing_id=%s (match=%s) from arg=%s", routing_id, match_type, arg)
        if is_collection_link(routing_id):
            collection_code = parse_collection_link(routing_id)
            await deliver_collection(update, context, collection_code, user)
            return
        # Named payload — use the routing_id for delivery.
        await attempt_delivery(update, context, routing_id, user)
        return

    # Neither payload nor collection -> invalid link (Issue 14).
    logger.warning("Start: could not resolve payload from arg=%s (no full match, no routing_id suffix)", arg)
    # V8: explicit return — the /start handler NEVER continues to the
    # welcome/admin panel when a payload parameter was present.
    await safe_send_text(context.bot, update.effective_chat.id,
                         "\u274C Invalid or expired link.")
    return



async def render_help_screen() -> Tuple[str, InlineKeyboardMarkup, Optional[list]]:
    """BOT6: render the user-facing Help / User Guide.

    Loads the admin-configured help_message row (variant='default'); falls
    back to DEFAULT_HELP_TEXT if none. Returns (text, keyboard, entities) so
    the caller can send media+caption or plain text, preserving formatting.
    The keyboard includes a \u2B05\uFE0F Back button that returns to the previous
    screen (caller sets the back callback_data).
    """
    row = None
    try:
        row = await db.get_help_message("default")
    except Exception:  # noqa: BLE001
        row = None
    if row and row["caption"]:
        text = row["caption"]
        entities = deserialize_entities(row["entities"] if "entities" in row.keys() else None)
    else:
        text = DEFAULT_HELP_TEXT
        entities = None
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="help:back")],
    ])
    return text, kb, entities



async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """BOT6: /help is USER-FACING — shows the guide to everyone (not admin-only).

    Renders the admin-configurable help_message (or default). Edits in place
    when invoked from a callback; sends a new message when invoked from a
    command."""
    user = update.effective_user
    if not user:
        return
    text, kb, entities = await render_help_screen()
    # When invoked as a callback (help button), edit in place.
    q = update.callback_query if hasattr(update, "callback_query") else None
    if q:
        if entities:
            await safe_edit_text(q, text, reply_markup=kb, entities=entities)
        else:
            await safe_edit_text(q, text, reply_markup=kb)
        return
    # Command invocation — send a new message.
    if entities:
        await safe_send_text(context.bot, update.effective_chat.id, text,
                              reply_markup=kb, entities=entities)
    else:
        await safe_send_text(context.bot, update.effective_chat.id, text,
                              reply_markup=kb)



async def show_help_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """BOT6 Phase 26: admin Help / User Guide editor panel.

    Shows the current help text + media status, with buttons to edit text,
    media, buttons, preview, and toggle enabled. Mirrors the start message editor.
    """
    row = await db.get_help_message("default")
    if row:
        mt = row["message_type"] or "text"
        cap_preview = (row["caption"] or "(not set)")[:80]
        has_buttons = bool(row["buttons_json"] and row["buttons_json"] != "[]")
        enabled = bool(row["enabled"])
    else:
        mt = "none"
        cap_preview = DEFAULT_HELP_TEXT[:80] + "..."
        has_buttons = False
        enabled = True

    status_str = "\U0001F7E2 Enabled" if enabled else "\U0001F534 Disabled"
    buttons_str = "yes" if has_buttons else "no"

    text = (
        "*\U0001F4DA Help / User Guide*\n\n"
        f"Status: {status_str}\n"
        f"Type: {mt}\n"
        f"Text: {cap_preview}\n"
        f"Buttons: {buttons_str}\n\n"
        "This guide is shown to ALL users via /help and the \U0001F4DA Help button."
    )
    kb_rows: List[List[InlineKeyboardButton]] = [
        [InlineKeyboardButton("\u270F\uFE0F Edit Text", callback_data="help:edittext"),
         InlineKeyboardButton("\U0001F5BC Edit Media", callback_data="help:media")],
        [InlineKeyboardButton("\U0001F518 Edit Buttons", callback_data="help:buttons"),
         InlineKeyboardButton("\U0001F441 Preview", callback_data="help:preview")],
        [InlineKeyboardButton("\U0001F534 Disable" if enabled else "\U0001F7E2 Enable",
                              callback_data="help:toggle")],
        [InlineKeyboardButton("\U0001F504 Reset to Default", callback_data="help:reset")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:main")],
    ]
    await safe_edit_text(update.callback_query, text,
                         parse_mode=ParseMode.MARKDOWN,
                         reply_markup=InlineKeyboardMarkup(kb_rows))
