"""Referral — dashboards, referral start, appreciation.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



async def _maybe_send_appreciation(bot, campaign, inviter_user_id: int,
                                    required: int) -> None:
    """BOTV13 Part 2: Send at most one appreciation notification per 24 hours
    to an already-unlocked inviter. Summarizes new joins in the last 24h.

    Rate-limit logic:
      - Read `last_thank_you_sent` from payload_unlocks.
      - If None or > 24 hours ago: send appreciation + update timestamp.
      - Else: do nothing (no notification).
    """
    payload_id = campaign["payload_id"] if campaign else None
    campaign_id = campaign["id"] if campaign and "id" in campaign.keys() else None
    if not payload_id:
        return
    try:
        # Read the current appreciation timestamp.
        cur = await db.conn.execute(
            "SELECT last_thank_you_sent FROM payload_unlocks "
            "WHERE payload_id = ? AND user_id = ?",
            (payload_id, inviter_user_id),
        )
        row = await cur.fetchone()
        last_sent_str = row["last_thank_you_sent"] if row and "last_thank_you_sent" in row.keys() else None
        now = datetime.now(timezone.utc)
        should_send = True
        if last_sent_str:
            try:
                last_sent = datetime.fromisoformat(last_sent_str)
                if last_sent.tzinfo is None:
                    last_sent = last_sent.replace(tzinfo=timezone.utc)
                elapsed = (now - last_sent).total_seconds()
                if elapsed < 86400:  # 24 hours
                    should_send = False
            except (ValueError, TypeError):
                pass  # Corrupt timestamp — send anyway.
        if not should_send:
            logger.debug("Appreciation: rate-limited (last sent < 24h) for inviter %s.", inviter_user_id)
            return
        # Count new joins in the last 24 hours for this campaign+inviter.
        cutoff = (now - timedelta(hours=24)).isoformat()
        cur = await db.conn.execute(
            "SELECT COUNT(*) as c FROM referral_history "
            "WHERE campaign_id = ? AND inviter_user_id = ? AND qualified = 1 "
            "AND created_at >= ?",
            (campaign_id, inviter_user_id, cutoff),
        )
        count_row = await cur.fetchone()
        new_joins = int(count_row["c"]) if count_row else 0
        # Build the appreciation message with human-friendly referral link.
        payload_row = await db.get_payload_by_id(int(payload_id))
        display_name = None
        routing_slug = None
        if payload_row:
            routing_slug = payload_row["payload"]
            display_name = payload_row["display_name"] if "display_name" in payload_row.keys() else None
        # Build the appreciation text.
        if new_joins > 0:
            appreciate_text = (
                "\U0001F389 Thanks for inviting more friends!\n\n"
                f"\U0001F4C8 Last 24 hours\n"
                f"\U0001F465 New joins: {new_joins}\n\n"
                f"Keep sharing your invite link if you'd like to help more "
                f"people discover this content."
            )
        else:
            appreciate_text = (
                "\U0001F389 Thank you for sharing!\n\n"
                f"\u2764\ufe0f Your support helps the community grow."
            )
        # Append the referral link if available.
        if routing_slug:
            link = build_link(routing_slug, display_name=display_name)
            appreciate_text += f"\n\n{link}"
        await safe_send_text(bot, inviter_user_id, appreciate_text)
        # Update the last_thank_you_sent timestamp.
        await db.conn.execute(
            "UPDATE payload_unlocks SET last_thank_you_sent = ? "
            "WHERE payload_id = ? AND user_id = ?",
            (now.isoformat(), payload_id, inviter_user_id),
        )
        await db.conn.commit()
        logger.info("Appreciation: sent to inviter %s (new_joins_24h=%s).", inviter_user_id, new_joins)
    except Exception as e:  # noqa: BLE001
        logger.warning("Appreciation: failed for inviter %s: %s", inviter_user_id, e)


def _build_progress_bar_styled(completed: int, required: int, style: str = "block",
                                width: int = 10) -> str:
    """Build a progress bar in the configured style.

    Styles:
      block   → ████░░░░░░ (default)
      square  → ■■■■□□□□□□
      emoji   → 🟩🟩🟩🟩⬜⬜⬜⬜⬜⬜
      solid   → ██████████ (full blocks, no empty glyph — for 100% look)
      circle  → ⬤⬤⬤⬤○○○○○○
      default → block
    """
    if required <= 0:
        filled = width
    else:
        filled = min(width, int((completed / required) * width))
    remaining = width - filled
    if style == "square":
        return ("\u25A0" * filled) + ("\u25A1" * remaining)
    elif style == "emoji":
        return ("\U0001F7E9" * filled) + ("\u26AB" * remaining)
    elif style == "solid":
        # Solid uses full blocks everywhere; empty cells are spaces so the bar
        # keeps its width but reads as a continuous fill.
        return ("\u2588" * filled) + (" " * remaining)
    elif style == "circle":
        return ("\u2B24" * filled) + ("\u25CB" * remaining)
    else:  # block / default
        return ("\u2588" * filled) + ("\u2591" * remaining)



# ============================================================
# V12 — PREMIUM LOCKED-DASHBOARD HELPERS
# ============================================================
# Dynamic progress display + engagement messages + social proof. These power
# the {percentage}, {dots}, {motivation}, and {unlock_count} placeholders.
# ============================================================
def _dashboard_percentage(completed: int, required: int) -> int:
    """Percentage complete (0-100). 0 when required <= 0 (treated as unlocked)."""
    if required <= 0:
        return 100
    pct = int(round((completed / required) * 100))
    return max(0, min(100, pct))



def _build_dot_progress(completed: int, required: int, width: int = 5) -> str:
    """Build a compact dot progress indicator: ● ● ● ○ ○.

    Caps at `width` dots so it stays mobile-friendly even for large required
    counts. Each dot represents ~required/width referrals.
    """
    if required <= 0:
        filled = width
    else:
        filled = min(width, int(round((completed / required) * width)))
    filled = max(0, filled)
    return " ".join(["\u25CF"] * filled + ["\u25CB"] * (width - filled))



def _dashboard_motivation(completed: int, required: int) -> str:
    """Dynamic engagement message based on progress percentage.

    0%      → 🚀 Start inviting friends!
    1-24%   → 💪 Great start!
    25-49%  → 💪 Great start!
    50-74%  → 🔥 Halfway there!
    75-89%  → ⚡ Almost unlocked!
    90-99%  → 🎉 Just one more friend!
    100%    → (empty — the unlock flow takes over)
    """
    if required <= 0 or completed >= required:
        return ""  # Unlocked — the unlock flow handles messaging.
    pct = _dashboard_percentage(completed, required)
    if pct == 0:
        return "\U0001F680 Start inviting friends!"
    elif pct < 50:
        return "\U0001F4AA Great start!"
    elif pct < 75:
        return "\U0001F525 Halfway there!"
    elif pct < 90:
        return "\u26A1 Almost unlocked!"
    else:
        return "\U0001F389 Just one more friend!"



async def _fetch_unlock_count(campaign_id: Optional[int]) -> int:
    """BOTV13 fix (PART 7): Fetch the number of UNIQUE USERS who CLICKED/OPENED
    the payload link — not the number who unlocked. This is the social-proof
    metric shown on the referral dashboard.

    Counts DISTINCT user_id from access_events WHERE event_type='ref_link_open'
    AND campaign_id = ?. This counts every unique user who opened a referral
    link, regardless of whether they completed the referral requirement or
    unlocked the content.

    Returns 0 if the count is unavailable or campaign_id is None. The renderer
    hides the social-proof line entirely when this is 0.
    """
    if not campaign_id:
        return 0
    try:
        cur = await db.conn.execute(
            "SELECT COUNT(DISTINCT user_id) AS c FROM access_events "
            "WHERE event_type = 'ref_link_open' AND campaign_id = ?",
            (int(campaign_id),),
        )
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    except Exception as e:  # noqa: BLE001
        logger.debug("Dashboard: click count fetch failed: %s", e)
        return 0



async def render_referral_dashboard(campaign: aiosqlite.Row, unlock_record: Optional[aiosqlite.Row],
                                     user: Optional[User], bot_token_username: str = "",
                                     campaign_id_override: Optional[int] = None,
                                     settings_override: Optional[Dict[str, str]] = None,
                                     has_preview: bool = False,
                                     watch_ads_context: Optional[Dict[str, Any]] = None
                                     ) -> Dict[str, Any]:
    """V13: THE centralized referral dashboard renderer (single source of truth).

    Renders the single `dashboard_template` (with placeholders) into a premium
    locked-screen layout. Used by:
      - dashboard_send (locked dashboard delivery)
      - dashboard_update (Check Progress refresh / Unlock edit)
      - Dashboard Editor live preview (via settings_override — no DB writes)

    V13 change: preview media is NO LONGER auto-sent. The dashboard is always a
    text/caption message. A "Watch Preview" button is added to the keyboard
    when `has_preview=True` so the user can request preview media on demand.

    WATCH_AD (v25): when `watch_ads_context` is supplied (real-user renders
    only — the Dashboard Editor preview passes None), a [🎬 Watch Ad] button
    is inserted as the FIRST button row, BEFORE Watch Preview / Invite
    Friends / Refresh / How It Works, exactly per the dynamic button rules:
        🎬 Watch Ad        (if watch_ads_enabled)
        🎬 Watch Preview   (if preview exists)
        📤 Invite Friends  (if referral enabled)
        🔄 Refresh  ℹ️ How It Works
    The Watch Ad button opens the Watch Ads Mini App directly (web_app button
    with a per-user secure session URL) when the global Watch Ads
    configuration is ready; otherwise it falls back to the `wad:<pid>`
    callback which reports temporary unavailability. ONLY the buttons whose
    requirements are satisfied are shown.

    Supported placeholders (replaced at render time):
      {payload_name} {current} {required} {remaining}
      {progress_bar} {referral_link} {user_name} {first_name}
      V12 dynamic: {percentage} {dots} {motivation} {unlock_count}

    Referral link visibility: when link_preview_enabled == "0", the
    {referral_link} placeholder is replaced with an empty string so the link
    line is hidden — but the Invite Friends button always carries it via the
    Telegram share URL.

    Social proof: {unlock_count} is the number of UNIQUE USERS who CLICKED /
    OPENED the referral link for this campaign (COUNT(DISTINCT user_id) WHERE
    event_type='ref_link_open' AND campaign_id=current). It is NOT the number
    who unlocked, NOT qualified referrals, NOT campaign completions. The same
    user clicking 5 times counts as 1. Lines containing {unlock_count} are
    DROPPED entirely when the count is 0 (never show "0 people clicked").
    """
    campaign_id = campaign_id_override or (campaign["id"] if campaign else 0)
    required = int(campaign["required_referrals"]) if campaign else 5
    completed = int(unlock_record["completed_referrals"]) if unlock_record else 0
    # BOTV13 Part 2: cap completed at required for display. After unlock,
    # completed_referrals is no longer incremented (see qualify_referral_atomic),
    # but existing data from before this fix may have 6/5, 7/5. Cap ensures
    # the dashboard always shows 5/5 after unlock, never 6/5.
    if required > 0 and completed > required:
        completed = required
    remaining = max(0, required - completed)
    # Load dashboard settings, OR use the supplied draft (editor live preview).
    if settings_override is not None:
        settings = dict(settings_override)
        # Editor preview: use the draft's template if present, else the default.
        if not settings.get("dashboard_template"):
            settings["dashboard_template"] = db.DASHBOARD_DEFAULTS["dashboard_template"]
        settings.setdefault("progress_bar_style", "block")
        settings.setdefault("preview_caption_enabled", "1")
        settings.setdefault("link_preview_enabled", "0")
        # Preview: use a placeholder link (no DB token creation).
        ref_link = f"https://t.me/{BOT_USERNAME or 'Bot'}?start=ref_preview"
        template = settings["dashboard_template"]
        # Mock dynamic values for the editor preview (2/5 → 40%).
        unlock_count = 3  # non-zero so the social-proof line shows in preview
    else:
        settings = await db.get_all_dashboard_settings(campaign_id)
        # V11: load the template via the migration-aware helper (composes from
        # legacy fields on first read if no template exists yet).
        template = await db.get_dashboard_template(campaign_id)
        settings["dashboard_template"] = template
        # Build the referral token + link for this user.
        # Build the referral token + link for this user.
        user_id = user.id if user else 0
        ref_link = ""
        if user_id and user_id > 0:
            token = await db.get_or_create_referral_token(campaign_id, user_id)
            ref_link = build_referral_link(token)
            logger.info("Referral trace [render_referral_dashboard]: token created for inviter_user_id=%s (campaign=%s)", user_id, campaign_id)
        else:
            logger.warning("Referral trace [render_referral_dashboard]: SKIP token creation — user_id=%s is invalid (campaign=%s)", user_id, campaign_id)
            ref_link = f"https://t.me/{BOT_USERNAME or 'Bot'}?start=ref_preview"
        # V12: fetch real unlock count for social proof (0 → line hidden).
        unlock_count = await _fetch_unlock_count(campaign_id)

    # Build progress display (bar + dots + percentage).
    bar_style = settings.get("progress_bar_style", "block")
    progress_bar = _build_progress_bar_styled(completed, required, bar_style)
    dots = _build_dot_progress(completed, required, width=5)
    percentage = _dashboard_percentage(completed, required)
    motivation = _dashboard_motivation(completed, required)
    # Referral link visibility: hide in text when link_preview is OFF.
    link_preview_on = settings.get("link_preview_enabled", "0") == "1"
    ref_link_display = ref_link if link_preview_on else ""
    # Placeholder values (V11 base + V12 dynamic).
    # BOTV13: {payload_name} priority chain:
    #   1. Stored display_name (the editable human-readable title)
    #   2. Payload slug (Title-Cased) — fallback for legacy rows
    #   3. File name (stem)
    #   4. Campaign payload_code (Title-Cased)
    #   5. "Exclusive Content"
    dashboard_title = ""

    payload_id_val = campaign["payload_id"] if campaign else None
    p_row = None

    if payload_id_val:
        p_row = await db.get_payload_by_id(int(payload_id_val))

    # Priority 1: Stored display_name (BOTV13 — the editable title).
    if p_row:
        stored_dn = _safe_row_get(p_row, "display_name")
        if stored_dn:
            dashboard_title = stored_dn.strip()

    # Priority 2: Payload slug (Title-Cased) — fallback for legacy rows.
    if not dashboard_title and p_row and _safe_row_get(p_row, "payload"):
        dashboard_title = get_payload_display_name(p_row["payload"])

    # Priority 3: File name
    if not dashboard_title and p_row and _safe_row_get(p_row, "index_id"):
        f_row = await db.get_indexed_file_by_id(int(p_row["index_id"]))
        if f_row and _safe_row_get(f_row, "file_name"):
            dashboard_title = get_payload_display_name("", file_name=f_row["file_name"])

    # Priority 4: Campaign payload code
    if not dashboard_title:
        raw_pcode = campaign["payload_code"] if campaign else ""
        dashboard_title = (
            get_payload_display_name(raw_pcode)
            if raw_pcode else
            "Exclusive Content"
        )
    placeholders = {
        "payload_name": dashboard_title,
        "current": str(completed),
        "required": str(required),
        "remaining": str(remaining),
        "progress_bar": progress_bar,
        "referral_link": ref_link_display,
        "user_name": f"@{user.username}" if user and user.username else "",
        "first_name": user.first_name if user and user.first_name else "",
        # V12 dynamic placeholders.
        "percentage": str(percentage),
        "dots": dots,
        "motivation": motivation,
        "unlock_count": str(unlock_count) if unlock_count > 0 else "",
    }

    # Social proof: drop any line referencing {unlock_count} when count is 0
    # (never display "0 people unlocked"). This is done line-by-line BEFORE
    # placeholder substitution so the rest of the template renders normally.
    lines = template.split("\n")
    if unlock_count <= 0:
        lines = [ln for ln in lines if "{unlock_count}" not in ln]
    text = "\n".join(lines)

    # Replace placeholders in the template (single pass).
    for k, v in placeholders.items():
        text = text.replace("{" + k + "}", v)

    # Clean up: remove lines that became empty after {motivation}/{referral_link}
    # substitution (e.g. empty motivation at 100%, or hidden referral link).
    # Keep lines that were intentionally blank in the template (spacing).
    cleaned_lines = []
    prev_blank = False
    for ln in text.split("\n"):
        is_blank = ln.strip() == ""
        if is_blank and prev_blank:
            continue  # collapse 2+ consecutive blanks into 1
        # Drop a line that is ONLY a label now stripped of its value (heuristic:
        # a line ending in a colon with no content after substitution). We keep
        # this conservative — only drop lines that became completely empty AND
        # were not originally blank.
        if not is_blank and ln.strip() == "":
            continue
        cleaned_lines.append(ln)
        prev_blank = is_blank
    text = "\n".join(cleaned_lines).strip()
    # Final collapse of any 3+ blank lines.
    while "\n\n\n" in text:
        text = text.replace("\n\n\n", "\n\n")

    # Build share URL for Invite Friends. V14: premium share text. The button
    # carries the referral link via the Telegram share URL — the dashboard text
    # NEVER prints the raw URL (no {referral_link} in the default template).
    share_text = (
        "\U0001F525 I'm unlocking exclusive premium content.\n\n"
        "Join using my invite link:\n"
        "Once enough friends join, I'll unlock the content.\n\n"
        "\U0001F447 Tap below to join."
    )
    from urllib.parse import quote as _urlquote
    share_url = f"https://t.me/share/url?url={_urlquote(ref_link, safe='')}&text={_urlquote(share_text, safe='')}"
    # V13: Premium keyboard — Watch Preview (only if media exists) + Invite
    # Friends (full-width) + Refresh + How It Works (2-column, mobile-friendly).
    # WATCH_AD (v25): [🎬 Watch Ad] is ALWAYS the FIRST button when the payload
    # has Watch Ads enabled (before Watch Preview / Invite Friends). It is a
    # web_app button (direct Mini App launch with the secure session URL) when
    # the global config is ready, else a `wad:<pid>` callback fallback.
    # WATCH_AD V2 (v26): the dashboard text gains an explicit OR hint when
    # Watch Ads is enabled — the user unlocks by completing EITHER the
    # referral goal OR the required ads (never "both required").
    rows: List[List[InlineKeyboardButton]] = []
    if watch_ads_context and watch_ads_context.get("enabled"):
        # BOTV13 PHASE 6 (§4): the ad-option wording is rendered by the SAME
        # single-source template (get_watch_ads_unlock_template ->
        # render_watch_ads_unlock_message) the standalone WA screen uses —
        # no second hard-coded Watch Ads message.
        _wad_line = "\u2022 \U0001F3AC Watch the ad below"
        try:
            _tpl = await get_watch_ads_unlock_template()
            _minutes = await _watch_ads_unlock_minutes()
            _wad_line = ("\u2022 " + render_watch_ads_unlock_message(
                _tpl, minutes=_minutes,
                ads_required=int(watch_ads_context.get("required_ads") or 1),
                completed_ads=int(watch_ads_context.get("completed_ads") or 0),
            )).replace("\n", "\n  ")
        except Exception:  # noqa: BLE001 — wording must never break the dashboard
            pass
        text += (
            "\n\n\U0001F513 Unlock options (either one unlocks):\n"
            f"\u2022 Invite {remaining} more friend{'s' if remaining != 1 else ''}, OR\n"
            f"{_wad_line}"
        )
        _launch = watch_ads_context.get("launch_url")
        _wad_pid = watch_ads_context.get("payload_id") or campaign_id
        # V5 (§34): the combined Referral + Watch Ads dashboard render —
        # [🎬 Watch Ad] is the FIRST button (spec §18 order: Watch Ad,
        # Watch Preview, Invite Friends, Refresh, How It Works).
        logger.info(
            "WATCH_AD_DASHBOARD_RENDER user_id=%s campaign_id=%s "
            "payload_id=%s kind=referral_combined_locked "
            "watch_ad_button=first launch=%s",
            (user.id if user else 0), campaign_id, _wad_pid,
            "web_app" if (_launch and str(_launch).startswith("https://"))
            else "callback")
        if _launch and _launch.startswith("https://"):
            rows.append([InlineKeyboardButton("\U0001F3AC Watch Ad",
                                              web_app=WebAppInfo(url=_launch))])
        else:
            rows.append([InlineKeyboardButton("\U0001F3AC Watch Ad",
                                              callback_data=f"wad:{_wad_pid}")])
    if has_preview:
        rows.append([InlineKeyboardButton("\U0001F3AC Watch Preview",
                                          callback_data=f"refwatch:{campaign_id}")])
    rows.append([InlineKeyboardButton("\U0001F4E8 Invite Friends", url=share_url)])
    rows.append([InlineKeyboardButton("\U0001F504 Refresh", callback_data=f"refcheck:{campaign_id}"),
                 InlineKeyboardButton("\u2139\uFE0F How It Works", callback_data=f"refhow:{campaign_id}")])
    kb = InlineKeyboardMarkup(rows)
    return {
        "text": text,
        "keyboard": kb,
        "share_url": share_url,
        "ref_link": ref_link,
        "settings": settings,
    }



async def dashboard_send(bot, chat_id: int, user_id: int, campaign,
                         unlock_record, *, has_preview: bool = False,
                         disable_web_page_preview: bool = True) -> Optional[Message]:
    """V14: THE single dashboard sender. Sends the dashboard banner (optional)
    then the dashboard TEXT message, and persists (chat_id, message_id, mode)
    for later mode-aware edits.

    V14: optional Dashboard Media banner — a decorative media message sent
    BEFORE the dashboard text. Completely separate from Preview Media. The
    banner stays visible; Watch Preview opens separate preview content.

    V13: preview media is NO LONGER auto-sent with the dashboard. The dashboard
    is always a standalone text message (mode=TEXT). Preview media is sent
    on-demand via the Watch Preview button.

    The `has_preview` flag controls whether the Watch Preview button appears on
    the dashboard keyboard.

    Returns the dashboard Message (the one carrying the keyboard) or None.
    """
    class _MiniUser:
        def __init__(self, uid):
            self.id = uid
            self.username = None
            self.first_name = None
    # WATCH_AD (v25): resolve the payload-level Watch Ads requirement so the
    # [🎬 Watch Ad] button is rendered FIRST when enabled (single renderer).
    _watch_ads_ctx = None
    if campaign is not None and user_id:
        _watch_ads_ctx = await _resolve_watch_ads_dashboard_context(campaign, user_id)
    rendered = await render_referral_dashboard(campaign, unlock_record, _MiniUser(user_id),
                                                has_preview=has_preview,
                                                watch_ads_context=_watch_ads_ctx)
    dashboard_text = rendered["text"]
    kb = rendered["keyboard"]
    pid = campaign["payload_id"] if campaign else None
    campaign_id = campaign["id"] if campaign and "id" in campaign.keys() else None
    # NETWORK POINTS (v29, spec §51): the referral dashboard gains the
    # Points OR-alternative row when point access is enabled and the user
    # is still locked (unlocked users never see a spend button — the
    # dashboard_send caller only renders for locked users, but guard
    # anyway). The ptunlock: callback performs the ATOMIC debit.
    try:
        if pid is not None and unlock_record is not None \
                and not _safe_row_get(unlock_record, "unlocked") \
                and await _point_access_active():
            _pcost = await _point_cost()
            _pbal = await db.points_balance(int(user_id))
            _pt_row = [InlineKeyboardButton(
                f"\u2B50 Unlock with {_pcost} Point"
                f"{'s' if _pcost != 1 else ''} ({_pbal} available)",
                callback_data=f"{NET_PT_UNLOCK_CB}{int(pid)}")]
            if kb is not None and getattr(kb, "inline_keyboard", None):
                kb.inline_keyboard.insert(0, _pt_row)
            else:
                kb = InlineKeyboardMarkup([_pt_row])
            dashboard_text += (
                f"\n\u2B50 OR unlock instantly with {_pcost} point"
                f"{'s' if _pcost != 1 else ''} (you have {_pbal}).")
    except Exception:  # noqa: BLE001 — points must never break the dashboard
        logger.debug("points dashboard row skipped", exc_info=True)

    # V14/BOTV13: Dashboard Media support. When a banner is configured AND the
    # dashboard text fits within the 1024-char caption limit, the dashboard is
    # sent AS THE MEDIA'S CAPTION (CAPTION mode) — one message, editable via
    # edit_message_caption. When no banner or the text is too long, the dashboard
    # is sent as a standalone TEXT message (TEXT mode) and the banner (if any)
    # is a separate decorative message above it.
    banner_file_id = None
    banner_type = None
    dashboard_caption_mode = False
    if campaign_id:
        try:
            settings = await db.get_all_dashboard_settings(campaign_id)
            banner_file_id = settings.get("dashboard_media_file_id") or None
            banner_type = settings.get("dashboard_media_type") or None
            # BOTV13: caption mode when banner exists + text fits 1024 chars.
            if banner_file_id and banner_type and len(dashboard_text) <= 1024:
                dashboard_caption_mode = True
        except Exception:  # noqa: BLE001
            logger.debug("Dashboard V14: banner settings load failed.", exc_info=True)

    if banner_file_id and banner_type and not dashboard_caption_mode:
        # BOTV13: TEXT mode with a separate decorative banner above. Delete the
        # previous banner (if any) before sending a new one, preventing banner
        # accumulation when a user opens the dashboard multiple times.
        prev_banner = _dashboard_banner_msgs.get((pid, user_id)) if pid is not None else None
        if prev_banner:
            try:
                await _delete_message_safe(bot, prev_banner[0], prev_banner[1])
            except Exception:  # noqa: BLE001
                logger.debug("Dashboard V14: prev banner delete failed.", exc_info=True)
            _dashboard_banner_msgs.pop((pid, user_id), None)
        try:
            banner_msg = await send_bot_media(bot, chat_id, banner_type, banner_file_id)
            if banner_msg and banner_msg.message_id and pid is not None:
                _dashboard_banner_msgs[(pid, user_id)] = (chat_id, banner_msg.message_id)
            logger.info("Dashboard V14: banner sent (type=%s) for user %s.", banner_type, user_id)
        except Exception:  # noqa: BLE001
            logger.warning("Dashboard V14: banner send failed — continuing to dashboard text.")
    elif dashboard_caption_mode:
        # BOTV13: CAPTION mode — send the dashboard as the media's caption.
        # One message, editable via edit_message_caption. The banner IS the
        # dashboard controller (no separate decorative message).
        logger.info("Dashboard V14: CAPTION mode (text=%d chars, type=%s) for user %s.",
                    len(dashboard_text), banner_type, user_id)

    # Send the dashboard message.
    msg: Optional[Message] = None
    try:
        if dashboard_caption_mode and banner_file_id and banner_type:
            # CAPTION mode: send media with the dashboard text as caption + kb.
            try:
                msg = await send_bot_media(bot, chat_id, banner_type, banner_file_id,
                                           caption=dashboard_text, reply_markup=kb)
            except Exception:  # noqa: BLE001
                logger.warning("Dashboard V14: CAPTION send failed — falling back to TEXT mode.")
                msg = None
            if msg is None:
                # Fallback to TEXT mode (no banner).
                dashboard_caption_mode = False
                msg = await safe_send_text(bot, chat_id, dashboard_text, reply_markup=kb,
                                           disable_web_page_preview=disable_web_page_preview)
        else:
            # TEXT mode (no banner, or banner is separate decorative message).
            msg = await safe_send_text(bot, chat_id, dashboard_text, reply_markup=kb,
                                       disable_web_page_preview=disable_web_page_preview)
    except Exception:  # noqa: BLE001
        logger.exception("Dashboard V14: text send failed for user %s.", user_id)
        return None
    if msg and pid is not None:
        mode = DASHBOARD_MODE_CAPTION if dashboard_caption_mode else DASHBOARD_MODE_TEXT
        await db.save_dashboard_msg(pid, user_id, chat_id, msg.message_id, mode)
        # BOT6 P17: log the initial render state so CREATE + UPDATE are both
        # visible in the runtime log. This is the CREATE event.
        import hashlib as _hashlib
        _text_hash = _hashlib.md5(dashboard_text.encode("utf-8")).hexdigest()[:8] if dashboard_text else "-"
        _kb_rows = len(kb.inline_keyboard) if kb else 0
        logger.info(
            "BOT6_DASHBOARD_RENDER_STATE action=CREATE payload_id=%s campaign_id=%s "
            "message_id=%s mode=%s web_preview=%s text_hash=%s keyboard_rows=%s render_version=v14",
            pid, campaign_id, msg.message_id, mode, disable_web_page_preview, _text_hash, _kb_rows,
        )
        logger.info("Dashboard V14: sent as %s (msg=%s, has_preview=%s, banner=%s) for user %s.",
                    mode, msg.message_id, has_preview, bool(banner_file_id), user_id)
    return msg



async def dashboard_update(bot, campaign, user_id: int, *,
                            text: Optional[str] = None,
                            keyboard: Optional[InlineKeyboardMarkup] = None,
                            disable_web_page_preview: bool = True) -> bool:
    """V13: THE single dashboard updater — MODE-AWARE edit.

    Reads dashboard_mode from the stored record and calls the correct API:
      - CAPTION → bot.edit_message_caption (the dashboard lives on a media msg)
      - TEXT    → bot.edit_message_text    (the dashboard is a text msg)

    V13: when re-rendering the dashboard (no explicit text/keyboard supplied),
    the Watch Preview button is included if the campaign has preview media.

    Never calls editMessageText on a media message.
    Never calls editMessageCaption on a text message.
    Returns True if the edit succeeded, False otherwise.
    """
    if not campaign:
        return False
    pid = campaign["payload_id"] if "payload_id" in campaign.keys() else None
    if pid is None:
        return False
    saved = await db.get_dashboard_msg(int(pid), user_id)
    if not saved:
        logger.debug("Dashboard V13: update — no stored dashboard for payload %s user %s.", pid, user_id)
        return False
    dash_chat, dash_msg, mode = saved
    # Render the production dashboard if the caller didn't supply text/keyboard.
    if text is None or keyboard is None:
        rec = await db.get_or_create_unlock_record(
            int(pid), campaign["id"] if "id" in campaign.keys() else None,
            user_id, int(campaign["required_referrals"]) if "required_referrals" in campaign.keys() else 0)
        # V13: determine has_preview so the Watch Preview button is preserved
        # across refreshes / unlock edits.
        resolved = await _resolve_campaign_preview(campaign)
        has_preview = bool(resolved["mode"] != PREVIEW_MODE_DISABLED
                           and resolved["file_id"] and resolved["media_type"])
        # ROOT CAUSE FIX: Pass a valid user object instead of None
        class _MiniUser:
            def __init__(self, uid):
                self.id = uid
                self.username = None
                self.first_name = None

        logger.info("Referral trace [dashboard_update]: rendering dashboard for user_id=%s (campaign=%s)",
                    user_id, campaign["id"] if "id" in campaign.keys() else None)
        # WATCH_AD (v25): resolve the payload-level Watch Ads requirement so
        # the [🎬 Watch Ad] button is preserved FIRST across refreshes.
        _watch_ads_ctx = await _resolve_watch_ads_dashboard_context(campaign, user_id)
        rendered = await render_referral_dashboard(campaign, rec, _MiniUser(user_id),
                                                    has_preview=has_preview,
                                                    watch_ads_context=_watch_ads_ctx)
        if text is None:
            text = rendered["text"]
        if keyboard is None:
            keyboard = rendered["keyboard"]
    try:
        # BOT6 P12/P17: log the render state so refresh stability is verifiable.
        # The persisted mode (TEXT/CAPTION) + message_id + disable_web_page_preview
        # must remain STABLE across refreshes. Only the text/keyboard content changes.
        import hashlib as _hashlib
        _text_hash = _hashlib.md5(text.encode("utf-8")).hexdigest()[:8] if text else "-"
        _kb_rows = len(keyboard.inline_keyboard) if keyboard else 0
        logger.info(
            "BOT6_DASHBOARD_RENDER_STATE action=UPDATE payload_id=%s campaign_id=%s "
            "message_id=%s mode=%s web_preview=%s text_hash=%s keyboard_rows=%s "
            "render_version=v14",
            pid, campaign["id"] if "id" in campaign.keys() else None,
            dash_msg, mode, disable_web_page_preview, _text_hash, _kb_rows,
        )
        if mode == DASHBOARD_MODE_CAPTION:
            # Media message — edit the CAPTION (and parse mode/keyboard).
            await bot.edit_message_caption(
                chat_id=dash_chat, message_id=dash_msg,
                caption=text, reply_markup=keyboard)
        else:
            # Text message — edit the text.
            await bot.edit_message_text(
                chat_id=dash_chat, message_id=dash_msg,
                text=text, reply_markup=keyboard,
                disable_web_page_preview=disable_web_page_preview)
        logger.info("Dashboard V13: updated (mode=%s msg=%s) for user %s.",
                    mode, dash_msg, user_id)
        return True
    except TelegramError as e:
        msg_str = str(e)
        # "message not modified" is benign (content unchanged) — not an error.
        if "not modified" in msg_str.lower():
            return True
        # BOTV13 fix: if edit_message_text fails with "no text in the message"
        # the dashboard was actually sent as a media+caption message but the
        # stored mode is TEXT (legacy/stale). Retry with edit_message_caption.
        if "no text in the message" in msg_str.lower() and mode != DASHBOARD_MODE_CAPTION:
            try:
                await bot.edit_message_caption(
                    chat_id=dash_chat, message_id=dash_msg,
                    caption=text, reply_markup=keyboard)
                # Fix the stored mode so future edits use the correct API.
                await db.save_dashboard_msg(int(pid), user_id, dash_chat, dash_msg,
                                            DASHBOARD_MODE_CAPTION)
                logger.info("Dashboard V13: mode auto-corrected TEXT→CAPTION (msg=%s) for user %s.",
                            dash_msg, user_id)
                return True
            except TelegramError as e2:
                logger.warning("Dashboard V13: caption retry also failed (msg=%s): %s", dash_msg, e2)
                return False
        logger.warning("Dashboard V13: update failed (mode=%s msg=%s): %s", mode, dash_msg, e)
        return False
    except Exception:  # noqa: BLE001
        logger.exception("Dashboard V13: update error (mode=%s msg=%s) for user %s.",
                         mode, dash_msg, user_id)
        return False



async def dashboard_delete(bot, campaign, user_id: int) -> bool:
    """V9: Delete the stored dashboard message (best-effort). Clears the stored
    metadata afterwards so no stale edits are attempted.

    BOTV13: also deletes the decorative banner message (if any) tracked in
    _dashboard_banner_msgs, so no banner is left orphaned when the dashboard
    is removed."""
    if not campaign:
        return False
    pid = campaign["payload_id"] if "payload_id" in campaign.keys() else None
    if pid is None:
        return False
    saved = await db.get_dashboard_msg(int(pid), user_id)
    if not saved:
        # Even if there's no stored dashboard text, there may be a banner.
        prev_banner = _dashboard_banner_msgs.pop((int(pid), user_id), None)
        if prev_banner:
            try:
                await _delete_message_safe(bot, prev_banner[0], prev_banner[1])
            except Exception:  # noqa: BLE001
                pass
        return False
    dash_chat, dash_msg, _mode = saved
    try:
        await bot.delete_message(chat_id=dash_chat, message_id=dash_msg)
        logger.info("Dashboard V9: deleted msg %s for user %s.", dash_msg, user_id)
    except TelegramError as e:
        logger.debug("Dashboard V9: delete failed (msg=%s): %s", dash_msg, e)
    # BOTV13: also clean up the banner.
    prev_banner = _dashboard_banner_msgs.pop((int(pid), user_id), None)
    if prev_banner:
        try:
            await _delete_message_safe(bot, prev_banner[0], prev_banner[1])
        except Exception:  # noqa: BLE001
            pass
    await db.clear_dashboard_msg(int(pid), user_id)
    return True



async def show_referral_preview_screen(bot, chat_id: int, user_id: int,
                                        payload_code: str, campaign: aiosqlite.Row,
                                        unlock_record: aiosqlite.Row) -> None:
    """V13: Entry point that renders the referral dashboard via the Controller.

    V13 change: preview media is NO LONGER auto-sent. Only the locked referral
    dashboard is shown (text message). The dashboard keyboard includes a
    "Watch Preview" button when preview media is available — the user requests
    it on demand via the refwatch: callback. This creates curiosity, saves
    bandwidth, and feels more premium.

    The preview is still RESOLVED here (self-healing auto-preview persists the
    resolved file_id to the campaign row) so the Watch Preview button can serve
    it instantly without re-resolving.

    v26 fix / V5.1 note: campaign can be None only via legacy/defense paths —
    the Access Engine now falls back to the BASE policy (authorized,
    reason=referral_inactive) when a FORCE_JOIN_REFERRAL payload has no
    active campaign and Watch Ads is off, so this fallback should NOT be
    reachable from the normal engine flow anymore. It stays as
    defense-in-depth: the user still gets a safe generic message instead of
    a crash.
    """
    if campaign is None:
        logger.warning(
            "Referral dashboard requested without an active campaign "
            "(payload_code=%s user=%s) — showing safe fallback.",
            payload_code, user_id)
        await safe_send_text(bot, chat_id,
            "\u274C This content is not available right now.")
        return
    # Analytics.
    await db.log_access_event("preview_view",
                              payload_id=campaign["payload_id"],
                              campaign_id=campaign["id"], user_id=user_id)

    # V5: Resolve the effective preview via the centralized RUNTIME resolver.
    # Self-heals Auto Preview: if the campaign's stored file_id is missing, the
    # resolver re-detects compatible media and persists it back. This resolution
    # happens here (not at Watch Preview time) so the button is instant.
    resolved = await _resolve_campaign_preview(campaign)
    preview_mode = resolved["mode"]
    preview_media_file_id = resolved["file_id"]
    preview_media_type = resolved["media_type"]
    has_preview = bool(preview_mode != PREVIEW_MODE_DISABLED
                       and preview_media_file_id and preview_media_type)
    logger.info("Dashboard V13: entry (preview_mode=%s source=%s has_preview=%s) for user %s",
                preview_mode, resolved["source"], has_preview, user_id)

    # Load dashboard settings (link preview toggle).
    settings = await db.get_all_dashboard_settings(campaign["id"])
    link_preview = settings.get("link_preview_enabled", "0") == "1"
    disable_preview = not link_preview

    # Hand off to the SINGLE dashboard sender. V13: always a text dashboard.
    # The Watch Preview button is added by the renderer when has_preview=True.
    await dashboard_send(
        bot, chat_id, user_id, campaign, unlock_record,
        has_preview=has_preview,
        disable_web_page_preview=disable_preview,
    )



async def _delete_preview_after_delay(bot, chat_id: int, msg_id: int, delay: int) -> None:
    """Delete a preview message after a configured delay. Dashboard remains."""
    try:
        await asyncio.sleep(delay)
        try:
            await bot.delete_message(chat_id=chat_id, message_id=msg_id)
            logger.info("Preview: auto-deleted message %s after %ds", msg_id, delay)
        except TelegramError as e:
            logger.warning("Preview: auto-delete failed for msg %s: %s", msg_id, e)
    except asyncio.CancelledError:
        pass


async def send_watch_preview(bot, chat_id: int, user_id: int, campaign) -> bool:
    """V14: Send preview media on-demand (Watch Preview button).
    Sends media with the text attached as a caption."""
    if not campaign:
        return False
    try:
        resolved = await _resolve_campaign_preview(campaign)
        file_id = resolved.get("file_id")
        media_type = resolved.get("media_type")
        if not file_id or not media_type:
            return False
            
        preview_description = _safe_row_get(campaign, "preview_description")
        
        # Attach the description directly to the media as a caption
        msg = await send_bot_media(bot, chat_id, media_type, file_id,
                                   caption=preview_description or None)
                                   
        # Schedule Auto-Delete for the single message.
        # BOTV13: explicit payload -> global -> 20s fallback (matches BOTV10's
        # documented Watch Preview timer priority). Watch Preview ALWAYS
        # auto-deletes (the 20s ultimate fallback) so protected preview media
        # is never left visible indefinitely.
        if msg and msg.message_id:
            try:
                # BOT5 FIX: use ONLY the global preview timer.
                delay = await resolve_preview_timer()
                if delay and delay > 0:
                    asyncio.create_task(schedule_auto_delete(
                        bot, chat_id, [msg.message_id], delay))
                    logger.info(
                        "BOT6_PREVIEW_RUNTIME source=global_preview preview_timer=%s "
                        "payload_id=%s user_id=%s (Watch Preview scheduled)",
                        delay, campaign["payload_id"], user_id,
                    )
                else:
                    logger.info(
                        "BOT6_PREVIEW_RUNTIME source=global_preview preview_timer=%s "
                        "payload_id=%s user_id=%s (NOT scheduled — timer=0)",
                        delay, campaign["payload_id"], user_id,
                    )
            except Exception:  # noqa: BLE001
                logger.warning("Watch Preview V14: auto-delete schedule failed.", exc_info=True)
                
        # Analytics
        await db.log_access_event("preview_view",
                                  payload_id=campaign["payload_id"],
                                  campaign_id=campaign["id"], user_id=user_id)
        logger.info("Watch Preview V14: sent attached media+text to user %s.", user_id)
        return True
    except Exception:  # noqa: BLE001
        logger.exception("Watch Preview V14: failed for user %s.", user_id)
        return False


async def handle_referral_start(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                 token: str, user: User) -> None:
    """Access Engine V1: handle a referral link open (ref_<token>).

    BOTV13 Fix:
      - `ref_link_open` analytics is logged AFTER the payload/campaign checks
        pass (was logged unconditionally before, causing duplicate rows on
        repeated /start ref_<token> clicks).
      - `qualify_referral` is wrapped in try/except so a transient DB error
        (e.g. nested-txn) never prevents `attempt_delivery` from running —
        the user still gets their content.
      - `attempt_delivery` is always wrapped in try/except so a delivery
        failure never crashes the referral flow.
    """
    token_row = await db.lookup_referral_token(token)
    if not token_row:
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u274C Invalid or expired referral link.")
        return

    campaign_id = token_row["campaign_id"]
    inviter_user_id = token_row["inviter_user_id"]
    logger.info("Referral trace [handle_referral_start]: token looked up → campaign_id=%s inviter_user_id=%s referred_user_id=%s", campaign_id, inviter_user_id, user.id)
    if not inviter_user_id or inviter_user_id <= 0:
        logger.error("Referral trace [handle_referral_start]: ABORT — inviter_user_id=%s is invalid (stale 0-inviter token). campaign=%s referred=%s", inviter_user_id, campaign_id, user.id)
        await safe_send_text(context.bot, update.effective_chat.id, "\u274C This referral link is invalid. Please ask your friend for a new invite link.")
        return

    campaign = await db.get_referral_campaign_by_id(campaign_id)
    if not campaign or not _safe_row_get(campaign, "enabled"):
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u274C This referral campaign is no longer active.")
        return

    # Defensive payload_id extraction
    payload_id = _safe_row_get(campaign, "payload_id")
    if not payload_id:
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u274C This payload is no longer available.")
        return

    # Immutable ID lookup
    payload_row = await db.get_payload_by_id(int(payload_id))
    if not payload_row:
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u274C This payload is no longer available.")
        return

    # Verify the payload slug actually exists and isn't corrupted
    payload_slug = _safe_row_get(payload_row, "payload")
    if not payload_slug:
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u274C This payload is no longer available.")
        return

    # Analytics: Use the verified payload_row["id"] for absolute certainty.
    # BOTV13 Fix: logged AFTER all checks pass, so repeated clicks on a stale
    # token / disabled campaign no longer produce spurious ref_link_open rows.
    await db.log_access_event("ref_link_open",
                              payload_id=payload_row["id"],
                              campaign_id=campaign_id, user_id=user.id)

    # Qualify referral using campaign_id (immutable). BOTV13 Fix: wrapped in
    # try/except so a transient DB error never blocks the user's delivery.
    if user.id != inviter_user_id:
        try:
            await qualify_referral(context.bot, campaign_id, inviter_user_id, user.id)
        except Exception as e:  # noqa: BLE001
            logger.warning("Referral: qualify_referral failed (campaign=%s inviter=%s referred=%s): %s — proceeding to delivery.",
                           campaign_id, inviter_user_id, user.id, e)

    # Deliver via current live payload slug. BOTV13 Fix: wrapped in try/except
    # so a delivery failure never crashes the referral flow. On failure, log
    # FULL diagnostic context (payload, user, FJ mode, schema version, column
    # existence) so operators can find the root cause, but show the user a
    # generic message that does NOT expose database internals.
    try:
        await attempt_delivery(update, context, payload_slug, user)
    except Exception as e:  # noqa: BLE001
        logger.exception("Referral: attempt_delivery failed for payload %s user %s: %s",
                         payload_slug, user.id, e)
        # Diagnostic context for operators (NOT shown to the user).
        try:
            fj_mode_val = await get_fj_mode()
        except Exception:  # noqa: BLE001
            fj_mode_val = "?"
        try:
            cur_v = await db.conn.execute(
                "SELECT value FROM schema_meta WHERE key='version';")
            vrow = await cur_v.fetchone()
            schema_v = vrow["value"] if vrow else "?"
        except Exception:  # noqa: BLE001
            schema_v = "?"
        col_status = []
        for _t, _c, _ in db.CRITICAL_COLUMNS:
            try:
                ok = await db._column_exists(_t, _c)
            except Exception:  # noqa: BLE001
                ok = False
            col_status.append(f"{_t}.{_c}={'OK' if ok else 'MISSING'}")
        logger.error(
            "Delivery failure diagnostics — payload_slug=%s payload_id=%s "
            "user_id=%s campaign_id=%s inviter_user_id=%s fj_mode=%s "
            "schema_meta_version=%s DATABASE_FILE=%s columns=[%s] "
            "error_type=%s",
            payload_slug,
            _safe_row_get(payload_row, "id") if payload_row else None,
            user.id, campaign_id, inviter_user_id, fj_mode_val, schema_v,
            getattr(db, "db_path", "?"),
            " | ".join(col_status),
            type(e).__name__,
        )
        try:
            await safe_send_text(context.bot, update.effective_chat.id,
                "\u274C Could not deliver this payload right now. Please try the link again.")
        except Exception:  # noqa: BLE001
            pass
