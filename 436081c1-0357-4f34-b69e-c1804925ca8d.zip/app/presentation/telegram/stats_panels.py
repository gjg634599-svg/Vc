"""Statistics panels — stats, top downloads, index health.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



# ---------- STATISTICS PANEL ----------
async def stats_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    g = await db.global_view_stats()
    text = (
        "*\U0001F4CA Statistics*\n\n"
        f"\U0001F4C1 Files: {await db.count_indexed_files()}\n"
        f"\U0001F517 Payloads: {await db.count_payloads()}\n"
        f"\U0001F4C2 Storage channels: {len(await db.list_storage_channels())}\n"
        f"\U0001F465 Users: {await db.total_users()}\n\n"
        f"\U0001F4CA Clicks\n"
        f"  Total: {g['total']}\n"
        f"  Unique: {g['unique']}\n"
        f"  Today: {g['daily']}\n"
        f"  Week: {g['weekly']}\n"
        f"  Month: {g['monthly']}\n\n"
        f"\U0001F4E5 Downloads by type\n"
        f"  Payload: {await db.get_stat('payload_downloads', 0)}\n"
        f"  Message-ID: {await db.get_stat('msgid_downloads', 0)}\n"
        f"  Range: {await db.get_stat('range_downloads', 0)}\n\n"
        f"\U0001F4E3 Broadcasts: {await db.get_stat('broadcast_count', 0)}\n"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\U0001F3C6 Top Payloads", callback_data="panel:top"),
         InlineKeyboardButton("\U0001F4E5 Top Downloads", callback_data="panel:topdl")],
        [InlineKeyboardButton("\U0001F510 Access Analytics", callback_data="panel:access")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:main")],
    ])
    await safe_edit_text(update.callback_query,
        text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb
    )



async def access_global_analytics_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Access Engine V1: global analytics across all referral campaigns."""
    active = await db.count_active_referral_campaigns()
    total_views = await db.access_event_count("campaign_view")
    total_opens = await db.access_event_count("payload_open")
    total_preview = await db.access_event_count("preview_view")
    total_ref_opens = await db.access_event_count("ref_link_open")
    total_qualified = await db.access_event_count("qualified_referral")
    total_unlocks = await db.access_event_count("unlock")
    top_camps = await db.top_campaigns(limit=10)
    text = (
        "*\U0001F510 Access Analytics*\n\n"
        f"Active referral campaigns: {active}\n\n"
        f"\U0001F441 Campaign views: {total_views}\n"
        f"\U0001F4C4 Payload opens: {total_opens}\n"
        f"\U0001F5BC Preview views: {total_preview}\n"
        f"\U0001F517 Referral link opens: {total_ref_opens}\n"
        f"\u2705 Qualified referrals: {total_qualified}\n"
        f"\U0001F513 Unlocks: {total_unlocks}\n"
    )
    if top_camps:
        text += "\n*Top Campaigns (by qualified referrals):*\n"
        for i, c in enumerate(top_camps, 1):
            state = "\U0001F7E2" if c["enabled"] else "\U0001F534"
            code = c["payload_code"]
            text += (f"  {i}. {state} {md_code_span(code)} \u2014 "
                     f"{c['qualified_count']} qualified "
                     f"(req {c['required_referrals']})\n")
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:stats")],
    ])
    await safe_edit_text(update.callback_query, text,
                         parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



async def top_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    rows = await db.top_payloads(limit=10)
    lines = ["*Top Payloads*", ""]
    if not rows:
        lines.append("No data yet.")
    for i, r in enumerate(rows, 1):
        lines.append(f"{i}. {md_code_span(r['payload'])} - clicks={r['current_clicks']} views={r['views']}")
    kb = InlineKeyboardMarkup(
        [[InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:stats")]]
    )
    await safe_edit_text(update.callback_query, 
        "\n".join(lines), parse_mode=ParseMode.MARKDOWN, reply_markup=kb
    )



async def top_downloads_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    rows = await db.top_downloads(limit=10)
    lines = ["*Top Downloads*", ""]
    if not rows:
        lines.append("No data yet.")
    for i, r in enumerate(rows, 1):
        name = (r["file_name"] or f"file_{r['id']}")[:40]
        # §36 markdown escaping: the filename lives INSIDE a code span —
        # md_code_span keeps it unbreakable (a backtick in a file name can
        # never close the span) WITHOUT the visible "\_" escape artifacts
        # escape_md would add inside the span.
        lines.append(f"{i}. {media_emoji(r['media_type'])} {md_code_span(name)} - dl={r['downloads']} views={r['views']}")
    kb = InlineKeyboardMarkup(
        [[InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:stats")]]
    )
    await safe_edit_text(update.callback_query, 
        "\n".join(lines), parse_mode=ParseMode.MARKDOWN, reply_markup=kb
    )



async def index_health_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Issue #76: Index Health Dashboard.

    Shows per-channel: total indexed, last scan, integrity status.
    """
    channels = await db.list_storage_channels()
    lines = ["*\U0001F4CA Index Health*", ""]
    if not channels:
        lines.append("No storage channels configured.")
    buttons: List[List[InlineKeyboardButton]] = []
    for ch in channels:
        cid = ch["channel_id"]
        title = ch['title'] or f"Channel {cid}"
        indexed = await db.count_indexed_files_for_channel(cid)
        last_scan = ch["last_scan"] or "Never"
        # Quick integrity estimate: compare indexed count vs max message_id.
        max_msg = await db.max_message_id_for_channel(cid)
        state = await db.get_reindex_state(cid)
        cursor = state["last_scanned_message_id"] if state else None
        status = "\u2705 OK" if (cursor and max_msg and cursor >= (max_msg or 0)) else "\u26A0\uFE0F May need sync"
        lines.append(f"\u2022 {title}\n  Indexed: {indexed}  |  Last scan: {fmt_ts(last_scan)}  |  {status}")
        buttons.append([InlineKeyboardButton(
            f"\U0001F50D {title}",
            callback_data=f"idxhealthch:{cid}",
        )])
    buttons.append([InlineKeyboardButton("\U0001F504 Quick Sync All", callback_data="panel:reindex")])
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:storage")])
    await safe_edit_text(update.callback_query, "\n".join(lines),
                         parse_mode=ParseMode.MARKDOWN,
                         reply_markup=InlineKeyboardMarkup(buttons))
