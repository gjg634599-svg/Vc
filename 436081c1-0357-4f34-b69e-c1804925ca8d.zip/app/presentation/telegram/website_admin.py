"""Website admin — website control facades + mini app server.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



def _website_media_gateway():
    """Facade → app/services/container.py (application-level media
    composition — §8; no longer a hidden bot.py implementation)."""
    return _app_container.website_media_gateway(_LEGACY_NS)



async def _website_network_bot_tokens() -> List[Dict[str, Any]]:
    """Facade → app/services/container.py (§8 website composition)."""
    return await _app_container.website_network_bot_tokens(_LEGACY_NS)



def _website_deps_factory():
    """Facade → app/services/container.py (§8 website composition)."""
    return _app_container.website_deps_factory(_LEGACY_NS)



def _wsite_deps():
    """Facade → app/services/container.py (§8 website admin composition)."""
    return _app_container.website_admin_deps(_LEGACY_NS)



async def _handle_wsite_panel(update, context):
    """Facade → app/presentation/telegram/website_ui.py (Website Control panel)."""
    from app.presentation.telegram.website_ui import website_panel
    try:
        await website_panel(update, context, _wsite_deps())
    except Exception as e:  # noqa: BLE001 — panels must never crash the bot
        logger.error("WEBSITE panel render failed: %s", e, exc_info=True)
        await safe_answer_callback(update.callback_query,
                                   "Website panel failed to render.")



async def _handle_wsite_callback(update, context):
    """Facade → app/presentation/telegram/website_ui.py (wsite:* dispatch)."""
    from app.presentation.telegram.website_ui import handle_wsite_callback
    try:
        await handle_wsite_callback(update, context, _wsite_deps())
    except Exception as e:  # noqa: BLE001 — never crash on_callback
        logger.error("WEBSITE callback failed: %s", e, exc_info=True)
        await safe_answer_callback(update.callback_query,
                                   "Website action failed.")



async def _handle_wsite_media(update, context, info):
    """Facade → app/presentation/telegram/website_ui.py (wizard thumbnail capture /
    per-listing thumbnail replacement). Returns True when consumed."""
    from app.presentation.telegram.website_ui import website_wizard_media
    try:
        return await website_wizard_media(update, context, _wsite_deps(),
                                          info)
    except Exception as e:  # noqa: BLE001
        logger.error("WEBSITE media input failed: %s", e, exc_info=True)
        return False



async def _handle_wsite_text(update, context, user, text):
    """Facade → app/presentation/telegram/website_ui.py (wizard link input + field
    editors). Returns True when consumed. Admin-gated: non-admins never
    have the states set, but this is enforced again here."""
    if not await is_admin(user.id):
        return False
    from app.presentation.telegram.website_ui import website_wizard_text
    try:
        return await website_wizard_text(update, context, _wsite_deps(),
                                         text)
    except Exception as e:  # noqa: BLE001
        logger.error("WEBSITE text input failed: %s", e, exc_info=True)
        return False


async def _handle_wsitecat_callback(update, context):
    """Facade → app/presentation/telegram/website_gap_ui.py (wsitecat:*
    dispatch — the Website CATEGORY admin panels, GAP-CLOSURE §26-§29)."""
    from app.presentation.telegram.website_gap_ui import (
        handle_wsitecat_callback)
    try:
        await handle_wsitecat_callback(update, context, _wsite_deps())
    except Exception as e:  # noqa: BLE001 — never crash on_callback
        logger.error("WEBSITE CATEGORY callback failed: %s", e,
                     exc_info=True)
        await safe_answer_callback(update.callback_query,
                                   "Categories action failed.")


async def _handle_wsad_callback(update, context):
    """Facade → app/presentation/telegram/website_gap_ui.py (wsad:*
    dispatch — the centralized ADS PLATFORM admin panels, GAP-CLOSURE
    §35-§56)."""
    from app.presentation.telegram.website_gap_ui import handle_wsad_callback
    try:
        await handle_wsad_callback(update, context, _wsite_deps())
    except Exception as e:  # noqa: BLE001 — never crash on_callback
        logger.error("ADS PLATFORM callback failed: %s", e, exc_info=True)
        await safe_answer_callback(update.callback_query,
                                   "Ads action failed.")


async def _handle_wspr_callback(update, context):
    """Facade → app/presentation/telegram/website_preroll_ui.py (wspr:*
    dispatch — the VIDEO PRE-ROLL ADS admin panel, Task 9). The wspr:
    prefix was verified collision-free (no other handler dispatches it)
    and is admin-gated by the master admin gate like wsite:."""
    from app.presentation.telegram.website_preroll_ui import (
        handle_wspr_callback)
    try:
        await handle_wspr_callback(update, context, _wsite_deps())
    except Exception as e:  # noqa: BLE001 — never crash on_callback
        logger.error("PREROLL callback failed: %s", e, exc_info=True)
        await safe_answer_callback(update.callback_query,
                                   "Pre-roll action failed.")


async def _handle_wsmain_callback(update, context):
    """Facade → app/presentation/telegram/website_ui.py (wsmain:*
    dispatch — BOT-11 spec §2-§5: the MAIN MINI APP admin panel: the
    canonical URL + Change URL + truthful Apply-to-All + Refresh). The
    wsmain: prefix was verified collision-free and is admin-gated by
    the master admin gate like wsite:."""
    from app.presentation.telegram.website_ui import handle_wsmain_callback
    try:
        await handle_wsmain_callback(update, context, _wsite_deps())
    except Exception as e:  # noqa: BLE001 — never crash on_callback
        logger.error("MAIN MINI APP callback failed: %s", e, exc_info=True)
        await safe_answer_callback(update.callback_query,
                                   "Main Mini App action failed.")


async def _handle_wspr_text(update, context, user, text):
    """Facade → app/presentation/telegram/website_preroll_ui.py (pre-roll
    URL text inputs). Returns True when consumed. Admin-gated exactly
    like _handle_wsite_text."""
    if not await is_admin(user.id):
        return False
    from app.presentation.telegram.website_preroll_ui import (
        website_preroll_text)
    try:
        return await website_preroll_text(update, context, _wsite_deps(),
                                          text)
    except Exception as e:  # noqa: BLE001
        logger.error("PREROLL text input failed: %s", e, exc_info=True)
        return False


async def _handle_gap_text(update, context, user, text):
    """Facade → app/presentation/telegram/website_gap_ui.py (category +
    ads wizard/editor text inputs). Returns True when consumed.
    Admin-gated exactly like _handle_wsite_text."""
    if not await is_admin(user.id):
        return False
    from app.presentation.telegram.website_gap_ui import website_gap_text
    try:
        return await website_gap_text(update, context, _wsite_deps(), text)
    except Exception as e:  # noqa: BLE001
        logger.error("GAP PANEL text input failed: %s", e, exc_info=True)
        return False



async def start_mini_app_server(bot) -> bool:
    """Facade → app/web/server.py (server lifecycle ownership)."""
    return await _web_server.start_mini_app_server(bot, _LEGACY_NS)



async def stop_mini_app_server() -> None:
    """Facade → app/web/server.py (server lifecycle ownership)."""
    await _web_server.stop_mini_app_server(_LEGACY_NS)
