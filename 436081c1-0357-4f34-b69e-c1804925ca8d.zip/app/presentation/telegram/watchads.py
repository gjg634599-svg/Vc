"""Watch Ads — ad sessions, unlock screens, admin panels.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations

# ============================================================
# WATCH_AD (v25) — USER FLOW, SESSIONS & ACCESS UI
# ============================================================
# Watch Ads user flow (payload opened -> delivery):
#   Payload opened
#     -> existing payload resolution (start_command routing, unchanged)
#     -> Access Engine (Force Join -> base policy -> referral -> WATCH_AD)
#     -> denied reason="watch_ad_required"
#     -> show_watch_ad_access_screen  (standalone: referral OFF/completed)
#        or referral dashboard with [🎬 Watch Ad] FIRST (referral pending)
#     -> [🎬 Watch Ad] (web_app button w/ secure per-session URL, or the
#        wad:<pid> callback which creates the session then surfaces the
#        launch button)
#     -> Mini App GET /watch-ad/<token> (same Python process, aiohttp)
#     -> Telegram initData identity verified (HMAC-SHA256, official model)
#     -> Monetag SDK rewarded ad plays (admin-supplied SDK tag, ymid=token)
#     -> Monetag S2S postback (ymid=token, reward_event_type=valued)
#     -> process_watch_ad_reward (transactional, idempotent, replay-safe)
#     -> unlock window opens (unlock_expires_at)
#     -> user is notified in Telegram with the payload deep link
#     -> user re-opens the payload link -> Access Engine re-evaluates
#     -> authorized -> EXISTING delivery pipeline (one-time/delete-after
#        behavior executes exactly as before).
#
# The protected payload is NEVER delivered from the Watch Ad callback path.
# ============================================================

# Postback-related key names accepted from the Monetag SSP configuration
# (both short and canonical macro names are accepted, e.g. `event` or
# `event_type`, `value` or `reward_event_type`).


# ============================================================
# BOTV13 PHASE 6 (§2-§4): WATCH ADS UNLOCK MESSAGE TEMPLATE
# ============================================================
# Single source of truth:
#   get_watch_ads_unlock_template()  -> the stored template (or the default)
#   render_watch_ads_unlock_message() -> safe placeholder rendering
#
# The renderer is used wherever the Watch Ads requirement is presented to
# users (the standalone WA access screen and the combined referral+WA
# dashboard). The template ONLY changes presentation:
#   * the server stays authoritative,
#   * timer text can never grant access,
#   * only a verified S2S reward advances a session.
#
# Supported placeholders (unknown ones render literally — never crash):
#   {minutes} {ads_required} {completed_ads} {remaining_ads} {payload}
# ============================================================


# Placeholders the renderer understands. Anything else renders literally.


        # payload flag above still gates, and reward verification stays
        # server-authoritative in every path.


def _serving_network_bot_id(bot) -> Optional[int]:
    """V26 (Network Bot Watch Ads): the network_bot_id of the bot client
    currently rendering an access screen — resolved through the live
    BotWorkerManager (telegram-id lookup first, username fallback — the
    same guarded resolution app/network/lifecycle._worker_manager_nid_lookup
    uses; a PTB Bot raises RuntimeError before initialize(), so every
    access is guarded). None = the main bot / a test double.

    Used to stamp the Watch-Ad session's launch context so the
    VERIFIED-reward notification + auto-resume route through the bot the
    user is actually talking to."""
    manager = _net_workers
    if manager is None or bot is None:
        return None
    try:
        bid = getattr(bot, "id", None)
    except Exception:  # noqa: BLE001 — uninitialized PTB client
        bid = None
    if bid:
        try:
            w = manager.get_by_telegram_id(int(bid))
        except Exception:  # noqa: BLE001
            w = None
        if w is not None:
            return int(w.network_bot_id)
    try:
        uname = (getattr(bot, "username", "") or "").lstrip("@")
    except Exception:  # noqa: BLE001 — uninitialized PTB client
        uname = ""
    if uname:
        try:
            w = manager.get_by_username(uname)
        except Exception:  # noqa: BLE001
            w = None
        if w is not None:
            return int(w.network_bot_id)
    return None


async def _resolve_watch_ads_dashboard_context(campaign: Optional[aiosqlite.Row],
                                               user_id: int,
                                               network_bot_id: Optional[int] = None
                                               ) -> Optional[Dict[str, Any]]:
    """Resolve the Watch Ads keyboard context for the referral dashboard.

    Used ONLY by real-user renders of the dashboard (dashboard_send /
    dashboard_update). The Dashboard Editor preview never calls this — its
    renderer path passes watch_ads_context=None so no DB session is created.

    Returns None when the campaign's payload has Watch Ads disabled — the
    dashboard then renders EXACTLY as before (zero change). V4 (v27): also
    returns None when the GLOBAL master switch is OFF (no [🎬 Watch Ad]
    button on the referral dashboard while Watch Ads is disabled platform-
    wide — the referral requirement renders alone, exactly like pre-v25).
    """
    if campaign is None:
        return None
    pid = _safe_row_get(campaign, "payload_id")
    if not pid:
        return None
    payload_row = await db.get_payload_by_id(int(pid))
    if not await _watch_ads_gate_active(payload_row):
        return None
    ctx: Dict[str, Any] = {"enabled": True, "payload_id": int(pid)}
    if user_id and int(user_id) > 0:
        ctx["launch_url"] = await build_watch_ad_session_url(
            int(user_id), payload_row, network_bot_id=network_bot_id)
    else:
        ctx["launch_url"] = None
    # BOTV13 PHASE 6 (§4): server-authoritative ad progress for the template
    # render (the same single-source wording as the standalone WA screen).
    # get_or_create reuses the live pending session — no duplicate sessions.
    ctx["required_ads"] = 1
    ctx["completed_ads"] = 0
    if user_id and int(user_id) > 0:
        try:
            _sess, _ = await db.get_or_create_watch_ad_session(int(user_id), int(pid))
            if _sess:
                ctx["required_ads"] = max(1, int(_safe_row_get(_sess, "required_ads") or 1))
                ctx["completed_ads"] = max(0, int(_safe_row_get(_sess, "completed_ads") or 0))
        except Exception:  # noqa: BLE001 — progress display must never break the dashboard
            pass
    return ctx



async def show_watch_ad_access_screen(bot, chat_id: int, user: Optional[User],
                                      res: AccessResult, *,
                                      link_arg: Optional[str] = None,
                                      edit_message_id: Optional[int] = None) -> None:
    """WATCH_AD standalone access screen (referral OFF or referral completed).

    Renders EXACTLY the spec'd standalone layout:

        🔒 Access Required

        Watch a short ad to unlock this payload.

        [🎬 Watch Ad]

    When the global Watch Ads configuration is missing (no Mini App URL / no
    Monetag SDK) or a session cannot be created, NO broken link is generated:
    the user sees "⚠️ Watch Ads is temporarily unavailable. Please try again
    later." and the [🎬 Watch Ad] button falls back to the wad:<pid> callback
    (which repeats the same safe message). Configuration details are NEVER
    exposed to normal users.
    """
    if res is None or not res.payload_id:
        await safe_send_text(bot, chat_id,
            "\u274C This content is not available right now.")
        return
    payload_row = await db.get_payload_by_id(int(res.payload_id))
    if not payload_row:
        await safe_send_text(bot, chat_id,
            "\u274C This content is not available right now.")
        return
    title = get_payload_display_name(
        payload_row["payload"],
        display_name=_safe_row_get(payload_row, "display_name"))
    launch_url: Optional[str] = None
    unavailable = False
    session_required_ads = 1
    session_completed_ads = 0
    if user and user.id and not await is_admin(user.id):
        # V26 (Network Bot Watch Ads): resolve the serving bot's network
        # context so the session's launch context is stamped for reward
        # routing (None = the main bot — pre-V26 behavior preserved).
        launch_url = await build_watch_ad_session_url(
            user.id, payload_row,
            network_bot_id=_serving_network_bot_id(bot))
        if not launch_url:
            unavailable = True
            # build_watch_ad_session_url() logged the exact structured cause
            # (WATCH_AD_CONFIG_MISSING / WATCH_AD_URL_INVALID /
            # WATCH_AD_CREATE_SESSION_FAILED) with user+payload context.
            logger.info(
                "Watch Ads unavailable screen shown user_id=%s payload_id=%s "
                "— see the WATCH_AD_* diagnostic above for the real cause.",
                user.id, int(res.payload_id))
        else:
            # Reflect the LIVE session's ad requirement in the wording (the
            # count is server-side truth — a reused session keeps its own
            # progress, a new session uses the current Ads Control mode).
            _sess, _created = await db.get_or_create_watch_ad_session(
                user.id, int(payload_row["id"]))
            if _sess:
                session_required_ads = max(1, int(_safe_row_get(_sess, "required_ads") or 1))
                session_completed_ads = max(0, int(_safe_row_get(_sess, "completed_ads") or 0))
    # BOTV13 PHASE 6 (§4): the unlock wording comes from the SINGLE template
    # source (get_watch_ads_unlock_template -> render_watch_ads_unlock_message).
    # Presentation only — the server stays authoritative and only a verified
    # S2S reward advances the session. The hard-coded line below is only a
    # last-resort fallback if the template path ever fails.
    ad_line = (f"Watch {session_required_ads} ad"
               f"{'s' if session_required_ads != 1 else ''} to unlock this payload.")
    try:
        _tpl = await get_watch_ads_unlock_template()
        _minutes = await _watch_ads_unlock_minutes()
        ad_line = render_watch_ads_unlock_message(
            _tpl, minutes=_minutes,
            ads_required=session_required_ads,
            completed_ads=session_completed_ads,
            payload=title)
    except Exception:  # noqa: BLE001 — the template can never break the screen
        pass
    if session_required_ads > 1 or session_completed_ads > 0:
        ad_line += (f"\n\n\u2705 Rewards verified: "
                    f"{session_completed_ads}/{session_required_ads}")
    # V5.2 (bot.log 18 @ 03:33:24, payload 773 "#nataliastar"): a
    # FORCE_JOIN_REFERRAL payload whose campaign is missing/disabled used to
    # render a BARE two-button card ("Access Required" + [Watch Ad] +
    # [Refresh]) — the user-visible screenshot showed exactly that and read
    # as "the combined dashboard never reached me". The WA access screen now
    # carries the FULL combined keyboard shape (single dashboard standard):
    #   1. [🎬 Watch Ad]      — always first
    #   2. [🎬 Watch Preview] — when the payload's campaign has preview media
    #   3. [📤 Invite Friends]— ONLY when the campaign is ACTIVE (a disabled
    #                           campaign can never credit invites — showing
    #                           the button would be a false promise)
    #   4. [🔄 Refresh] [ℹ️ How It Works] — always (wadhow: WA explainer)
    # For payloads with an ACTIVE campaign the /start entry path renders the
    # stored referral dashboard (referral_combined_locked) — this screen is
    # the fallback/wad: path, and now it is consistent with it.
    campaign = None
    if res.payload_id:
        campaign = await db.get_referral_campaign_by_payload(int(res.payload_id))
    campaign_active = bool(campaign and _safe_row_get(campaign, "enabled"))
    has_preview = False
    if campaign:
        try:
            resolved_prev = await _resolve_campaign_preview(campaign)
            has_preview = bool(
                resolved_prev["mode"] != PREVIEW_MODE_DISABLED
                and resolved_prev["file_id"] and resolved_prev["media_type"])
        except Exception:  # noqa: BLE001
            has_preview = False
    if campaign_active and campaign is not None:
        try:
            _rem = max(0, int(campaign["required_referrals"] or 0))
            ad_line += (f"\n\n\U0001F4E4 Invite {_rem} more friend"
                        f"{'s' if _rem != 1 else ''} also unlocks this payload"
                        "\n— either option works.")
        except Exception:  # noqa: BLE001
            pass
    # V5 (§34): the Watch-Ads-ONLY access screen render (no referral UI —
    # spec §19: no Invite Friends / referral progress / referral goal) —
    # kept when there is genuinely NO referral option; the combined shape
    # above applies whenever a referral option exists.
    logger.info(
        "WATCH_AD_DASHBOARD_RENDER user_id=%s payload_id=%s "
        "kind=%s required_ads=%s completed_ads=%s campaign_id=%s "
        "campaign_active=%s has_preview=%s launch=%s",
        (user.id if user else 0), int(res.payload_id),
        ("watch_ads_with_referral" if campaign_active else "watch_ads_only"),
        session_required_ads,
        session_completed_ads,
        (int(campaign["id"]) if campaign is not None else 0),
        (1 if campaign_active else 0), (1 if has_preview else 0),
        "web_app" if launch_url else "callback")
    text = (
        "\U0001F512 Access Required\n\n"
        f"{title}\n\n"
        f"{ad_line}"
    )
    if unavailable:
        text += "\n\n\u26A0\uFE0F Watch Ads is temporarily unavailable.\nPlease try again later."
    # NETWORK POINTS (v29, spec §51): the Points OR-alternative line. Point
    # access enabled → the user can unlock by EITHER watching ads OR
    # spending points (earned via bot registration). Balance shown for
    # transparency; the ptunlock: callback re-runs the Access Engine and
    # performs the ATOMIC debit (never a blind spend).
    points_button: Optional[InlineKeyboardButton] = None
    if res.points_eligible and res.payload_id:
        try:
            _pbal = res.points_balance if res.point_cost else \
                await db.points_balance(int(user.id if user else 0))
            _pcost = res.point_cost or await _point_cost()
            text += (f"\n\n\u2B50 OR unlock instantly with {_pcost} point"
                     f"{'s' if _pcost != 1 else ''} "
                     f"(you have {_pbal}).\nRegister bots to earn +5 each.")
            points_button = InlineKeyboardButton(
                f"\u2B50 Unlock with {_pcost} Point"
                f"{'s' if _pcost != 1 else ''}",
                callback_data=f"{NET_PT_UNLOCK_CB}{int(res.payload_id)}")
        except Exception:  # noqa: BLE001 — points must never break the screen
            points_button = None
    kb_rows: List[List[InlineKeyboardButton]] = []
    if launch_url:
        kb_rows.append([InlineKeyboardButton("\U0001F3AC Watch Ad",
                                             web_app=WebAppInfo(url=launch_url))])
    else:
        kb_rows.append([InlineKeyboardButton("\U0001F3AC Watch Ad",
                                             callback_data=f"wad:{res.payload_id}")])
    if points_button is not None:
        kb_rows.append([points_button])
    if has_preview and campaign is not None:
        kb_rows.append([InlineKeyboardButton(
            "\U0001F3AC Watch Preview",
            callback_data=f"refwatch:{int(campaign['id'])}")])
    if campaign_active and campaign is not None and user and user.id:
        # Same share mechanics as render_referral_dashboard (single standard)
        # — but ONLY for an ACTIVE campaign (honest: invites credit only
        # while the campaign is enabled).
        try:
            _tok = await db.get_or_create_referral_token(
                int(campaign["id"]), user.id)
            _ref_link = build_referral_link(_tok)
            from urllib.parse import quote as _urlquote
            _share_text = ("\U0001F525 I'm unlocking exclusive premium "
                           "content.\n\nJoin using my invite link:")
            _share_url = (
                "https://t.me/share/url?url="
                f"{_urlquote(_ref_link, safe='')}"
                f"&text={_urlquote(_share_text, safe='')}")
            kb_rows.append([InlineKeyboardButton("\U0001F4E8 Invite Friends",
                                                 url=_share_url)])
        except Exception:  # noqa: BLE001
            pass
    # Refresh re-runs the full delivery path (Access Engine re-evaluates the
    # rewarded unlock — one tap after completing the ad).
    # V26 (callback_data safety): a NAMED payload slug can be 64 chars —
    # 'wadcheck:' + slug exceeds Telegram's 64-byte callback_data limit
    # (Button_data_invalid kills the WHOLE access screen). Structurally
    # short link forms pass through; a named slug becomes the compact
    # reversible 'i<payload_id>' (the wadcheck handler resolves it back).
    check_arg = link_arg or res.payload_code or payload_row["payload"]
    try:
        if check_arg and not (str(check_arg)[:1] in ("m", "c", "r")
                              and len(str(check_arg)) <= 16):
            _cand = await db.get_payload(str(check_arg)) \
                if hasattr(db, "get_payload") else None
            if _cand is not None:
                check_arg = f"i{int(_cand['id'])}"
    except Exception:  # noqa: BLE001 — fall back to the raw arg
        pass
    kb_rows.append([InlineKeyboardButton("\U0001F504 Refresh",
                                         callback_data=f"wadcheck:{check_arg}"),
                    InlineKeyboardButton("\u2139\uFE0F How It Works",
                                         callback_data=f"wadhow:{res.payload_id}")])
    kb = InlineKeyboardMarkup(kb_rows)
    if edit_message_id:
        try:
            await bot.edit_message_text(chat_id=chat_id, message_id=edit_message_id,
                                        text=text, reply_markup=kb)
            return
        except TelegramError:
            pass  # fall through to a fresh send
    await safe_send_text(bot, chat_id, text, reply_markup=kb)



# NOTE (v26): _edit_dashboard_to_watch_ad_step() was REMOVED. It implemented
# the v25 AND semantics ("referral goal reached -> Watch Ad STILL required"),
# which V2 explicitly replaces with REFERRAL OR WATCH ADS: when the referral
# goal is reached the payload is authorized immediately and
# auto_deliver_unlocked_payload() edits the dashboard to the standard
# unlocked/ready screen via the Dashboard Controller (single renderer).


async def handle_watch_ad(update: Update, context: ContextTypes.DEFAULT_TYPE,
                          payload_id: int) -> None:
    """WATCH_AD button handler (callback `wad:<payload_id>`).

    Follows the 12-step contract:
      1. Validate Telegram user.          7. Verify Watch Ads is enabled.
      2. Resolve payload.                 8. Reuse an existing valid session.
      3. Verify payload exists.           9. Otherwise create a secure session.
      4. Verify payload is active.       10. Generate the Mini App URL.
      5. Check existing admin bypass.    11. Launch the Mini App (web_app button).
      6. Check existing Force Join.      12. NEVER directly deliver the payload.
    """
    q = update.callback_query
    user = q.from_user if q else None
    if not q or not user:
        return
    # 1-4: resolve + validate the payload.
    try:
        pid = int(payload_id)
    except (TypeError, ValueError):
        await safe_answer_callback(q, "Invalid request.", show_alert=True)
        return
    payload_row = await db.get_payload_by_id(pid)
    if not payload_row:
        await safe_answer_callback(q, "Payload not found.", show_alert=True)
        return
    if payload_row["status"] != "active":
        await safe_answer_callback(q, "This payload is no longer available.",
                                   show_alert=True)
        return
    # 5: existing admin bypass (admins never see Watch Ads — access_engine
    # exempts them before the gate; mirror that here with a helpful note).
    if await is_admin(user.id):
        await safe_answer_callback(
            q, "Admins bypass Watch Ads. Open the payload link to receive the file.",
            show_alert=True)
        return
    # 6: existing Force Join check (FJ is a prerequisite — never bypassed).
    # b11 §2: the MAIN bot performs the membership check when the Watch Ad
    # request arrived through a NETWORK worker.
    # V26.2 (bot-41 §16-§24): the prerequisite is THIS payload's pinned
    # batch (the same per-gate view the Access Engine used to reach the
    # watch-ad step) — the legacy full-requirement view would wrongly
    # block a user who completed the payload's current batch while later
    # batches remain pending (progressive batching).
    if await force_join_active():
        not_joined = await fj_gate_unjoined(
            user.id, f"b|p|{int(pid)}", payload_id=pid,
            bot=_fj_verifier_bot(context.bot))
        if not_joined:
            await safe_answer_callback(q, "Please join the required channels first.",
                                       show_alert=True)
            await send_force_join_page(context.bot, q.message.chat_id, user.id,
                                       payload_row["payload"],
                                       gate_channels=list(not_joined))
            return
    # 7: Watch Ads must be enabled for this payload (V4 v27: AND globally ON).
    if not _safe_row_get(payload_row, "watch_ads_enabled"):
        await safe_answer_callback(q, "Watch Ads is not enabled for this payload.",
                                   show_alert=True)
        return
    if not await db.get_watch_ads_global_enabled():
        logger.info("WATCH_AD_CONFIG_MISSING user_id=%s payload_id=%s "
                    "reason=watch_ads_globally_disabled (wad: callback)",
                    user.id, pid)
        await safe_answer_callback(
            q, "Watch Ads is currently disabled.\nPlease use the normal access path.",
            show_alert=True)
        return
    # Unlock already valid? Re-run the full delivery path (Access Engine
    # re-evaluates — no direct delivery from this handler).
    ad_ok, _exp = await db.watch_ad_unlock_valid(user.id, pid)
    if ad_ok:
        await safe_answer_callback(q, "\u2705 Your ad reward is already verified — "
                                      "refreshing access.")
        await attempt_delivery(update, context, payload_row["payload"], user)
        return
    # 8-10: reuse/create the secure session + generate the Mini App URL.
    # V26 (Network Bot Watch Ads): stamp the launch context from the
    # serving worker (the wad: callback runs on whichever bot the user
    # pressed the button in — the worker context when this is a NETWORK
    # bot, None on the main bot).
    _launch_nid = _net_context_id(context) or _serving_network_bot_id(
        getattr(context, "bot", None))
    launch_url = await build_watch_ad_session_url(
        user.id, payload_row, network_bot_id=_launch_nid)
    if not launch_url:
        cfg = await get_watch_ads_global_config()
        if not cfg["url_ok"]:
            logger.warning("WATCH_AD_CONFIG_MISSING user_id=%s payload_id=%s "
                           "reason=mini_app_url_not_configured", user.id, pid)
        elif not cfg["sdk_ok"]:
            logger.warning("WATCH_AD_CONFIG_MISSING user_id=%s payload_id=%s "
                           "reason=monetag_sdk_not_configured", user.id, pid)
        else:
            logger.warning("WATCH_AD_SESSION_INVALID user_id=%s payload_id=%s "
                           "reason=launch_url_build_failed", user.id, pid)
        await safe_answer_callback(
            q, "\u26A0\uFE0F Watch Ads is temporarily unavailable.\nPlease try again later.",
            show_alert=True)
        return
    # 11: surface the launch. When the source message is the stored referral
    # dashboard, keep it (single controller edit with the web_app button as
    # the FIRST row); otherwise edit the pressed message into the ready
    # screen. 12: the payload itself is NEVER delivered here.
    session, _created = await db.get_or_create_watch_ad_session(user.id, pid)
    campaign = await db.get_referral_campaign_by_payload(pid)
    if campaign and campaign["enabled"]:
        saved = await db.get_dashboard_msg(pid, user.id)
        if saved:
            ctx = await _resolve_watch_ads_dashboard_context(
                campaign, user.id, network_bot_id=_launch_nid)
            rec = await db.get_or_create_unlock_record(
                pid, campaign["id"], user.id, int(campaign["required_referrals"]))
            class _MiniUser:
                def __init__(self, uid):
                    self.id = uid
                    self.username = None
                    self.first_name = None
            resolved_preview = await _resolve_campaign_preview(campaign)
            has_preview = bool(resolved_preview["mode"] != PREVIEW_MODE_DISABLED
                               and resolved_preview["file_id"]
                               and resolved_preview["media_type"])
            rendered = await render_referral_dashboard(
                campaign, rec, _MiniUser(user.id),
                has_preview=has_preview, watch_ads_context=ctx)
            ok = await dashboard_update(context.bot, campaign, user.id,
                                        text=rendered["text"],
                                        keyboard=rendered["keyboard"])
            if ok:
                await safe_answer_callback(q, "\U0001F3AC Tap Watch Ad below to start.")
                return
    await safe_answer_callback(q, "\U0001F3AC Watch Ad session ready.")
    await show_watch_ad_access_screen(
        context.bot, q.message.chat_id if q.message else user.id, user,
        AccessResult(payload_id=pid, payload_code=payload_row["payload"],
                     watch_ads_enabled=True, reason=WATCH_AD_REASON_REQUIRED),
        link_arg=payload_row["payload"],
        edit_message_id=q.message.message_id if q.message else None,
    )



# ============================================================
# WATCH_AD (v25) — ADMIN PANELS (payload-level + global settings)
# ============================================================
# Payload-level:  Payload Details / Access Policy → [🎬 Watch Ads]
#                 → watch_ads_payload_panel (Enable / Disable / analytics)
# Global config:  Settings → [🎬 Watch Ads Settings]
#                 → 🌐 Mini App Website (Add / Change / Delete)
#                 → 📜 Monetag SDK     (Add / Replace / Delete)
#                 → ⏱ Unlock Window presets
# All panels reuse the existing admin authorization (on_callback master
# gate + has_permission), callback conventions, navigation context and
# bot_settings persistence. NO separate admin panel is created.
# ============================================================


async def watch_ads_payload_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                  payload_id: int) -> None:
    """Per-payload Watch Ads configuration panel (Payload Details → Watch Ads)."""
    row = await db.get_payload_by_id(payload_id)
    if not row:
        await safe_answer_callback(update.callback_query, "Payload not found.",
                                   show_alert=True)
        await payload_list_panel(update, context)
        return
    enabled = bool(_safe_row_get(row, "watch_ads_enabled"))
    try:
        stats = await db.watch_ad_payload_stats(payload_id)
    except Exception:  # noqa: BLE001
        stats = {"sessions": 0, "ad_watch_started": 0, "ad_rewarded": 0,
                 "ad_unlock_granted": 0, "ad_unlock_expired": 0,
                 "ad_unlock_rejected": 0, "ad_reward_duplicate": 0}
    stored_display = row["display_name"] if "display_name" in row.keys() else None
    title = get_payload_display_name(row["payload"], display_name=stored_display)
    # V4 (v27): the per-payload ad-mode override (global default vs override).
    override = await db.get_payload_watch_ads_ad_mode_override(payload_id)
    global_mode = await db.get_watch_ads_ad_control()
    if override:
        mode_label = (WATCH_AD_AD_CONTROL_META.get(override,
                      WATCH_AD_AD_CONTROL_META[WATCH_AD_AD_CONTROL_SHORT])["label"]
                      + " (override)")
    else:
        mode_label = (WATCH_AD_AD_CONTROL_META.get(global_mode,
                      WATCH_AD_AD_CONTROL_META[WATCH_AD_AD_CONTROL_SHORT])["label"]
                      + " (global default)")
    text = (
        "\U0001F3AC Watch Ads\n\n"
        f"Payload: {title}\n"
        f"Status: {'Enabled' if enabled else 'Disabled'}\n"
        f"Ads Mode: {mode_label}\n\n"
        "\U0001F4CA Watch Ads Analytics (this payload)\n"
        f"  Ad sessions: {stats['sessions']}\n"
        f"  Ad watches started: {stats['ad_watch_started']}\n"
        f"  Ad rewards verified: {stats['ad_rewarded']}\n"
        f"  Unlocks granted: {stats['ad_unlock_granted']}\n"
        f"  Unlocks expired: {stats['ad_unlock_expired']}\n"
        f"  Rewards rejected: {stats['ad_unlock_rejected']}\n"
        f"  Duplicate rewards ignored: {stats['ad_reward_duplicate']}"
    )
    kb_rows: List[List[InlineKeyboardButton]] = [
        [InlineKeyboardButton("\u274C Disable" if enabled else "\u2705 Enable",
                              callback_data=f"plgwadt:{payload_id}"),
         InlineKeyboardButton("\U0001F39B Ads Mode", callback_data=f"plgwadm:{payload_id}")],
        [InlineKeyboardButton("\u2699\uFE0F Global Ad Settings",
                              callback_data="panel:wadsettings")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"pldetail:{payload_id}")],
    ]
    await safe_edit_text(update.callback_query, text,
                         reply_markup=InlineKeyboardMarkup(kb_rows))



async def watch_ads_payload_mode_panel(update: Update,
                                        context: ContextTypes.DEFAULT_TYPE,
                                        payload_id: int) -> None:
    """🎛 Per-payload Ads Mode override (V4 v27).

    The GLOBAL Ads Control is the DEFAULT; this payload may override it.
    'Follow global' (the default) keeps the payload on the global mode.
    Changes apply to NEWLY created ad sessions only (existing sessions keep
    their stamped mode/required_ads — server-authoritative stability).
    """
    row = await db.get_payload_by_id(payload_id)
    if not row:
        await safe_answer_callback(update.callback_query, "Payload not found.",
                                   show_alert=True)
        return
    stored_display = row["display_name"] if "display_name" in row.keys() else None
    title = get_payload_display_name(row["payload"], display_name=stored_display)
    override = await db.get_payload_watch_ads_ad_mode_override(payload_id)
    global_mode = await db.get_watch_ads_ad_control()
    global_label = WATCH_AD_AD_CONTROL_META.get(
        global_mode, WATCH_AD_AD_CONTROL_META[WATCH_AD_AD_CONTROL_SHORT])["label"]
    rows: List[List[InlineKeyboardButton]] = [
        [InlineKeyboardButton(
            ("" if override else "\u2713 ") + f"\U0001F30D Follow global ({global_label})",
            callback_data=f"plgwadmset:{payload_id}:global")],
    ]
    for mode in WATCH_AD_AD_CONTROL_MODES:
        m = WATCH_AD_AD_CONTROL_META[mode]
        mark = "\u2713 " if override == mode else ""
        rows.append([InlineKeyboardButton(f"{mark}{m['label']}",
                                          callback_data=f"plgwadmset:{payload_id}:{mode}")])
    rows.append([InlineKeyboardButton("\u2B05\uFE0F Back",
                                      callback_data=f"plgwad:{payload_id}")])
    await safe_edit_text(update.callback_query,
        f"\U0001F39B Ads Mode — {title}\n\n"
        f"Global default: {global_label}\n"
        f"This payload: {global_label + ' (global)' if not override else WATCH_AD_AD_CONTROL_META.get(override, WATCH_AD_AD_CONTROL_META[WATCH_AD_AD_CONTROL_SHORT])['label'] + ' (override)'}\n\n"
        "The mode shapes ONE Watch Ad session\n"
        "(one tap \u2192 sequential ads inside it).\n"
        "Applies to newly created sessions only.",
        reply_markup=InlineKeyboardMarkup(rows))



async def watch_ads_payload_mode_set(update: Update,
                                     context: ContextTypes.DEFAULT_TYPE,
                                     payload_id: int, mode: str) -> None:
    """Persist the per-payload ads-mode override (NULL = follow global)."""
    if not await db.get_payload_by_id(payload_id):
        await safe_answer_callback(update.callback_query, "Payload not found.",
                                   show_alert=True)
        return
    if mode == WATCH_AD_OVERRIDE_GLOBAL:
        value = None          # follow the global default
    elif mode in WATCH_AD_AD_CONTROL_MODES:
        value = mode
    else:
        await safe_answer_callback(update.callback_query, "Unknown ads mode.")
        await watch_ads_payload_mode_panel(update, context, payload_id)
        return
    await db.update_payload_field(payload_id, "watch_ads_ad_mode_override", value)
    admin_id = (update.callback_query.from_user.id if update.callback_query
                and update.callback_query.from_user else None)
    await log_admin_action(admin_id, "set_payload_watch_ads_mode",
                           "payload", payload_id,
                           f"mode={value or 'global'}")
    logger.info("Watch Ads ads-mode override for payload %s set to '%s' (admin=%s).",
                payload_id, value or "global", admin_id)
    label = ("global default" if value is None
             else WATCH_AD_AD_CONTROL_META[mode]["label"])
    await safe_answer_callback(
        update.callback_query, f"\u2705 Ads Mode set to {label}.")
    await watch_ads_payload_mode_panel(update, context, payload_id)



async def watch_ads_payload_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                   payload_id: int) -> None:
    """Toggle watch_ads_enabled OFF -> ON / ON -> OFF (persisted immediately).

    Never touches the access policy, referral campaigns, links, files, or
    delivery settings — Watch Ads stays a fully independent requirement.
    """
    row = await db.get_payload_by_id(payload_id)
    if not row:
        await safe_answer_callback(update.callback_query, "Payload not found.",
                                   show_alert=True)
        return
    new_val = 0 if _safe_row_get(row, "watch_ads_enabled") else 1
    await db.update_payload_field(payload_id, "watch_ads_enabled", new_val)
    await db.log_access_event(
        "watch_ads_enabled" if new_val else "watch_ads_disabled",
        payload_id=payload_id)
    await log_admin_action(
        (update.callback_query.from_user.id if update.callback_query and
         update.callback_query.from_user else None),
        "toggle_watch_ads", "payload", payload_id,
        f"watch_ads_enabled={new_val}")
    logger.info("Watch Ad %s for payload %s",
                "enabled" if new_val else "disabled", payload_id)
    await safe_answer_callback(
        update.callback_query,
        "\u2705 Watch Ads enabled for this payload." if new_val
        else "\u274C Watch Ads disabled for this payload.")
    await watch_ads_payload_panel(update, context, payload_id)



async def watch_ads_settings_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Global Watch Ads Settings (Settings → 🎬 Watch Ads Settings).

    V4 (v27) — the GLOBAL Watch Ads admin panel. Manages the global
    configuration values (all act as DEFAULTS; payloads may override the ad
    mode per payload, and per-payload watch_ads_enabled stays independent):
      🌐 Mini App Website — the public HTTPS base URL of the Mini App
      📜 Monetag SDK     — the official Monetag SDK / ad-tag code
      ⏱ Unlock Window    — default unlock validity duration
      ⏳ Session Timeout — default verification/session timeout
      🎛 Ads Control     — default ad mode (1 / 2 / 3 / random 1–3)
      🌍 Global ON/OFF   — platform-wide master switch
      📊 Status          — monitoring: sessions, postbacks, errors, rewards
    """
    cfg = await get_watch_ads_global_config()
    stats = await db.watch_ad_global_stats()
    url_line = (f"{cfg['mini_app_url']}  \u2705 Configured" if cfg["url_ok"]
                else "\u274C Not Configured")
    sdk_line = "\u2705 Configured" if cfg["sdk_ok"] else "\u274C Not Configured"
    # v36 §18A: the WEBSITE ad tag is a SEPARATE setting — status shown
    # independently and truthfully (never merged with the TMA SDK status).
    try:
        _wsdk_on, _wsdk_src = await _website_ad_tag_status()
    except Exception:  # noqa: BLE001 — status display never crashes
        _wsdk_on, _wsdk_src = False, None
    wsdk_line = ("\u2705 Configured" if _wsdk_on else "\u274C Not Configured")
    window = cfg["unlock_window"]
    window_label = f"{window}s" if window else "never"
    ad_control = cfg.get("ad_control") or WATCH_AD_AD_CONTROL_DEFAULT
    control_label = WATCH_AD_AD_CONTROL_META.get(
        ad_control, WATCH_AD_AD_CONTROL_META[WATCH_AD_AD_CONTROL_SHORT])["label"]
    ttl = int(cfg.get("session_ttl") or WATCH_AD_SESSION_TTL)
    ttl_label = f"{ttl // 60} min" if ttl % 60 == 0 and ttl >= 60 else f"{ttl}s"
    global_on = bool(cfg.get("enabled", True))
    global_state_line = "\u2705 ON" if global_on else "\u274C OFF"
    text = (
        "\U0001F3AC Watch Ads Settings\n\n"
        f"\U0001F30D Global: {global_state_line}\n"
        "  (master switch — payload toggles stay saved)\n\n"
        "\U0001F310 Mini App Website:\n"
        f"{url_line}\n\n"
        "\U0001F4DC Mini App Monetag SDK:\n"
        f"{sdk_line}\n\n"
        "\U0001F310 Website Monetag SDK (ad tag):\n"
        f"{wsdk_line}\n\n"
        f"\u23F1 Unlock Window: {window_label}\n"
        "  (how long a verified ad unlock stays valid)\n\n"
        f"\u23F3 Session Timeout: {ttl_label}\n"
        "  (how long an unverified ad session lives)\n\n"
        f"\U0001F39B Ads Control (default): {control_label}\n"
        "  (what happens inside ONE ad session — one\n"
        "  Watch Ad tap always opens one session;\n"
        "  payloads can override the mode individually)\n\n"
        f"\U0001F4CA Usage: {stats['payloads_enabled']} payload(s) enabled | "
        f"{stats['sessions']} ad session(s) | {stats['ad_rewarded']} reward(s) verified"
        "\n\n\U0001F916 Control split (docs.monetag.com):\n"
        "\U0001F916 Bot controls: required rewards\n"
        "  (1/2/3/random), session timeout,\n"
        "  unlock window, global ON/OFF,\n"
        "  per-payload mode override.\n"
        "\U0001F4FA Monetag controls: ad creative,\n"
        "  ACTUAL duration, availability,\n"
        "  frequency, reward callback timing.\n"
        "  The SDK exposes NO duration knob\n"
        "  ('timeout' = preload wait only) —\n"
        "  longer engagement = more ads\n"
        "  (Two/Three/Random). No fake timers:\n"
        "  only SERVER-VERIFIED rewards count."
    )
    # Admin-facing configuration hints (admins only see this panel).
    if not global_on:
        text += ("\n\n\u26A0\uFE0F Watch Ads is globally DISABLED — every payload"
                 " behaves as if Watch Ads is off.\nPayload toggles are preserved"
                 " and re-activate when it is turned back ON.")
    if not cfg["url_ok"]:
        text += "\n\n\u26A0\uFE0F Watch Ads Mini App URL is not configured."
    if not cfg["sdk_ok"]:
        text += "\n\n\u26A0\uFE0F Monetag SDK is not configured."
    if not _wsdk_on:
        text += ("\n\n\u2139\uFE0F Website Monetag SDK is not configured — "
                 "the Website works without it (no website ads shown).")
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\U0001F30D Global: ON" if global_on else "\U0001F30D Global: OFF",
                              callback_data="wadcfg:globaloff" if global_on else "wadcfg:globalon"),
         InlineKeyboardButton("\U0001F4CA Status", callback_data="wadcfg:status")],
        [InlineKeyboardButton("\U0001F310 Website", callback_data="wadcfg:web"),
         InlineKeyboardButton("\U0001F4DC Mini App SDK", callback_data="wadcfg:sdk")],
        [InlineKeyboardButton("\U0001F310 Website SDK", callback_data="wadcfg:wsdk"),
         InlineKeyboardButton("\u23F1 Unlock Window", callback_data="wadcfg:window")],
        [InlineKeyboardButton("\u23F3 Session Timeout", callback_data="wadcfg:ttl"),
         InlineKeyboardButton("\U0001F39B Ads Control", callback_data="wadcfg:control")],
        [InlineKeyboardButton("\U0001F3AC Ads Unlock Message", callback_data="wadcfg:tpl"),
         InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:settings")],
    ])
    await safe_edit_text(update.callback_query, text, reply_markup=kb)



# ============================================================
# BOTV13 PHASE 6 (§2-§3): 🎨 ADS UNLOCK MESSAGE (template admin UI)
# ============================================================
async def watch_ads_template_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """🎨 Ads Unlock Message — view / edit / preview / test / reset.

    The template is the single source of the user-facing unlock wording.
    PREVIEW renders the CURRENT template with the LIVE configuration values;
    TEST sends the rendered message with DUMMY values — it never creates a
    real Watch Ads session and never touches reward state.
    """
    tpl = await get_watch_ads_unlock_template()
    is_default = (tpl == WATCH_AD_UNLOCK_TEMPLATE_DEFAULT)
    unknown = _watch_ads_template_unknown_placeholders(tpl)
    minutes = await _watch_ads_unlock_minutes()
    preview = render_watch_ads_unlock_message(
        tpl, minutes=minutes, ads_required=2, completed_ads=0,
        payload="Sample Payload")
    text = (
        "\U0001F3AC Ads Unlock Message\n\n"
        f"Status: {'default template' if is_default else 'custom template'}\n"
        f"Length: {len(tpl)} chars (max {WATCH_AD_TEMPLATE_MAX_LEN})\n\n"
        "Supported placeholders:\n"
        "  {minutes} — unlock window (minutes)\n"
        "  {ads_required} — ads needed this session\n"
        "  {completed_ads} — verified rewards so far\n"
        "  {remaining_ads} — ads still needed\n"
        "  {payload} — payload display name\n"
        "Unknown placeholders render literally (never crash).\n\n"
        f"Rendered with current values ({minutes} min):\n"
        f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
        f"{preview}\n"
        "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500"
    )
    if unknown:
        text += ("\n\n\u26A0\uFE0F Unknown placeholders: " + ", ".join(unknown)
                 + "\n(they render literally — rename or remove them.)")
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u270F\uFE0F Edit", callback_data="wadcfg:tpledit"),
         InlineKeyboardButton("\U0001F441 Preview", callback_data="wadcfg:tplpreview")],
        [InlineKeyboardButton("\U0001F9EA Test", callback_data="wadcfg:tpltest"),
         InlineKeyboardButton("\u21A9\uFE0F Reset", callback_data="wadcfg:tplreset")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:wadsettings")],
    ])
    await safe_edit_text(update.callback_query, text, reply_markup=kb)



async def watch_ads_template_edit_prompt(update: Update,
                                         context: ContextTypes.DEFAULT_TYPE) -> None:
    """✏️ Edit — prompt for the new template text (text-input state)."""
    context.user_data["awaiting_wad_template"] = True
    await safe_answer_callback(update.callback_query)
    await safe_send_text(context.bot, update.effective_chat.id,
        "\U0001F3AC Ads Unlock Message — Edit\n\n"
        "Send the new template text.\n\n"
        "Placeholders (optional):\n"
        "  {minutes} {ads_required} {completed_ads}\n"
        "  {remaining_ads} {payload}\n\n"
        "Rules: plain text, up to "
        f"{WATCH_AD_TEMPLATE_MAX_LEN} chars.\n"
        "A failed validation never changes the working template.\n"
        "Send cancel to keep the current value.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u274C Cancel", callback_data="wadcfg:tplcancel")],
            [InlineKeyboardButton("\U0001F4CB Show current template",
                                  callback_data="wadcfg:tpl")],
        ]))



async def watch_ads_template_preview_panel(update: Update,
                                           context: ContextTypes.DEFAULT_TYPE) -> None:
    """👁 Preview — the CURRENT template rendered with live values, plus the
    full sample with progress lines exactly as a mid-session user sees it."""
    tpl = await get_watch_ads_unlock_template()
    minutes = await _watch_ads_unlock_minutes()
    cfg = await get_watch_ads_global_config()
    ad_control = cfg.get("ad_control") or WATCH_AD_AD_CONTROL_DEFAULT
    sample_req = 3 if ad_control == WATCH_AD_AD_CONTROL_THREE else \
        2 if ad_control == WATCH_AD_AD_CONTROL_TWO else 1
    rendered_mid = render_watch_ads_unlock_message(
        tpl, minutes=minutes, ads_required=sample_req,
        completed_ads=max(0, sample_req - 1), payload="Sample Payload")
    text = (
        "\U0001F441 Preview — current template, live values\n\n"
        f"Unlock window: {minutes} min | Ads Control sample: {sample_req} ad"
        f"{'s' if sample_req != 1 else ''}\n\n"
        f"{rendered_mid}\n\n"
        f"\u2705 Rewards verified: {max(0, sample_req - 1)}/{sample_req}\n"
        "\n(preview only — presentation, never a grant)"
    )
    await safe_edit_text(update.callback_query, text,
                         reply_markup=InlineKeyboardMarkup([
                             [InlineKeyboardButton("\U0001F9EA Test", callback_data="wadcfg:tpltest")],
                             [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="wadcfg:tpl")],
                         ]))



async def watch_ads_template_test_send(update: Update,
                                       context: ContextTypes.DEFAULT_TYPE) -> None:
    """🧪 Test — send the ACTUAL rendered Telegram message with DUMMY values.

    Never creates a real Watch Ads session and never grants/advances
    anything — display only. The test message is a temporary workflow
    message and is auto-deleted after the preview timer (§18)."""
    tpl = await get_watch_ads_unlock_template()
    rendered = render_watch_ads_unlock_message(
        tpl, minutes=20, ads_required=2, completed_ads=0,
        payload="Test Payload")
    text = (
        f"{rendered}\n\n"
        "Ads required: 2\n"
        "Progress: 0/2\n\n"
        "(dummy values — test render, nothing was created)"
    )
    user = update.effective_user
    await safe_answer_callback(update.callback_query, "\U0001F9EA Test sent below.")
    sent = await safe_send_text(context.bot, update.effective_chat.id, text)
    logger.info("WATCH_AD_TEMPLATE_TEST admin=%s length=%d dummy_values=1 "
                "session_created=0", (user.id if user else 0), len(rendered))
    if sent and getattr(sent, "message_id", None):
        # §18: temporary test message — auto-delete; never a persistent
        # dashboard.
        try:
            await schedule_admin_preview_delete(
                context.bot, update.effective_chat.id, [int(sent.message_id)])
        except Exception:  # noqa: BLE001
            pass



async def watch_ads_template_reset_confirm(update: Update,
                                           context: ContextTypes.DEFAULT_TYPE) -> None:
    """↩️ Reset — confirm restoring the default template."""
    tpl = await get_watch_ads_unlock_template()
    if tpl == WATCH_AD_UNLOCK_TEMPLATE_DEFAULT:
        await safe_answer_callback(update.callback_query,
                                   "Already the default template.")
        await watch_ads_template_panel(update, context)
        return
    await safe_edit_text(update.callback_query,
        "\u21A9\uFE0F Reset to the default template?\n\n"
        "The current custom template will be replaced by\n"
        "the built-in default wording.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u2705 Reset", callback_data="wadcfg:tplresetyes"),
             InlineKeyboardButton("\u274C Cancel", callback_data="wadcfg:tpl")],
        ]))



async def watch_ads_website_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """🌐 Mini App Website management (Add / Change / Delete)."""
    cfg = await get_watch_ads_global_config()
    current = cfg["mini_app_url"] or "—"
    has_url = cfg["url_ok"]
    text = (
        "\U0001F310 Mini App Website\n\n"
        f"Current: {current}\n\n"
        "The public HTTPS base URL where the Watch Ads\n"
        "Mini App is hosted. Secure per-session links are\n"
        "generated as: {url}/watch-ad/<session-token>\n\n"
        "Requirements: HTTPS, valid absolute URL.\n"
        "The URL persists across bot restarts."
    )
    kb_rows: List[List[InlineKeyboardButton]] = []
    if has_url:
        kb_rows.append([InlineKeyboardButton("\u270F\uFE0F Change Website",
                                             callback_data="wadcfg:webchange")])
        kb_rows.append([InlineKeyboardButton("\U0001F5D1 Delete Website",
                                             callback_data="wadcfg:webdel")])
    else:
        kb_rows.append([InlineKeyboardButton("\u2795 Add Website",
                                             callback_data="wadcfg:webadd")])
    kb_rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:wadsettings")])
    await safe_edit_text(update.callback_query, text,
                         reply_markup=InlineKeyboardMarkup(kb_rows))



async def watch_ads_website_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Prompt the admin to send the Mini App Website URL (text input state)."""
    context.user_data["awaiting_wad_url"] = True
    await safe_answer_callback(update.callback_query)
    await safe_send_text(context.bot, update.effective_chat.id,
        "\U0001F310 Mini App Website\n\n"
        "Send the HTTPS URL of your Watch Ads Mini App website.\n"
        "Example: https://app.example.com\n\n"
        "Requirements:\n"
        "\u2022 HTTPS only (production)\n"
        "\u2022 Valid absolute URL\n\n"
        "Send cancel or tap the button below to cancel without\n"
        "changing the current value.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u274C Cancel", callback_data="wadcfg:webcancel")],
        ]))



async def watch_ads_website_delete_confirm(update: Update,
                                           context: ContextTypes.DEFAULT_TYPE) -> None:
    """Confirm deleting the Mini App Website setting (safe, reversible by re-adding)."""
    cfg = await get_watch_ads_global_config()
    if not cfg["url_ok"]:
        await watch_ads_website_panel(update, context)
        return
    await safe_edit_text(update.callback_query,
        "\u26A0\uFE0F Delete Mini App Website?\n\n"
        f"{cfg['mini_app_url']}\n\n"
        "Watch Ads will stop generating Mini App links (users\n"
        "will see \u201Ctemporarily unavailable\u201D) until a new URL\n"
        "is added. Payloads and links are NOT modified.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u2705 Delete", callback_data="wadcfg:webdelyes")],
            [InlineKeyboardButton("\u274C Cancel", callback_data="wadcfg:web")],
        ]))



async def watch_ads_sdk_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """📜 Monetag SDK management (Add / Replace / Delete).

    The SDK code is stored securely and served ONLY to the Watch Ads Mini App
    page. It is never dumped into Telegram messages, never logged, and never
    executed in bot handlers / Access Engine / migrations.
    """
    cfg = await get_watch_ads_global_config()
    has_sdk = cfg["sdk_ok"]
    parsed = _parse_monetag_sdk_tag(cfg["sdk_code"]) if has_sdk else {"sdk_fn": None, "zone": None}
    text = (
        "\U0001F4DC Monetag SDK\n\n"
        "Status: \u2705 Configured" if has_sdk else "\U0001F4DC Monetag SDK\n\nStatus: \u274C Not Configured"
    )
    if has_sdk:
        text += (
            "\n\nThe SDK is securely stored and used by\n"
            "the Watch Ads Mini App."
        )
        if parsed.get("sdk_fn") or parsed.get("zone"):
            text += (f"\n\nDetected SDK tag: {parsed['sdk_fn'] or '—'}"
                     f" (zone {parsed['zone'] or '—'})")
    else:
        text += (
            "\n\nPaste the SDK / ad-tag code copied from your\n"
            "Monetag dashboard (Telegram Mini Apps \u2192 Get SDK)."
        )
    kb_rows: List[List[InlineKeyboardButton]] = []
    if has_sdk:
        kb_rows.append([InlineKeyboardButton("\u270F\uFE0F Replace SDK",
                                             callback_data="wadcfg:sdkreplace")])
        kb_rows.append([InlineKeyboardButton("\U0001F5D1 Delete SDK",
                                             callback_data="wadcfg:sdkdel")])
    else:
        kb_rows.append([InlineKeyboardButton("\u2795 Add SDK",
                                             callback_data="wadcfg:sdkadd")])
    kb_rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:wadsettings")])
    await safe_edit_text(update.callback_query, text,
                         reply_markup=InlineKeyboardMarkup(kb_rows))



async def watch_ads_sdk_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Prompt the admin to paste the Monetag SDK code (text input state)."""
    context.user_data["awaiting_wad_sdk"] = True
    await safe_answer_callback(update.callback_query)
    await safe_send_text(context.bot, update.effective_chat.id,
        "\U0001F4DC Monetag SDK\n\n"
        "Paste the SDK / ad-tag code copied from your\n"
        "Monetag dashboard (one message, up to "
        f"{WATCH_AD_SDK_MAX_CHARS} chars).\n\n"
        "The code is validated, stored securely, and served\n"
        "only to the Watch Ads Mini App.\n\n"
        "Send cancel or tap the button below to cancel without\n"
        "changing the current value.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u274C Cancel", callback_data="wadcfg:sdkcancel")],
        ]))



async def watch_ads_sdk_delete_confirm(update: Update,
                                       context: ContextTypes.DEFAULT_TYPE) -> None:
    """Confirm deleting the Monetag SDK setting."""
    cfg = await get_watch_ads_global_config()
    if not cfg["sdk_ok"]:
        await watch_ads_sdk_panel(update, context)
        return
    await safe_edit_text(update.callback_query,
        "\u26A0\uFE0F Delete Monetag SDK?\n\n"
        "The Watch Ads Mini App will stop running ads\n"
        "(users will see \u201Ctemporarily unavailable\u201D)\n"
        "until a new SDK is added. Watch Ads will NOT\n"
        "fall back to demo/fake ad code.\n\n"
        "Payloads, links, referral campaigns and analytics\n"
        "are NOT modified.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u2705 Delete", callback_data="wadcfg:sdkdelyes")],
            [InlineKeyboardButton("\u274C Cancel", callback_data="wadcfg:sdk")],
        ]))



# ============================================================
# v36 §18A — Monetag WEBSITE SDK / ad-tag management (the NORMAL
# Website surface — SEPARATE from the Telegram Mini App TMA SDK).
#
# Two DIFFERENT Monetag surfaces exist and must never be mixed:
#   • TMA SDK        — setting ``watch_ads_monetag_sdk`` (the Telegram
#                      Mini App SDK, libtl.com) rendered ONLY on
#                      /watch-ad/{token}.
#   • WEBSITE ad tag — setting ``website_monetag_ad_tag`` (its OWN provider
#                      zone) injected ONLY into /site HTML <head> by
#                      app/web/website_monetag.py. This section manages it.
# The stored tag is NEVER displayed, never logged in full, never sent to
# Telegram bot messages, and never executed in bot handlers.
#
# NAMESPACE NOTE: only the str/int constants are imported as values; the
# validator is wrapped in a module-owned function (the namespace rebinder
# recompiles section functions with the shared namespace as globals, so
# an externally-owned function must NEVER be re-exported directly).
# ============================================================
from app.web.website_monetag import (  # noqa: E402 — str/int values only
    WEBSITE_MONETAG_AD_TAG_KEY as _WSITE_AD_TAG_KEY,
    WEBSITE_AD_TAG_MAX_CHARS as _WSITE_AD_TAG_MAX,
)


def _validate_website_ad_tag(raw):
    """Validate a Website Monetag ad tag (wrapper keeps the external
    function's own module globals — never re-exported into the shared
    namespace directly)."""
    from app.web.website_monetag import validate_website_ad_tag
    return validate_website_ad_tag(raw)


async def _website_ad_tag_status() -> tuple:
    """(configured: bool, source: str|None) for the stored website tag."""
    raw = await db.get_setting(_WSITE_AD_TAG_KEY)
    if isinstance(raw, str) and raw.strip():
        tag, _err = _validate_website_ad_tag(raw)
        return (tag is not None, "db")
    import os as _os
    env = (_os.environ.get("WEBSITE_MONETAG_AD_TAG") or "").strip()
    if env:
        tag, _err = _validate_website_ad_tag(env)
        return (tag is not None, "env")
    return (False, None)


async def watch_ads_website_sdk_panel(update: Update,
                                      context: ContextTypes.DEFAULT_TYPE) -> None:
    """🌐 Monetag WEBSITE SDK (ad tag) management — Add / Replace / Delete.

    §18A: separate from the Mini App TMA SDK. Status is truthful: when no
    website tag is configured the panel says "Not Configured" — it never
    pretends website ads are active. Website functionality works WITHOUT
    the tag (injection is additive)."""
    configured, source = await _website_ad_tag_status()
    tma_cfg = await get_watch_ads_global_config()
    text = (
        "\U0001F310 Monetag WEBSITE SDK\n\n"
        "Status: \u2705 Configured (source=%s)" % source if configured
        else "\U0001F310 Monetag WEBSITE SDK\n\nStatus: \u274C Not Configured"
    )
    text += (
        "\n\nThis is the ad tag for the NORMAL Website\n"
        "(/site pages) — separate from the Mini App\n"
        "TMA SDK (libtl.com, Watch Ads Mini App).\n\n"
        "Paste the exact Website SDK / ad-tag code\n"
        "supplied by Monetag for the website surface."
    )
    if configured:
        text += ("\n\nWhen configured, the tag is injected into\n"
                 "the <head> of the /site Website pages only —\n"
                 "never into Telegram bot messages and never\n"
                 "into the Watch Ads Mini App.")
    else:
        text += ("\n\nWhile not configured, NOTHING is injected —\n"
                 "the Website keeps working without website ads.")
    text += ("\n\nMini App TMA SDK (separate setting):\n"
             + ("\u2705 Configured" if tma_cfg["sdk_ok"]
                else "\u274C Not Configured"))
    kb_rows: List[List[InlineKeyboardButton]] = []
    if configured:
        kb_rows.append([InlineKeyboardButton("\u270F\uFE0F Replace Website SDK",
                                             callback_data="wadcfg:wsdkreplace")])
        kb_rows.append([InlineKeyboardButton("\U0001F5D1 Delete Website SDK",
                                             callback_data="wadcfg:wsdkdel")])
    else:
        kb_rows.append([InlineKeyboardButton("\u2795 Add Website SDK",
                                             callback_data="wadcfg:wsdkadd")])
    kb_rows.append([InlineKeyboardButton("\u2B05\uFE0F Back",
                                         callback_data="panel:wadsettings")])
    await safe_edit_text(update.callback_query, text,
                         reply_markup=InlineKeyboardMarkup(kb_rows))


async def watch_ads_website_sdk_prompt(update: Update,
                                        context: ContextTypes.DEFAULT_TYPE) -> None:
    """Prompt the admin to paste the Monetag WEBSITE SDK code (text input)."""
    # v36: single active conversation + freshness stamp.
    clear_conversation_input_states(context)
    context.user_data["awaiting_wsdk"] = stamp_conversation_state(
        {"step": "await_tag"})
    await safe_answer_callback(update.callback_query)
    await safe_send_text(context.bot, update.effective_chat.id,
        "\U0001F310 Monetag WEBSITE SDK\n\n"
        "Paste the Website SDK / ad-tag code supplied by\n"
        "Monetag for the WEBSITE surface (one message, up to "
        f"{_WSITE_AD_TAG_MAX} chars).\n\n"
        "The code is validated, stored securely, and injected\n"
        "only into the /site Website pages.\n\n"
        "Send cancel or tap the button below to cancel without\n"
        "changing the current value.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u274C Cancel", callback_data="wadcfg:wsdkcancel")],
        ]))


async def watch_ads_website_sdk_delete_confirm(update: Update,
                                               context: ContextTypes.DEFAULT_TYPE) -> None:
    """§18A: explicit confirmation before deleting the Website SDK."""
    configured, _source = await _website_ad_tag_status()
    if not configured:
        await watch_ads_website_sdk_panel(update, context)
        return
    await safe_edit_text(update.callback_query,
        "\u26A0\uFE0F Delete Monetag WEBSITE SDK?\n\n"
        "The Website (/site pages) will stop showing\n"
        "website ads — NOTHING else changes:\n"
        "the Website keeps working, payloads, streams\n"
        "and the Mini App TMA SDK are NOT modified.\n\n"
        "Delete is safe and reversible: re-add the tag\n"
        "code anytime to restore website ads.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u2705 Delete", callback_data="wadcfg:wsdkdelyes")],
            [InlineKeyboardButton("\u274C Cancel", callback_data="wadcfg:wsdk")],
        ]))



async def watch_ads_window_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """⏱ Unlock Window presets (how long a verified unlock stays valid)."""
    cfg = await get_watch_ads_global_config()
    cur = cfg["unlock_window"]
    presets = [60, 180, 300, 900, 3600]
    rows: List[List[InlineKeyboardButton]] = []
    for secs in presets:
        mark = "\u2713 " if secs == cur else ""
        label = f"{secs}s" if secs < 3600 else "1 hour"
        rows.append([InlineKeyboardButton(f"{mark}\u23F1 {label}",
                                          callback_data=f"wadcfg:windowset:{secs}")])
    rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:wadsettings")])
    cur_label = f"{cur}s" if cur and cur < 3600 else ("1 hour" if cur == 3600 else str(cur))
    await safe_edit_text(update.callback_query,
        "\u23F1 Watch Ads Unlock Window\n\n"
        f"Current: {cur_label}\n\n"
        "After a verified ad reward, the payload stays\n"
        "unlocked for this user for the window duration.\n"
        "After it elapses, a new ad is required.",
        reply_markup=InlineKeyboardMarkup(rows))



async def watch_ads_ad_control_panel(update: Update,
                                     context: ContextTypes.DEFAULT_TYPE) -> None:
    """🎛 Ads Control — WHAT HAPPENS INSIDE ONE Watch Ads session.

    The mode controls the ad experience inside a single session, NEVER how
    many times the Telegram [🎬 Watch Ad] button is pressed: ONE click always
    starts/resumes exactly ONE session. Persisted in bot_settings
    (watch_ads_ad_control) — DB authoritative, survives restarts, applies to
    NEWLY created sessions (existing sessions keep their stored mode).
    """
    cfg = await get_watch_ads_global_config()
    cur = cfg.get("ad_control") or WATCH_AD_AD_CONTROL_DEFAULT
    meta = WATCH_AD_AD_CONTROL_META.get(cur, WATCH_AD_AD_CONTROL_META[WATCH_AD_AD_CONTROL_SHORT])
    rows: List[List[InlineKeyboardButton]] = []
    for mode in WATCH_AD_AD_CONTROL_MODES:
        m = WATCH_AD_AD_CONTROL_META[mode]
        mark = "\u2713 " if mode == cur else ""
        rows.append([InlineKeyboardButton(f"{mark}{m['label']}",
                                          callback_data=f"wadcfg:controlset:{mode}")])
    rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:wadsettings")])
    await safe_edit_text(update.callback_query,
        "\U0001F39B Ads Control\n\n"
        f"Current: {meta['label']}\n"
        f"{meta['desc']}\n\n"
        "One [🎬 Watch Ad] tap always opens ONE session;\n"
        "the selected mode shapes what happens inside it.\n"
        "Applies to newly created ad sessions.\n\n"
        "\U0001F4FA Duration is provider-controlled\n"
        "(docs.monetag.com): the SDK has NO ad-\n"
        "duration setting — Monetag serves the\n"
        "creative with its own length. For longer\n"
        "engagement pick MORE ads (Two/Three/\n"
        "Random), never a fake timer.",
        reply_markup=InlineKeyboardMarkup(rows))



async def watch_ads_ad_control_set(update: Update,
                                   context: ContextTypes.DEFAULT_TYPE,
                                   mode: str) -> None:
    """Persist the selected Ads Control mode (validated; DB authoritative)."""
    if mode not in WATCH_AD_AD_CONTROL_MODES:
        await safe_answer_callback(update.callback_query,
                                   "Unknown ads control mode.")
        await watch_ads_ad_control_panel(update, context)
        return
    await db.set_setting(WATCH_AD_AD_CONTROL_KEY, mode)
    await log_admin_action(
        (update.callback_query.from_user.id if update.callback_query and
         update.callback_query.from_user else None),
        "set_watch_ads_ad_control", "setting", None, f"mode={mode}")
    logger.info("Watch Ads Ads Control set to '%s' (admin=%s).", mode,
                update.callback_query.from_user.id if update.callback_query
                and update.callback_query.from_user else None)
    await safe_answer_callback(
        update.callback_query,
        f"\u2705 Ads Control set to {WATCH_AD_AD_CONTROL_META[mode]['label']}.")
    await watch_ads_ad_control_panel(update, context)



# ============================================================
# WATCH_AD V4 (v27) — ADMIN: Global controls / Status / Reconcile
# ============================================================
def _fmt_secs_short(secs: int) -> str:
    secs = int(secs)
    if secs >= 3600 and secs % 3600 == 0:
        return f"{secs // 3600}h"
    if secs >= 60 and secs % 60 == 0:
        return f"{secs // 60}min"
    return f"{secs}s"



async def watch_ads_global_toggle_confirm(update: Update,
                                          context: ContextTypes.DEFAULT_TYPE) -> None:
    """🌍 Global Watch Ads OFF — confirmation (dangerous action).

    Turning Watch Ads OFF globally makes every payload behave as if its
    watch_ads_enabled=0 (base policy only). V5.1: payloads whose referral
    campaign is ALSO unavailable fall back to the BASE policy (Force Join
    only) — never the old 'content not available' dead end. Per-payload
    toggles are NEVER modified.
    """
    await safe_edit_text(update.callback_query,
        "\u26A0\uFE0F Disable Watch Ads GLOBALLY?\n\n"
        "Every payload will behave as if Watch Ads\n"
        "is off (base access policy only):\n"
        "\u2022 Referral+WA payloads \u2192 referral only\n"
        "\u2022 WA-only payloads (no campaign) \u2192\n"
        "   base policy (Force Join only)\n"
        "\u2022 In-flight ad sessions keep their stability\n\n"
        "Referral itself is NEVER disabled by this\n"
        "switch, and no payload dead-ends.\n"
        "Per-payload toggles are PRESERVED and\n"
        "re-activate when Watch Ads is turned back ON.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u274C Disable globally",
                                  callback_data="wadcfg:globaloffyes")],
            [InlineKeyboardButton("\u2B05\uFE0F Cancel",
                                  callback_data="panel:wadsettings")],
        ]))



async def watch_ads_global_toggle_set(update: Update,
                                      context: ContextTypes.DEFAULT_TYPE,
                                      enabled: bool) -> None:
    """Persist the GLOBAL master switch (validated; DB authoritative)."""
    admin_id = (update.callback_query.from_user.id if update.callback_query
                and update.callback_query.from_user else None)
    await db.set_setting(WATCH_ADS_GLOBAL_ENABLED_KEY, "1" if enabled else "0")
    await log_admin_action(admin_id, "set_watch_ads_global_enabled",
                           "setting", None, f"enabled={int(enabled)}")
    logger.info("Watch Ads GLOBAL %s (admin=%s).",
                "ENABLED" if enabled else "DISABLED", admin_id)
    await safe_answer_callback(
        update.callback_query,
        "\u2705 Watch Ads ENABLED globally." if enabled
        else "\u274C Watch Ads DISABLED globally.")
    await watch_ads_settings_panel(update, context)



async def watch_ads_session_ttl_panel(update: Update,
                                      context: ContextTypes.DEFAULT_TYPE) -> None:
    """⏳ Session Timeout — how long a pending (unverified) ad session lives.

    This is the default VERIFICATION timeout: the window in which Monetag
    postbacks can still reward a session. Delayed postbacks inside the window
    are never failed; beyond it the user simply starts a new session.
    """
    cfg = await get_watch_ads_global_config()
    cur = int(cfg.get("session_ttl") or WATCH_AD_SESSION_TTL)
    presets = [300, 600, 900, 1800, 3600, 7200]
    rows: List[List[InlineKeyboardButton]] = []
    for secs in presets:
        mark = "\u2713 " if secs == cur else ""
        rows.append([InlineKeyboardButton(f"{mark}\u23F3 {_fmt_secs_short(secs)}",
                                          callback_data=f"wadcfg:ttlset:{secs}")])
    rows.append([InlineKeyboardButton("\u2B05\uFE0F Back",
                                      callback_data="panel:wadsettings")])
    await safe_edit_text(update.callback_query,
        "\u23F3 Watch Ads Session Timeout\n\n"
        f"Current: {_fmt_secs_short(cur)}\n\n"
        "A pending ad session stays valid for this\n"
        "duration. Postbacks arriving inside the\n"
        "window are always processed (a delayed\n"
        "reward is NEVER failed — the Mini App keeps\n"
        "polling until the server confirms).\n\n"
        f"Range: {_fmt_secs_short(WATCH_ADS_SESSION_TTL_MIN)}"
        f"\u2013{_fmt_secs_short(WATCH_ADS_SESSION_TTL_MAX)}.\n"
        "Applies to newly created sessions.",
        reply_markup=InlineKeyboardMarkup(rows))



async def watch_ads_session_ttl_set(update: Update,
                                    context: ContextTypes.DEFAULT_TYPE,
                                    secs: int) -> None:
    """Persist the session timeout (clamped; DB authoritative)."""
    secs = max(WATCH_ADS_SESSION_TTL_MIN,
               min(WATCH_ADS_SESSION_TTL_MAX, int(secs)))
    admin_id = (update.callback_query.from_user.id if update.callback_query
                and update.callback_query.from_user else None)
    await db.set_setting(WATCH_ADS_SESSION_TTL_KEY, str(secs))
    await log_admin_action(admin_id, "set_watch_ads_session_ttl",
                           "setting", None, f"seconds={secs}")
    logger.info("Watch Ads session TTL set to %ss (admin=%s).", secs, admin_id)
    await safe_answer_callback(
        update.callback_query,
        f"\u2705 Session timeout set to {_fmt_secs_short(secs)}.")
    await watch_ads_session_ttl_panel(update, context)



async def watch_ads_reconcile_confirm(update: Update,
                                      context: ContextTypes.DEFAULT_TYPE) -> None:
    """🧹 Reconcile stuck sessions — confirmation (state-changing action)."""
    counts = await db.watch_ad_session_status_counts()
    await safe_edit_text(update.callback_query,
        "\U0001F9F9 Reconcile Stuck Ad Sessions?\n\n"
        "Two idempotent, non-destructive repairs:\n"
        "\u2022 Pending sessions whose verified progress\n"
        "  already reached the requirement \u2192 marked\n"
        "  rewarded + unlock window started\n"
        "\u2022 Pending sessions past their timeout \u2192\n"
        "  marked expired\n\n"
        f"Currently pending: {counts['pending_active']} active | "
        f"{counts['pending_stuck']} stuck\n\n"
        "Never invents rewards (only the server-\n"
        "verified progress is used). Never touches\n"
        "rewarded/consumed sessions, referrals,\n"
        "payloads or users.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\u2705 Reconcile now",
                                  callback_data="wadcfg:reconcileyes")],
            [InlineKeyboardButton("\u2B05\uFE0F Cancel",
                                  callback_data="wadcfg:status")],
        ]))



async def watch_ads_reconcile_run(update: Update,
                                  context: ContextTypes.DEFAULT_TYPE) -> None:
    """Execute the reconcile (see Database.reconcile_watch_ad_sessions)."""
    admin_id = (update.callback_query.from_user.id if update.callback_query
                and update.callback_query.from_user else None)
    cfg = await get_watch_ads_global_config()
    try:
        out = await db.reconcile_watch_ad_sessions(int(cfg.get("unlock_window")
                                                       or WATCH_AD_UNLOCK_WINDOW))
    except Exception as e:  # noqa: BLE001
        await safe_answer_callback(
            update.callback_query,
            "\u274C Reconcile failed — see the bot log (WATCH_AD_RECONCILE_FAILED).",
            show_alert=True)
        await watch_ads_status_panel(update, context)
        return
    await log_admin_action(admin_id, "reconcile_watch_ad_sessions",
                           "setting", None,
                           f"repaired={out['repaired']} expired={out['expired']}")
    await safe_answer_callback(
        update.callback_query,
        f"\u2705 Reconciled: {out['repaired']} repaired, {out['expired']} expired.")
    await watch_ads_status_panel(update, context)



async def watch_ads_status_panel(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE) -> None:
    """📊 Watch Ads Status & Monitoring (admin).

    Uses ONLY the existing database (sessions, reward ledger, postback log)
    — no new infrastructure. Shows: global state + mode, provider readiness,
    session counts by status, active sessions with live progress, postback
    counts by classification (total / rewarded / duplicate / invalid /
    errors, last 24h), recent rewards, and recent internal errors.
    """
    cfg = await get_watch_ads_global_config()
    sessions = await db.watch_ad_session_status_counts()
    pb = await db.watch_ad_postback_stats()
    recent_rewards = await db.recent_watch_ad_rewards(5)
    recent_errors = await db.recent_watch_ad_postback_errors(5)
    active = await db.recent_active_watch_ad_sessions(8)
    launch = await db.watch_ad_launch_metrics()
    top_payloads = await db.watch_ad_payload_launch_metrics(5)
    # V27.1 (windowed metrics): the recency readout — session counts in
    # the last 24h and last 7d windows, from the SAME windowed rollups the
    # metrics surface exposes (window_hours=24 / 168). Computed after the
    # all-time queries so the panel stays one coherent snapshot; only
    # rendered when there are sessions at all (fresh deployment unchanged).
    recency_24h = recency_7d = 0
    if sessions.get("total"):
        recency_24h = (await db.watch_ad_launch_metrics(24))["total_sessions"]
        recency_7d = (await db.watch_ad_launch_metrics(168))["total_sessions"]
    ad_control = cfg.get("ad_control") or WATCH_AD_AD_CONTROL_DEFAULT
    control_label = WATCH_AD_AD_CONTROL_META.get(
        ad_control, WATCH_AD_AD_CONTROL_META[WATCH_AD_AD_CONTROL_SHORT])["label"]
    global_on = bool(cfg.get("enabled", True))
    global_state_line = "\u2705 ON" if global_on else "\u274C OFF"
    url_state = "\u2705" if cfg["url_ok"] else "\u274C"
    sdk_state = "\u2705" if cfg["sdk_ok"] else "\u274C"
    lines: List[str] = [
        "\U0001F4CA Watch Ads Status\n",
        f"\U0001F30D Global: {global_state_line}",
        f"\U0001F39B Default mode: {control_label}",
        f"\U0001F310 Website: {url_state} | \U0001F4DC SDK: {sdk_state}",
        f"\u23F1 Unlock window: {_fmt_secs_short(cfg['unlock_window'])} | "
        f"\u23F3 Session timeout: {_fmt_secs_short(cfg.get('session_ttl') or WATCH_AD_SESSION_TTL)}",
        "",
        "\U0001F4C8 Sessions",
        f"  Active (pending): {sessions['pending_active']}",
        f"  Stuck (past TTL): {sessions['pending_stuck']}",
        f"  Rewarded: {sessions['rewarded']}",
        f"  Expired: {sessions['expired']} | Rejected: {sessions['rejected']}",
        f"  Total: {sessions['total']}",
        "",
        "\U0001F4E9 Postbacks",
        f"  Total: {pb['total']} (last 24h: {pb['last_24h']})",
        f"  Rewarded: {pb['rewarded']} | Duplicates: {pb['duplicate']}",
        f"  Invalid (unknown/rejected/expired): {pb['invalid']}",
        f"  DB errors (HTTP 500, retried): {pb['error']}",
    ]
    # V27.1 (windowed metrics): the recency readout — session counts in
    # the last 24h and 7d windows from the SAME windowed rollups the
    # metrics surface exposes (window_hours=24 / 168). Rendered only when
    # sessions exist, so a fresh deployment's panel stays exactly as long
    # as before (the empty guarantee kept from V27).
    if sessions.get("total"):
        lines += [
            "",
            "\U0001F4C8 Sessions \u00B7 windows (V27.1)",
            f"  Last 24h: {recency_24h} | Last 7d: {recency_7d} "
            f"(windowed rollups)",
        ]
    # V27.2 (hourly trend): the direction readout — this 24h vs the
    # previous 24h from the hourly buckets (watch_ad_session_trend), with
    # the busiest hour. Rendered only when either window has a session, so
    # a fresh deployment's panel stays exactly as long as before.
    # V27.3: the same direction readout DAY-BUCKETED over the last 7
    # calendar days (watch_ad_session_trend(168, bucket="day")) — the
    # week-level trend alongside the day-level one.
    if sessions.get("total"):
        trend = await db.watch_ad_session_trend(24)
        if trend["current"] or trend["previous"]:
            arrow = {"up": "\u25B2", "down": "\u25BC",
                     "flat": "\u25B6"}[trend["trend"]]
            peak = (f" \u00B7 peak {trend['peak_sessions']} @ "
                    f"{trend['peak_hour'][11:13]}:00"
                    if trend["peak_hour"] else "")
            lines += [
                "",
                "\U0001F4C8 Hourly trend (V27.2 \u00B7 24h buckets)",
                f"  This 24h: {trend['current']} \u00B7 previous 24h: "
                f"{trend['previous']} {arrow} {trend['trend']}"
                f" \u00B7 rewarded {trend['rewarded_current']}{peak}",
            ]
        trend7 = await db.watch_ad_session_trend(168, bucket="day")
        if trend7["current"] or trend7["previous"]:
            arrow7 = {"up": "\u25B2", "down": "\u25BC",
                      "flat": "\u25B6"}[trend7["trend"]]
            peak7 = (f" \u00B7 peak {trend7['peak_sessions']} @ "
                     f"{trend7['peak_hour'][5:10]}"
                     if trend7["peak_hour"] else "")
            lines += [
                f"  This 7d: {trend7['current']} \u00B7 previous 7d: "
                f"{trend7['previous']} {arrow7} {trend7['trend']}"
                f" \u00B7 rewarded {trend7['rewarded_current']}{peak7}"
                "  (V27.3 \u00B7 day buckets)",
            ]
    # V27 (admin metrics): the launch-context rollup — sessions per launch
    # bot (main vs each network bot), the reward funnel and completion
    # rate per context. Rendered only when there is something to show so a
    # fresh deployment's panel stays exactly as long as before.
    if launch.get("total_sessions"):
        m = launch["main"]
        lines += [
            "",
            "\U0001F680 Launch context (V26+)",
            f"  Main bot: {m['sessions']} sessions \u00B7 "
            f"{m['rewarded']} rewarded ({m['reward_rate']:.0%})",
        ]
        for nb in launch["network"]:
            label = ("@" + nb["username"]) if nb["username"] \
                else f"bot id {nb['telegram_bot_id']}"
            lines.append(
                f"  {label} [{nb['bot_status']}]: {nb['sessions']} "
                f"sessions \u00B7 {nb['rewarded']} rewarded "
                f"({nb['reward_rate']:.0%})")
        for uk in launch["unknown"]:
            lines.append(
                f"  \u2022 unknown id {uk['network_bot_id']}: "
                f"{uk['sessions']} sessions \u00B7 "
                f"{uk['rewarded']} rewarded")
    # V27 (admin metrics): the per-PAYLOAD breakdown — where the Watch-Ads
    # traffic lives: top payloads by session volume, each with its funnel
    # and its launch split (main vs network sessions). Bounded (top 5) so
    # the panel stays within Telegram's message limits.
    if top_payloads:
        lines += [
            "",
            "\U0001F4E6 Top payloads by Watch-Ad sessions",
        ]
        for pl in top_payloads:
            label = (pl["payload_code"] or pl["payload_display"]
                     or f"id {pl['payload_id']}")
            lines.append(
                f"  \u2022 {label}: {pl['sessions']} sessions \u00B7 "
                f"{pl['rewarded']} rewarded ({pl['reward_rate']:.0%}) \u00B7 "
                f"main {pl['main_sessions']} \u00B7 "
                f"network {pl['network_sessions']}")
    if active:
        lines.append("")
        lines.append("\U0001F576 Active sessions")
        for s in active:
            pcode = s["payload_code"] or s["payload_display"] or s["payload_id"]
            lines.append(f"  \u2022 u{s['user_id']} \u2192 {pcode}: "
                         f"{s['completed_ads']}/{s['required_ads']} "
                         f"({s['ad_control_mode']})")
    if recent_rewards:
        lines.append("")
        lines.append("\U0001F3C6 Recent rewards")
        for r in recent_rewards:
            pcode = r["payload_code"] or r["payload_id"]
            ts = (str(r["created_at"]) or "")[11:19]
            lines.append(f"  \u2022 {ts} u{r['user_id']} \u2192 {pcode}"
                         f" (ad {r['ad_index'] or 1})")
    if recent_errors:
        lines.append("")
        lines.append("\u26A0\uFE0F Recent errors")
        for e in recent_errors:
            ts = (str(e["created_at"]) or "")[11:19]
            lines.append(f"  \u2022 {ts} ymid={e['ymid_prefix'] or '-'}\u2026 "
                         f"http={e['http_status']}")
    else:
        lines.append("")
        lines.append("\u26A0\uFE0F Recent errors: none")
    await safe_edit_text(update.callback_query, "\n".join(lines),
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("\U0001F504 Refresh", callback_data="wadcfg:status"),
             InlineKeyboardButton("\U0001F9F9 Reconcile", callback_data="wadcfg:reconcile")],
            [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:wadsettings")],
        ]))



async def payload_timer_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                               payload_id: int) -> None:
    """BOTV13 Phase 4: Delivery screen — delete timer + forward blocking."""
    row = await db.get_payload_by_id(payload_id)
    if not row:
        await update.callback_query.answer("Payload not found.", show_alert=True)
        return
    da = row["delete_after"]
    # BOTV13 Phase 4: per-payload forward blocking (NULL=inherit, 1=ON, 0=OFF).
    fb = row["forward_blocking"] if "forward_blocking" in row.keys() else None
    global_protect = await resolve_delivery_protection()
    if fb is None:
        fb_label = f"Inherit global ({'ON' if global_protect else 'OFF'})"
    elif fb:
        fb_label = "ON"
    else:
        fb_label = "OFF"
    da_label = "inherit global" if da is None else ("never" if da == 0 else f"{da}s")
    text = (
        f"\U0001F6E0 Delivery Settings\n\n"
        f"\u23F1\ufe0f Timer: {da_label}\n"
        f"\U0001F6E1 Forward Blocking: {fb_label}\n"
    )
    rows: List[List[InlineKeyboardButton]] = []
    # Delete timer presets.
    for secs in DELETE_TIMER_PRESETS:
        mark = "\u2713 " if da == secs else ""
        rows.append([InlineKeyboardButton(
            f"{mark}{DELETE_TIMER_LABELS[secs]}",
            callback_data=f"pltset:{payload_id}:{secs}",
        )])
    inherit_mark = "\u2713 " if da is None else ""
    rows.append([InlineKeyboardButton(
        f"{inherit_mark}\U0001F310 Inherit global timer",
        callback_data=f"pltset:{payload_id}:{INHERIT_SENTINEL}",
    )])
    # BOTV13 Phase 4: custom delete timer.
    rows.append([InlineKeyboardButton(
        "\u270F\ufe0f Custom Time",
        callback_data=f"pltcustom:{payload_id}",
    )])
    # Forward blocking 3-state toggle.
    rows.append([InlineKeyboardButton(
        f"\U0001F6E1 Forward Blocking: {fb_label}",
        callback_data=f"plfb:{payload_id}",
    )])
    rows.append([InlineKeyboardButton("\u2B05\ufe0f Back", callback_data=f"pldetail:{payload_id}")])
    await safe_edit_text(update.callback_query, text, reply_markup=InlineKeyboardMarkup(rows))



async def send_payload_info(update: Update, row: aiosqlite.Row) -> None:
    file_row = await db.get_indexed_file_by_id(row["index_id"])
    stats = await db.payload_view_stats(row["id"])
    da = row["delete_after"]
    da_label = "inherit global" if da is None else ("never" if da == 0 else f"{da}s")
    # BOTV13 Part 1: show display_name, routing ID, and human-friendly link.
    stored_dn = row["display_name"] if "display_name" in row.keys() else None
    display_val = stored_dn if stored_dn else row["payload"]
    text = (
        f"*Name:* {display_val}\n"
        f"*Routing ID:* {md_code_span(row['payload'])}\n"
        f"*Status:* {row['status']}\n"
        f"*File:* {escape_md(file_row['file_name'] if file_row else 'missing')}\n"
        f"*One-time:* {'yes' if row['one_time'] else 'no'}\n"
        f"*Password:* {'yes' if row['password'] else 'no'}\n"
        f"*Expires:* {row['expires_at'] or 'never'}\n"
        f"*Max clicks:* {row['max_clicks'] or 'unlimited'}\n"
        f"*Current clicks:* {row['current_clicks']}\n"
        f"*Delete timer:* {da_label}\n"
        f"*Views:* total={stats['total']} unique={stats['unique']}\n\n"
        f"*Link:* {md_code_span(build_link(row['payload'], display_name=stored_dn))}"
    )
    kb = InlineKeyboardMarkup(
        [[InlineKeyboardButton("\U0001F4CB Copy Link", callback_data=f"copy_id:{row['id']}")]]
    )
    await reply_protected(update, text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



async def send_payload_created_message(update: Update, payload: str) -> None:
    # BOTV13 fix: use copy_id:<id> to avoid Button_data_invalid on long slugs.
    # V26: the legacy copy:<slug> fallback only fired when the payload row
    # lookup FAILED — a copy link for an unresolvable payload is useless
    # AND a 64-char slug breaks the 64-byte limit. No row -> NO button
    # (the central validate_keyboard_markup tripwire backs this up).
    p_row = await db.get_payload(payload)
    copy_cb = f"copy_id:{p_row['id']}" if p_row else None
    text = (
        f"*\u2705 Payload created!*\n\n"
        f"*Payload:* {md_code_span(payload)}\n"
        f"*Link:* {md_code_span(build_link(payload))}"
    )
    if copy_cb:
        kb = InlineKeyboardMarkup(
            [[InlineKeyboardButton("\U0001F4CB Copy Link", callback_data=copy_cb)]]
        )
    else:
        kb = None
    await reply_protected(update, text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb)
