"""aiohttp server lifecycle (ARCHITECTURE PHASE).

``WebServerLifecycle`` owns the AppRunner/TCPSite mechanics (setup, start,
stop, cleanup) for the in-process Mini App web server. Route registration
stays with the pinned legacy lines in bot.py (docs/BOT_COMPATIBILITY.md);
this class removes the lifecycle responsibility from the monolith.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger("payload-bot")


class WebServerLifecycle:
    """Runner + site lifecycle for one aiohttp Application."""

    def __init__(self, app: Any, host: str = "0.0.0.0", port: int = 8080,
                 web_module: Optional[Any] = None) -> None:
        self._app = app
        self._host = host
        self._port = port
        self._web = web_module  # aiohttp.web, injected (importable w/o aiohttp)
        self._runner: Optional[Any] = None
        self._site: Optional[Any] = None

    async def start(self) -> bool:
        if self._web is None:
            logger.error(
                "Mini App HTTP server NOT started: aiohttp is not installed.")
            return False
        self._runner = self._web.AppRunner(self._app)
        await self._runner.setup()
        self._site = self._web.TCPSite(self._runner, self._host, self._port)
        await self._site.start()
        logger.info(
            "WATCH_AD Mini App HTTP server started on port %s (same process).",
            self._port)
        return True

    async def stop(self) -> None:
        try:
            if self._runner is not None:
                await self._runner.cleanup()
                logger.info("WATCH_AD Mini App HTTP server stopped.")
        except Exception:  # noqa: BLE001
            logger.debug("Mini App server cleanup error.", exc_info=True)
        self._runner = None
        self._site = None
