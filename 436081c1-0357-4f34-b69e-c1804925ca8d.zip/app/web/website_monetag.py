"""Monetag WEBSITE integration surface (WS-B — spec §19/§20/§21).

TWO SEPARATE Monetag integration surfaces exist in this deployment and
must NEVER be mixed (spec §19):

  1. TELEGRAM MINI APP (Watch Ads) — the libtl.com TMA SDK tag stored in
     the ``watch_ads_monetag_sdk`` setting, rendered ONLY on the
     GET /watch-ad/{token} Mini App page (app/presentation/telegram/
     miniapp.py ``_wad_mini_app_page``). TMA zone 11742509. This module
     never touches that surface.

  2. WEBSITE — the Monetag WEBSITE integration for the /site pages:
       * a Service Worker that MUST be served at the DOMAIN ROOT
         (``https://<domain>/sw.js`` — root scope, NOT /site/sw.js,
         spec §20). This module serves the provider-supplied sw.js
         VERBATIM at GET /sw.js (bytes from app/web/static/sw.js —
         never a replacement, domain/zone untouched).
       * an ad-zone ``<script>`` tag the Monetag provider account must
         supply for the website surface (spec §21). NOT supplied yet:
         this module implements the CONFIGURATION POINT only — the
         database setting ``website_monetag_ad_tag`` (the existing
         generic settings store — same mechanism as
         ``watch_ads_monetag_sdk`` / ``website_enabled``) with the
         ``WEBSITE_MONETAG_AD_TAG`` env as fallback. When configured
         the tag is injected into the <head> of every /site HTML page
         at the SAME position the site renderer's ``head_extra``
         mechanism uses (immediately before ``</head>``); when NOT
         configured NOTHING is injected and the diagnostics report
         "website ad tag: NOT CONFIGURED (provider tag required)".

No provider code is fabricated here: the sw.js bytes come verbatim from
the uploaded provider file and the ad tag comes verbatim from operator
configuration.

The <head> injection is implemented as an aiohttp RESPONSE middleware
(wired in app/web/server.py) rather than a pages.py change: the /site
renderer (app/web/site/pages.py + html.py, ``head_extra``) is owned by a
parallel workstream and the middleware performs the byte-identical
</head>-tail insertion. ``website_monetag_head_html`` is exported for the
renderer owner to adopt ``head_extra`` directly later if preferred.

Also lives here: the optional ORIGIN PROXY SHARED SECRET guard (spec
§24-§28). When env ``ORIGIN_PROXY_SECRET`` is set on the aiohttp server,
requests that do not carry the matching ``X-Origin-Key`` header are
rejected with 403. Default (env unset): the guard is DISABLED — zero
behavior change. The Cloudflare worker (cloudflare/worker.js) injects
that header from its ``ORIGIN_PROXY_SECRET`` Worker secret.
"""
from __future__ import annotations

import hmac
import logging
import os
import re
from typing import Any, Callable, Dict, Optional, Tuple

logger = logging.getLogger("payload-bot")

try:  # pragma: no cover - optional dependency (same guard as server.py)
    from aiohttp import web as _aiohttp_web

    AIOHTTP_AVAILABLE = True
except Exception:  # noqa: BLE001
    _aiohttp_web = None
    AIOHTTP_AVAILABLE = False


# ------------------------------------------------------------------ sw.js
SW_PATH = "/sw.js"
"""Monetag WEBSITE service worker URL — MUST be the DOMAIN ROOT.

Monetag website integrations register the provider service worker at
root scope (``navigator.serviceWorker.register('/sw.js')`` from the
provider script), so the file must answer at ``https://<domain>/sw.js``.
``Service-Worker-Allowed`` is NOT needed precisely because the file is
served at root scope (the default maximum scope)."""

SW_STATIC_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "static", "sw.js")
"""Repo home of the provider-supplied sw.js (served VERBATIM — never a
replacement; domain 3nbf4.com / zoneId 11800971 untouched)."""

# BOT-26 ISSUE B diagnostic (spec §6/§8 of the production-fix brief): the
# master switch for the Monetag WEBSITE surface. Default ENABLED — the
# provider worker is served VERBATIM and the configured ad tag injects.
# When WEBSITE_MONETAG_ENABLED is a falsy value ("0"/"false"/"no"/"off")
# the ENTIRE third-party website-ad layer is isolated for diagnosis:
# no ad tag is injected anywhere and /sw.js serves the DIAGNOSTIC NO-OP
# service worker below (self-unregistering — it actively removes any
# previously-registered worker from controlling clients) so the /site
# shell can never be held hostage by a stale third-party worker during
# the diagnostic. This is a DIAGNOSTIC/DEVELOPMENT configuration only:
# it does NOT remove the Monetag configuration, does NOT touch the
# Telegram Mini App (Watch Ads) surface, and the production default is
# UNCHANGED (enabled) until evidence justifies otherwise.
WEBSITE_MONETAG_ENABLED_ENV = "WEBSITE_MONETAG_ENABLED"

# The diagnostic no-op service worker (BOT-26 §8: "If a diagnostic no-op
# service worker is needed, keep it strictly behind a diagnostic/
# development configuration"). Served ONLY while the Monetag website
# surface is DISABLED. It never caches anything, never intercepts
# fetches, unregisters itself on activation and asks every client to
# reload — the recovery path that removes a previously-registered
# third-party worker WITHOUT touching the provider file.
DIAGNOSTIC_NOOP_SW_BYTES = (
    b"/* payload-bot diagnostic no-op service worker (BOT-26)\n"
    b" * Served ONLY while WEBSITE_MONETAG_ENABLED is disabled.\n"
    b" * Caches nothing, intercepts nothing, unregisters itself and\n"
    b" * reloads open clients so a previously-registered third-party\n"
    b" * worker can never keep a stale shell in front of users.\n */\n"
    b"self.addEventListener('install', function (e) {\n"
    b"  self.skipWaiting();\n"
    b"});\n"
    b"self.addEventListener('activate', function (e) {\n"
    b"  e.waitUntil(self.registration.unregister().then(function () {\n"
    b"    return self.clients.matchAll({ type: 'window' });\n"
    b"  }).then(function (clients) {\n"
    b"    clients.forEach(function (c) { c.navigate(c.url); });\n"
    b"  }));\n"
    b"});\n"
)


def website_monetag_enabled() -> bool:
    """Is the Monetag WEBSITE surface enabled? (default True).

    BOT-13 RULE F: the raw env is parsed centrally in
    app/bootstrap/config.py — this reads the parsed default only.
    """
    from app.bootstrap.config import EnvDefaults
    return bool(EnvDefaults.from_env().website_monetag_enabled)


# Startup diagnostics / status endpoint (spec §21: admins must be able to
# see that the website ad tag is missing; the provider tag is required).
MONETAG_STATUS_PATH = "/api/website/monetag-status"

_sw_bytes_cache: Optional[bytes] = None


def load_website_sw_bytes() -> Optional[bytes]:
    """Load the provider sw.js bytes (cached). Returns None when the file
    is missing/empty — the handler then answers a plain 404 (honest)."""
    global _sw_bytes_cache
    if _sw_bytes_cache is None:
        try:
            with open(SW_STATIC_FILE, "rb") as fh:
                data = fh.read()
            if data.strip():
                _sw_bytes_cache = data
        except Exception:  # noqa: BLE001 — never crash on a static read
            logger.warning("MONETAG WEBSITE: sw.js static file unreadable (%s)",
                           SW_STATIC_FILE, exc_info=True)
            return None
    return _sw_bytes_cache


async def handle_website_sw_js(request: Any) -> Any:
    """GET /sw.js — the Monetag WEBSITE service worker, EXACT provider
    bytes, no auth (public by definition), ``application/javascript``.

    ``Cache-Control: no-store`` so a redeployed provider worker is picked
    up on the next navigation instead of a stale cached copy (max-age=600
    would also be acceptable; no-store is the safest for updates).

    BOT-26 diagnostic (WEBSITE_MONETAG_ENABLED=false): while the Monetag
    website surface is DISABLED the provider bytes are NOT served — the
    DIAGNOSTIC NO-OP worker is answered instead (self-unregistering, so
    a previously-registered third-party worker is actively removed from
    controlling clients). This is the only path that ever replaces the
    provider bytes, and it exists strictly behind the diagnostic flag.
    """
    if _aiohttp_web is None:  # pragma: no cover — guarded import parity
        return _aiohttp_web.Response(status=503)  # type: ignore[union-attr]
    if not website_monetag_enabled():
        return _aiohttp_web.Response(
            body=DIAGNOSTIC_NOOP_SW_BYTES,
            content_type="application/javascript",
            headers={
                "Cache-Control": "no-store",
                "X-Content-Type-Options": "nosniff",
            })
    data = load_website_sw_bytes()
    if data is None:
        return _aiohttp_web.Response(status=404, text="sw.js unavailable")
    return _aiohttp_web.Response(
        body=data,
        content_type="application/javascript",
        headers={
            "Cache-Control": "no-store",
            "X-Content-Type-Options": "nosniff",
        })


# ------------------------------------------------- website ad tag (§21)
WEBSITE_MONETAG_AD_TAG_KEY = "website_monetag_ad_tag"
WEBSITE_MONETAG_AD_TAG_ENV = "WEBSITE_MONETAG_AD_TAG"
WEBSITE_AD_TAG_MAX_CHARS = 4096

_NOT_CONFIGURED_MESSAGE = (
    "website ad tag: NOT CONFIGURED (provider tag required)")

# §19/§21 separation guards: the WEBSITE ad tag must be a DIFFERENT zone
# from the two known zones of this deployment (11742509 = the Telegram
# Mini App TMA zone rendered on /watch-ad/{token}; 11800971 = the website
# service-worker zone already deployed at /sw.js) and must never load the
# TMA SDK surface (libtl.com) into the website.
_FORBIDDEN_ZONES = ("11742509", "11800971")
_FORBIDDEN_TMA_HOST = "libtl.com"

_SCRIPT_TAG_RE = re.compile(r"<script\b[^>]*>.*?</script\s*>",
                            re.IGNORECASE | re.DOTALL)


def validate_website_ad_tag(raw: Optional[str]) -> Tuple[Optional[str], str]:
    """Validation for the operator-supplied Monetag WEBSITE ad tag.

    The tag is UNTRUSTED CONFIGURATION (same trust model as
    ``watch_ads_monetag_sdk``):
      * rejected when empty / above WEBSITE_AD_TAG_MAX_CHARS / NUL bytes;
      * must be ONLY ``<script ...>...</script>`` tags (+ whitespace) —
        no other markup can ride along;
      * every ``src`` must be https:// or protocol-relative // (never
        plain http:, javascript:, data:);
      * §19/§21 separation: rejects libtl.com (the TMA SDK host) and the
        known zones 11742509 (TMA) / 11800971 (website SW) — the website
        ad tag must come from the provider account as its own zone;
      * NEVER executed during validation, NEVER logged in full.
    Returns (accepted_tag, "") or (None, error_message).
    """
    if raw is None:
        return None, "Website ad tag is empty."
    tag = raw.strip()
    if not tag:
        return None, "Website ad tag is empty."
    if len(tag) > WEBSITE_AD_TAG_MAX_CHARS:
        return None, ("Website ad tag is too large "
                      f"({len(tag)} chars, max {WEBSITE_AD_TAG_MAX_CHARS}).")
    if "\x00" in tag:
        return None, "Website ad tag contains invalid characters."
    lowered = tag.lower()
    # ---- §19/§21 separation guards (checked BEFORE structure so a
    # wrong-surface tag is never partially accepted) -------------------
    if _FORBIDDEN_TMA_HOST in lowered:
        return None, ("libtl.com is the Telegram Mini App SDK surface "
                      "(spec §19) — it must not load on the website.")
    for zone in _FORBIDDEN_ZONES:
        if re.search(rf"data-zone\s*=\s*[\"']?{zone}\b", lowered) \
                or re.search(rf"\bzone[_-]?(?:id)?\s*[:=]\s*[\"']?{zone}\b",
                             lowered):
            return None, (f"Zone {zone} belongs to an existing surface "
                          "(TMA SDK / website service worker) — the website "
                          "ad tag must be its own provider zone.")
    # ---- structure: ONLY <script> tags --------------------------------
    matches = list(_SCRIPT_TAG_RE.finditer(tag))
    if not matches:
        return None, ("Invalid Monetag website tag — no <script> tag found "
                      "(the raw provider tag is required).")
    remainder = _SCRIPT_TAG_RE.sub("", tag).strip()
    if remainder:
        return None, ("Invalid Monetag website tag — only <script> tags are "
                      "allowed in the website ad tag.")
    # ---- script sources: https / protocol-relative only ----------------
    for m in re.finditer(r"<script\b[^>]*>", tag, re.IGNORECASE):
        attrs = m.group(0)
        src = re.search(r"\bsrc\s*=\s*[\"']([^\"']+)[\"']", attrs,
                        re.IGNORECASE)
        if not src:
            continue  # inline provider script (operator-supplied)
        value = src.group(1).strip()
        if not (value.startswith("https://") or value.startswith("//")):
            return None, ("Script src must be https:// (or protocol-relative "
                          f"//) — rejected: scheme of {value[:32]!r}.")
    return tag, ""


def _env_website_ad_tag() -> Optional[str]:
    # BOT-13 RULE F: env parsing centralized in app/bootstrap/config.py —
    # this module reads the parsed default, never the raw env directly.
    from app.bootstrap.config import EnvDefaults
    raw = str(EnvDefaults.from_env().website_monetag_ad_tag or "").strip()
    return raw or None


async def resolve_website_monetag_ad_tag(
        db_getter: Optional[Callable[[], Any]] = None
) -> Tuple[Optional[str], Optional[str]]:
    """Resolve the configured website ad tag.

    Precedence: the generic settings-store row ``website_monetag_ad_tag``
    (admin-configurable, same mechanism as every other website setting)
    wins; the ``WEBSITE_MONETAG_AD_TAG`` env is the fallback. Returns
    ``(tag, source)`` — ``(None, None)`` when not configured (then
    NOTHING is injected anywhere).

    The DB read happens per rendered /site HTML page (one indexed SELECT
    — the same order of cost the page render already pays repeatedly);
    no cache, so an admin change applies to the very next request.
    """
    db = None
    try:
        if db_getter is not None:
            db = db_getter()
    except Exception:  # noqa: BLE001
        db = None
    if db is not None:
        try:
            raw = await db.get_setting(WEBSITE_MONETAG_AD_TAG_KEY)
        except Exception:  # noqa: BLE001 — config failure never blocks
            logger.warning("MONETAG WEBSITE: ad-tag setting read failed",
                           exc_info=True)
            raw = None
        if isinstance(raw, str) and raw.strip():
            tag, err = validate_website_ad_tag(raw)
            if tag is not None:
                return tag, "db"
            logger.warning("MONETAG WEBSITE: stored ad tag rejected (%s)",
                           err)
            return None, "invalid"
    env_tag = _env_website_ad_tag()
    if env_tag:
        tag, err = validate_website_ad_tag(env_tag)
        if tag is not None:
            return tag, "env"
        logger.warning("MONETAG WEBSITE: env ad tag rejected (%s)", err)
    return None, None


def website_monetag_head_html(tag: Optional[str]) -> str:
    """The exact HTML fragment injected into the /site pages' <head>
    (the position the renderer's ``head_extra`` mechanism occupies —
    immediately before ``</head>``). Empty string when unconfigured."""
    if not tag:
        return ""
    return "<!-- Monetag website ad tag (operator-configured) -->\n" + tag


async def website_monetag_diagnostics(
        db_getter: Optional[Callable[[], Any]] = None
) -> Dict[str, Any]:
    """Admin diagnostics for the Monetag WEBSITE surface (spec §21).

    Never returns the raw tag and never any secret — only
    configured/not-configured, the source and the surface wiring.
    BOT-26: also reports the WEBSITE_MONETAG_ENABLED master-switch state
    so an operator can confirm the diagnostic isolation from the status
    endpoint (and from the startup log)."""
    enabled = website_monetag_enabled()
    tag, source = (None, None) if not enabled else \
        await resolve_website_monetag_ad_tag(db_getter)
    sw_bytes = load_website_sw_bytes()
    if not enabled:
        message = ("website ad tag: DISABLED (WEBSITE_MONETAG_ENABLED is "
                   "false — diagnostic isolation: no ad tag injected, "
                   "/sw.js serves the self-unregistering no-op worker)")
    elif tag:
        message = f"website ad tag: configured (source={source})"
    elif source == "invalid":
        message = ("website ad tag: INVALID (stored value rejected by "
                   "validation — provider tag required)")
    else:
        message = _NOT_CONFIGURED_MESSAGE
    return {
        "ok": True,
        "service": "monetag-website",
        "enabled": enabled,
        "service_worker": {
            "path": SW_PATH,
            "available": sw_bytes is not None,
            "bytes": len(sw_bytes) if sw_bytes is not None else 0,
            "scope": "/",
            "note": ("provider bytes served verbatim at the domain root "
                     "(spec §20)" if enabled else
                     "DIAGNOSTIC MODE: the self-unregistering no-op "
                     "worker is served while WEBSITE_MONETAG_ENABLED is "
                     "disabled"),
        },
        "website_ad_tag": {
            "configured": bool(tag),
            "source": source if tag else None,
            "message": message,
        },
        "tma_separation": {
            "watch_ads_sdk_setting": "watch_ads_monetag_sdk",
            "renders_on": "GET /watch-ad/{token} only",
            "note": ("the libtl.com TMA SDK (zone 11742509) is the Mini App "
                     "surface and never loads on /site (spec §19)"),
        },
    }


def make_monetag_status_handler(
        db_getter: Callable[[], Any]) -> Callable[[Any], Any]:
    """Build the GET /api/website/monetag-status handler bound to a
    db getter (the legacy namespace ``db`` in production)."""
    async def _handle(request: Any) -> Any:
        if _aiohttp_web is None:  # pragma: no cover
            return _aiohttp_web.json_response({"ok": False}, status=503)  # type: ignore[union-attr]
        try:
            diag = await website_monetag_diagnostics(db_getter)
            return _aiohttp_web.json_response(diag)
        except Exception:  # noqa: BLE001 — diagnostics never crash
            logger.warning("MONETAG WEBSITE: status endpoint failed",
                           exc_info=True)
            return _aiohttp_web.json_response(
                {"ok": False, "error": "diagnostics_failed"}, status=500)
    return _handle


# --------------------------------------------- head-injection middleware
_HEAD_CLOSE_RE = re.compile(r"</head\s*>", re.IGNORECASE)
_SKIP_RESPONSE_HEADERS = frozenset({
    "content-length", "content-type", "transfer-encoding"})


def make_website_monetag_middleware(
        db_getter: Callable[[], Any]) -> Any:
    """aiohttp middleware: inject the configured Monetag WEBSITE ad tag
    into the <head> of /site HTML pages (spec §21).

    Surgical by design:
      * ONLY paths ``/site`` and ``/site/...`` (the website surface — the
        Watch Ads Mini App /watch-ad pages and every API are untouched);
      * ONLY 200 responses with content type text/html (media streams,
        zip packs, JSON APIs and redirects pass through untouched — no
        body is ever read for them, so nothing is buffered);
      * NOTHING injected when the tag is unset;
      * any failure degrades to the ORIGINAL response (an ads
        configuration problem can never block content — spec §44 parity).
    """
    if _aiohttp_web is None:  # pragma: no cover
        return None

    async def _inject_ad_tag(request: Any, handler: Any):
        response = await handler(request)
        try:
            # BOT-26 diagnostic: while WEBSITE_MONETAG_ENABLED is false the
            # third-party website-ad layer is fully isolated — NOTHING is
            # injected (the configured tag, if any, stays untouched in
            # the settings store and resumes when re-enabled).
            if not website_monetag_enabled():
                return response
            path = request.path
            if not (path == "/site" or path.startswith("/site/")):
                return response
            if path.startswith("/site/api/") or path.startswith("/site/pack/"):
                return response  # JSON APIs / bounded downloads — pages only
            if getattr(response, "status", None) != 200:
                return response
            ctype = str(response.content_type or "")
            if ctype != "text/html":
                return response
            tag, _source = await resolve_website_monetag_ad_tag(db_getter)
            if not tag:
                return response
            # aiohttp's server-side web.Response exposes the decoded body
            # via the .text PROPERTY (str); anything else (e.g. a streamed
            # FileResponse) is not rewritable text — pass it through.
            html = getattr(response, "text", None)
            if not isinstance(html, str):
                return response
            m = _HEAD_CLOSE_RE.search(html)
            if m is None:
                return response
            fragment = website_monetag_head_html(tag)
            new_html = html[:m.start()] + fragment + "\n" + html[m.start():]
            out = _aiohttp_web.Response(
                status=200,
                body=new_html.encode("utf-8"),
                content_type="text/html",
                charset="utf-8")
            for key, value in response.headers.items():
                if key.lower() in _SKIP_RESPONSE_HEADERS:
                    continue
                out.headers.setdefault(key, value)
            return out
        except Exception:  # noqa: BLE001 — NEVER block content
            logger.debug("MONETAG WEBSITE: head injection skipped",
                         exc_info=True)
            return response

    return _aiohttp_web.middleware(_inject_ad_tag)


# ----------------------------------------------- origin proxy secret (§24-§28)
ORIGIN_PROXY_SECRET_ENV = "ORIGIN_PROXY_SECRET"
ORIGIN_PROXY_HEADER = "X-Origin-Key"


# -------------------------- dynamic /site HTML cache hardening (BOT-26 §7)
# The production-fix brief §7: dynamically generated website HTML under
# /site and /site/* must not be served stale by an intermediary (the
# Telegram Android WebView, the Cloudflare worker proxy, or any shared
# cache). Every /site page is rendered per-request (session-aware chrome,
# force-join state, shelves) — there is NO representation that is valid to
# reuse, so the correct header contract for dynamic HTML is:
SITE_HTML_CACHE_CONTROL = "no-store, no-cache, must-revalidate, max-age=0"

_SITE_HTML_PATHS_EXACT = frozenset({"/site", "/site/"})


def make_site_html_cache_middleware() -> Any:
    """aiohttp middleware: harden the cache contract of DYNAMIC /site HTML.

    Surgical by design (BOT-26 §7 — "Do not apply aggressive no-store
    headers to static assets unless there is a demonstrated reason"):
      * ONLY paths ``/site`` and ``/site/...`` (the website surface);
      * ONLY responses whose content type is ``text/html`` — media
        streams, HLS playlists/segments, thumbs, zip packs and every
        JSON API keep their own content-appropriate cache headers;
      * ``Cache-Control: no-store, no-cache, must-revalidate, max-age=0``
        + ``Pragma: no-cache`` are set (replacing any weaker value the
        handler might have set — no /site HTML handler ever sets a
        deliberate caching policy, the pages are per-request renders);
      * any failure degrades to the ORIGINAL response (cache policy can
        never block content — spec §44 parity).

    Middleware ORDER note (app/web/server.py): this middleware is
    registered AFTER the Monetag head-injection middleware in the
    application's list, which makes it the INNERMOST — it decorates the
    handler response BEFORE the Monetag middleware rebuilds it, so the
    rebuilt response carries these headers through the header copy.
    """
    if _aiohttp_web is None:  # pragma: no cover
        return None

    async def _harden_site_html_cache(request: Any, handler: Any):
        response = await handler(request)
        try:
            path = request.path
            is_site_html_path = (path in _SITE_HTML_PATHS_EXACT
                                 or path.startswith("/site/"))
            if not is_site_html_path:
                return response
            if getattr(response, "status", None) != 200:
                return response
            ctype = str(response.content_type or "")
            if ctype != "text/html":
                return response
            response.headers["Cache-Control"] = SITE_HTML_CACHE_CONTROL
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
            return response
        except Exception:  # noqa: BLE001 — never block content
            logger.debug("site HTML cache hardening skipped", exc_info=True)
            return response

    return _aiohttp_web.middleware(_harden_site_html_cache)


def make_origin_proxy_middleware(secret: Optional[str] = None,
                                header_name: str = ORIGIN_PROXY_HEADER
                                ) -> Any:
    """Optional origin shared-secret guard (spec §24-§28, WS-B).

    When the ``ORIGIN_PROXY_SECRET`` env is set (or a secret is passed
    explicitly), every request must carry the matching ``X-Origin-Key``
    header or it is rejected with 403 — so the public origin can refuse
    anything that did not come through the Cloudflare worker (which
    injects the header from its own ``ORIGIN_PROXY_SECRET`` secret).

    Default (env unset): returns None — the guard is NOT installed and
    the server behaves exactly as before (zero behavior change)."""
    if _aiohttp_web is None:  # pragma: no cover
        return None
    if secret is None:
        # BOT-13 RULE F: env parsing centralized in bootstrap/config.py.
        from app.bootstrap.config import EnvDefaults
        secret = str(EnvDefaults.from_env().origin_proxy_secret or "").strip()
    if not secret:
        return None

    @_aiohttp_web.middleware
    async def _origin_guard(request: Any, handler: Any):
        supplied = request.headers.get(header_name, "")
        if not hmac.compare_digest(supplied.encode("utf-8", "replace"),
                                   secret.encode("utf-8", "replace")):
            return _aiohttp_web.json_response(
                {"error": "forbidden"}, status=403)
        return await handler(request)

    return _origin_guard
