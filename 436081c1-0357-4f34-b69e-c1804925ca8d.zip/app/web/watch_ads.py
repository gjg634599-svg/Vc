"""Watch Ads web service surface (ARCHITECTURE PHASE).

The Watch Ads HTTP handlers (_wad_handle_*) and the Mini App page HTML are
source-pinned inside bot.py by the regression suites; this module is the
web-side contract home for the NEXT phase (Mini App browsing UI): the path
constants, the auth hook, and the service handle future routes will call.
No duplicate handler logic lives here.
"""
from __future__ import annotations

from app.web.routes import WATCH_AD_WEB_PATHS  # noqa: F401
from app.web import auth as web_auth  # noqa: F401

__all__ = ["WATCH_AD_WEB_PATHS", "web_auth"]
