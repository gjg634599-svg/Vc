"""WebApp authentication: Telegram initData HMAC-SHA256 validation
(Mini App + Network auth foundation)."""
from __future__ import annotations

from types import SimpleNamespace

from app.core.constants import WATCH_AD_INITDATA_MAX_AGE
from typing import Any, Dict, Optional
from urllib.parse import parse_qsl
import hashlib
import hmac
import json
import json as _json
import time


def make_web_auth_service(db, BOT_TOKEN=None):
    """Bind the verbatim implementations to explicit
    dependencies (call-time late binding - no globals)."""
    def validate_telegram_init_data(init_data: str) -> Optional[Dict[str, Any]]:
        """Validate Telegram Mini App initData (official WebAppData model).

        secret_key = HMAC_SHA256(key="WebAppData", msg=BOT_TOKEN)
        hash       = HMAC_SHA256(key=secret_key, msg=data_check_string)
        Also enforces auth_date freshness (WATCH_AD_INITDATA_MAX_AGE).
        Returns {"user_id": int, "raw": {...}} or None when invalid/expired.
        """
        if not init_data or not BOT_TOKEN or BOT_TOKEN == "PUT_YOUR_BOT_TOKEN_HERE":
            return None
        try:
            from urllib.parse import parse_qsl
            pairs = dict(parse_qsl(init_data, keep_blank_values=True))
        except Exception:  # noqa: BLE001
            return None
        received_hash = pairs.pop("hash", "")
        if not received_hash:
            return None
        auth_date = pairs.get("auth_date", "")
        if auth_date and str(auth_date).isdigit():
            if abs(time.time() - int(auth_date)) > WATCH_AD_INITDATA_MAX_AGE:
                return None
        data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calc_hash = hmac.new(secret_key, data_check_string.encode(),
                             hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calc_hash, received_hash):
            return None
        user_id = None
        try:
            user_obj = json.loads(pairs.get("user") or "{}")
            user_id = int(user_obj.get("id") or 0) or None
        except Exception:  # noqa: BLE001
            user_id = None
        if not user_id:
            return None
        return {"user_id": user_id, "raw": pairs}

    def _validate_webapp_init_data(init_data: str,
                                   bot_token: str,
                                   max_age_seconds: int = 86400
                                   ) -> Optional[Dict[str, Any]]:
        """NETWORK (N5, spec §49): OFFICIAL Telegram WebApp initData validation.

        Verifies the HMAC-SHA256 signature exactly as documented by Telegram:
          secret_key = HMAC_SHA256(bot_token, "WebAppData")
          received   = hex(HMAC_SHA256(secret_key, data_check_string))
        where data_check_string is every initData field EXCEPT hash, sorted,
        joined with '\\n'. Also enforces auth_date freshness. Returns the
        parsed user dict on success, None on ANY failure (never trusts
        browser-supplied identities).
        """
        if not init_data or not bot_token:
            return None
        try:
            from urllib.parse import parse_qsl
            pairs = parse_qsl(init_data, keep_blank_values=True)
            fields = {}
            recv_hash = None
            for k, v in pairs:
                if k == "hash":
                    recv_hash = v
                else:
                    fields[k] = v
            if not recv_hash or "auth_date" not in fields:
                return None
            dcs = "\n".join(f"{k}={v}" for k, v in sorted(fields.items()))
            secret = hmac.new(b"WebAppData", bot_token.encode("utf-8"),
                              hashlib.sha256).digest()
            calc = hmac.new(secret, dcs.encode("utf-8"),
                            hashlib.sha256).hexdigest()
            if not hmac.compare_digest(calc, recv_hash):
                return None
            auth_age = time.time() - int(fields["auth_date"])
            if auth_age > max_age_seconds or auth_age < -300:
                return None
            import json as _json
            user = {}
            if fields.get("user"):
                user = _json.loads(fields["user"])
            return {"user": user, "auth_date": int(fields["auth_date"]),
                    "raw_fields": {k: v for k, v in fields.items()
                                   if k != "user"}}
        except Exception:  # noqa: BLE001 — any malformed input fails closed
            return None

    return SimpleNamespace(
        validate_telegram_init_data=validate_telegram_init_data,
        _validate_webapp_init_data=_validate_webapp_init_data,
    )
