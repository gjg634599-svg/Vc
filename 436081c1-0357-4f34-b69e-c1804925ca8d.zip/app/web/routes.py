"""Web route registry (ARCHITECTURE PHASE).

The pinned legacy route REGISTRATION lines remain in bot.py
(start_mini_app_server — see docs/ARCHITECTURE_AUDIT.md §3); this module is
the canonical machine-readable table used by architecture tests and by the
next phase's web modules.
"""
from __future__ import annotations

# (method, path, legacy handler name)
WEB_ROUTES: tuple[tuple[str, str, str], ...] = (
    ("GET", "/watch-ad/{token}", "_wad_handle_page"),
    ("POST", "/api/network/auth", "_net_handle_webapp_auth"),
    ("POST", "/api/watch-ad/status", "_wad_handle_status"),
    ("POST", "/api/watch-ad/ad-event", "_wad_handle_ad_event"),
    ("GET", "/api/watch-ad/postback", "_wad_handle_postback"),
    ("GET", "/healthz", "_wad_handle_health"),
)

WATCH_AD_WEB_PATHS = frozenset({
    "/watch-ad/{token}", "/api/watch-ad/status",
    "/api/watch-ad/ad-event", "/api/watch-ad/postback",
})

HEALTH_PATH = "/healthz"
NETWORK_AUTH_PATH = "/api/network/auth"

# MONETAG WEBSITE (WS-B — spec §20/§21): the provider service worker at
# the DOMAIN ROOT (root scope — required by the Monetag website
# integration; served VERBATIM by app/web/website_monetag.py) and the
# website ad-tag diagnostics endpoint (reports configured /
# NOT CONFIGURED without leaking the raw tag).
WEBSITE_MONETAG_SW_PATH = "/sw.js"
WEBSITE_MONETAG_STATUS_PATH = "/api/website/monetag-status"
