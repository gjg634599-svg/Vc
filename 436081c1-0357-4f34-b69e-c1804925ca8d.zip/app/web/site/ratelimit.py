"""WEBSITE PHASE 3/4 — bounded in-process rate limiting for Website endpoints.

Same design as the proven ``_wad_status_ratelimit`` precedent (in-process
dict + pruning) but generalized to named buckets with sliding windows.
Protects: Mini App auth, Website search, Website API, Payload detail and
(the Phase 3 admin-side website actions reuse the Telegram-side admin rate
limits that already exist). Bounds are deliberately generous so normal
Website navigation is never blocked; abuse is.

WEBSITE PHASE 4 adds the STREAMING buckets (spec §28): stream-token
issuance, stream requests (browsers issue MANY legitimate Range requests
while seeking — the bound is high enough that real seeking is never
broken), thumbnails, plus a per-IP CONCURRENT stream cap (a counting
semaphore — released when the response finishes or the client
disconnects).
"""
from __future__ import annotations

import time
from collections import deque
from typing import Deque, Dict, Tuple

# Bucket defaults: (max_events, window_seconds).
_RATE_BUCKETS: Dict[str, Tuple[int, int]] = {
    "site_page": (60, 60),      # feed / search / detail browsing
    "site_video": (30, 60),     # payload video selection page
    "site_auth": (10, 60),      # Mini App initData validation
    "site_access": (20, 60),    # access verdict API
    # PHASE 4 streaming surface:
    "site_stream_issue": (30, 60),   # stream-token issuance
    "site_stream": (240, 60),        # gateway requests (seeking = ranges)
    "site_thumb": (120, 60),         # thumbnail bytes
    # GAP-CLOSURE: session/login, FJ recheck, ads API, pack API.
    "site_session": (15, 60),        # login + identity verification
    "site_fj_verify": (20, 60),      # Force Join Verify Again
    "site_ads_api": (60, 60),        # ad decisions + events
    "site_pack": (6, 60),            # download-pack start + fetch
    # BOT-11 (spec §15): the Website Get File random-delivery API —
    # generous enough that multi-click distribution (a NEW mint per
    # click beyond the 2s per-user guard) is never blocked, tight enough
    # that mint-spam is bounded.
    "site_getfile": (30, 60),
    # B18-FINAL (bot-22.log pass): media engagement (view pings + reactions)
    # and the external-browser handoff. View pings are one-per-page-view
    # (player fires once after the playback threshold); reactions are
    # user-bounded separately in engagement.py — the IP bound stops
    # trivial abuse only, never normal use.
    "site_engage": (60, 60),
    # Handoff mint + consume: single-tap actions; tight by design.
    "site_ext": (12, 60),
}

# Hard cap on tracked keys (the watch-ad precedent's pruning discipline).
_MAX_TRACKED_KEYS = 5000

# PHASE 4: per-IP concurrent open streams (counting semaphore).
MAX_CONCURRENT_STREAMS_PER_IP = 6
_concurrent_streams: Dict[str, int] = {}

_events: Dict[str, Deque[float]] = {}


def _prune(now: float) -> None:
    if len(_events) <= _MAX_TRACKED_KEYS:
        return
    # Drop idle buckets wholesale (oldest-last-seen first).
    stale = []
    for key, dq in _events.items():
        if not dq or now - dq[-1] > 300:
            stale.append(key)
    for key in stale:
        _events.pop(key, None)
    if len(_events) > _MAX_TRACKED_KEYS:
        # Still too many: clear the oldest half entirely (bounded memory,
        # worst case an attacker's buckets reset — acceptable + documented).
        for key in list(_events.keys())[: len(_events) // 2]:
            _events.pop(key, None)


def check_rate(bucket: str, key: str, *, now: float = None) -> bool:
    """True when the event is allowed. Sliding window per (bucket, key)."""
    now = time.time() if now is None else now
    if bucket not in _RATE_BUCKETS:
        bucket = "site_page"
    max_events, window = _RATE_BUCKETS[bucket]
    k = f"{bucket}:{key}"
    dq = _events.get(k)
    if dq is None:
        dq = deque(maxlen=max_events)
        _events[k] = dq
    while dq and now - dq[0] > window:
        dq.popleft()
    if len(dq) >= max_events:
        return False
    dq.append(now)
    _prune(now)
    return True


def begin_stream(key: str, *, limit: int = MAX_CONCURRENT_STREAMS_PER_IP
                 ) -> bool:
    """True when a new concurrent stream slot was acquired for ``key``."""
    n = _concurrent_streams.get(key, 0)
    if n >= limit:
        return False
    _concurrent_streams[key] = n + 1
    return True


def end_stream(key: str) -> None:
    """Release one concurrent stream slot (always pairs with begin_stream
    in a finally block — disconnects included)."""
    n = _concurrent_streams.get(key, 0)
    if n <= 1:
        _concurrent_streams.pop(key, None)
    else:
        _concurrent_streams[key] = n - 1


def concurrent_streams(key: str) -> int:
    return _concurrent_streams.get(key, 0)


def reset_all() -> None:
    """Test helper: clear every tracked bucket + stream slot."""
    _events.clear()
    _concurrent_streams.clear()
