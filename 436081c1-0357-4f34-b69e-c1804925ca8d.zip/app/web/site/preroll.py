"""WEBSITE VIDEO PRE-ROLL ADS — server-side config + policy (Task 9).

A dedicated, YouTube-style pre-roll system for the website video player
(``/site/payload/{opaque}/video/{ref}``), SEPARATE from:

  * the centralized Ads Platform (app/ads/service.py — campaigns/creatives,
    ``AD_VIDEO_BEFORE`` placement): that system keeps working unchanged;
  * the Monetag WEBSITE Rich Tag (app/web/website_monetag.py head
    injection) and the TMA Watch Ads SDK (libtl.com zone 11742509):
    both are untouched by this module;
  * the legacy ``_preroll_script`` state machine injected by pages.py for
    Ads-Platform creatives: it keeps working; when THIS system is active
    for a playback the player suppresses the legacy stage for that one
    playback (single pre-roll UX, never two stacked pre-rolls).

All configuration lives in the EXISTING ``bot_settings`` store (same
mechanism as ``website_enabled`` / ``website_monetag_ad_tag`` — admin
panel writes, live reads). Every decision is made SERVER-side:

  * the admin panel (wspr: namespace) validates and writes settings;
  * ``PreRollPolicy.resolve`` reads them, applies the frequency policy
    and returns the payload the player consumes through the EXISTING
    stream-issuance response (POST /site/api/stream — the single
    authenticated playback-metadata call the player page already makes);
  * FREQUENCY ACCOUNTING IS SERVER-SIDE ONLY. There is NO endpoint that
    accepts a client ``adCompleted``-style claim, and none ever changes
    the frequency state: the serve is recorded at DECISION time
    (issuance), keyed by the AUTHENTICATED Telegram user id. Frontend
    timers/flags are UX ONLY.

Frequency state storage (honest, bounded, documented): a module-level
TTL map keyed by ``(kind, authenticated user id, session key)`` — the
same style the codebase uses for in-memory rate limiting
(app/web/site/ratelimit.py). Entries expire after
``_FREQUENCY_STATE_TTL_SECONDS`` (6h) and the map is pruned on every
record, so it stays bounded. A day rollover resets session counts
(bounded honesty — a browser session spanning midnight gets a fresh
count). Anonymous callers (user_id None — impossible on the stream
endpoint, which requires verified initData) are never tracked.

The pre-roll AD MEDIA itself: the admin configures an ABSOLUTE https://
URL (``website_preroll_source_url``) pointing at any hosted .mp4/.webm
(or any https URL the player may attempt). This deployment intentionally
does NOT proxy ad media through the authenticated media gateway — that
chain is for CONTENT tokens only and must not be weakened. VAST/VMAP
(``website_preroll_vast_url``) is validated + stored as a FUTURE HOOK
ONLY: no VAST internals are fabricated or parsed here; while no
server-side VAST adapter exists, a VAST URL alone never activates a
pre-roll (the policy honestly reports ``not_configured`` until a direct
media source URL is set).
"""
from __future__ import annotations

import logging
import re
import time
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger("payload-bot")

# ------------------------------------------------------------------ keys
PREROLL_ENABLED_KEY = "website_preroll_enabled"
PREROLL_MODE_KEY = "website_preroll_mode"
PREROLL_SKIP_DELAY_KEY = "website_preroll_skip_delay"
PREROLL_DURATION_KEY = "website_preroll_duration"
PREROLL_SOURCE_URL_KEY = "website_preroll_source_url"
PREROLL_VAST_URL_KEY = "website_preroll_vast_url"
PREROLL_FREQUENCY_KEY = "website_preroll_frequency"
PREROLL_SESSION_FREQUENCY_KEY = "website_preroll_session_frequency"
PREROLL_COOLDOWN_KEY = "website_preroll_cooldown"
PREROLL_FALLBACK_KEY = "website_preroll_fallback"

# Defaults + clamps (single source of truth for the admin panel too).
PREROLL_MODES = ("skippable", "non_skippable")
PREROLL_FREQ_MODES = ("every_video", "session", "cooldown")
PREROLL_FALLBACKS = ("release", "block")

PREROLL_DEFAULT_ENABLED = "0"
PREROLL_DEFAULT_MODE = "skippable"
PREROLL_DEFAULT_SKIP_DELAY = 5
PREROLL_SKIP_DELAY_MIN = 1
PREROLL_SKIP_DELAY_MAX = 30
PREROLL_DEFAULT_DURATION = 15
PREROLL_DURATION_MIN = 5
PREROLL_DURATION_MAX = 120
PREROLL_DEFAULT_FREQUENCY = "every_video"
PREROLL_DEFAULT_SESSION_FREQUENCY = 1
PREROLL_SESSION_FREQUENCY_MIN = 1
PREROLL_SESSION_FREQUENCY_MAX = 10
PREROLL_DEFAULT_COOLDOWN = 300
PREROLL_COOLDOWN_MIN = 30
PREROLL_COOLDOWN_MAX = 86400
PREROLL_DEFAULT_FALLBACK = "release"

_URL_MAX_CHARS = 2048
# A plausible https media URL: scheme + host; optional path/query. The
# player is allowed to ATTEMPT any https URL (the honest failure path
# then applies the configured fallback) — but obvious garbage (spaces,
# control chars, javascript:/data:/file:/http:) is rejected on save.
_HTTPS_URL_RE = re.compile(
    r"^https://[A-Za-z0-9._~%-]+(?::[0-9]{1,5})?"
    r"(?:/[A-Za-z0-9._~%!$&'()*+,;=:@/-]*)?"
    r"(?:\?[A-Za-z0-9._~%!$&'()*+,;=:@/?-]*)?$")


def _clamp(value: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, int(value)))


def validate_preroll_source_url(raw: Any) -> Tuple[Optional[str], str]:
    """Validation for the admin-supplied pre-roll AD media URL.

    Accepts an ABSOLUTE https:// URL (a hosted .mp4/.webm or any https
    URL the player may attempt — the honest failure path covers the
    rest). Rejects empty input, http:// (plaintext), javascript:/data:/
    file:, non-URLs and control characters. NEVER fetches the URL and
    NEVER fabricates provider endpoints/zone ids. Returns
    (normalized_url, "") or (None, error_message)."""
    if raw is None:
        return None, "The ad source URL is empty."
    url = str(raw).strip()
    if not url:
        return None, "The ad source URL is empty."
    if len(url) > _URL_MAX_CHARS:
        return None, (f"The ad source URL is too long ({len(url)} chars, "
                      f"max {_URL_MAX_CHARS}).")
    if any(ch in url for ch in "\x00\r\n\t"):
        return None, "The ad source URL contains invalid characters."
    lowered = url.lower()
    for bad in ("javascript:", "data:", "file:", "http:", "ftp:",
                "ws:", "wss:"):
        if lowered.startswith(bad):
            return None, ("The ad source URL must be an absolute https:// "
                          f"URL ({bad[:-1]} is not allowed).")
    if not lowered.startswith("https://"):
        return None, ("The ad source URL must be an absolute https:// URL "
                      "pointing at a hosted .mp4/.webm (or any https URL "
                      "the player can attempt).")
    if not _HTTPS_URL_RE.match(url):
        return None, ("The ad source URL is not a valid https URL "
                      "(host required).")
    return url, ""


def validate_preroll_vast_url(raw: Any) -> Tuple[Optional[str], str]:
    """Validation for the FUTURE-HOOK VAST/VMAP URL (https-only).

    The URL is validated and stored ONLY — no VAST XML is fabricated or
    parsed anywhere in this deployment; while no server-side VAST adapter
    exists, a VAST URL alone never activates a pre-roll."""
    url, err = validate_preroll_source_url(raw)
    if url is None:
        return None, err.replace("ad source URL", "VAST/VMAP URL")
    return url, ""


def clamp_skip_delay(value: Any) -> int:
    try:
        return _clamp(int(str(value).strip()), PREROLL_SKIP_DELAY_MIN,
                      PREROLL_SKIP_DELAY_MAX)
    except (TypeError, ValueError):
        return PREROLL_DEFAULT_SKIP_DELAY


def clamp_duration(value: Any) -> int:
    try:
        return _clamp(int(str(value).strip()), PREROLL_DURATION_MIN,
                      PREROLL_DURATION_MAX)
    except (TypeError, ValueError):
        return PREROLL_DEFAULT_DURATION


def clamp_session_frequency(value: Any) -> int:
    try:
        return _clamp(int(str(value).strip()), PREROLL_SESSION_FREQUENCY_MIN,
                      PREROLL_SESSION_FREQUENCY_MAX)
    except (TypeError, ValueError):
        return PREROLL_DEFAULT_SESSION_FREQUENCY


def clamp_cooldown(value: Any) -> int:
    try:
        return _clamp(int(str(value).strip()), PREROLL_COOLDOWN_MIN,
                      PREROLL_COOLDOWN_MAX)
    except (TypeError, ValueError):
        return PREROLL_DEFAULT_COOLDOWN


def normalize_mode(value: Any) -> str:
    v = str(value or "").strip().lower().replace("-", "_")
    if v in ("non_skippable", "nonskippable", "blocked"):
        return "non_skippable"
    return "skippable"


def normalize_frequency(value: Any) -> str:
    v = str(value or "").strip().lower()
    if v in ("session", "per_session"):
        return "session"
    if v in ("cooldown", "cool_down"):
        return "cooldown"
    return "every_video"


def normalize_fallback(value: Any) -> str:
    return "block" if str(value or "").strip().lower() == "block" \
        else "release"


def is_enabled_value(value: Any) -> bool:
    return str(value or "").strip().lower() in ("1", "true", "yes", "on")


# ------------------------------------------------- server-side frequency
# Module-level TTL map (documented above). Keys:
#   ("sess", user_id, session_key) -> {"count": int, "day": "YYYYMMDD",
#                                       "ts": float}
#   ("cd", user_id, "")            -> {"last": float, "ts": float}
_FREQUENCY_STATE: Dict[Tuple[str, int, str], Dict[str, Any]] = {}
_FREQUENCY_STATE_TTL_SECONDS = 6 * 3600.0
_FREQUENCY_STATE_MAX_ENTRIES = 20000


def _day_key(now: Optional[float] = None) -> str:
    import datetime as _dt
    t = _dt.datetime.fromtimestamp(
        now if now is not None else time.time(), _dt.timezone.utc)
    return t.strftime("%Y%m%d")


def _prune_frequency_state(now: float) -> None:
    """Bounded housekeeping: drop entries older than the TTL; if the hard
    cap is somehow exceeded, drop the oldest until back under the cap."""
    stale = [k for k, v in _FREQUENCY_STATE.items()
             if now - float(v.get("ts") or 0) > _FREQUENCY_STATE_TTL_SECONDS]
    for k in stale:
        _FREQUENCY_STATE.pop(k, None)
    if len(_FREQUENCY_STATE) > _FREQUENCY_STATE_MAX_ENTRIES:
        oldest = sorted(_FREQUENCY_STATE.items(),
                        key=lambda kv: float(kv[1].get("ts") or 0))
        for k, _v in oldest[:len(_FREQUENCY_STATE)
                            - _FREQUENCY_STATE_MAX_ENTRIES]:
            _FREQUENCY_STATE.pop(k, None)


def reset_frequency_state() -> None:
    """Test/diagnostic hook — clears the in-memory frequency accounting.

    The production flows NEVER call this from any HTTP endpoint: there is
    deliberately NO client-reachable way to reset or decrement frequency
    state (the policy is authoritative server-side)."""
    _FREQUENCY_STATE.clear()


def _frequency_state_snapshot() -> Dict[Tuple[str, int, str], Dict[str, Any]]:
    """Read-only snapshot (tests/diagnostics only)."""
    return {k: dict(v) for k, v in _FREQUENCY_STATE.items()}


class PreRollPolicy:
    """The ONE server-side pre-roll decision point.

    ``resolve`` reads the live settings, applies validation + the
    frequency policy and returns the payload the player consumes. It
    NEVER raises: an ads configuration problem degrades to an inactive,
    truthful verdict (reason carries the honest cause) — a pre-roll can
    never block content issuance (mirrors app/ads/service.py §44).

    SECURITY: frequency is accounted HERE, at DECISION time, keyed by the
    AUTHENTICATED user id (+ the signed site-session key when present).
    No HTTP endpoint accepts an ``adCompleted``-style claim and no client
    value can rotate or decrement the accounting — the client-side
    timers/flags in the player are UX ONLY.
    """

    async def _setting(self, db: Any, key: str, default: str) -> str:
        try:
            val = await db.get_setting(key)
            if val is None:
                return default
            return str(val)
        except Exception:  # noqa: BLE001 — config failure never blocks
            return default

    def _base_payload(self, *, mode: str, skip_delay: int, duration: int,
                      source_url: str, vast_url: str, fallback: str,
                      frequency: str) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "mode": mode,
            "duration": duration,
            "source_url": source_url,
            "vast_url": vast_url,
            "fallback": fallback,
            "frequency": frequency,
        }
        # V26 Phase 5: NO skip parameters are EVER emitted to the client
        # — the player carries no Skip control or skip action, so the
        # payload never authorizes an early return from the ad (the old
        # skippable branch sent skip_delay; the player now ignores and
        # the server no longer offers it). The stored admin mode/skip
        # settings remain part of the pre-roll policy record.
        return payload

    async def resolve(self, db: Any, user_id: Optional[int],
                      session_key: Optional[str] = None
                      ) -> Dict[str, Any]:
        """Resolve the pre-roll decision for one playback issuance.

        Returns a dict with ``active`` + every parameter the player needs
        + a truthful ``reason`` ("disabled" | "not_configured" |
        "invalid_source" | "frequency_capped" | "cooldown_active" |
        "ok"). When ``active`` is True the serve has been RECORDED
        server-side (frequency accounting; ``counted`` is True for the
        session/cooldown modes)."""
        try:
            return await self._resolve_inner(db, user_id, session_key)
        except Exception as exc:  # noqa: BLE001 — never block content
            logger.warning("PREROLL_RESOLVE_ERROR err=%s",
                           type(exc).__name__)
            base = self._base_payload(
                mode=PREROLL_DEFAULT_MODE,
                skip_delay=PREROLL_DEFAULT_SKIP_DELAY,
                duration=PREROLL_DEFAULT_DURATION,
                source_url="", vast_url="", fallback=PREROLL_DEFAULT_FALLBACK,
                frequency=PREROLL_DEFAULT_FREQUENCY)
            base.update({"active": False, "reason": "resolve_error"})
            return base

    async def _resolve_inner(self, db: Any, user_id: Optional[int],
                             session_key: Optional[str]) -> Dict[str, Any]:
        enabled = is_enabled_value(
            await self._setting(db, PREROLL_ENABLED_KEY,
                                PREROLL_DEFAULT_ENABLED))
        mode = normalize_mode(
            await self._setting(db, PREROLL_MODE_KEY, PREROLL_DEFAULT_MODE))
        skip_delay = clamp_skip_delay(
            await self._setting(db, PREROLL_SKIP_DELAY_KEY,
                                str(PREROLL_DEFAULT_SKIP_DELAY)))
        duration = clamp_duration(
            await self._setting(db, PREROLL_DURATION_KEY,
                                str(PREROLL_DEFAULT_DURATION)))
        source_url = (await self._setting(db, PREROLL_SOURCE_URL_KEY,
                                          "")).strip()
        vast_url = (await self._setting(db, PREROLL_VAST_URL_KEY,
                                        "")).strip()
        frequency = normalize_frequency(
            await self._setting(db, PREROLL_FREQUENCY_KEY,
                                PREROLL_DEFAULT_FREQUENCY))
        session_frequency = clamp_session_frequency(
            await self._setting(db, PREROLL_SESSION_FREQUENCY_KEY,
                                str(PREROLL_DEFAULT_SESSION_FREQUENCY)))
        cooldown = clamp_cooldown(
            await self._setting(db, PREROLL_COOLDOWN_KEY,
                                str(PREROLL_DEFAULT_COOLDOWN)))
        fallback = normalize_fallback(
            await self._setting(db, PREROLL_FALLBACK_KEY,
                                PREROLL_DEFAULT_FALLBACK))

        base = self._base_payload(mode=mode, skip_delay=skip_delay,
                                  duration=duration, source_url=source_url,
                                  vast_url=vast_url, fallback=fallback,
                                  frequency=frequency)

        if not enabled:
            base.update({"active": False, "reason": "disabled"})
            return base
        # Render-time honesty (mirrors the Ads Platform creatives): a
        # stored URL that no longer passes validation serves NOTHING.
        if source_url:
            ok_src, _err = validate_preroll_source_url(source_url)
            if ok_src is None:
                base.update({"active": False, "reason": "invalid_source",
                             "source_url": ""})
                return base
        if not source_url:
            # Truthful: no playable media configured. A VAST URL alone is
            # a FUTURE HOOK — never an active pre-roll here.
            base.update({"active": False, "reason": "not_configured"})
            return base

        # ---- frequency (SERVER-side only; keyed by authenticated uid) --
        now = time.time()
        counted = False
        if user_id is not None:
            uid = int(user_id)
            if frequency == "session":
                skey = str(session_key or "")[:64]
                key = ("sess", uid, skey)
                rec = _FREQUENCY_STATE.get(key)
                if rec is not None and rec.get("day") != _day_key(now):
                    rec = None  # day rollover: fresh, bounded count
                if rec is not None \
                        and int(rec.get("count") or 0) >= session_frequency:
                    base.update({"active": False,
                                 "reason": "frequency_capped"})
                    return base
            elif frequency == "cooldown":
                key = ("cd", uid, "")
                rec = _FREQUENCY_STATE.get(key)
                if rec is not None:
                    age = now - float(rec.get("last") or 0)
                    if age < float(cooldown):
                        base.update({"active": False,
                                     "reason": "cooldown_active"})
                        return base

        # ---- the decision is ACTIVE: record the serve SERVER-side ------
        if user_id is not None:
            uid = int(user_id)
            if frequency == "session":
                skey = str(session_key or "")[:64]
                key = ("sess", uid, skey)
                rec = _FREQUENCY_STATE.get(key)
                if rec is None or rec.get("day") != _day_key(now):
                    rec = {"count": 0, "day": _day_key(now), "ts": now}
                rec["count"] = int(rec.get("count") or 0) + 1
                rec["ts"] = now
                _FREQUENCY_STATE[key] = rec
                counted = True
            elif frequency == "cooldown":
                key = ("cd", uid, "")
                _FREQUENCY_STATE[key] = {"last": now, "ts": now}
                counted = True
            _prune_frequency_state(now)

        base.update({"active": True, "reason": "ok", "counted": counted})
        return base


_PREROLL_POLICY = PreRollPolicy()


def get_preroll_policy() -> PreRollPolicy:
    """The shared policy instance (one decision point, no second one)."""
    return _PREROLL_POLICY
