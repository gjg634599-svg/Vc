"""WEBSITE media engagement + the signed external-browser handoff
(B18-FINAL — the bot-22.log final production pass).

Two INDEPENDENT features, one module (both are website-session surfaces):

1. MEDIA ENGAGEMENT (Views / Like / Dislike) — server-authoritative:
     * ``POST /site/api/media/view``  — a threshold-qualified playback
       ping. A view COUNTS only when the authenticated viewer actually
       watched (>= the playback threshold) AND no view was recorded for
       this viewer inside the dedupe window — refreshing or reopening the
       page NEVER inflates counts. VIDEO FILES ONLY: photos and documents
       never receive video view counts (the API layer enforces the media
       type before touching the store).
     * ``POST /site/api/media/react`` — the caller's single like/dislike
       per file: 'like' | 'dislike' | 'none'. Switching replaces the
       reaction ATOMICALLY (one transaction); repeating the active
       reaction removes it. Counts + the caller's own state return in the
       response so the UI updates without a page reload. No Telegram user
       id or any sensitive identifier is ever exposed — counts only.
   Identity: the signed HttpOnly SITE SESSION cookie (the same identity
   the whole site uses). The reaction store keys on the authenticated
   user id; the view store keys a stable per-viewer key derived from it.

2. EXTERNAL-BROWSER HANDOFF (RETIRED — A.3/bot-25): the Mini App ->
   browser session transfer surface was removed from every UI path.
   The ``handle_site_api_ext_link`` / ``handle_site_ext_consume``
   handlers remain in this module as DEAD functions (compatibility);
   the ROUTE REGISTRATIONS below no longer register
   ``POST /site/api/ext-link`` or ``GET /site/ext/{token}`` — they are
   unreachable from any normal UI path. (The header "Open in browser"
   button and its _OPEN_EXT_JS bootstrap were removed from html.py.)
   The documented protocol, kept for reference:
     * ``POST /site/api/ext-link`` — the Mini App client (initData
       verified server-side) asks for a ONE-TAP external-browser URL for
       the CURRENT page. The server mints a SHORT-LIVED, SINGLE-USE
       AEAD-signed handoff token (the URL never carries a raw user id)
       whose plaintext binds: version, user id, display name, the 18+
       flag, a random nonce, an absolute expiry and the target path
       (validated site-relative). The nonce is persisted (website_handoffs)
       so consume is replay-protected even across restarts.
     * ``GET /site/ext/{token}``  — the external browser hits this once:
       AEAD-decode + expiry + SINGLE-USE nonce consume -> a regular site
       session cookie is issued for the SAME authenticated user -> 302 to
       the bound target path. Any replay/expiry/tamper answers the honest
       "session expired — return to Telegram" page, never a bare error.
   The client triggers the transfer with Telegram's supported Mini App
   API (``Telegram.WebApp.openLink``) — a user-interaction-driven,
   officially supported external open (never a forced WebView fullscreen).
"""
from __future__ import annotations

import logging
import secrets
import time
from typing import Any, Dict, Optional

from app.web.site import ratelimit
from app.web.site.session import (
    SESSION_COOKIE_NAME,
    make_site_session_codec,
    session_cookie_header,
)
from app.web.site.stream import make_listing_resolver
from app.web.site.tokens import make_video_token_codec
from app.network.credentials import CredentialVault

logger = logging.getLogger("payload-bot")

try:  # pragma: no cover — optional dependency, same as the rest of app/web
    from aiohttp import web as _aiohttp_web
except Exception:  # noqa: BLE001
    _aiohttp_web = None  # type: ignore[assignment]

_deps_factory = None

# Handoff token: version tag of the AEAD plaintext.
_HANDOFF_VERSION = "h1"
# Handoff lifetime (seconds) — short by design (single tap, immediate open).
HANDOFF_TTL_DEFAULT = 120
HANDOFF_TTL_MIN = 60
HANDOFF_TTL_MAX = 600

# View playback threshold: a view counts after this much watched playback.
MEDIA_VIEW_THRESHOLD_MS = 5000
# For very short videos the threshold shrinks (25% of duration, >= 1.5s).
MEDIA_VIEW_THRESHOLD_MIN_MS = 1500
MEDIA_VIEW_FRACTION = 0.25

# Per-user reaction rate limit (in-process; bounded memory).
_REACT_WINDOW_SECONDS = 60
_REACT_MAX_PER_WINDOW = 20
_react_events: Dict[str, Any] = {}
_REACT_MAX_KEYS = 4096


def _clamp_handoff_ttl(seconds: Optional[int]) -> int:
    try:
        t = int(seconds or HANDOFF_TTL_DEFAULT)
    except (TypeError, ValueError):
        t = HANDOFF_TTL_DEFAULT
    return max(HANDOFF_TTL_MIN, min(HANDOFF_TTL_MAX, t))


def _deps() -> Optional[Any]:
    try:
        return _deps_factory() if _deps_factory is not None else None
    except Exception:  # noqa: BLE001
        logger.debug("engagement deps unavailable", exc_info=True)
        return None


def _client_ip(request) -> str:
    fwd = request.headers.get("X-Forwarded-For", "")
    if fwd:
        first = fwd.split(",")[0].strip()
        if first:
            return first[:64]
    return str(request.remote or "unknown")[:64]


async def _website_on(deps: Any) -> bool:
    try:
        from app.web.site.service import make_website_service
        return await make_website_service(deps.db).website_enabled()
    except Exception:  # noqa: BLE001 — fail CLOSED (maintenance)
        return False


def _session_of(request, deps: Any) -> Optional[Dict[str, Any]]:
    try:
        raw = request.cookies.get(SESSION_COOKIE_NAME, "")
        if not raw:
            return None
        return make_site_session_codec(
            getattr(deps, "bot_token", None)).decode_session(raw)
    except Exception:  # noqa: BLE001 — fail closed
        return None


async def _resolve_target(gateway: Any, listing_opaque: str,
                           file_pk: int) -> Optional[Dict[str, Any]]:
    """Await the (async) canonical listing resolver — the gateway's own
    when present, else the REAL make_listing_resolver fallback."""
    rl = getattr(gateway, "listing_resolver", None)
    if rl is None:
        # Fallback: build one through the same canonical resolver factory
        # the gateway uses (published check + ordered-files membership).
        deps = _deps()
        rl = make_listing_resolver(deps.db) if deps else None
    if not callable(rl):
        return None
    return await rl(listing_opaque, file_pk)


# ------------------------------------------------------------------
# 1. MEDIA ENGAGEMENT
# ------------------------------------------------------------------
async def handle_site_api_media_view(request):
    """POST /site/api/media/view — a threshold-qualified playback ping.

    Body: {video_ref, played_ms, duration_ms?}. The view counts ONLY when:
      * the caller has a valid site session (authenticated viewer);
      * the video_ref decodes to a PUBLISHED listing + a current file;
      * the file's media type is VIDEO (photos/documents never count);
      * the played threshold is met (5s, or 25% for short videos);
      * the viewer had no counted view inside the dedupe window.
    Response: {ok, counted, views, reason?}.
    """
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False, "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "maintenance",
             "message": "Website is temporarily switched off."}, status=503)
    if not ratelimit.check_rate("site_engage", _client_ip(request)):
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "rate_limited"},
                                          status=429)
    session = _session_of(request, deps)
    if not session:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unauthorized"},
                                          status=401)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _aiohttp_web.json_response({"ok": False, "error": "bad_request"},
                                          status=400)
    video_ref = str((body or {}).get("video_ref") or "")[:2048]
    played_ms = int((body or {}).get("played_ms") or 0)
    duration_ms = int((body or {}).get("duration_ms") or 0)
    codec = make_video_token_codec(getattr(deps, "bot_token", None))
    decoded = codec.decode_video_ref(video_ref)
    if decoded is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "invalid_video_ref"},
                                          status=400)
    listing_opaque = str(decoded.get("listing") or "")
    file_pk = int(decoded.get("file_pk") or 0)
    # Published-listing + current-file membership (the canonical resolver).
    gw = getattr(deps, "media_gateway", None)
    if callable(gw) and not hasattr(gw, "handle_stream_request"):
        gw = gw()
    target = None
    try:
        target = await _resolve_target(gw, listing_opaque, file_pk)
    except Exception:  # noqa: BLE001 — resolve failure = not counted
        target = None
    if target is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "not_found"},
                                          status=404)
    # VIDEOS ONLY (bot-22 pass requirement): photos/documents never
    # receive video view counts.
    media_type = str(target.get("media_type") or "").lower()
    if media_type != "video":
        return _aiohttp_web.json_response(
            {"ok": True, "counted": False, "reason": "not_video"})
    # Playback threshold: 5s watched, or 25% for short videos (>= 1.5s).
    threshold = MEDIA_VIEW_THRESHOLD_MS
    if duration_ms > 0:
        threshold = min(MEDIA_VIEW_THRESHOLD_MS,
                        max(MEDIA_VIEW_FRACTION * duration_ms,
                            MEDIA_VIEW_THRESHOLD_MIN_MS))
    if played_ms < threshold:
        return _aiohttp_web.json_response(
            {"ok": True, "counted": False, "reason": "below_threshold"})
    uid = int(session.get("user_id") or 0)
    if uid <= 0:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unauthorized"},
                                          status=401)
    viewer_key = f"u{uid}"
    try:
        counted = await deps.db.record_media_view(file_pk, viewer_key)
        views = await deps.db.media_view_count(file_pk)
    except Exception:  # noqa: BLE001 — engagement never breaks playback
        logger.warning("MEDIA_VIEW_RECORD_FAILED file_pk=%s "
                       "(view not counted)", file_pk, exc_info=True)
        return _aiohttp_web.json_response(
            {"ok": False, "error": "storage_unavailable"}, status=500)
    return _aiohttp_web.json_response(
        {"ok": True, "counted": bool(counted), "views": int(views)})


async def handle_site_api_media_react(request):
    """POST /site/api/media/react — the caller's like/dislike for one file.

    Body: {video_ref, reaction: 'like'|'dislike'|'none'}. One reaction per
    (file, user): switching replaces atomically; repeating the active one
    removes it. Response: {ok, reaction, likes, dislikes}. Rate limited
    per user (trivial-abuse bound) and per IP.
    """
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False, "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "maintenance",
             "message": "Website is temporarily switched off."}, status=503)
    if not ratelimit.check_rate("site_engage", _client_ip(request)):
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "rate_limited"},
                                          status=429)
    session = _session_of(request, deps)
    if not session:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unauthorized"},
                                          status=401)
    uid = int(session.get("user_id") or 0)
    if uid <= 0:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unauthorized"},
                                          status=401)
    # Per-user trivial-abuse bound (sliding window, bounded memory).
    now = time.time()
    dq = _react_events.get(f"u{uid}")
    if dq is None:
        from collections import deque
        dq = deque()
        _react_events[f"u{uid}"] = dq
    while dq and now - dq[0] > _REACT_WINDOW_SECONDS:
        dq.popleft()
    if len(_react_events) > _REACT_MAX_KEYS:
        for k in [k for k in _react_events
                  if not _react_events[k] or now - _react_events[k][-1]
                  > _REACT_WINDOW_SECONDS * 2][:64]:
            _react_events.pop(k, None)
    if len(dq) >= _REACT_MAX_PER_WINDOW:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "rate_limited"},
                                          status=429)
    dq.append(now)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _aiohttp_web.json_response({"ok": False, "error": "bad_request"},
                                          status=400)
    video_ref = str((body or {}).get("video_ref") or "")[:2048]
    reaction = str((body or {}).get("reaction") or "").strip().lower() or "none"
    if reaction not in ("like", "dislike", "none"):
        return _aiohttp_web.json_response({"ok": False, "error": "bad_request"},
                                          status=400)
    codec = make_video_token_codec(getattr(deps, "bot_token", None))
    decoded = codec.decode_video_ref(video_ref)
    if decoded is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "invalid_video_ref"},
                                          status=400)
    listing_opaque = str(decoded.get("listing") or "")
    file_pk = int(decoded.get("file_pk") or 0)
    gw = getattr(deps, "media_gateway", None)
    if callable(gw) and not hasattr(gw, "handle_stream_request"):
        gw = gw()
    try:
        target = await _resolve_target(gw, listing_opaque, file_pk)
    except Exception:  # noqa: BLE001
        target = None
    if target is None:
        return _aiohttp_web.json_response({"ok": False, "error": "not_found"},
                                          status=404)
    # SERVER-AUTHORITATIVE toggle semantics (never client-computed): a
    # repeat of the CALLER'S OWN active reaction REMOVES it; any other
    # valid value SETS it. The client only reports which button was
    # tapped — 'none' is the explicit clear. The store keeps ONE
    # reaction per (file, user) and the switch is transactional.
    try:
        current = await deps.db.get_media_reaction(file_pk, uid)
    except Exception:  # noqa: BLE001
        current = None
    if reaction != "none" and current == reaction:
        reaction = "none"
    try:
        out = await deps.db.set_media_reaction(
            file_pk, uid, None if reaction == "none" else reaction)
    except Exception:  # noqa: BLE001
        logger.warning("MEDIA_REACTION_FAILED file_pk=%s "
                       "(reaction not stored)", file_pk, exc_info=True)
        return _aiohttp_web.json_response(
            {"ok": False, "error": "storage_unavailable"}, status=500)
    return _aiohttp_web.json_response(
        {"ok": True, "reaction": out.get("reaction"),
         "likes": int(out.get("likes") or 0),
         "dislikes": int(out.get("dislikes") or 0)})


# ------------------------------------------------------------------
# 2. EXTERNAL-BROWSER HANDOFF (signed, short-lived, single-use)
# ------------------------------------------------------------------
def _validate_handoff_path(path: str) -> str:
    """Site-relative path whitelist: must start with /site, no scheme, no
    protocol-relative form, no dot-segments (../ traversal — the browser
    would normalize them OUTSIDE /site), bounded length. '' = invalid."""
    p = str(path or "").strip()
    if not p.startswith("/site") or p.startswith("//"):
        return ""
    if len(p) > 512 or "\r" in p or "\n" in p or "\x00" in p:
        return ""
    lowered = p.lower()
    if "://" in lowered or "javascript:" in lowered:
        return ""
    # Dot-segment rejection: any . or .. path segment is a traversal
    # attempt (the browser normalizes /site/../x to /x — outside the site).
    segments = p.split("/")
    if any(seg == ".." or seg == "." for seg in segments):
        return ""
    return p


def _make_handoff_codec(bot_token: Optional[str] = None):
    vault = CredentialVault(bot_token_fallback=bot_token,
                            allow_ephemeral_fallback=True)

    def encode_handoff(user_id: int, username: str, first_name: str,
                       age_ok: bool, nonce: str, expires_at: float,
                       target: str) -> str:
        plaintext = "|".join((
            _HANDOFF_VERSION, str(int(user_id)), str(username or "")[:64],
            str(first_name or "")[:64], "1" if age_ok else "0",
            str(nonce), str(int(expires_at)), str(target)))
        return vault.encrypt(plaintext)

    def decode_handoff(token: str) -> Optional[Dict[str, Any]]:
        try:
            raw = vault.decrypt(str(token or ""))
        except Exception:  # noqa: BLE001 — fail closed
            return None
        parts = raw.split("|")
        if len(parts) != 8 or parts[0] != _HANDOFF_VERSION:
            return None
        try:
            uid = int(parts[1])
            exp = float(parts[6])
        except ValueError:
            return None
        if uid <= 0 or exp < time.time():
            return None
        return {"user_id": uid, "username": parts[2],
                "first_name": parts[3], "age_ok": parts[4] == "1",
                "nonce": parts[5], "expires_at": exp, "target": parts[7]}

    return encode_handoff, decode_handoff


async def handle_site_api_ext_link(request):
    """POST /site/api/ext-link — mint the ONE-TAP external-browser URL.

    Body: {init_data, path}. The Mini App identity is verified server-side
    (multi-token initData validation — the SAME validator the stream API
    uses); the target path is whitelisted site-relative; the returned URL
    carries ONLY the AEAD handoff token (never a raw user id). The token
    is single-use, short-lived and replay-protected through the
    website_handoffs store.
    """
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False, "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "maintenance",
             "message": "Website is temporarily switched off."}, status=503)
    if not ratelimit.check_rate("site_ext", _client_ip(request)):
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "rate_limited"},
                                          status=429)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _aiohttp_web.json_response({"ok": False, "error": "bad_request"},
                                          status=400)
    init_data = str((body or {}).get("init_data") or "")[:8192]
    path = _validate_handoff_path(str((body or {}).get("path") or ""))
    if not init_data or not path:
        return _aiohttp_web.json_response({"ok": False, "error": "bad_request"},
                                          status=400)
    from app.web.site.auth import make_multi_token_web_auth
    from app.web.site.pages import _make_single_validator
    multi_auth = make_multi_token_web_auth(
        getattr(deps, "bot_token", None),
        getattr(deps, "network_tokens", None),
        validate_with_token=_make_single_validator(deps))
    verified = await multi_auth.validate_init_data(init_data)
    if verified is None:
        logger.info("WEBSITE_EXT_HANDOFF_MINT_REJECTED reason=unauthorized")
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unauthorized"},
                                          status=401)
    uid = int(verified.get("user_id") or 0)
    if uid <= 0:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unauthorized"},
                                          status=401)
    tg_user = verified.get("user") or {}
    username = str(tg_user.get("username") or "")[:64]
    first_name = str(tg_user.get("first_name") or "")[:64]
    # The 18+ confirmation rides along ONLY from an EXISTING session that
    # belongs to the SAME verified user (user A's confirmation never
    # transfers to user B's browser session).
    age_ok = False
    session = _session_of(request, deps)
    if session and int(session.get("user_id") or 0) == uid:
        age_ok = bool(session.get("age_ok"))
    nonce = secrets.token_urlsafe(24)
    ttl = _clamp_handoff_ttl(
        getattr(deps, "ext_handoff_ttl_seconds", None))
    expires_at = time.time() + ttl
    encode_handoff, _ = _make_handoff_codec(
        getattr(deps, "bot_token", None))
    try:
        token = encode_handoff(uid, username, first_name, age_ok,
                               nonce, expires_at, path)
    except Exception:  # noqa: BLE001 — mint fails closed
        logger.warning("WEBSITE_EXT_HANDOFF_MINT_FAILED reason=encode")
        return _aiohttp_web.json_response(
            {"ok": False, "error": "signing_unavailable"}, status=500)
    if not await deps.db.create_website_handoff(nonce, uid, path,
                                                expires_at):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "signing_unavailable"}, status=500)
    from app.web.site.service import make_website_service
    svc = make_website_service(deps.db)
    base = await svc.website_public_base_url()
    url = svc.build_site_url(f"site/ext/{token}", base)
    if not url:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "signing_unavailable"}, status=500)
    logger.info("WEBSITE_EXT_HANDOFF_MINTED user_id=%s ttl=%ss "
                "target=%s (token/nonce never logged)", uid, ttl, path)
    # Opportunistic prune of long-expired handoff rows.
    try:
        await deps.db.prune_website_handoffs()
    except Exception:  # noqa: BLE001
        pass
    return _aiohttp_web.json_response({"ok": True, "url": url, "ttl": ttl})


async def handle_site_ext_consume(request):
    """GET /site/ext/{token} — the external browser's ONE-TAP entry.

    AEAD-decode + expiry + SINGLE-USE nonce consume -> a regular site
    session cookie for the SAME authenticated user -> 302 to the bound
    target path. Replays/expiry/tampering answer the honest
    session-expired page (never a bare 500), because the Mini App link
    that minted the URL is where the user returns to.
    """
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.Response(status=503)
    if not await _website_on(deps):
        from app.web.site import html as _html
        return _aiohttp_web.Response(text=_html.maintenance_page(),
                                     content_type="text/html", status=503)
    if not ratelimit.check_rate("site_ext", _client_ip(request)):
        return _aiohttp_web.Response(status=429)
    token = str(request.match_info.get("token") or "")[:2048]
    _, decode_handoff = _make_handoff_codec(
        getattr(deps, "bot_token", None))
    payload = decode_handoff(token)
    if payload is None:
        logger.info("WEBSITE_EXT_HANDOFF_REJECTED reason=invalid_or_expired")
        return _handoff_expired_page()
    consumed = None
    try:
        consumed = await deps.db.consume_website_handoff(
            str(payload.get("nonce") or ""))
    except Exception:  # noqa: BLE001 — consume fails CLOSED
        logger.warning("WEBSITE_EXT_HANDOFF_CONSUME_ERROR", exc_info=True)
        return _handoff_expired_page()
    if not consumed or int(consumed.get("user_id") or 0) != int(
            payload.get("user_id") or 0):
        logger.info("WEBSITE_EXT_HANDOFF_REJECTED reason=replay_or_unknown")
        return _handoff_expired_page()
    target = _validate_handoff_path(str(consumed.get("target") or ""))
    if not target or target != str(payload.get("target") or ""):
        logger.info("WEBSITE_EXT_HANDOFF_REJECTED reason=target_mismatch")
        return _handoff_expired_page()
    uid = int(payload.get("user_id") or 0)
    codec = make_site_session_codec(getattr(deps, "bot_token", None))
    session_token = codec.issue_session(
        uid, username=str(payload.get("username") or ""),
        first_name=str(payload.get("first_name") or ""),
        age_ok=bool(payload.get("age_ok")))
    secure = str(request.url.scheme).lower() == "https"
    header_name, header_value = session_cookie_header(
        session_token, ttl_seconds=int(codec.ttl_seconds), secure=secure)
    logger.info("WEBSITE_EXT_HANDOFF_CONSUMED user_id=%s target=%s "
                "(browser session issued)", uid, target)
    resp = _aiohttp_web.Response(status=302, headers={
        header_name: header_value, "Location": target,
        "Cache-Control": "no-store"})
    return resp


def _handoff_expired_page():
    """The honest replay/expiry answer: a styled page that sends the user
    back to Telegram (the minting Mini App) — never a bare error."""
    from app.web.site import html as _html
    try:
        return _aiohttp_web.Response(
            text=_html.session_expired_page(),
            content_type="text/html", status=410)
    except Exception:  # noqa: BLE001 — the screen must always render
        return _aiohttp_web.Response(
            text=("<!doctype html><meta charset=utf-8>"
                  "<meta name=viewport content='width=device-width,"
                  "initial-scale=1'><title>Link expired</title>"
                  "<p>This browser link has expired or was already used."
                  "</p><p>Open the website from Telegram again.</p>"),
            content_type="text/html", status=410)


def register_engagement_routes(app, deps_factory) -> bool:
    """Register the engagement + handoff routes (called from the site's
    route registration — additive lines only)."""
    global _deps_factory
    if _aiohttp_web is None:  # pragma: no cover
        return False
    _deps_factory = deps_factory
    app.router.add_post("/site/api/media/view",
                        handle_site_api_media_view)
    app.router.add_post("/site/api/media/react",
                        handle_site_api_media_react)
    # A.3 (bot-25): the external-link handoff routes are NO LONGER
    # registered — the "Open in browser" header button was removed from
    # every page (html.py) so no normal UI path reaches these endpoints.
    # The handlers above stay as dead functions for compatibility.
    return True
