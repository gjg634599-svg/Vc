"""BOT-16 — the website HLS serving surface (aiohttp handlers).

Route (registered ADDITIVELY by the integrator — this module registers
NOTHING at import and mutates NOTHING global):

    GET/HEAD /site/hls/{token}/{path:.*}

The production failure this module closes (bot-16.log root cause #3): a
Telegram-stored MKV/HEVC file streamed as raw bytes → the browser refuses
it ("Cannot play in this browser"). With this pipeline the player mounts
an HLS <video> (h264/aac, MPEG-TS segments — universally decodable), and
THIS surface serves the master/variant playlists and segments that
:mod:`app.media.transcode` rendered.

Authorization chain — the SAME machinery as ``/site/media`` (stream.py),
never a second system:

  1. The stream token is decoded with the SAME
     :func:`app.media.streamtokens.make_stream_token_codec` bound to the
     deployment vault key (a token that fails here would fail there too);
     ``purpose`` must be "stream".
  2. The canonical target (payload_id) is resolved through the media
     GATEWAY's ``listing_resolver`` when available — the exact resolver
     the /site/media chain uses (published check + file membership).
  3. The EXISTING Access Engine is re-verified on EVERY request
     (``deps.access_engine(_bot, uid, payload_id=...)`` — mirroring
     stream.py's issuance re-check; a revoked user cannot ride an
     unexpired token).

The file identity + a LOCAL source path resolver are supplied by the
WIRING layer through ``deps.hls_resolver`` — an async callable
``(listing_opaque, file_pk) -> {"file_unique_id": str,
"source_path_fn": async () -> str} | None``. Until the integrator wires
it, every request answers an honest 503 "hls_not_wired" (feature-flagged
surface, never a crash, never a silent raw-mkv fallback that would replay
the production bug).

Path safety (BOT-16): the ``{path}`` match is percent-decoded and then
VALIDATED against a strict whitelist — exactly three shapes are legal:

    master.m3u8
    <variant>/index.m3u8
    <variant>/segNNNNN.ts

with ``<variant>`` matching ``^[A-Za-z0-9_\\-]+$``. Traversal (``..``),
empty components (``//``), NUL, backslash, absolute paths, and ANY other
shape answer 404. Validation is exported as :func:`validate_hls_path`
for the regression suite.

Serving semantics: .m3u8 → ``application/vnd.apple.mpegurl``,
``Cache-Control: private, max-age=60``, no ranges; .ts →
``video/mp2t``, ``Cache-Control: private, max-age=3600``,
``Accept-Ranges: bytes`` with SINGLE-range 206 support parsed by the
same :mod:`app.media.ranges` discipline the Media Gateway uses. HEAD is
supported. Errors are honest JSON bodies (the site's shape).

Secrets discipline: tokens are NEVER logged; the request log cites the
token-purpose-decoded file_pk, the validated path, and the status.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
from urllib.parse import unquote

try:  # pragma: no cover — aiohttp is guaranteed in the web layer
    from aiohttp import web as _aiohttp_web
except Exception:  # noqa: BLE001
    _aiohttp_web = None  # type: ignore[assignment]

logger = logging.getLogger("payload-bot")

HLS_ROUTE = "/site/hls/{token}/{path:.*}"

# Content types (BOT-16): the Apple HLS playlist type + MPEG-TS.
HLS_PLAYLIST_CONTENT_TYPE = "application/vnd.apple.mpegurl"
HLS_SEGMENT_CONTENT_TYPE = "video/mp2t"

# Cache-Control (BOT-16): playlists may be re-rendered — short TTL;
# segments are immutable for a rendered tree — long TTL. ``private``:
# tokens are per-user, intermediaries must not share.
HLS_PLAYLIST_MAX_AGE = 60
HLS_SEGMENT_MAX_AGE = 3600

# Serving chunk for segment bodies (bounded memory, never whole-segment
# buffers) — the StreamCache chunk discipline.
_HLS_SERVE_CHUNK = 1024 * 1024

# ------------------------------------------------------------- path safety
_VARIANT_NAME_RE = re.compile(r"^[A-Za-z0-9_\-]+$")
_SEGMENT_NAME_RE = re.compile(r"^seg[0-9]+\.(ts|m4s)$")
_MASTER_NAME = "master.m3u8"
_PLAYLIST_NAME = "index.m3u8"


def validate_hls_path(path: str) -> Optional[Tuple[str, str, str]]:
    """Validate ONE percent-decoded ``{path}`` match.

    Returns ``(kind, variant, filename)`` with kind in
    {"master", "playlist", "segment"} — or None for EVERY other shape
    (traversal, absolute, backslash, NUL, empty/double components, extra
    depth, non-whitelisted names). PURE and total: never raises.
    """
    try:
        p = str(path or "")
    except Exception:  # noqa: BLE001 — hostile input is data
        return None
    if not p:
        return None
    if p.startswith("/") or p.startswith("\\"):
        return None  # absolute / windows drive shapes
    if "\\" in p or "\x00" in p:
        return None
    if "//" in p or "/./" in p or "/../" in p:
        return None
    parts = p.split("/")
    if any(part in ("", ".", "..") for part in parts):
        return None
    if len(parts) == 1:
        if parts[0] == _MASTER_NAME:
            return ("master", "", _MASTER_NAME)
        return None
    if len(parts) != 2:
        return None
    variant, name = parts
    if not _VARIANT_NAME_RE.match(variant):
        return None
    if name == _PLAYLIST_NAME:
        return ("playlist", variant, name)
    if _SEGMENT_NAME_RE.match(name):
        return ("segment", variant, name)
    return None


# ------------------------------------------------------------------ helpers
def _client_ip(request) -> str:
    fwd = request.headers.get("X-Forwarded-For", "")
    if fwd:
        first = fwd.split(",")[0].strip()
        if first:
            return first[:64]
    return str(request.remote or "unknown")[:64]


def _resolve_deps(deps: Any) -> Optional[Any]:
    """Accept either the deps NAMESPACE or the pages-style deps FACTORY
    (the StreamCache/_gateway tolerance for late-bound wiring)."""
    if deps is None:
        return None
    if callable(deps) and not hasattr(deps, "db") \
            and not hasattr(deps, "bot_token") \
            and not hasattr(deps, "media_gateway"):
        try:
            return deps()
        except Exception:  # noqa: BLE001 — fail closed
            logger.debug("hls deps factory failed", exc_info=True)
            return None
    return deps


def _gateway(deps: Any) -> Optional[Any]:
    """The Media Gateway singleton from the request deps (the exact
    stream.py helper semantics — callable gateway factory resolved,
    anything without handle_stream_request rejected)."""
    gw = getattr(deps, "media_gateway", None)
    if callable(gw) and not hasattr(gw, "handle_stream_request"):
        try:
            gw = gw()
        except Exception:  # noqa: BLE001 — fail closed
            logger.debug("media gateway construction failed", exc_info=True)
            return None
    return gw if hasattr(gw, "handle_stream_request") else None


async def _website_on(deps: Any) -> bool:
    """The GLOBAL website_enabled gate (the stream.py rule — fail CLOSED
    to maintenance on any lookup failure)."""
    try:
        from app.web.site.service import make_website_service
        return await make_website_service(deps.db).website_enabled()
    except Exception:  # noqa: BLE001 — fail CLOSED (maintenance)
        logger.debug("website_enabled check failed — maintenance",
                     exc_info=True)
        return False


# ------------------------------------------------------------ registration
def register_hls_routes(app, deps) -> bool:
    """Register the BOT-16 HLS route ADDITIVELY (the integrator wires this
    from the pages route table; nothing here mutates module globals).

    ``deps`` — the request deps namespace OR the pages-style deps factory.
    Returns False (and registers nothing) when aiohttp is unavailable.
    """
    if _aiohttp_web is None:  # pragma: no cover — aiohttp guaranteed
        return False

    async def _handler(request):
        return await handle_site_hls(request, deps)

    app.router.add_get(HLS_ROUTE, _handler)  # allow_head=True (default)
    return True


# ----------------------------------------------------------------- serving
async def _serve_hls_file(request, path: Path, media_type: str,
                          max_age: int, *, ranged: bool):
    """Serve one rendered HLS file with the site's honest semantics.

    ``ranged`` — True only for MPEG-TS segments (single-range 206 via
    app.media.ranges — the gateway's Range discipline; playlists answer
    "Accept-Ranges: none" and ignore Range headers).
    """
    web = _aiohttp_web
    base_headers = {
        "Content-Type": media_type,
        "Cache-Control": f"private, max-age={int(max_age)}",
        "Accept-Ranges": "bytes" if ranged else "none",
    }

    def _size() -> Optional[int]:
        try:
            return os.path.getsize(path)
        except OSError:
            return None

    size = await asyncio.to_thread(_size)
    if size is None:
        return None  # caller answers 404 (vanished mid-request)

    range_header = request.headers.get("Range") if ranged else None
    if ranged and range_header:
        from app.media.ranges import (
            UNSATISFIABLE, content_range_header, parse_range_header)
        parsed = parse_range_header(range_header, size)
        if parsed is UNSATISFIABLE:
            return web.Response(
                status=416,
                headers={"Content-Range": f"bytes */{size}"},
                body=b"")
        if parsed is not None:
            start, end = int(parsed[0]), int(parsed[1])
            length = end - start + 1
            headers = dict(base_headers)
            headers["Content-Range"] = content_range_header(start, end,
                                                            size)
            if request.method == "HEAD":
                headers["Content-Length"] = str(length)
                return web.Response(status=206, headers=headers)
            resp = web.StreamResponse(status=206, headers=headers)
            resp.content_length = length
            await _write_range(request, resp, path, start, length)
            return resp

    if request.method == "HEAD":
        headers = dict(base_headers)
        headers["Content-Length"] = str(size)
        return web.Response(status=200, headers=headers)

    # Full 200 body: playlists are small (single read); segments stream
    # in bounded chunks (never a whole segment in RAM).
    if size <= _HLS_SERVE_CHUNK:
        def _read() -> bytes:
            with open(path, "rb") as fh:
                return fh.read()
        body = await asyncio.to_thread(_read)
        return web.Response(status=200, body=body, headers=base_headers)
    resp = web.StreamResponse(status=200, headers=base_headers)
    resp.content_length = size
    await _write_range(request, resp, path, 0, size)
    return resp


async def _write_range(request, resp, path: Path, start: int,
                       length: int) -> None:
    """Bounded chunked writer for [start, start+length) of one file.

    A client disconnect mid-write closes quietly (the stream.py
    _ClientGoneSignal discipline: never an error, never a partial 5xx).
    """
    pos = int(start)
    end = int(start) + int(length)

    def _read_chunk(fh, want: int) -> bytes:
        return fh.read(want)

    f = await asyncio.to_thread(open, str(path), "rb")
    try:
        if pos > 0:
            await asyncio.to_thread(f.seek, pos)
        first = True
        while pos < end:
            want = min(_HLS_SERVE_CHUNK, end - pos)
            data = await asyncio.to_thread(_read_chunk, f, want)
            if not data:
                break  # file shorter than promised — honest partial stop
            pos += len(data)
            try:
                if first:
                    await resp.prepare(request)
                    first = False
                await resp.write(data)
            except (ConnectionError, RuntimeError):
                return  # client gone (aiohttp raises on a dead socket)
        if first:
            await resp.prepare(request)
        try:
            await resp.write_eof()
        except (ConnectionError, RuntimeError):
            pass
    finally:
        await asyncio.to_thread(f.close)


# ------------------------------------------------------------------ handler
async def handle_site_hls(request, deps):
    """GET/HEAD /site/hls/{token}/{path} — the BOT-16 HLS surface.

    Chain (every step honest, every failure classified): path validation
    → website gate → rate limit → stream-token decode (same codec as
    /site/media) → listing resolution (gateway resolver) → Access Engine
    re-verification → wiring resolver (deps.hls_resolver) →
    TranscodeManager.ensure_hls → file serve.
    """
    web = _aiohttp_web
    if web is None:  # pragma: no cover — aiohttp guaranteed
        return web.Response(status=503)

    def _json(status: int, code: str, message: str = "",
              file_pk: Any = None, path: str = ""):
        body: Dict[str, Any] = {"ok": False, "error": code}
        if message:
            body["message"] = message
        resp = web.json_response(body, status=status)
        logger.info("WEBSITE_HLS_REQUEST file_pk=%s path=%s status=%s "
                    "error=%s", file_pk, path, status, code)
        return resp

    deps = _resolve_deps(deps)
    if deps is None:
        return _json(503, "unavailable", "Website dependencies are not "
                                       "wired yet.")
    if not await _website_on(deps):
        return _json(503, "maintenance", "Website is temporarily "
                                       "switched off.")
    # V26 Phase 6 + V26 FINAL: the Anti-Leech toggle (stream.py) — a
    # foreign-host referer/origin on the HLS surface is a hotlink; the
    # PROXY-AWARE host set keeps the deployment's legitimate public
    # hosts (Worker/proxy) allowed.
    try:
        from app.web.site.stream import (
            _anti_leech_active, _anti_leech_decision, _log_anti_leech)
        if await _anti_leech_active(deps):
            _al = await _anti_leech_decision(request, deps)
            if not _al.get("allowed"):
                _log_anti_leech("hls", _al, blocked=True)
                return _json(403, "anti_leech",
                             "Hotlinking this media is not permitted.")
            _log_anti_leech("hls", _al, blocked=False)
    except Exception:  # noqa: BLE001 — the gate must never 500
        pass
    try:
        from app.web.site import ratelimit
        if not ratelimit.check_rate("site_stream", _client_ip(request)):
            return _json(429, "rate_limited")
    except Exception:  # noqa: BLE001 — rate limiting must not 500
        pass

    # ---- 1. path validation (BEFORE anything expensive) ----------------
    raw_path = str(request.match_info.get("path") or "")
    try:
        decoded_path = unquote(raw_path, errors="strict")
    except Exception:  # noqa: BLE001 — hostile percent-encoding
        decoded_path = None
    parsed = validate_hls_path(decoded_path) if decoded_path is not None \
        else None
    if parsed is None:
        return _json(404, "not_found", "Unknown HLS resource.")
    kind, variant, filename = parsed

    # ---- 2. stream-token decode (the SAME codec machinery) -------------
    from app.media.streamtokens import (
        PURPOSE_STREAM, make_stream_token_codec)
    token = str(request.match_info.get("token") or "")
    codec = make_stream_token_codec(getattr(deps, "bot_token", None))
    decoded = codec.decode_stream_token(token)
    if decoded is None:
        return _json(401, "invalid_stream_token",
                     "This playback link is invalid or has expired.")
    if str(decoded.get("purpose") or "") != PURPOSE_STREAM:
        return _json(401, "wrong_purpose",
                     "This link is not valid for media playback.")
    uid = int(decoded.get("user_id") or 0)
    listing_opaque = str(decoded.get("listing") or "")
    file_pk = int(decoded.get("file_pk") or 0)
    # V26 FINAL (Part 14 — cross-user replay guard): a VALID site session
    # proving the caller is a DIFFERENT user than the token's user → 403
    # (user B replaying user A's copied HLS master/segment URL inside a
    # logged-in browser). No session cookie → the token alone decides.
    try:
        from app.web.site.stream import _token_user_if_mismatched
        _mismatch = await _token_user_if_mismatched(request, deps, token)
        if _mismatch is not None:
            logger.info(
                "WEBSITE_HLS_REQUEST file_pk=%s path=%s status=403 "
                "error=wrong_user (session user %s != token user %s)",
                file_pk, raw_path, _mismatch[0], _mismatch[1])
            return _json(403, "wrong_user",
                         "This playback link belongs to another user.",
                         file_pk, raw_path)
    except Exception:  # noqa: BLE001 — the guard never blocks playback
        logger.debug("hls wrong-user cross-check failed", exc_info=True)

    # ---- 3. canonical listing resolution (the gateway's own resolver) --
    gateway = _gateway(deps)
    payload_id = None
    resolver_fn = getattr(gateway, "listing_resolver", None) \
        if gateway is not None else None
    if callable(resolver_fn):
        try:
            target = await resolver_fn(listing_opaque, file_pk)
        except Exception:  # noqa: BLE001 — honest 503, never a crash
            logger.debug("hls listing resolution failed", exc_info=True)
            target = None
        # BOT-40 (Section B): the 404s are now CLASSIFIED — the listing
        # resolution outcome is its own telemetry line (never the token,
        # never the listing secret, only the token-decoded file_pk).
        logger.info("WEBSITE_HLS_RESOLVE file_pk=%s listing_resolved=%s",
                    file_pk, "yes" if target is not None else "no")
        if target is None:
            return _json(404, "not_found",
                         "This file no longer belongs to a published "
                         "payload.", file_pk, raw_path)
        payload_id = target.get("payload_id")

    # ---- 4. Access Engine re-verification (every request — the
    #         stream.py discipline, late-bound live bot) ---------------
    # B23/P0-1: through the website-playback authorization chokepoint —
    # every engine reason stays enforced EXCEPT watch_ad_required (the
    # TELEGRAM payload Watch-Ad gate does not gate website playback).
    # B23/P0-3 (§3.2 HLS age recheck): a long-lived HLS token issued
    # before a category became age-restricted must stop serving
    # restricted segments — the SAME identity-bound age rule the stream
    # issuance path applies (session age_ok must belong to the SAME uid
    # the token embeds). Unconfirmed → the SAME honest 404 shape as an
    # unresolvable target (no existence leak).
    _bot_ref = getattr(deps, "bot_ref", None)
    _bot = _bot_ref() if callable(_bot_ref) else None
    authorized = False
    try:
        from app.web.site.authz import authorize_website_playback
        verdict = await authorize_website_playback(
            deps, _bot, uid, payload_id=payload_id,
            gate_key=f"w|{listing_opaque}|{int(file_pk or 0)}")
        authorized = bool(getattr(verdict, "authorized", False))
    except Exception as engine_exc:  # noqa: BLE001 — engine failure fails CLOSED
        from app.web.site.authz import log_website_engine_failure
        log_website_engine_failure(
            "hls_reverify", engine_exc, user_id=uid, payload_id=payload_id,
            file_pk=file_pk, gate_key=f"w|{listing_opaque}|{int(file_pk or 0)}")
        authorized = False
    if not authorized:
        return _json(403, "access_denied",
                     "Complete the access requirement in the bot, then "
                     "reload.", file_pk, raw_path)

    # ---- 4b. age recheck (§3.2 — shared predicate, identity-bound) ----
    try:
        from app.web.site.stream import (
            _listing_age_restricted, _session_age_confirmed)
        if not await _session_age_confirmed(request, deps, uid) \
                and await _listing_age_restricted(deps, listing_opaque):
            logger.info(
                "WEBSITE_HLS_AGE_DENIED user_id=%s file_pk=%s listing=%s "
                "(18+ unconfirmed — the long-lived HLS token no longer "
                "serves this restricted listing)", uid, file_pk,
                listing_opaque[:8])
            return _json(404, "not_found",
                         "This content is no longer available.",
                         file_pk, raw_path)
    except Exception:  # noqa: BLE001 — age recheck failure fails CLOSED
        logger.debug("hls age recheck failed", exc_info=True)
        return _json(404, "not_found",
                     "This content is no longer available.",
                     file_pk, raw_path)

    # ---- 5. wiring resolver (file identity + local source path) --------
    hls_resolver = getattr(deps, "hls_resolver", None)
    if not callable(hls_resolver):
        return _json(503, "hls_not_wired",
                     "HLS transcoding is not wired on this deployment.",
                     file_pk, raw_path)
    try:
        info = await hls_resolver(listing_opaque, file_pk)
    except Exception:  # noqa: BLE001 — honest 503, never a crash
        logger.debug("hls resolver failed", exc_info=True)
        info = None
    _fuid = str((info or {}).get("file_unique_id") or "")
    # BOT-40 (Section B): the identity resolution outcome — the SAFE
    # truncated unique id only (the existing cache-fill log discipline,
    # first 16 chars; never file_id, never the token).
    logger.info("WEBSITE_HLS_SOURCE file_pk=%s file_unique_id=%s "
                "source_available=%s", file_pk,
                _fuid[:16] if _fuid else "-",
                "yes" if (isinstance(info, dict) and _fuid
                          and callable(info.get("source_path_fn"))) else "no")
    if not isinstance(info, dict) or not _fuid:
        # BOT-40 root cause: the issuance minted an HLS plan for a file
        # whose identity the serve chain cannot resolve (NULL/stale
        # file_unique_id on the matched row). Honest, CLASSIFIED 404 —
        # a distinct error code (no existence leak, no raw fallback).
        return _json(404, "unresolvable_media_identity",
                     "This file's media identity is incomplete — the "
                     "source channel needs re-indexing.", file_pk, raw_path)
    file_unique_id = _fuid
    source_path_fn = info.get("source_path_fn")
    if not callable(source_path_fn):
        return _json(503, "hls_not_wired",
                     "HLS source resolution is incomplete.",
                     file_pk, raw_path)

    # ---- 6. the HLS tree — ASYNCHRONOUS PREPARATION (V26.2-bot42) ------
    # TASK C1 root cause: this step used to AWAIT manager.ensure_hls(...)
    # inside the browser's HTTP request — with ffmpeg timeouts in the
    # hours, master.m3u8 could hang the player for the entire transcoding
    # (bot-42: MEDIA_TRANSCODE_START with no timely MEDIA_TRANSCODE_
    # COMPLETE while the browser waited). The contract now:
    #   * a READY tree (state + outputs verified) serves IMMEDIATELY;
    #   * a FAILED entry inside its retry window answers the honest
    #     classified 503 transcode_failed;
    #   * anything else STARTS (or JOINS) the ONE coalesced background
    #     preparation job and answers 503 hls_preparing — the player
    #     retries with bounded backoff against the SAME authorized URL
    #     (never a fake playlist, never raw Telegram media, never a
    #     second ffmpeg process for the same identity).
    manager = getattr(deps, "hls_manager", None)
    if manager is None or not hasattr(manager, "ensure_hls"):
        from app.media.transcode import get_transcode_manager
        manager = get_transcode_manager()

    base: Optional[Path] = None
    master_name = "master.m3u8"
    _snapshot: Optional[Dict[str, Any]] = None
    if hasattr(manager, "hls_preparation_snapshot"):
        try:
            _snapshot = await manager.hls_preparation_snapshot(file_unique_id)
        except Exception:  # noqa: BLE001 — snapshot is a pure read
            logger.debug("hls preparation snapshot failed", exc_info=True)
            _snapshot = None

    if _snapshot is not None and bool(_snapshot.get("ready")):
        # SERVE from the verified READY tree (no lock, no job, no wait).
        base = Path(str(_snapshot.get("dir")))
        master_name = str(_snapshot.get("master") or "master.m3u8")
        try:
            _dir_ok = base.is_dir()
        except Exception:  # noqa: BLE001 — stat best-effort
            _dir_ok = False
        try:
            _master_ok = (base / master_name).is_file()
        except Exception:  # noqa: BLE001 — stat best-effort
            _master_ok = False
        logger.info("WEBSITE_HLS_ENSURE file_pk=%s ok=yes dir_exists=%s "
                    "master_exists=%s reason=-", file_pk,
                    "yes" if _dir_ok else "no",
                    "yes" if _master_ok else "no")
    elif _snapshot is not None and bool(_snapshot.get("failed")) \
            and float(_snapshot.get("backoff_remaining_s") or 0.0) > 0.0:
        # A recent genuine failure inside its retry window — the honest
        # classified 503 (never re-presented as "preparing").
        logger.info("WEBSITE_HLS_ENSURE file_pk=%s ok=no dir_exists=no "
                    "master_exists=no reason=recent_failure_backoff",
                    file_pk)
        return _json(503, "transcode_failed",
                     "This video could not be prepared for this browser.",
                     file_pk, raw_path)
    else:
        # START or JOIN the ONE background preparation job, then answer
        # the honest temporary 503 hls_preparing.
        try:
            _started = await manager.start_hls_preparation(
                file_unique_id, source_path_fn)
        except Exception as e:  # noqa: BLE001 — honest classification
            logger.warning("WEBSITE_HLS_ENSURE_ERROR file_pk=%s detail=%s",
                           file_pk, type(e).__name__, exc_info=True)
            logger.info("WEBSITE_HLS_ENSURE file_pk=%s ok=no dir_exists=no "
                        "master_exists=no reason=ensure_error:%s",
                        file_pk, type(e).__name__)
            return _json(503, "transcode_failed",
                         "The transcoding pipeline failed to start.",
                         file_pk, raw_path)
        if not bool(_started.get("started")):
            # A live job already exists — this request JOINED it (the
            # coalescing guarantee: concurrent requests share ONE job).
            logger.info("HLS_PREPARE_WAIT file_pk=%s state=already_running "
                        "retry_after=2", file_pk)
        logger.info("WEBSITE_HLS_ENSURE file_pk=%s ok=no dir_exists=no "
                    "master_exists=no reason=hls_preparing", file_pk)
        return _json(503, "hls_preparing",
                     "This video is being prepared for playback. It will "
                     "be ready shortly — retry in a few seconds.",
                     file_pk, raw_path)

    if base is None:
        # Legacy manager wiring without the snapshot API — the ORIGINAL
        # synchronous ensure_hls path (kept only for exotic test doubles;
        # every production wiring resolves the real TranscodeManager).
        try:
            result = await manager.ensure_hls(file_unique_id, source_path_fn)
        except Exception as e:  # noqa: BLE001 — honest classification
            logger.warning("WEBSITE_HLS_ENSURE_ERROR file_pk=%s detail=%s",
                           file_pk, type(e).__name__, exc_info=True)
            logger.info("WEBSITE_HLS_ENSURE file_pk=%s ok=no dir_exists=no "
                        "master_exists=no reason=ensure_error:%s",
                        file_pk, type(e).__name__)
            return _json(503, "transcode_failed",
                         "The transcoding pipeline failed to start.",
                         file_pk, raw_path)
        if not result.ok or result.dir is None:
            logger.warning("WEBSITE_HLS_ENSURE_FAILED file_pk=%s error=%s",
                           file_pk, result.error)
            # BOT-40 (Section B): the SAFE reason head only (the
            # classification prefix — paths/exception tails are dropped).
            _reason = str(result.error or "").split(":", 1)[0][:80] \
                or "transcode_failed"
            logger.info("WEBSITE_HLS_ENSURE file_pk=%s ok=no dir_exists=no "
                        "master_exists=no reason=%s", file_pk, _reason)
            return _json(503, "transcode_failed",
                         "This video could not be prepared for this browser.",
                         file_pk, raw_path)
        base = Path(result.dir)
        master_name = str(result.master or "master.m3u8")
        try:
            _dir_ok = base.is_dir()
        except Exception:  # noqa: BLE001 — stat best-effort
            _dir_ok = False
        logger.info("WEBSITE_HLS_ENSURE file_pk=%s ok=yes dir_exists=%s "
                    "master_exists=yes reason=-", file_pk,
                    "yes" if _dir_ok else "no")

    # ---- 7. resolve + serve the requested file -------------------------
    if kind == "master":
        file_path = base / master_name
        media_type = HLS_PLAYLIST_CONTENT_TYPE
        max_age = HLS_PLAYLIST_MAX_AGE
        ranged = False
    elif kind == "playlist":
        file_path = base / variant / "index.m3u8"
        media_type = HLS_PLAYLIST_CONTENT_TYPE
        max_age = HLS_PLAYLIST_MAX_AGE
        ranged = False
    else:
        file_path = base / variant / filename
        media_type = HLS_SEGMENT_CONTENT_TYPE
        max_age = HLS_SEGMENT_MAX_AGE
        ranged = True
    if not file_path.is_file():
        return _json(404, "hls_output_missing",
                     "HLS output is not present yet.",
                     file_pk, raw_path)
    try:
        resp = await _serve_hls_file(request, file_path, media_type,
                                     max_age, ranged=ranged)
    except Exception:  # noqa: BLE001 — honest 503, never a traceback
        logger.warning("WEBSITE_HLS_SERVE_ERROR file_pk=%s path=%s",
                       file_pk, raw_path, exc_info=True)
        return _json(503, "serve_failed",
                     "The HLS file could not be served.", file_pk, raw_path)
    if resp is None:
        return _json(404, "not_found", "HLS segment vanished mid-request.",
                     file_pk, raw_path)
    # BOT-40 (Section B): the FINAL serve outcome — the classified twin of
    # the legacy WEBSITE_HLS_REQUEST line (which stays for grep continuity).
    logger.info("WEBSITE_HLS_SERVE file_pk=%s kind=%s status=%s",
                file_pk, kind, resp.status)
    logger.info("WEBSITE_HLS_REQUEST file_pk=%s path=%s status=%s",
                file_pk, raw_path, resp.status)
    return resp


__all__ = [
    "register_hls_routes", "handle_site_hls", "validate_hls_path",
    "HLS_ROUTE", "HLS_PLAYLIST_CONTENT_TYPE", "HLS_SEGMENT_CONTENT_TYPE",
    "HLS_PLAYLIST_MAX_AGE", "HLS_SEGMENT_MAX_AGE",
]
