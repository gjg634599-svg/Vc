"""WEBSITE PHASE 3 — multi-token Telegram WebApp initData validation.

The Phase 0 audit found the existing WebApp authentication validates ONLY
the main BOT_TOKEN — a Mini App launched from a NETWORK bot signs its
initData with THAT bot's token and would 401. This module adds the
multi-token resolver on top of the EXISTING canonical validator
(app/web/auth.py — never a second HMAC implementation):

  1. main BOT_TOKEN first (never breaks main-bot authentication);
  2. then every ACTIVE network bot token, decrypted through the existing
     credential vault/registry (never logged, never exposed).

Tokens are resolved via an injected async provider (bot.py wires the
registry-backed one) and cached briefly by the PROVIDER side to avoid
per-request decryption. Server-side ONLY — the client user id / username /
auth flags are NEVER trusted; the authenticated identity comes exclusively
from the HMAC-verified initData (spec §11/§20).
"""
from __future__ import annotations

import logging
from types import SimpleNamespace
from typing import Any, Dict, Optional

logger = logging.getLogger("payload-bot")


def make_multi_token_web_auth(main_bot_token: Optional[str],
                              network_tokens_provider,
                              *, validate_with_token,
                              max_age_seconds: int = 86400):
    """Build the multi-token validator.

    ``validate_with_token``: the canonical single-token validator —
    ``_validate_webapp_init_data(init_data, bot_token, max_age)`` from
    app/web/auth.py (injected; NO duplicate HMAC code here).
    ``network_tokens_provider``: async () -> [{"token": str,
    "bot_id": int}, ...] (ACTIVE network bots only).
    """

    async def validate_init_data(init_data: str) -> Optional[Dict[str, Any]]:
        """Validate initData against the main bot, then ACTIVE network bots.

        Returns {"user": {...}, "user_id": int, "via": "main"|"network",
        "bot_id": int|None, "auth_date": int} or None on ANY failure
        (invalid signature, stale auth_date, no user) — never raises.
        """
        if not init_data:
            return None
        # 1. Main bot first — existing behavior is never affected.
        if main_bot_token:
            try:
                v = validate_with_token(init_data, main_bot_token,
                                        max_age_seconds)
            except Exception:  # noqa: BLE001 — fail closed
                v = None
            if v:
                uid = int((v.get("user") or {}).get("id") or 0)
                if uid:
                    return {"user": v.get("user") or {}, "user_id": uid,
                            "via": "main", "bot_id": None,
                            "auth_date": v.get("auth_date")}
        # 2. ACTIVE network bots (Mini Apps launched from network bots).
        try:
            candidates = await network_tokens_provider() if callable(
                network_tokens_provider) else []
        except Exception:  # noqa: BLE001 — degrade to main-token-only
            candidates = []
            logger.debug("website multi-token provider unavailable — "
                         "main-bot validation only", exc_info=True)
        for nb in candidates or []:
            token = (nb or {}).get("token") or ""
            if not token or token == main_bot_token:
                continue
            try:
                v = validate_with_token(init_data, token, max_age_seconds)
            except Exception:  # noqa: BLE001 — fail closed
                v = None
            if v:
                uid = int((v.get("user") or {}).get("id") or 0)
                if uid:
                    return {"user": v.get("user") or {}, "user_id": uid,
                            "via": "network",
                            "bot_id": int((nb or {}).get("bot_id") or 0),
                            "auth_date": v.get("auth_date")}
        return None

    return SimpleNamespace(validate_init_data=validate_init_data)
