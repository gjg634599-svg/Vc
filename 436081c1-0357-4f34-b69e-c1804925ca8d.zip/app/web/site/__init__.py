"""WEBSITE PHASE 3 — the Website Payload presentation platform.

Standalone presentation layer for the canonical Payload system. NEVER a
second Payload engine, a second search engine or a second access engine:

  * listings reference ``payloads.id`` / ``collections.collection_id``
    (canonical, never copied media);
  * the feed/search/pagination run DB-side on the shared Phase 2
    facilities (ONE search system);
  * authorization calls the EXISTING ``access_engine`` — the Website OFF
    flag is checked HERE (presentation concern), NEVER inside the Access
    Engine (spec §5/§12).

Modules:
  service     — website_enabled setting, thumbnail fallback chain, link
                parsing helpers, listing lifecycle helpers
  tokens      — opaque short-lived SIGNED video references (AEAD via the
                existing CredentialVault; no DB ids in URLs)
  ratelimit   — bounded in-process rate limiting for website endpoints
  auth        — multi-token Telegram WebApp initData validation (main bot
                + ACTIVE network bots)
  html        — XSS-safe mobile-first HTML rendering
  pages       — the aiohttp handlers + route registration
"""
from app.web.site.service import make_website_service
from app.web.site.tokens import make_video_token_codec
from app.web.site.auth import make_multi_token_web_auth

__all__ = [
    "make_website_service",
    "make_video_token_codec",
    "make_multi_token_web_auth",
    "register_site_routes",
]


def register_site_routes(app, deps_factory):
    """Register the public Website routes on the EXISTING Mini App aiohttp
    application (called from bot.py ``start_mini_app_server`` AFTER the
    pinned Watch Ads routes — additive lines only)."""
    from app.web.site.pages import _register_routes
    return _register_routes(app, deps_factory)
