"""WEBSITE site sessions (GAP-CLOSURE spec §21-§23).

The identity backbone of the Website login flow:

    Telegram WebApp initData (HMAC-validated server-side)
        → optional additional confirmation (user ID OR username)
        → SERVER-COMPARED against the authenticated identity
        → signed site-session cookie
        → verified user display + age confirmation + ad identity

The session token REUSES the existing CredentialVault AEAD (the same
construction as the video references / stream tokens — no new
cryptography). Cookie value (B23-3 §5.19, format ``s2``):

    AEAD("s2|{user_id}|{username}|{first_name}|{age_ok}|{session_key}|{exp}")

where the free-text fields (``username`` / ``first_name`` /
``session_key``) are PERCENT-ESCAPED (``|`` → ``%7C``, ``%`` → ``%25``)
BEFORE encryption — a first_name like ``A|B`` can no longer break the
``|``-split on decode (the pre-B23 ``s1`` format split the DECRYPTED
plaintext on ``|`` and demanded exactly 7 parts, so any ``|`` inside a
field failed the session closed). The escaping lives INSIDE the AEAD
plaintext, so authentication coverage is unchanged. Legacy ``s1``
cookies (no ``|`` possible in their valid fields) still decode — the
raw pre-escape values are returned for them until they expire.

* ``user_id``      — the ONLY authoritative identity (never client-set)
* ``username``     — the Telegram username at login (display only; may be
                     empty → "Telegram User", spec §23)
* ``age_ok``       — the 18+ confirmation flag (spec §29; re-issued on an
                     explicit age-confirm API call)
* ``session_key``  — random per-session id (ad frequency session caps,
                     spec §52)
* ``exp``          — absolute expiry (default 12h, from the
                     website_session_ttl_seconds setting)

Security: HttpOnly + SameSite=Lax + Secure-when-https cookie; the session
GRANTS IDENTITY ONLY — it never grants payload access (the Access Engine
still authorizes every payload/stream separately, spec §25) and never
bypasses Force Join (spec §24).
"""
from __future__ import annotations

import re
import secrets
import time
from types import SimpleNamespace
from typing import Any, Dict, Optional, Tuple

from app.network.credentials import CredentialVault

# Default session lifetime (seconds) — clamped at construction.
WEBSITE_SESSION_TTL_DEFAULT = 43200  # 12 hours
WEBSITE_SESSION_TTL_MIN = 300        # 5 minutes
WEBSITE_SESSION_TTL_MAX = 7 * 86400  # 7 days

SESSION_COOKIE_NAME = "endie_site"
_VERSION = "s1"            # legacy wire format (raw fields, no escaping)
_VERSION_ESCAPED = "s2"    # B23-3 §5.19: percent-escaped free-text fields

# Percent-escaping for the ``|``-delimited wire format: the encoder only
# ever emits ``%25`` / ``%7C`` escapes, so the single-pass decoder below is
# an exact inverse (``%`` is escaped FIRST, so no double-decode is
# possible — "A%7CB" encodes to "A%257CB" and round-trips).
_ESCAPE_RE = re.compile(r"%(25|7C)")


def _escape_field(value: str) -> str:
    return (str(value or "")
            .replace("%", "%25")
            .replace("|", "%7C"))


def _unescape_field(value: str) -> str:
    return _ESCAPE_RE.sub(
        lambda m: "%" if m.group(1) == "25" else "|", value)


def clamp_session_ttl(ttl_seconds: Optional[int]) -> int:
    try:
        ttl = int(ttl_seconds or WEBSITE_SESSION_TTL_DEFAULT)
    except (TypeError, ValueError):
        ttl = WEBSITE_SESSION_TTL_DEFAULT
    return max(WEBSITE_SESSION_TTL_MIN,
               min(WEBSITE_SESSION_TTL_MAX, ttl))


def make_site_session_codec(bot_token: Optional[str] = None,
                            *, ttl_seconds: Optional[int] = None):
    """Build the session encode/decode pair (CredentialVault AEAD)."""
    ttl = clamp_session_ttl(ttl_seconds or WEBSITE_SESSION_TTL_DEFAULT)
    vault = CredentialVault(bot_token_fallback=bot_token,
                                allow_ephemeral_fallback=True)

    def issue_session(user_id: int, *, username: str = "",
                      first_name: str = "", age_ok: bool = False,
                      ttl_override: Optional[int] = None,
                      session_key: Optional[str] = None) -> str:
        """Mint a signed session token for an ALREADY-AUTHENTICATED user."""
        expires_at = int(time.time()) + clamp_session_ttl(
            ttl_override if ttl_override is not None else ttl)
        key = session_key or secrets.token_hex(8)
        # B23-3 §5.19: escape the free-text fields so a first_name like
        # "A|B" cannot break the | -split on decode.
        plaintext = "|".join((
            _VERSION_ESCAPED, str(int(user_id)),
            _escape_field(str(username or "")[:64]),
            _escape_field(str(first_name or "")[:64]),
            "1" if age_ok else "0",
            _escape_field(str(key)), str(expires_at)))
        return vault.encrypt(plaintext)

    def decode_session(token: str) -> Optional[Dict[str, Any]]:
        """Validate + decode a session token. Fails CLOSED (None) on
        tampering, wrong key, malformed input or expiry — never raises."""
        try:
            raw = vault.decrypt(str(token or ""))
        except Exception:  # noqa: BLE001 — any failure fails closed
            return None
        parts = raw.split("|")
        if len(parts) != 7:
            return None
        if parts[0] == _VERSION_ESCAPED:
            username = _unescape_field(parts[2])
            first_name = _unescape_field(parts[3])
            session_key = _unescape_field(parts[5])
        elif parts[0] == _VERSION:
            # Legacy pre-B23 cookie: fields were stored RAW (a valid s1
            # token can by construction carry no "|" inside a field).
            username = parts[2]
            first_name = parts[3]
            session_key = parts[5]
        else:
            return None
        try:
            user_id = int(parts[1])
            expires_at = int(parts[6])
        except ValueError:
            return None
        if user_id <= 0 or expires_at < time.time():
            return None
        return {
            "user_id": user_id,
            "username": username,
            "first_name": first_name,
            "age_ok": parts[4] == "1",
            "session_key": session_key,
            "expires_at": expires_at,
        }

    return SimpleNamespace(
        issue_session=issue_session,
        decode_session=decode_session,
        ttl_seconds=ttl,
        cookie_name=SESSION_COOKIE_NAME,
    )


def session_cookie_header(token: str, *, ttl_seconds: int,
                          secure: bool = False) -> Tuple[str, str]:
    """The Set-Cookie (name, value) pair for an issued session token."""
    cookie = (
        f"{SESSION_COOKIE_NAME}={token}; Path=/; Max-Age={int(ttl_seconds)}; "
        f"HttpOnly; SameSite=Lax"
        + ("; Secure" if secure else ""))
    return "Set-Cookie", cookie


def clear_cookie_header() -> Tuple[str, str]:
    return "Set-Cookie", (
        f"{SESSION_COOKIE_NAME}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax")


def identity_matches(authenticated: Dict[str, Any],
                     confirm_user_id: Optional[str],
                     confirm_username: Optional[str]) -> bool:
    """The spec §22 additional-confirmation comparison.

    The entered identity is ONLY an extra confirmation: the backend
    compares it with the HMAC-authenticated Telegram identity. A wrong ID
    or wrong username REJECTS (user A can never enter user B's identity
    to gain access). Empty input (the user submitted nothing) simply
    skips the confirmation — the authenticated identity remains the sole
    authority (spec §22: \"If username unavailable: use authenticated
    Telegram ID as authoritative identity\").
    """
    if confirm_user_id is None and confirm_username is None:
        return True
    auth_uid = str(authenticated.get("user_id") or "")
    auth_username = str(authenticated.get("username") or "").strip().lstrip("@")
    if confirm_user_id is not None and str(confirm_user_id).strip():
        entered = str(confirm_user_id).strip()
        # tolerate the @-less id forms; reject anything else
        if entered != auth_uid:
            return False
    if confirm_username is not None and str(confirm_username).strip():
        entered = str(confirm_username).strip().lstrip("@").lower()
        if not auth_username or entered != auth_username.lower():
            return False
    return True
