"""WEBSITE PHASE 3 — website service: ON/OFF setting, thumbnail fallback
chain, payload-link parsing and listing lifecycle helpers.

Standalone module (never imports bot.py / telegram). All heavy lifting is
delegated to the canonical repositories on the shared Database; this module
only contains PRESENTATION decisions.
"""
from __future__ import annotations

import logging
import re
from types import SimpleNamespace
from typing import Any, Dict, List, Optional, Tuple

from app.core.payload.service import (is_collection_link,
                                       parse_collection_link)
from app.storage.dbutil import now_iso as _now_iso

logger = logging.getLogger("app.web.site.service")

# bot_settings keys (v31 seeds; defaults keep the Website opt-in OFF).
WEBSITE_ENABLED_KEY = "website_enabled"
WEBSITE_PUBLIC_BASE_URL_KEY = "website_public_base_url"


def normalize_site_url(base_url: str, path: str) -> str:
    """BOT-16 — build a public Website URL with the base path normalized
    EXACTLY ONCE.

    Production evidence (bot-16.log): the site runs behind a prefix
    (Cloudflare Worker at ``https://host/site``) and the admin's
    ``website_public_base_url`` legitimately INCLUDES that prefix, while
    the INTERNAL route paths ALSO start with the ``site`` mount segment
    (``site/media/...``, ``site/payload/...``). Naive concatenation
    produced ``https://host/site/site/media/...`` → 404 on EVERY media
    request (the website video playback outage) and a broken
    ``.../site/site`` Main Mini App menu button on every network bot.

    Rule: when the configured base URL's path is a prefix of ``path``
    (segment-wise), the duplicate is NOT prepended again. The function is
    idempotent: ``normalize(normalize(base, p), p) == normalize(base, p)``.

    Examples (base | path -> result):
      https://h/site | /site/media/t -> https://h/site/media/t
      https://h      | /site/media/t -> https://h/site/media/t
      https://h/site/| site/media/t  -> https://h/site/media/t
      https://h/site | /site         -> https://h/site
      https://h/alt  | /site/media/t -> https://h/alt/site/media/t
      ""             | /site/media/t -> /site/media/t (relative)
    """
    base = str(base_url or "").strip().rstrip("/")
    raw = str(path or "/")
    path = "/" + raw.lstrip("/")
    if not base:
        return path
    try:
        from urllib.parse import urlsplit
        sp = urlsplit(base if "://" in base else f"//{base}",
                      scheme="https")
        authority = sp.netloc
        base_path = sp.path.rstrip("/")
        scheme = f"{base.split('://', 1)[0]}://" if "://" in base else ""
    except Exception:  # noqa: BLE001 — never fail URL building
        authority, base_path, scheme = "", "", ""
    segs_base = [s for s in base_path.split("/") if s]
    segs_path = [s for s in path.split("/") if s]
    overlap = 0
    if segs_base and segs_path:
        for k in range(min(len(segs_base), len(segs_path)), 0, -1):
            if segs_base[-k:] == segs_path[:k]:
                overlap = k
                break
    if overlap:
        # The base already carries the head of ``path`` — keep the base's
        # authority + base path, then append only the non-duplicated tail.
        tail = segs_path[overlap:]
        out_path = base_path + (("/" + "/".join(tail)) if tail else "")
        if authority:
            # A schemeless base yields a protocol-relative URL (//host/...).
            return f"{scheme}{authority}{out_path}" if scheme \
                else f"//{authority}{out_path}"
        return base + (("/" + "/".join(tail)) if tail else "")
    return f"{base}{path}"

# Thumbnail priority chain (spec §17): configured Website thumbnail →
# payload image → indexed image → Telegram thumbnail → fallback.
# Phase 3 resolves the chain as DATA (a descriptor); rendering actual
# thumbnail bytes over HTTP is the Phase 4 Media Gateway's job — until
# then every level renders the styled placeholder art.
THUMB_SOURCE_CONFIGURED = "configured"
THUMB_SOURCE_INDEXED = "indexed"
THUMB_SOURCE_TELEGRAM = "telegram"
THUMB_SOURCE_FALLBACK = "fallback"

# Acceptable "send me the payload link" input shapes:
#   https://t.me/<bot>?start=<arg>   (full deep link)
#   https://t.me/<bot>/<arg>         (older style)
#   t.me/<bot>?start=<arg>
#   <arg>                            (bare routing code: slug / c<code> /
#                                     <display>_<routing>)
_TME_START_RE = re.compile(
    r"^(?:https?://)?t\.me/(?P<bot>[A-Za-z0-9_]{4,64})"
    r"(?:\?start=|/)(?P<arg>[A-Za-z0-9_-]{1,64})/?$",
    re.IGNORECASE)


def parse_payload_link_input(text: str) -> Optional[str]:
    """Extract the routing argument from an admin-provided Payload link.

    Accepts full t.me deep links or a bare routing code. Returns the
    extracted routing argument (lowercased), or None for input that is not
    a plausible payload reference (the caller then shows a friendly error).
    NEVER throws — malformed input is handled by the caller.
    """
    if not text:
        return None
    raw = str(text).strip()
    if not raw:
        return None
    m = _TME_START_RE.match(raw)
    if m:
        return m.group("arg").lower()
    # Bare routing code (payload slug, c<code> collection link, or a
    # <display>_<routing> deep-link argument). Guard against garbage /
    # other URLs / injection attempts with a strict charset + length bound.
    if len(raw) > 64:
        return None
    if not re.fullmatch(r"[A-Za-z0-9_-]+", raw):
        return None
    if raw.lower().startswith(("http://", "https://", "t.me/")):
        return None
    return raw.lower()


def make_website_service(db):
    """Bind the presentation service to the shared canonical Database."""

    async def website_enabled() -> bool:
        """GLOBAL Website ON/OFF (bot_settings; default OFF — opt-in)."""
        try:
            return await db.get_setting_bool(WEBSITE_ENABLED_KEY, False)
        except Exception:  # noqa: BLE001 — fail CLOSED (maintenance page)
            return False

    async def set_website_enabled(enabled: bool) -> None:
        await db.set_setting(WEBSITE_ENABLED_KEY,
                             "true" if enabled else "false")

    async def website_public_base_url() -> str:
        try:
            return str(await db.get_setting(WEBSITE_PUBLIC_BASE_URL_KEY, "")
                       or "").strip()
        except Exception:  # noqa: BLE001
            return ""

    async def set_website_public_base_url(url: str) -> None:
        await db.set_setting(WEBSITE_PUBLIC_BASE_URL_KEY, str(url or "").strip())

    def build_site_url(path: str, base_url: str = "") -> str:
        """Build a public Website URL (absolute when a base URL is
        configured, relative otherwise). ``path`` must already be the
        urlencoded path portion.

        BOT-16: delegates to :func:`normalize_site_url` so the mount
        prefix is prepended exactly once (see its docstring for the
        production /site/site/media 404 evidence)."""
        return normalize_site_url(base_url, path)

    def resolve_thumbnail(listing: Optional[Dict[str, Any]],
                          file_row: Optional[Dict[str, Any]] = None
                          ) -> Dict[str, Any]:
        """Resolve the Website thumbnail PRIORITY chain (spec §17).

        Returns a descriptor (data-level only — Phase 3 renders styled
        placeholder art for every level; Phase 4's Media Gateway turns the
        resolved reference into servable bytes):
          configured  — the admin-supplied Website thumbnail
          indexed     — the canonical indexed file's own thumbnail
                        (file_unique_id identity; covers payload image /
                        indexed image levels)
          telegram    — a Telegram thumbnail reference WITHOUT stable
                        identity (thumb_file_id only) — lowest-priority ref
          fallback    — styled placeholder art
        """
        listing = listing or {}
        file_row = file_row or {}
        if listing.get("thumb_file_unique_id") or listing.get("thumb_file_id"):
            return {
                "source": THUMB_SOURCE_CONFIGURED,
                "file_unique_id": listing.get("thumb_file_unique_id"),
                "file_id": listing.get("thumb_file_id"),
            }
        if file_row.get("thumb_file_unique_id") or file_row.get("thumb_file_id"):
            return {
                "source": THUMB_SOURCE_INDEXED,
                "file_unique_id": file_row.get("thumb_file_unique_id"),
                "file_id": file_row.get("thumb_file_id"),
            }
        if file_row.get("file_unique_id") and str(
                file_row.get("media_type") or "").lower() in (
                "photo", "image"):
            # The canonical file itself is an image — usable as its own card
            # art ("payload image / indexed image" levels of the chain).
            return {
                "source": THUMB_SOURCE_INDEXED,
                "file_unique_id": file_row.get("file_unique_id"),
                "file_id": file_row.get("file_id"),
            }
        return {"source": THUMB_SOURCE_FALLBACK,
                "file_unique_id": None, "file_id": None}

    async def resolve_canonical_for_wizard(
            routing_arg: str, *, resolve_payload_link=None
    ) -> Optional[Dict[str, Any]]:
        """Resolve an admin-provided routing argument to the CANONICAL
        payload/collection through the EXISTING Payload system.

        Order (mirrors the /start router's semantics — the collection
        link check runs FIRST, prefix stripped):
          1. exact collection link (c<code> → bare code; the collection
             must exist with at least one item)
          2. exact payload code (db.get_payload — slug OR alias)
          3. suffix-resolution via the injected bot.py resolver
             (_resolve_routing_id — display-name links), then 1/2 again.

        Returns {"kind": "payload", "payload_id": int, "payload": str,
        "display_name": str|None, "file_count": int, ...} or
        {"kind": "collection", "collection_id": str, "file_count": int}
        or None when nothing resolves (caller shows a friendly error and
        creates NO partial DB record).
        """
        arg = parse_payload_link_input(routing_arg or "")
        if not arg:
            return None
        # V26 (root-cause fix): the CANONICAL collection resolution — the
        # /start router semantics (is_collection_link FIRST, prefix
        # stripped). The old collection branch passed the c-PREFIXED arg
        # to db.get_collection (collections store BARE codes) so it was
        # dead code; a c-link then fell through to the payloads branch
        # (a payloads row named c<code> exists) and resolved as
        # kind="payload" with ONE file — diverging from /start and
        # mis-publishing multi-part packages as single-file listings.
        if is_collection_link(arg):
            code = parse_collection_link(arg)
            coll = None
            try:
                coll = await db.get_collection(code)
            except Exception:  # noqa: BLE001 — honest unknown
                coll = None
            if coll is not None:
                n_items = 0
                try:
                    n_items = await db.count_collection_items(code)
                except Exception:  # noqa: BLE001
                    n_items = 0
                if n_items > 0:
                    return {"kind": "collection", "collection_id": code,
                            "file_count": n_items}
        row = await db.get_payload(arg)
        if row:
            files = await db.get_payload_file_overview([int(row["id"])])
            if not files:
                return None  # payload exists but its file is gone — invalid
            return {
                "kind": "payload",
                "payload_id": int(row["id"]),
                "payload": row["payload"],
                "display_name": row["display_name"] if "display_name" in row.keys() else None,
                "file_unique_id": files[0]["file_unique_id"],
                "file_name": files[0]["file_name"],
                "media_type": files[0]["media_type"],
                "file_count": 1,
            }
        if resolve_payload_link is not None:
            try:
                resolved, _method = await resolve_payload_link(arg, 0)
            except Exception:  # noqa: BLE001
                resolved = None
            if resolved and resolved != arg:
                row = await db.get_payload(resolved)
                if row:
                    files = await db.get_payload_file_overview(
                        [int(row["id"])])
                    if files:
                        return {
                            "kind": "payload",
                            "payload_id": int(row["id"]),
                            "payload": row["payload"],
                            "display_name": row["display_name"] if "display_name" in row.keys() else None,
                            "file_unique_id": files[0]["file_unique_id"],
                            "file_name": files[0]["file_name"],
                            "media_type": files[0]["media_type"],
                            "file_count": 1,
                        }
                if is_collection_link(resolved):
                    # V26 (root-cause fix): the SAME c-prefix bug — strip
                    # it; collections store BARE codes (mirrors /start,
                    # which never looks up a collection by its c-link).
                    rcode = parse_collection_link(resolved)
                    rcoll = None
                    try:
                        rcoll = await db.get_collection(rcode)
                    except Exception:  # noqa: BLE001 — honest unknown
                        rcoll = None
                    if rcoll is not None:
                        rcnt = 0
                        try:
                            rcnt = await db.count_collection_items(rcode)
                        except Exception:  # noqa: BLE001
                            rcnt = 0
                        if rcnt > 0:
                            return {"kind": "collection",
                                    "collection_id": rcode,
                                    "file_count": int(rcnt)}
        return None

    async def get_listing_detail(opaque_id: str) -> Optional[Dict[str, Any]]:
        """Resolve a listing by PUBLIC opaque id into its full detail view:
        listing row + canonical metadata + the ORDERED file list (Part 1..N)
        with per-file short-lived signed video references.

        Single-file payload -> one file; collection -> all items in canonical
        position order. Dead canonical references resolve to None (honest
        404 — never a fabricated card).
        """
        listing = await db.get_website_payload_by_opaque(opaque_id)
        if listing is None:
            return None
        ld = dict(listing)
        files: List[Dict[str, Any]] = []
        canonical: Dict[str, Any] = {}
        if ld.get("collection_id"):
            coll = await db.get_collection(ld["collection_id"])
            if coll is None:
                return None  # canonical collection deleted — honest 404
            canonical = {
                "kind": "collection",
                "collection_id": str(coll["collection_id"]),
                "channel_id": coll["channel_id"] if "channel_id" in coll.keys() else None,
            }
            items = await db.get_collection_items(ld["collection_id"])
            for item in items:
                ikeys = item.keys()
                files.append({
                    "file_pk": int(item["id"]) if "id" in ikeys else None,
                    "file_unique_id": item["file_unique_id"] if "file_unique_id" in ikeys else None,
                    "file_name": item["file_name"] if "file_name" in ikeys else None,
                    "media_type": item["media_type"] if "media_type" in ikeys else None,
                    "file_size": item["file_size"] if "file_size" in ikeys else None,
                    "mime_type": item["mime_type"] if "mime_type" in ikeys else None,
                    "width": item["width"] if "width" in ikeys else None,
                    "height": item["height"] if "height" in ikeys else None,
                    "thumb_file_unique_id": item["thumb_file_unique_id"] if "thumb_file_unique_id" in ikeys else None,
                    "thumb_file_id": item["thumb_file_id"] if "thumb_file_id" in ikeys else None,
                    "file_id": None,  # NEVER exposed to the web layer
                    # A.6.6 (bot-25): the per-item DURABLE source reference
                    # (ci.channel_id / ci.message_id) — the pack row view
                    # needs the REAL chat, never a fabricated 0.
                    "channel_id": item["channel_id"] if "channel_id" in ikeys else None,
                    "message_id": item["message_id"] if "message_id" in ikeys else None,
                })
        elif ld.get("payload_id") is not None:
            prow = await db.get_payload_by_id(int(ld["payload_id"]))
            if prow is None:
                return None  # canonical payload deleted — honest 404
            pkeys = prow.keys()
            canonical = {
                "kind": "payload",
                "payload_id": int(prow["id"]),
                "payload": prow["payload"],
                "display_name": prow["display_name"] if "display_name" in pkeys else None,
                # BOT-13 §46/§48 + BOT-16: the per-payload Get File ON/OFF
                # control, surfaced so every page/API surface can enforce
                # it from ONE resolution (fail-open ONLY for legacy DBs
                # that somehow lack the v36 column — default ON is the
                # backward-compatible shape).
                # ``video_ad_destination`` is DEPRECATED (BOT-16 surface
                # separation): ad behavior is surface-based — the website
                # pre-roll follows the WEBSITE ad settings, Telegram Watch
                # Ads follow the Telegram settings. The column is no
                # longer surfaced to (or read by) any runtime surface.
                "show_get_file": (
                    bool(int(prow["show_get_file"]))
                    if "show_get_file" in pkeys
                    and prow["show_get_file"] is not None else True),
            }
            overview = await db.get_payload_file_overview(
                [int(ld["payload_id"])])
            if overview:
                f = overview[0]
                fkeys = f.keys()
                files.append({
                    "file_pk": int(f["file_pk"]),
                    "file_unique_id": f["file_unique_id"],
                    "file_name": f["file_name"],
                    "media_type": f["media_type"],
                    "file_size": f["file_size"],
                    "mime_type": f["mime_type"],
                    "width": f["width"],
                    "height": f["height"],
                    "thumb_file_unique_id": f["thumb_file_unique_id"],
                    "thumb_file_id": f["thumb_file_id"],
                    "file_id": None,  # NEVER exposed to the web layer
                    # A.6.6 (bot-25): the canonical indexed file's DURABLE
                    # source reference (now projected by
                    # get_payload_file_overview).
                    "channel_id": f["channel_id"] if "channel_id" in fkeys else None,
                    "message_id": f["message_id"] if "message_id" in fkeys else None,
                })
            # A.4 (bot-25): MULTI-FILE PAYLOAD EXPANSION — when the payload's
            # canonical indexed file is a MEMBER of a collection, the
            # listing expands to the collection's FULL ordered file list
            # (every part selectable, prev/next navigation across parts).
            # Otherwise the single-file fallback above is preserved
            # EXACTLY (a standalone payload stays one part).
            _expand_fn = getattr(db, "find_collection_id_for_index_id", None)
            if callable(_expand_fn) and files:
                try:
                    _index_id = int(prow["index_id"]) if "index_id" in pkeys \
                        and prow["index_id"] is not None else 0
                except (TypeError, ValueError):
                    _index_id = 0
                if _index_id:
                    _coll_id = None
                    try:
                        _coll_id = await _expand_fn(_index_id)
                    except Exception:  # noqa: BLE001 — expansion is additive
                        _coll_id = None
                    if _coll_id:
                        try:
                            _items = await db.get_collection_items(str(_coll_id))
                        except Exception:  # noqa: BLE001 — keep single-file
                            _items = []
                        _live = [it for it in _items
                                 if (it.keys() and it["id"] is not None)]
                        # V25 (§5): media integrity — a dead collection
                        # member is EXPLICITLY logged (never a silent
                        # drop): stored == live unless a dead row is
                        # reported here. The invariant trace makes any
                        # divergence (async race, partial indexing, dead
                        # join row) observable in production logs.
                        if len(_live) != len(_items):
                            logger.warning(
                                "WEBSITE_MEDIA_DEAD_DROPPED "
                                "collection=%s total=%s live=%s "
                                "dropped=%s (V25 §5: dead collection "
                                "members are logged, never silently "
                                "discarded)",
                                _coll_id, len(_items), len(_live),
                                len(_items) - len(_live))
                        if len(_live) > 1:
                            files = []
                            for item in _live:
                                ikeys = item.keys()
                                files.append({
                                    "file_pk": int(item["id"]),
                                    "file_unique_id": item["file_unique_id"],
                                    "file_name": item["file_name"],
                                    "media_type": item["media_type"],
                                    "file_size": item["file_size"],
                                    "mime_type": item["mime_type"],
                                    "width": item["width"],
                                    "height": item["height"],
                                    "thumb_file_unique_id": item["thumb_file_unique_id"],
                                    "thumb_file_id": item["thumb_file_id"],
                                    "file_id": None,  # NEVER exposed
                                    "channel_id": item["channel_id"] if "channel_id" in ikeys else None,
                                    "message_id": item["message_id"] if "message_id" in ikeys else None,
                                })
                            canonical["expanded_from_collection"] = str(_coll_id)
            # A payload listing with a dead file is still shown with the
            # honest "file unavailable" state ONLY when unpublished changes
            # are impossible; public rendering already filters this via the
            # feed query. For detail we keep the page but files list empty.
        else:
            return None  # invalid listing (no canonical ref) — honest 404
        eff_title = (ld.get("title") or canonical.get("display_name")
                     or canonical.get("payload")
                     or ld.get("collection_id") or "")
        # B24 (Phase 4): compute the per-kind media_counts from the FULL
        # resolved file list (collection items OR the A.4 multi-file
        # expansion) so the inner detail badge renders the truthful
        # "3 videos · 2 photos" instead of collapsing to files[0]. This
        # runs over files (the FULL list, pre-MAX_DETAIL_FILES cap) so
        # the displayed summary stays truthful even when the rendered
        # rows are capped. Pure local computation — no extra SQL.
        try:
            from app.web.site.html import aggregate_media_counts
            _mc = aggregate_media_counts(files)
        except Exception:  # noqa: BLE001 — rendering must never break
            _mc = {}
        # V26.2 (bot-41 §9-§11): PACKAGE CHILD DISPLAY LABELS. For a
        # PACKAGE (collection-kind listing, or the A.4 multi-file payload
        # expansion of a collection member) the individual file entries
        # are CHILDREN of the package — their raw original Telegram
        # filenames ("@OnlyHotNet - Rachel…", "a93c8e2cba30…") must NOT
        # become the user-facing entry identity on the Website. Each
        # child gets a subordinate, position-stable label ("Video 1",
        # "Video 2", … per media kind). The raw file_name stays fully
        # intact as INTERNAL metadata (indexing, admin panels, dedup,
        # reindex, diagnostics, ZIP member naming) — this projection
        # only adds a display field; it never rewrites the database.
        _is_package = bool(ld.get("collection_id")) or bool(
            canonical.get("expanded_from_collection"))
        if _is_package and len(files) > 1:
            _per_kind: Dict[str, int] = {}
            for _f in files:
                _kind = str(_f.get("media_type") or "file").lower()
                if _kind in ("video", "animation", "video_note"):
                    _noun = "Video"
                elif _kind in ("photo", "sticker"):
                    _noun = "Photo"
                elif _kind in ("audio", "voice"):
                    _noun = "Audio"
                else:
                    _noun = "File"
                _per_kind[_noun] = _per_kind.get(_noun, 0) + 1
                _f["display_label"] = f"{_noun} {_per_kind[_noun]}"
        return {
            "listing": ld,
            "canonical": canonical,
            "eff_title": str(eff_title),
            "files": files,
            "media_counts": _mc,
        }

    return SimpleNamespace(
        website_enabled=website_enabled,
        set_website_enabled=set_website_enabled,
        website_public_base_url=website_public_base_url,
        set_website_public_base_url=set_website_public_base_url,
        build_site_url=build_site_url,
        resolve_thumbnail=resolve_thumbnail,
        parse_payload_link_input=parse_payload_link_input,
        resolve_canonical_for_wizard=resolve_canonical_for_wizard,
        get_listing_detail=get_listing_detail,
    )
