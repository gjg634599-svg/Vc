"""WEBSITE PHASE 6 — PREMIUM STREAMING PLATFORM redesign (spec §20+).

XSS-safe mobile-first HTML rendering. Every dynamic value passes through
``esc()`` (html.escape). No external resources EXCEPT the official Telegram
Mini App SDK (``telegram-web-app.js`` in ``<head>`` — the same tag the
Watch Ads mini app loads; when it is unavailable the pages fall back to
the honest "Open in Telegram" state after a bounded wait), no ``javascript:``
URLs, and no inline event handlers (the ONLY surviving attribute-literal
handlers are the two pre-existing ``onerror="this.remove()"`` image guards;
everything else wires up through ``addEventListener`` inside ``<script>``
blocks).

Design language — the premium streaming pass:
  * design-token system in ``:root`` (near-black layered canvas #060609
    with a subtle violet undertone + a restrained radial lilac glow, muted
    violet/indigo/lilac accent family for the premium creator-platform
    identity, muted champagne #d9c290 for highlights/badges, refined type
    scale, uppercase micro-labels with letter-spacing);
  * sticky GLASS navigation bar (brand dot + "EndieFans" wordmark +
    "WEBSITE" tag, search, verified-user chip §23, theme toggle — dark /
    light (V25 §17: the System option was removed; legacy stored values
    are migrated once by the no-flash boot), persisted in localStorage
    "eutheme");
  * one-time cinematic welcome overlay (§30) — autoplay-safe, once
    per browser session, never re-fired on navigation (the Website sound
    system was REMOVED; the payload players and the ad video system stay);
  * category nav (§28): up to 3 chips + a "⋮ More" menu that always
    carries Collections / My Points / About / Settings; age-restricted
    categories are ALWAYS discoverable in the ⋮ More menu (B10-W2 spec
    §19: the 🔞 18+ entry renders even before age confirmation and links
    to /site/c/{slug}, which serves the age gate — the entry itself
    never carries restricted content);
  * glassmorphism pills, card hover lift + accent ring + art zoom, 16:9
    art with a bottom gradient overlay, kind badges, ``.skel`` shimmer;
  * AD SLOTS (§37) on feed/detail/video pages — an empty or missing slot
    renders NOTHING AT ALL (complete collapse, never an empty box); the
    ad html arrives pre-rendered from the caller and is placed verbatim;
  * motion: rise-in stagger + hover lift, all disabled under
    ``prefers-reduced-motion``;
  * a11y: skip link, :focus-visible rings, aria-current on the active
    page / sort option, touch targets >= 44px, safe-area insets for the
    Telegram WebApp (§33), semantic landmarks;
  * responsive grid: 1 column through the phone widths (360/375/390/412),
    2 at 768, 3 at 1024, 4 at >=1440 inside a centered 1320px rail —
    no horizontal overflow at any width.

The player page keeps the Phase 4 bootstrap EXACTLY as-is (it is
load-bearing: initData verification against /site/api/stream, the
deny/locked/ok verdict states, plresume: localStorage resume, parts
pills and prev/next navigation) and ADDS a pre-roll AD STAGE whose real
state machine is injected by the caller via ``head_extra`` — this module
only ships the markup plus ``window.__adStage`` placeholders.
"""
from __future__ import annotations

import html
import json
from typing import Any, Dict, Iterable, List, Optional
from urllib.parse import quote_plus

# BOT-16 (Work Item C.1): the pinned hls.js v1 CDN line the player loads
# dynamically ONLY when the stream issuance verdict is "transcode" (native
# HLS is preferred; every CDN failure gracefully falls back to the direct
# stream_url). One constant — the single place the URL lives.
HLSJS_CDN_URL = "https://cdn.jsdelivr.net/npm/hls.js@1/dist/hls.min.js"

# ---------------------------------------------------------------- tokens
# The whole visual system hangs off these custom properties: one dark
# cinematic palette (near-black layered canvas with a violet undertone +
# muted violet/lilac accent + champagne highlights), one radii/elevation
# ladder, one type scale and one motion
# vocabulary. Nothing else in the stylesheet hardcodes a brand color.
_SITE_CSS = """
:root{
/* palette — dark cinematic premium */
--bg:#060609;--bg-soft:#09080f;--surface:#0e0d16;--surface-2:#15131f;
--line:#242036;--line-soft:#1c1929;
--text:#f3f1f8;--muted:#a09aac;--faint:#655f73;
--accent:#a78bfa;--accent-dk:#8b6fd6;--accent-deep:#2e2447;
--accent-ink:#120b26;
--gold:#d9c290;--gold-soft:rgba(217,194,144,.12);--danger:#f87171;
--glass-bg:rgba(8,7,14,.62);--glass-line:rgba(255,255,255,.1);
/* radii */
--radius:18px;--radius-sm:12px;--radius-pill:999px;
/* elevation */
--shadow-1:0 1px 2px rgba(0,0,0,.5);
--shadow-2:0 16px 38px -16px rgba(0,0,0,.8);
--shadow-3:0 28px 64px -28px rgba(0,0,0,.9);
/* typography */
--font:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,
sans-serif;
--fs-display:clamp(25px,6vw,33px);
--fs-title:19px;--fs-body:14.5px;--fs-small:13px;--fs-micro:10.5px;
--ls-wide:1.5px;
/* motion */
--dur-1:.16s;--dur-2:.3s;--ease:cubic-bezier(.22,.61,.36,1);
/* layout */
--gap:16px;--pad:16px}
/* -------------------------------------------- light theme overrides
   The whole visual system re-tokenizes for [data-theme="light"]: paper
   white canvas, dark ink, the SAME violet/champagne accent families
   (tuned for contrast on light). A tiny inline head script resolves the stored
   "eutheme" preference (dark | light — V25 S17) BEFORE first paint, so
   there is never a dark→light flash. The few literal colors outside the
   tokens (selection, scrollbar, header glass, wordmark gradient, card
   copy, skeleton shimmer, intro overlay) are overridden below too. The
   PLAYER SURFACE (playerbox/adstage/audio bg) intentionally stays dark
   in both themes — video content areas read best on black and all the
   text around them uses the tokens. */
[data-theme="light"]{
--bg:#f7f6fa;--bg-soft:#efedf5;--surface:#ffffff;--surface-2:#f2f0f7;
--line:#ddd8ea;--line-soft:#e7e3f0;
--text:#1a1626;--muted:#5d5770;--faint:#8d8798;
--accent:#6a58b5;--accent-dk:#57479e;--accent-deep:#34295a;
--accent-ink:#ffffff;
--gold:#8a6d3b;--gold-soft:rgba(138,109,59,.12);--danger:#cc4b4b;
--glass-bg:rgba(255,255,255,.78);--glass-line:rgba(26,22,38,.12);
--shadow-1:0 1px 2px rgba(26,22,38,.08);
--shadow-2:0 16px 38px -16px rgba(26,22,38,.16);
--shadow-3:0 28px 64px -28px rgba(26,22,38,.24)}
[data-theme="light"] body{background:
radial-gradient(1100px 480px at 50% -12%,rgba(106,88,181,.08),transparent 58%),
radial-gradient(760px 380px at 108% -6%,rgba(138,109,59,.05),transparent 52%),
var(--bg)}
[data-theme="light"] ::selection{background:rgba(106,88,181,.28)}
[data-theme="light"] ::-webkit-scrollbar-thumb{background:#ccc7dc}
*{box-sizing:border-box;margin:0;padding:0}
html{-webkit-text-size-adjust:100%;scroll-behavior:smooth}
body{background:
radial-gradient(1100px 480px at 50% -12%,rgba(139,111,214,.11),transparent 58%),
radial-gradient(760px 380px at 108% -6%,rgba(217,194,144,.05),transparent 52%),
var(--bg);
color:var(--text);font-family:var(--font);line-height:1.55;min-height:100vh;
display:flex;flex-direction:column;-webkit-tap-highlight-color:transparent;
overflow-wrap:break-word}
a{color:var(--accent);text-decoration:none}
a:hover{text-decoration:underline}
img,svg,video,audio{max-width:100%}
::selection{background:rgba(167,139,250,.32)}
::-webkit-scrollbar{width:10px;height:10px}
::-webkit-scrollbar-thumb{background:#26223a;border-radius:8px}
::-webkit-scrollbar-track{background:transparent}
[hidden]{display:none!important}
.skip{position:absolute;left:-9999px;top:0;z-index:100;background:
var(--accent-dk);color:var(--accent-ink);font-weight:700;padding:10px 16px;
border-radius:0 0 10px 0}
.skip:focus{left:0}
a:focus-visible,button:focus-visible,input:focus-visible,summary:focus-visible{
outline:2px solid var(--accent);outline-offset:2px;border-radius:10px}

/* ------------------------------------------------- sticky glass header */
header.site{position:sticky;top:0;z-index:50;background:linear-gradient(
180deg,rgba(6,6,9,.92),rgba(6,6,9,.74));backdrop-filter:blur(18px)
saturate(150%);-webkit-backdrop-filter:blur(18px) saturate(150%);
border-bottom:1px solid rgba(255,255,255,.07);padding:10px 14px;display:
flex;flex-direction:column;gap:10px;box-shadow:0 12px 32px -20px
rgba(0,0,0,.85)}
[data-theme="light"] header.site{background:linear-gradient(
180deg,rgba(247,246,250,.94),rgba(247,246,250,.82));border-bottom-color:
rgba(26,22,38,.09);box-shadow:0 12px 32px -20px rgba(26,22,38,.28)}
.hrow{display:flex;align-items:center;justify-content:space-between;
gap:10px;flex-wrap:wrap}
.brand{display:flex;align-items:center;gap:10px;font-weight:800;
font-size:17px;letter-spacing:-.2px;min-height:44px}
.brand .dot{width:10px;height:10px;border-radius:50%;background:
var(--accent);box-shadow:0 0 16px var(--accent),0 0 5px var(--accent);
animation:dotpulse 3.2s ease-in-out infinite;flex:none}
.brand a{color:inherit}
.brand a:hover{text-decoration:none}
.brand .wordmark{background:linear-gradient(110deg,#fff 30%,
rgba(255,255,255,.78));-webkit-background-clip:text;background-clip:text;
color:transparent}
[data-theme="light"] .brand .wordmark{background:linear-gradient(110deg,
#1a1626 30%,rgba(26,22,38,.75));-webkit-background-clip:text;
background-clip:text}
.brand .brandtag{font-size:var(--fs-micro);font-weight:700;color:var(--gold);
border:1px solid rgba(217,194,144,.35);background:var(--gold-soft);
border-radius:var(--radius-pill);padding:3px 9px;letter-spacing:1.6px;
text-transform:uppercase;white-space:nowrap}
.hactions{display:flex;align-items:center;gap:10px;min-height:44px;
flex-wrap:wrap}
.userchip{display:flex;align-items:center;gap:9px;background:
rgba(167,139,250,.08);border:1px solid rgba(167,139,250,.28);border-radius:
var(--radius-pill);padding:5px 14px 5px 6px;min-height:44px}
.userchip .uava{width:32px;height:32px;border-radius:50%;background:
linear-gradient(140deg,var(--accent-deep),rgba(139,111,214,.4));display:
flex;align-items:center;justify-content:center;font-size:14px;flex:none}
.userchip .uinfo{display:flex;flex-direction:column;line-height:1.25;
min-width:0}
.userchip .uname{font-size:13px;font-weight:700;color:var(--text);
white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:150px}
.userchip .usub{font-size:var(--fs-micro);color:var(--accent);
letter-spacing:1px;text-transform:uppercase;font-weight:700}
.themebtn{width:44px;height:44px;min-width:44px;border-radius:50%;border:
1px solid var(--line);background:rgba(255,255,255,.04);color:var(--muted);
font-size:17px;line-height:1;display:flex;align-items:center;justify-content:
center;cursor:pointer;transition:border-color var(--dur-1) ease,box-shadow
var(--dur-1) ease,color var(--dur-1) ease}
.themebtn:hover{border-color:rgba(167,139,250,.5);color:var(--text)}
.themebtn[aria-pressed="true"]{border-color:rgba(167,139,250,.55);
color:var(--accent);box-shadow:0 0 0 3px rgba(167,139,250,.12)}
[data-theme="light"] .themebtn{background:rgba(26,22,38,.05)}

/* ------------------------------------------------------------ search */
form.search{display:flex;gap:8px}
.searchwrap{flex:1;min-width:0;position:relative;display:flex;
align-items:center}
.searchwrap .searchicon{position:absolute;left:14px;width:16px;height:16px;
color:var(--faint);pointer-events:none}
input[type=search]{flex:1;min-width:0;background:rgba(255,255,255,.045);
color:var(--text);border:1px solid var(--line);border-radius:
var(--radius-pill);padding:11px 16px 11px 40px;font-size:15px;
font-family:inherit;min-height:44px;outline:none;transition:border-color
var(--dur-1) ease,box-shadow var(--dur-1) ease}
input[type=search]::placeholder{color:var(--faint)}
input[type=search]:focus{border-color:var(--accent-dk);box-shadow:
0 0 0 3px rgba(139,111,214,.16)}
[data-theme="light"] input[type=search]{background:rgba(26,22,38,.05)}
button.searchbtn{background:linear-gradient(135deg,var(--accent),
var(--accent-dk));color:var(--accent-ink);border:none;border-radius:
var(--radius-pill);width:44px;height:44px;min-width:44px;display:flex;
align-items:center;justify-content:center;cursor:pointer;transition:
transform var(--dur-1) ease,filter var(--dur-1) ease}
button.searchbtn svg{width:17px;height:17px}
button.searchbtn:hover{filter:brightness(1.08)}
button.searchbtn:active{transform:scale(.94)}

/* ------------------------------------------------- category nav §28 */
.catnav{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.catchip{display:inline-flex;align-items:center;gap:7px;background:
rgba(255,255,255,.04);border:1px solid var(--line);border-radius:
var(--radius-pill);padding:9px 15px;font-size:13px;font-weight:600;
color:var(--muted);min-height:44px;max-width:100%;min-width:0;transition:color
var(--dur-1) ease,border-color var(--dur-1) ease,background var(--dur-1)
ease}
.catchip .clabel{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.catchip .cico{font-size:14px;line-height:1;flex:none}
[data-theme="light"] .catchip{background:rgba(26,22,38,.04)}
a.catchip:hover{text-decoration:none;color:var(--text);border-color:
rgba(167,139,250,.5);background:rgba(167,139,250,.08)}
/* B24 (Phase 3): the ACTIVE category chip — clear affordance of which
   category the user is currently viewing (matches the active feed page). */
.catchip.cur,.catchip[aria-current="page"]{color:var(--accent);border-color:
var(--accent);background:rgba(167,139,250,.12)}
[data-theme="light"] .catchip.cur,[data-theme="light"] .catchip[aria-current="page"]{background:rgba(167,139,250,.14)}
.catmore{position:relative;display:inline-flex}
.catmore summary{list-style:none;cursor:pointer;font-family:inherit}
.catmore summary::-webkit-details-marker{display:none}
.catmore summary:hover{color:var(--text);border-color:
rgba(167,139,250,.5)}
/* V25 (§25): the More chevron — DOWN when closed, UP when open (the
   toggle-event sync in _UX_JS keeps aria-expanded + the rotation on the
   ONE canonical <details> state; no second panel, no stale state). */
.catmore .chev{display:inline-flex;align-items:center;margin-left:2px}
.catmore .chev svg{width:14px;height:14px;transition:transform .18s ease}
.catmore[open] .chev svg{transform:rotate(180deg)}
.moremenu{position:absolute;top:calc(100% + 10px);left:0;min-width:216px;
max-width:min(300px,calc(100vw - 28px));
max-height:calc(100dvh - 130px);max-height:calc(100vh - 130px);overflow-y:auto;
-webkit-overflow-scrolling:touch;
background:rgba(10,9,16,.97);backdrop-filter:blur(18px);-webkit-backdrop-
filter:blur(18px);border:1px solid var(--line);border-radius:14px;
padding:8px;box-shadow:var(--shadow-3);display:flex;flex-direction:column;
gap:2px;z-index:80}
[data-theme="light"] .moremenu{background:rgba(255,255,255,.97)}
/* phones (<768): the dropdown becomes a sheet anchored to the whole
   sticky header so it can never clip off either edge of the viewport */
@media(max-width:767px){
.catmore{position:static}
.moremenu{left:14px;right:14px;min-width:0;max-width:none}
}
.mmitem{display:flex;align-items:center;gap:11px;padding:11px 13px;
border-radius:10px;color:var(--muted);font-size:13.5px;font-weight:600;
min-height:44px;white-space:nowrap;min-width:0;overflow:hidden}
.mmitem .mmlabel,.mmitem>span:not(.r18mark):not(svg){min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1 1 auto}
.mmitem svg{width:16px;height:16px;color:var(--accent);flex:none}
.mmitem.r18{color:var(--gold)}
.mmitem.r18 svg{color:var(--gold)}
/* B10-W2 §19: the guaranteed 🔞 marker on the always-visible 18+ nav
entry (renderer-supplied — never the admin-managed category icon) and the
confirmed-category 18+ pill on /site/c/{slug} */
.mmitem .r18mark{font-size:15px;line-height:1;flex:none}
.r18pill{color:var(--gold);border-color:rgba(217,194,144,.45)}
a.mmitem:hover{text-decoration:none;background:rgba(167,139,250,.1);
color:var(--text)}
.mmdiv{height:1px;background:var(--line-soft);margin:6px 4px}

/* ---------------------------------------------------- main + grid */
main.site{flex:1;width:100%;max-width:860px;margin:0 auto;padding:20px
var(--pad) 40px}
.narrow{width:100%;max-width:920px;margin:0 auto}
/* phones 360/375/390/412: single column (base rule) */
.grid{display:grid;grid-template-columns:minmax(0,1fr);gap:var(--gap)}
@media(min-width:768px){.grid{grid-template-columns:repeat(2,minmax(0,1fr));
gap:18px}}
@media(min-width:1024px){.grid{grid-template-columns:repeat(3,minmax(0,1fr));
gap:20px}main.site{max-width:1120px}}
@media(min-width:1440px){.grid{grid-template-columns:repeat(4,minmax(0,1fr));
gap:22px}main.site{max-width:1320px}}

@keyframes rise{from{opacity:0;transform:translateY(12px)}to{opacity:1;
transform:none}}
@keyframes dotpulse{0%,100%{box-shadow:0 0 16px var(--accent),0 0 5px
var(--accent)}50%{box-shadow:0 0 6px var(--accent),0 0 2px var(--accent)}}
@keyframes floaty{0%,100%{transform:translateY(0)}50%{transform:
translateY(-7px)}}
@keyframes thinking{0%,100%{opacity:1}50%{opacity:.4}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes shimmer{to{transform:translateX(100%)}}
@keyframes wpulse{0%,100%{opacity:.55;transform:scale(.92)}50%{opacity:1;
transform:scale(1.06)}}
@keyframes wrise{from{opacity:0;transform:translateY(16px) scale(.97)}to{
opacity:1;transform:none}}
@keyframes wreveal{from{opacity:0;letter-spacing:.95em}to{opacity:1;
letter-spacing:.55em}}

/* skeleton shimmer (spec §20 design system) */
.skel{position:relative;overflow:hidden;background:var(--surface-2);
border-radius:var(--radius-sm);min-height:44px}
.skel::after{content:"";position:absolute;inset:0;transform:
translateX(-100%);background:linear-gradient(90deg,transparent,
rgba(255,255,255,.06),transparent);animation:shimmer 1.5s ease-in-out
infinite}
[data-theme="light"] .skel::after{background:linear-gradient(90deg,
transparent,rgba(26,22,38,.06),transparent)}

/* -------------------------------------------------------- feed head */
.feedhead{display:flex;flex-direction:column;gap:12px;margin:2px 0 18px}
@media(min-width:640px){.feedhead{flex-direction:row;align-items:
flex-end;justify-content:space-between}}
.kicker{font-size:var(--fs-micro);font-weight:800;letter-spacing:
var(--ls-wide);text-transform:uppercase;color:var(--gold);margin-bottom:6px}
.feedtitle{font-size:var(--fs-display);font-weight:800;letter-spacing:
-.6px;line-height:1.15}
.feedmeta{font-size:13px;color:var(--muted);margin-top:6px}
.feedmeta b{color:var(--accent);font-weight:700}
.sortbar{display:inline-flex;background:var(--glass-bg);backdrop-filter:
blur(10px);-webkit-backdrop-filter:blur(10px);border:1px solid var(--line);
border-radius:var(--radius-pill);padding:4px;gap:2px;width:max-content;
max-width:100%;overflow-x:auto}
.sortopt{border-radius:var(--radius-pill);padding:9px 16px;font-size:13px;
font-weight:600;color:var(--muted);white-space:nowrap;min-height:44px;
display:flex;align-items:center;transition:color var(--dur-1) ease,
background var(--dur-1) ease}
.sortopt:hover{text-decoration:none;color:var(--text)}
.sortopt.cur{background:linear-gradient(135deg,var(--accent),
var(--accent-dk));color:var(--accent-ink);box-shadow:0 6px 16px -8px
rgba(139,111,214,.8)}

/* ------------------------------------------------------------ cards */
.card{background:linear-gradient(180deg,var(--surface) 0%,var(--bg-soft)
100%);border:1px solid var(--line);border-radius:var(--radius);overflow:
hidden;display:flex;flex-direction:column;box-shadow:var(--shadow-1);
transition:transform var(--dur-2) var(--ease),border-color var(--dur-2)
ease,box-shadow var(--dur-2) var(--ease);animation:rise .45s var(--ease)
both;animation-delay:min(calc(var(--i,0)*45ms),540ms);position:relative}
.card:hover{transform:translateY(-5px);border-color:rgba(167,139,250,.45);
box-shadow:0 0 0 1px rgba(167,139,250,.35),var(--shadow-3)}
.card:active{transform:translateY(-1px) scale(.99)}
a.cardlink{display:flex;flex-direction:column;color:inherit;height:100%}
a.cardlink:hover{text-decoration:none}
.thumb{position:relative;aspect-ratio:16/9;background:var(--surface-2);
display:flex;align-items:center;justify-content:center;overflow:hidden}
.thumb>svg,.thumb .thumbimg{width:100%;height:100%;display:block;
object-fit:cover;transition:transform .5s var(--ease)}
.thumb::after{content:"";position:absolute;inset:0;background:
linear-gradient(180deg,rgba(6,6,9,0) 42%,rgba(6,6,9,.72) 100%);
pointer-events:none;z-index:1}
.card:hover .thumb>svg,.card:hover .thumb .thumbimg{transform:scale(1.06)}
.thumbimg{position:absolute;inset:0;width:100%;height:100%;object-fit:
cover}
.glass{background:rgba(7,6,11,.6);backdrop-filter:blur(8px);
-webkit-backdrop-filter:blur(8px);border:1px solid var(--glass-line);
color:#fff}
.badge{position:absolute;right:10px;bottom:10px;z-index:2;border-radius:8px;
padding:4px 10px;font-size:11.5px;font-weight:700;display:flex;
align-items:center;gap:5px;letter-spacing:.2px;background:rgba(13,12,19,.66);
border:1px solid rgba(217,194,144,.35);color:var(--gold);backdrop-filter:
blur(8px);-webkit-backdrop-filter:blur(8px)}
.badge svg{width:12px;height:12px;opacity:.95}
.typepill{position:absolute;left:10px;top:10px;z-index:2;border-radius:
var(--radius-pill);padding:4px 11px;font-size:11px;font-weight:700;
display:flex;align-items:center;gap:5px;letter-spacing:.8px;
text-transform:uppercase}
.typepill svg{width:11px;height:11px}
.cardbody{padding:13px 15px 15px;display:flex;flex-direction:column;gap:7px}
.cardtitle{font-weight:700;font-size:15px;color:var(--text);display:
-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:
hidden;letter-spacing:-.1px}
.carddesc{font-size:13px;color:#a09aac;display:-webkit-box;
-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
[data-theme="light"] .carddesc{color:#5d5770}
.chips{display:flex;flex-wrap:wrap;gap:6px}
.chip{background:rgba(167,139,250,.07);color:var(--accent);border:1px solid
rgba(167,139,250,.18);border-radius:var(--radius-pill);padding:8px 12px;
font-size:12px;font-weight:600;min-height:44px;display:inline-flex;
align-items:center;transition:background var(--dur-1) ease,border-color
var(--dur-1) ease}
a.chip:hover{text-decoration:none;background:rgba(167,139,250,.15);
border-color:rgba(167,139,250,.4)}
.meta{font-size:12px;color:var(--muted)}
.sectionhead{margin:4px 0 12px;font-size:18px;font-weight:700}

/* ---------------------------------------------------- ad slots §37 */
.adslot{display:block;width:100%;margin:0;padding:0;border-radius:
var(--radius);overflow:hidden;position:relative}
.ad-collapsed{display:none}   /* §37/§44: failed creative = full collapse */
.ad-top{margin:0 0 18px}
.ad-foot{margin:22px 0 0}
.ad-native{grid-column:1/-1}
.ad-detail{margin:16px 0 0}

/* ---------------------------------------------------------- detail */
.detailhead{background:linear-gradient(180deg,var(--surface),var(--bg-soft));
border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;
margin-bottom:18px;box-shadow:var(--shadow-2);animation:rise .4s
var(--ease) both}
.detailbody{padding:20px}
.detailtitle{font-size:clamp(22px,5.5vw,30px);font-weight:800;
letter-spacing:-.6px;line-height:1.22}
.detaildesc{font-size:14px;color:var(--muted);margin-top:8px;line-height:1.65}
.metarow{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}
.metapill{display:inline-flex;align-items:center;gap:6px;background:
rgba(255,255,255,.04);border:1px solid var(--line);border-radius:
var(--radius-pill);padding:6px 13px;font-size:12.5px;font-weight:600;
color:var(--muted)}
[data-theme="light"] .metapill{background:rgba(26,22,38,.04)}
.metapill svg{width:13px;height:13px;color:var(--accent)}
.metapill b{color:var(--text);font-weight:700}
.backlink{display:inline-flex;align-items:center;gap:7px;background:
rgba(255,255,255,.04);border:1px solid var(--line);border-radius:
var(--radius-pill);padding:10px 17px 10px 13px;font-size:13.5px;
font-weight:600;color:var(--muted);min-height:44px;margin-bottom:14px;
transition:color var(--dur-1) ease,border-color var(--dur-1) ease,
transform var(--dur-1) ease}
[data-theme="light"] .backlink{background:rgba(26,22,38,.04)}
.backlink svg{width:16px;height:16px}
.backlink:hover{text-decoration:none;color:var(--text);border-color:
rgba(167,139,250,.5);transform:translateX(-2px)}
.fileslabel{font-size:var(--fs-micro);font-weight:800;color:var(--faint);
letter-spacing:var(--ls-wide);text-transform:uppercase;margin:2px 0 12px}
.filelist{display:flex;flex-direction:column;gap:10px}
/* V25 responsive: media rows clear the fixed bottom nav for ANY
   programmatic scroll (focus, hash, find-in-page) — the payload-detail
   finding: a row's focus target could land under the 57px nav. The
   page-level bottom clearance (main.site padding 116px) already lifts
   the last row fully above the nav when scrolled to the end. */
.filerow{scroll-margin-bottom:calc(70px + env(safe-area-inset-bottom,0px))}
.filerow{display:flex;align-items:center;gap:12px;background:var(--surface);
border:1px solid var(--line);border-radius:14px;padding:12px 14px;
box-shadow:var(--shadow-1);transition:border-color var(--dur-1) ease,
background var(--dur-1) ease,transform var(--dur-1) ease;animation:rise
.45s var(--ease) both;animation-delay:min(calc(var(--i,0)*60ms),480ms)}
.filerow:hover{border-color:rgba(167,139,250,.55);background:
var(--surface-2);transform:translateX(3px)}
a.filerow{color:inherit}
a.filerow:hover{text-decoration:none}
.partnum{flex-shrink:0;width:46px;height:46px;border-radius:13px;background:
linear-gradient(145deg,rgba(139,111,214,.18),rgba(139,111,214,.05));border:1px
solid rgba(139,111,214,.28);color:var(--accent);display:flex;align-items:
center;justify-content:center;font-weight:800;font-size:13px;
letter-spacing:.4px}
.partnum b{font-weight:800}
.fileinfo{flex:1;min-width:0}
.filename{display:block;font-weight:700;font-size:14px;white-space:nowrap;
overflow:hidden;text-overflow:ellipsis;letter-spacing:-.1px}
.filemeta{display:flex;align-items:center;gap:5px;font-size:11.5px;color:
var(--faint);margin-top:3px}
.filemeta svg{width:12px;height:12px;color:var(--faint);flex-shrink:0}
.filemeta b{color:var(--accent);font-weight:700;font-size:12px}
.playbtn{flex-shrink:0;width:44px;height:44px;border-radius:50%;border:1.5px
solid rgba(139,111,214,.6);color:var(--accent);display:flex;align-items:
center;justify-content:center;transition:background var(--dur-1) ease,
color var(--dur-1) ease,transform var(--dur-1) ease}
.filerow:hover .playbtn{background:linear-gradient(135deg,var(--accent),
var(--accent-dk));color:var(--accent-ink);transform:scale(1.06)}
.filerow:active{transform:translateX(3px) scale(.99)}
.filerow:active .playbtn{background:linear-gradient(135deg,var(--accent),
var(--accent-dk));color:var(--accent-ink);transform:scale(.92)}
/* V25 (§4): inner-media row thumbnails + kind-correct controls. The
rowthumb is the REAL per-file thumbnail bytes through the Media Gateway
(resolver supports file_pk>0); the partnum tile becomes the artwork frame
when a thumb exists, falling back to the P{n} numbering tile. */
.rowthumbwrap{position:relative;flex-shrink:0;width:64px;height:46px;
border-radius:11px;overflow:hidden;border:1px solid var(--line);
background:var(--surface-2,rgba(127,127,127,.08))}
.rowthumbwrap img{width:100%;height:100%;object-fit:cover;display:block}
.rowthumbwrap svg{width:100%;height:100%;display:block;color:var(--faint)}
.rowthumbkind{position:absolute;left:3px;bottom:3px;width:17px;height:17px;
border-radius:6px;background:rgba(9,8,14,.72);color:#ece5fb;display:flex;
align-items:center;justify-content:center;backdrop-filter:blur(3px)}
.rowthumbkind svg{width:10px;height:10px;color:#ece5fb}
/* V25 (§4): the part badge overlays the row artwork — the P<n> identity
   survives the thumbnail upgrade (ordering stays visible). */
.rowpart{position:absolute;right:3px;top:3px;min-width:17px;height:17px;
padding:0 4px;border-radius:6px;background:rgba(9,8,14,.72);color:#ece5fb;
display:flex;align-items:center;justify-content:center;font-size:9.5px;
font-weight:800;letter-spacing:.4px;backdrop-filter:blur(3px)}

/* --------------------------------------------------------- pager */
.pager{display:flex;gap:7px;justify-content:center;align-items:center;
margin-top:24px;flex-wrap:wrap}
.pgbtn,.pgnum,.pagerpos{background:var(--surface);border:1px solid
var(--line);border-radius:12px;min-height:44px;display:flex;align-items:
center;justify-content:center;color:var(--text);font-size:14px;box-shadow:
var(--shadow-1);transition:border-color var(--dur-1) ease}
.pgbtn{padding:0 17px;font-weight:600;gap:6px}
.pgbtn svg{width:14px;height:14px}
.pgbtn:hover{text-decoration:none;border-color:rgba(167,139,250,.5)}
.pgbtn.off{opacity:.35;pointer-events:none}
.pgnum{width:44px;font-weight:700}
a.pgnum:hover{text-decoration:none;border-color:rgba(167,139,250,.5)}
.pgnum.cur{background:linear-gradient(135deg,var(--accent),var(--accent-dk));
color:var(--accent-ink);border-color:transparent;box-shadow:0 6px 18px -8px
rgba(139,111,214,.8)}
.pgell{color:var(--faint);padding:0 2px;letter-spacing:2px}
.pagerpos{padding:0 16px;font-weight:800;color:var(--gold);border-color:
rgba(217,194,144,.35);letter-spacing:.5px}
.pagenums{display:none;gap:7px;align-items:center}
@media(min-width:560px){.pagenums{display:flex}}

/* --------------------------------------------- empty / center / mbox */
.empty{background:var(--surface);border:1px dashed var(--line);border-radius:
var(--radius);padding:48px 22px;text-align:center;color:var(--muted);
animation:rise .4s var(--ease) both}
.empty .eglyph{font-size:42px;display:block;margin-bottom:12px;animation:
floaty 3.4s ease-in-out infinite}
.empty b{color:var(--text);display:block;font-size:16px;margin-bottom:4px}
.centerwrap{flex:1;display:flex;align-items:center;justify-content:center;
padding:28px 16px}
.mbox{background:linear-gradient(180deg,var(--surface),var(--bg-soft));
border:1px solid var(--line);border-radius:22px;padding:44px 30px;
max-width:430px;width:100%;text-align:center;display:flex;flex-direction:
column;gap:12px;align-items:center;box-shadow:var(--shadow-3);animation:
rise .45s var(--ease) both}
.mbox .glyph{font-size:46px;animation:floaty 3.4s ease-in-out infinite}
.mbox h1{font-size:21px;font-weight:800;letter-spacing:-.3px}
.mbox p{font-size:14px;color:var(--muted);line-height:1.6}
.mbox .maction{margin-top:6px}

/* --------------------------------------------------- player page */
.verdict{border-radius:14px;padding:16px 18px;font-size:14.5px;display:
flex;flex-direction:column;gap:9px;line-height:1.55}
.verdict.ok{background:rgba(139,111,214,.09);border:1px solid
rgba(139,111,214,.4)}
.verdict.locked{background:rgba(217,194,144,.07);border:1px solid
rgba(217,194,144,.35)}
.verdict.deny{background:rgba(248,113,113,.08);border:1px solid
rgba(248,113,113,.4)}
.verdict .vmain{font-weight:700;font-size:15.5px;display:flex;align-items:
center;gap:8px}
.verdict .vmain svg{width:17px;height:17px;flex:none}
.verdict .vmain.thinking::after{content:"";width:7px;height:7px;border-
radius:50%;background:var(--gold);margin-left:3px;animation:thinking
1.1s ease-in-out infinite}
.minitext{font-size:12.5px;color:var(--muted)}
.playerwrap{margin-top:14px;display:flex;flex-direction:column;gap:10px}
.playerbox{position:relative;border-radius:var(--radius);overflow:hidden;
background:#020305;border:1px solid var(--line);box-shadow:var(--shadow-3)}
/* BOT-16: the gate-only state (no media mounted yet) needs a real
   media-shaped box height — without it the box collapses to ~2px and the
   absolutely-positioned Join gate renders outside the click-able area. */
.playerbox.gated{aspect-ratio:16/9;min-height:280px}
/* B17 UX FIX (VLM-audit finding): on phones the gate CONTENT (title +
   requirement + channel rows + Verify CTA) is taller than a 16:9 box —
   the absolutely-positioned gate scrolled and the primary Verify button
   sat below the fold. On <=640px the gate becomes NORMAL FLOW (the box
   sizes to its content — the CTA is always fully visible; no inner
   scrolling). */
@media(max-width:640px){
.playerbox.gated{aspect-ratio:auto;min-height:0}
.playerbox.gated .fjgate{position:relative;inset:auto;overflow:visible}
.fjgate h2{font-size:15.5px}
.fjgate{gap:9px;padding:16px 12px}
.fjgate .fjrows{gap:8px}
.fjrow{padding:8px 10px}
}
.playerbox video,.playerbox img.pimg{display:block;width:100%;
max-height:62vh;max-height:62dvh;background:#000}
.playerbox audio{display:block;width:100%;padding:14px 16px;background:
#0b1220}
.playerbox .ploading{position:absolute;inset:0;display:flex;align-items:
center;justify-content:center;flex-direction:column;gap:10px;color:var(
--muted);font-size:13px;background:rgba(2,3,5,.88);z-index:2}
.playerbox .ploading .spin{width:34px;height:34px;border-radius:50%;
border:3px solid rgba(167,139,250,.2);border-top-color:var(--accent);
animation:spin 1s linear infinite}
.playerbox .pwm{position:absolute;right:12px;top:12px;z-index:12;pointer-events:
none;user-select:none;max-width:60%;overflow:hidden;text-overflow:ellipsis;
white-space:nowrap;font-size:11px;font-weight:600;letter-spacing:.04em;
text-transform:uppercase;color:rgba(233,233,245,.85);text-shadow:0 1px 2px
rgba(0,0,0,.9);background:rgba(6,6,12,.42);border:1px solid rgba(233,233,245,
.14);border-radius:8px;padding:4px 9px}
.adstage{position:absolute;inset:0;z-index:9;display:flex;flex-direction:
column;background:#060609}
.adstage .adbar{display:flex;align-items:center;justify-content:space-
between;gap:10px;padding:12px 16px}
.adstage .adlabel{font-size:var(--fs-micro);font-weight:800;letter-spacing:
var(--ls-wide);text-transform:uppercase;color:var(--gold)}
.adstage .adtimer{font-size:12px;font-weight:700;color:var(--muted)}
.adbody{flex:1;min-height:0;overflow:hidden;display:flex;align-items:
center;justify-content:center}
.adbody video{width:100%;height:100%;object-fit:contain;display:block;
max-width:100%;background:#000}
.playmeta{display:flex;flex-wrap:wrap;gap:8px;align-items:center;
justify-content:space-between;font-size:12.5px;color:var(--muted)}
.playmeta .pfile{font-weight:600;color:var(--text);max-width:100%;
overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.partsnav{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.moreparts{display:inline-flex;align-items:center;gap:7px;padding:9px 14px;
border-radius:var(--radius-pill);border:1px dashed var(--line);color:var(
--faint);font-size:12px;font-weight:600;line-height:1.35}
.moreparts svg{width:14px;height:14px;opacity:.7;flex:none}
.partsnav .plabel{font-size:var(--fs-micro);color:var(--faint);font-weight:
800;letter-spacing:var(--ls-wide);text-transform:uppercase;margin-right:2px}
.partpill{display:inline-flex;align-items:center;gap:6px;padding:9px 15px;
border-radius:var(--radius-pill);border:1px solid var(--line);background:
rgba(255,255,255,.03);color:var(--muted);font-size:12.5px;font-weight:600;
text-decoration:none;min-height:44px;transition:border-color var(--dur-1),
background var(--dur-1),color var(--dur-1)}
[data-theme="light"] .partpill{background:rgba(26,22,38,.04)}
.partpill svg{width:14px;height:14px}
.partpill:hover{border-color:var(--accent);color:var(--text);background:
rgba(167,139,250,.08);text-decoration:none}
.partpill.cur{border-color:var(--accent);color:var(--accent);background:
rgba(167,139,250,.1);pointer-events:none}
/* V25 fix (browser-caught): interactive accent pills (Resume / Retry
   Stream) — the SAME accent look as .cur but CLICKABLE. Reusing .cur
   (whose pointer-events:none is meant for the non-interactive
   current-part pill) made the Resume and Retry Stream buttons
   unclickable for real pointer input. */
.partpill.go{border-color:var(--accent);color:var(--accent);background:
rgba(167,139,250,.1);pointer-events:auto;cursor:pointer}
.partpill .pprev,.partpill .pnext{display:inline-flex}
button.partpill{cursor:pointer;font-family:inherit}
/* v35 §16/§17: the canonical Telegram fallback surfaces */
.tgbtn{display:inline-flex;align-items:center;gap:8px;padding:11px 18px;
border-radius:var(--radius-pill);border:1px solid var(--accent);background:
rgba(167,139,250,.12);color:var(--accent);font-size:13px;font-weight:700;
text-decoration:none;min-height:44px;transition:background var(--dur-1),
transform var(--dur-1)}
.tgbtn svg{width:15px;height:15px}
.tgbtn:hover{background:rgba(167,139,250,.2);text-decoration:none;
transform:translateY(-1px)}
[data-theme="light"] .tgbtn{background:rgba(46,36,71,.08)}
[data-theme="light"] .tgbtn:hover{background:rgba(46,36,71,.14)}
/* ---- B18-FINAL media engagement bar (views + like/dislike) ---- */
.engbar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:12px 0 4px;
padding:10px 14px;border:1px solid var(--line);border-radius:var(--radius);
background:var(--surface);min-height:56px}
.engviews{display:inline-flex;align-items:center;gap:7px;color:var(--muted);
font-size:13px}
.engviews svg{width:16px;height:16px;opacity:.85}
.engviews b{color:var(--text);font-size:15px;font-variant-numeric:tabular-nums}
.engviews.engviews-note{font-size:12px;opacity:.8}
.englabel{font-size:12px;color:var(--muted)}
.engspacer{flex:1}
.engbtn{display:inline-flex;align-items:center;gap:8px;padding:10px 16px;min-height:44px;
min-width:44px;border-radius:var(--radius-pill);border:1px solid var(--line);
background:var(--surface);color:var(--muted);font-size:13px;font-weight:700;
cursor:pointer;transition:background var(--dur-1),color var(--dur-1),
border-color var(--dur-1),transform var(--dur-1);-webkit-tap-highlight-color:transparent}
.engbtn svg{width:16px;height:16px}
.engbtn b{font-size:14px;font-variant-numeric:tabular-nums;color:var(--text)}
.engbtn:hover{border-color:var(--accent);color:var(--text)}
.engbtn:active{transform:scale(.97)}
.engbtn[aria-pressed="true"]{border-color:var(--accent);
background:rgba(167,139,250,.14);color:var(--accent)}
.engbtn[aria-pressed="true"] b{color:var(--accent)}
#engdislike[aria-pressed="true"]{border-color:#f87171;background:rgba(248,113,113,.12);
color:#f87171}
#engdislike[aria-pressed="true"] b{color:#f87171}
@media (max-width:360px){.engbar{gap:8px;padding:9px 11px}
.engbtn{padding:9px 12px}.englabel{display:none}}
.vactions{display:flex;align-items:center;gap:10px;flex-wrap:wrap;
margin-top:10px}
.vactions[hidden]{display:none}
/* BOT-11 §6-§18: the Get File control (button + subtitle + honest
status span — never the bot list, never an alert) */
.getfilebar{display:flex;align-items:center;gap:12px;flex-wrap:wrap;
margin-top:12px}
.getfilesub{font-size:12px;color:var(--faint)}
.getfilestatus{display:block;font-size:12.5px;color:var(--warn,
#f5b342);margin-top:8px;line-height:1.45}
.getfilestatus[hidden]{display:none}
.streamnote{font-size:12px;color:var(--faint);line-height:1.5;border-top:
1px dashed var(--line);padding-top:12px}
.resumebar{display:none;font-size:12.5px;color:var(--muted);align-items:
center;gap:10px;flex-wrap:wrap}
.resumebar.show{display:flex}
.resumebar a{color:var(--accent);font-weight:700;text-decoration:none}

/* -------------------------------------- welcome overlay §30 (no sound) */
.wintro{position:fixed;inset:0;z-index:220;display:flex;align-items:center;
justify-content:center;padding:24px;background:radial-gradient(120% 90% at
50% 38%,rgba(139,111,214,.14),rgba(6,6,9,.9) 55%,#060609);transition:
opacity .45s ease}
.wintro.fade{opacity:0;pointer-events:none}
[data-theme="light"] .wintro{background:radial-gradient(120% 90% at 50% 38%,
rgba(139,111,214,.1),rgba(247,246,250,.92) 55%,#f7f6fa)}
.wglow{position:absolute;left:50%;top:38%;width:340px;height:340px;margin:
-170px 0 0 -170px;border-radius:50%;background:radial-gradient(circle,
rgba(167,139,250,.22),transparent 65%);filter:blur(10px);animation:wpulse
2.4s ease-in-out infinite}
.wcard{position:relative;text-align:center;display:flex;flex-direction:
column;gap:14px;align-items:center;animation:wrise .5s var(--ease) both}
.wbrand{font-size:12px;font-weight:800;letter-spacing:.55em;color:var(--gold);
text-transform:uppercase;padding-left:.55em;animation:wreveal .8s var(--ease)
both}
.wbrand .wdot{display:inline-block;width:7px;height:7px;border-radius:50%;
background:var(--accent);box-shadow:0 0 12px var(--accent);margin-right:
12px;vertical-align:2px}
.wtitle{font-size:clamp(24px,7vw,34px);font-weight:800;letter-spacing:-.5px;
background:linear-gradient(120deg,#fff,rgba(255,255,255,.72) 55%,
var(--accent));-webkit-background-clip:text;background-clip:text;color:
transparent}
[data-theme="light"] .wtitle{background:linear-gradient(120deg,#1a1626,
rgba(26,22,38,.75) 55%,var(--accent));-webkit-background-clip:text;
background-clip:text}
.wline{font-size:14px;color:var(--muted)}
.wskip{min-height:44px;padding:10px 26px;border-radius:var(--radius-pill);
border:1px solid var(--line);background:rgba(255,255,255,.05);color:var(
--text);font-weight:700;font-size:14px;font-family:inherit;cursor:pointer;
margin-top:6px;transition:border-color var(--dur-1) ease}
.wskip:hover{border-color:rgba(167,139,250,.55)}
[data-theme="light"] .wskip{background:rgba(26,22,38,.05)}

/* -------------------------------- settings theme section (Dark/Light/System) */
.themerow{display:flex;flex-wrap:wrap;gap:10px;justify-content:center}
.themechoice{border:1px solid var(--line);background:rgba(255,255,255,.04);
font-family:inherit;cursor:pointer;min-height:44px;padding:10px 18px;
border-radius:var(--radius-pill);color:var(--muted);font-weight:600;
font-size:13.5px;transition:border-color var(--dur-1) ease,color var(--dur-1)
ease,box-shadow var(--dur-1) ease}
.themechoice:hover{border-color:rgba(167,139,250,.5);color:var(--text)}
.themechoice[aria-pressed="true"]{border-color:var(--accent);
color:var(--accent);box-shadow:0 0 0 3px rgba(167,139,250,.14)}
[data-theme="light"] .themechoice{background:rgba(26,22,38,.04)}

/* ------------------------- autoplay-denied fallback on the player */
.tapplay{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);
z-index:8;min-height:44px;padding:12px 22px;border-radius:
var(--radius-pill);border:1px solid rgba(217,194,144,.55);background:
rgba(10,9,16,.92);color:var(--gold);font-weight:700;font-size:14px;
font-family:inherit;cursor:pointer;box-shadow:var(--shadow-3)}
.tapplay:hover{background:rgba(217,194,144,.16)}

/* §13 YouTube-like preview: the big play button over the poster.
   B17 UX FIX (z-order): the big play sits ABOVE the control bar
   (z 8 > 7) — at 320-360px viewports the 16:9 stage is short enough
   that the centered button's hit area fell UNDER the bar (its click
   point was covered and the button never received the click). The AD
   stage stays ABOVE it (z 9) so a running pre-roll still owns the
   surface; it hides once the content actually starts. */
.pbigplay{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);
z-index:8;width:72px;height:72px;border-radius:50%;border:1px solid
rgba(217,194,144,.6);background:rgba(10,9,16,.62);color:var(--gold);
font-size:26px;line-height:1;font-family:inherit;cursor:pointer;
box-shadow:var(--shadow-3);display:flex;align-items:center;
justify-content:center;transition:background var(--dur-1) ease,
transform var(--dur-1) ease}
.pbigplay:hover{background:rgba(217,194,144,.2);transform:translate(-50%,
-50%) scale(1.06)}
.pbigplay[hidden]{display:none}

/* ------------------- BOT-16: the Join Required screens (screens.py) */
/* The gate classes previously shipped with no styling at all; these rules
   use the SAME design tokens (dark + light) so the Join Required page and
   the in-player Join gate read as first-class surfaces. */
.fjbox{max-width:520px;width:100%;background:linear-gradient(180deg,
var(--surface),var(--bg-soft));border:1px solid var(--line);border-radius:
var(--radius);box-shadow:var(--shadow-2);padding:26px 22px;display:flex;
flex-direction:column;gap:14px;text-align:center}
.fjbox .glyph{font-size:42px;line-height:1}
.fjbox h1{font-size:22px;font-weight:800;letter-spacing:-.3px}
.loginlead{font-size:14px;color:var(--muted)}
.fineprint{font-size:12px;color:var(--faint);line-height:1.5}
.loginstate{font-size:13px;min-height:18px;color:var(--muted)}
.loginstate.ok{color:var(--accent)}
.loginstate.bad{color:var(--danger)}
.fjhealth{font-size:12.5px;color:var(--gold);background:var(--gold-soft);
border:1px solid rgba(217,194,144,.35);border-radius:var(--radius-sm);
padding:9px 12px;line-height:1.45;text-align:left}
.fjlist,.fjrows{list-style:none;display:flex;flex-direction:column;gap:10px;
margin:0;padding:0}
.fjrow{display:flex;align-items:center;gap:10px;flex-wrap:wrap;
background:var(--surface-2);border:1px solid var(--line);border-radius:
var(--radius-sm);padding:10px 12px}
.fjtitle{font-weight:700;font-size:13.5px;text-align:left;flex:1;
min-width:120px;overflow-wrap:anywhere}
.fjbadge{font-size:var(--fs-micro);font-weight:800;letter-spacing:
var(--ls-wide);text-transform:uppercase;border-radius:var(--radius-pill);
padding:3px 9px;border:1px solid var(--line);color:var(--muted);flex:none}
.fjbadge.warn{color:var(--gold);border-color:rgba(217,194,144,.5);
background:var(--gold-soft)}
.fjbadge.dead{color:var(--danger);border-color:rgba(248,113,113,.4);
background:rgba(248,113,113,.08)}
.joinbtn{display:inline-flex;align-items:center;gap:7px;min-height:44px;
padding:10px 16px;border-radius:var(--radius-pill);border:1px solid
var(--accent);background:rgba(167,139,250,.12);color:var(--accent);
font-size:13px;font-weight:700;text-decoration:none;flex:none}
.joinbtn svg{width:14px;height:14px}
.joinbtn:hover{background:rgba(167,139,250,.2);text-decoration:none}
[data-theme="light"] .joinbtn{background:rgba(46,36,71,.08)}
.joinbtn.dead{border-color:var(--line);background:transparent;color:var(
--faint);cursor:not-allowed}
.fjnote{flex-basis:100%;text-align:left;font-size:11.5px;color:var(--gold);
line-height:1.45}
.verifybtn{display:inline-flex;align-items:center;justify-content:center;
gap:9px;min-height:48px;padding:12px 26px;border-radius:var(
radius-pill);border:1px solid var(--accent);background:var(--accent-dk);
color:var(--accent-ink);font-weight:800;font-size:14.5px;font-family:
inherit;cursor:pointer;transition:transform var(--dur-1) ease,box-shadow
var(--dur-1) ease,background var(--dur-1) ease;box-shadow:0 6px 18px
rgba(139,111,214,.22)}
.verifybtn:hover{transform:translateY(-1px);box-shadow:0 9px 24px
rgba(139,111,214,.3)}
.verifybtn:active{transform:translateY(0) scale(.985)}
.verifybtn:focus-visible{outline:2px solid var(--gold);outline-offset:2px}
.verifybtn:disabled{opacity:.6;cursor:wait;transform:none;box-shadow:none}
.verifybtn .agespinner{display:none;width:16px;height:16px;border-radius:50%;
border:2px solid rgba(18,11,38,.35);border-top-color:var(--accent-ink);
animation:agespin .7s linear infinite;flex:none}
.verifybtn.is-pending .agespinner{display:inline-block}
@keyframes agespin{to{transform:rotate(360deg)}}
@media (prefers-reduced-motion:reduce){
  .verifybtn .agespinner{animation-duration:1.6s}
  .verifybtn,.verifybtn:hover{transition:none;transform:none}
}
/* -------- V25 §22: the 18+ age-gate interstitial (B.2 screens) -------- */
.agebox{width:100%;max-width:420px;background:var(--surface);border:1px
solid var(--line);border-radius:var(--radius);padding:26px 22px 22px;
display:flex;flex-direction:column;gap:12px;text-align:center;
box-shadow:0 18px 48px rgba(0,0,0,.45);position:relative;overflow:hidden}
.agebox::before{content:"";position:absolute;inset:0 0 auto 0;height:3px;
background:linear-gradient(90deg,var(--gold),var(--danger),var(--gold));
opacity:.75}
[data-theme="light"] .agebox{box-shadow:0 14px 36px rgba(26,22,38,.1)}
.agebox-head{display:flex;align-items:center;justify-content:center;
gap:9px;margin-bottom:2px}
.agebox .glyph{font-size:26px;line-height:1}
.agetag{display:inline-flex;align-items:center;min-height:24px;padding:3px
10px;border-radius:var(--radius-pill);border:1px solid var(--danger);
color:var(--danger);background:rgba(248,113,113,.1);font-weight:800;
font-size:12px;letter-spacing:.06em}
[data-theme="light"] .agetag{background:rgba(204,75,75,.08)}
.agebox h1{font-size:21px;font-weight:800;letter-spacing:-.01em}
.agerow{display:flex;align-items:center;justify-content:center;gap:10px;
flex-wrap:wrap;margin-top:4px}
.agerow .backlink{min-height:48px;display:inline-flex;align-items:center}

/* -------- BOT-16: the IN-PLAYER Join Required gate (Work Item C.4) */
.fjgate{position:absolute;inset:0;z-index:6;overflow:auto;background:rgba(
6,5,10,.97);display:flex;flex-direction:column;align-items:center;
justify-content:center;gap:12px;padding:22px 16px;text-align:center}
.fjgate h2{font-size:17px;font-weight:800;color:#fff;display:flex;
align-items:center;gap:8px}
.fjgate .loginlead{color:rgba(255,255,255,.75);max-width:420px}
.fjgate .fjrows{width:100%;max-width:430px}
.fjgate .fjstate{font-size:12.5px;min-height:16px}

/* ---------------- BOT-16: the custom player control bar (C.2) ----- */
/* Touch-first (>=44px targets), dark surface in BOTH themes (the player
   surface stays cinematic black), keyboard-focusable controls with the
   site focus ring, no scrollbars on the popovers.
   B17 UX POLISH: single-row control bar at EVERY width (never a crowded
   multi-row wrap), SVG icon controls (no platform-dependent Unicode
   glyphs), interaction-aware auto-hide (fade + slide out after
   inactivity ONLY while playing; mouse/touch/keyboard/focus restore;
   pinned visible while paused/ended, while a menu is open and during
   slider drags), a mobile Settings sheet consolidating Speed/Quality/
   PiP behind one gear button, and a consistent 16:9 stage with the
   video letterboxed inside it (source dimensions never dictate the
   page layout). */
.pctl{position:absolute;left:0;right:0;bottom:0;z-index:7;display:flex;
flex-direction:column;gap:4px;padding:8px 10px 10px;background:linear-
gradient(180deg,transparent,rgba(2,3,5,.55) 34%,rgba(2,3,5,.92));color:#fff;
transition:opacity .28s var(--ease),transform .28s var(--ease)}
.pctl[hidden]{display:none}
.pctl.adshidden{display:none}
/* BOT-43 (Section 2): the cinematic TOP overlay — Back + now-playing
   title on a top gradient, sharing the bottom bar's auto-hide contract
   (fades + slides out while playing after inactivity; visible while
   paused/ended, during menus, and on every wake input; the ad stage
   hides it via .adshidden). */
.ptop{position:absolute;left:0;right:0;top:0;z-index:7;display:flex;
align-items:center;gap:6px;padding:8px 10px;background:linear-gradient(
180deg,rgba(2,3,5,.86),rgba(2,3,5,.42) 58%,transparent);color:#fff;
transition:opacity .28s var(--ease),transform .28s var(--ease)}
.ptop[hidden]{display:none}
.ptop.adshidden{display:none}
.ptop.ctl-idle,.playerbox.ctl-idle .ptop{opacity:0;transform:
translateY(-10px);pointer-events:none;transition:opacity .32s ease,
transform .32s ease}
.ptopbtn{display:inline-flex;align-items:center;justify-content:center;
min-width:44px;min-height:44px;border-radius:12px;border:1px solid
transparent;background:rgba(255,255,255,.07);color:#fff;font-family:
inherit;cursor:pointer;line-height:1;padding:0;flex:none;transition:
background var(--dur-1) ease,transform var(--dur-1) ease}
.ptopbtn svg{width:20px;height:20px;display:block;pointer-events:none;
transform:rotate(180deg)}
.ptopbtn:hover{background:rgba(255,255,255,.16)}
.ptopbtn:active{transform:scale(.9);background:rgba(255,255,255,.24)}
.ptopbtn:focus-visible{outline:2px solid var(--accent);outline-offset:-2px}
.ptoptitle{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;
white-space:nowrap;font-size:13.5px;font-weight:700;color:rgba(255,255,
255,.94);text-shadow:0 1px 2px rgba(0,0,0,.85);padding-right:10px}
.pctl.ctl-idle{opacity:0;transform:translateY(12px);pointer-events:none;
transition:opacity .32s ease,transform .32s ease}
.playerbox.ctl-idle{cursor:none}
.pctlseek{-webkit-appearance:none;appearance:none;width:100%;height:28px;
margin:0;background:transparent;cursor:pointer;min-height:28px}
.pctlseek::-webkit-slider-runnable-track{height:5px;border-radius:3px;
background:linear-gradient(90deg,var(--accent) 0 var(--pval,0%),
rgba(255,255,255,.4) var(--pval,0%) var(--pbuf,0%),rgba(255,255,255,.18)
var(--pbuf,0%) 100%)}
.pctlseek::-moz-range-track{height:5px;border-radius:3px;background:
rgba(255,255,255,.18)}
.pctlseek::-moz-range-progress{height:5px;border-radius:3px;background:
var(--accent)}
.pctlseek::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
width:14px;height:14px;border-radius:50%;background:var(--accent);border:0;
margin-top:-4.5px}
.pctlseek::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
background:var(--accent);border:0}
.pctlrow{display:flex;align-items:center;gap:4px;flex-wrap:nowrap;
min-width:0}
.pctlbtn{display:inline-flex;align-items:center;justify-content:center;
min-width:44px;min-height:44px;border-radius:12px;border:1px solid
transparent;background:rgba(255,255,255,.07);color:#fff;font-family:inherit;
font-size:13px;font-weight:700;cursor:pointer;line-height:1;padding:0 10px;
flex:none;transition:background var(--dur-1) ease,transform var(--dur-1)
ease,color var(--dur-1) ease}
.pctlbtn svg{width:20px;height:20px;display:block;pointer-events:none}
.pctlbtn:hover{background:rgba(255,255,255,.16)}
.pctlbtn:active{transform:scale(.9);background:rgba(255,255,255,.24)}
.pctlbtn:focus-visible{outline:2px solid var(--accent);outline-offset:-2px}
.pctlbtn[disabled],.pctlbtn[aria-disabled="true"]{opacity:.4;cursor:
default;pointer-events:none;transform:none}
.pctlbtn[hidden]{display:none}
.pctlbtn.ctl-on{color:var(--accent)}
.pctltime{font-size:12.5px;font-weight:600;color:rgba(255,255,255,.88);
font-variant-numeric:tabular-nums;white-space:nowrap;overflow:hidden;
text-overflow:ellipsis;min-width:0;flex:0 1 auto}
.pctlvol{-webkit-appearance:none;appearance:none;width:84px;height:28px;
background:transparent;cursor:pointer;min-height:28px;flex:none}
.pctlvol::-webkit-slider-runnable-track{height:4px;border-radius:2px;
background:linear-gradient(90deg,var(--accent) 0 var(--pvol,100%),
rgba(255,255,255,.25) var(--pvol,100%) 100%)}
.pctlvol::-moz-range-track{height:4px;border-radius:2px;background:
rgba(255,255,255,.25)}
.pctlvol::-moz-range-progress{height:4px;border-radius:2px;background:
var(--accent)}
.pctlvol::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
width:12px;height:12px;border-radius:50%;background:var(--accent);border:0;
margin-top:-4px}
.pctlvol::-moz-range-thumb{width:12px;height:12px;border-radius:50%;
background:var(--accent);border:0}
.pctlspacer{flex:1}
/* the Settings gear (phones only) carries Speed / Quality / PiP */
.pctlbtn.plset{display:none}
/* the popover is anchored to the PLAYER BOX (never the bar: % heights
   resolved against the bar clipped the old menu to ~one item), opens
   above the live bar height and is capped to the real space above it
   via JS; on phones it becomes a full-width sheet. */
.pctlmenu{position:absolute;right:10px;bottom:96px;z-index:10;background:
rgba(10,9,16,.96);backdrop-filter:blur(14px);-webkit-backdrop-filter:
blur(14px);border:1px solid var(--line);border-radius:14px;box-shadow:
var(--shadow-3);min-width:170px;max-width:min(260px,calc(100% - 20px));
max-height:240px;overflow:auto;padding:6px;display:flex;flex-direction:
column;gap:2px}
.pctlmenu[hidden]{display:none}
.pctlmgroup{font-size:10.5px;font-weight:800;letter-spacing:1.4px;
text-transform:uppercase;color:rgba(255,255,255,.45);padding:10px 12px 4px;
white-space:nowrap}
.pctlmitem{display:flex;align-items:center;justify-content:space-between;
gap:10px;min-height:44px;padding:10px 12px;border-radius:10px;border:0;
background:transparent;color:rgba(255,255,255,.88);font-family:inherit;
font-size:13.5px;font-weight:600;cursor:pointer;text-align:left;width:100%}
.pctlmitem .mlabel{flex:1;min-width:0;overflow:hidden;text-overflow:
ellipsis;white-space:nowrap}
.pctlmitem .mval{font-size:12px;color:rgba(255,255,255,.55);font-variant-
numeric:tabular-nums;flex:none}
.pctlmitem .mchev{width:14px;height:14px;color:rgba(255,255,255,.5);
flex:none;display:inline-flex}
.pctlmitem .mchev svg{width:14px;height:14px;display:block}
.pctlmitem .mcheck{width:16px;height:16px;display:inline-flex;color:var(
--accent);flex:none}
.pctlmitem .mcheck svg{width:16px;height:16px;display:block}
.pctlmitem:hover{background:rgba(255,255,255,.1)}
.pctlmitem:focus-visible{outline:2px solid var(--accent);outline-offset:
-2px}
.pctlmitem[aria-checked="true"]{background:rgba(167,139,250,.14);color:#fff}
.pctlmitem[aria-checked="true"] .mval{color:var(--accent)}
.pctlmitem[aria-disabled="true"]{opacity:.45;cursor:default}
/* V25 (§11): the submenu BACK row ("← Quality") — a real 44px target
   with a chevron; it returns to the settings ROOT (Esc/Back close the
   deepest level first). */
.pctlmback{display:flex;align-items:center;gap:8px;min-height:44px;padding:
10px 12px;border-radius:10px;border:0;background:rgba(255,255,255,.055);
color:#fff;font-family:inherit;font-size:13.5px;font-weight:700;cursor:
pointer;text-align:left;width:100%;margin-bottom:2px;position:sticky;
top:0;z-index:1}
.pctlmback:hover{background:rgba(255,255,255,.13)}
.pctlmback:focus-visible{outline:2px solid var(--accent);outline-offset:-2px}
.pctlmback .mchev{width:15px;height:15px;color:var(--accent);display:
inline-flex;transform:rotate(180deg)}
.pctlmback .mchev svg{width:15px;height:15px;display:block}
.pctlmtitle{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;
white-space:nowrap;letter-spacing:.2px}
/* phones (<=640px): ONE clean row — play / time / mute / settings /
   fullscreen; the volume slider and the inline secondary buttons
   collapse into the Settings sheet (primary controls stay immediate).
   <=350px tightens further (gap 2, 38px button width, 11px time) so the
   narrowest phones never feel crowded (VLM-audit finding). */
@media(max-width:640px){
.pctl{padding:6px 6px calc(8px + env(safe-area-inset-bottom,0px));gap:3px}
.ptop{padding:6px 6px 6px 2px;gap:4px}
.ptopbtn{min-width:40px;min-height:44px;border-radius:11px}
.ptopbtn svg{width:19px;height:19px}
.ptoptitle{font-size:12.5px}
.pctlbtn{min-width:40px;min-height:44px;padding:0 7px;border-radius:11px}
.pctlbtn svg{width:19px;height:19px}
.pctltime{font-size:11.5px;flex:1 1 auto;min-width:0}
.pctlspacer{display:none}
.pctlvol{display:none}
#pspeed,#pquality,#ppip{display:none!important}
.pctlbtn.plset{display:inline-flex}
.pctlmenu{left:8px;right:8px;min-width:0;max-width:none;bottom:88px;
padding-bottom:calc(6px + env(safe-area-inset-bottom,0px))}
.pbigplay{width:64px;height:64px}
.pbigplay svg{width:26px;height:26px}
}
@media(max-width:350px){
.pctl{padding:4px 4px 6px;gap:2px}
.pctlbtn{min-width:38px;padding:0 5px}
.pctltime{font-size:11px}
}
.pwait{position:absolute;inset:0;display:flex;align-items:center;
justify-content:center;z-index:4;background:rgba(2,3,5,.35);
pointer-events:none}
.pwait .spin{width:38px;height:38px;border-radius:50%;border:3px solid
rgba(167,139,250,.2);border-top-color:var(--accent);animation:spin 1s
linear infinite}
.pwait[hidden]{display:none}
.playerbox:fullscreen,.playerbox:-webkit-full-screen{border-radius:0;
border:0;background:#000}
.playerbox:fullscreen video,.playerbox:-webkit-full-screen video{position:
absolute;inset:0;width:100%;height:100%;max-height:none;object-fit:contain;
background:#000}
/* FINAL-1 (bot-20.log — Telegram-Android WebView): CSS PSEUDO-FULLSCREEN.
   The real Fullscreen API is unavailable/unhandled for elements in many
   in-app WebViews (the production "fullscreen button does nothing");
   .fsfake pins the player box to the viewport with position:fixed so
   the custom control bar STAYS visible and the video fills the screen
   in every environment. Esc / the fullscreen button exits it. */
.playerbox.fsfake{position:fixed!important;inset:0!important;z-index:2147483000;
width:100vw!important;width:100dvw!important;height:100vh!important;height:100dvh!important;max-height:none!important;
aspect-ratio:auto!important;border-radius:0;border:0;background:#000;
margin:0}
.playerbox.fsfake video{position:absolute;inset:0;width:100%;height:100%;
max-height:none;object-fit:contain;background:#000}
body.fsfake-scroll-lock{overflow:hidden}
/* A.1 (bot-25): the html+body scroll lock — html scroll containment so
   the pinned .fsfake player never produces a shrink/expand jump while
   the document is locked (Telegram Android WebView). */
html.fsfake-scroll-lock,
body.fsfake-scroll-lock {
  overflow: hidden !important;
  height: 100% !important;
  max-height: 100vh !important;
  max-height: 100dvh !important;
  position: relative !important;
}
/* TASK G (BOT-45/46 §10 — TRUE player-only fullscreen): while the CSS
   pseudo-fullscreen (.fsfake) OR the real Fullscreen API element is
   active, the player script mirrors the SAME fsfake-scroll-lock state
   onto <html>/<body> (__fsChromeSync on every enter/exit/fullscreen
   change). EVERY site-chrome layer that sat ABOVE the pinned player
   box — the production z-index inversion (#bnav 2147483300, #mini
   2147483400, .sheet/.sheetbak 2147483401-402, #toasts/.toast
   2147483500, #navprog 2147483600 — all above .fsfake 2147483000, so
   Home/Categories/Search/Library rendered over the fullscreen video)
   — is display:none'd under the body state class. ROOT-CAUSE fix:
   chrome removal under the scoped state class, NEVER a z-index bump.
   Only the player box + its control stack remain visible. The Mini
   App fullscreen layer is intentionally excluded (§13 keeps the
   NORMAL layout inside the larger viewport). */
body.fsfake-scroll-lock #bnav,
body.fsfake-scroll-lock #mini,
body.fsfake-scroll-lock .partpill,
body.fsfake-scroll-lock .partsnav,
body.fsfake-scroll-lock .sheet,
body.fsfake-scroll-lock .sheetbak,
body.fsfake-scroll-lock #toasts,
body.fsfake-scroll-lock .toast,
body.fsfake-scroll-lock #navprog,
body.fsfake-scroll-lock header.site,
body.fsfake-scroll-lock footer.site,
body.fsfake-scroll-lock .backlink,
body.fsfake-scroll-lock .detailhead,
body.fsfake-scroll-lock .engbar,
body.fsfake-scroll-lock .streamnote{display:none!important}
.pfsnote{position:absolute;left:50%;bottom:64px;transform:translateX(-50%);
z-index:8;background:rgba(2,3,5,.82);color:#ece5fb;font-size:12px;
line-height:1.35;padding:8px 12px;border-radius:10px;max-width:82%;
text-align:center;pointer-events:none}
/* B17: the 16:9 responsive stage — the video letterboxes INSIDE the
   stage; source dimensions never dictate the page layout. The gate-only
   box (.gated) already used this shape; the playing state now matches
   it. Fullscreen keeps its own fill rules above. */
.playerbox.stage{aspect-ratio:16/9;max-height:min(76vh,640px);max-height:min(76dvh,640px)}
.playerbox.stage video{position:absolute;inset:0;width:100%;height:100%;
max-height:none;object-fit:contain;background:#000}
/* B17: the big-play / tap-to-play / retry / ad-skip icons */
.pbigplay svg{width:30px;height:30px}
.tapplay{display:inline-flex;align-items:center;gap:8px}
.tapplay svg{width:16px;height:16px}
.partpill svg{flex:none}
.fjgate h2 svg{width:18px;height:18px;color:var(--gold);flex:none}

/* -------------------------------------------------------- footer */
footer.site{border-top:1px solid var(--line);padding:18px 16px;text-align:
center;color:var(--faint);font-size:12px;display:flex;flex-direction:column;
gap:6px;align-items:center;margin-top:auto}
footer.site .fdot{width:6px;height:6px;border-radius:50%;background:
var(--accent);opacity:.7}

/* ------------------------------------- safe-area insets §33 (gated) */
@supports(padding:calc(1px + env(safe-area-inset-top,0px))){
header.site{padding-top:calc(10px + env(safe-area-inset-top,0px));
padding-right:calc(14px + env(safe-area-inset-right,0px));padding-left:
calc(14px + env(safe-area-inset-left,0px))}
main.site{padding-right:calc(var(--pad) + env(safe-area-inset-right,0px));
padding-left:calc(var(--pad) + env(safe-area-inset-left,0px))}
footer.site{padding-bottom:calc(18px + env(safe-area-inset-bottom,0px))}
}


/* ================= PROMPT B (bot-25 UX pass) ================= */
:root{--sheetbg:rgba(11,10,17,.92);--ring:0 0 0 2px var(--accent)}
#navprog{position:fixed;top:0;left:0;height:2px;width:0;z-index:2147483600;
background:var(--accent);opacity:0;transition:opacity .2s;pointer-events:none}
#navprog.go{opacity:1}
.shelf{margin:0 0 26px}
.shelfhead{display:flex;align-items:baseline;gap:10px;margin:0 0 10px}
.shelftitle{font-size:16.5px;font-weight:800;letter-spacing:.2px;color:var(--text)}
.shelfsub{font-size:12px;color:var(--muted)}
.shelfrow{display:flex;gap:12px;overflow-x:auto;scroll-snap-type:x proximity;
padding:2px 2px 8px;-webkit-overflow-scrolling:touch;scrollbar-width:none}
.shelfrow::-webkit-scrollbar{display:none}
.shelfrow .card{flex:0 0 160px;scroll-snap-align:start}
@media(min-width:768px){.shelfrow .card{flex:0 0 220px}}
.shelfwrap{position:relative}
.shelfnav{position:absolute;top:38%;width:38px;height:52px;border-radius:12px;
border:1px solid var(--line);background:var(--sheetbg);color:var(--text);
display:none;align-items:center;justify-content:center;cursor:pointer;
z-index:5;font-size:18px}
.shelfwrap:hover .shelfnav,.shelfnav:focus-visible{display:flex}
.shelfnav.prev{left:-6px}.shelfnav.next{right:-6px}
.lockbadge{position:absolute;left:8px;top:8px;z-index:3;display:inline-flex;
align-items:center;gap:5px;background:rgba(2,3,5,.78);color:#f0e3c0;
font-size:11px;font-weight:700;padding:4px 8px;border-radius:8px}
.lockbadge svg{width:12px;height:12px}
.cardprog{position:absolute;left:0;right:0;bottom:0;height:3px;z-index:3;
background:rgba(255,255,255,.18)}
.cardprog i{display:block;height:100%;background:var(--accent);
border-radius:0 2px 2px 0}
.card.watched .thumbimg,.card.watched .thumbart{opacity:.8}
.watchedtick{position:absolute;right:8px;top:8px;z-index:3;width:20px;
height:20px;border-radius:50%;background:var(--accent);color:#120b26;
display:none;align-items:center;justify-content:center}
.watchedtick svg{width:12px;height:12px}
.card.watched .watchedtick{display:inline-flex}
@media(hover:hover){.card{transition:transform .2s,box-shadow .2s}
.card:hover,.card:focus-within{transform:translateY(-2px) scale(1.03);
box-shadow:var(--ring),0 10px 26px rgba(0,0,0,.42)}
.card:hover .cardtitle{color:var(--accent)}}
.cardmenu{position:absolute;right:6px;top:6px;z-index:6;display:none}
.card:hover .cardmenu,.card:focus-within .cardmenu{display:block}
.cardmenubtn{width:32px;height:32px;border-radius:9px;border:1px solid
var(--line);background:rgba(2,3,5,.82);color:var(--text);cursor:pointer;
font-size:15px;line-height:1;display:flex;align-items:center;justify-content:center}
.cardmenu .menu{right:0;top:36px;position:absolute}
.sk{background:linear-gradient(100deg,var(--surface) 30%,var(--line) 50%,
var(--surface) 70%);background-size:200% 100%;animation:skshim 1.15s
linear infinite;border-radius:10px}
@media(prefers-reduced-motion:reduce){.sk{animation:none;opacity:.6}}
@keyframes skshim{to{background-position:-200% 0}}
.skcard{height:196px}
body.theater main.site{max-width:1200px}
.playerbox.theater{max-width:1400px!important}
.ambwrap{position:relative}
/* BOT-26 T9 responsive fix: the ambient bleed was laid out as
   inset:-8%/width:116% — LAYOUT overflow that pushed the document
   scrollWidth ~7px past a 320px viewport (the masked-by-green-screen
   horizontal overflow the b23 suite surfaced once the body was fixed).
   The canvas now fills the wrap exactly (inset:0/100%) and the
   EXISTING blur(46px) provides the surrounding glow — blur is ink
   overflow only, so it never creates scrollable overflow. (A transform
   scale would NOT work: the transformed box of an absolutely-positioned
   element still contributes to scrollable overflow per CSS Overflow.) */
#ambient{position:absolute;inset:0;width:100%;height:100%;z-index:0;
filter:blur(46px) saturate(1.25) brightness(.6);opacity:.55;
pointer-events:none;background:var(--bg)}
.playerbox{position:relative;z-index:1}
#mini{position:fixed;z-index:2147483400;right:14px;bottom:14px;width:340px;
max-width:calc(100vw - 20px);background:var(--sheetbg);border:1px solid
var(--line);border-radius:14px;box-shadow:0 14px 40px rgba(0,0,0,.55);
display:none;padding:8px;gap:8px}
@media(max-width:768px){#mini{left:10px;right:10px;bottom:calc(66px +
env(safe-area-inset-bottom,0px));width:auto}}
#mini.on{display:block}
#mini .mv{width:100%;background:#000;border-radius:8px;max-height:210px}
#mini .mbar{display:flex;align-items:center;gap:8px;padding:6px 4px 2px}
#mini .mtitle{flex:1;font-size:12px;color:var(--muted);white-space:nowrap;
overflow:hidden;text-overflow:ellipsis}
#mini .mbtn{width:34px;height:34px;border-radius:9px;border:1px solid
var(--line);background:transparent;color:var(--text);cursor:pointer;
display:inline-flex;align-items:center;justify-content:center}
.mpill{position:absolute;left:50%;transform:translateX(-50%);bottom:
calc(100% + 8px);background:var(--sheetbg);border:1px solid var(--line);
color:var(--text);font-size:12px;padding:6px 12px;border-radius:999px;
z-index:2147483401;white-space:nowrap}
.ripple{position:absolute;z-index:4;width:110px;height:110px;margin:-55px
0 0 -55px;border-radius:50%;background:rgba(255,255,255,.16);display:flex;
align-items:center;justify-content:center;font-size:13px;font-weight:700;
color:#fff;pointer-events:none;animation:rip .5s ease-out forwards}
@keyframes rip{from{opacity:.9;transform:scale(.6)}to{opacity:0;
transform:scale(1.25)}}
@media(prefers-reduced-motion:reduce){.ripple{animation:none;opacity:.6}}
.spd{position:absolute;right:14px;top:12px;z-index:6;background:var(--accent);
color:#120b26;font-size:12px;font-weight:800;padding:5px 10px;
border-radius:8px;display:none}
.endscr{position:absolute;inset:0;z-index:6;display:none;gap:12px;
align-items:center;justify-content:center;background:rgba(5,4,9,.72);
backdrop-filter:blur(4px);padding:16px;flex-wrap:wrap}
.endscr.on{display:flex}
.endcard{width:180px;background:var(--surface);border:1px solid var(--line);
border-radius:12px;overflow:hidden;cursor:pointer;transition:transform .2s}
.endscr.on .endcard{animation:endin .3s ease-out}
@keyframes endin{from{opacity:0;transform:scale(.94)}to{opacity:1;
transform:scale(1)}}
@media(prefers-reduced-motion:reduce){.endscr.on .endcard{animation:none}}
.endcard img,.endcard .eart{width:100%;height:96px;object-fit:cover;
background:var(--line)}
.endcard .et{font-size:12.5px;font-weight:700;padding:8px 10px;color:var(--text)}
/* TASK G (BOT-45/46 §11): the END-OF-PLAYBACK screen — a centered
   "Playback complete" title + the [ Replay ] / [ Next Part ] controls
   (44px touch targets, §33). Shown ONLY by the video 'ended' event
   (never during startup/playing/paused/seeking/buffering — the old
   last-20-seconds overlay was removed). */
.endtitle{flex:0 0 100%;text-align:center;font-size:15.5px;font-weight:800;
letter-spacing:.3px;color:var(--text)}
.endbtns{display:flex;gap:10px;align-items:center;justify-content:center;
flex-wrap:wrap;flex:0 0 100%}
.endbtn{display:inline-flex;align-items:center;justify-content:center;gap:8px;
min-height:44px;min-width:44px;padding:11px 20px;border-radius:12px;
border:1px solid var(--line);background:var(--surface);color:var(--text);
font-size:13.5px;font-weight:700;cursor:pointer;font-family:inherit}
.endbtn:hover,.endbtn:focus-visible{border-color:var(--accent)}
.endbtn svg{width:16px;height:16px;flex:none}
.endbtn.go{border-color:var(--accent);color:var(--accent);
background:rgba(139,92,246,.10)}
[data-theme="light"] .endbtn.go{background:rgba(139,92,246,.08)}
.chapterbar{display:flex;gap:2px;margin:0 0 6px;flex-wrap:wrap}
.chap{font-size:11px;color:var(--accent);border:1px solid var(--line);
background:transparent;border-radius:7px;padding:3px 8px;cursor:pointer}
.mediagrid{display:block}
@media(min-width:1024px){.mediagrid{display:grid;grid-template-columns:
minmax(0,1fr) 340px;gap:24px;align-items:start}
.msidebar{position:sticky;top:14px;max-height:calc(100vh - 28px);
overflow-y:auto;padding-right:4px}
.msidebar .shelfrow{flex-direction:column;overflow:visible}
.msidebar .card{flex:0 0 auto;width:100%}}
.sidesec{margin:0 0 18px}
.sidesec .shelftitle{font-size:13.5px}
#toasts{position:fixed;left:50%;transform:translateX(-50%);bottom:
calc(18px + env(safe-area-inset-bottom,0px));z-index:2147483500;display:flex;
flex-direction:column;gap:8px;align-items:center;pointer-events:none}
.toast{pointer-events:auto;background:var(--sheetbg);border:1px solid
var(--line);color:var(--text);font-size:13px;padding:10px 16px;
border-radius:12px;box-shadow:0 8px 26px rgba(0,0,0,.4);display:flex;
gap:9px;align-items:center;animation:tin .2s ease-out}
@keyframes tin{from{opacity:0;transform:translateY(8px)}to{opacity:1;
transform:none}}
@media(prefers-reduced-motion:reduce){.toast{animation:none}}
#bnav{position:fixed;left:0;right:0;bottom:0;z-index:2147483300;display:none;
background:var(--sheetbg);border-top:1px solid var(--line);
padding:4px 6px calc(4px + env(safe-area-inset-bottom,0px));
justify-content:space-around}
#bnav.on{display:flex}
#bnav a,#bnav button{flex:1;min-height:48px;min-width:48px;display:flex;
flex-direction:column;align-items:center;justify-content:center;gap:3px;
color:var(--muted);font-size:10.5px;text-decoration:none;background:none;
border:0;cursor:pointer;font-family:inherit}
#bnav a.on{color:var(--accent)}
#bnav svg{width:20px;height:20px}
@media(max-width:640px){#bnav.on{display:flex}
footer.site{padding-bottom:calc(64px + env(safe-area-inset-bottom,0px))}
/* V25 S19 (browser-verified defect): the FIXED #bnav band must never
   cover end-of-page interactive content (the player Resume / Start-over
   prompt, Get File, the last card row). The sticky-footer layout clears
   through main: the extra bottom padding reserves the fixed-nav band +
   safe area at the CONTENT level (root cause — no z-index hacks). */
main.site{padding-bottom:calc(40px + 76px + env(safe-area-inset-bottom,0px))}
/* scroll-into-view of player/prompts clears the fixed nav band too */
.pbox{scroll-margin-bottom:calc(76px + env(safe-area-inset-bottom,0px))}}
.sheet{position:fixed;left:0;right:0;bottom:0;z-index:2147483402;
background:var(--surface);border-radius:18px 18px 0 0;transform:translateY(102%);
transition:transform .26s ease-out;max-height:calc(76dvh - env(safe-area-inset-top,0px));
max-height:76vh;overflow-y:auto;
padding:6px 16px calc(18px + env(safe-area-inset-bottom,0px));display:none}
@media(max-width:640px){.sheet{display:block}}
.sheet.on{transform:translateY(0)}
.sheet .grab{width:44px;height:5px;border-radius:3px;background:var(--line);
margin:6px auto 12px}
.sheetbak{position:fixed;inset:0;z-index:2147483401;background:rgba(0,0,0,.45);
backdrop-filter:blur(2px);display:none}
.sheetbak.on{display:block}
/* V25 (§26-§28): the redesigned Categories bottom sheet — grouped rows,
   48px+ separate semantic targets, active state, bounded dynamic height
   with INTERNAL scrolling; the underlying page is never scrollable or
   clickable while open (the scrim + sheetbak cover it). */
.cshead{display:flex;align-items:center;justify-content:space-between;
gap:10px;padding:2px 2px 10px;border-bottom:1px solid var(--line);
margin-bottom:6px}
.cshead .cstitle{font-size:16.5px;font-weight:800;letter-spacing:-.2px;
margin:0}
.csclose{width:44px;height:44px;margin:-6px -8px -6px 0;border-radius:12px;
border:0;background:transparent;color:var(--muted);display:inline-flex;
align-items:center;justify-content:center;cursor:pointer}
.csclose:hover{background:var(--surface-2);color:var(--text)}
.csclose:focus-visible{outline:2px solid var(--accent);outline-offset:-2px}
.csclose svg{width:19px;height:19px}
.csgroup{font-size:10.5px;font-weight:800;letter-spacing:1.4px;
text-transform:uppercase;color:var(--faint);padding:12px 4px 6px}
.csitem{display:flex;align-items:center;gap:12px;min-height:48px;
padding:8px 10px;border-radius:12px;color:var(--text);text-decoration:none;
font-size:15px;font-weight:600;position:relative;border:1px solid transparent}
.csitem:hover{background:var(--surface-2);text-decoration:none}
.csitem:focus-visible{outline:2px solid var(--accent);outline-offset:-2px}
.csitem:active{transform:scale(.985);background:rgba(167,139,250,.12)}
.csitem.cur{background:rgba(167,139,250,.12);color:var(--accent);
border-color:rgba(167,139,250,.32)}
[data-theme="light"] .csitem.cur{background:rgba(167,139,250,.14)}
.csitem .csi{flex:none;width:24px;height:24px;display:inline-flex;
align-items:center;justify-content:center;font-size:17px;line-height:1}
.csitem .csi.svg svg{width:19px;height:19px;color:var(--muted)}
.csitem.cur .csi.svg svg{color:var(--accent)}
.csitem .cslabel{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;
white-space:nowrap}
.csitem .csdot{flex:none;width:7px;height:7px;border-radius:50%;
background:var(--accent)}
.r18pill{flex:none;font-size:10px;font-weight:800;letter-spacing:.6px;
color:#ffb4b4;background:rgba(239,68,68,.16);border:1px solid
rgba(239,68,68,.35);border-radius:6px;padding:2px 6px}
[data-theme="light"] .r18pill{color:#b91c1c}
.csbody{max-height:calc(58dvh - env(safe-area-inset-bottom,0px));
max-height:58vh;overflow-y:auto;-webkit-overflow-scrolling:touch;
overscroll-behavior:contain;margin:0 -6px;padding:0 6px}
.qrow{display:flex;gap:8px;align-items:center;padding:8px;border:1px solid
var(--line);border-radius:10px;margin:0 0 8px;background:var(--surface)}
.qrow img,.qrow .qart{width:74px;height:46px;object-fit:cover;border-radius:7px;
background:var(--line);flex:none}
.qrow .qt{flex:1;min-width:0;font-size:12.5px;color:var(--text)}
.qrow .qt small{display:block;color:var(--muted);font-size:11px}
.qrow /* V25 S13: the destructive Clear-queue Confirm affordance */
.qbtnDanger{border-color:rgba(239,68,68,.55);color:#f87171}
.qbtnDanger:hover{border-color:rgba(239,68,68,.8);background:rgba(239,68,68,.12)}
.qbtnDanger:disabled{opacity:.45;cursor:not-allowed}
.qbtn{width:32px;height:32px;border-radius:8px;border:1px solid
var(--line);background:transparent;color:var(--text);cursor:pointer;
display:inline-flex;align-items:center;justify-content:center;font-size:13px}
.qempty{color:var(--muted);font-size:13px;padding:18px 4px}

@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none
!important;transition:none!important}html{scroll-behavior:auto}}
"""

# ------------------- PROMPT B site UX layer (bot-25) -------------------
# Vanilla JS only. NO authorization logic lives here — every click still
# routes through the server pipeline (the B.3 router layer owns the
# fetch/swap; this layer only ADDS affordances).
_UX_JS = """(function(){
"use strict";
var D = document;
function $(s, r){ return (r || D).querySelector(s); }
function $all(s, r){ return Array.prototype.slice.call(
  (r || D).querySelectorAll(s)); }
function uid(){ try{ return D.body.dataset.uid || "guest"; }catch(e){
  return "guest"; } }
function qkey(){ return "queue:" + uid(); }
function reduced(){ try{ return !!(window.matchMedia &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  }catch(e){ return false; } }
function saveData(){ try{ return !!(navigator.connection &&
  navigator.connection.saveData); }catch(e){ return false; } }
function slowNet(){ try{ var e = navigator.connection &&
  navigator.connection.effectiveType || ""; return e === "2g" || e === "3g";
  }catch(e){ return false; } }

/* ---------------- B.7.1 toasts (stack max 3, 3s, Escape) -------------- */
var toastHost = null;
function toast(msg){
  try{
    if(!toastHost){ toastHost = D.createElement("div");
      toastHost.id = "toasts"; D.body.appendChild(toastHost); }
    while(toastHost.children.length >= 3){ toastHost.removeChild(
      toastHost.firstChild); }
    var t = D.createElement("div");
    t.className = "toast"; t.setAttribute("role", "status");
    t.textContent = msg;
    toastHost.appendChild(t);
    var kill = function(){ if(t.parentNode){ t.parentNode.removeChild(t); } };
    setTimeout(kill, 3000);
    t.addEventListener("click", kill);
  }catch(e){}
}
D.addEventListener("keydown", function(ev){
  if(ev && (ev.key === "Escape") && toastHost && toastHost.firstChild){
    toastHost.removeChild(toastHost.firstChild);
  }
});
window.__uxToast = toast;

/* ------------- B.5.3 prefetch + B.3.4 progress via fetch wrapper ------- */
var PFCACHE = {};   // url -> {t, promise}
var PF_TTL = 30000;
function pfGet(u){
  var e = PFCACHE[u];
  if(e && Date.now() - e.t < PF_TTL){ return e.promise; }
  var p = fetch(u, {credentials: "same-origin",
                     headers: {"X-UX-Prefetch": "1"}}).then(function(r){
    return r.ok ? r.text() : Promise.reject(r.status);
  });
  PFCACHE[u] = {t: Date.now(), promise: p};
  return p;
}
var prog = null, progTimer = null, progMO = null;
function progStart(){
  try{
    if(!prog){ prog = D.createElement("div"); prog.id = "navprog";
      D.body.appendChild(prog); }
    if(reduced()){ return; }
    prog.style.width = "0"; prog.classList.add("go");
    prog.style.width = "72%";
    if(progMO){ progMO.disconnect(); }
    progMO = new MutationObserver(function(){ progDone(); });
    progMO.observe($("#main") || D.body, {childList: true, subtree: true});
    clearTimeout(progTimer);
    progTimer = setTimeout(progDone, 8000);
  }catch(e){}
}
function progDone(){
  try{
    if(!prog){ return; }
    prog.style.width = "100%";
    clearTimeout(progTimer);
    if(progMO){ progMO.disconnect(); progMO = null; }
    setTimeout(function(){ prog.classList.remove("go");
      prog.style.width = "0"; }, 220);
  }catch(e){}
}
/* hover prefetch: 100ms intent, cancel on leave, skip saveData/2G/3G */
D.addEventListener("pointerover", function(ev){
  try{
    if(saveData() || slowNet()){ return; }
    var a = ev.target && ev.target.closest ? ev.target.closest("a[href]")
      : null;
    if(!a || a.dataset.noRouter !== undefined){ return; }
    var href = a.getAttribute("href") || "";
    if(!href || href.charAt(0) === "#" || /^([a-z]+:)?\\/\\//i.test(href)
       || a.hasAttribute("download")){ return; }
    var u = new URL(href, location.href);
    if(u.origin !== location.origin){ return; }
    clearTimeout(a.__pfT);
    a.__pfT = setTimeout(function(){ pfGet(u.pathname + u.search); }, 100);
  }catch(e){}
}, true);
D.addEventListener("pointerout", function(ev){
  try{
    var a = ev.target && ev.target.closest ? ev.target.closest("a[href]")
      : null;
    if(a){ clearTimeout(a.__pfT); }
  }catch(e){}
}, true);
/* drive the progress bar from the nav layer's own fetches */
(function(){
  var of = window.fetch;
  window.fetch = function(u, o){
    try{
      var us = String(typeof u === "string" ? u : (u && u.url) || "");
      if(us && us.indexOf(location.origin) === 0){ progStart(); }
    }catch(e){}
    return of.apply(this, arguments);
  };
  D.addEventListener("click", function(ev){
    var a = ev.target && ev.target.closest ? ev.target.closest("a[href]")
      : null;
    if(a){ progStart(); }
  }, true);
  setTimeout(progDone, 2500);
})();

/* ---------------- B.2.6 session queue ---------------------------------- */
var QMAX = 50;
function qRead(){
  try{ return JSON.parse(sessionStorage.getItem(qkey()) || "[]"); }
  catch(e){ return []; }
}
function qWrite(list){
  try{ sessionStorage.setItem(qkey(), JSON.stringify(list)); }
  catch(e){}
}
function qAdd(e){
  var list = qRead();
  list = list.filter(function(x){ return x.file_pk !== e.file_pk; });
  list.unshift(e);
  while(list.length > QMAX){ list.pop(); }
  qWrite(list);
  if(list.length >= QMAX && e.__wasFull !== false){
    toast("Queue is full (50)");
  } else {
    toast("Added to queue");
  }
  renderQueue();
}
function qRemove(filePk){
  qWrite(qRead().filter(function(x){ return x.file_pk !== filePk; }));
  toast("Removed");
  renderQueue();
}
function qMove(filePk, dir){
  var list = qRead();
  var i = list.findIndex(function(x){ return x.file_pk === filePk; });
  var j = i + dir;
  if(i < 0 || j < 0 || j >= list.length){ return; }
  var tmp = list[i]; list[i] = list[j]; list[j] = tmp;
  qWrite(list); renderQueue();
}
function qClear(){ qWrite([]); renderQueue(); }
function cardOf(el){
  var a = $(".cardlink", el) || el.closest("a[href]");
  return {
    file_pk: parseInt(el.dataset.filePk || "0", 10) || 0,
    payload_id: el.dataset.payloadId || null,
    canonical_url: a ? a.getAttribute("href") : (el.dataset.href || ""),
    title: (el.dataset.title || ($(".cardtitle", el) || {}).textContent
            || "").trim(),
    poster: (el.dataset.poster || (($(".thumbimg", el) || {}).src) || ""),
    added_at: Math.floor(Date.now() / 1000)
  };
}
window.__uxQueue = {add: qAdd, remove: qRemove, clear: qClear,
                   read: qRead, toast: toast};

/* ---------------- B.7.4 card actions + B.6.4 long-press ---------------- */
function menuFor(card){
  var m = $(".menu", card);
  if(m){ return m; }
  var host = $(".cardmenu", card) || card;
  m = D.createElement("div");
  m.className = "menu pctlmenu";
  m.hidden = true;
  var e = cardOf(card);
  m.innerHTML =
    '<button type="button" data-act="open">Open</button>' +
    '<button type="button" data-act="copy">Copy link</button>' +
    '<button type="button" data-act="queue">Add to queue</button>';
  host.appendChild(m);
  m.addEventListener("click", function(ev){
    var b = ev.target.closest("button");
    if(!b){ return; }
    ev.preventDefault(); ev.stopPropagation();
    var act = b.dataset.act;
    if(act === "open"){
      var a = $(".cardlink", card);
      if(a){ a.click(); }
    } else if(act === "copy"){
      var url = new URL(e.canonical_url, location.origin).toString();
      (navigator.clipboard && navigator.clipboard.writeText(url)
       ? navigator.clipboard.writeText(url)
       : Promise.reject()).then(function(){ toast("Link copied"); },
                                function(){ toast("Link copied"); });
    } else if(act === "queue"){
      qAdd(cardOf(card));
    }
    m.hidden = true;
  });
  m.addEventListener("keydown", function(ev){
    if(ev.key === "Escape"){ m.hidden = true;
      var b = $(".cardmenubtn", card); if(b){ b.focus(); } }
  });
  /* V25 S12/S14: ONE shared outside-tap closer for EVERY card menu (the
     old per-menu anonymous document listener accumulated one listener
     per card — a slow leak across SPA-lite swaps). Registered once. */
  if(!D.__cardMenuCloserArmed){
    D.__cardMenuCloserArmed = true;
    D.addEventListener("click", function(ev){
      $all(".menu").forEach(function(mm){
        if(!mm.hidden && !mm.contains(ev.target) &&
           !(ev.target.closest && ev.target.closest(".cardmenubtn"))){
          mm.hidden = true;
        }
      });
    });
  }
  return m;
}
function armCard(card){
  if(card.dataset.uxArmed){ return; }
  card.dataset.uxArmed = "1";
  var men = D.createElement("div");
  men.className = "cardmenu";
  men.innerHTML = '<button class="cardmenubtn" type="button" ' +
    'aria-label="Card actions" aria-haspopup="menu">&#8943;</button>';
  card.appendChild(men);
  men.querySelector("button").addEventListener("click", function(ev){
    ev.preventDefault(); ev.stopPropagation();
    /* V25 S12: on <=640px the card actions UI is the bottom SHEET (the
       pointerdown handler below opens it). Toggling the desktop popover
       here TOO left a ghost "open" (invisible, zero-size) menu behind
       the sheet — the exact "tap the three-dot and it stays open"
       complaint. The popover path is desktop-only now. */
    try{
      if(window.matchMedia("(max-width: 640px)").matches){ return; }
    }catch(e2){}
    var m = menuFor(card);
    m.hidden = !m.hidden;
    var first = m.querySelector("button"); if(first){ first.focus(); }
  });
  /* B.6.4 long-press (cards only; never the browser context menu) */
  var lpT = null, lpFired = false;
  card.addEventListener("pointerdown", function(ev){
    if(ev.pointerType === "mouse" || ev.button !== 0){ return; }
    lpFired = false;
    lpT = setTimeout(function(){
      lpFired = true;
      var m = menuFor(card);
      $all("button", m).forEach(function(b){ b.setAttribute("tabindex",
        "-1"); });
      m.hidden = false;
      setTimeout(function(){ $all("button", m).forEach(function(b){
        b.removeAttribute("tabindex"); }); }, 60000);
    }, 500);
  });
  ["pointerup", "pointercancel", "pointerleave"].forEach(function(n){
    card.addEventListener(n, function(){ clearTimeout(lpT);
      if(n === "pointercancel"){ lpFired = false; } });
  });
  card.addEventListener("click", function(ev){
    if(lpFired){ ev.preventDefault(); ev.stopPropagation(); lpFired = false; }
  }, true);
}
/* B.6.2: on <=640px the card menu becomes a bottom sheet */
var __sheetCloserArmed = false;
function openSheet(html){
  closeSheet();
  var bak = D.createElement("div"); bak.className = "sheetbak"; bak.id = "sbak";
  var sh = D.createElement("div"); sh.className = "sheet on"; sh.id = "sheet";
  sh.innerHTML = '<div class="grab" aria-hidden="true"></div>' + html;
  D.body.appendChild(bak); D.body.appendChild(sh);
  requestAnimationFrame(function(){ sh.classList.add("on"); });
  bak.addEventListener("click", closeSheet);
  D.addEventListener("keydown", escSheet);
  /* V25 S14: the hardware/Telegram Back button closes the OPEN sheet
     before any navigation (the modalClosers LIFO — one persistent closer,
     armed once; a stale closer returns false and is drained harmlessly). */
  if(!__sheetCloserArmed && window.__SITE_NAV__ &&
     window.__SITE_NAV__.registerModalCloser){
    __sheetCloserArmed = true;
    window.__SITE_NAV__.registerModalCloser(function(){
      if(D.getElementById("sheet")){ closeSheet(); return true; }
      return false;
    });
  }
  /* swipe-down dismiss */
  var y0 = null;
  sh.addEventListener("pointerdown", function(ev){ y0 = ev.clientY; });
  sh.addEventListener("pointerup", function(ev){
    if(y0 !== null && ev.clientY - y0 > 70){ closeSheet(); }
    y0 = null;
  });
  return sh;
}
function escSheet(ev){ if(ev.key === "Escape"){ closeSheet(); } }
function closeSheet(){
  var sh = $("#sheet"), bak = $("#sbak");
  if(sh){ sh.remove(); } if(bak){ bak.remove(); }
  D.removeEventListener("keydown", escSheet);
}
function sheetMenuFor(card){
  var e = cardOf(card);
  var sh = openSheet(
    '<h3 class="shelftitle" style="margin:4px 6px 12px">' +
    String(e.title).replace(/</g, "&lt;") + "</h3>" +
    '<button class="qbtn" style="width:100%;margin-bottom:8px" data-act="open">' +
    "Open</button>" +
    '<button class="qbtn" style="width:100%;margin-bottom:8px" data-act="copy">' +
    "Copy link</button>" +
    '<button class="qbtn" style="width:100%" data-act="queue">' +
    "Add to queue</button>");
  sh.addEventListener("click", function(ev){
    var b = ev.target.closest("button[data-act]");
    if(!b){ return; }
    var act = b.dataset.act;
    if(act === "open"){ var a = $(".cardlink", card); if(a){ a.click(); } }
    else if(act === "copy"){ var u = new URL(e.canonical_url,
      location.origin).toString();
      try{ navigator.clipboard.writeText(u); }catch(e2){}
      toast("Link copied"); }
    else if(act === "queue"){ qAdd(cardOf(card)); }
    closeSheet();
  });
}

/* ---------------- B.2.4 shelves: chevrons + keyboard ------------------- */
function armShelves(root){
  $all(".shelfwrap", root).forEach(function(w){
    var row = $(".shelfrow", w);
    if(!row || w.dataset.uxArmed){ return; }
    w.dataset.uxArmed = "1";
    ["prev", "next"].forEach(function(dir){
      var b = D.createElement("button");
      b.type = "button";
      b.className = "shelfnav " + dir;
      b.setAttribute("aria-label", dir === "prev" ? "Scroll left"
        : "Scroll right");
      b.innerHTML = dir === "prev" ? "&#8249;" : "&#8250;";
      b.addEventListener("click", function(){
        row.scrollBy({left: (dir === "prev" ? -1 : 1)
          * Math.max(200, row.clientWidth * 0.8),
          behavior: reduced() ? "auto" : "smooth"});
      });
      w.appendChild(b);
    });
    row.setAttribute("tabindex", "0");
    row.setAttribute("role", "group");
    row.setAttribute("aria-label", "Horizontal shelf — use arrow keys");
    row.addEventListener("keydown", function(ev){
      if(ev.key === "ArrowRight"){ row.scrollBy({left: 240,
        behavior: reduced() ? "auto" : "smooth"}); ev.preventDefault(); }
      if(ev.key === "ArrowLeft"){ row.scrollBy({left: -240,
        behavior: reduced() ? "auto" : "smooth"}); ev.preventDefault(); }
    });
  });
}

/* ---------- B.2.5/B.7.2 continue-watching + resume bars + watched ------ */
function resumeFor(listing){
  var out = null;
  try{
    for(var i = 0; i < localStorage.length; i++){
      var k = localStorage.key(i);
      if(k && k.indexOf("plresume:") === 0){
        var parts = k.split(":");
        if(parts[2] === listing){
          var st = JSON.parse(localStorage.getItem(k) || "null");
          if(st && st.t > 10 && (!out || st.t > out.t)){ out = st; }
        }
      }
    }
  }catch(e){}
  return out;
}
function watchedFor(listing){
  try{
    return localStorage.getItem("plwatched:*:" + listing) === "1"
      || localStorage.getItem("plwatched:" + uid() + ":" + listing) === "1";
  }catch(e){ return false; }
}
function hydrateCards(root){
  $all(".card[data-listing]", root).forEach(function(card){
    var listing = card.dataset.listing;
    var r = resumeFor(listing);
    var pct = (r && r.d) ? Math.min(100, Math.round(r.t / r.d * 100)) : null;
    var watched = watchedFor(listing)
      || (pct !== null && pct > 95);
    if(watched){
      card.classList.add("watched");
      var tick = D.createElement("span");
      tick.className = "watchedtick";
      tick.innerHTML = '<svg viewBox="0 0 24 24" fill="none" ' +
        'stroke="currentColor" stroke-width="3"><path d="M4 12l6 6L20 6"' +
        "/></svg>";
      $(".thumb", card).appendChild(tick);
      return;
    }
    if(pct !== null && pct >= 5 && pct <= 95 && !$(".cardprog", card)){
      var bar = D.createElement("div");
      bar.className = "cardprog";
      bar.innerHTML = "<i style=\\"width:" + pct + "%\\"></i>";
      bar.setAttribute("aria-hidden", "true");
      $(".thumb", card).appendChild(bar);
    }
  });
  /* the Continue Watching shelf: keep ONLY cards with a live resume */
  var cw = $("#cwshelf", root);
  if(cw){
    var kept = 0;
    $all(".card[data-listing]", cw).forEach(function(card){
      var r = resumeFor(card.dataset.listing);
      var ok = false;
      if(r && r.d){ ok = r.t > 10 && (r.t / r.d) < 0.95; }
      else if(r){ ok = r.t > 10; }
      if(!ok){ card.remove(); } else { kept++; }
    });
    if(!kept){ var s = cw.closest(".shelf"); if(s){ s.remove(); } }
    else{ cw.closest(".shelf").style.display = ""; }
  }
}

/* ---------------- queue panel (Library sheet) -------------------------- */
/* V25 S13: the Library sheet (queue view + Clear queue) and the Clear-
   queue CONFIRMATION dialog. Full lifecycle contract:
     * Library sheet: second bottom-nav tap CLOSES it (toggle — same
       control, no stuck-open state); backdrop tap / Esc / swipe-down /
       hardware Back (modalClosers) all close it.
     * Clear queue opens the CONFIRMATION exactly once; Cancel closes it
       (and returns to the Library sheet); Confirm clears and closes with
       a success toast — a failure keeps the dialog open with the honest
       error line (never a stale modal, never a silent half-state). */
function openLibrarySheet(){
  var ex = D.getElementById("sheet");
  if(ex && ex.getAttribute("data-sheet-kind") === "library"){
    closeSheet();              // second tap on Library CLOSES the sheet
    return;
  }
  openSheet('<h3 class="shelftitle" style="margin:4px 6px 12px">Queue' +
    '</h3><div id="qlist"></div>' +
    '<button class="qbtn" style="width:100%;margin-top:8px" id="qclear">' +
    "Clear queue</button>");
  var sh = D.getElementById("sheet");
  if(sh){ sh.setAttribute("data-sheet-kind", "library"); }
  renderQueue();
  var qc = $("#qclear");
  if(qc){ qc.addEventListener("click", confirmClearQueue); }
}
function confirmClearQueue(){
  var n = qRead().length;
  openSheet(
    '<h3 class="shelftitle" style="margin:4px 6px 12px">Clear queue?</h3>' +
    '<div class="qempty" id="qctxt" role="status" aria-live="polite">' +
    (n > 0
      ? "Remove all " + n + " item" + (n === 1 ? "" : "s") +
        " from your queue?"
      : "Your queue is already empty.") +
    "</div>" +
    '<button class="qbtn" style="width:100%;margin:8px 0" id="qcancel">' +
    "Cancel</button>" +
    '<button class="qbtn qbtnDanger" style="width:100%" id="qconfirm"' +
    (n > 0 ? "" : " disabled") + ">Clear queue</button>");
  var sh = D.getElementById("sheet");
  if(sh){ sh.setAttribute("data-sheet-kind", "qclear-confirm"); }
  var c = D.getElementById("qcancel");
  if(c){
    c.addEventListener("click", function(){
      closeSheet();
      openLibrarySheet();      // Cancel returns to the queue view
    });
  }
  var f = D.getElementById("qconfirm");
  if(f){
    f.addEventListener("click", function(){
      if(f.disabled){ return; }
      var err = D.getElementById("qctxt");
      try{
        qWrite([]);
        if(qRead().length === 0){
          closeSheet();        // success: the dialog closes, no stale state
          toast("Queue cleared");
          return;
        }
        if(err){ err.textContent =
          "Couldn't clear the queue right now. Try again."; }
      }catch(e2){
        if(err){ err.textContent =
          "Couldn't clear the queue right now. Try again."; }
      }
    });
  }
}
function renderQueue(){
  var host = $("#qlist");
  if(!host){ return; }
  var list = qRead();
  if(!list.length){
    host.innerHTML = '<div class="qempty">Your queue is empty. Add ' +
      "videos to keep watching.</div>";
    return;
  }
  host.innerHTML = "";
  list.forEach(function(e){
    var row = D.createElement("div");
    row.className = "qrow";
    row.innerHTML =
      '<img class="qart" alt="" src="' + String(e.poster || "").replace(
        /"/g, "&quot;") + '">' +
      '<div class="qt">' + String(e.title || "Untitled").replace(/</g, "&lt;")
      + "<small>queued</small></div>" +
      '<button class="qbtn" data-q="up" aria-label="Move up">&#9650;</button>' +
      '<button class="qbtn" data-q="down" aria-label="Move down">' +
      "&#9660;</button>" +
      '<button class="qbtn" data-q="rm" aria-label="Remove">&times;</button>';
    row.addEventListener("click", function(ev){
      var b = ev.target.closest("button[data-q]");
      if(!b){ return; }
      if(b.dataset.q === "rm"){ qRemove(e.file_pk); }
      else if(b.dataset.q === "up"){ qMove(e.file_pk, -1); }
      else{ qMove(e.file_pk, 1); }
    });
    row.addEventListener("dblclick", function(){
      if(e.canonical_url){ location.href = e.canonical_url; }
    });
    host.appendChild(row);
  });
}

/* ---------------- B.6.1 bottom nav ------------------------------------- */
function armBottomNav(){
  if($("#bnav")){ return; }
  var nav = D.createElement("nav");
  nav.id = "bnav";
  nav.setAttribute("aria-label", "Primary");
  nav.innerHTML =
    '<a href="' + ($("body").dataset.siteRoot || "/site") + '" ' +
    'data-n="home"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
    'stroke-width="2"><path d="M3 11l9-8 9 8v10a1 1 0 01-1 1h-5v-7h-6v7H4a1 ' +
    '1 0 01-1-1z"/></svg>Home</a>' +
    '<button type="button" data-n="cats"><svg viewBox="0 0 24 24" fill="none" ' +
    'stroke="currentColor" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h16"' +
    '/></svg>Categories</button>' +
    '<button type="button" data-n="search"><svg viewBox="0 0 24 24" ' +
    'fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" ' +
    'cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>Search</button>' +
    '<button type="button" data-n="lib"><svg viewBox="0 0 24 24" fill="none" ' +
    'stroke="currentColor" stroke-width="2"><path d="M4 5h16v14H8l-4 4z"/></svg>' +
    "Library</button>";
  D.body.appendChild(nav);
  var mq = window.matchMedia("(max-width: 640px)");
  var sync = function(){ nav.classList.toggle("on", mq.matches); };
  sync();
  if(mq.addEventListener){ mq.addEventListener("change", sync); }
  /* hide when the keyboard is open (visualViewport) */
  if(window.visualViewport){
    var vv = window.visualViewport;
    var vsync = function(){
      nav.style.display = (vv.height < window.innerHeight - 120)
        ? "none" : "";
    };
    vv.addEventListener("resize", vsync);
  }
  nav.addEventListener("click", function(ev){
    var b = ev.target.closest("[data-n]");
    if(!b){ return; }
    var n = b.dataset.n;
    if(n === "search"){
      ev.preventDefault();
      var s = $("#q") || $("input[type=search]") || $("input[name=q]");
      if(s){ s.focus(); s.scrollIntoView({block: "center"}); }
      else{
        /* V26.x: query-safe concatenation — a siteRoot that carries a
           query (the demo gateway's ?XTransformPort=…) keeps its query
           AFTER the path; a plain "/site" root behaves identically to
           the old "root + '/search'" construction. */
        var root = String($("body").dataset.siteRoot || "/site");
        var cut = root.indexOf("?");
        location.href = (cut < 0 ? root : root.slice(0, cut))
                      + "/search" + (cut < 0 ? "" : root.slice(cut));
      }
    } else if(n === "cats"){
      ev.preventDefault();
      /* V25 S12/S26: the same Categories control TOGGLES — a second tap
         closes the open sheet (never a stuck-open panel). */
      var ex = D.getElementById("sheet");
      if(ex && ex.getAttribute("data-sheet-kind") === "categories"){
        closeSheet();
        return;
      }
      openCategorySheet();
    } else if(n === "lib"){
      ev.preventDefault();
      openLibrarySheet();
    }
  });
}

/* ---------------- V25 (§26-§29): the Categories panel ------------------ */
function catPanelItems(){
  // V25 (§27): every entry is read from the STRUCTURED data attributes
  // the server renders (data-cat-name / data-cat-icon / data-r18 /
  // data-group) — never from flattened textContent (the old sheet
  // concatenated "Shorts 18+ Collections My Points About Settings" into
  // one clipped run). Each item keeps its OWN semantic row.
  var chips = $all("header nav.catnav a.catchip");
  var more  = $all("header .catmore .moremenu a.mmitem");
  var here = "";
  try{ here = location.pathname.replace(/\\/$/, ""); }catch(e){}
  function active(a){
    try{
      var u = new URL(a.getAttribute("href") || "#", location.origin);
      return (u.pathname.replace(/\\/$/, "") === here);
    }catch(e){ return false; }
  }
  var content = [], library = [], app = [];
  chips.forEach(function(a){
    content.push({href: a.getAttribute("href") || "#",
      name: a.dataset.catName || (a.textContent || "").trim(),
      icon: a.dataset.catIcon || "", r18: false, cur: active(a) || a.classList.contains("cur")});
  });
  more.forEach(function(a){
    var it = {href: a.getAttribute("href") || "#",
      name: a.dataset.catName || (a.textContent || "").trim(),
      icon: a.dataset.catIcon || "", r18: a.dataset.r18 === "1", cur: active(a)};
    var g = a.dataset.group;
    if(g === "library"){ library.push(it); }
    else if(g === "app"){ app.push(it); }
    else { content.push(it); }
  });
  return {content: content, library: library, app: app};
}
function catRowHtml(it){
  // One separate semantic row: icon + readable label + 48px target,
  // active/pressed/focus states, no concatenation, no clipping.
  var ic = it.icon
    ? '<span class="csi" aria-hidden="true">' + escHtml(it.icon) + "</span>"
    : '<span class="csi svg" aria-hidden="true">' + CAT_ICONS[it.name] + "</span>";
  var r18 = it.r18 ? ' <span class="r18pill" aria-label="age restricted">18+</span>' : "";
  return '<a class="csitem' + (it.cur ? " cur" : "") + '" href="' +
    escAttr(it.href) + '"' + (it.cur ? ' aria-current="page"' : "") + ">" +
    ic + '<span class="cslabel">' + escHtml(it.name) + "</span>" + r18 +
    (it.cur ? '<span class="csdot" aria-hidden="true"></span>' : "") +
    "</a>";
}
function escHtml(s){
  return String(s == null ? "" : s).replace(/[&<>"']/g, function(c){
    return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];
  });
}
function escAttr(s){ return escHtml(s); }
var CAT_ICONS = {
  "Collections": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>',
  "My Points": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 21 12 17.77 5.82 21 7 14.14l-5-4.87 6.91-1.01z"/></svg>',
  "About": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>',
  "Settings": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09a1.65 1.65 0 001.51-1 1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33h.08a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.09a1.65 1.65 0 001 1.51h.08a1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82v.08a1.65 1.65 0 001.51 1H21a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>'
};
function openCategorySheet(){
  // V25 (§26/§28): the redesigned Categories bottom sheet — grouped
  // CONTENT / LIBRARY / APP sections with clear hierarchy, rounded top
  // corners, scrim, drag affordance + explicit Close, bounded dynamic
  // height with INTERNAL scrolling (the page behind never scrolls and is
  // never clickable), separate 48px+ rows with icons, active state, and
  // honest empty state. Opening closes the header <details> panel (ONE
  // canonical open surface at a time).
  closeCatMore();
  var d = catPanelItems();
  var groups = [];
  if(d.content.length){
    groups.push('<div class="csgroup">Content</div>' +
      d.content.map(catRowHtml).join(""));
  }
  if(d.library.length){
    groups.push('<div class="csgroup">Library</div>' +
      d.library.map(catRowHtml).join(""));
  }
  if(d.app.length){
    groups.push('<div class="csgroup">App</div>' +
      d.app.map(catRowHtml).join(""));
  }
  var body = groups.length
    ? groups.join("")
    : '<div class="qempty">No categories</div>';
  var sh = openSheet(
    '<div class="cshead"><h3 class="cstitle">Categories</h3>' +
    '<button type="button" class="csclose" id="csclose" aria-label="Close categories">' +
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>' +
    "</button></div>" +
    '<div class="csbody">' + body + "</div>");
  if(sh && sh.setAttribute){
    sh.setAttribute("data-sheet-kind", "categories");
  }
  var cb = $("#csclose", sh);
  if(cb){ cb.addEventListener("click", closeSheet); }
  /* V25 (§29): category navigation closes the panel first (the sheet is
     removed before the SPA-lite router swaps <main> — no lingering scrim,
     no invisible overlay over the destination page). */
  sh.addEventListener("click", function(ev){
    var a = ev.target.closest ? ev.target.closest("a.csitem") : null;
    if(a){ closeSheet(); }
  });
}

/* ---------------- B.6.3 edge swipe -> More sheet ----------------------- */
(function(){
  var x0 = null, y0 = null;
  D.addEventListener("pointerdown", function(ev){
    if(ev.pointerType === "mouse"){ return; }
    if(ev.clientX > 26){ x0 = null; return; }
    x0 = ev.clientX; y0 = ev.clientY;
  });
  D.addEventListener("pointerup", function(ev){
    if(x0 === null){ return; }
    var dx = ev.clientX - x0, dy = Math.abs(ev.clientY - y0);
    x0 = null;
    if(dx > 64 && dy < 70){
      var b = $("#bnav [data-n=cats]");
      if(b){ b.click(); }
      else{
        var more = $("header .catmore summary");
        if(more){ more.click(); }
      }
    }
  });
})();

/* ---------------- boot ------------------------------------------------- */
function boot(root){
  armShelves(root || D);
  $all(".card", root || D).forEach(function(c){
    if($(".cardlink", c)){ armCard(c); }
  });
  hydrateCards(root || D);
  armBottomNav();
  renderQueue();
  /* <=640px: the card hover menu is touch-only (long-press) — make the
     sheet menu the touch path (B.6.2). */
  $all(".cardmenubtn", root || D).forEach(function(b){
    b.addEventListener("pointerdown", function(ev){
      if(ev.pointerType !== "mouse" && window.matchMedia(
        "(max-width: 640px)").matches){
        ev.preventDefault();
        sheetMenuFor(b.closest(".card"));
      }
    });
  });
}
if(D.readyState !== "loading"){ boot(D); }
else{ D.addEventListener("DOMContentLoaded", function(){ boot(D); }); }
// B24 (Phase 3): after a SPA-lite fetch-and-swap the NEW <main> has fresh
// .card/.shelfwrap elements with NO listeners (applyDoc ripped them) —
// re-boot on every swap so shelves, card menus, hydration + watched
// ticks survive navigation. boot() is idempotent (bottom-nav guard +
// per-element data attributes).
document.addEventListener("sitenav:swapped", function(ev){
  try{
    var root = document.getElementById("main") || D;
    boot(root);
    // B24 (Phase 3): close the <details> More panel on any nav (the
    // popstate modal-closer path handles back; a fresh tap on a chip
    // must also close it so it does not linger over the swapped page).
    var d = document.querySelector("details.catmore");
    if(d && d.open){ d.open = false; }
  }catch(e){}
});
// B24 (Phase 3): register the <details class="catmore"> More panel as a
// modal closer so the hardware/Telegram Back button CLOSES the panel
// instead of navigating away (the user's mental model: back closes
// the open menu first). Also close on backdrop tap + ESC.
function closeCatMore(){
  var d = document.querySelector("details.catmore");
  if(d && d.open){ d.open = false; return true; }
  return false;
}
if(window.__SITE_NAV__ && window.__SITE_NAV__.registerModalCloser){
  window.__SITE_NAV__.registerModalCloser(closeCatMore);
}
D.addEventListener("click", function(ev){
  var d = document.querySelector("details.catmore");
  if(!d || !d.open){ return; }
  if(!ev.target.closest || !ev.target.closest(".catmore")){ d.open = false; }
}, true);
D.addEventListener("keydown", function(ev){
  if(ev && (ev.key === "Escape" || ev.key === "Esc")){ closeCatMore(); }
});
/* V25 (§25): the More control state machine — the native <details> toggle
   is mirrored onto aria-expanded (chevron rotation is CSS-driven by
   [open]). One canonical state; the sync survives SPA swaps because it
   listens at document scope (toggle does not bubble — capture phase). */
function syncCatMoreState(dt){
  var s = dt.querySelector("summary");
  if(s){ s.setAttribute("aria-expanded", dt.open ? "true" : "false"); }
}
D.addEventListener("toggle", function(ev){
  var t = ev.target;
  if(t && t.classList && t.classList.contains("catmore")){
    syncCatMoreState(t);
  }
}, true);
window.__UX__ = {boot: boot, toast: toast, queue: window.__uxQueue,
                 prefetch: pfGet, hydrateCards: hydrateCards};
})();"""


# ------------------------------- page bootstrap: welcome §30 + theme §DARK
# One tiny dependency-free bootstrap (inline, runs once per page): the
# cinematic intro overlay (NO sound — the Website audio option was removed;
# payload players and the ad video system are untouched) and the header
# THEME toggle (V25 §17: dark ↔ light ONLY, persisted in localStorage
# "eutheme"; the System option was removed and legacy values migrate once).
# The intro is shown at most once per browser session (sessionStorage
# "euintro"); the theme resolution itself happens EARLIER, in the inline
# no-flash <head> script emitted by _page() (before first paint).
_INTRO_JS = """(function(){
"use strict";
var intro = document.getElementById("wintro");
var wline = document.getElementById("wline");
var wname = document.getElementById("wname");
var skipBtn = intro ? intro.querySelector(".wskip") : null;
var themeBtn = document.getElementById("themebtn");
var reduced = false;
try{
  reduced = !!(window.matchMedia &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches);
}catch(e){}
function seenIntro(){
  try{ return sessionStorage.getItem("euintro") === "1"; }catch(e){ return true; }
}
function markIntro(){ try{ sessionStorage.setItem("euintro", "1"); }catch(e){} }
/* ------- theme (V25 S17: localStorage "eutheme" dark|light ONLY) ------- */
/* The user-facing System option was REMOVED (V25 S17). A legacy
   stored system value was ALREADY migrated by the no-flash boot script
   (resolved to the device preference and persisted) — themePref()
   therefore only ever sees dark or light after boot; the defensive
   default below keeps a cold localStorage read honest. */
function themePref(){
  var v = null;
  try{ v = localStorage.getItem("eutheme"); }catch(e){}
  return (v === "light") ? "light" : "dark";
}
function applyTheme(){
  var t = themePref();
  document.documentElement.setAttribute("data-theme", t);
  var mt = document.querySelector('meta[name="theme-color"]');
  if(mt){ mt.setAttribute("content", t === "light" ? "#f7f6fa" : "#060609"); }
}
function paintThemeBtn(){
  if(!themeBtn){ return; }
  var p = themePref();
  themeBtn.textContent = p === "dark" ? "\U0001F319" : "\u2600\uFE0F";
  var label = "Theme: " + p + " (tap to change)";
  themeBtn.setAttribute("title", label);
  themeBtn.setAttribute("aria-label", label);
  themeBtn.setAttribute("aria-pressed", "true");
}
if(themeBtn){
  themeBtn.addEventListener("click", function(){
    /* V25 S17: the cycle is dark <-> light (the System option no longer
       exists anywhere in the user-facing theme control). */
    var next = themePref() === "dark" ? "light" : "dark";
    try{ localStorage.setItem("eutheme", next); }catch(e){}
    applyTheme();
    paintThemeBtn();
  });
  paintThemeBtn();
}
/* -------- A.3.4 (bot-25): phone landscape best-effort -------------- */
/* Runs after the theme boot. Telegram WebView may ignore the request;
   plain phone browsers receive it. Never breaks the app when the
   Orientation API is unsupported (silent best-effort). */
try{
  if(screen && screen.orientation && screen.orientation.lock){
    var _shortest = Math.min(screen.width, screen.height);
    if(_shortest < 768){
      var _lk = screen.orientation.lock("landscape");
      if(_lk && _lk.catch){ _lk.catch(function(){}); }
    }
  }
}catch(e){}
/* ---------------- intro overlay (silent, same timing/skip as before) -- */
function hideIntro(now){
  if(!intro || intro.hidden){ return; }
  markIntro();
  if(now || reduced){
    intro.hidden = true;
    intro.classList.remove("fade");
    return;
  }
  intro.classList.add("fade");
  window.setTimeout(function(){
    intro.hidden = true;
    intro.classList.remove("fade");
  }, 460);
}
if(intro){
  var rawUser = intro.getAttribute("data-user") || "";
  var um = /^[A-Za-z0-9_]{1,24}$/.exec(String(rawUser));
  if(um && wname){
    wname.textContent = "@" + um[0];
  }else if(wline){
    wline.hidden = true;
  }
  if(!seenIntro() && !reduced){
    intro.hidden = false;
    window.setTimeout(function(){ hideIntro(false); }, 2400);
  }
  if(skipBtn){
    skipBtn.addEventListener("click", function(){ hideIntro(true); });
  }
}
})();"""


# --------------------------- no-flash theme boot (inline, in <head>) ----
# Runs BEFORE the stylesheet is parsed (so before first paint): resolves
# the stored "eutheme" preference (dark | light | system — system follows
# prefers-color-scheme) onto <html data-theme> and syncs the theme-color
# meta. Tiny, dependency-free, and shared by EVERY page _page() emits.
# NOTE (QA-stub guard): this file must never contain the literal string
# "window.Telegram=" — the browser QA proxy keys stub injection on it.
_THEME_BOOT_JS = """(function(){try{
/* V25 S17: the user-facing theme control is DARK|LIGHT ONLY. A legacy
   stored "system" value is migrated ONCE right here (before first paint):
   resolved to the device preference and PERSISTED, so the stored record
   is never deleted, the user keeps seeing exactly what they saw (no
   flash), and every later load reads a clean dark|light value. An absent
   value (first-time visitor) keeps resolving per load until the user
   picks — nothing is forced. */
var _d=document.documentElement,_v=null;
try{_v=localStorage.getItem("eutheme");}catch(e){}
var _os=(window.matchMedia&&window.matchMedia("(prefers-color-scheme: light)").matches)?"light":"dark";
if(_v==="system"){
  var _r=_os;
  try{localStorage.setItem("eutheme",_r);}catch(e2){}
  _v=_r;
}
var _t=(_v==="dark"||_v==="light")?_v:_os;
_d.setAttribute("data-theme",_t);
var _m=document.querySelector('meta[name="theme-color"]');
if(_m){_m.setAttribute("content",_t==="light"?"#f7f6fa":"#060609");}
}catch(e){try{document.documentElement.setAttribute("data-theme","dark");
}catch(e2){}}})();"""


# ------------- head telemetry boot + nav deferral (V26 script ordering) ---
# V26 SCRIPT-ORDERING FIX (the Phase-1 browser defect): page scripts that
# live INSIDE <main> (the player bootstrap, the age-gate / FJ-gate /
# login / settings scripts) execute when the parser reaches them —
# BEFORE the trailing _SITE_NAV_JS / _UX_JS at the end of <body>. Two
# globals they reference at TOP LEVEL must therefore exist BEFORE any
# <main> content:
#   1. window.__TEL_URL__ + window.__siteTel — the telemetry helper.
#      It needs NO DOM (sendBeacon / fetch only), so the <head> is the
#      correct deterministic home. Previously the helper was defined at
#      the END of _SITE_NAV_JS: on full loads PLAYER_OPEN (and the gate
#      RENDER / HANDLER_ATTACHED events) silently never fired because
#      the helper did not exist yet when the body scripts ran.
#   2. window.__siteNavReady(fn) — a deterministic deferral queue for
#      __SITE_NAV__ registrations (the player's settings-menu
#      modalCloser). Body scripts queue; _SITE_NAV_JS drains the queue
#      synchronously the moment it publishes __SITE_NAV__ — no timers,
#      no polling, no arbitrary setTimeout. On SPA swaps __SITE_NAV__
#      already exists and the callback runs immediately.
_TELEMETRY_BOOT_JS = """(function(){
"use strict";
// V26 PLAYER / AGE-GATE telemetry: bounded, allowlisted client events
// POSTed to /site/api/telemetry (the server logs WEBSITE_TELEMETRY
// lines — greppable production evidence). Fire-and-forget: failures are
// silent (telemetry must never break UX); sendBeacon during unload,
// fetch keepalive otherwise. NEVER carries secrets (no tokens, no
// initData, no signed URLs) — bounded event names + bounded fields.
window.__siteTel = function(ev, fields){
  try{
    var url = window.__TEL_URL__;
    if(!url){ return; }
    var payload = {event: String(ev || "").slice(0, 40)};
    if(fields){
      for(var k in fields){
        if(!Object.prototype.hasOwnProperty.call(fields, k)){ continue; }
        var val = fields[k];
        if(val === null || val === undefined){ continue; }
        payload[String(k).slice(0, 24)] =
          (typeof val === "number")
          ? (isFinite(val) ? Math.round(val * 1000) / 1000 : 0)
          : String(val).slice(0, 64);
      }
    }
    var body = JSON.stringify(payload);
    if(navigator.sendBeacon){
      try{
        if(navigator.sendBeacon(url, new Blob([body],
            {type: "application/json"}))){ return; }
      }catch(e){}
    }
    try{
      fetch(url, {method: "POST",
        headers: {"Content-Type": "application/json"},
        body: body, keepalive: true}).catch(function(){});
    }catch(e){}
  }catch(e){}
};
// V26 script-ordering deferral: body scripts register __SITE_NAV__
// hooks through this queue; _SITE_NAV_JS drains it after publishing.
window.__siteNavQ = [];
window.__siteNavReady = function(fn){
  try{
    if(window.__SITE_NAV__){ fn(window.__SITE_NAV__); return; }
    window.__siteNavQ.push(fn);
  }catch(e){}
};
})();"""


# ------------------------------------------- open-in-browser (RETIRED)
# A.3 (bot-25): _OPEN_EXT_JS is REMOVED. The Mini App → external-browser
# handoff bootstrap (header button reveal + POST /site/api/ext-link +
# Telegram.WebApp.openLink) no longer ships on any page; the header
# control (openextbtn) and the ext-link route registration are gone too
# (engagement.py). The server-side handlers remain as dead functions for
# compatibility and are unreachable from any normal UI path.


# -------------------------------------- internal history nav (B23 §4.3)
# The SPA-lite internal navigation layer. Every same-origin /site link
# (payload cards, part pills, back links, chips) becomes a fetch-and-swap
# transition with a REAL history.pushState entry — the platform Back
# control (Telegram.WebApp.BackButton inside the Mini App, the browser
# back button / Android hardware back elsewhere) then walks the site's
# OWN history instead of closing the Mini App:
#
#   Root → Payload → Video 1 → Back → Payload → Video 2 → Back → Payload
#        → Back → Root → Back → normal Telegram/browser exit
#
# Rules (§4.3):
#   * internal navigation NEVER reloads the whole page — the <main>
#     region (and <title>, and the category nav's active state) swap
#     in place from the fetched document;
#   * a modal open → close takes precedence (delegated: modal overlays
#     register a closer with __SITE_NAV__ and the FIRST back closes the
#     modal instead of navigating);
#   * Telegram BackButton shows when deeper than root, hides at root;
#   * plain <a> links keep working without JS (progressive enhancement);
#     a failed fetch falls back to an honest full navigation.
#   * scroll position per URL is remembered and restored on back;
#   * NO infinite history entries (same-URL clicks replaceState).
_SITE_NAV_JS = """(function(){
"use strict";
var ROOT_RE = /^\\/?site\\/?$/;
var main = document.getElementById("main");
if(!main){ return; }
// (V26 script-ordering fix: window.__siteTel + window.__TEL_URL__ now
// live in the <head> _TELEMETRY_BOOT_JS, BEFORE any <main> script —
// body-embedded page scripts (player bootstrap, gate scripts) could
// never see the helper when it was defined here, at the document end.)
var swapCache = {};                 // url -> {main, title, scroll}
var modalClosers = [];              // LIFO: first back closes the modal
var depth = 0;                      // internal entries beyond the entry URL
// V26 FINAL (Parts 6+7) — the WEBSITE NAVIGATION BOUNDARY.
// entryBackSafe: TRUE when THIS full load was reached from another
// /site page of the same origin (document.referrer) — browser history
// genuinely has an internal entry BEHIND us, so history.back() walks
// INSIDE the site. FALSE for a cold deep link (Telegram entry, shared
// link, fresh tab): pressing an in-app Back control then MUST NOT
// blindly history.back() (that exits the website / closes the Mini
// App — the production "Back throws the user completely out" defect);
// the canonical fallback is /site (HOME).
var entryBackSafe = false;
try{
  var _ref = document.referrer || "";
  if(_ref){
    var _ru = new URL(_ref, location.href);
    entryBackSafe = (_ru.origin === location.origin)
      && (_ru.pathname === "/site"
          || _ru.pathname.indexOf("/site/") === 0);
  }
}catch(e){}
// V26 FINAL (Part 7) — navigation telemetry (SITE_NAV_*). Fields:
// from/to/route/source/state_id — the paths are SANITIZED (long
// capability-looking segments truncated) so tokens never reach logs.
var navSeq = 0;
function navLogPath(url){
  try{
    var u = new URL(String(url || ""), location.href);
    var segs = u.pathname.split("/");
    for(var i = 0; i < segs.length; i++){
      if(segs[i].length > 16){
        segs[i] = segs[i].slice(0, 8) + "~" + segs[i].length;
      }
    }
    return segs.join("/") || "/";
  }catch(e){ return "/~"; }
}
function navRoute(url){
  try{
    var u = new URL(String(url || ""), location.href);
    var p = u.pathname;
    if(ROOT_RE.test(p) || p === "/" || p === ""){ return "home"; }
    if(p.indexOf("/site/c/") === 0){ return "category"; }
    if(p.indexOf("/site/payload/") === 0
       && p.indexOf("/video/") !== -1){ return "video"; }
    if(p.indexOf("/site/payload/") === 0){ return "payload"; }
    if(p.indexOf("/site/search") === 0){ return "search"; }
    if(p.indexOf("/site/collections") === 0){ return "collections"; }
    if(p.indexOf("/site/settings") === 0){ return "settings"; }
    return "other";
  }catch(e){ return "other"; }
}
function navTel(kind, fields){
  try{
    if(window.__siteTel){
      window.__siteTel("SITE_NAV_" + kind, fields || {});
    }
  }catch(e){}
}
function navTelBase(source){
  navSeq++;
  return {
    from: navLogPath(location.href),
    route: navRoute(location.href),
    source: String(source || "-"),
    state_id: String(navSeq)
  };
}
// V26 PLAYER BACK SEMANTICS — the layer stack. Every in-player overlay
// (settings sheet root, settings submenu, fullscreen) owns ONE real
// history entry (pushed at open). Back therefore closes EXACTLY ONE
// layer WITHOUT navigating (URL and content stay in sync — the old
// modalClosers-only path consumed a real navigation entry instead,
// leaving the URL pointing at the payload page while the screen still
// showed the player). popLayer() uses history.back() behind a
// pending-pop counter so UI-initiated closes consume their own sentinel
// silently (never a loop, never a double navigation).
var __layerStack = [];              // [{type: 'menu'|'fs', closer: fn}]
var __layerPopPending = 0;          // our own in-flight back() pops
function __pushLayer(type, closer){
  if(__layerStack.length >= 6){ return; }   // bounded — never a runaway
  try{
    history.pushState({siteNavLayer: __layerStack.length + 1}, "",
      location.href);
  }catch(e){ return; }
  __layerStack.push({type: type, closer: closer || null});
  depth++;
  syncBackButton();
}
function __popLayer(){
  if(__layerStack.length <= __layerPopPending){ return; }
  __layerPopPending++;
  try{ history.back(); }
  catch(e){ __layerPopPending--; __layerStack.pop(); if(depth > 0){ depth--; } }
}
function __layerCount(type){
  var n = 0;
  for(var i = 0; i < __layerStack.length; i++){
    if(!type || __layerStack[i].type === type){ n++; }
  }
  return n;
}
function __clearLayers(){
  // Synchronous stack clear (player teardown): NO back() — a back()
  // inside a popstate-driven swap would consume a REAL navigation entry.
  // Stale sentinel history entries (same URL) cost at most one extra,
  // inert Back press — bounded, never a loop.
  __layerStack.length = 0;
  __layerPopPending = 0;
}

function isInternal(href){
  try{
    var u = new URL(href, location.href);
    if(u.origin !== location.origin){ return false; }
    return u.pathname === "/site" || u.pathname.indexOf("/site/") === 0;
  }catch(e){ return false; }
}
function atRoot(){
  return ROOT_RE.test(location.pathname) || location.pathname === "/"
    || location.pathname === "";
}
function syncBackButton(){
  var tg = null;
  try{ tg = window.Telegram && window.Telegram.WebApp; }catch(e){}
  if(!tg || !tg.BackButton){ return; }
  // B23 §4.3 (version gate): the BackButton API exists from Bot API 6.1
  // — on older clients every show()/hide() call logs an SDK warning
  // ("BackButton is not supported in version 6.0"). The site history is
  // REAL history entries, so the platform back control (browser back /
  // Android hardware back) keeps working on old clients regardless; the
  // Telegram BackButton is an enhancement, never a requirement.
  try{
    if(tg.isVersionAtLeast && !tg.isVersionAtLeast("6.1")){ return; }
  }catch(e){}
  // Self-healing: if the SDK object was REPLACED after we armed (a late
  // stub/SDK swap), re-register the onClick wiring on the CURRENT
  // BackButton — the navigation handler must never be lost.
  if(tg.BackButton !== _armedBB){ armBackButton(); }
  var deeper = !atRoot() || depth > 0;
  try{
    if(deeper){ tg.BackButton.show(); } else { tg.BackButton.hide(); }
  }catch(e){}
}
function applyDoc(doc, url, scroll){
  var m = doc.querySelector ? doc.querySelector("main#main") : null;
  if(!m){
    // V26 FINAL (Part 7): the honest full-load escape — logged, never
    // silent (a fetched doc without main#main is a navigation error).
    navTel("ERROR", (function(){
      var f = navTelBase("applydoc_no_main");
      f.to = navLogPath(url);
      return f;
    })());
    window.location.href = url;
    return false;
  }
  // B24 (Phase 2): tear down the OLD player before ripping <main> —
  // pauses <video>, revokes blob: URLs, destroys hls.js, removes the
  // document keydown + fullscreenchange listeners + tg.onEvent handlers
  // that would otherwise leak across navigations.
  try{ if(window.__playerTeardown){ window.__playerTeardown(); } }catch(e){}
  main.innerHTML = m.innerHTML;
  document.title = doc.title || document.title;
  // B.3.1: ONLY <title> + <meta name="description"> come from the
  // fetched document; the rest of <head> stays untouched.
  try{
    var md = doc.querySelector ? doc.querySelector(
      'meta[name="description"]') : null;
    var cur = document.querySelector('meta[name="description"]');
    if(md && cur){ cur.setAttribute("content",
      md.getAttribute("content") || ""); }
  }catch(e){}
  // B24 (Phase 3): Category nav active state follows the fetched document.
  // FIXED: the old selector `nav.cats` matched NOTHING (the real class is
  // `nav.catnav`) so the active chip + More-panel state never propagated
  // after a fetch-swap. replaceWith+clone preserves delegated listeners.
  try{
    var oldNav = document.querySelector("nav.catnav");
    var newNav = doc.querySelector ? doc.querySelector("nav.catnav") : null;
    if(oldNav && newNav){ oldNav.replaceWith(newNav.cloneNode(true)); }
  }catch(e){}
  window.scrollTo(0, scroll || 0);
  // B.3.2: horizontal shelf scroll positions restore with the page.
  try{
    var shelfScrolls = (swapCache[url] || {}).shelf || [];
    var rows = main.querySelectorAll(".shelfrow");
    for(var i = 0; i < rows.length && i < shelfScrolls.length; i++){
      rows[i].scrollLeft = shelfScrolls[i] || 0;
    }
  }catch(e){}
  execScripts(main);
  return true;
}
function execScripts(root){
  // Swapped-in <script> tags do not execute via innerHTML — re-create
  // each one (src or inline) so the target page bootstraps exactly as it
  // would on a full navigation (the OLD page's DOM is gone; fresh
  // bootstrap is the correct lifecycle).
  var scripts = root.querySelectorAll ? root.querySelectorAll("script") : [];
  for(var i = 0; i < scripts.length; i++){
    var s = scripts[i];
    var ns = document.createElement("script");
    if(s.getAttribute && s.getAttribute("src")){
      ns.src = s.getAttribute("src");
    } else {
      ns.textContent = s.textContent || "";
    }
    if(s.parentNode){ s.parentNode.replaceChild(ns, s); }
  }
}
function fetchSwap(url, push, scroll){
  var __navFrom = location.href;
  if(swapCache[url]){
    var hit = swapCache[url];
    if(push){
      history.pushState({siteNav:1}, "", url); depth++;
      navTel("PUSH", (function(){
        var f = navTelBase(push === "seed" ? "seed" : "click");
        f.to = navLogPath(url);
        return f;
      })());
    }
    applyDoc(hit.doc, url, scroll != null ? scroll : hit.scroll);
    syncBackButton();
    return;
  }
  var navFetch = (window.__UX__ && window.__UX__.prefetch)
    ? window.__UX__.prefetch(url).catch(function(){
        return fetch(url, {headers: {"X-Site-Nav": "1"},
                           credentials: "same-origin"})
          .then(function(r){
            if(!r.ok){ throw new Error("HTTP " + r.status); }
            return r.text();
          });
      })
    : fetch(url, {headers: {"X-Site-Nav": "1"}, credentials: "same-origin"})
      .then(function(r){
        if(!r.ok){ throw new Error("HTTP " + r.status); }
        return r.text();
      });
  navFetch
    .then(function(html){
      var doc = new DOMParser().parseFromString(html, "text/html");
      swapCache[url] = {doc: doc, scroll: scroll || 0};
      if(push){
        history.pushState({siteNav:1, from: location.href}, "", url);
        depth++;
        navTel("PUSH", (function(){
          var f = navTelBase("click");
          f.to = navLogPath(url);
          return f;
        })());
      }
      applyDoc(doc, url, scroll);
      syncBackButton();
      main.setAttribute("data-nav-url", url);
      document.dispatchEvent(
        new CustomEvent("sitenav:swapped", {detail: {url: url}}));
    })
    .catch(function(){
      // V26 FINAL (Part 7): fetch failure — logged, then the honest
      // full-load fallback (still an INTERNAL /site URL — the boundary
      // is never left).
      navTel("ERROR", (function(){
        var f = navTelBase("fetch_failed");
        f.to = navLogPath(url);
        return f;
      })());
      window.location.href = url;
    });
}
document.addEventListener("click", function(ev){
  var a = ev.target.closest ? ev.target.closest("a[href]") : null;
  if(!a){ return; }
  if(ev.defaultPrevented || ev.button !== 0 || ev.metaKey || ev.ctrlKey
     || ev.shiftKey || ev.altKey){ return; }
  if(a.target && a.target !== "_self"){ return; }
  if(a.hasAttribute("download")){ return; }
  // B.3.1: the explicit opt-out wins.
  if(a.dataset.noRouter !== undefined){ return; }
  var href = a.getAttribute("href") || "";
  if(!href || href.charAt(0) === "#" || href.indexOf("javascript:") === 0
     || href.indexOf("t.me") !== -1){ return; }
  if(!isInternal(a.href)){ return; }
  // A marked in-page back link with internal history BEHIND us walks the
  // history stack (never a fresh push); without history it follows the
  // href as a plain link would.
  if(a.classList.contains("backlink")){
    // V26 PLAYER_BACK telemetry: the player Back (the marked backlink
    // on the player page) closes the player and returns to the payload
    // — BOTH paths are the same user action: the history walk below,
    // and the plain-link fallback for a deep-linked player (no internal
    // history behind it). The old code only instrumented the history
    // walk, so a full-load player exit never emitted PLAYER_BACK.
    try{
      if(document.getElementById("playerbox")){
        window.__siteTel("PLAYER_BACK", {from: "player"});
      }
    }catch(e){}
    if(depth > 0){
      ev.preventDefault();
      navTel("BACK", (function(){
        var f = navTelBase("backlink");
        f.to = "history";
        return f;
      })());
      history.back();
      return;
    }
  }
  ev.preventDefault();
  // remember THIS page's scroll for the back restore
  var key = location.href;
  if(swapCache[key]){ swapCache[key].scroll = window.scrollY || 0; }
  else{
    // B24 (Phase 3): clone the CURRENT <main> so popstate can TRULY
    // restore it (the entry page + any deep-link reload has no fetched
    // doc snapshot; the old getDoc closure returned the LIVE document,
    // which had been mutated by every applyDoc — so back only scrolled
    // and left the user on the LAST swapped content with the entry URL).
    // boot() has already armed shelves/cards by now (DOMContentLoaded).
    var _snap = null;
    try{ _snap = main.cloneNode(true); }catch(e){}
    swapCache[key] = {doc: null, scroll: window.scrollY || 0, self: true,
      mainSnap: _snap};
  }
  // B.3.2: the horizontal shelf positions ride along with the page.
  try{
    var rows = main.querySelectorAll(".shelfrow");
    var shelf = [];
    for(var i = 0; i < rows.length; i++){ shelf.push(rows[i].scrollLeft); }
    swapCache[key].shelf = shelf;
  }catch(e){}
  var target = new URL(a.href, location.href).href;
  if(target === location.href){
    // same URL: refresh-in-place semantics WITHOUT a new history entry
    delete swapCache[target];
    fetchSwap(target, false, 0);
    return;
  }
  fetchSwap(target, true, 0);
}, true);
try{ if("scrollRestoration" in history){
  history.scrollRestoration = "manual"; } }catch(e){}
window.addEventListener("popstate", function(){
  // V26 layer sentinels — case 1: OUR OWN back() (a layer closed via its
  // UI Back/close button). Consume the entry silently: the stack was
  // already adjusted by the UI; no closer, no navigation.
  if(__layerPopPending > 0){
    __layerPopPending--;
    __layerStack.pop();
    if(depth > 0){ depth--; }
    syncBackButton();
    return;
  }
  // V26 layer sentinels — case 2: an in-player overlay (settings sheet /
  // submenu / fullscreen) is open and owns the top history entry. Back
  // closes EXACTLY ONE layer (LIFO) WITHOUT navigating — the URL stays
  // the player URL and the screen stays the player, one layer lighter.
  if(__layerStack.length){
    var __entry = __layerStack.pop();
    if(depth > 0){ depth--; }
    try{ if(__entry && __entry.closer){ __entry.closer(); } }catch(e){}
    syncBackButton();
    return;
  }
  // First back: an open modal closes INSTEAD of navigating.
  // V26 FIX (stale-closer drain): walk the LIFO stack WITHOUT permanently
  // unregistering non-applicable closers — the old while/pop loop dropped
  // every closer that returned false, so later Back presses navigated
  // instead of closing the (still-registered) modals.
  for(var __ci = modalClosers.length - 1; __ci >= 0; __ci--){
    var closer = modalClosers[__ci];
    var closed = false;
    try{ closed = closer() !== false; }catch(e){ closed = true; }
    if(closed){ return; }
  }
  if(depth > 0){ depth--; }
  var url = location.href;
  var hit = swapCache[url];
  // V26 FINAL (Part 7): a popstate that RESTORES a route (the modal/
  // layer consumptions above returned early — this is a REAL internal
  // navigation) is logged as SITE_NAV_POP.
  navTel("POP", (function(){
    var f = navTelBase("popstate");
    f.to = navLogPath(url);
    return f;
  })());
  if(hit && hit.doc){ applyDoc(hit.doc, url, hit.scroll || 0); }
  else if(hit && hit.mainSnap){
    // B24 (Phase 3): entry-page / deep-link restore — replace <main>
    // with a FRESH clone of the captured snapshot so the original
    // content (HOME feed, shelves, cards) comes back, not the last
    // swapped page. Re-boot so the clone's listeners re-arm.
    var fresh = hit.mainSnap.cloneNode(true);
    main.replaceWith(fresh);
    main = document.getElementById("main");
    if(main){ main.setAttribute("data-nav-url", url); }
    window.scrollTo(0, hit.scroll || 0);
    try{ execScripts(main); }catch(e){}
    try{ if(window.__UX__ && window.__UX__.boot){ window.__UX__.boot(main); } }catch(e){}
  }
  else if(hit && hit.getDoc){ window.scrollTo(0, hit.scroll || 0); }
  else{ fetchSwap(url, false, 0); }
  syncBackButton();
  document.dispatchEvent(
    new CustomEvent("sitenav:swapped", {detail: {url: url}}));
});
// The entry page registers ITSELF as a restorable snapshot (popstate to
// it must restore the scroll, not refetch what the user already had).
try{
  // B24 (Phase 3): placeholder — the real mainSnap is captured on the
  // FIRST click away (the click handler clones <main> then). getDoc is
  // kept as a no-op safety net for any path that still reads it.
  swapCache[location.href] = {doc: null, scroll: 0, self: true,
    mainSnap: null,
    getDoc: function(){ return document; }};
}catch(e){}
// V26 FINAL (Parts 6+7) — the CANONICAL CHAIN SEED for a cold deep
// entry. window.__NAV_CHAIN__ (server-rendered breadcrumb array, e.g.
// ["/site", "/site/payload/x"] on a video page) rebuilds the site's
// canonical hierarchy BEHIND the current entry: replaceState the entry
// to the chain root, pushState each parent, then re-claim the deep
// URL. The visible URL NEVER changes; Back then walks the canonical
// hierarchy (PLAY -> FILE DETAIL -> PAYLOAD -> ... -> HOME) instead of
// exiting the website. Only runs when the browser history did NOT
// begin inside /site (entryBackSafe === false) — a normal in-site
// arrival already has the true chain behind it.
try{
  if(!entryBackSafe && !atRoot()
     && window.__NAV_CHAIN__ && window.__NAV_CHAIN__.length){
    var __chain = [];
    for(var __nc = 0; __nc < window.__NAV_CHAIN__.length; __nc++){
      var __cu = new URL(String(window.__NAV_CHAIN__[__nc] || ""),
                         location.href);
      if(isInternal(__cu.href)
         && __cu.href !== location.href
         && __chain.indexOf(__cu.href) === -1){
        __chain.push(__cu.href);
      }
    }
    if(__chain.length){
      var __entryUrl = location.href;
      var __entrySnap = swapCache[__entryUrl];
      history.replaceState({siteNav:1, seeded:1}, "", __chain[0]);
      for(var __ni = 1; __ni < __chain.length; __ni++){
        history.pushState({siteNav:1, seeded:1}, "", __chain[__ni]);
      }
      history.pushState({siteNav:1, seeded:1}, "", __entryUrl);
      depth = __chain.length;
      // the deep entry's own snapshot stays restorable; the seeded
      // parents re-fetch on pop (they were never displayed).
      if(__entrySnap){ swapCache[__entryUrl] = __entrySnap; }
      navTel("REPLACE", (function(){
        var f = navTelBase("chain_seed");
        f.to = navLogPath(__chain[0]);
        return f;
      })());
      syncBackButton();
    }
  }
}catch(e){}
var _armedBB = null;
// V26 FINAL (Parts 6+7) — the in-app Back boundary predicate: an
// in-app Back control may history.back() ONLY when the walk provably
// stays inside /site (SPA entries exist: depth > 0; or this load was
// reached from an internal /site page: entryBackSafe). Otherwise the
// canonical SAFE BACK fallback runs: navigate to /site (HOME).
function canWalkBack(){
  return depth > 0 || entryBackSafe;
}
function navFallback(source){
  var f = navTelBase(source || "boundary");
  f.to = "/site";
  navTel("FALLBACK", f);
  try{ history.replaceState({siteNav:1, fallback:1}, "", "/site"); }catch(e){}
  fetchSwap("/site", false, 0);
  syncBackButton();
}
function armBackButton(){
  // The Mini App SDK can land AFTER DOMContentLoaded (network latency —
  // the same lesson the retired openext control taught us): poll
  // briefly so a LATE SDK still gets the BackButton wiring + the
  // visibility sync.
  var tg = null;
  try{ tg = window.Telegram && window.Telegram.WebApp; }catch(e){}
  if(!tg || !tg.BackButton){ return false; }
  if(tg.BackButton === _armedBB){ return true; }  // already armed
  try{
    tg.BackButton.onClick(function(){
      // V26 FINAL (Part 6): the Telegram BackButton NEVER exits the
      // website — with internal history it walks one level back; on a
      // cold deep link with no internal history it falls back to HOME.
      if(canWalkBack()){
        navTel("BACK", (function(){
          var f = navTelBase("telegram_backbutton");
          f.to = "history";
          return f;
        })());
        history.back();
      } else {
        navFallback("telegram_backbutton");
      }
    });
  }catch(e){}
  _armedBB = tg.BackButton;
  syncBackButton();
  return true;
}
if(!armBackButton()){
  var _navWaited = 0;
  var _navIv = setInterval(function(){
    _navWaited += 50;
    if(armBackButton() || _navWaited >= 3000){ clearInterval(_navIv); }
  }, 50);
}
syncBackButton();
window.__SITE_NAV__ = {
  registerModalCloser: function(fn){ modalClosers.push(fn); },
  depth: function(){ return depth; },
  // V26 layer-sentinel API (player Back semantics): every in-player
  // overlay owns one real history entry; Back closes exactly one layer.
  pushLayer: __pushLayer,
  popLayer: __popLayer,
  layerCount: __layerCount,
  layerTop: function(){
    return __layerStack.length ?
      __layerStack[__layerStack.length - 1].type : null;
  },
  clearLayers: __clearLayers
};
// V26 script-ordering fix: drain the deterministic deferral queue —
// body-embedded scripts (the player bootstrap INSIDE <main>) run BEFORE
// this file and queued their __SITE_NAV__ registrations through
// window.__siteNavReady (defined in the head _TELEMETRY_BOOT_JS).
// Synchronous, once, no timers — and re-drain-safe (the queue empties).
try{
  var __navQ = window.__siteNavQ;
  if(__navQ && __navQ.length){
    for(var __navI = 0; __navI < __navQ.length; __navI++){
      try{ __navQ[__navI](window.__SITE_NAV__); }catch(e){}
    }
    __navQ.length = 0;
  }
}catch(e){}
})();"""


# ------------------------------------------------------------- media icons
# Inline stroke icons (feather-style, no external resources). Every glyph
# is a complete <svg> sized by CSS; stroke uses currentColor.
def _icon(name: str, *, cls: str = "") -> str:
    c = (f' class="{cls}"' if cls else "")
    base = ('<svg' + c + ' viewBox="0 0 24 24" fill="none" '
            'stroke="currentColor" stroke-width="2" '
            'stroke-linecap="round" stroke-linejoin="round" '
            'aria-hidden="true">')
    paths = {
        "video": ('<rect x="2" y="4" width="20" height="16" rx="3"/>'
                  '<path d="M7 4v16M17 4v16M2 9h5M2 15h5M17 9h5M17 15h5"/>'),
        "play": '<path d="M6 4l14 8-14 8z" fill="currentColor" stroke="none"/>',
        "audio": ('<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/>'
                  '<circle cx="18" cy="16" r="3"/>'),
        "photo": ('<rect x="3" y="3" width="18" height="18" rx="3"/>'
                  '<circle cx="8.5" cy="8.5" r="1.5"/>'
                  '<path d="M21 15l-5-5L5 21"/>'),
        "document": ('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12'
                     'a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M16 13H8'
                     'M16 17H8"/>'),
        "animation": ('<path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1'
                      ' 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13'
                      'v2a4 4 0 0 1-4 4H3"/>'),
        "collection": ('<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0'
                       '-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7'
                       ' 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d='
                       '"M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12"/>'),
        "file": ('<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0'
                 ' 0 0 2-2V9z"/><path d="M13 2v7h7"/>'),
        "search": ('<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35'
                   '-4.35"/>'),
        "arrow-left": ('<path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/>'),
        "arrow-right": ('<path d="M5 12h14"/><path d="M12 5l7 7-7 7"/>'),
        "chevron-left": '<path d="M15 18l-6-6 6-6"/>',
        "chevron-right": '<path d="M9 18l6-6-6-6"/>',
        "chevron-down": '<path d="M6 9l6 6 6-6"/>',
        "layers": ('<path d="M12 2L2 7l10 5 10-5z"/><path d="M2 17l10 5'
                   ' 10-5"/><path d="M2 12l10 5 10-5"/>'),
        "clock": ('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>'),
        "size": ('<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7'
                 ' 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7'
                 '-4A2 2 0 0 0 21 16z"/>'),
        "grid": ('<rect x="3" y="3" width="7" height="7" rx="1"/>'
                 '<rect x="14" y="3" width="7" height="7" rx="1"/>'
                 '<rect x="14" y="14" width="7" height="7" rx="1"/>'
                 '<rect x="3" y="14" width="7" height="7" rx="1"/>'),
        "star": ('<path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 21 12'
                 ' 17.77 5.82 21 7 14.14l-5-4.87 6.91-1.01z"/>'),
        "info": ('<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/>'
                 '<path d="M12 8h.01"/>'),
        "settings": ('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65'
                     ' 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-'
                     '.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1'
                     ' 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51'
                     ' 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83'
                     'l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-'
                     '1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1'
                     ' 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-'
                     '2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.08a1.65 1.65 0'
                     ' 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1'
                     ' 1.51h.08a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1'
                     ' 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.08a1.65'
                     ' 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0'
                     ' 0 0-1.51 1z"/>'),
        "user": ('<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>'
                 '<circle cx="12" cy="7" r="4"/>'),
        # ---- B17 player-control icons (feather-style, same system) ----
        "pause": ('<path d="M7 4h3v16H7zM14 4h3v16h-3z" '
                  'fill="currentColor" stroke="none"/>'),
        "volume-2": ('<path d="M11 5L6 9H2v6h4l5 4z" '
                     'fill="currentColor" stroke="none"/>'
                     '<path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>'
                     '<path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>'),
        "volume-1": ('<path d="M11 5L6 9H2v6h4l5 4z" '
                     'fill="currentColor" stroke="none"/>'
                     '<path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>'),
        "volume-x": ('<path d="M11 5L6 9H2v6h4l5 4z" '
                     'fill="currentColor" stroke="none"/>'
                     '<path d="M23 9l-6 6M17 9l6 6"/>'),
        "maximize": ('<path d="M8 3H5a2 2 0 0 0-2 2v3"/>'
                     '<path d="M16 3h3a2 2 0 0 1 2 2v3"/>'
                     '<path d="M8 21H5a2 2 0 0 1-2-2v-3"/>'
                     '<path d="M16 21h3a2 2 0 0 0 2-2v-3"/>'),
        "minimize": ('<path d="M8 3v3a2 2 0 0 1-2 2H3"/>'
                     '<path d="M16 3v3a2 2 0 0 0 2 2h3"/>'
                     '<path d="M8 21v-3a2 2 0 0 0-2-2H3"/>'
                     '<path d="M16 21v-3a2 2 0 0 1 2-2h3"/>'),
        "pip": ('<rect x="2" y="4" width="20" height="16" rx="2"/>'
                '<rect x="12" y="11" width="8" height="6" rx="1" '
                'fill="currentColor" stroke="none"/>'),
        "check": '<path d="M20 6L9 17l-5-5"/>',
        "rotate-ccw": ('<path d="M1 4v6h6"/>'
                       '<path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>'),
        "lock": ('<rect x="3" y="11" width="18" height="11" rx="2"/>'
                 '<path d="M7 11V7a5 5 0 0 1 10 0v4"/>'),
        "external": ('<path d="M7 17L17 7"/>'
                     '<path d="M7 7h10v10"/>'),
        "alert-triangle": ('<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94'
                           'a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>'
                           '<path d="M12 9v4M12 17h.01"/>'),
        "check-circle": ('<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>'
                         '<path d="M22 4L12 14.01l-3-3"/>'),
        # ---- B18-FINAL engagement icons (feather-style, same system) ----
        "rotate-cw": ('<path d="M23 4v6h-6"/>'
                      '<path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>'),
        "thumbs-up": ('<path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0'
                      ' 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1'
                      '-2-2v-7a2 2 0 0 1 2-2h3"/>'),
        "thumbs-down": ('<path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0'
                        ' 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31'
                        ' 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"/>'),
        "eye": ('<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>'
                '<circle cx="12" cy="12" r="3"/>'),
        "download": ('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>'
                      '<path d="M7 10l5 5 5-5"/><path d="M12 15V3"/>'),
        "browser": ('<rect x="2" y="4" width="20" height="16" rx="2"/>'
                    '<path d="M2 8h20"/><path d="M5 6h.01M8 6h.01"/>'),
    }
    return base + paths.get(name, paths["file"]) + "</svg>"


# B17 UX POLISH: the icon set the PLAYER CONTROLS use in JS. Emitted into
# the player bootstrap as one JSON blob (``var ICONS = {...}``) so every
# control renders the same stroke-icon system as the rest of the site —
# never a platform-dependent Unicode glyph (\u25B6/\u23F8/\u26F6/\u29C9
# render inconsistently across OS emoji fonts).
_PLAYER_ICONS_JS = {
    "play": _icon("play"),
    "pause": _icon("pause"),
    "vol": _icon("volume-2"),
    "volLow": _icon("volume-1"),
    "volMute": _icon("volume-x"),
    "fs": _icon("maximize"),
    "fsExit": _icon("minimize"),
    "pip": _icon("pip"),
    "settings": _icon("settings"),
    "check": _icon("check"),
    "replay": _icon("rotate-ccw"),
    "reload": _icon("rotate-cw"),
    "thumbUp": _icon("thumbs-up"),
    "thumbDown": _icon("thumbs-down"),
    "eye": _icon("eye"),
    "browser": _icon("browser"),
    "lock": _icon("lock"),
    "external": _icon("external"),
    "chevron": _icon("chevron-right"),
    # V25 (§11): the submenu affordance alias (back rows + navigable rows)
    "chev": _icon("chevron-right"),
    "clock": _icon("clock"),
    "warn": _icon("alert-triangle"),
    "ok": _icon("check-circle"),
    "info": _icon("info"),
}


# ------------------------------------------------------------- art palettes
# Deterministic per-title gradient art (hash-stable — the same payload
# always renders the same art). Dark, rich, brand-compatible (violet /
# lilac / indigo / champagne / copper / rose / graphite).
_ART_PALETTES = [
    ("#150f2e", "#7c5fc9"),
    ("#1c1633", "#a78bfa"),
    ("#241c40", "#b9a5f0"),
    ("#2b2410", "#d9c290"),
    ("#2a1505", "#e08b4a"),
    ("#271022", "#c2588f"),
    ("#141821", "#5d6a7d"),
    ("#141a33", "#94a7dd"),
]

# media kind -> inline icon glyph (shared by pills / art / file rows)
_KIND_ICONS = {"video": "play", "audio": "audio", "photo": "photo",
               "document": "document", "animation": "animation",
               "collection": "collection"}

_TYPE_LABELS = {
    "video": "Video", "audio": "Audio", "photo": "Photo",
    "document": "Document", "animation": "Animation",
    "collection": "Collection", "file": "File",
}

# B24 (Phase 4): the per-kind count-label vocabulary + display order —
# used by aggregate_media_counts + _count_label so the outer card AND the
# inner detail badge render the TRUTHFUL multi-type summary ("3 videos · 2
# photos") instead of collapsing to the canonical file's single type.
_COUNT_KIND_ORDER = ("video", "animation", "audio", "photo", "document", "file")
_COUNT_KIND_LABEL = {
    "video": ("video", "videos"),
    "animation": ("animation", "animations"),
    "audio": ("audio track", "audio tracks"),
    "photo": ("photo", "photos"),
    "document": ("document", "documents"),
    "file": ("file", "files"),
}


def aggregate_media_counts(files) -> Dict[str, int]:
    """Aggregate per-kind media counts from a list of file dicts (B24 Phase 4).

    Used by the outer listing card AND the inner detail badge so BOTH
    reflect the TRUE multi-type inventory (3 videos + 2 photos → "3 videos ·
    2 photos") instead of collapsing to the first file's type. Pure +
    deterministic — safe to call over the FULL pre-cap file list so the
    displayed summary stays truthful even when MAX_DETAIL_FILES caps the
    rendered rows. Deleted/unavailable files must already be excluded by
    the caller (the detail resolver + the listing enrichment do this).
    """
    counts: Dict[str, int] = {}
    for f in files or []:
        mt = ""
        if isinstance(f, dict):
            mt = str(f.get("media_type") or "").lower()
        else:
            mt = str(f or "").lower()
        kind = _media_kind(mt)
        counts[kind] = counts.get(kind, 0) + 1
    return counts


def esc(value) -> str:
    """HTML-escape EVERY dynamic value (XSS-safe output, spec §20)."""
    return html.escape(str(value if value is not None else ""), quote=True)


def site_url(path: str) -> str:
    """Site-relative path (never absolute hosts — same-origin only)."""
    return "/" + str(path or "").lstrip("/")


def _art_svg(title: str, media_kind: str, *, seed: int = 0) -> str:
    """Deterministic gradient placeholder art with a media-type glyph.

    Renders placeholder art at every thumbnail-priority level (servable
    thumbnail bytes arrive through the Media Gateway); the art is derived
    from a stable hash of the title, so a payload always looks like
    itself across renders and pages.
    """
    h = (sum(ord(c) for c in str(title or "P")) + int(seed)) or 1
    c1, c2 = _ART_PALETTES[h % len(_ART_PALETTES)]
    gid = f"g{h % 100000}"
    glyph = _KIND_ICONS.get(media_kind, "collection")
    icon = _icon(glyph)
    return (
        '<svg viewBox="0 0 320 180" xmlns="http://www.w3.org/2000/svg" '
        'role="img" aria-label="placeholder artwork">'
        f'<defs><linearGradient id="{gid}" x1="0" y1="0" x2="1" y2="1">'
        f'<stop offset="0" stop-color="{c1}"/>'
        f'<stop offset="1" stop-color="{c2}"/>'
        "</linearGradient></defs>"
        f'<rect width="320" height="180" fill="url(#{gid})"/>'
        f'<circle cx="{40 + h % 240}" cy="{30 + h % 90}" r="{52 + h % 34}" '
        'fill="#ffffff" opacity="0.06"/>'
        f'<circle cx="{300 - h % 180}" cy="{150 - h % 70}" r="34" '
        'fill="#000000" opacity="0.16"/>'
        '<circle cx="160" cy="90" r="56" fill="#a78bfa" opacity="0.10"/>'
        '<circle cx="160" cy="90" r="42" fill="none" stroke="#a78bfa" '
        'stroke-opacity="0.28" stroke-width="1.5"/>'
        '<path d="M0 138 Q 160 96 320 150 L 320 180 L 0 180 Z" '
        'fill="#000000" opacity="0.2"/>'
        '<g transform="translate(128.8,58.8) scale(2.6)" '
        'style="color:#a78bfa;opacity:.9">' + icon + "</g>"
        "</svg>")


def _media_kind(item_or_media: Any, *, is_collection: bool = False) -> str:
    """Classify a listing/file into an art + icon kind."""
    if is_collection:
        return "collection"
    media = str(item_or_media or "").lower()
    if media in ("video", "animation"):
        return media
    if media in ("audio", "voice"):
        return "audio"
    if media in ("photo", "image"):
        return "photo"
    if media in ("document",):
        return "document"
    return "file"


def _type_pill(kind: str) -> str:
    label = _TYPE_LABELS.get(kind, "File")
    return ('<span class="typepill glass">' + _icon(
        _KIND_ICONS.get(kind, "file")) + esc(label) + "</span>")


def _show_type_pill(*, is_collection: bool, media: str,
                    count: int) -> bool:
    """Suppress the type pill when the count badge already carries the
    type word (a single VIDEO card shows '1 video' — the pill would be
    redundant; every other combination adds information)."""
    if is_collection:
        return True
    if str(media or "").lower() == "video" and count == 1:
        return False
    return True


# ------------------------------------------------------------ category nav
def _cat_chip(cat: Dict[str, Any], *, active_slug: str = "") -> str:
    """One header category chip (spec §28 — max 3 non-restricted).

    B24 (Phase 3): ``active_slug`` marks the chip corresponding to the
    page the user is currently viewing (the /site/c/{slug} feed) with a
    ``cur`` class + ``aria-current="page"`` so the active category is
    visually distinct and announced to assistive tech.

    V25 (§27): the chip carries STRUCTURED data attributes
    (``data-cat-name`` / ``data-cat-icon``) so the mobile Categories panel
    builds clean icon+label rows from the DOM instead of flattening
    ``textContent`` (the label-concatenation root cause).
    """
    slug = str(cat.get("slug") or "").strip()
    icon = str(cat.get("icon") or "")
    name = str(cat.get("name") or slug or "Category")
    cur = (" cur" if slug and slug == active_slug else "")
    aria = (' aria-current="page"' if slug and slug == active_slug else "")
    return ('<a class="catchip' + cur + '"' + aria
            + ' data-cat-name="' + esc(name) + '"'
            + (' data-cat-icon="' + esc(icon) + '"' if icon else "")
            + ' href="'
            + esc(site_url("site/c/" + quote_plus(slug))) + '">'
            + (f'<span class="cico" aria-hidden="true">{esc(icon)}</span>'
               if icon else "")
            + '<span class="clabel">' + esc(name) + "</span></a>")


def _cat_menu_item(cat: Dict[str, Any], *, r18: bool = False) -> str:
    """One entry inside the ⋮ More dropdown. B10-W2 (spec §19): the
    age-restricted entry is rendered ALWAYS — pre-confirmation included —
    with a GUARANTEED 🔞 marker (the renderer supplies it, never the
    admin-managed icon, so a renamed/re-iconed category can never lose
    the 18+ signal); it links to /site/c/{slug}, which serves the age
    gate until the session is confirmed. The entry carries the category
    name ONLY — never restricted payload titles or counts.

    V25 (§27): structured ``data-cat-name`` / ``data-cat-icon`` /
    ``data-r18`` attributes — the mobile Categories panel reads them and
    renders every entry as a separate semantic row (no textContent
    concatenation, no clipped runs of labels).
    """
    slug = str(cat.get("slug") or "").strip()
    icon = str(cat.get("icon") or "")
    name = str(cat.get("name") or slug or "Category")
    cls = "mmitem r18" if r18 else "mmitem"
    if r18:
        label = ('<span class="r18mark" aria-hidden="true">\U0001F51E</span>'
                 + " " + esc(name))
    else:
        label = ((esc(icon) + " ") if icon else "") + esc(name)
    return ('<a class="' + cls + '"'
            + ' data-cat-name="' + esc(name) + '"'
            + (' data-cat-icon="' + esc(icon) + '"' if icon else "")
            + (' data-r18="1"' if r18 else "")
            + ' href="'
            + esc(site_url("site/c/" + quote_plus(slug))) + '">'
            + label + "</a>")


# ---------------------------------------------------------------- layout
def _page(title: str, body: str, *, show_search: bool = False,
          search_value: str = "", head_extra: str = "",
          description: str = "Browse and unlock payload packages.",
          noindex: bool = False, user: Optional[dict] = None,
          categories: Optional[list] = None,
          age_ok: bool = False,
          active_slug: str = "", no_intro: bool = False) -> str:
    """The site chrome: sticky glass header (brand / search / verified
    identity chip §23 / THEME toggle (dark → light → system) / category
    nav §28), content, footer, one-time welcome overlay (§30) + the inline
    page bootstrap. The official Telegram Mini App SDK is loaded in
    <head> so the auth lifecycle (BOOT → TELEGRAM_LOADING →
    TELEGRAM_READY → AUTHENTICATING → READY / AUTHENTICATION_FAILED)
    always sees window.Telegram.WebApp once the WebView finishes parsing.
    Theming: the inline _THEME_BOOT_JS runs before first paint and the
    [data-theme="light"] token overrides re-skin the whole site.

    New optional kwargs (all default OFF so every existing call site
    stays valid):
      * ``user``        — {"username","first_name"}: verified chip
        "👤 @username" / "👤 Telegram User" + "Welcome back";
      * ``categories``  — [{"slug","name","icon","age_restricted"}]:
        up to 3 non-restricted chips + a ⋮ More dropdown that ALWAYS
        carries Collections / My Points / About / Settings;
      * ``age_ok``      — kept for call-site compatibility. B10-W2 spec
        §19: the age-restricted ⋮ More entries render regardless — the
        🔞 18+ entry must be discoverable BEFORE confirmation (it links
        to the /site/c/{slug} age gate); ``age_ok`` no longer hides them.
    """
    search_html = ""
    if show_search:
        search_html = (
            '<form class="search" action="' + esc(site_url("site/search"))
            + '" method="get" role="search">'
            '<span class="searchwrap">' + _icon("search", cls="searchicon")
            + '<input type="search" name="q" placeholder="Search payloads…" '
            'value="' + esc(search_value) + '" '
            'aria-label="Search payloads" autocomplete="off">'
            "</span>"
            '<button class="searchbtn" type="submit" aria-label="Search">'
            + _icon("arrow-right") + "</button></form>")

    # ---- verified identity chip (spec §23) --------------------------
    user_html = ""
    wuser = ""
    if user:
        username = str(user.get("username") or "").strip()
        first = str(user.get("first_name") or "").strip()
        wuser = username
        handle = ("@" + username) if username else "Telegram User"
        chip_title = "Verified Telegram identity"
        if first:
            chip_title = chip_title + " — " + first
        user_html = (
            '<div class="userchip" title="' + esc(chip_title) + '">'
            '<span class="uava" aria-hidden="true">\U0001F464</span>'
            '<span class="uinfo"><span class="uname">' + esc(handle)
            + '</span><span class="usub">Welcome back</span></span></div>')

    # ---- category nav (spec §28) -------------------------------------
    cat_html = ""
    if categories:
        cats = [c for c in categories if isinstance(c, dict)
                and str(c.get("slug") or "").strip()]
        open_cats: List[Dict[str, Any]] = []
        restricted: List[Dict[str, Any]] = []
        for c in cats:
            try:
                ar = int(c.get("age_restricted") or 0)
            except (TypeError, ValueError):
                ar = 0
            (restricted if ar else open_cats).append(c)
        nav = ['<nav class="catnav" aria-label="Categories">']
        nav.extend(_cat_chip(c, active_slug=active_slug) for c in open_cats[:3])
        more = [_cat_menu_item(c) for c in open_cats[3:]]
        # B10-W2 (spec §19): the age-restricted entries are ALWAYS listed
        # (pre-confirmation included) with the 🔞 marker — they link to
        # /site/c/{slug}, which serves the age gate until the session is
        # confirmed server-side. The entry itself leaks nothing about the
        # restricted content (category name only).
        more.extend(_cat_menu_item(c, r18=True) for c in restricted)
        if more:
            more.append('<div class="mmdiv" aria-hidden="true"></div>')
        more.extend((
            '<a class="mmitem" data-cat-name="Collections" data-group="library"'
            ' href="' + esc(site_url("site/collections"))
            + '">' + _icon("grid") + "Collections</a>",
            '<a class="mmitem" data-cat-name="My Points" data-group="library"'
            ' href="' + esc(site_url("site/network"))
            + '">' + _icon("star") + "My Points</a>",
            '<a class="mmitem" data-cat-name="About" data-group="app"'
            ' href="' + esc(site_url("site/about"))
            + '">' + _icon("info") + "About</a>",
            '<a class="mmitem" data-cat-name="Settings" data-group="app"'
            ' href="' + esc(site_url("site/settings"))
            + '">' + _icon("settings") + "Settings</a>"))
        # V25 (§25): the More control is a REAL state machine — the native
        # <details> open/closed state is mirrored onto aria-expanded and a
        # chevron that points DOWN when closed and UP when open (the
        # toggle-event sync lives in _UX_JS). One canonical state, one
        # control, no duplicate panels.
        nav.append(
            '<details class="catmore"><summary class="catchip more"'
            ' aria-haspopup="true" aria-expanded="false"'
            ' aria-controls="catmoremenu">'
            '<span class="clabel">\u22EE More</span>'
            '<span class="chev" aria-hidden="true">' + _icon("chevron-down")
            + '</span></summary>'
            '<div class="moremenu" id="catmoremenu">'
            + "".join(more) + "</div></details>")
        nav.append("</nav>")
        cat_html = "".join(nav)

    # A.3 (bot-25): the ext-link endpoint URL bootstrap (_OPEN_EXT_JS /
    # ext_api_script) is RETIRED together with the header control — the
    # external-browser handoff surface is removed from every page.

    # ---- one-time welcome overlay + page bootstrap (§30, theme) ----
    # V26 (fresh first-click Age Gate): ``no_intro=True`` suppresses the
    # one-time welcome OVERLAY for INTERACTIVE GATES. The overlay is a
    # full-screen fixed layer (z-index 220) shown for ~2.9 s on the first
    # page of a browser session — on the age-gate interstitial it sat ON
    # TOP of the "I am 18 or older" button, so the user's FIRST tap hit
    # the overlay instead of the button (bot-37.log: every fresh session
    # requested /site/c/adult twice before the POST /site/api/session/age
    # confirm ever fired — 17:16/17:38/17:44). A gate must be immediately
    # interactive. ONLY the overlay markup is omitted — the bootstrap
    # script still ships (it owns the header THEME toggle, and its intro
    # half is null-safe when #wintro is absent).
    _wintro_div = ("" if no_intro else (
        '<div id="wintro" class="wintro" hidden aria-live="polite"'
        ' data-user="' + esc(wuser) + '">'
        '<div class="wglow" aria-hidden="true"></div>'
        '<div class="wcard">'
        '<div class="wbrand" aria-hidden="true"><span class="wdot">'
        '</span>ENDIEFANS</div>'
        '<h2 class="wtitle">Welcome to EndieFans</h2>'
        '<p class="wline" id="wline">'
        + ("Signed in as " if user else "")
        + '<span id="wname"></span></p>'
        '<button class="wskip" type="button">Skip</button>'
        '</div></div>'))
    wintro = _wintro_div + '<script>' + _INTRO_JS + '</script>'

    robots = ('<meta name="robots" content="noindex">' if noindex else "")
    # Head order (auth lifecycle + no-flash theming, spec §7-§15 + §DARK):
    #   1. the OFFICIAL Telegram Mini App SDK — same tag the Watch Ads mini
    #      app loads, parsed synchronously BEFORE any body script runs;
    #   2. the meta block (color-scheme now "dark light", theme-color is
    #      synced to the active theme by the boot script below);
    #   3. the inline no-flash theme boot — resolves localStorage
    #      "eutheme" (dark|light|system) onto <html data-theme> BEFORE the
    #      stylesheet is parsed (never a dark→light flash);
    #   4. the stylesheet + caller head_extra.
    return (
        "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width,"
        "initial-scale=1,viewport-fit=cover\">"
        '<script src="https://telegram.org/js/telegram-web-app.js">'
        "</script>"
        "<meta name=\"color-scheme\" content=\"dark light\">"
        '<meta name="theme-color" content="#060609">'
        '<meta name="description" content="' + esc(description) + '">'
        + robots +
        "<title>" + esc(title) + " \u2014 EndieFans</title>"
        "<script>" + _THEME_BOOT_JS + "</script>"
        # V26 script-ordering fix: the telemetry endpoint + helper live
        # in the <head>, BEFORE any <main> script — body-embedded scripts
        # (player bootstrap, gate scripts) reference them at TOP LEVEL.
        # (Previously __TEL_URL__ was emitted near the footer: PLAYER_OPEN
        # and the gate RENDER / HANDLER_ATTACHED events never fired on
        # full loads, and SPA swaps never re-run trailing scripts.)
        '<script>window.__TEL_URL__='
        + json.dumps(site_url("site/api/telemetry")) + ';</script>'
        "<script>" + _TELEMETRY_BOOT_JS + "</script>"
        "<style>" + _SITE_CSS + "</style>" + head_extra + "</head>"
        # BOT-26 ISSUE B (production solid-green screen): this <body> tag
        # was missing its closing ">" — the following <a class="skip">
        # start tag was ABSORBED as body ATTRIBUTES by the HTML parser, so
        # the body element itself received class="skip" (and href) and the
        # skip anchor never existed. CSS .skip{position:absolute;
        # left:-9999px;top:0;z-index:100;background:var(--accent-dk);...}
        # then applied to the WHOLE BODY: the body box (header + main +
        # footer — every page's content) shifted 9999px off-screen while
        # the body's background (propagated to the canvas because html
        # has none) painted the viewport SOLID accent green in the dark theme
        # (--accent-dk); position:fixed children (#bnav bottom nav,
        # #toasts, #navprog) escaped the shift and stayed visible — the
        # exact production screenshot (Telegram top bar → solid green →
        # visible bottom nav, zero site content). The tag is now
        # well-formed: the body closes, the skip link is a real <a>.
        + '<body data-site-root="' + esc(site_url("site")) + '">'
        '<a class="skip" href="#main">Skip to content</a>'
        "<header class=\"site\">"
        "<div class=\"hrow\">"
        "<div class=\"brand\"><span class=\"dot\" aria-hidden=\"true\">"
        "</span><a class=\"wordmark\" href=\"" + esc(site_url("site")) + "\">"
        "EndieFans</a>"
        '<span class="brandtag">WEBSITE</span></div>'
        '<div class="hactions">' + user_html
        # A.3 (bot-25): the header Open-in-browser control is REMOVED —
        # the external-browser handoff surface is retired (no UI path
        # reaches /site/api/ext-link or /site/ext/{token} anymore; the
        # handlers stay as dead code for compatibility, the routes are
        # unregistered in engagement.py).
        + '<button id="themebtn" class="themebtn" type="button"'
        ' aria-pressed="false"'
        ' aria-label="Theme: dark (tap to change)"'
        ' title="Theme: dark (tap to change)">'
        "\U0001F319</button></div>"
        "</div>"
        + search_html + cat_html +
        "</header>"
        '<main id="main" class="site">' + body + "</main>"
        "<footer class=\"site\"><span class=\"fdot\" aria-hidden=\"true\">"
        "</span>"
        "Payload platform — search, open a payload, unlock in Telegram."
        "</footer>"
        + wintro +
        "<script>" + _SITE_NAV_JS + "</script>"
        "<script>" + _UX_JS + "</script>"
        "</body></html>")


# ---------------------------------------------------------------- maintenance
def maintenance_page() -> str:
    """Clean mobile-friendly maintenance page (Website OFF, spec §5/§6)."""
    body = ("<div class=\"centerwrap\"><div class=\"mbox\">"
            "<div class=\"glyph\">\U0001F6E0\uFE0F</div>"
            "<h1>Website under maintenance</h1>"
            "<p>The public website is temporarily switched off.</p>"
            "<p>All Telegram payload links, delivery and access keep working "
            "normally — open the bot in Telegram.</p>"
            '<p class="maction"><a class="backlink" href="'
            + esc(site_url("site")) + '">' + _icon("clock")
            + "Try again</a></p>"
            "</div></div>")
    return _page("Maintenance", body,
                 description="The public website is temporarily switched off.")


# ---------------------------------------------------------------- feed cards
def _chips(tags: Optional[Iterable[str]], *, links: bool = True) -> str:
    """Tag chips — clickable links into the ONE search system (q=tag)."""
    out = []
    for t in (tags or [])[:8]:
        t = str(t)
        if not t:
            continue
        if links:
            out.append('<a class="chip" href="'
                       + esc(site_url("site/search")
                             + "?q=" + quote_plus(t)) + '">'
                       + esc(t) + "</a>")
        else:
            out.append('<span class="chip">' + esc(t) + "</span>")
    return '<div class="chips">' + "".join(out) + "</div>" if out else ""


def _fmt_size(size) -> str:
    try:
        n = float(size)
    except (TypeError, ValueError):
        return ""
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return (f"{n:.0f} {unit}" if unit in ("B", "KB")
                    else f"{n:.1f} {unit}")
        n /= 1024
    return ""


def _count_label(count: int, media: str, *,
                 media_counts: Optional[Dict[str, int]] = None) -> str:
    """File-count badge text (pinned wording: 'N files' / 'N videos').

    B24 (Phase 4): when ``media_counts`` is provided, emit the truthful
    per-kind summary (e.g. '3 videos · 2 photos') instead of collapsing
    to a single type. The legacy (count, media) signature stays for every
    existing call site that has not been wired to the listing enrichment.
    """
    if media_counts:
        parts = []
        for k in _COUNT_KIND_ORDER:
            n = int(media_counts.get(k) or 0)
            if n <= 0:
                continue
            sing, plur = _COUNT_KIND_LABEL.get(k, ("file", "files"))
            parts.append(f"{n} {plur if n != 1 else sing}")
        if parts:
            return " \u00b7 ".join(parts)
    if media in ("video", "animation"):
        return (f"{count} video" if count == 1 else f"{count} videos")
    return (f"{count} file" if count == 1 else f"{count} files")


def _badge_icon(kind: str) -> str:
    return _icon({"video": "play", "audio": "audio", "photo": "photo",
                  "document": "document", "animation": "animation",
                  "collection": "layers"}.get(kind, "file"))


# ------------------ PROMPT B player UX layer (bot-25) --------------------
# Ambient mode, theater mode, mini-player + queue consumption, double-tap
# seek, long-press 2x, the end screen, the autoplay toggle and chapter
# parsing. Vanilla JS; NO authorization logic (the server pipeline owns
# every decision — this layer only enhances presentation).
_PLAYER_UX_JS = """(function(){
"use strict";
var D = document;
function $(s, r){ return (r || D).querySelector(s); }
function $all(s, r){ return Array.prototype.slice.call(
  (r || D).querySelectorAll(s)); }
function reduced(){ try{ return !!(window.matchMedia &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  }catch(e){ return false; } }
var UX = window.__UXDATA__ || {};
var pbox = $("#playerbox");
var v = null;   // resolved by the player bootstrap; polled for below
var boundEl = null;  // V26: the element armAll() bound to
var pv = setInterval(function(){
  var el = pbox ? pbox.querySelector("video, audio") : null;
  if(el){ v = el; boundEl = el; clearInterval(pv); armAll(); }
  if(!pbox && !$("#playerwrap")){ clearInterval(pv); }
}, 300);
setTimeout(function(){ clearInterval(pv); }, 30000);
/* V26 (one media element, one stream lifecycle): an in-place rebuild
   (Retry / re-auth / FJ-verify) REPLACES the media element — the old
   element's listeners die with it. The player script calls
   __uxPlayerRebind() after every mount so the UX extras (end screen,
   chapters, mini player, autoplay toggle, theater) re-bind to the LIVE
   element; teardownMedia removes the old overlays so nothing
   duplicates. Idempotent: a no-op while the element is unchanged. */
window.__uxPlayerRebind = function(){
  try{
    var el = pbox ? pbox.querySelector("video, audio") : null;
    if(el && el !== boundEl){
      v = el; boundEl = el;
      armAll();
    }
  }catch(e){}
};

function armAll(){
  if(!pbox){ return; }
  armAmbient();
  armTheater();
  armDoubleTap();
  armLongPress();
  armEndScreen();
  armChapters();
  armAutoplayToggle();
  armMini();
}

/* ---------------- B.1.1 ambient mode ----------------------------------- */
function armAmbient(){
  try{
    if(!(v && v.tagName === "VIDEO") || reduced()){ return; }
    var wrap = pbox.parentElement;
    if(!wrap || wrap.querySelector("#ambient")){ return; }
    var cv = D.createElement("canvas");
    cv.id = "ambient"; cv.setAttribute("aria-hidden", "true");
    wrap.classList.add("ambwrap");
    wrap.insertBefore(cv, pbox);
    var ambientIv = null;
    var draw = function(){
      try{
        /* V25 (§37): the sampler self-terminates once its canvas is
           detached (an SPA navigation away from the player must not
           leave an immortal 5s interval drawing on a dead canvas). */
        if(!cv.isConnected){
          if(ambientIv){ clearInterval(ambientIv); ambientIv = null; }
          return;
        }
        if(D.fullscreenElement || pbox.classList.contains("fsfake")
           || v.paused){ return; }
        var w = 40, h = Math.max(24, Math.round(40 * (v.videoHeight
          / (v.videoWidth || 1)) || 22));
        cv.width = w; cv.height = h;
        cv.getContext("2d").drawImage(v, 0, 0, w, h);
        cv.style.opacity = ".55";
      }catch(e){
        /* CORS taint or not-ready: fall back to the page background */
        cv.style.opacity = "0";
      }
    };
    ambientIv = setInterval(draw, 5000);
    v.addEventListener("playing", draw, {once: true});
  }catch(e){}
}

/* ---------------- B.1.2 theater mode ----------------------------------- */
function armTheater(){
  try{
    var bar = $(".pctl", pbox);
    if(!bar || $("#ptheater")){ return; }
    var fs = $("#pfs");
    var b = D.createElement("button");
    b.id = "ptheater"; b.className = "pctlbtn"; b.type = "button";
    b.setAttribute("aria-pressed", "false");
    b.setAttribute("aria-label", "Theater mode");
    b.innerHTML = "&#9635;";
    bar.insertBefore(b, fs || null);
    var sync = function(){
      var on = D.body.classList.contains("theater");
      pbox.classList.toggle("theater", on);
      b.setAttribute("aria-pressed", on ? "true" : "false");
      try{ sessionStorage.setItem("uxtheater", on ? "1" : "0"); }catch(e){}
    };
    b.addEventListener("click", function(){
      D.body.classList.toggle("theater"); sync();
    });
    try{
      if(sessionStorage.getItem("uxtheater") === "1"){
        D.body.classList.add("theater"); sync();
      }
    }catch(e){}
  }catch(e){}
}

/* ---------------- B.1.4 double-tap seek + B.1.5 long-press 2x ---------- */
function armDoubleTap(){
  try{
    var stage = v.parentElement || pbox;
    var lastTap = 0, tapTimer = null, lastX = 0;
    var lpTimer = null, prevRate = 1, spd = null;
    stage.addEventListener("pointerdown", function(ev){
      if(ev.pointerType === "mouse" && ev.button !== 0){ return; }
      lastX = ev.clientX;
      if(ev.pointerType !== "mouse"){
        lpTimer = setTimeout(function(){
          prevRate = v.playbackRate || 1;
          v.playbackRate = 2;
          if(!spd){ spd = D.createElement("div"); spd.className = "spd";
            spd.textContent = "2\\u00d7 \\u25b6"; pbox.appendChild(spd); }
          spd.style.display = "block";
        }, 500);
      }
    });
    ["pointerup", "pointercancel"].forEach(function(n){
      stage.addEventListener(n, function(ev){
        clearTimeout(lpTimer);
        if(spd && spd.style.display === "block"){
          v.playbackRate = prevRate;
          spd.style.display = "none";
          if(n === "pointercancel"){ return; }
        }
        if(n !== "pointerup"){ return; }
        var now = Date.now();
        var rect = stage.getBoundingClientRect();
        var left = (ev.clientX - rect.left) < rect.width / 2;
        if(now - lastTap < 300){
          /* double tap: seek with ripple */
          clearTimeout(tapTimer);
          lastTap = 0;
          try{ v.currentTime = Math.max(0, Math.min(
            (v.duration || 1e9), v.currentTime + (left ? -10 : 10))); }
          catch(e){}
          var rip = D.createElement("div");
          rip.className = "ripple";
          rip.textContent = left ? "\\u221210s" : "+10s";
          rip.style.left = (ev.clientX - rect.left) + "px";
          rip.style.top = (ev.clientY - rect.top) + "px";
          stage.appendChild(rip);
          setTimeout(function(){ if(rip.parentNode){
            rip.parentNode.removeChild(rip); } }, 520);
        } else {
          lastTap = now;
          /* single tap toggles the controls ONCE (delayed so a second
             tap never double-fires) */
          clearTimeout(tapTimer);
          tapTimer = setTimeout(function(){
            pbox.classList.toggle("ctl-idle");
          }, 260);
        }
      });
    });
  }catch(e){}
}
function armLongPress(){}

/* ---------------- B.2.2 end screen + B.2.3 autoplay toggle -------------- */
function armEndScreen(){
  try{
    if(!v || v.tagName !== "VIDEO"){ return; }
    if($(".endscr", pbox)){ return; }   // V26: never duplicate the overlay
    var hasNext = !!(UX.nextHref);
    var hasRel = !!(UX.relatedHref);
    /* TASK G (BOT-45/46 §11): the end screen is an END-OF-PLAYBACK state
       ONLY. The old last-20-seconds-while-playing overlay (a timeupdate
       "dur - currentTime <= 20" trigger) covered ACTIVE video and
       violated "Next Part only after playback ends". The overlay now
       appears EXCLUSIVELY on the media 'ended' event; startup, playing,
       paused, seeking and buffering NEVER show it, and any replay or
       seek-back hides it again (Next Part must never cover active
       video). Single payloads get [ Replay ] only; packages add
       [ Next Part ]. */
    var scr = D.createElement("div");
    scr.className = "endscr";
    scr.setAttribute("hidden", "");
    var cards = "";
    if(hasNext){
      cards += '<div class="endcard" data-go="' + UX.nextHref + '">' +
        '<img alt="" src="' + String(UX.poster || "").replace(/"/g,
          "&quot;") + '"><div class="et">Next part</div></div>';
    }
    if(hasRel){
      cards += '<div class="endcard" data-go="' + UX.relatedHref + '">' +
        '<img alt="" src="' + String(UX.relatedPoster || "").replace(/"/g,
          "&quot;") + '"><div class="et">' +
        String(UX.relatedTitle || "Related").replace(/</g, "&lt;") +
        "</div></div>";
    }
    var btns = '<div class="endbtns">' +
      '<button type="button" class="endbtn" data-end="replay">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
      'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ' +
      'aria-hidden="true"><polyline points="1 4 1 10 7 10"/><path ' +
      'd="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>Replay</button>';
    if(hasNext){
      btns += '<button type="button" class="endbtn go" data-end="next">' +
        "Next Part</button>";
    }
    btns += "</div>";
    scr.innerHTML = '<div class="endtitle">Playback complete</div>'
      + btns + cards;
    pbox.appendChild(scr);
    var shown = false;
    function showEnd(){
      if(shown){ return; }
      shown = true;
      scr.hidden = false;
      scr.classList.add("on");
      /* TASK G (BOT-45/46 §11): PLAYER_END_SCREEN fires the moment the
         end-of-playback screen appears (the 'ended' event — never
         while the video is playing). */
      try{ if(window.__siteTel){
        window.__siteTel("PLAYER_END_SCREEN", {next: hasNext ? 1 : 0});
      } }catch(e){}
    }
    function hideEnd(){
      if(!shown){ return; }
      shown = false;
      scr.hidden = true;
      scr.classList.remove("on");
    }
    /* The ONLY trigger: actual end of playback (never timeupdate). */
    v.addEventListener("ended", showEnd);
    /* Any return to ACTIVE playback (replay, seek, play) hides the
       screen again — the overlay never covers a playing video. */
    ["play", "playing", "seeking", "seeked"].forEach(function(n){
      v.addEventListener(n, hideEnd);
    });
    scr.addEventListener("click", function(ev){
      var b = ev.target.closest("button[data-end]");
      if(b){
        if(b.dataset.end === "replay"){
          /* TASK G: PLAYER_REPLAY — the Replay control activation. */
          try{ if(window.__siteTel){
            window.__siteTel("PLAYER_REPLAY");
          } }catch(e){}
          hideEnd();
          try{
            v.currentTime = 0;
            var p = v.play();
            if(p && p.catch){ p.catch(function(){}); }
          }catch(e2){}
        } else if(b.dataset.end === "next"){
          /* TASK G: PLAYER_NEXT_PART — the Next Part control
             activation (packages only; only ever from the end screen,
             never over active video). */
          try{ if(window.__siteTel){
            window.__siteTel("PLAYER_NEXT_PART");
          } }catch(e){}
          try{ v.pause(); }catch(e2){}
          location.href = UX.nextHref;
        }
        return;
      }
      var c = ev.target.closest(".endcard");
      if(!c){ return; }
      try{ v.pause(); }catch(e){}
      location.href = c.dataset.go;
    });
    /* B.2.3 autoplay next (off by default, localStorage) */
    v.addEventListener("ended", function(){
      try{
        if(localStorage.getItem("uxautoplay") !== "1"){ return; }
      }catch(e){ return; }
      if(hasNext){ location.href = UX.nextHref; }
      else if(hasRel){ location.href = UX.relatedHref; }
    });
  }catch(e){}
}
function armAutoplayToggle(){
  try{
    var menu = $(".pctlmenu", pbox);
    if(!menu){ return; }
    /* V26: openMenu() wipes .pctlmenu — re-arm after every render. The
       guard keeps a re-bind from duplicating the toggle when the menu
       survived. */
    if($("#uxautoplay", pbox)){ return; }
    var b = D.createElement("button");
    b.type = "button"; b.id = "uxautoplay";
    b.textContent = "Autoplay next: off";
    try{
      if(localStorage.getItem("uxautoplay") === "1"){
        b.textContent = "Autoplay next: on";
      }
    }catch(e){}
    b.addEventListener("click", function(){
      var on = false;
      try{
        on = localStorage.getItem("uxautoplay") !== "1";
        localStorage.setItem("uxautoplay", on ? "1" : "0");
      }catch(e2){}
      b.textContent = "Autoplay next: " + (on ? "on" : "off");
    });
    menu.appendChild(b);
  }catch(e){}
}

/* ---------------- B.1.7 chapters (description timestamps) -------------- */
function armChapters(){
  try{
    var desc = String(UX.description || "");
    var re = /(?:^|[\\s(<\\[])(\\d{1,2}):(\\d{2})(?::(\\d{2}))?(?:[\\s)\\]]|$)/g;
    var marks = [], m;
    while((m = re.exec(desc)) !== null && marks.length < 12){
      var t = m[3] !== undefined
        ? (parseInt(m[1], 10) * 3600 + parseInt(m[2], 10) * 60
           + parseInt(m[3], 10))
        : (parseInt(m[1], 10) * 60 + parseInt(m[2], 10));
      marks.push(t);
    }
    if(marks.length < 2 || !v){ return; }
    if($(".chapterbar")){ return; }     // V26: never duplicate the bar
    marks = marks.sort(function(a, b){ return a - b; });
    var bar = D.createElement("div");
    bar.className = "chapterbar";
    bar.setAttribute("role", "group");
    bar.setAttribute("aria-label", "Chapters");
    marks.forEach(function(t, i){
      var b = D.createElement("button");
      b.type = "button"; b.className = "chap";
      var mm = Math.floor(t / 60), ss = t % 60;
      b.textContent = (i + 1) + ". " + mm + ":"
        + (ss < 10 ? "0" : "") + ss;
      b.addEventListener("click", function(){
        try{ v.currentTime = t; v.play(); }catch(e){}
      });
      bar.appendChild(b);
    });
    var meta = $(".playmeta", pbox.parentElement) || pbox.parentElement;
    meta.parentNode.insertBefore(bar, meta);
  }catch(e){}
}

/* ---------------- B.1.3 mini-player + queue consumption ---------------- */
function armMini(){
  try{
    if(!v || v.tagName !== "VIDEO"){ return; }
    if($("#mini")){ return; }           // V26: never duplicate the dock
    var mini = D.createElement("div");
    mini.id = "mini";
    mini.innerHTML =
      '<div class="mvidhost"></div>' +
      '<div class="mbar">' +
      '<button class="mbtn" data-m="pp" aria-label="Play or pause">' +
      "&#9654;</button>" +
      '<div class="mtitle"></div>' +
      '<button class="mbtn" data-m="ret" aria-label="Return to player">' +
      "&#10548;</button>" +
      '<button class="mbtn" data-m="x" aria-label="Close mini player">' +
      '&times;</button></div>';
    D.body.appendChild(mini);
    var host = $(".mvidhost", mini);
    var docked = false;
    function dock(){
      if(docked || !pbox || pbox.classList.contains("fsfake")
         || D.fullscreenElement){ return; }
      docked = true;
      host.appendChild(v);
      mini.classList.add("on");
      $(".mtitle", mini).textContent = UX.title || "";
      syncPP();
    }
    function undock(){
      if(!docked){ return; }
      docked = false;
      var back = $("#playerbox");
      if(back && v.parentNode === host){
        back.insertBefore(v, back.querySelector("#adstage")
          || back.firstChild);
      }
      mini.classList.remove("on");
    }
    function syncPP(){
      var b = $('[data-m=pp]', mini);
      if(b){ b.innerHTML = (v && !v.paused) ? "&#10074;&#10074;"
        : "&#9654;"; }
    }
    var io = new IntersectionObserver(function(ents){
      ents.forEach(function(en){
        if(!en.isIntersecting && !v.paused){ dock(); }
        else if(en.isIntersecting){ undock(); }
      });
    }, {threshold: 0.35});
    if(pbox){ io.observe(pbox); }
    mini.addEventListener("click", function(ev){
      var b = ev.target.closest("button[data-m]");
      if(!b){ return; }
      if(b.dataset.m === "pp"){
        if(v.paused){ var p = v.play(); if(p && p.catch){ p.catch(
          function(){}); } } else { v.pause(); }
        syncPP();
      } else if(b.dataset.m === "ret"){
        undock();
        if(pbox){ pbox.scrollIntoView({block: "center",
          behavior: reduced() ? "auto" : "smooth"}); }
      } else if(b.dataset.m === "x"){
        try{ v.pause(); }catch(e){}
        undock();
      }
    });
    v.addEventListener("play", syncPP);
    v.addEventListener("pause", syncPP);
    /* mini-player swipe-down to close (B.6.3; the × button is the
       visible equivalent) */
    var y0 = null;
    mini.addEventListener("pointerdown", function(ev){ y0 = ev.clientY; });
    mini.addEventListener("pointerup", function(ev){
      if(y0 !== null && ev.clientY - y0 > 60){
        try{ v.pause(); }catch(e){}
        undock();
      }
      y0 = null;
    });
    /* queue end states */
    v.addEventListener("ended", function(){
      try{
        if(localStorage.getItem("uxautoplay") === "1"){ return; }
      }catch(e){}
      var q = (window.__uxQueue && window.__uxQueue.read()) || [];
      if(!q.length){
        var pill = D.createElement("div");
        pill.className = "mpill";
        pill.textContent = "Queue finished";
        mini.appendChild(pill);
        setTimeout(function(){ if(pill.parentNode){
          pill.parentNode.removeChild(pill); } }, 4000);
        return;
      }
      var next = q[0];
      function advance(){
        window.__uxQueue.remove(next.file_pk);
        location.href = next.canonical_url;
      }
      /* staleness first: an unavailable entry is removed with the honest
         toast and the NEXT entry advances; a gate page simply loads. */
      if(window.__UX__ && window.__UX__.prefetch){
        window.__UX__.prefetch(new URL(next.canonical_url,
          location.origin).pathname).then(advance, function(){
          window.__uxQueue.remove(next.file_pk);
          window.__uxToast("This item is no longer available");
          setTimeout(function(){
            var rest = (window.__uxQueue && window.__uxQueue.read()) || [];
            if(rest.length){ location.href = rest[0].canonical_url; }
          }, 900);
        });
      } else { advance(); }
      var pill2 = D.createElement("div");
      pill2.className = "mpill";
      pill2.textContent = "Playing next: " + (next.title || "");
      mini.appendChild(pill2);
      setTimeout(function(){ if(pill2.parentNode){
        pill2.parentNode.removeChild(pill2); } }, 3000);
    });
  }catch(e){}
}
})();"""


def shelf_section(title: str, sub: str = "", cards_html: str = "",
                  *, shelf_id: str = "", hidden: bool = False) -> str:
    """PROMPT B (bot-25): one horizontal shelf section (the home feed is
    built from these; the media sidebar reuses the section heads)."""
    if not cards_html:
        return ""
    sid = f' id="{esc(shelf_id)}"' if shelf_id else ""
    style = ' style="display:none"' if hidden else ""
    return (
        f'<section class="shelf"{sid}{style}>'
        f'<div class="shelfhead"><span class="shelftitle">{esc(title)}</span>'
        + (f'<span class="shelfsub">{esc(sub)}</span>' if sub else "")
        + "</div>"
        '<div class="shelfwrap"><div class="shelfrow">' + cards_html
        + "</div></div></section>")


def card(item: Dict[str, Any], *, index: int = 0,
         carry_query: str = "", thumb_url: str = "") -> str:
    """One Payload card: artwork (real thumbnail bytes via the Media
    Gateway when available, gradient art as the always-present fallback
    layer), media type pill, gold file-count glass badge, title,
    description, clickable tag chips. Clicking opens the Payload DETAIL
    page (the card is a Payload/package, never a single video — spec §1).

    ``carry_query`` appends preserved navigation state (q/p/sort) so a
    card opened from SEARCH returns to the exact results page (spec §10
    search-state preservation, now wired end-to-end).
    """
    tags = [t for t in str(item.get("tags") or "").split() if t][:8]
    desc = str(item.get("description") or "")
    count = int(item.get("file_count") or 0)
    is_collection = bool(item.get("collection_id")
                         or item.get("is_collection"))
    media = str(item.get("media_type") or item.get("media") or "").lower()
    kind = _media_kind(media, is_collection=is_collection)
    # B24 (Phase 4): the listing enrichment attaches a per-kind media_counts
    # dict (computed from the live child files — collection items OR the
    # A.4 multi-file expansion) so the badge renders the truthful
    # "3 videos · 2 photos" instead of "1 video".
    # V25 (§2/§6): COLLECTION CARDS RENDER THE SAME TRUTHFUL SUMMARY. The
    # B24 special-case discarded media_counts whenever is_collection=True
    # (collections_page stamps that flag on every item), collapsing every
    # collection card to the generic "N files" badge even though the
    # enrichment had already computed the real per-kind counts. The badge
    # now renders "3 videos · 2 photos" for a mixed collection and
    # "5 videos" for a single-kind one; genuine single-file payloads keep
    # the legacy wording exactly (no mc attached -> the legacy branch).
    mc = item.get("media_counts")
    count_label = _count_label(count, media if not is_collection else "",
                               media_counts=mc)
    opaque = str(item.get("opaque_id") or item.get("payload") or "")
    href = site_url(f"site/payload/{quote_plus(opaque)}")
    if carry_query:
        href += "?" + str(carry_query)
    title = str(item.get("eff_title") or item.get("title")
                or "Untitled payload")
    img = ""
    if thumb_url:
        # B.5.2: the FIRST four cards of a page are high-priority/eager;
        # every later one stays lazy + async.
        prio = 'loading="lazy" decoding="async"'
        if int(index) < 4 and not item.get("__no_priority"):
            prio = 'fetchpriority="high" loading="eager"'
        img = ('<img class="thumbimg" src="' + esc(thumb_url)
               + '" alt="" ' + prio + ' '
               'onerror="this.remove()">')
    # B.2.7: access-aware lock badges — a FORCE_JOIN-policy payload card
    # shows the Join-to-watch lock; an age-restricted-category listing
    # shows 18+. Both STILL link to the payload page (the gate renders in
    # context, server-side — the card never decides access).
    lock = ""
    if str(item.get("access_policy") or "").upper() == "FORCE_JOIN":
        lock = ('<span class="lockbadge">' + _icon("lock")
                + "Join to watch</span>")
    elif item.get("age_restricted"):
        lock = '<span class="lockbadge">' + _icon("lock") + "18+</span>"
    return (
        f'<div class="card" style="--i:{max(0, int(index))}"'
        f' data-listing="{esc(opaque)}"'
        + (f' data-file-pk="{int(item.get("file_pk") or 0)}"'
           if item.get("file_pk") else "")
        + f' data-title="{esc(title)}">'
        '<a class="cardlink" href="' + esc(href) + '">'
        '<div class="thumb">' + lock + _art_svg(title, kind) + img
        + '<span class="badge glass">' + _badge_icon(kind)
        + esc(count_label) + "</span>"
        + (_type_pill(kind)
           if _show_type_pill(is_collection=is_collection, media=media,
                              count=count) else "")
        + "</div>"
        '<div class="cardbody"><div class="cardtitle">' + esc(title)
        + "</div>"
        + ('<div class="carddesc">' + esc(desc) + "</div>" if desc else "")
        + _chips(tags)
        + "</div></a></div>")


_SORT_LABELS = [("curated", "Curated"), ("newest", "Newest"),
                ("title", "A–Z")]


def _sortbar(active: str, *, query: str = "",
            base_path: str = "site") -> str:
    """The feed/search sort control (segmented pills). Links keep the
    search query but reset to page 1 (standard sort UX). B10-W2:
    ``base_path`` lets a CATEGORY page (site/c/{slug}) keep its sort
    links inside the category instead of jumping to the generic feed."""
    if active not in dict(_SORT_LABELS):
        active = "curated"
    out = ['<div class="sortbar" role="group" aria-label="Sort payloads">']
    for key, label in _SORT_LABELS:
        href = site_url("site/search" if query else base_path) \
            + "?sort=" + key
        if query:
            href += "&q=" + quote_plus(query)
        cur = " cur" if key == active else ""
        aria = ' aria-current="true"' if key == active else ""
        out.append(f'<a class="sortopt{cur}"{aria} href="{esc(href)}">'
                   + esc(label) + "</a>")
    out.append("</div>")
    return "".join(out)


def feed_page(items: List[Dict[str, Any]], *, page: int, total: int,
              page_size: int, sort: str = "curated",
              thumb_urls: Optional[Dict[str, str]] = None,
              ad_slots: Optional[dict] = None,
              cat_slug: str = "", cat_name: str = "",
              cat_restricted: bool = False,
              user: Optional[dict] = None,
              categories: Optional[list] = None,
              age_ok: bool = False) -> str:
    """The Payload feed with DB-side pagination (spec §8) + statistics,
    sort control, staggered card animation and AD SLOTS (spec §37).

    B10-W2 (spec §18): ``cat_slug``/``cat_name``/``cat_restricted``
    render the CATEGORY view (the /site/c/{slug} page — and the
    /site?cat= flow through the SAME shared renderer): the head shows
    the category's own name (+ an honest 18+ pill when restricted and
    confirmed — the caller ONLY reaches here after the age gate), and
    the pagination/sort links stay INSIDE the category route. All three
    default to the plain generic-feed rendering (every existing call
    site unchanged).

    ``ad_slots`` (every key optional; an EMPTY or missing slot renders
    NOTHING AT ALL — complete collapse, never an empty box):
      * ``{"top": html}``       — full-width banner ABOVE the feed head;
      * ``{"between": [html]}`` — native ad cards, one after every 6th
        card (any leftover slots flush in after the final card so caller
        content is never silently dropped);
      * ``{"footer": html}``    — a footer slot ABOVE the pagination.
    The ad html arrives PRE-RENDERED by the caller and is placed
    verbatim inside the ``<aside class="adslot …">`` wrappers.
    """
    carry = ("sort=" + quote_plus(sort) if sort and sort != "curated"
             else "")
    tu = thumb_urls or {}
    ads = ad_slots if isinstance(ad_slots, dict) else {}
    between = [b for b in (ads.get("between") or []) if b]

    def _native(b) -> str:
        return '<aside class="adslot ad-native">' + str(b) + "</aside>"

    grid_parts: List[str] = []
    placed = 0
    for n, i in enumerate(items, start=1):
        grid_parts.append(card(i, index=n - 1, carry_query=carry,
                               thumb_url=tu.get(
                                   str(i.get("opaque_id") or ""), "")))
        if n % 6 == 0 and placed < len(between):
            grid_parts.append(_native(between[placed]))
            placed += 1
    while placed < len(between):
        grid_parts.append(_native(between[placed]))
        placed += 1
    if items:
        cards = "".join(grid_parts)
    else:
        cards = ('<div class="empty"><span class="eglyph">\U0001F4ED</span>'
                 "<b>No payloads published yet</b>"
                 "Publish a payload from the admin Website Control to see "
                 "it here.</div>")
    top_ad = ('<aside class="adslot ad-top">' + str(ads["top"]) + "</aside>"
              if ads.get("top") else "")
    foot_ad = ('<aside class="adslot ad-foot">' + str(ads["footer"])
               + "</aside>" if ads.get("footer") else "")
    # B10-W2 (spec §18): a CATEGORY page paginates/sorts INSIDE its own
    # route (site/c/{slug}) instead of falling back to the generic feed.
    cat_base = ("site/c/" + quote_plus(cat_slug)) if cat_slug else "site"
    pager = _pager(page, total, page_size, base_path=cat_base, sort=sort)
    stats = (f"<b>{total}</b> payload" + ("s" if total != 1 else "")
             + (" in " + esc(cat_name) if cat_slug and cat_name else "")
             + " published") if total else (
        "Nothing published yet" if not cat_slug
        else "No payloads in this category yet")
    if cat_slug:
        # The 18+ pill appears ONLY on the confirmed rendering (the age
        # gate runs server-side BEFORE this page is ever produced).
        r18_pill = ('<span class="typepill glass r18pill" title="Age-'
                    'restricted category (18+ confirmed)">\U0001F51E 18+'
                    "</span>") if cat_restricted else ""
        head = (
            '<div class="feedhead"><div><div class="kicker">Category'
            '</div><h1 class="feedtitle">'
            + esc(cat_name or cat_slug) + "</h1>"
            f'<div class="feedmeta">{stats}</div>'
            + r18_pill + "</div>"
            + _sortbar(sort, base_path=cat_base) + "</div>")
        title = cat_name or cat_slug or "Category"
    else:
        head = (
            '<div class="feedhead"><div><div class="kicker">The Library'
            '</div><h1 class="feedtitle">Payloads</h1>'
            f'<div class="feedmeta">{stats}</div></div>'
            + _sortbar(sort) + "</div>")
        title = "Payloads"
    body = (top_ad + head + '<div class="grid">' + cards + "</div>"
            + foot_ad + pager)
    return _page(title, body, show_search=True, user=user,
                 categories=categories, age_ok=age_ok,
                 active_slug=cat_slug,
                 description=("Browse the " + esc(cat_name or cat_slug)
                              + " category." if cat_slug else
                              "Browse published payload packages — videos, "
                              "music, photos and documents."))


def search_page(items: List[Dict[str, Any]], *, query: str, page: int,
                total: int, page_size: int, sort: str = "curated",
                thumb_urls: Optional[Dict[str, str]] = None,
                user: Optional[dict] = None,
                categories: Optional[list] = None,
                age_ok: bool = False) -> str:
    """Search results — normalized DB-side search with preserved query
    state (spec §9), result statistics and the sort control."""
    tu = thumb_urls or {}
    if not query:
        cards = ('<div class="empty"><span class="eglyph">\U0001F50D</span>'
                 "<b>Search payloads</b>"
                 "Type a title, tag or description word above.</div>")
    elif not items:
        cards = ('<div class="empty"><span class="eglyph">\U0001F4ED</span>'
                 "<b>No payloads match</b>"
                 "Nothing published matches \u201C" + esc(query)
                 + "\u201D — try another word or clear the search.</div>")
    else:
        # spec §10: carry the search state on every card so the detail
        # page's back link returns to THIS results page.
        carry = ("q=" + quote_plus(query) + "&p=" + str(page))
        if sort and sort != "curated":
            carry += "&sort=" + quote_plus(sort)
        cards = "".join(
            card(i, index=n, carry_query=carry,
                 thumb_url=tu.get(str(i.get("opaque_id") or ""), ""))
            for n, i in enumerate(items))
    pager = _pager(page, total, page_size, base_path="site/search",
                   query=query, sort=sort)
    stats = (f"<b>{total}</b> result" + ("s" if total != 1 else "")
             + ' for \u201C' + esc(query) + "\u201D") if query else ""
    head = (
        '<div class="feedhead"><div><div class="kicker">Results</div>'
        '<h1 class="feedtitle">Search</h1>'
        f'<div class="feedmeta">{stats}</div></div>'
        + (_sortbar(sort, query=query) if query else "") + "</div>")
    body = head + '<div class="grid">' + cards + "</div>" + pager
    return _page("Search", body, show_search=True, search_value=query,
                 user=user, categories=categories, age_ok=age_ok,
                 description=f"Search results for payloads matching "
                             f"{query[:80]}.", noindex=True)


def _pager(page: int, total: int, page_size: int, *, base_path: str,
           query: str = "", sort: str = "curated") -> str:
    """Numbered windowed pagination. Keeps the compact 'N / M' position
    indicator (visible on every size — mobile shows just prev/next +
    position) and adds touch-friendly numbered pills on wider screens."""
    pages = max(1, (total + page_size - 1) // page_size) if page_size else 1
    if pages <= 1:
        return ""
    page = max(1, min(pages, page))
    extra = ""
    if query:
        extra += "&q=" + quote_plus(query)
    if sort and sort != "curated":
        extra += "&sort=" + quote_plus(sort)
    prev_link = (f'<a class="pgbtn" href="'
                 + esc(f"{site_url(base_path)}?p={page-1}{extra}")
                 + '" aria-label="Previous page">'
                 + _icon("chevron-left") + "Prev</a>"
                 if page > 1 else
                 '<span class="pgbtn off" aria-hidden="true">'
                 + _icon("chevron-left") + "Prev</span>")
    next_link = (f'<a class="pgbtn" href="'
                 + esc(f"{site_url(base_path)}?p={page+1}{extra}")
                 + '" aria-label="Next page">Next'
                 + _icon("arrow-right") + "</a>"
                 if page < pages else
                 '<span class="pgbtn off" aria-hidden="true">Next'
                 + _icon("arrow-right") + "</span>")
    # numbered window: first/last + a bounded run around the current page
    want = {1, pages}
    lo = max(1, page - 2)
    hi = min(pages, page + 2)
    want.update(range(lo, hi + 1))
    nums = []
    prev_n = 0
    for n in sorted(want):
        if prev_n and n - prev_n > 1:
            nums.append('<span class="pgell" aria-hidden="true">…</span>')
        if n == page:
            nums.append(f'<span class="pgnum cur" aria-current="page">'
                        f"{n}</span>")
        else:
            nums.append(f'<a class="pgnum" href="'
                        + esc(f"{site_url(base_path)}?p={n}{extra}")
                        + f'" aria-label="Page {n}">{n}</a>')
        prev_n = n
    return ('<nav class="pager" aria-label="Pagination">' + prev_link
            + f'<span class="pagenums">' + "".join(nums) + "</span>"
            + f'<span class="pagerpos">{page} / {pages}</span>'
            + next_link + "</nav>")


# ---------------------------------------------------------------- detail
def _nav_chain_script(nav_chain: Optional[list]) -> str:
    """V26 FINAL (Parts 6+7) — render ``window.__NAV_CHAIN__`` (the
    canonical navigation breadcrumb array, HOME-first order) as a head
    script. The SPA router seeds the canonical hierarchy BEHIND a cold
    deep entry so every in-app Back control walks INSIDE /site instead
    of exiting the website. Empty/None renders NOTHING."""
    if not nav_chain:
        return ""
    try:
        return ('<script>window.__NAV_CHAIN__='
                + json.dumps([str(u) for u in nav_chain]) + ';</script>')
    except Exception:  # noqa: BLE001 — breadcrumb is best-effort
        return ""


def detail_page(detail: Dict[str, Any], *, sidebar: str = "",
               video_hrefs: Dict[int, str],
                back_href: str, back_label: str = "All payloads",
                thumb_url: str = "", files_extra: int = 0,
                ad_slots: Optional[dict] = None,
                user: Optional[dict] = None,
                categories: Optional[list] = None,
                age_ok: bool = False,
                file_thumb_urls: Optional[Dict[int, str]] = None,
                nav_chain: Optional[list] = None) -> str:
    """Payload DETAIL: artwork (real thumbnail bytes when available),
    title, description, clickable tags, media stats (count / parts /
    total size) and the ORDERED file list (Part 1..N) — the user selects
    the desired file from INSIDE the Payload (spec §1/§10).

    PHASE 5: ``files_extra`` is the number of parts beyond the rendered
    cap (MAX_DETAIL_FILES) — the count pill stays TRUE (rendered + extra)
    and an honest "+N more parts" note closes the list.

    V25 (§4): ``file_thumb_urls`` maps file_pk -> short-lived Media
    Gateway thumbnail URL so every INNER media row renders its REAL
    per-file artwork (video poster / photo preview) where available —
    bounded thumbnail bytes, never full-resolution originals. Rows carry
    kind-correct controls: a play glyph for video/animation/audio, a view
    glyph for photos, an open/download glyph for documents — a photo row
    NEVER shows a video play button. Canonical media order is preserved
    (the caller's files list) with one row per stored media record.

    ``ad_slots`` (spec §37, complete-collapse when empty/missing):
    ``{"top": html}`` above the hero, ``{"detail": html}`` below it.
    The html arrives pre-rendered from the caller and is placed verbatim.
    """
    listing = detail.get("listing") or {}
    files = detail.get("files") or []
    title = detail.get("eff_title") or detail.get("title") \
        or "Untitled payload"
    tags = [t for t in str(listing.get("tags") or "").split() if t][:12]
    desc = str(listing.get("description") or "")
    count = len(files) + int(files_extra or 0)
    is_collection = bool(listing.get("collection_id"))
    media = str((files[0].get("media_type") if files else "") or "").lower()
    kind = _media_kind(media if not is_collection else "",
                       is_collection=is_collection)
    # B24 (Phase 4): the detail resolver computes media_counts over the
    # FULL pre-cap file list (files_all) so the badge stays truthful even
    # when MAX_DETAIL_FILES caps the rendered rows. Fallback: aggregate
    # from the visible files (defensive — never collapses to files[0]).
    # V25 (§2/§4): the is_collection special-case is GONE — the collection
    # DETAIL badge renders the same truthful "3 videos · 2 photos"
    # summary (the B24 branch discarded it, collapsing to "N files").
    mc = detail.get("media_counts") or aggregate_media_counts(files)
    count_label = _count_label(count, media if not is_collection else "",
                               media_counts=mc)
    multi = count > 1
    total_size = sum(int(f.get("file_size") or 0) for f in files
                     if f.get("file_size"))
    size_txt = _fmt_size(total_size) if total_size else ""
    ads = ad_slots if isinstance(ad_slots, dict) else {}
    top_ad = ('<aside class="adslot ad-top">' + str(ads["top"]) + "</aside>"
              if ads.get("top") else "")
    detail_ad = ('<aside class="adslot ad-detail">' + str(ads["detail"])
                 + "</aside>" if ads.get("detail") else "")
    img = ""
    if thumb_url:
        img = ('<img class="thumbimg" src="' + esc(thumb_url)
               + '" alt="" loading="lazy" decoding="async" '
               'onerror="this.remove()">')
    head = (
        '<div class="detailhead"><div class="thumb">'
        + _art_svg(title, kind) + img
        + '<span class="badge glass">' + _badge_icon(kind)
        + esc(count_label) + "</span>"
        + (_type_pill(kind)
           if _show_type_pill(is_collection=is_collection, media=media,
                              count=count) else "")
        + "</div>"
        '<div class="detailbody">'
        '<div class="kicker">Payload</div>'
        '<h1 class="detailtitle">' + esc(title) + "</h1>"
        + ('<p class="detaildesc">' + esc(desc) + "</p>" if desc else "")
        + _chips(tags)
        + '<div class="metarow">'
        + ('<span class="metapill">' + _icon("layers") + "<b>"
           + esc(count_label) + "</b></span>")
        + (f'<span class="metapill">{_icon("collection")}Part 1\u2013'
           f"{count}</span>" if multi else "")
        + (f'<span class="metapill">{_icon("size")}\u2248 {esc(size_txt)}'
           "</span>" if size_txt else "")
        + "</div></div></div>")
    rows = []
    _ftu = file_thumb_urls if isinstance(file_thumb_urls, dict) else {}
    # V25 (§4): the trailing control matches the media KIND — video /
    # animation / audio rows get the play glyph, photo rows the view
    # glyph, document rows the open/download glyph. (A photo row never
    # shows a video play control; documents never get playback controls.)
    _ROW_CTL_ICON = {"video": "play", "animation": "play", "audio": "play",
                     "photo": "eye"}
    _ROW_CTL_ARIA = {"video": "Play video", "animation": "Play animation",
                     "audio": "Play audio", "photo": "View photo",
                     "document": "Open document"}
    seen_pks = set()
    for idx, f in enumerate(files, start=1):
        pk = f.get("file_pk")
        # V25 (§4): no duplicate rows — a repeated file_pk (bad join,
        # duplicated collection item) renders exactly once, and the
        # skip is loud (see WEBSITE_MEDIA_INVENTORY logging in pages.py).
        if pk in seen_pks:
            continue
        if pk is not None:
            seen_pks.add(pk)
        href = video_hrefs.get(pk) or "#"
        # V26.2 (bot-41 §9-§11): a PACKAGE child's user-facing label is its
        # subordinate display_label ("Video 1", …) — the raw original
        # Telegram filename is INTERNAL metadata only and must not become
        # the entry identity. Single-payload rows keep the legacy
        # file_name label (their own canonical name).
        name = str(f.get("display_label") or "").strip() \
            or str(f.get("file_name") or "").strip() \
            or ("Part " + str(idx) if multi else "File")
        fkind = _media_kind(str(f.get("media_type") or "").lower())
        meta_bits = [_TYPE_LABELS.get(fkind, "File")]
        sz = _fmt_size(f.get("file_size"))
        if sz:
            meta_bits.append(sz)
        if f.get("width") and f.get("height"):
            meta_bits.append(f"{f['width']}\u00D7{f['height']}")
        # V25 (§4): the leading tile prefers the REAL per-file thumbnail
        # (bounded Media Gateway bytes) with an overlaid kind glyph; the
        # plain P<n> numbering tile stays the fallback for every row the
        # gateway cannot serve (never a broken image — onerror hides it
        # and the kind glyph alone identifies the row).
        turl = str(_ftu.get(pk) or "")
        if turl:
            # V25 (§4): the part IDENTITY rides WITH the artwork (the
            # P<n> overlay preserves canonical ordering cues; the kind
            # glyph marks the media type; the real thumbnail is the
            # visual representation).
            lead = ('<span class="rowthumbwrap">'
                    '<img class="rowthumb" src="' + esc(turl)
                    + '" alt="" loading="lazy" decoding="async" '
                    'onerror="this.remove()">'
                    + (('<span class="rowpart" aria-hidden="true"><b>P'
                        + str(idx) + "</b></span>") if multi else "")
                    + '<span class="rowthumbkind" aria-hidden="true">'
                    + _icon(_KIND_ICONS.get(fkind, "file"))
                    + "</span></span>")
        else:
            lead = ('<span class="partnum">'
                    + ("<b>P" + str(idx) + "</b>" if multi else "\u25B6")
                    + "</span>")
        ctl_icon = _ROW_CTL_ICON.get(fkind, "download")
        ctl_aria = _ROW_CTL_ARIA.get(fkind, "Open file")
        rows.append(
            f'<a class="filerow" style="--i:{idx-1}" data-kind="{esc(fkind)}"'
            f' href="' + esc(href)
            + '" aria-label="' + esc(ctl_aria + ": " + name) + '">'
            + lead
            + '<span class="fileinfo"><span class="filename">' + esc(name)
            + "</span>"
            '<span class="filemeta">' + _icon(
                _KIND_ICONS.get(fkind, "file"))
            + "<b>" + esc(meta_bits[0]) + "</b>"
            + (esc(" \u2022 " + " \u2022 ".join(meta_bits[1:]))
               if len(meta_bits) > 1 else "")
            + "</span></span>"
            '<span class="playbtn" aria-hidden="true">' + _icon(ctl_icon)
            + "</span></a>")
    files_html = ('<div class="filelist">' + "".join(rows) + "</div>" if rows
                  else '<div class="empty"><span class="eglyph">\u26A0'
                       "\uFE0F</span><b>Files unavailable</b>"
                       "The files of this payload are currently unavailable."
                       "</div>")
    if files_extra > 0:
        # PHASE 5 honest cap note: the rendered list is bounded; the parts
        # beyond it remain fully available through Telegram delivery.
        files_html += (
            f'<div class="moreparts">{_icon("layers")}'
            f"+ {int(files_extra)} more part"
            + ("s" if files_extra != 1 else "")
            + " not shown here — open the payload in Telegram to reach "
              "them.</div>")
    label = (f'<div class="fileslabel">{count} part'
             + ("s" if count != 1 else "")
             + " \u2022 select below</div>") if multi else ""
    back = ('<a class="backlink" href="' + esc(back_href) + '">'
            + _icon("chevron-left") + esc(back_label) + "</a>")
    # BOT-11 (spec §6-§18/§15): the SAME Get File control as the player
    # page — the shared helper renders the button + script given the
    # listing id (payload-level: file_pk=0; each click is a FRESH random
    # eligible REGISTERED-BOT selection through /site/api/get-file, no
    # pre-mint at render time). No payload_link href fallback here (the
    # detail page never built one) — the API response is the authority.
    # BOT-13 §46.2: show_get_file=0 renders NO button AND NO script —
    # not a CSS hide (the functional control is absent from the DOM and
    # the server endpoint refuses direct attempts equally).
    _gf_canonical = detail.get("canonical") or {}
    _show_get_file = bool(_gf_canonical.get("show_get_file", True))
    listing_opaque = str(listing.get("opaque_id") or "")
    get_file_control = (
        get_file_button_html("")
        + (get_file_script_html(listing_opaque, 0)
           if listing_opaque else "")) if _show_get_file else ""
    body = ('<div class="narrow">' + back + top_ad + head + detail_ad
            + label + files_html + get_file_control + "</div>")
    og = ('<meta property="og:title" content="' + esc(title)
          + ' — EndieFans">'
          '<meta property="og:description" content="'
          + esc(desc[:180] or count_label) + '">'
          '<meta property="og:type" content="website">')
    # PROMPT B (bot-25): B.2.1 — the DETAIL page can also carry the
    # media sidebar (the caller passes it; dormant by default).
    if sidebar:
        body = ('<div class="mediagrid"><div>' + body + '</div>'
                '<aside class="msidebar" aria-label="More to watch">'
                + sidebar + "</aside></div>")
    return _page(title, body, show_search=True, user=user,
                 categories=categories, age_ok=age_ok,
                 description=(desc[:160] or f"{title} — {count_label} "
                             "payload package."),
                 head_extra=(og + _nav_chain_script(nav_chain)))


# ------------------------------------------------- BOT-11 §6-§18 Get File
# The Website Get File control: an <a> BUTTON whose click calls
# POST /site/api/get-file (server-side RANDOM eligible REGISTERED-BOT
# selection + durable targeted Global Payload Link mint — spec §17: the
# bot list NEVER reaches the page, no internal bot ids are rendered) and
# redirects to the returned t.me URL. The server-built legacy main-bot
# payload_link stays as the href FALLBACK (progressive enhancement: with
# JS disabled the anchor still navigates; on signing_unavailable /
# network failure the script opens it). The button label carries NO bot
# identity (§17) — "📥 Get File" + a "Delivery via Telegram" subtitle.
GETFILE_LABEL = "\U0001F4E5 Get File"
GETFILE_SUBTITLE = "Delivery via Telegram"
GETFILE_NO_BOT_NOTICE = ("\u26A0\uFE0F No delivery bot is currently "
                         "available. Please try again later.")


def get_file_button_html(fallback_href: str = "", *,
                         primary: bool = True) -> str:
    """The Get File BUTTON markup (BOT-11 spec §6-§18/§17).

    ``primary=True`` renders the script-bound anchor (id="getfile" +
    the status span companion); the non-primary copies (the
    not-streamable verdict block) share the class only — one id per
    page, the script binds to the primary. ``fallback_href`` is the
    legacy server-built main-bot deep link (progressive enhancement;
    empty = the API result is the only path — never a fabricated href)."""
    href_attr = (f' href="{esc(str(fallback_href))}"'
                 if str(fallback_href or "") else "")
    id_attr = ' id="getfile"' if primary else ""
    status = ('<span class="getfilestatus" id="getfilestatus" '
              'aria-live="polite" hidden></span>') if primary else ""
    return (
        '<div class="getfilebar">'
        f'<a class="tgbtn getfile"{id_attr}{href_attr} rel="noopener" '
        f'role="button">{GETFILE_LABEL}</a>'
        f'<span class="getfilesub">{GETFILE_SUBTITLE}</span>'
        "</div>" + status)


def get_file_script_html(listing_opaque: str, file_pk: int = 0) -> str:
    """The inline Get File script (BOT-11 spec §6-§18/§15/§17): click →
    POST /site/api/get-file with {listing, file_pk} (+ initData when the
    Mini App SDK is present) → redirect to the returned t.me URL. Honest
    client states, NEVER an alert(): no_delivery_bot → the inline
    truthful notice; 401 → the site login flow (the payload page gate);
    signing_unavailable / network failure → the existing fallback href
    when present, else the honest notice. NO bot list, NO ids in the
    markup — only the listing id + file pk the page already carries."""
    api = json.dumps(site_url("site/api/get-file"))
    login = json.dumps(site_url(f"site/payload/{listing_opaque}"))
    listing_js = _esc_js_attr(str(listing_opaque or ""))
    try:
        pk_js = int(file_pk or 0)
    except (TypeError, ValueError):
        pk_js = 0
    return (
        "<script>\n"
        "(function(){\n"
        "  var btn = document.getElementById(\"getfile\");\n"
        "  if(!btn || !btn.addEventListener){ return; }\n"
        "  var st = document.getElementById(\"getfilestatus\");\n"
        f"  var API = {api};\n"
        f"  var LOGIN = {login};\n"
        f"  var LISTING = \"{listing_js}\";\n"
        f"  var FILE_PK = {pk_js};\n"
        "  function tel(kind, reason){\n"
        "    try{ if(window.__siteTel){\n"
        "      var f = {action: \"get_file\"};\n"
        "      if(reason){ f.reason = String(reason).slice(0, 64); }\n"
        "      window.__siteTel(\"SITE_ACTION_\" + kind, f);\n"
        "    } }catch(e){}\n"
        "  }\n"
        "  function honestNotice(){\n"
        "    if(st){ st.hidden = false; st.textContent = \""
        + GETFILE_NO_BOT_NOTICE.replace("\u26A0\uFE0F", "\\u26A0\\uFE0F")
        + "\"; }\n"
        "  }\n"
        "  function openFallback(){\n"
        "    var href = btn.getAttribute(\"href\") || \"\";\n"
        "    if(href){ window.location.href = href; return; }\n"
        "    honestNotice();\n"
        "  }\n"
        "  btn.addEventListener(\"click\", function(ev){\n"
        "    ev.preventDefault();\n"
        "    tel(\"START\");\n"
        "    var payload = {listing: LISTING, file_pk: FILE_PK};\n"
        "    try{\n"
        "      var tg = window.Telegram && window.Telegram.WebApp;\n"
        "      if(tg && tg.initData){ payload.init_data = tg.initData; }\n"
        "    }catch(e){}\n"
        "    fetch(API, {method: \"POST\",\n"
        "      headers: {\"Content-Type\": \"application/json\"},\n"
        "      body: JSON.stringify(payload)})\n"
        "    .then(function(r){\n"
        "      if(r.status === 401){\n"
        "        tel(\"FAILED\", \"unauthorized\");\n"
        "        window.location.href = LOGIN; return null;\n"
        "      }\n"
        "      return r.json();\n"
        "    })\n"
        "    .then(function(j){\n"
        "      if(!j){ return; }\n"
        "      if(j.ok && j.url){\n"
        "        tel(\"SUCCESS\");\n"
        "        btn.textContent = \"Opening Telegram\\u2026\";\n"
        "        window.location.href = String(j.url);\n"
        "        return;\n"
        "      }\n"
        "      if(String(j.error || \"\") === \"signing_unavailable\"){\n"
        "        tel(\"FAILED\", \"signing_unavailable\");\n"
        "        openFallback(); return;\n"
        "      }\n"
        "      tel(\"FAILED\", String(j.error || \"no_delivery_bot\")\n"
        "        .slice(0, 64));\n"
        "      honestNotice();\n"
        "    })\n"
        "    .catch(function(){\n"
        "      tel(\"FAILED\", \"network_error\");\n"
        "      openFallback();\n"
        "    });\n"
        "  });\n"
        "})();\n"
        "</script>")


# ---------------------------------------------------------------- video page
# --------------------------------------- B18-FINAL media engagement bar
def engagement_bar_html(media_stats: Optional[Dict[str, int]] = None,
                        user_reaction: Optional[str] = None,
                        is_video: bool = True,
                        video_ref: str = "") -> str:
    """The per-file engagement bar below the player: views (VIDEO files
    only) + the caller's like/dislike. Server-rendered initial counts +
    the authenticated caller's own reaction state; the companion script
    updates counts in place from the engagement APIs (never a page
    reload). One bar per FILE — reacting to Part 1 never touches Part 2.
    No Telegram user id or any sensitive identifier is rendered."""
    stats = media_stats if isinstance(media_stats, dict) else {}
    views = int(stats.get("views") or 0)
    likes = int(stats.get("likes") or 0)
    dislikes = int(stats.get("dislikes") or 0)
    reaction = str(user_reaction or "").lower()
    like_on = reaction == "like"
    dislike_on = reaction == "dislike"
    views_html = (
        '<span class="engviews">' + _icon("eye")
        + '<b id="engviews">' + str(views) + "</b>"
        + '<span class="englabel">views</span></span>'
        if is_video else
        '<span class="engviews engviews-note">' + _icon("eye")
        + '<span class="englabel">views count for videos</span></span>')
    return (
        '<div id="engbar" class="engbar" data-ref="'
        + esc(video_ref) + '" data-video="' + ("1" if is_video else "0")
        + '">'
        + views_html
        + '<span class="engspacer" aria-hidden="true"></span>'
        + '<button id="englike" class="engbtn" type="button"'
        + (' aria-pressed="true" data-on="1"' if like_on
           else ' aria-pressed="false" data-on="0"')
        + ' aria-label="Like this media">'
        + _icon("thumbs-up")
        + '<b id="englikes">' + str(likes) + "</b>"
        + '<span class="englabel">Like</span></button>'
        + '<button id="engdislike" class="engbtn" type="button"'
        + (' aria-pressed="true" data-on="1"' if dislike_on
           else ' aria-pressed="false" data-on="0"')
        + ' aria-label="Dislike this media">'
        + _icon("thumbs-down")
        + '<b id="engdislikes">' + str(dislikes) + "</b>"
        + '<span class="englabel">Dislike</span></button>'
        + "</div>"
        + '<script>window.__ENG_API_VIEW__ = '
        + json.dumps(site_url("site/api/media/view"))
        + ';window.__ENG_API_REACT__ = '
        + json.dumps(site_url("site/api/media/react")) + ';</script>'
        + "<script>\n" + _ENGAGEMENT_JS + "</script>")


# The engagement client: threshold-gated view ping + reaction toggling.
# Views: VIDEO files only — the player element is polled for, and ONE ping
# fires after the meaningful-playback threshold (5s, or 25% for very short
# videos, min 1.5s); the server dedupes per viewer per window so refreshes
# never inflate counts. Reactions: click toggles like/dislike/none through
# /site/api/media/react; the server's atomic response updates the counts
# and aria state in place. Session cookie is the identity (HttpOnly).
_ENGAGEMENT_JS = """(function(){
"use strict";
var bar = document.getElementById("engbar");
if(!bar){ return; }
var API_VIEW = window.__ENG_API_VIEW__;
var API_REACT = window.__ENG_API_REACT__;
var REF = bar.getAttribute("data-ref") || "";
var IS_VIDEO = bar.getAttribute("data-video") === "1";
var elViews = document.getElementById("engviews");
var elLikes = document.getElementById("englikes");
var elDislikes = document.getElementById("engdislikes");
var btnLike = document.getElementById("englike");
var btnDislike = document.getElementById("engdislike");
function fmt(n){
  n = Number(n) || 0;
  return (n >= 1000) ? ((n / 1000).toFixed(1).replace(/\\.0$/, "")) + "K" : String(n);
}
function paint(likes, dislikes, reaction){
  if(elLikes){ elLikes.textContent = fmt(likes); }
  if(elDislikes){ elDislikes.textContent = fmt(dislikes); }
  if(btnLike){
    btnLike.setAttribute("aria-pressed", reaction === "like" ? "true" : "false");
    btnLike.setAttribute("data-on", reaction === "like" ? "1" : "0");
  }
  if(btnDislike){
    btnDislike.setAttribute("aria-pressed", reaction === "dislike" ? "true" : "false");
    btnDislike.setAttribute("data-on", reaction === "dislike" ? "1" : "0");
  }
}
function post(url, body){
  return fetch(url, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(body)
  }).then(function(r){ return r.json(); });
}
function react(kind){
  // SERVER-AUTHORITATIVE toggle: the client reports WHICH button was
  // tapped; the server decides set-vs-remove from the caller's OWN
  // stored reaction (a repeat of the active one removes it).
  post(API_REACT, {video_ref: REF, reaction: kind}).then(function(j){
    if(j && j.ok){ paint(j.likes || 0, j.dislikes || 0, j.reaction || null); }
  }).catch(function(){ /* honest no-op */ });
}
if(btnLike){ btnLike.addEventListener("click", function(){ react("like"); }); }
if(btnDislike){ btnDislike.addEventListener("click", function(){ react("dislike"); }); }
if(IS_VIDEO){
  var fired = false;
  var tries = 0;
  var timer = setInterval(function(){
    tries += 1;
    var v = document.querySelector("#playerbox video");
    if(!v && tries < 600){ return; }
    clearInterval(timer);
    if(!v){ return; }
    v.addEventListener("timeupdate", function(){
      if(fired){ return; }
      var dur = (v.duration && isFinite(v.duration)) ? (v.duration * 1000) : 0;
      var threshold = 5000;
      if(dur > 0){ threshold = Math.min(5000, Math.max(1500, dur * 0.25)); }
      if((v.currentTime * 1000) >= threshold){
        fired = true;
        post(API_VIEW, {video_ref: REF,
                        played_ms: Math.round(v.currentTime * 1000),
                        duration_ms: Math.round(dur)}).then(function(j){
          if(j && j.ok && j.counted && elViews && typeof j.views === "number"){
            elViews.textContent = fmt(j.views);
          }
        }).catch(function(){ /* honest no-op */ });
      }
    });
  }, 250);
}
})();
"""


def video_page(detail: Dict[str, Any], part_index: int,
               video_href: str, *, video_hrefs: Optional[Dict[int, str]] = None,
               poster_url: str = "",
               current_file_pk: int = 0, files_extra: int = 0,
               payload_link: str = "",
               ad_slots: Optional[dict] = None,
               user: Optional[dict] = None,
               categories: Optional[list] = None,
               age_ok: bool = False,
               media_stats: Optional[Dict[str, int]] = None,
               user_reaction: Optional[str] = None,
               is_video: bool = True,
               sidebar: Optional[str] = "",
               related: Optional[Dict[str, Any]] = None,
               watermark_text: str = "",
               nav_chain: Optional[list] = None) -> str:
    """WEBSITE PHASE 4 — the PLAYER page (spec §20/§21/§22), restyled by
    the Phase 6 premium pass WITHOUT touching the load-bearing player
    bootstrap (verdict flow, /site/api/stream call, plresume: localStorage
    resume, parts pills, next/prev links, deny/locked/ok states).

    v35 (spec §6/§7/§16/§17):
      * ``payload_link`` — the canonical Main-Bot deep link (t.me) built
        SERVER-side. Rendered under EVERY player ("Get File in Telegram"),
        in the not-streamable state, and in EVERY failure state — the
        player is never a dead end and bot-side policy stays enforced.
      * Truthful, machine-readable media error states: the player's
        error handler PROBES the stream URL (Range 0-0) and maps the
        server's JSON error code to an honest state + actions
        (Retry Stream / Get File in Telegram) instead of the old
        one-size "Stream ended or expired" lie.

    Truthfulness (spec §22): video/* renders <video>, audio/* <audio>,
    image/* <img>; anything else renders the HONEST "not streamable in
    the web player" state — never a blind video/mp4 guess.

    Resume (spec §21): client-side localStorage scoped STRICTLY to
    user + payload + media (key plresume:<uid>:<listing>:<file_pk>).

    Next/previous (spec §20): pills below the player navigate ONLY within
    THIS payload's canonical ordered file list — never unrelated payloads.

    PRE-ROLL AD STAGE (spec §37): a hidden #adstage overlay ships INSIDE
    the player box (Advertisement label, #adcount countdown, #adbody
    slot) plus ``window.__adStage`` placeholders — the real state machine
    is injected separately by the caller through ``head_extra``
    (``ad_slots={"preroll_head": html}`` places that script verbatim
    into <head>); an empty/missing slot renders NOTHING. V26 Phase 5:
    there is NO Skip control anywhere in the player — the pre-roll ad
    always plays to its completion (or the honest failure fallback);
    the ad-skip arming, the #adskip button, its CSS and its click
    action were REMOVED (not CSS-hidden).
    """
    title = detail.get("eff_title") or detail.get("title") or "Payload"
    listing = detail.get("listing") or {}
    files = detail.get("files") or []
    listing_opaque = str(listing.get("opaque_id") or "")
    part_label = f"Part {part_index}" if part_index else "Selected file"
    back = site_url(f"site/payload/{listing_opaque}")
    # Ordered parts navigation — within THIS payload only (spec §20).
    parts_pills = []
    if video_hrefs and len(files) > 1:
        pills = ['<div class="partsnav"><span class="plabel">Parts</span>']
        for idx, f in enumerate(files, start=1):
            pk = int(f.get("file_pk") or 0)
            href = (video_hrefs or {}).get(pk)
            if not href:
                continue
            if part_index and idx == part_index:
                pills.append(f'<a class="partpill cur" aria-current="true" '
                             f'href="#">Part {idx}</a>')
            else:
                pills.append('<a class="partpill" href="' + esc(href)
                             + f'">Part {idx}</a>')
        pills.append("</div>")
        parts_pills = pills
    if len(files) > 1 and part_index:
        prev_idx, next_idx = part_index - 1, part_index + 1
        nav = []
        if prev_idx >= 1:
            prev_href = (video_hrefs or {}).get(
                int(files[prev_idx - 1].get("file_pk") or 0) or -1)
            if prev_href:
                nav.append('<a class="partpill pprev" href="' + esc(prev_href)
                           + '">' + _icon("chevron-left") + "Previous part</a>")
        if next_idx <= len(files):
            next_href = (video_hrefs or {}).get(
                int(files[next_idx - 1].get("file_pk") or 0) or -1)
            if next_href:
                nav.append('<a class="partpill pnext" href="' + esc(next_href)
                           + '">Next part' + _icon("chevron-right") + "</a>")
        if nav:
            parts_pills.append('<div class="partsnav">' + "".join(nav)
                               + "</div>")
    parts_html = "".join(parts_pills)
    if files_extra > 0:
        # PHASE 5 honest cap note for the parts navigation (same rationale
        # as the detail page): pills are bounded; the parts beyond the cap
        # stay reachable through Telegram delivery and direct links.
        parts_html += (
            '<div class="partsnav"><span class="moreparts">'
            + _icon("layers")
            + f"+ {int(files_extra)} more part"
            + ("s" if files_extra != 1 else "")
            + " not shown — open the payload in Telegram to reach them."
            + "</span></div>")
    # Server-side context for the player script (safe values only):
    # the resume key scope is user + listing + CURRENT file pk, plus the
    # canonical payload deep link for the §16/§17 fallback surfaces.
    # BOT-13 §46.2: with show_get_file=0 the deep link is suppressed in
    # ctx too — the player-failure states render NO Telegram CTA.
    _gf_canonical = detail.get("canonical") or {}
    _show_get_file = bool(_gf_canonical.get("show_get_file", True))
    _pl = str(payload_link or "") if _show_get_file else ""
    # PROMPT B (bot-25): the next part (end screen / autoplay) — the
    # SAME canonical parts list the pills use, never an unrelated payload.
    _next_href = ""
    _next_title = ""
    try:
        _files = detail.get("files") or []
        for _i, _f in enumerate(_files):
            if int(_f.get("file_pk") or 0) == int(current_file_pk or 0) \
                    and _i + 1 < len(_files):
                _pk = int(_files[_i + 1].get("file_pk") or 0)
                if _pk and _pk in (video_hrefs or {}):
                    _next_href = video_hrefs[_pk]
                    # V26.2 (bot-41 §9-§11): package children present the
                    # subordinate display_label — raw original filenames
                    # are internal metadata, never the surfaced identity.
                    _next_title = str(
                        _files[_i + 1].get("display_label")
                        or _files[_i + 1].get("file_name")
                        or "Next part")
                break
    except Exception:  # noqa: BLE001 — enhancement only
        pass
    ctx = {"listing": listing_opaque,
           "file_pk": int(current_file_pk or 0),
           "payload_link": _pl}
    ctx_json = json.dumps(ctx)
    ads = ad_slots if isinstance(ad_slots, dict) else {}
    head_extra = (str(ads["preroll_head"])
                  if ads.get("preroll_head") else "")
    # V26 FINAL (Parts 6+7): the canonical navigation chain breadcrumb —
    # the SPA router seeds the site's canonical hierarchy BEHIND a cold
    # deep entry (PLAY -> PAYLOAD -> ... -> HOME) so every Back control
    # walks INSIDE the site instead of exiting it.
    head_extra = _nav_chain_script(nav_chain) + head_extra
    # v35 spec 16/17: the canonical payload deep link surfaces - under
    # every player (Get File in Telegram), in the not-streamable verdict,
    # and in every player-failure state (the JS state machine reuses it).
    # BOT-11 (spec §6-§18/§17): the anchor is now the Get File BUTTON —
    # the click calls /site/api/get-file (SERVER-side random eligible
    # REGISTERED-BOT selection + durable targeted link mint; the bot list
    # never reaches the page). The server-built legacy main-bot link
    # stays as the href FALLBACK (progressive enhancement / JS-off).
    # BOT-13 §46.2: show_get_file=0 renders NO Get File control at all
    # (primary, secondary and script) — the endpoint refuses direct
    # attempts, so the UI stays truthful.
    get_file_html = get_file_button_html(_pl) if _show_get_file else ""
    get_file_html_secondary = (get_file_button_html(_pl, primary=False)
                               if _show_get_file else "")
    get_file_script = (get_file_script_html(listing_opaque, current_file_pk)
                       if _show_get_file else "")
    body = (
        '<div class="narrow">'
        '<a class="backlink" href="' + esc(back) + '">'
        + _icon("chevron-left") + "Back to payload</a>"
        '<div class="detailhead"><div class="detailbody">'
        '<div class="kicker">Now playing</div>'
        '<h1 class="detailtitle">' + esc(part_label)
        + " \u2022 " + esc(title) + "</h1>"
        '<div id="verdict" class="verdict locked" style="margin-top:14px">'
        '<div class="vmain thinking">' + _icon("clock") +
            "<span>Checking your access\u2026</span></div>"
        '<div class="minitext">Verifying your Telegram Mini App identity.</div>'
        "</div>"
        '<div id="vactions" class="vactions" hidden></div>'
        "</div></div>"
        '<div id="playerwrap" class="playerwrap" hidden>'
        '<div class="playerbox" id="playerbox">'
        + (('<div class="pwm" aria-hidden="true">'
            + esc(watermark_text) + "</div>")
           if watermark_text else "")
        + '<div class="ploading"><div class="spin"></div>'
        "Preparing your stream\u2026</div>"
        '<div id="adstage" class="adstage" hidden>'
        '<div class="adbar"><span class="adlabel">Advertisement</span>'
        '<span class="adtimer"><span id="adcount"></span>s</span></div>'
        '<div id="adbody" class="adbody"></div>'
        "</div></div>"
        '<div class="playmeta"><span class="pfile" id="pfile"></span>'
        '<span id="psize"></span></div>'
        '<div class="resumebar" id="resumebar"></div>'
        + get_file_html +
        "</div>"
        # B18-FINAL (bot-22.log pass): the media engagement bar — per-file
        # views (VIDEO files only; a meaningful playback threshold gates
        # the count server-side and refreshes never inflate it) + the
        # caller's single like/dislike (atomic switch, counts update in
        # place without a page reload). Independent per file: reacting to
        # Part 1 never touches Part 2. No Telegram user id or any
        # sensitive identifier reaches the markup.
        + engagement_bar_html(
            media_stats, user_reaction, is_video,
            str(video_href or "").rstrip("/").rsplit("/", 1)[-1]) +
        '<div id="nostream" class="verdict locked" hidden>'
        '<div class="vmain">' + _icon("info") +
            "<span>Not streamable in the web player</span></div>"
        '<div class="minitext" id="nostreamtext">This file type cannot play '
        "in the browser. Open the payload in Telegram to receive it.</div>"
        + ('<div class="vactions">' + get_file_html_secondary + "</div>"
           if _pl else "") +
        "</div>"
        + parts_html +
        '<div class="streamnote">Streams are authorized for your account '
        "only and expire shortly — reload the page to continue watching. "
        "Part navigation stays inside this payload.</div>"
        '<div id="pctx" data-ctx="' + esc(ctx_json) + '"></div>'
        '<script>window.__UXDATA__ = ' + json.dumps({
            "listing": listing_opaque,
            "filePk": int(current_file_pk or 0),
            "title": str(title),
            "description": str((detail.get("listing") or {}).get(
                "description") or ""),
            "poster": str(poster_url or ""),
            "nextHref": (_next_href or ""),
            "nextTitle": (_next_title or ""),
            "relatedHref": str((related or {}).get("href") or ""),
            "relatedTitle": str((related or {}).get("title") or ""),
            "relatedPoster": str((related or {}).get("poster") or ""),
        }) + ';</script>'
        '<script>' + _PLAYER_UX_JS + '</script>'
        # BOT-11 (spec §6-§18): the Get File click script — ONE binding to
        # the primary #getfile button (server-side random registered-bot
        # delivery; honest states; never the bot list).
        + get_file_script +
        '<!-- GAP-CLOSURE fix: the placeholder only installs itself when\n'
        '     the REAL ad state machine (injected via head_extra, which\n'
        '     runs BEFORE this body script) is absent — the old\n'
        '     unconditional assignment clobbered the real machine, so\n'
        '     pre-roll/mid-roll ads never attached. -->\n'
        '<script>window.__adStage = window.__adStage || {show:null,hide:null};</script>\n'
        '<script>\n'
        '  var API_STREAM = ' + json_stream_src() + ';\n' +
        '  var API_FJ_VERIFY = ' + json.dumps(site_url("site/api/forcejoin/verify")) + ';\n' +
        '  var FJ_GATE_KEY = ' + json.dumps(
            "w|%s|%s" % (str(listing_opaque or ""),
                         int(current_file_pk or 0))) + ';\n' +
        '  var VIDEO_REF = ' + json_video_ref(video_href) + ';\n' +
        '  var HLS_CDN = ' + json.dumps(HLSJS_CDN_URL) + ';\n' +
        '(function(){\n'
        '  var box = document.getElementById("verdict");\n'
        '  var wrap = document.getElementById("playerwrap");\n'
        '  var pbox = document.getElementById("playerbox");\n'
        '  // V26 PLAYER_OPEN telemetry: the player page booted (the\n'
        '  // playback surface exists; the stream lifecycle starts here).\n'
        '  try{ if(window.__siteTel){ window.__siteTel("PLAYER_OPEN"); } }catch(e){}\n'
        '  var nostream = document.getElementById("nostream");\n'
        '  var adStageEl = document.getElementById("adstage");\n'
        '  function show(cls, main, sub){\n'
        '    if(!box){return;}\n'
        '    box.className = "verdict " + cls;\n'
        '    box.innerHTML = "<div class=\\"vmain\\">" + main + "</div>" +\n'
        '      (sub ? "<div class=\\"minitext\\">" + sub + "</div>" : "");\n'
        '  }\n'
        '  function safe(s){ return String(s == null ? "" : s)\n'
        '    .replace(/&/g,"&amp;").replace(/</g,"&lt;")\n'
        '    .replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }\n'
        '  function fmtSize(n){\n'
        '    if(!n || n <= 0){ return ""; }\n'
        '    var u = ["B","KB","MB","GB"], i = 0;\n'
        '    while(n >= 1024 && i < 3){ n /= 1024; i++; }\n'
        '    return (i < 2 ? Math.round(n) : n.toFixed(1)) + " " + u[i];\n'
        '  }\n'
        '  function fmtTime(t){\n'
        '    if(!isFinite(t) || t < 0){ t = 0; }\n'
        '    var s = Math.floor(t % 60), m = Math.floor(t / 60) % 60,\n'
        '        h = Math.floor(t / 3600);\n'
        '    var two = function(x){ return (x < 10 ? "0" : "") + x; };\n'
        '    return (h > 0 ? h + ":" + two(m) + ":" + two(s)\n'
        '                  : m + ":" + two(s));\n'
        '  }\n'
        '  function ctxData(){\n'
        '    var el = document.getElementById("pctx");\n'
        '    try{ return JSON.parse(el.getAttribute("data-ctx")) || {}; }\n'
        '    catch(e){ return {}; }\n'
        '  }\n'
        '  function info(m){ try{ console.info(m); }catch(e){} }\n'
        '  // BOT-16 player-wide state: the current media element, the custom\n'
        '  // control bar, the in-player Join gate and the HLS plumbing.\n'
        '  var tg = null;\n'
        '  var mediaEl = null;\n'
        '  var ctl = null;\n'
        '  var fjGateEl = null;\n'
        '  var __streamUrl = null;\n'
        '  var __hls = null;\n'
        '  var __hlsMaster = "";\n'
        '  var __hlsNative = false;\n'
        '  var __hlsNetTries = 0;\n'
        '  // BOT-43 (Section 3 - the duplicate DESTROY/CLOSE root cause):\n'
        '  // __playerTeardown fired PLAYER_DESTROY + PLAYER_CLOSE on EVERY\n'
        '  // call with no idempotency sentinel - the bot-43 production log\n'
        '  // shows FOUR pairs in 7 seconds during one navigation burst\n'
        '  // (04:52:10/12/16/17). The pair reports ONE lifecycle exactly\n'
        '  // once; mountPlayer re-arms the sentinel for the next player.\n'
        '  var __destroyReported = false;\n'
        # B17 UX POLISH: the player-control icon set (same feather-style
        # stroke system as the whole site — never a platform-dependent
        # Unicode glyph). One JSON blob, injected once.
        '  var ICONS = ' + json.dumps(_PLAYER_ICONS_JS) + ';\n'
        '  function denyOpen(){\n'
        '    show("deny", "Open in Telegram",\n'
        '      "This website is verified through your Telegram account. " +\n'
        '      "Open it from the bot to continue.");\n'
        '  }\n'
        '  // Auth lifecycle (spec 7-15): BOOT -> TELEGRAM_LOADING (bounded poll:\n'
        '  // 50ms steps up to 3000ms - the SDK <head> script tag may still be\n'
        '  // loading on a slow WebView) -> TELEGRAM_READY -> AUTHENTICATING ->\n'
        '  // READY / AUTHENTICATION_FAILED. The QA stub provides\n'
        '  // window.Telegram.WebApp synchronously, so real environments and the\n'
        '  // QA path share this one state machine.\n'
        '  var waited = 0;\n'
        '  var iv = setInterval(function(){\n'
        '    tg = window.Telegram && window.Telegram.WebApp;\n'
        '    if(tg){ clearInterval(iv); startAuth(tg); return; }\n'
        '    waited += 50;\n'
        '    if(waited >= 3000){ clearInterval(iv); startAuth(null); }\n'
        '  }, 50);\n'
        '  function startAuth(tg){\n'
        '    if(!tg){\n'
        '      info("telegram_sdk_present=false reason=sdk_unavailable");\n'
        '      denyOpen();\n'
        '      return;\n'
        '    }\n'
        '    info("telegram_sdk_present=true");\n'
        '    if(!tg.initData){\n'
        '      info("init_data_present=false reason=init_data_missing");\n'
        '      denyOpen();\n'
        '      return;\n'
        '    }\n'
        '    info("init_data_present=true");\n'
        '    try{ tg.ready(); tg.expand(); }catch(e){}\n'
        '    requestStream();\n'
        '  }\n'
        '  // ---- BOT-16: stream issuance (initial load + every Retry re-issue).\n'
        '  // The POST /site/api/stream call is ONE function so the error-state\n'
        '  // Retry button, the ad-block Retry and a successful Join-gate Verify\n'
        '  // all re-issue the SAME request and rebuild the player in place -\n'
        '  // never a window.location.reload, never a Telegram redirect.\n'
        '  // V26.2-bot42 (ROOT CAUSE B - the false "Stream link expired"):\n'
        '  // the HTTP STATUS is captured and errors classified EXPLICITLY.\n'
        '  // The old `if(!j || !j.ok) showState("AUTH_EXPIRED")` collapsed\n'
        '  // EVERY failure - including HTTP 500 engine_error and 503\n'
        '  // hls_preparing - into "Stream link expired" (bot-42: a user\n'
        '  // with a server-side 500 was told their authorization expired).\n'
        '  // Mapping: 401/explicit expiry -> AUTH_EXPIRED; wrong purpose/token\n'
        '  // -> AUTH_INVALID; 403 -> ACCESS_DENIED; 404 -> MEDIA_NOT_FOUND;\n'
        '  // 429 -> NETWORK_INTERRUPTED; 500 engine_error -> PLAYBACK_ERROR;\n'
        '  // 503 hls_preparing -> PREPARING; 503 other -> MEDIA_UPSTREAM_ERROR;\n'
        '  // network failure -> NETWORK_ERROR. A generic !j.ok NEVER maps to\n'
        '  // AUTH_EXPIRED.\n'
        '  function requestStream(){\n'
        '    // BOT-43 (Section 4 - the stale-rejoin root cause): EVERY\n'
        '    // re-issuance clears any live Force-Join gate FIRST. The old\n'
        '    // code delegated ALL gate cleanup to mountPlayer - when the\n'
        '    // re-issued stream returned a NON-mount outcome (the bot-43\n'
        '    // production 500s: PLAYER_OPEN -> POST /site/api/stream -> 500\n'
        '    // -> PLAYER_REAUTH -> 500), the stale #fjgate with its Join\n'
        '    // rows + Join buttons + disabled Verify stayed overlaid on the\n'
        '    // player even though the server had already confirmed MEMBER\n'
        '    // + FJ_COMPLETE. A FRESH force_join_required denial below\n'
        '    // re-renders the gate from the NEW response; a completed gate\n'
        '    // can never survive a re-issue.\n'
        '    clearFjGateUI();\n'
        '    show("locked", ICONS.clock + "<span>Checking your access\\u2026</span>",\n'
        '      "Verifying your Telegram Mini App identity.");\n'
        '    fetch(API_STREAM, {\n'
        '      method: "POST",\n'
        '      headers: {"Content-Type": "application/json"},\n'
        '      body: JSON.stringify({\n'
        '        init_data: (tg && tg.initData) || "",\n'
        '        video_ref: VIDEO_REF\n'
        '      })\n'
        '    }).then(function(r){\n'
        '      var status = r.status;\n'
        '      return r.json().catch(function(){ return null; })\n'
        '        .then(function(j){ handleStreamJson(j, status); });\n'
        '    }).catch(function(){\n'
        '      showState("NETWORK_ERROR");\n'
        '    });\n'
        '  }\n'
        '  function issuanceStateFromResponse(status, j){\n'
        '    var code = String((j && j.error) || "");\n'
        '    if(status === 401){\n'
        '      return (code === "wrong_purpose") ? "AUTH_INVALID" : "AUTH_EXPIRED";\n'
        '    }\n'
        '    if(status === 400){\n'
        '      return (code === "invalid_video_ref") ? "AUTH_INVALID"\n'
        '        : "PLAYBACK_ERROR";\n'
        '    }\n'
        '    if(status === 403){ return "ACCESS_DENIED"; }\n'
        '    if(status === 404){ return "MEDIA_NOT_FOUND"; }\n'
        '    if(status === 429){ return "NETWORK_INTERRUPTED"; }\n'
        '    if(status === 500){\n'
        '      // engine_error / any server-side failure - NEVER "expired".\n'
        '      return "PLAYBACK_ERROR";\n'
        '    }\n'
        '    if(status === 503){\n'
        '      if(code === "hls_preparing"){ return "PREPARING"; }\n'
        '      if(code === "too_large_for_transport"){\n'
        '        return "MEDIA_UNSUPPORTED";\n'
        '      }\n'
        '      // streaming_disabled / streaming_unavailable / unavailable /\n'
        '      // maintenance - honest upstream unavailability.\n'
        '      return "MEDIA_UPSTREAM_ERROR";\n'
        '    }\n'
        '    if(status >= 500){ return "MEDIA_UPSTREAM_ERROR"; }\n'
        '    // 200-class body with ok:false (defensive - only an EXPLICIT\n'
        '    // authorization-expiry code is AUTH_EXPIRED).\n'
        '    if(code === "rate_limited"){ return "NETWORK_INTERRUPTED"; }\n'
        '    if(code === "wrong_purpose" || code === "invalid_video_ref"){\n'
        '      return "AUTH_INVALID";\n'
        '    }\n'
        '    if(code === "unauthorized" || code === "auth_expired"){\n'
        '      return "AUTH_EXPIRED";\n'
        '    }\n'
        '    if(code === "hls_preparing"){ return "PREPARING"; }\n'
        '    return "MEDIA_UPSTREAM_ERROR";\n'
        '  }\n'
        '  function handleStreamJson(j, status){\n'
        '    // BOT-43: ANY resolved response (mount, denial, or terminal\n'
        '    // error) ends the generic preparing/re-authorizing spinner.\n'
        '    hideLoading();\n'
        '    if(!j || !j.ok){\n'
        '      showState(issuanceStateFromResponse(\n'
        '        (typeof status === "number") ? status : 0, j));\n'
        '      return;\n'
        '    }\n'
        '    if(!j.authorized){\n'
        '      var reason = String(j.reason || "");\n'
        '      if(reason === "force_join_required" &&\n'
        '         j.not_joined && j.not_joined.length){\n'
        '        // BOT-16 Work Item C.4: the in-place Join Required UI replaces\n'
        '        // the old ACCESS_DENIED text + the surface-crossing t.me button.\n'
        '        renderFjGate(j);\n'
        '        return;\n'
        '      }\n'
        '      if(reason.indexOf("points") !== -1){\n'
        '        // B23/P0-1: the Telegram payload WATCH-AD requirement no\n'
        '        // longer reaches the website player AT ALL (the server\n'
        '        // waives it for website playback — watch_ad_required can\n'
        '        // never appear in a stream/access denial again). The ONLY\n'
        '        // requirement that still renders the unlock-in-Telegram\n'
        '        // state is POINTS (a bot-side unlock). Any watch_ad-shaped\n'
        '        // reason that somehow appears (defense in depth) is\n'
        '        // re-authorized, never displayed as an ad gate.\n'
        '        showState("UNLOCK_IN_TELEGRAM",\n'
        '          safe(j.requirement || ""));\n'
        '      } else if(reason.indexOf("watch_ad") !== -1){\n'
        '        // Defense in depth (unreachable with the B23 server waiver):\n'
        '        // re-authorize instead of ever displaying a Watch-Ad gate.\n'
        '        info("unexpected_watch_ad_denial=retry_reauthorize");\n'
        '        retryStream();\n'
        '      } else {\n'
        '        showState("ACCESS_DENIED", safe(j.requirement || ""));\n'
        '      }\n'
        '      return;\n'
        '    }\n'
        '    if(!j.streamable){\n'
        '      nostream.hidden = false;\n'
        '      var nt = document.getElementById("nostreamtext");\n'
        '      if(j.unavailable_reason === "too_large_for_transport"){\n'
        '        // GAP-CLOSURE spec 11: the CONTROLLED "Local Bot API required"\n'
        '        // state - never a generic stream-ended error.\n'
        '        show("locked", ICONS.warn + "<span>Large file streaming</span>",\n'
        '          safe(j.message || "This file requires a Local Bot API " +\n'
        '          "server for streaming."));\n'
        '        var va1 = document.getElementById("vactions");\n'
        '        if(va1){\n'
        '          va1.innerHTML = tgButton();\n'
        '          va1.hidden = !va1.innerHTML;\n'
        '        }\n'
        '        return;\n'
        '      }\n'
        '      show("ok", ICONS.ok + "<span>Access granted</span>", "");\n'
        '      if(nt && (j.display_name || j.file_name)){\n'
        '        nt.textContent = safe(j.display_name || j.file_name) +\n'
        '          (j.size ? " (" + fmtSize(j.size) + ")" : "") +\n'
        '          " cannot play in the browser. Open the payload in Telegram " +\n'
        '          "to receive it.";\n'
        '      }\n'
        '      return;\n'
        '    }\n'
        '    mountPlayer(j);\n'
        '  }\n'
        '  function retryStream(){\n'
        '    info("media_action=retry_stream");\n'
        '    // V26 PLAYER_REAUTH telemetry: an explicit re-authorization\n'
        '    // (Retry button / error-state recovery) — a fresh stream token\n'
        '    // is requested for the same file.\n'
        '    try{ if(window.__siteTel){ window.__siteTel("PLAYER_REAUTH"); } }catch(e){}\n'
        '    teardownMedia();\n'
        '    wrap.hidden = false;\n'
        '    show("locked", ICONS.clock + "<span>Re-authorizing\\u2026</span>",\n'
        '      "Requesting a fresh stream for your account.");\n'
        '    showLoading("Re-authorizing\\u2026");\n'
        '    requestStream();\n'
        '  }\n'
        '  function showLoading(text){\n'
        '    if(pbox.querySelector(".ploading")){ return; }\n'
        '    var d = document.createElement("div");\n'
        '    d.className = "ploading";\n'
        '    d.innerHTML = "<div class=\\"spin\\"></div>" +\n'
        '      safe(text || "Preparing your stream\\u2026");\n'
        '    pbox.appendChild(d);\n'
        '  }\n'
        '  function hideLoading(){\n'
        '    // BOT-43: any resolved stream response (mount OR terminal\n'
        '    // error state) ends the generic preparing spinner - it can\n'
        '    // never outlive the response that superseded it.\n'
        '    try{\n'
        '      var pl = pbox.querySelectorAll(".ploading");\n'
        '      for(var i = 0; i < pl.length; i++){ pl[i].remove(); }\n'
        '    }catch(e){}\n'
        '  }\n'
        '  function clearFjGateUI(){\n'
        '    // BOT-43 (Section 4 - AUTHORITATIVE completed-state cleanup):\n'
        '    // remove the gate element (every Join row + Join button + the\n'
        '    // stale verification message live INSIDE it), drop the gated\n'
        '    // class. Idempotent; called at EVERY stream re-issuance and on\n'
        '    // a successful Verify so a completed Force-Join can never\n'
        '    // redisplay the previous batch.\n'
        '    try{\n'
        '      var g = pbox.querySelectorAll("#fjgate");\n'
        '      for(var i = 0; i < g.length; i++){ g[i].remove(); }\n'
        '    }catch(e){}\n'
        '    if(fjGateEl){ try{ fjGateEl.remove(); }catch(e){} fjGateEl = null; }\n'
        '    try{ pbox.classList.remove("gated"); }catch(e){}\n'
        '  }\n'
        '  function teardownMedia(){\n'
        '    // Remove the current media element + custom controls + overlays +\n'
        '    // the in-player Join gate (idempotent; mountPlayer and every Retry\n'
        '    // run through here so the player is genuinely REBUILT).\n'
        '    // V26.2-bot42 (Section 8 - lifecycle cleanup): the bounded\n'
        '    // hls_preparation retry timer is CANCELLED here so a rebuilt\n'
        '    // player never inherits a stale poll (no duplicate polling, no\n'
        '    // duplicate authorization, no duplicate player init).\n'
        '    cancelPrepTimer();\n'
        '    __prepAttempts = 0;\n'
        '    __hlsLastLevel = null;\n'
        '    if(ctl){\n'
        '      try{\n'
        '        if(ctl.stopIdle){ ctl.stopIdle(); }\n'
        '      }catch(e){}\n'
        '      try{\n'
        '        if(ctl.keyHandler){\n'
        '          document.removeEventListener("keydown", ctl.keyHandler);\n'
        '        }\n'
        '      }catch(e){}\n'
        '      try{ if(ctl.mo){ ctl.mo.disconnect(); } }catch(e){}\n'
        '      ctl = null;\n'
        '    }\n'
        '    destroyHls();\n'
        '    __hlsNative = false;\n'
        '    __hlsMaster = "";\n'
        '    __hlsNetTries = 0;\n'
        '    // B23 §4.1 PHOTO FIX: a MediaSource blob: URL must NEVER survive\n'
        '    // teardown (hls.js once attached to an <img> left its blob URL\n'
        '    // stamped on the element — the "persistent blob UUID"). destroy\n'
        '    // any blob: src on EVERY media element before it is removed.\n'
        '    try{\n'
        '      var old = pbox.querySelector("#pmedia");\n'
        '      if(old && /^blob:/i.test(String(old.src || ""))){\n'
        '        try{ URL.revokeObjectURL(String(old.src)); }catch(e){}\n'
        '        try{ old.removeAttribute("src"); }catch(e){}\n'
        '      }\n'
        '    }catch(e){}\n'
        '    // V26 (one media element, one stream lifecycle): a media element\n'
        '    // DOCKED into the mini-player lives OUTSIDE #playerbox, so the\n'
        '    // pbox scan above misses it — a rebuild (Retry / re-auth / FJ\n'
        '    // verify) would then append a SECOND live <video> while the old\n'
        '    // one kept playing. Reclaim EVERY #pmedia in the document that\n'
        '    // is not inside pbox: pause, revoke any blob: URL, detach.\n'
        '    try{\n'
        '      var stray = document.querySelectorAll("#pmedia");\n'
        '      for(var si = 0; si < stray.length; si++){\n'
        '        var se = stray[si];\n'
        '        if(pbox && pbox.contains(se)){ continue; }\n'
        '        try{ se.pause(); }catch(e){}\n'
        '        try{\n'
        '          if(/^blob:/i.test(String(se.src || ""))){\n'
        '            URL.revokeObjectURL(String(se.src));\n'
        '          }\n'
        '        }catch(e){}\n'
        '        try{ se.removeAttribute("src"); se.load(); }catch(e){}\n'
        '        try{ se.remove(); }catch(e){}\n'
        '      }\n'
        '    }catch(e){}\n'
        '    var sel = ["#pmedia", ".pbigplay", ".tapplay", "#pwait", "#fjgate",\n'
        '               ".pctl", ".pctlmenu", ".ploading", ".endscr", ".spd",\n'
        '               ".ptop"];\n'
        '    for(var i = 0; i < sel.length; i++){\n'
        '      var nodes = pbox.querySelectorAll(sel[i]);\n'
        '      for(var k = 0; k < nodes.length; k++){\n'
        '        try{ nodes[k].remove(); }catch(e){}\n'
        '      }\n'
        '    }\n'
        '    // V26 UX re-bind support: the _PLAYER_UX_JS overlays live OUTSIDE\n'
        '    // the pbox scan (.chapterbar + #ambient in the player wrap,\n'
        '    // #mini at body scope) — remove them too so a REBUILT player\n'
        '    // re-arms cleanly (the rebind never duplicates overlays).\n'
        '    try{\n'
        '      var wrap = pbox.parentElement;\n'
        '      if(wrap){\n'
        '        var wsel = [".chapterbar", "#ambient"];\n'
        '        for(var wj = 0; wj < wsel.length; wj++){\n'
        '          var wn = wrap.querySelectorAll(wsel[wj]);\n'
        '          for(var wk = 0; wk < wn.length; wk++){\n'
        '            try{ wn[wk].remove(); }catch(e){}\n'
        '          }\n'
        '        }\n'
        '      }\n'
        '      var mn = document.querySelectorAll("#mini");\n'
        '      for(var mk = 0; mk < mn.length; mk++){\n'
        '        try{ mn[mk].remove(); }catch(e){}\n'
        '      }\n'
        '    }catch(e){}\n'
        '    if(fjGateEl){ try{ fjGateEl.remove(); }catch(e){} fjGateEl = null; }\n'
        '    try{ pbox.classList.remove("gated", "stage", "ctl-idle"); }catch(e){}\n'
        '    mediaEl = null;\n'
        '    window.__playerEl = null;\n'
        '    clearActions();\n'
        '  }\n'
        '  function destroyHls(){\n'
        '    if(__hls){\n'
        '      try{ __hls.destroy(); }catch(e){}\n'
        '      __hls = null;\n'
        '    }\n'
        '  }\n'
        '  function mountPlayer(j){\n'
        '    teardownMedia();\n'
        '    // BOT-43: a NEW player lifecycle begins - re-arm the\n'
        '    // PLAYER_DESTROY/PLAYER_CLOSE once-only sentinel (the previous\n'
        '    // lifecycle already reported its pair exactly once).\n'
        '    __destroyReported = false;\n'
        '    show("ok", ICONS.ok + "<span>Access granted</span>",\n'
        '      "Playback is authorized for your account.");\n'
        '    wrap.hidden = false;\n'
        '    var f = document.getElementById("pfile");\n'
        '    if(f){ f.textContent = j.display_name || j.file_name || "Payload file"; }\n'
        '    // BOT-43 (Section 2): the top overlay title mirrors the\n'
        '    // now-playing identity (setupControls created it from the same\n'
        '    // j; a REBUILT player re-syncs it here).\n'
        '    var tt = document.getElementById("ptitle");\n'
        '    if(tt){ tt.textContent = String(j.display_name || j.file_name || ""); }\n'
        '    var s = document.getElementById("psize");\n'
        '    if(s){ s.textContent = fmtSize(j.size); }\n'
        '    var mime = String(j.mime_type || "").toLowerCase();\n'
        '    var mt = String(j.media_type || "").toLowerCase();\n'
        '    var el;\n'
        '    if(mime.indexOf("audio/") === 0 ||\n'
        '        (mime === "" && mt === "audio")){\n'
        '      el = document.createElement("audio");\n'
        '      // audio keeps the native controls (the custom bar is a video\n'
        '      // surface; audio is honest with the platform chrome).\n'
        '      el.setAttribute("controls","");\n'
        '      el.setAttribute("preload","metadata");\n'
        '      el.style.width = "100%";\n'
        '    } else if(mime.indexOf("image/") === 0 ||\n'
        '               (mime === "" && (mt === "photo" || mt === "image"))){\n'
        '      el = document.createElement("img");\n'
        '      el.className = "pimg";\n'
        '      el.setAttribute("alt", j.display_name || j.file_name || "payload image");\n'
        '      el.setAttribute("loading","eager");\n'
        '    } else {\n'
        '      el = document.createElement("video");\n'
        '      // BOT-43 (Section 1 - the DOUBLE play/pause root cause): the\n'
        '      // video is created WITHOUT the native controls attribute.\n'
        '      // The old code set controls="" here and setupControls\n'
        '      // removed it only AFTER the custom bar installed - on\n'
        '      // Telegram Android BOTH control surfaces rendered (native\n'
        '      // + custom = the two-play/pause screenshot), and any\n'
        '      // setup failure left both live. Now the CUSTOM bar is the\n'
        '      // ONLY control system; native controls are enabled BELOW\n'
        '      // solely as the setupControls failure fallback (never both\n'
        '      // simultaneously - never CSS-hidden while logically on).\n'
        '      el.setAttribute("playsinline","");\n'
        '      el.setAttribute("preload","metadata");\n'
        '      el.setAttribute("controlslist","nodownload");\n'
        '      try{ el.controls = false; }catch(e){}\n'
        + (f'      el.setAttribute("poster","{_esc_js_attr(poster_url)}");\n'
           if poster_url else "") +
        '    }\n'
        '    el.id = "pmedia";\n'
        '    if(el.tagName === "VIDEO"){\n'
        '      // B17 UX POLISH: the 16:9 responsive stage — the video\n'
        '      // letterboxes inside the box; source dimensions never\n'
        '      // dictate the page layout.\n'
        '      try{ pbox.classList.add("stage"); }catch(e){}\n'
        '    }\n'
        '    // GAP-CLOSURE (spec 39-54): expose the authorized media element so\n'
        '    // the video-ad state machine can hook el.play() (pre-roll before\n'
        '    // first play, mid-roll at 50%, consumed-break tracking). The ad\n'
        '    // stage treats every ad failure as skip-and-play - content is\n'
        '    // NEVER blocked (spec 44).\n'
        '    window.__playerEl = el;\n'
        '    mediaEl = el;\n'
        '    pbox.appendChild(el);\n'
        '    // V26 PLAYER_READY telemetry + the UX re-bind: the media\n'
        '    // element is live (one element, one stream lifecycle — the\n'
        '    // rebind re-arms the UX extras on THIS element; teardownMedia\n'
        '    // already reclaimed any stray/docked one).\n'
        '    try{ if(window.__siteTel){\n'
        '      window.__siteTel("PLAYER_READY", {tag: el.tagName});\n'
        '    } }catch(e){}\n'
        '    try{ if(window.__uxPlayerRebind){ window.__uxPlayerRebind(); } }catch(e){}\n'
        '    var loading = pbox.querySelector(".ploading");\n'
        '    if(loading){ loading.remove(); }\n'
        '    el.addEventListener("error", function(){\n'
        '      diagnosePlayer(el);\n'
        '    });\n'
        '    el.addEventListener("ended", function(){\n'
        '      info("media_state=STREAM_SUCCESS"); clearActions(); });\n'
        '    // Audio permission (wrapper 3): catch any programmatic play()\n'
        '    // rejection (unmuted autoplay blocked) and surface the one-tap\n'
        '    // "Tap to play" overlay instead of failing silently - the tap IS\n'
        '    // the permission gesture; never loop, never re-prompt. The\n'
        '    // user-initiated native controls path is untouched.\n'
        '    // B23 §4.1 PHOTO FIX: only VIDEO/AUDIO elements have .play()\n'
        '    // — binding el.play on an <img> threw TypeError inside the\n'
        '    // .then chain, which the requestStream .catch rendered as\n'
        '    // "Could not start playback" with the image left src-less.\n'
        '    if(el.tagName === "VIDEO" || el.tagName === "AUDIO"){\n'
        '      var guard = el.play.bind(el);\n'
        '      el.play = function(){\n'
        '        var p = guard();\n'
        '        if(p && p.catch){\n'
        '          p.catch(function(){\n'
        '            var b = document.createElement("button");\n'
        '            b.type = "button";\n'
        '            b.className = "tapplay";\n'
        '            b.innerHTML = ICONS.play + "<span>Tap to play</span>";\n'
        '            b.addEventListener("click", function(){\n'
        '              b.remove();\n'
        '              var q = guard();\n'
        '              if(q && q.catch){ q.catch(function(){}); }\n'
        '            });\n'
        '            pbox.appendChild(b);\n'
        '          });\n'
        '        }\n'
        '        return p;\n'
        '      };\n'
        '    }\n'
        '    // YouTube-like preview (13): the big play button over the poster.\n'
        '    // The raw media URL is NEVER in the initial DOM - the src is\n'
        '    // attached only AFTER the stream issuance below prepared the ad\n'
        '    // session. The overlay sits UNDER the ad stage, so a served\n'
        '    // pre-roll always owns the surface; its click runs the SAME gated\n'
        '    // el.play() (the ad, when served, runs first - never a race with\n'
        '    // the content video).\n'
        '    if(el.tagName === "VIDEO"){\n'
        '      var big = document.createElement("button");\n'
        '      big.type = "button";\n'
        '      big.className = "pbigplay";\n'
        '      big.setAttribute("aria-label", "Play");\n'
        '      big.innerHTML = ICONS.play;\n'
        '      big.addEventListener("click", function(){\n'
        '        try{\n'
        '          var pp = el.play();\n'
        '          if(pp && pp.catch){ pp.catch(function(){}); }\n'
        '        }catch(e){}\n'
        '      });\n'
        '      el.addEventListener("play", function(){ big.hidden = true; });\n'
        '      pbox.appendChild(big);\n'
        '    }\n'
        '    // VIDEO ADS (9-16): the ad session (the server policy from the\n'
        '    // issuance response j) is prepared BEFORE the main video src is\n'
        '    // attached - the gate is armed while the element is still blank,\n'
        '    // so the content can never start behind the ad.\n'
        '    setupPreRoll(el, j);\n'
        '    // BOT-16 Work Item C.2 + BOT-43 (Section 1): the custom control\n'
        '    // bar installs BEFORE the content source attaches (it observes\n'
        '    // the ad stage and hides itself while an ad runs - the ad stage\n'
        '    // owns its own minimal UI). This is the ONLY control system: the\n'
        '    // video was created WITHOUT native controls; ONLY if the custom\n'
        '    // initialization genuinely throws does the fallback enable the\n'
        '    // NATIVE controls (PLAYER_CONTROL_MODE native) - both surfaces\n'
        '    // are never active simultaneously.\n'
        '    if(el.tagName === "VIDEO"){\n'
        '      var __ctlMode = "custom";\n'
        '      try{ setupControls(el, j); }\n'
        '      catch(e){\n'
        '        __ctlMode = "native";\n'
        '        info("player_controls_fallback reason=" +\n'
        '          String((e && e.message) || "error"));\n'
        '        // BOT-43: the honest fallback - native controls ON because\n'
        '        // the custom bar IS NOT installed (not overlaid, not\n'
        '        // half-installed: teardownMedia already removed any partial\n'
        '        // bar children on the next rebuild).\n'
        '        try{ el.setAttribute("controls",""); }catch(e2){}\n'
        '      }\n'
        '      try{ if(window.__siteTel){\n'
        '        window.__siteTel("PLAYER_CONTROL_MODE", {mode: __ctlMode});\n'
        '      } }catch(e){}\n'
        '    }\n'
        '    // BOT-16 Work Item C.1: the codec verdict picks the transport\n'
        '    // (direct src | HLS via hls.js/native) - the ONE place a content\n'
        '    // source is attached.\n'
        '    attachSource(el, j);\n'
        '    setupResume(el, j);\n'
        '    // V25 (§10): the initial source attach (el.src = …) RESETS\n'
        '    // playbackRate on several engines — re-apply the persisted\n'
        '    // speed AFTER the swap (the same discipline as the native\n'
        '    // variant switch), so a saved 1.5× survives the mount.\n'
        '    try{\n'
        '      var __bootRate = 1;\n'
        '      if(ctl && ctl.speedKey){\n'
        '        __bootRate = parseFloat(\n'
        '          sessionStorage.getItem(ctl.speedKey)) || 1;\n'
        '      }\n'
        '      if(isFinite(__bootRate) && __bootRate > 0\n'
        '         && el.tagName === "VIDEO"){\n'
        '        el.playbackRate = __bootRate;\n'
        '      }\n'
        '    }catch(e){}\n'
        '  }\n'
        '  // ---- BOT-16 Work Item C.1: codec verdict -> direct | HLS ---------\n'
        '  function attachSource(el, j){\n'
        '    var verdict = String(j.codec_verdict || "direct");\n'
        '    // B23 §4.1 PHOTO FIX (player-side defense in depth): the HLS\n'
        '    // transports exist ONLY for <video> elements. hls.js attached\n'
        '    // to an <img> stamps a MediaSource blob: URL onto the element\n'
        '    // and the image dies with naturalWidth=0. Non-video surfaces\n'
        '    // ALWAYS take the direct stream URL (the server also never\n'
        '    // mints hls_url for image media — this guard holds even if a\n'
        '    // future verdict regresses).\n'
        '    if(verdict === "transcode" && j.hls_url\n'
        '        && el.tagName === "VIDEO"){\n'
        '      info("WEBSITE_PLAYER_FORMAT verdict=transcode");\n'
        '      attachHls(el, j);\n'
        '      return;\n'
        '    }\n'
        '    info("WEBSITE_PLAYER_FORMAT verdict=" +\n'
        '      (verdict === "transcode" ? "transcode_fallback_direct" : "direct"));\n'
        '    el.src = j.stream_url;\n'
        '    __streamUrl = String(j.stream_url || "");\n'
        '  }\n'
        '  function variantUrl(master, id){\n'
        '    // The transcode ladder layout: <hls_url dir>/<variant>/index.m3u8.\n'
        '    if(!master || !id || id === "auto"){ return String(master || ""); }\n'
        '    var dir = String(master).replace(/[^\\/]*$/, "");\n'
        '    return dir + String(id) + "/index.m3u8";\n'
        '  }\n'
        '  // ---- V26.2-bot42 (TASK C1 player side): the master READINESS gate --\n'
        '  // The server answers 503 hls_preparing while the ONE background\n'
        '  // transcoding job runs. The player polls the SAME authorized master\n'
        '  // URL with BOUNDED backoff (the SAME stream token - no new\n'
        '  // issuance, no Mini App reload, no recursive player creation;\n'
        '  // re-authorization happens only when the authorization actually\n'
        '  // expires, which surfaces as a 401 here).\n'
        '  var __prepTimer = null;\n'
        '  var __prepAttempts = 0;\n'
        '  var __PREP_DELAYS = [1000, 2000, 4000, 8000, 12000, 20000, 30000,\n'
        '    45000];\n'
        '  var __PREP_MAX_MS = 600000;\n'
        '  function cancelPrepTimer(){\n'
        '    if(__prepTimer){ clearTimeout(__prepTimer); __prepTimer = null; }\n'
        '  }\n'
        '  function ensureMasterReady(j, onReady, onClassified){\n'
        '    cancelPrepTimer();\n'
        '    var url = String(j.hls_url || "");\n'
        '    var started = Date.now();\n'
        '    function attempt(){\n'
        '      fetch(url, {credentials: "same-origin"}).then(function(r){\n'
        '        if(r.status === 200){\n'
        '          onReady(url);\n'
        '          return;\n'
        '        }\n'
        '        return r.json().catch(function(){ return null; })\n'
        '          .then(function(body){\n'
        '            var code = String((body && body.error) || "");\n'
        '            if(r.status === 503 && code === "hls_preparing"){\n'
        '              var waited = Date.now() - started;\n'
        '              if(waited >= __PREP_MAX_MS){\n'
        '                // Bounded maximum reached - the honest preparation\n'
        '                // give-up state (never AUTH_EXPIRED).\n'
        '                onClassified("PREPARING");\n'
        '                return;\n'
        '              }\n'
        '              __prepAttempts += 1;\n'
        '              var delay = __PREP_DELAYS[Math.min(__prepAttempts - 1,\n'
        '                __PREP_DELAYS.length - 1)];\n'
        '              info("hls_preparing attempt=" + __prepAttempts +\n'
        '                " next_retry_ms=" + delay);\n'
        '              showLoading("Preparing this video\\u2026");\n'
        '              __prepTimer = setTimeout(attempt, delay);\n'
        '              return;\n'
        '            }\n'
        '            // Any other outcome is classified ONCE, honestly.\n'
        '            onClassified(issuanceStateFromResponse(r.status, body));\n'
        '          });\n'
        '      }).catch(function(){\n'
        '        onClassified("NETWORK_ERROR");\n'
        '      });\n'
        '    }\n'
        '    attempt();\n'
        '  }\n'
        '  function attachHls(el, j){\n'
        '    // V26.2-bot42 (ROOT CAUSE D - the Android HLS ENGINE ORDER):\n'
        '    // hls.js (MSE) FIRST; native HLS only when hls.js/MSE is\n'
        '    // unavailable. Android Chrome - the Telegram Android WebView\n'
        '    // engine - answers canPlayType("application/vnd.apple.mpegurl")\n'
        '    // with "maybe" but cannot decode MPEG-TS natively: the old\n'
        '    // native-first order mounted a dead <video src=master.m3u8> on\n'
        '    // every Android device (bot-42: no MANIFEST_PARSED, no quality\n'
        '    // menu, no playback). ONE media element, ONE HLS instance, ONE\n'
        '    // lifecycle - the engine attaches exactly once, after the master\n'
        '    // is genuinely ready.\n'
        '    ensureMasterReady(j, function(url){\n'
        '      loadHlsJs(function(Hls){\n'
        '        if(Hls && Hls.isSupported()){\n'
        '          info("WEBSITE_PLAYER_FORMAT verdict=transcode engine=hls_js");\n'
        '          __hls = new Hls({enableWorker: true});\n'
        '          __hlsMaster = url;\n'
        '          __hls.attachMedia(el);\n'
        '          __hls.loadSource(url);\n'
        '          __hls.on(Hls.Events.MANIFEST_PARSED, function(){\n'
        '            setupQualityMenuHls(el, j);\n'
        '          });\n'
        '          __hls.on(Hls.Events.LEVEL_SWITCHED, function(evt, data){\n'
        '            // V26.2-bot42 (Section 9): QUALITY_CHANGE is emitted\n'
        '            // only AFTER the REAL level switch (hls.js switched the\n'
        '            // active rendition) - never at user-intent time, never\n'
        '            // for the initial ABR pick (only an actual CHANGE). MSE\n'
        '            // preserves currentTime across the switch by design.\n'
        '            try{\n'
        '              if(typeof __hlsLastLevel === "undefined" ||\n'
        '                 __hlsLastLevel === null){\n'
        '                __hlsLastLevel = data.level;\n'
        '                return;\n'
        '              }\n'
        '              if(__hlsLastLevel === data.level){ return; }\n'
        '              __hlsLastLevel = data.level;\n'
        '              if(window.__siteTel && __hls){\n'
        '                var lv = (__hls.levels && __hls.levels[data.level])\n'
        '                  ? __hls.levels[data.level] : null;\n'
        '                var label = lv && lv.height\n'
        '                  ? (lv.height + "p") : ("level " + data.level);\n'
        '                var _qt = 0; try{ _qt = el.currentTime || 0; }catch(e){}\n'
        '                window.__siteTel("QUALITY_CHANGE",\n'
        '                  {to: label, level: data.level});\n'
        '                // BOT-43 (Section 3): the spec-named twin event\n'
        '                // (same real-switch-only discipline).\n'
        '                window.__siteTel("PLAYER_QUALITY_CHANGE",\n'
        '                  {to: label, level: data.level, position_s: _qt});\n'
        '              }\n'
        '            }catch(e){}\n'
        '          });\n'
        '          __hls.on(Hls.Events.ERROR, function(evt, data){\n'
        '            if(!data || !data.fatal){ return; }\n'
        '            if(data.type === Hls.ErrorTypes.NETWORK_ERROR){\n'
        '              __hlsNetTries += 1;\n'
        '              if(__hlsNetTries <= 2){\n'
        '                try{ __hls.startLoad(); }catch(e){}\n'
        '                return;\n'
        '              }\n'
        '              showState("NETWORK_INTERRUPTED");\n'
        '              return;\n'
        '            }\n'
        '            if(data.type === Hls.ErrorTypes.MEDIA_ERROR){\n'
        '              try{ __hls.recoverMediaError(); }catch(e){}\n'
        '              return;\n'
        '            }\n'
        '            // Unrecoverable - graceful degradation to the direct stream.\n'
        '            info("WEBSITE_PLAYER_FORMAT verdict=transcode " +\n'
        '              "engine=fallback_direct");\n'
        '            destroyHls();\n'
        '            el.src = String(j.stream_url || "");\n'
        '            __streamUrl = String(j.stream_url || "");\n'
        '            try{ el.load(); }catch(e){}\n'
        '          });\n'
        '        } else {\n'
        '          // hls.js/MSE unavailable on this browser - the NATIVE\n'
        '          // fallback (Section 8: native only when hls.js is not an\n'
        '          // option; never a blind canPlayType preference).\n'
        '          attachNativeHls(el, j, url);\n'
        '        }\n'
        '      }, function(){\n'
        '        // hls.js CDN unreachable - the native fallback, then the\n'
        '        // direct stream as the last resort.\n'
        '        attachNativeHls(el, j, url);\n'
        '      });\n'
        '    }, function(state){\n'
        '      // The preparation poll gave up or classified a real failure.\n'
        '      showState(state);\n'
        '    });\n'
        '  }\n'
        '  function attachNativeHls(el, j, url){\n'
        '    var native = false;\n'
        '    try{\n'
        '      native = !!el.canPlayType &&\n'
        '        !!el.canPlayType("application/vnd.apple.mpegurl");\n'
        '    }catch(e){ native = false; }\n'
        '    if(native){\n'
        '      // Genuine native HLS support (Safari / iOS).\n'
        '      __hlsNative = true;\n'
        '      __hlsMaster = url;\n'
        '      __streamUrl = url;\n'
        '      info("WEBSITE_PLAYER_FORMAT verdict=transcode engine=native_hls");\n'
        '      el.src = url;\n'
        '      setupQualityMenuNative(el, j);\n'
        '      return;\n'
        '    }\n'
        '    // Neither hls.js/MSE nor native HLS - the direct stream as the\n'
        '    // honest last resort (the error surface handles a refusal).\n'
        '    info("WEBSITE_PLAYER_FORMAT verdict=transcode " +\n'
        '      "engine=fallback_direct");\n'
        '    el.src = String(j.stream_url || "");\n'
        '    __streamUrl = String(j.stream_url || "");\n'
        '  }\n'
        '  function loadHlsJs(ok, fail){\n'
        '    // Dynamically load hls.js from the pinned v1 CDN line with a hard\n'
        '    // timeout; every failure path falls back to the direct stream.\n'
        '    if(window.Hls){ ok(window.Hls); return; }\n'
        '    var done = false;\n'
        '    var t = setTimeout(function(){\n'
        '      if(done){ return; } done = true; fail();\n'
        '    }, 10000);\n'
        '    var s = document.createElement("script");\n'
        '    s.src = HLS_CDN;\n'
        '    s.async = true;\n'
        '    s.onload = function(){\n'
        '      if(done){ return; }\n'
        '      done = true; clearTimeout(t);\n'
        '      ok(window.Hls || null);\n'
        '    };\n'
        '    s.onerror = function(){\n'
        '      if(done){ return; }\n'
        '      done = true; clearTimeout(t); fail();\n'
        '    };\n'
        '    document.head.appendChild(s);\n'
        '  }\n'
        '  // ---- VIDEO ADS (§9-§16) — server-decided PRE_ROLL_SLOT -----\n'
        '  // SECURITY NOTE: everything in this block is UX ONLY. The\n'
        '  // authoritative ad decision AND the frequency accounting\n'
        '  // happened SERVER-side at stream issuance (POST /site/api/stream\n'
        '  // attaches "preroll" ONLY when the video-ad policy resolves to\n'
        '  // SERVE for the authenticated user). The server NEVER trusts an\n'
        '  // adCompleted-style client claim and this code never sends one\n'
        '  // (the best-effort lifecycle records below are display-only and\n'
        '  // can never mutate any server-side state — §12).\n'
        '  function videoAdLog(name, extra){\n'
        '    // name is the FULL §14 event name (VIDEO_AD_RESPONSE etc.).\n'
        '    try{\n'
        '      console.log(String(name) + (extra ? " " + extra : ""));\n'
        '    }catch(e){}\n'
        '  }\n'
        '  function videoAdEvent(name, provider, detail){\n'
        '    // §14 lifecycle: structured client events — the FULL names\n'
        '    // VIDEO_AD_RESPONSE / VIDEO_AD_START /\n'
        '    // VIDEO_AD_COMPLETE / VIDEO_AD_NO_FILL / VIDEO_AD_ERROR with\n'
        '    // provider + detail (NEVER any token or URL) — plus a\n'
        '    // best-effort display-only record to the EXISTING ads-event\n'
        '    // endpoint (compact va_* slug — the endpoint field is\n'
        '    // bounded). The server recognizes the CLOSED slug set and\n'
        '    // logs the record with the FULL VIDEO_AD_* name server-\n'
        '    // side; pure display record — it can never touch the ad\n'
        '    // policy state (§12: no completion claim, no frequency\n'
        '    // effect, no creative is recorded for a pre-roll slot).\n'
        '    videoAdLog(name, "provider=" + String(provider || "direct")\n'
        '      + (detail ? " " + String(detail) : ""));\n'
        '    var slug = "va_" + String(name).replace(/^video_ad_/i, "")\n'
        '                           .toLowerCase();\n'
        '    try{\n'
        '      fetch(' + json.dumps(site_url("site/api/ads/event")) + ', {\n'
        '        method: "POST",\n'
        '        headers: {"Content-Type": "application/json"},\n'
        '        body: JSON.stringify({placement: "AD_VIDEO_BEFORE",\n'
        '          event: slug,\n'
        '          provider: String(provider || ""),\n'
        '          reason: String(detail || ""), creative_id: 0})\n'
        '      }).catch(function(){});\n'
        '    }catch(e){}\n'
        '  }\n'
        '  function parseVastSkipoffset(raw){\n'
        '    // Mirrors app/web/site/video_ads.py:parse_vast_skipoffset —\n'
        '    // the VAST timeformat "HH:MM:SS(.fff)", the short "MM:SS"\n'
        '    // form, or plain seconds. Returns seconds (number) or null.\n'
        '    if(raw == null){ return null; }\n'
        '    var s = String(raw).trim();\n'
        '    if(!s){ return null; }\n'
        '    var m = s.match(/^(\\d+):(\\d{1,2}):(\\d{1,2})(?:\\.(\\d{1,3}))?$/);\n'
        '    if(m){\n'
        '      if(parseInt(m[2], 10) > 59 || parseInt(m[3], 10) > 59){\n'
        '        return null;\n'
        '      }\n'
        '      return parseInt(m[1], 10) * 3600 + parseInt(m[2], 10) * 60\n'
        '        + parseInt(m[3], 10)\n'
        '        + (m[4] ? parseFloat("0." + m[4]) : 0);\n'
        '    }\n'
        '    m = s.match(/^(\\d{1,2}):(\\d{1,2})(?:\\.(\\d{1,3}))?$/);\n'
        '    if(m){\n'
        '      if(parseInt(m[1], 10) > 59 || parseInt(m[2], 10) > 59){\n'
        '        return null;\n'
        '      }\n'
        '      return parseInt(m[1], 10) * 60 + parseInt(m[2], 10)\n'
        '        + (m[3] ? parseFloat("0." + m[3]) : 0);\n'
        '    }\n'
        '    if(/^(\\d+(?:\\.\\d+)?)$/.test(s)){\n'
        '      var v = parseFloat(s);\n'
        '      return (isFinite(v) && v >= 0) ? v : null;\n'
        '    }\n'
        '    return null;\n'
        '  }\n'
        '  function vastTrackAll(urls){\n'
        '    // Best-effort VAST tracking beacons (§14): fire-and-forget\n'
        '    // no-cors fetches — NEVER block ad or content playback.\n'
        '    if(!urls || !urls.length){ return; }\n'
        '    for(var i = 0; i < urls.length; i++){\n'
        '      try{\n'
        '        fetch(urls[i], {mode: "no-cors"}).catch(function(){});\n'
        '      }catch(e){}\n'
        '    }\n'
        '  }\n'
        '  function parseVastDoc(doc){\n'
        '    // Select the FIRST playable ad: an <Ad> with an <InLine> whose\n'
        '    // <Creative><Linear> carries a supported <MediaFile>\n'
        '    // (video/mp4 | video/webm; highest bitrate wins, the first\n'
        '    // mp4 breaks ties). Returns the ad info or null (no playable\n'
        '    // ad / malformed document — the honest no-fill path, §14).\n'
        '    if(!doc){ return null; }\n'
        '    var ads = doc.getElementsByTagName("Ad");\n'
        '    for(var i = 0; i < ads.length; i++){\n'
        '      var ad = ads[i];\n'
        '      if(!ad.getElementsByTagName("InLine").length){ continue; }\n'
        '      var linears = ad.getElementsByTagName("Linear");\n'
        '      if(!linears.length){ continue; }\n'
        '      var linear = linears[0];\n'
        '      var mfs = linear.getElementsByTagName("MediaFile");\n'
        '      var best = null, bestScore = -1, bestIsMp4 = false;\n'
        '      for(var j = 0; j < mfs.length; j++){\n'
        '        var mf = mfs[j];\n'
        '        var type = String(mf.getAttribute("type") || "").toLowerCase();\n'
        '        var isMp4 = type.indexOf("video/mp4") === 0;\n'
        '        if(!isMp4 && type.indexOf("video/webm") !== 0){ continue; }\n'
        '        var url = String(mf.textContent || "").trim();\n'
        '        if(!url){ continue; }\n'
        '        var br = parseFloat(mf.getAttribute("bitrate") || "0") || 0;\n'
        '        var score = br * 2 + (isMp4 ? 1 : 0);\n'
        '        if(score > bestScore){\n'
        '          bestScore = score; best = url; bestIsMp4 = isMp4;\n'
        '        }\n'
        '      }\n'
        '      if(!best){ continue; }\n'
        '      // V26 Phase 5: the skipoffset attribute is NO LONGER parsed\n'
        '      // — no skip control exists in the player, so the VAST\n'
        '      // skip declaration can never authorize an early return\n'
        '      // from the ad. parseVastSkipoffset remains ONLY as the\n'
        '      // Duration time parser (HH:MM:SS).\n'
        '      var dur = 0;\n'
        '      var durEls = linear.getElementsByTagName("Duration");\n'
        '      if(durEls.length){\n'
        '        var dv = parseVastSkipoffset(durEls[0].textContent);\n'
        '        if(dv != null && dv > 0){ dur = dv; }\n'
        '      }\n'
        '      function txt(els){\n'
        '        var out = [];\n'
        '        for(var k = 0; k < els.length; k++){\n'
        '          var t = String(els[k].textContent || "").trim();\n'
        '          if(t){ out.push(t); }\n'
        '        }\n'
        '        return out;\n'
        '      }\n'
        '      return {\n'
        '        url: best, isMp4: bestIsMp4,\n'
        '        duration: dur,\n'
        '        impressions: txt(ad.getElementsByTagName("Impression")),\n'
        '        errors: txt(ad.getElementsByTagName("Error")),\n'
        '        clicks: txt(linear.getElementsByTagName("ClickTracking"))\n'
        '      };\n'
        '    }\n'
        '    return null;\n'
        '  }\n'
        '  function fetchVastAd(cfg, onResolved){\n'
        '    // §12/§14: fetch the VAST tag with a HARD timeout, parse it\n'
        '    // and resolve EXACTLY once — either the filled ad info or a\n'
        '    // no-fill/error reason the caller maps through the SERVER\n'
        '    // failure policy (release/block). The guard timer always\n'
        '    // resolves, so the player is never left stuck (§14).\n'
        '    var timeoutMs = Math.max(2, parseInt(cfg.timeout, 10) || 8)\n'
        '                    * 1000;\n'
        '    var settled = false;\n'
        '    var guardT = setTimeout(function(){\n'
        '      resolve(false, null, "error", "timeout");\n'
        '    }, timeoutMs + 250);\n'
        '    function resolve(filled, info, failKind, reason){\n'
        '      if(settled){ return; } settled = true;\n'
        '      if(guardT){ clearTimeout(guardT); guardT = null; }\n'
        '      try{\n'
        '        onResolved(filled, info || null, failKind, reason || "");\n'
        '      }catch(e){}\n'
        '    }\n'
        '    try{\n'
        '      var sig = null;\n'
        '      try{ sig = AbortSignal.timeout(timeoutMs); }catch(e){\n'
        '        sig = null; }\n'
        '      fetch(String(cfg.vast_url || ""), sig ? {signal: sig} : {})\n'
        '      .then(function(r){\n'
        '        if(!r.ok){ throw new Error("http_" + r.status); }\n'
        '        return r.text();\n'
        '      }).then(function(xml){\n'
        '        var doc = null;\n'
        '        try{\n'
        '          doc = new DOMParser().parseFromString(\n'
        '            String(xml || ""), "application/xml");\n'
        '        }catch(e){ doc = null; }\n'
        '        var malformed = (!doc\n'
        '          || doc.getElementsByTagName("parsererror").length > 0);\n'
        '        var info = malformed ? null : parseVastDoc(doc);\n'
        '        if(info){\n'
        '          videoAdEvent("VIDEO_AD_RESPONSE", "vast",\n'
        '            "fill=1 media=" + (info.isMp4 ? "mp4" : "webm")\n'
        '            + (info.duration > 0\n'
        '               ? " duration=" + info.duration : ""));\n'
        '          resolve(true, info, "", "");\n'
        '        } else {\n'
        '          var reason = malformed ? "malformed" : "no_fill";\n'
        '          videoAdEvent("VIDEO_AD_RESPONSE", "vast",\n'
        '            "fill=0 reason=" + reason);\n'
        '          resolve(false, null, "no_fill", reason);\n'
        '        }\n'
        '      }).catch(function(err){\n'
        '        var msg = String((err && err.message) || err || "");\n'
        '        var reason = /timeout|abort/i.test(msg)\n'
        '          ? "timeout" : "fetch_error";\n'
        '        resolve(false, null, "error", reason);\n'
        '      });\n'
        '    }catch(e){\n'
        '      resolve(false, null, "error", "fetch_error");\n'
        '    }\n'
        '  }\n'
        '  function setupPreRoll(el, j){\n'
        '    // Wire contract (stable, §16): the server attaches "preroll"\n'
        '    // ONLY when the video-ad policy resolved to SERVE for this\n'
        '    // authenticated playback — there is no "active" field on the\n'
        '    // wire; the key\'s presence plus a usable ad source IS the\n'
        '    // serve signal: a non-empty vast_url for provider=vast, a\n'
        '    // non-empty source_url otherwise (the v37 direct contract,\n'
        '    // unchanged).\n'
        '    var cfg = j && j.preroll;\n'
        '    if(!cfg){ return; }\n'
        '    var provider = String(cfg.provider || "direct");\n'
        '    var usable = (provider === "vast")\n'
        '      ? String(cfg.vast_url || "").length > 0\n'
        '      : String(cfg.source_url || "").length > 0;\n'
        '    if(!usable){ return; }\n'
        '    // Single pre-roll UX: suppress the legacy Ads-Platform video\n'
        '    // stage for THIS playback through its own pass-through flag\n'
        '    // (the legacy machine itself is never modified).\n'
        '    try{\n'
        '      if(window.__adStage){ window.__adStage.__done = true; }\n'
        '    }catch(e){}\n'
        '    // B23 §4.1 PHOTO FIX: an <img> has no .play — the preroll\n'
        '    // gate only exists for VIDEO/AUDIO playback. For photos the\n'
        '    // gate is inert (no playback to gate) and a hard bind would\n'
        '    // throw TypeError inside the requestStream .then chain\n'
        '    // ("Could not start playback" with a src-less image).\n'
        '    var innerPlay = (typeof el.play === "function")\n'
        '      ? el.play.bind(el)\n'
        '      : function(){ return null; };\n'
        '    var adStarted = false;   // the gate fired once (any path)\n'
        '    var adRunning = false;   // the ad overlay is up right now\n'
        '    function startAd(after){\n'
        '      adStarted = true; adRunning = true;\n'
        '      runPreRoll(cfg, el, function(released){\n'
        '        adRunning = false;\n'
        '        if(released){ after(); }\n'
        '      });\n'
        '    }\n'
        '    // Gate EVERY playback start, not just programmatic play():\n'
        '    // the "play" event fires for the NATIVE controls too (the\n'
        '    // only other start path on this player — nothing autoplays).\n'
        '    // The content video is paused/locked behind the overlay until\n'
        '    // the ad ends, is skipped, or fails over per the SERVER\n'
        '    // fallback policy. UX only — the decision was server-side.\n'
        '    el.addEventListener("play", function(){\n'
        '      if(adRunning){ try{ el.pause(); }catch(e){} return; }\n'
        '      if(adStarted){ return; }\n'
        '      try{ el.pause(); }catch(e){}\n'
        '      startAd(function(){\n'
        '        var p = innerPlay();\n'
        '        if(p && p.catch){ p.catch(function(){}); }\n'
        '      });\n'
        '    });\n'
        '    // Programmatic starts (resume bar, mid-roll resume) run the\n'
        '    // ad BEFORE the content element ever starts, so the play\n'
        '    // event never double-fires for the same ad.\n'
        '    el.play = function(){\n'
        '      if(adStarted){ return innerPlay(); }\n'
        '      var args = arguments;\n'
        '      startAd(function(){\n'
        '        var p = innerPlay.apply(el, args);\n'
        '        if(p && p.catch){ p.catch(function(){}); }\n'
        '      });\n'
        '      return Promise.resolve();\n'
        '    };\n'
        '  }\n'
        '  function runPreRoll(cfg, contentEl, onDone){\n'
        '    // The ONE PRE_ROLL_SLOT machine (§11): provider-agnostic\n'
        '    // overlay + timers + the single ad→content transition. Only\n'
        '    // the SOURCE of the ad media differs by provider — the slot,\n'
        '    // its DOM and its controls are identical for every provider\n'
        '    // (§16: swapping providers never rewrites the player).\n'
        '    var stage = document.getElementById("adstage");\n'
        '    var body = document.getElementById("adbody");\n'
        '    var count = document.getElementById("adcount");\n'
        '    if(!stage || !body){ onDone(true); return; }\n'
        '    var provider = String(cfg.provider || "direct");\n'
        '    // V26 Phase 5: mode/skip_delay no longer reach the player\n'
        '    // decision — the ad ALWAYS plays to completion (no skip\n'
        '    // control exists anywhere in the player).\n'
        '    var maxDur = Math.max(1, parseInt(cfg.duration, 10) || 15);\n'
        '    var fallback = String(cfg.fallback || "release");\n'
        '    var finished = false;\n'
        '    var timers = [];\n'
        '    var adEl = null;\n'
        '    var tracker = {impressions: [], errors: [], clicks: []};\n'
        '    function clearTimers(){\n'
        '      for(var i = 0; i < timers.length; i++){\n'
        '        try{ clearTimeout(timers[i]); clearInterval(timers[i]); }\n'
        '        catch(e){}\n'
        '      }\n'
        '      timers.length = 0;\n'
        '    }\n'
        '    function cleanup(){\n'
        '      clearTimers();\n'
        '      if(adEl){\n'
        '        try{ adEl.pause(); }catch(e){}\n'
        '        try{ adEl.removeAttribute("src"); adEl.load(); }catch(e){}\n'
        '        try{ adEl.remove(); }catch(e){}\n'
        '        adEl = null;\n'
        '      }\n'
        '      body.innerHTML = "";\n'
        '      stage.hidden = true;\n'
        '      if(count){ count.textContent = ""; }\n'
        '      if(count && count.parentNode){ count.parentNode.hidden = false; }\n'
        '    }\n'
        '    function finishPreroll(){\n'
        '      // THE one ad→content transition (§11): EVERY provider path\n'
        '      // — natural completion or fail-open release — runs\n'
        '      // through HERE and only here (never duplicated, never\n'
        '      // provider-specific).\n'
        '      if(finished){ return; } finished = true;\n'
        '      cleanup(); onDone(true);\n'
        '    }\n'
        '    function blockPlayback(){\n'
        '      // Honest hard-enforcement state: "ad unavailable". Retry\n'
        '      // stays offered \u2014 never a silent permanent lock, never a\n'
        '      // faked impression (\u00a714). BOT-16 Work Item C.6: website ad\n'
        '      // failures NEVER push users to Telegram \u2014 the Get File CTA is\n'
        '      // removed from this state (Retry Stream only).\n'
        '      show("locked", ICONS.warn + "<span>Ad unavailable</span>",\n'
        '        "The pre-roll ad could not be loaded and the current " +\n'
        '        "ad policy blocks playback. Tap Retry Stream to try " +\n'
        '        "again.");\n'
        '      var va = document.getElementById("vactions");\n'
        '      if(va){\n'
        '        va.innerHTML = "";\n'
        '        var b = document.createElement("button");\n'
        '        b.type = "button"; b.className = "partpill go";\n'
        '        b.innerHTML = ICONS.replay + "<span>Retry Stream</span>";\n'
        '        b.addEventListener("click", function(){\n'
        '          retryStream();\n'
        '        });\n'
        '        va.appendChild(b);\n'
        '        va.hidden = false;\n'
        '      }\n'
        '      onDone(false);\n'
        '    }\n'
        '    function videoAdFail(eventName, reason){\n'
        '      // §14 failure policy: no-fill / malformed / timeout /\n'
        '      // media error — release (default) or block, SERVER-\n'
        '      // decided; the player never stays stuck either way.\n'
        '      if(finished){ return; } finished = true;\n'
        '      cleanup();\n'
        '      videoAdEvent(eventName, provider, "reason=" + reason);\n'
        '      if(eventName === "VIDEO_AD_ERROR" && tracker.errors.length){\n'
        '        vastTrackAll(tracker.errors);   // VAST <Error> beacons\n'
        '      }\n'
        '      if(fallback === "block"){ blockPlayback(); }\n'
        '      else { onDone(true); }\n'
        '    }\n'
        '    function startAdMedia(src, opts){\n'
        '      // opts: {duration, fireImpressions}. V26 Phase 5: there is\n'
        '      // NO Skip control in the player — the ONE PRE_ROLL_SLOT\n'
        '      // render path ("Advertisement" label + the remaining-\n'
        '      // duration countdown + the SAME layered ad <video> for\n'
        '      // every provider) plays the ad to its completion; the\n'
        '      // skip arming, the skip button and its click action were\n'
        '      // REMOVED (never CSS-hidden).\n'
        '      stage.hidden = false;\n'
        '      body.innerHTML = "";\n'
        '      var total = (opts.duration > 0 ? opts.duration : 0);\n'
        '      if(count){\n'
        '        count.textContent = total > 0\n'
        '          ? String(Math.ceil(total)) : "";\n'
        '        if(count.parentNode){\n'
        '          count.parentNode.hidden = (total <= 0);\n'
        '        }\n'
        '      }\n'
        '      adEl = document.createElement("video");\n'
        '      adEl.className = "advideo";\n'
        '      adEl.setAttribute("playsinline", "");\n'
        '      adEl.setAttribute("preload", "auto");\n'
        '      adEl.src = src;\n'
        '      var progressSeen = false;\n'
        '      var startedLogged = false;\n'
        '      var watchdog = null;\n'
        '      function markProgress(){\n'
        '        if(!progressSeen){\n'
        '          progressSeen = true;\n'
        '          if(watchdog){ clearTimeout(watchdog); watchdog = null; }\n'
        '        }\n'
        '      }\n'
        '      adEl.addEventListener("error", function(){\n'
        '        if(!adEl){ return; }\n'
        '        videoAdFail("VIDEO_AD_ERROR", "media_error"); });\n'
        '      adEl.addEventListener("timeupdate", markProgress);\n'
        '      adEl.addEventListener("loadeddata", markProgress);\n'
        '      adEl.addEventListener("playing", function(){\n'
        '        markProgress();\n'
        '        if(!adEl){ return; }\n'
        '        if(!startedLogged){\n'
        '          startedLogged = true;\n'
        '          videoAdEvent("VIDEO_AD_START", provider, "");\n'
        '          if(opts.fireImpressions && tracker.impressions.length){\n'
        '            vastTrackAll(tracker.impressions);\n'
        '          }\n'
        '        }\n'
        '      });\n'
        '      adEl.addEventListener("ended", function(){\n'
        '        videoAdEvent("VIDEO_AD_COMPLETE", provider, "via=ended");\n'
        '        finishPreroll();\n'
        '      });\n'
        '      adEl.addEventListener("click", function(){\n'
        '        // Optional <ClickTracking> (§14): best-effort beacon\n'
        '        // only — never navigates away from the player.\n'
        '        if(tracker.clicks.length){ vastTrackAll(tracker.clicks); }\n'
        '      });\n'
        '      adEl.addEventListener("timeupdate", function(){\n'
        '        // b10 §33 browser-QA fix: cleanup() nulls adEl during the\n'
        '        // ad→content transition, but a QUEUED timeupdate on the\n'
        '        // removed element can still fire afterwards (observed live:\n'
        '        // "TypeError: Cannot read properties of null (reading\n'
        '        // \'currentTime\')"). Guard and bail — the ad is finished.\n'
        '        if(!adEl){ return; }\n'
        '        var t = adEl.currentTime || 0;\n'
        '        // V26 Phase 5: NO skip arming exists — the countdown\n'
        '        // ALWAYS shows the remaining AD duration and the ad\n'
        '        // auto-continues at its end.\n'
        '        var left = (opts.duration > 0\n'
        '          ? Math.max(0, Math.ceil(opts.duration - t)) : -1);\n'
        '        if(count){ count.textContent = (left >= 0)\n'
        '          ? String(left) : ""; }\n'
        '      });\n'
        '      if(opts.duration > 0){\n'
        '        // V26 Phase 5 (the ONLY continuation path): the ad ALWAYS\n'
        '        // auto-continues at the known maximum duration — there is\n'
        '        // no skip action anywhere in the player.\n'
        '        timers.push(setTimeout(function(){\n'
        '          if(!finished){\n'
        '            videoAdEvent("VIDEO_AD_COMPLETE", provider,\n'
        '              "via=max_duration");\n'
        '            finishPreroll();\n'
        '          }\n'
        '        }, opts.duration * 1000));\n'
        '      }\n'
        '      // FAILURE watchdog: 8s to see ANY progress event, then the\n'
        '      // configured fallback applies (release / block).\n'
        '      watchdog = setTimeout(function(){\n'
        '        if(!progressSeen){\n'
        '          videoAdFail("VIDEO_AD_ERROR", "no_progress_timeout"); }\n'
        '      }, 8000);\n'
        '      timers.push(watchdog);\n'
        '      body.appendChild(adEl);\n'
        '      var p = adEl.play();\n'
        '      if(p && p.catch){\n'
        '        p.catch(function(){\n'
        '          // Unmuted programmatic autoplay rejected — retry muted\n'
        '          // once; a second rejection is an honest ad failure.\n'
        '          try{ adEl.muted = true; }catch(e){}\n'
        '          var q = adEl.play();\n'
        '          if(q && q.catch){\n'
        '            q.catch(function(){\n'
        '              videoAdFail("VIDEO_AD_ERROR", "autoplay_blocked"); });\n'
        '          }\n'
        '        });\n'
        '      }\n'
        '    }\n'
        '    if(provider === "vast"){\n'
        '      // ---- VAST adapter (§9/§12): the provider fills the slot. --\n'
        '      fetchVastAd(cfg, function(filled, info, failKind, reason){\n'
        '        if(filled && info){\n'
        '          tracker.impressions = info.impressions;\n'
        '          tracker.errors = info.errors;\n'
        '          tracker.clicks = info.clicks;\n'
        '          // V26 Phase 5: NO skippable decision — every pre-roll\n'
        '          // plays to completion; the VAST skipoffset is IGNORED\n'
        '          // (a skip control no longer exists anywhere in the\n'
        '          // player, so the ad never hands playback back early).\n'
        '          startAdMedia(info.url, {\n'
        '            duration: info.duration > 0\n'
        '              ? Math.round(info.duration) : 0,\n'
        '            fireImpressions: true\n'
        '          });\n'
        '        } else {\n'
        '          videoAdFail(failKind === "error" ? "VIDEO_AD_ERROR"\n'
        '            : "VIDEO_AD_NO_FILL", reason);\n'
        '        }\n'
        '      });\n'
        '    } else {\n'
        '      // ---- DIRECT media (the v37 behavior, unchanged) ----------\n'
        '      var src = String(cfg.source_url || "");\n'
        '      if(!src){ videoAdFail("VIDEO_AD_NO_FILL",\n'
        '        "not_configured"); return; }\n'
        '      startAdMedia(src, {\n'
        '        duration: maxDur,\n'
        '        fireImpressions: false\n'
        '      });\n'
        '    }\n'
        '  }\n'
        '  // ---- BOT-16 Work Item C.2: QUALITY menus (HLS only) --------------\n'
        '  function setupQualityMenuHls(el, j){\n'
        '    if(!ctl || !__hls){ return; }\n'
        '    var levels = (__hls && __hls.levels) || [];\n'
        '    if(levels.length <= 1){\n'
        '      // single level - nothing to switch: the menu stays hidden.\n'
        '      ctl.qBtn.hidden = true;\n'
        '      return;\n'
        '    }\n'
        '    // B18-FINAL (Issue E): re-apply the session-persisted choice.\n'
        '    var pref = loadQualityPref(j);\n'
        '    try{\n'
        '      if(pref >= 0 && pref < levels.length){ __hls.currentLevel = pref; }\n'
        '      else { __hls.currentLevel = -1; }\n'
        '    }catch(e){}\n'
        '    var items = [{\n'
        '      label: "Auto", id: "auto",\n'
        '      checked: (__hls.currentLevel < 0),\n'
        '      onSelect: function(){\n'
        '        try{ __hls.currentLevel = -1; }catch(e){}\n'
        '        saveQualityPref(j, "auto");\n'
        '        if(ctl && ctl.qBtn){ ctl.qBtn.textContent = "Auto"; }\n'
        '        // V26.2-bot42: the telemetry moved to LEVEL_SWITCHED - it\n'
        '        // fires only after the REAL rendition switch.\n'
        '      }\n'
        '    }];\n'
        '    for(var i = 0; i < levels.length; i++){\n'
        '      (function(idx, lv){\n'
        '        var label = (lv && lv.height ? lv.height + "p"\n'
        '          : (lv && lv.bitrate ? Math.round(lv.bitrate / 1000) + "k"\n'
        '            : ("Level " + (idx + 1))));\n'
        '        items.push({\n'
        '          label: label, id: String(idx),\n'
        '          checked: (__hls.currentLevel === idx),\n'
        '          onSelect: function(){\n'
        '            try{ __hls.currentLevel = idx; }catch(e){}\n'
        '            saveQualityPref(j, String(idx));\n'
        '            if(ctl && ctl.qBtn){ ctl.qBtn.textContent = label; }\n'
        '            // V26.2-bot42: the telemetry moved to LEVEL_SWITCHED - it\n'
        '            // fires only after the REAL rendition switch.\n'
        '          }\n'
        '        });\n'
        '      })(i, levels[i]);\n'
        '    }\n'
        '    ctl.qualityItems = function(){\n'
        '      for(var n = 0; n < items.length; n++){\n'
        '        var it = items[n];\n'
        '        it.checked = (it.id === "auto")\n'
        '          ? (__hls.currentLevel < 0)\n'
        '          : (__hls.currentLevel === parseInt(it.id, 10));\n'
        '      }\n'
        '      return items;\n'
        '    };\n'
        '    ctl.qBtn.hidden = false;\n'
        '  }\n'
        '  function parseMasterRenditions(txt){\n'
        '    // V26 FINAL (Part 4): parse the REAL rendition set from the\n'
        '    // authenticated master playlist — #EXT-X-STREAM-INF lines +\n'
        '    // their variant URIs. The rendition id is the ladder\n'
        '    // directory name ("720p"); the label comes from the\n'
        '    // RESOLUTION height. Only resolutions that REALLY exist are\n'
        '    // ever shown (no fabricated qualities).\n'
        '    var out = [];\n'
        '    if(!txt){ return out; }\n'
        '    var lines = String(txt).split(/\\r?\\n/);\n'
        '    for(var i = 0; i < lines.length; i++){\n'
        '      if(lines[i].indexOf("#EXT-X-STREAM-INF") !== 0){ continue; }\n'
        '      var uri = "";\n'
        '      for(var k = i + 1; k < lines.length; k++){\n'
        '        var t = lines[k].trim();\n'
        '        if(t && t.charAt(0) !== "#"){ uri = t; break; }\n'
        '      }\n'
        '      var m = /RESOLUTION=(\\d+)x(\\d+)/i.exec(lines[i]);\n'
        '      var h = m ? parseInt(m[2], 10) : 0;\n'
        '      var id = "";\n'
        '      var mm = /^([^\\/?#]+)\\/index\\.m3u8/.exec(uri || "");\n'
        '      if(mm){ id = mm[1]; }\n'
        '      else { id = String(uri || "").replace(/[^0-9a-z]/gi, ""); }\n'
        '      if(!id){ continue; }\n'
        '      out.push({id: id, label: h ? (h + "p") : id});\n'
        '    }\n'
        '    out.sort(function(a, b){\n'
        '      return (parseInt(b.id, 10) || 0) - (parseInt(a.id, 10) || 0);\n'
        '    });\n'
        '    return out;\n'
        '  }\n'
        '  function setupQualityMenuNative(el, j){\n'
        '    if(!ctl){ return; }\n'
        '    // V26 FINAL (Part 4): the Quality button is visible ONLY when\n'
        '    // multiple renditions ACTUALLY exist. The REAL set comes from\n'
        '    // the master playlist itself (the wire "variants" array is the\n'
        '    // server\'s pre-probe preview — for a probe_unavailable source\n'
        '    // it is a conservative placeholder, and the synthetic "auto"\n'
        '    // entry is not a rendition at all). A single-rendition\n'
        '    // manifest keeps the menu hidden.\n'
        '    var master = String(__hlsMaster || j.hls_url || "");\n'
        '    var wire = (j && j.variants && j.variants.length)\n'
        '      ? j.variants : [];\n'
        '    fetch(master, {credentials: "same-origin"}).then(function(r){\n'
        '      return r.ok ? r.text() : "";\n'
        '    }).then(function(txt){\n'
        '      var source = "master";\n'
        '      var renditions = parseMasterRenditions(txt);\n'
        '      if(!renditions.length){\n'
        '        // master unreadable: the wire ladder EXCLUDING the\n'
        '        // synthetic "auto" entry — REAL variants only.\n'
        '        renditions = [];\n'
        '        for(var i = 0; i < wire.length; i++){\n'
        '          if(String(wire[i].id || "") === "auto"){ continue; }\n'
        '          renditions.push(wire[i]);\n'
        '        }\n'
        '        source = "wire";\n'
        '      }\n'
        '      if(renditions.length <= 1){\n'
        '        ctl.qBtn.hidden = true;\n'
        '        return;\n'
        '      }\n'
        '      buildNativeQualityMenu(el, j, renditions, source);\n'
        '    }).catch(function(){\n'
        '      // honest: unknown rendition set → the menu stays hidden.\n'
        '      ctl.qBtn.hidden = true;\n'
        '    });\n'
        '  }\n'
        '  function buildNativeQualityMenu(el, j, renditions, source){\n'
        '    // B18-FINAL (Issue E): re-apply the session-persisted variant.\n'
        '    var st = {currentId: "auto"};\n'
        '    try{\n'
        '      var pv = sessionStorage.getItem(qualityKey(j));\n'
        '      if(pv && pv !== "auto"){\n'
        '        var known = false;\n'
        '        for(var c = 0; c < renditions.length; c++){\n'
        '          if(String(renditions[c].id) === String(pv)){ known = true; }\n'
        '        }\n'
        '        if(known){ st.currentId = pv; }\n'
        '      }\n'
        '    }catch(e){}\n'
        '    var items = [{\n'
        '      label: "Auto", id: "auto", checked: (st.currentId === "auto"),\n'
        '      onSelect: function(){\n'
        '        st.currentId = "auto";\n'
        '        saveQualityPref(j, "auto");\n'
        '        switchNativeVariant(el, j, "auto", "Auto");\n'
        '      }\n'
        '    }];\n'
        '    for(var i = 0; i < renditions.length; i++){\n'
        '      (function(v){\n'
        '        var id = String(v.id || "");\n'
        '        var label = String(v.label || id);\n'
        '        items.push({\n'
        '          label: label, id: id, checked: (id === st.currentId),\n'
        '          onSelect: function(){\n'
        '            st.currentId = id;\n'
        '            saveQualityPref(j, id);\n'
        '            switchNativeVariant(el, j, id, label);\n'
        '          }\n'
        '        });\n'
        '      })(renditions[i]);\n'
        '    }\n'
        '    ctl.qualityItems = function(){\n'
        '      for(var n = 0; n < items.length; n++){\n'
        '        items[n].checked = (items[n].id === st.currentId);\n'
        '      }\n'
        '      return items;\n'
        '    };\n'
        '    ctl.qBtn.hidden = false;\n'
        '    info("WEBSITE_PLAYER_FORMAT quality_source=" + source +\n'
        '      " renditions=" + renditions.length);\n'
        '  }\n'
        '  function switchNativeVariant(el, j, id, label){\n'
        '    // Native HLS level switch: swap master -> the variant playlist\n'
        '    // (the transcode ladder layout) preserving currentTime and the\n'
        '    // play state - honest best-effort (Safari has no JS level API).\n'
        '    var url = variantUrl(__hlsMaster || j.hls_url, id);\n'
        '    if(!url){ return; }\n'
        '    var t = 0, wasPaused = el.paused;\n'
        '    try{ t = el.currentTime || 0; }catch(e){}\n'
        '    // V26 QUALITY_CHANGE telemetry (native path): the actual\n'
        '    // rendition switch + the playback position being preserved.\n'
        '    // BOT-43 (Section 3): the spec-named PLAYER_QUALITY_CHANGE\n'
        '    // twin fires with the same real-switch discipline.\n'
        '    try{ if(window.__siteTel){\n'
        '      window.__siteTel("QUALITY_CHANGE",\n'
        '        {to: String(label || id), position_s: t});\n'
        '      window.__siteTel("PLAYER_QUALITY_CHANGE",\n'
        '        {to: String(label || id), position_s: t});\n'
        '    } }catch(e){}\n'
        '    var onMeta = function(){\n'
        '      el.removeEventListener("loadedmetadata", onMeta);\n'
        '      try{\n'
        '        if(t > 0 && t < (el.duration || Infinity)){\n'
        '          el.currentTime = t;\n'
        '        }\n'
        '      }catch(e){}\n'
        '        // V25 (§9): the source swap resets playbackRate on some\n'
        '        // engines — re-apply the persisted speed so a quality\n'
        '        // switch never silently drops the user’s setting.\n'
        '        try{\n'
        '          var vr = 1;\n'
        '          if(ctl && ctl.speedKey){\n'
        '            vr = parseFloat(sessionStorage.getItem(ctl.speedKey)) || 1;\n'
        '          }\n'
        '          if(isFinite(vr) && vr > 0){ el.playbackRate = vr; }\n'
        '        }catch(e){}\n'
        '      if(!wasPaused){\n'
        '        var p = el.play();\n'
        '        if(p && p.catch){ p.catch(function(){}); }\n'
        '      }\n'
        '    };\n'
        '    el.addEventListener("loadedmetadata", onMeta);\n'
        '    el.src = url;\n'
        '    try{ el.load(); }catch(e){}\n'
        '    if(ctl && ctl.qBtn){ ctl.qBtn.textContent = label; }\n'
        '  }\n'
        '  // ---- BOT-16 Work Item C.4: the in-player Join Required gate ------\n'
        '  function fjRowHtml(ch){\n'
        '    var state = String(ch.state || "");\n'
        '    if(!state){\n'
        '      var ver = String(ch.verification || "");\n'
        '      state = (ver === "unavailable")\n'
        '        ? (ch.url ? "api_temporary_failure" : "invalid_channel")\n'
        '        : "not_joined";\n'
        '    }\n'
        '    var title = safe(ch.title || "Channel");\n'
        '    var url = String(ch.url || "");\n'
        '    var badgeText = {\n'
        '      "not_joined": "Not joined",\n'
        '      "api_temporary_failure": "Check unavailable",\n'
        '      "invalid_channel": "Unavailable",\n'
        '      "bot_permission_failure": "Unavailable"\n'
        '    }[state] || "Not joined";\n'
        '    var bcls = {\n'
        '      "api_temporary_failure": " warn",\n'
        '      "invalid_channel": " dead",\n'
        '      "bot_permission_failure": " dead"\n'
        '    }[state] || "";\n'
        '    var badge = "<span class=\\"fjbadge" + bcls + "\\">" +\n'
        '      safe(badgeText) + "</span>";\n'
        '    var action = "";\n'
        '    if(state === "not_joined" || state === "api_temporary_failure"){\n'
        '      // BOT-16: a TRANSIENT verification failure still renders the Join\n'
        '      // button - the stored invite URL keeps working for users\n'
        '      // regardless of bot access (bot-side semantics).\n'
        '      if(url){\n'
        '        action = "<a class=\\"joinbtn\\" href=\\"" + safe(url) +\n'
        '          "\\" target=\\"_blank\\" rel=\\"noopener noreferrer\\">" +\n'
        '          ICONS.external + " Join Channel</a>";\n'
        '      } else {\n'
        '        action = "<span class=\\"joinbtn dead\\">" + ICONS.lock +\n'
        '          " Join in Telegram</span>";\n'
        '      }\n'
        '    } else {\n'
        '      action = "<span class=\\"joinbtn dead\\">Unavailable</span>";\n'
        '    }\n'
        '    var note = "";\n'
        '    if(state === "api_temporary_failure"){\n'
        '      note = "<span class=\\"fjnote\\">We could not verify just now " +\n'
        '        "\\u2014 join, then tap Verify.</span>";\n'
        '    }\n'
        '    return "<li class=\\"fjrow\\"><span class=\\"fjtitle\\">" + title +\n'
        '      "</span>" + badge + action + note + "</li>";\n'
        '  }\n'
        '  function renderFjGate(j){\n'
        '    // NO t.me bot link on this path: the tgButton Telegram CTA stays\n'
        '    // reserved for genuine Get File flows and media errors.\n'
        '    clearActions();\n'
        '    teardownMedia();\n'
        '    wrap.hidden = false;\n'
        '    show("locked", ICONS.lock + "<span>Join to watch</span>",\n'
        '      safe(j.requirement ||\n'
        '        "Join the required channel(s) to watch this video."));\n'
        '    var gate = document.createElement("div");\n'
        '    gate.className = "fjgate";\n'
        '    gate.id = "fjgate";\n'
        '    var h = document.createElement("h2");\n'
        '    h.innerHTML = ICONS.lock + "<span>Join to watch</span>";\n'
        '    gate.appendChild(h);\n'
        '    var sub = document.createElement("p");\n'
        '    sub.className = "loginlead";\n'
        '    sub.textContent = String(j.requirement ||\n'
        '      "Join the required channel(s) to watch this video.");\n'
        '    gate.appendChild(sub);\n'
        '    var fh = (j.fj_health || {});\n'
        '    var healthy = parseInt(fh.healthy, 10);\n'
        '    var total = parseInt(fh.total, 10);\n'
        '    if(String(fh.fj_health || "") === "degraded" ||\n'
        '        (total > 0 && healthy < total)){\n'
        '      var hb = document.createElement("div");\n'
        '      hb.className = "fjhealth";\n'
        '      hb.setAttribute("role", "status");\n'
        '      hb.textContent = "Force Join: " + (isNaN(healthy) ? 0 : healthy) +\n'
        '        "/" + (isNaN(total) ? 0 : total) +\n'
        '        " channels verifiable right now.";\n'
        '      gate.appendChild(hb);\n'
        '    }\n'
        '    var list = document.createElement("ul");\n'
        '    list.className = "fjrows";\n'
        '    list.id = "fjgatelist";\n'
        '    list.innerHTML = (j.not_joined || []).map(fjRowHtml).join("");\n'
        '    gate.appendChild(list);\n'
        '    var verify = document.createElement("button");\n'
        '    verify.type = "button";\n'
        '    verify.className = "verifybtn";\n'
        '    verify.id = "fjplayverify";\n'
        '    verify.textContent = "Verify Membership";\n'
        '    gate.appendChild(verify);\n'
        '    var state = document.createElement("div");\n'
        '    state.className = "loginstate";\n'
        '    state.id = "fjgatestate";\n'
        '    state.setAttribute("aria-live", "polite");\n'
        '    gate.appendChild(state);\n'
        '    pbox.appendChild(gate);\n'
        '    fjGateEl = gate;\n'
        '    // BOT-16 FIX — the player box has no intrinsic height until a\n'
        '    // media element mounts (the poster <img>/video provides it).\n'
        '    // With ONLY the gate rendered the box collapsed to ~2px, so\n'
        '    // the absolutely-positioned gate (inset:0) rendered its content\n'
        '    // OUTSIDE the click-able surface — the Verify Membership button\n'
        '    // was unclickable (C7e browser-QA reproduction). Give the box a\n'
        '    // real media-shaped height while gated; mountPlayer removes it.\n'
        '    try{ pbox.classList.add("gated"); }catch(e){}\n'
        '    verify.addEventListener("click", function(){\n'
        '      verify.disabled = true;\n'
        '      state.hidden = false;\n'
        '      state.className = "loginstate";\n'
        '      state.textContent = "Checking your membership\\u2026";\n'
        '      // V26 FINAL (Part 8): the site-action lifecycle telemetry.\n'
        '      var act = function(kind, reason){\n'
        '        try{ if(window.__siteTel){\n'
        '          var f = {action: "fj_verify"};\n'
        '          if(reason){ f.reason = String(reason).slice(0, 64); }\n'
        '          window.__siteTel("SITE_ACTION_" + kind, f);\n'
        '        } }catch(e){}\n'
        '      };\n'
        '      act("START");\n'
        '      var id = "";\n'
        '      try{ id = (tg && tg.initData) || ""; }catch(e){}\n'
        '      fetch(API_FJ_VERIFY, {\n'
        '        method: "POST",\n'
        '        headers: {"Content-Type": "application/json"},\n'
        '        body: JSON.stringify({init_data: id, gate_key: FJ_GATE_KEY})\n'
        '      }).then(function(r){ return r.json(); }).then(function(v){\n'
        '        // BOT-43 (Section 4 - the AUTHORITATIVE contract): the\n'
        '        // server returns the unambiguous completed state\n'
        '        // {ok:true, joined:true, remaining:[], complete:true}.\n'
        '        // Either joined=true OR the explicit complete=true flag\n'
        '        // decides - and the cleanup happens HERE, not deferred to\n'
        '        // mountPlayer: the gate, its Join rows/buttons and the\n'
        '        // stale verification message are removed IMMEDIATELY, the\n'
        '        // player box shows the honest preparing spinner while the\n'
        '        // stream re-issues (requestStream clears the gate again\n'
        '        // defensively), and NO non-mount outcome below can leave\n'
        '        // the old batch visible again.\n'
        '        if(v && v.ok && (v.joined || v.complete === true)){\n'
        '          act("SUCCESS");\n'
        '          clearFjGateUI();\n'
        '          showLoading("Preparing your stream\\u2026");\n'
        '          // re-issue the stream and mount the player IN PLACE (no page\n'
        '          // reload, no Telegram redirect).\n'
        '          requestStream();\n'
        '          return;\n'
        '        }\n'
        '        if(v && v.ok && v.not_joined && v.not_joined.length){\n'
        '          // update the channel list in place, highlighting what remains.\n'
        '          act("FAILED", "not_joined_" + v.not_joined.length);\n'
        '          list.innerHTML = v.not_joined.map(fjRowHtml).join("");\n'
        '          state.className = "loginstate bad";\n'
        '          state.textContent = "Still missing " + v.not_joined.length +\n'
        '            " channel" + (v.not_joined.length > 1 ? "s" : "") +\n'
        '            ". Join them, then verify again.";\n'
        '          verify.disabled = false;\n'
        '          return;\n'
        '        }\n'
        '        // honest failure - never unlocks, never claims joined.\n'
        '        act("FAILED", "verify_failed");\n'
        '        state.className = "loginstate bad";\n'
        '        state.textContent = (v && v.verify_hint)\n'
        '          ? String(v.verify_hint)\n'
        '          : "Couldn\\u2019t verify right now \\u2014 try again.";\n'
        '        verify.disabled = false;\n'
        '      }).catch(function(){\n'
        '        act("FAILED", "network_error");\n'
        '        state.className = "loginstate bad";\n'
        '        state.textContent = "Network error \\u2014 try again.";\n'
        '        verify.disabled = false;\n'
        '      });\n'
        '    });\n'
        '  }\n'
        '  // ---- BOT-16 Work Item C.2: the custom control bar ----------------\n'
        '  // V25 (§10): the canonical speed ladder — 1× is Normal;\n'
        '  // every stored-value read falls back to 1× when invalid.\n'
        '  var SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];\n'
        '  function speedKey(j){\n'
        '    var uid = (j && j.user && j.user.id) ? String(j.user.id) : "0";\n'
        '    return "plspeed:" + uid;\n'
        '  }\n'
        '  // B18-FINAL (Issue E): the quality selection persists through the\n'
        '  // CURRENT browser session (sessionStorage — a new tab/session\n'
        '  // starts fresh on Auto). Scoped to the user, mirroring speedKey.\n'
        '  function qualityKey(j){\n'
        '    var uid = (j && j.user && j.user.id) ? String(j.user.id) : "0";\n'
        '    return "plquality:" + uid;\n'
        '  }\n'
        '  function loadQualityPref(j){\n'
        '    try{\n'
        '      var v = sessionStorage.getItem(qualityKey(j));\n'
        '      if(v === "auto"){ return -1; }\n'
        '      var n = parseInt(v, 10);\n'
        '      return (isFinite(n) && n >= 0) ? n : -1;\n'
        '    }catch(e){ return -1; }\n'
        '  }\n'
        '  function saveQualityPref(j, v){\n'
        '    try{ sessionStorage.setItem(qualityKey(j), String(v)); }catch(e){}\n'
        '  }\n'
        '  function applySpeed(el, rate, userInitiated){\n'
        '    try{ el.playbackRate = rate; }catch(e){}\n'
        '    if(ctl && ctl.speedBtn){\n'
        '      ctl.speedBtn.textContent = rate + "\\u00D7";\n'
        '      ctl.speedBtn.classList.toggle("ctl-on", rate !== 1);\n'
        '      var items = ctl.menu\n'
        '        ? ctl.menu.querySelectorAll("[data-rate]") : [];\n'
        '      for(var i = 0; i < items.length; i++){\n'
        '        items[i].setAttribute("aria-checked",\n'
        '          (parseFloat(items[i].getAttribute("data-rate")) === rate)\n'
        '            ? "true" : "false");\n'
        '        var mk = items[i].querySelector(".mcheck");\n'
        '        if(mk){\n'
        '          mk.style.visibility =\n'
        '            (parseFloat(items[i].getAttribute("data-rate")) === rate)\n'
        '              ? "visible" : "hidden";\n'
        '        }\n'
        '      }\n'
        '    }\n'
        '    try{ sessionStorage.setItem(ctl.speedKey, String(rate)); }catch(e){}\n'
        '    // BOT-43 (Section 3): PLAYER_SPEED_CHANGE fires on USER speed\n'
        '    // changes only (the boot-time persisted-rate restore passes no\n'
        '    // userInitiated flag - no per-mount noise).\n'
        '    if(userInitiated){\n'
        '      try{ if(window.__siteTel){\n'
        '        var _sp = 0; try{ _sp = el.currentTime || 0; }catch(e2){}\n'
        '        window.__siteTel("PLAYER_SPEED_CHANGE",\n'
        '          {to: rate, position_s: _sp});\n'
        '      } }catch(e){}\n'
        '    }\n'
        '  }\n'
        '  // V25 (§11): the TWO-LEVEL settings menu. The gear opens the\n'
        '  // ROOT (Quality -> <current> / Playback speed -> <current>);\n'
        '  // tapping a row opens its SUBMENU with a real "Back <name>"\n'
        '  // back row. Selecting an option applies + closes everything;\n'
        '  // Esc / the back row close the DEEPEST level first; an outside\n'
        '  // tap closes all. Every row is a real 44px+ button (no\n'
        '  // concatenation, no clipping — placeMenu keeps the sheet inside\n'
        '  // the player viewport, safe-area aware on phones).\n'
        '  var menuLevel = 0;   // 0 = root, 1 = submenu\n'
        '  function openMenu(items, back){\n'
        '    if(!ctl || !ctl.menu){ return; }\n'
        '    menuLevel = back ? 1 : 0;\n'
        '    if(!back){ ctl.menuRoot = items; }\n'
        '    ctl.menu.innerHTML = "";\n'
        '    if(back){\n'
        '      var bb = document.createElement("button");\n'
        '      bb.type = "button";\n'
        '      bb.className = "pctlmback";\n'
        '      bb.setAttribute("role", "menuitem");\n'
        '      bb.setAttribute("aria-label", "Back to " + back.label);\n'
        '      var bchev = document.createElement("span");\n'
        '      bchev.className = "mchev";\n'
        '      bchev.innerHTML = ICONS.chev;\n'
        '      bb.appendChild(bchev);\n'
        '      var btitle = document.createElement("span");\n'
        '      btitle.className = "pctlmtitle";\n'
        '      btitle.textContent = back.label;\n'
        '      bb.appendChild(btitle);\n'
        '      bb.addEventListener("click", function(ev){\n'
        '        ev.stopPropagation();\n'
        '        openMenu(back.items, back.parent || null);\n'
        '      });\n'
        '      ctl.menu.appendChild(bb);\n'
        '    }\n'
        '    for(var i = 0; i < items.length; i++){\n'
        '      (function(item){\n'
        '        if(item.group){\n'
        '          // B17: a section heading inside the mobile Settings sheet.\n'
        '          var g = document.createElement("div");\n'
        '          g.className = "pctlmgroup";\n'
        '          g.setAttribute("role", "presentation");\n'
        '          g.textContent = item.group;\n'
        '          ctl.menu.appendChild(g);\n'
        '          return;\n'
        '        }\n'
        '        var b = document.createElement("button");\n'
        '        b.type = "button";\n'
        '        b.className = "pctlmitem";\n'
        '        b.setAttribute("role", (item.action || item.sub) ? "menuitem"\n'
        '          : "menuitemradio");\n'
        '        if(!item.action && !item.sub){\n'
        '          b.setAttribute("aria-checked",\n'
        '            item.checked ? "true" : "false");\n'
        '        }\n'
        '        if(item.rate != null){\n'
        '          b.setAttribute("data-rate", String(item.rate));\n'
        '        }\n'
        '        if(item.id != null){\n'
        '          b.setAttribute("data-qid", String(item.id));\n'
        '        }\n'
        '        var label = document.createElement("span");\n'
        '        label.className = "mlabel";\n'
        '        label.textContent = item.label;\n'
        '        b.appendChild(label);\n'
        '        if(item.value != null){\n'
        '          var val = document.createElement("span");\n'
        '          val.className = "mval";\n'
        '          val.textContent = String(item.value);\n'
        '          b.appendChild(val);\n'
        '        }\n'
        '        if(item.sub){\n'
        '          // V25 (§11): a navigable row — chevron affordance, opens\n'
        '          // the submenu (traversal, not a selection).\n'
        '          var chev = document.createElement("span");\n'
        '          chev.className = "mchev";\n'
        '          chev.innerHTML = ICONS.chev;\n'
        '          b.appendChild(chev);\n'
        '          b.addEventListener("click", function(ev){\n'
        '            ev.stopPropagation();\n'
        '            openMenu(item.sub, {label: item.label, items: items,\n'
        '                                parent: null});\n'
        '          });\n'
        '        } else {\n'
        '          var mark = document.createElement("span");\n'
        '          mark.className = "mcheck";\n'
        '          mark.innerHTML = ICONS.check;\n'
        '          if(!item.checked){ mark.style.visibility = "hidden"; }\n'
        '          b.appendChild(mark);\n'
        '          b.addEventListener("click", function(ev){\n'
        '            ev.stopPropagation();\n'
        '            closeMenu();\n'
        '            if(item.onSelect){ item.onSelect(); }\n'
        '          });\n'
        '        }\n'
        '        ctl.menu.appendChild(b);\n'
        '      })(items[i]);\n'
        '    }\n'
        '    placeMenu();\n'
        '    ctl.menu.hidden = false;\n'
        '    if(ctl.wake){ try{ ctl.wake(); }catch(e){} }\n'
        '    __syncMenuHistory();\n'
        '  }\n'
        '  function placeMenu(){\n'
        '    // B17 UX FIX: anchor the popover to the PLAYER BOX — the live\n'
        '    // bar height clears it and the max-height NEVER exceeds the\n'
        '    // real space above the bar. (The old CSS-only % max-height\n'
        '    // resolved against the BAR and clipped the menu to ~one\n'
        '    // item — a genuinely broken popover.)\n'
        '    if(!ctl || !ctl.menu){ return; }\n'
        '    var menu = ctl.menu;\n'
        '    var barH = ctl.bar ? ctl.bar.offsetHeight : 0;\n'
        '    menu.style.bottom = (barH + 10) + "px";\n'
        '    var space = pbox.clientHeight - barH - 20;\n'
        '    // V25 fix (browser-caught at 390px): the old 96px floor let the\n'
        '    // scrollable menu collapse to ~1 visible row under the STICKY\n'
        '    // back row (position:sticky;top:0) — the speed options were\n'
        '    // effectively untappable on mobile player sizes. A 200px floor\n'
        '    // keeps ~4 rows cleanly reachable below the sticky header; the\n'
        '    // popover may transiently cover the video (standard player UX).\n'
        '    menu.style.maxHeight = Math.max(200, Math.min(320, space)) + "px";\n'
        '  }\n'
        '  function closeMenu(){\n'
        '    if(ctl && ctl.menu){ ctl.menu.hidden = true; }\n'
        '    menuLevel = 0;\n'
        '    if(ctl && ctl.wake){ try{ ctl.wake(); }catch(e){} }\n'
        '    __syncMenuHistory();\n'
        '  }\n'
        '  function menuBack(){\n'
        '    // V25 (§11): Esc/Back close the SUBMENU first — only a second\n'
        '    // close dismisses the settings sheet entirely.\n'
        '    if(menuOpen() && menuLevel > 0 && ctl && ctl.menuRoot){\n'
        '      openMenu(ctl.menuRoot, null);\n'
        '      return true;\n'
        '    }\n'
        '    return false;\n'
        '  }\n'
        '  function menuOpen(){\n'
        '    return !!(ctl && ctl.menu && !ctl.menu.hidden);\n'
        '  }\n'
        '  // V26 PLAYER BACK SEMANTICS — the menu layer sentinels. The\n'
        '  // settings sheet root and the open submenu each own ONE real\n'
        '  // history entry, so browser/Telegram Back closes exactly one\n'
        '  // level (submenu -> settings root -> player) WITHOUT navigating:\n'
        '  //   * openMenu/closeMenu call __syncMenuHistory() so the history\n'
        '  //     stack always matches the visible menu state;\n'
        '  //   * a UI close pops its own sentinel silently (the nav layer\\u2019s\n'
        '  //     pending-pop guard — never a loop);\n'
        '  //   * a Back press pops the top sentinel and runs the closer\n'
        '  //     (menuBack first, then closeMenu) — one level per press.\n'
        '  function __menuLayerCloser(){\n'
        '    if(menuOpen()){\n'
        '      if(!menuBack()){ closeMenu(); }\n'
        '    }\n'
        '  }\n'
        '  function __syncMenuHistory(){\n'
        '    var nav = window.__SITE_NAV__;\n'
        '    if(!nav || !nav.pushLayer || !nav.layerCount){ return; }\n'
        '    var want = menuOpen() ? (1 + (menuLevel > 0 ? 1 : 0)) : 0;\n'
        '    var have = nav.layerCount("menu");\n'
        '    while(have < want){\n'
        '      nav.pushLayer("menu", __menuLayerCloser); have++;\n'
        '    }\n'
        '    // Pop only when the MENU layers are the TOP of the stack (LIFO\n'
        '    // clean). A fullscreen layer above the menu is left alone (the\n'
        '    // stale sentinel costs one inert Back press at most — bounded).\n'
        '    while(have > want && __navTopIs("menu")){\n'
        '      nav.popLayer(); have--;\n'
        '    }\n'
        '  }\n'
        '  function __navTopIs(type){\n'
        '    var nav = window.__SITE_NAV__;\n'
        '    return !!(nav && nav.layerTop && nav.layerTop() === type);\n'
        '  }\n'
        '  function fsElement(){\n'
        '    return document.fullscreenElement ||\n'
        '      document.webkitFullscreenElement || null;\n'
        '  }\n'
        '  function tgWebApp(){\n'
        '    try{ return (window.Telegram && window.Telegram.WebApp) || null; }\n'
        '    catch(e){ return null; }\n'
        '  }\n'
        '  function tgFullscreenApi(){\n'
        '    // B23 §4.4 — the REAL Telegram Mini App fullscreen API\n'
        '    // (Bot API 8.0+: requestFullscreen / exitFullscreen /\n'
        '    // isFullscreen / fullscreenChanged / fullscreenFailed).\n'
        '    var tg = tgWebApp();\n'
        '    if(!tg || !tg.requestFullscreen || !tg.exitFullscreen){\n'
        '      return null;\n'
        '    }\n'
        '    try{\n'
        '      if(tg.isVersionAtLeast && !tg.isVersionAtLeast("8.0")){\n'
        '        return null;\n'
        '      }\n'
        '    }catch(e){ /* presence is the gate when unversioned */ }\n'
        '    return tg;\n'
        '  }\n'
        '  // ---- V25 (§13/§14): the CANONICAL fullscreen state machine -----\n'
        '  // NORMAL -> MINI_APP_FULLSCREEN -> VIDEO_FULLSCREEN (layered),\n'
        '  // with the canonical exit path VIDEO_FULLSCREEN ->\n'
        '  // MINI_APP_FULLSCREEN -> NORMAL. The player fullscreen button\n'
        '  // NEVER tears down the Telegram Mini App fullscreen layer: when\n'
        '  // the Mini App is already fullscreen the player expands INSIDE\n'
        '  // that viewport (.fsfake only — no competing browser fullscreen,\n'
        '  // which would make the Telegram fullscreen disappear), and\n'
        '  // exiting video fullscreen KEEPS the Mini App fullscreen (only\n'
        '  // the Telegram client\\u2019s own control / Esc exits that layer).\n'
        '  var tgFsIntent = false;   // OUR button requested Mini App fullscreen\n'
        '  var __fsDocHandlers = []; // V25 (§16): named document handlers\n'
        '  var __fsTgEvents = [];    // V25 (§16): tg.onEvent registrations\n'
        '  function fsState(){\n'
        '    if(fsElement() || fsFakeActive()){ return "video"; }\n'
        '    if(tgIsFullscreen()){ return "miniapp"; }\n'
        '    return "normal";\n'
        '  }\n'
        '  function requestMiniAppFullscreen(){\n'
        '    // Path 0 (§4.4): the Mini App OWN fullscreen API (Bot API 8.0+).\n'
        '    // B24 fix carried forward: Telegram Mini App fullscreen is\n'
        '    // OUT-OF-BAND — it does NOT trigger the browser :fullscreen\n'
        '    // pseudo-class, so the .stage/<video> clamps (max-height:\n'
        '    // min(76vh,640px)) would STAY in force while the WebView is\n'
        '    // resized to fill the screen → the player SHRINKS inside a\n'
        '    // now-larger canvas. The fix engages the SAME .fsfake CSS state\n'
        '    // the pseudo path uses (position:fixed;inset:0) so the clamps\n'
        '    // lift; the icon stays truthful via the fullscreenChanged\n'
        '    // listener below. V25: the intent flag distinguishes OUR\n'
        '    // request from a Telegram-UI-initiated expand (§13).\n'
        '    var tg = tgFullscreenApi();\n'
        '    if(!tg){ return false; }\n'
        '    try{\n'
        '      tgFsIntent = true;\n'
        '      var p = tg.requestFullscreen();\n'
        '      if(p && p.then){\n'
        '        p.then(function(){\n'
        '          tgFsIntent = false;\n'
        '          enterFakeFullscreen();\n'
        '          updateFsIcon();\n'
        '          info("WEBSITE_FULLSCREEN_ENTER source=telegram_api");\n'
        '        })\n'
        '         .catch(function(err){\n'
        '           tgFsIntent = false;\n'
        '           info("WEBSITE_FULLSCREEN_FAILURE source=telegram_api detail=" +\n'
        '             String((err && err.message) || "unknown")\n'
        '               .slice(0, 90));\n'
        '           tryContainerFullscreen();\n'
        '         });\n'
        '      }\n'
        '      updateFsIcon();\n'
        '      return true;\n'
        '    }catch(e){\n'
        '      tgFsIntent = false;\n'
        '      info("WEBSITE_FULLSCREEN_FAILURE source=telegram_api_throw");\n'
        '      return false;\n'
        '    }\n'
        '  }\n'
        '  function toggleFullscreen(){\n'
        '    // THE player fullscreen button (V25 §13): toggles the VIDEO\n'
        '    // layer only — the Mini App fullscreen layer is never exited\n'
        '    // here (the old code called tg.exitFullscreen() when the Mini\n'
        '    // App was ALREADY fullscreen: MINI_APP -> NORMAL -> (re-enter),\n'
        '    // the exact state-conflict V25 fixes).\n'
        '    if(fsElement() || fsFakeActive()){\n'
        '      exitVideoFullscreen();\n'
        '      updateFsIcon();\n'
        '      return;\n'
        '    }\n'
        '    if(tgIsFullscreen()){\n'
        '      // §14: Telegram fullscreen is ACTIVE -> expand the player\n'
        '      // INSIDE the Mini App viewport. NO element.requestFullscreen()\n'
        '      // (a competing browser fullscreen makes the Telegram\n'
        '      // fullscreen disappear) and NO tg.requestFullscreen()\n'
        '      // (already fullscreen).\n'
        '      enterFakeFullscreen();\n'
        '      updateFsIcon();\n'
        '      info("WEBSITE_FULLSCREEN_ENTER source=inside_miniapp_fullscreen");\n'
        '      return;\n'
        '    }\n'
        '    if(requestMiniAppFullscreen()){ return; }\n'
        '    if(tgWebApp()){\n'
        '      // A.1 (bot-25): inside Telegram WITHOUT the 8.0 API the CSS\n'
        '      // pseudo-fullscreen is the DIRECT path (the container/video\n'
        '      // element chain is NEVER tried there).\n'
        '      if(fsFakeActive()){ exitFakeFullscreen(); }\n'
        '      else{ enterFakeFullscreen(); }\n'
        '      updateFsIcon();\n'
        '      return;\n'
        '    }\n'
        '    tryContainerFullscreen();\n'
        '  }\n'
        '  function exitVideoFullscreen(){\n'
        '    // V25 §13 canonical exit: VIDEO_FULLSCREEN -> MINI_APP_FULLSCREEN\n'
        '    // when the Mini App is fullscreen, else -> NORMAL. The Mini App\n'
        '    // layer is INTENTIONALLY preserved (only the Telegram client\\u2019s\n'
        '    // own control or the Esc layering exits it).\n'
        '    if(fsElement()){\n'
        '      if(document.exitFullscreen){ document.exitFullscreen(); }\n'
        '      else if(document.webkitExitFullscreen){\n'
        '        document.webkitExitFullscreen();\n'
        '      }\n'
        '    }\n'
        '    exitFakeFullscreen();\n'
        '    info("WEBSITE_FULLSCREEN_EXIT source=player_button " +\n'
        '      "mini_app_fullscreen=" + (tgIsFullscreen() ? "kept" : "off"));\n'
        '  }\n'
        '  function tryContainerFullscreen(){\n'
        '    var target = pbox;\n'
        '    if(fsElement()){\n'
        '      if(document.exitFullscreen){ document.exitFullscreen(); }\n'
        '      else if(document.webkitExitFullscreen){\n'
        '        document.webkitExitFullscreen();\n'
        '      }\n'
        '      return;\n'
        '    }\n'
        '    if(fsFakeActive()){\n'
        '      exitFakeFullscreen();\n'
        '      updateFsIcon();\n'
        '      return;\n'
        '    }\n'
        '    if(target && target.requestFullscreen){\n'
        '      try{\n'
        '        var p;\n'
        '        try{ p = target.requestFullscreen(); }catch(e){ p = null; }\n'
        '        if(p && p.then){\n'
        '          p.then(function(){ lockLandscape(); }).catch(function(err){\n'
        '            info("fullscreen_rejected=container detail=" +\n'
        '              String((err && err.message) || "unknown").slice(0, 90));\n'
        '            tryVideoFullscreen();\n'
        '          });\n'
        '          return;\n'
        '        }\n'
        '        if(p !== undefined && p !== null){\n'
        '          lockLandscape();\n'
        '          return;\n'
        '        }\n'
        '      }catch(e){}\n'
        '    }\n'
        '    if(target && target.webkitRequestFullscreen){\n'
        '      try{ target.webkitRequestFullscreen(); return; }catch(e){}\n'
        '    }\n'
        '    tryVideoFullscreen();\n'
        '  }\n'
        '  function tryVideoFullscreen(){\n'
        '    // Path 2 — the MEDIA ELEMENT itself. Android WebView commonly\n'
        '    // hands the video to the native player even when element\n'
        '    // fullscreen is unsupported; iOS Safari uses the native video\n'
        '    // fullscreen (webkitEnterFullscreen). A REJECTED media-element\n'
        '    // request falls THROUGH to the CSS pseudo-fullscreen (the\n'
        '    // FINAL-1 rejection-aware fix — a rejecting requestFullscreen\n'
        '    // must never end the chain in silence).\n'
        '    var v = mediaEl;\n'
        '    if(!v){ fallbackFakeFullscreen(); return; }\n'
        '    try{\n'
        '      if(v.requestFullscreen){\n'
        '        var vp;\n'
        '        try{ vp = v.requestFullscreen(); }catch(e){ vp = null; }\n'
        '        if(vp && vp.then){\n'
        '          vp.then(function(){ lockLandscape(); }).catch(function(err){\n'
        '            info("fullscreen_rejected=video_element detail=" +\n'
        '              String((err && err.message) || "unknown").slice(0, 90));\n'
        '            fallbackFakeFullscreen();\n'
        '          });\n'
        '          return;\n'
        '        }\n'
        '        if(vp !== undefined && vp !== null){\n'
        '          lockLandscape();\n'
        '          return;\n'
        '        }\n'
        '      }\n'
        '      if(v.webkitRequestFullscreen){ v.webkitRequestFullscreen(); return; }\n'
        '      if(v.webkitEnterFullscreen){ v.webkitEnterFullscreen(); return; }\n'
        '    }catch(e){}\n'
        '    fallbackFakeFullscreen();\n'
        '  }\n'
        '  function fsFakeActive(){\n'
        '    return !!(pbox && pbox.classList &&\n'
        '      pbox.classList.contains("fsfake"));\n'
        '  }\n'
        '  function enterFakeFullscreen(){\n'
        '    // A.1 (bot-25): BOTH <body> AND <html> get the scroll lock\n'
        '    // (html scroll containment — no shrink/expand jump while the\n'
        '    // pinned player box is up).\n'
        '    if(!pbox || !pbox.classList){ return false; }\n'
        '    pbox.classList.add("fsfake");\n'
        '    if(document.body && document.body.classList){\n'
        '      document.body.classList.add("fsfake-scroll-lock");\n'
        '    }\n'
        '    if(document.documentElement){\n'
        '      document.documentElement.classList.add("fsfake-scroll-lock");\n'
        '    }\n'
        '    lockLandscape();\n'
        '    if(ctl && ctl.wake){ try{ ctl.wake(); }catch(e){} }\n'
        '    placeMenu();\n'
        '    return true;\n'
        '  }\n'
        '  function exitFakeFullscreen(){\n'
        '    // A.1 (bot-25): symmetric unlock on BOTH <body> and <html>.\n'
        '    if(pbox && pbox.classList){ pbox.classList.remove("fsfake"); }\n'
        '    if(document.body && document.body.classList){\n'
        '      document.body.classList.remove("fsfake-scroll-lock");\n'
        '    }\n'
        '    if(document.documentElement){\n'
        '      document.documentElement.classList.remove("fsfake-scroll-lock");\n'
        '    }\n'
        '    try{\n'
        '      if(screen && screen.orientation && screen.orientation.unlock){\n'
        '        screen.orientation.unlock();\n'
        '      }\n'
        '    }catch(e){}\n'
        '    placeMenu();\n'
        '  }\n'
        '  function fallbackFakeFullscreen(){\n'
        '    if(enterFakeFullscreen()){\n'
        '      updateFsIcon();\n'
        '      fsToast("Pseudo-fullscreen — this view does not support " +\n'
        '        "real fullscreen.");\n'
        '      return;\n'
        '    }\n'
        '    fsToast("Fullscreen is not available in this view");\n'
        '  }\n'
        '  function fsToast(msg){\n'
        '    // transient in-player notice — the honest failure surface\n'
        '    // (never a silent no-op). role=status for screen readers.\n'
        '    try{\n'
        '      var old = document.getElementById("pfsnote");\n'
        '      if(old && old.parentNode){ old.parentNode.removeChild(old); }\n'
        '      var el = document.createElement("div");\n'
        '      el.id = "pfsnote";\n'
        '      el.className = "pfsnote";\n'
        '      el.setAttribute("role", "status");\n'
        '      el.textContent = msg;\n'
        '      (pbox || document.body).appendChild(el);\n'
        '      setTimeout(function(){\n'
        '        if(el && el.parentNode){ el.parentNode.removeChild(el); }\n'
        '      }, 2600);\n'
        '    }catch(e){}\n'
        '  }\n'
        '  function lockLandscape(){\n'
        '    // best-effort landscape lock on mobile (ignored where unsupported)\n'
        '    try{\n'
        '      if(screen && screen.orientation && screen.orientation.lock){\n'
        '        var p = screen.orientation.lock("landscape");\n'
        '        if(p && p.catch){ p.catch(function(){}); }\n'
        '      }\n'
        '    }catch(e){}\n'
        '  }\n'
        '  function tgIsFullscreen(){\n'
        '    var tg = tgWebApp();\n'
        '    try{ return !!(tg && tg.isFullscreen); }catch(e){ return false; }\n'
        '  }\n'
        '  // TASK G (BOT-45/46 §10 — TRUE player-only fullscreen): the\n'
        '  // body-level CHROME state. While EITHER fullscreen surface is\n'
        '  // active (the real Fullscreen API element OR the CSS .fsfake\n'
        '  // pseudo-fullscreen) the fsfake-scroll-lock state class is\n'
        '  // mirrored onto <html>/<body> — the scoped CSS display:none\n'
        '  // EVERY site-chrome layer that sat ABOVE the pinned player\n'
        '  // (the #bnav z-index inversion root cause: 2147483300 >\n'
        '  // .fsfake 2147483000). The Mini App fullscreen layer is\n'
        '  // intentionally EXCLUDED (§13: NORMAL layout inside the\n'
        '  // larger viewport).\n'
        '  function __fsChromeSync(){\n'
        '    try{\n'
        '      var on = !!(fsElement() || fsFakeActive());\n'
        '      if(document.body && document.body.classList){\n'
        '        document.body.classList.toggle("fsfake-scroll-lock", on);\n'
        '      }\n'
        '      if(document.documentElement\n'
        '         && document.documentElement.classList){\n'
        '        document.documentElement.classList.toggle(\n'
        '          "fsfake-scroll-lock", on);\n'
        '      }\n'
        '    }catch(e){}\n'
        '  }\n'
        '  var __fsLastState = null;\n'
        '  var __fsModeLast = "none";  // TASK G: the surface behind the\n'
        '                               // last fullscreen transition\n'
        '  function updateFsIcon(){\n'
        '    if(ctl && ctl.fsBtn){\n'
        '      var fs = !!(fsElement() || fsFakeActive() || tgIsFullscreen());\n'
        '      ctl.fsBtn.innerHTML = fs ? ICONS.fsExit : ICONS.fs;\n'
        '      ctl.fsBtn.setAttribute("aria-label",\n'
        '        fs ? "Exit fullscreen" : "Fullscreen");\n'
        '    }\n'
        '    // BOT-43 (Section 3): PLAYER_FULLSCREEN on every REAL\n'
        '    // transition (enter/exit - the icon refresh runs after every\n'
        '    // fullscreen change; repeated calls with an unchanged state\n'
        '    // never re-emit).\n'
        '    try{\n'
        '      var __fsNow = !!(fsElement() || fsFakeActive() || tgIsFullscreen());\n'
        '      if(__fsNow !== __fsLastState){\n'
        '        __fsLastState = __fsNow;\n'
        '        // TASK G: the surface behind the transition (api = the\n'
        '        // real Fullscreen API element, fsfake = the CSS\n'
        '        // pseudo-fullscreen, miniapp = the Telegram layer).\n'
        '        var __fmode = "none";\n'
        '        if(fsElement()){ __fmode = "api"; }\n'
        '        else if(fsFakeActive()){ __fmode = "fsfake"; }\n'
        '        else if(tgIsFullscreen()){ __fmode = "miniapp"; }\n'
        '        if(__fsNow){ __fsModeLast = __fmode; }\n'
        '        else{ __fmode = __fsModeLast || "none";\n'
        '              __fsModeLast = "none"; }\n'
        '        if(window.__siteTel){\n'
        '          var _fp = 0;\n'
        '          try{ if(mediaEl){ _fp = mediaEl.currentTime || 0; } }catch(e2){}\n'
        '          window.__siteTel("PLAYER_FULLSCREEN",\n'
        '            {state: __fsNow ? "enter" : "exit", position_s: _fp});\n'
        '          // TASK G (BOT-45/46 §10): the enter/exit pair with the\n'
        '          // active surface mode (api|fsfake|miniapp).\n'
        '          window.__siteTel(\n'
        '            __fsNow ? "PLAYER_FULLSCREEN_ENTER"\n'
        '                    : "PLAYER_FULLSCREEN_EXIT",\n'
        '            {mode: __fmode, position_s: _fp});\n'
        '        }\n'
        '      }\n'
        '    }catch(e){}\n'
        '    // TASK G: keep the body-level chrome state truthful on EVERY\n'
        '    // fullscreen change (real-API transitions only surface here).\n'
        '    __fsChromeSync();\n'
        '    __syncFsHistory();\n'
        '  }\n'
        '  // V26 PLAYER BACK SEMANTICS — the fullscreen layer sentinel:\n'
        '  // entering video fullscreen owns ONE real history entry, so\n'
        '  // Back exits fullscreen FIRST (back to the player, no\n'
        '  // navigation); a UI exit pops its own sentinel silently. The\n'
        '  // Mini App fullscreen layer is NOT ours to sentinel (the\n'
        '  // Telegram client owns it — Esc/§13 handles it).\n'
        '  function __fsLayerCloser(){\n'
        '    if(fsElement() || fsFakeActive()){\n'
        '      try{ exitVideoFullscreen(); }catch(e){}\n'
        '      try{ updateFsIcon(); }catch(e){}\n'
        '    }\n'
        '  }\n'
        '  function __syncFsHistory(){\n'
        '    var nav = window.__SITE_NAV__;\n'
        '    if(!nav || !nav.pushLayer || !nav.layerCount){ return; }\n'
        '    var want = (fsElement() || fsFakeActive()) ? 1 : 0;\n'
        '    var have = nav.layerCount("fs");\n'
        '    while(have < want){\n'
        '      nav.pushLayer("fs", __fsLayerCloser); have++;\n'
        '    }\n'
        '    while(have > want && nav.layerTop && nav.layerTop() === "fs"){\n'
        '      nav.popLayer(); have--;\n'
        '    }\n'
        '  }\n'
        '  // B23 §4.4 + V25 §13/§16: the Telegram Mini App fullscreen events\n'
        '  // keep the icon + layout truthful when the user expands/collapses\n'
        '  // via the Telegram client UI. NAMED handler references, registered\n'
        '  // in the teardown-managed registries so __playerTeardown REALLY\n'
        '  // removes them (the SDK pushes, never replaces — anonymous\n'
        '  // registrations ACCUMULATE across SPA navigations).\n'
        '  var __tgFsChange = null, __tgFsFail = null;\n'
        '  (function(){\n'
        '    var tg = tgWebApp();\n'
        '    if(!tg){ return; }\n'
        '    try{\n'
        '      if(tg.onEvent){\n'
        '        __tgFsChange = function(){\n'
        '          info("telegram_fullscreen_changed is=" +\n'
        '            String(!!(tg.isFullscreen)));\n'
        '          if(tg.isFullscreen){\n'
        '            // V25 §13: OUR player-button request -> the player\n'
        '            // expands (the promise handler or this mirror —\n'
        '            // idempotent). A Telegram-UI-initiated expand does\n'
        '            // NOT force video fullscreen: the state becomes\n'
        '            // MINI_APP_FULLSCREEN with the player in its NORMAL\n'
        '            // layout inside the larger viewport.\n'
        '            if(tgFsIntent){ tgFsIntent = false; enterFakeFullscreen(); }\n'
        '          } else {\n'
        '            // The Mini App layer collapsed -> any in-viewport video\n'
        '            // fullscreen collapses with it (canonical exit to\n'
        '            // NORMAL; the user exits via the Telegram client UI).\n'
        '            tgFsIntent = false;\n'
        '            exitFakeFullscreen();\n'
        '            info("WEBSITE_FULLSCREEN_EXIT source=telegram_api " +\n'
        '              "(mini_app_fullscreen ended)");\n'
        '          }\n'
        '          updateFsIcon();\n'
        '        };\n'
        '        tg.onEvent("fullscreenChanged", __tgFsChange);\n'
        '        __fsTgEvents.push(["fullscreenChanged", __tgFsChange]);\n'
        '        __tgFsFail = function(ev){\n'
        '          info("telegram_fullscreen_failed");\n'
        '          tgFsIntent = false;\n'
        '          exitFakeFullscreen();\n'
        '          updateFsIcon();\n'
        '        };\n'
        '        tg.onEvent("fullscreenFailed", __tgFsFail);\n'
        '        __fsTgEvents.push(["fullscreenFailed", __tgFsFail]);\n'
        '      }\n'
        '    }catch(e){}\n'
        '  })();\n'
        '  // V25 §16: the element-fullscreen state listeners — NAMED +\n'
        '  // registered ONCE at player scope (they were per-mount inside\n'
        '  // setupControls; the same reference makes re-registration a\n'
        '  // no-op and teardown removes them for real).\n'
        '  document.addEventListener("fullscreenchange", updateFsIcon);\n'
        '  document.addEventListener("webkitfullscreenchange", updateFsIcon);\n'
        '  __fsDocHandlers.push(["fullscreenchange", updateFsIcon],\n'
        '                       ["webkitfullscreenchange", updateFsIcon]);\n'
        '  // FINAL-1 + V25 §13: Esc peels the layers IN ORDER — an open\n'
        '  // settings SUBMENU first, then the VIDEO layer (keeping the\n'
        '  // Mini App fullscreen), then the Mini App layer. NAMED handler\n'
        '  // (registered ONCE at player scope; removed by teardown).\n'
        '  var __playerEsc = function(ev){\n'
        '    if(!ev || !(ev.key === "Escape" || ev.key === "Esc")){ return; }\n'
        '    if(menuOpen()){\n'
        '      if(menuBack()){ return; }   // §11: submenu closes first\n'
        '      closeMenu();\n'
        '      return;\n'
        '    }\n'
        '    if(fsElement() || fsFakeActive()){\n'
        '      exitVideoFullscreen();\n'
        '      updateFsIcon();\n'
        '      return;\n'
        '    }\n'
        '    if(tgIsFullscreen()){\n'
        '      var tg = tgWebApp();\n'
        '      if(tg){ try{ tg.exitFullscreen(); }catch(e){} }\n'
        '    }\n'
        '  };\n'
        '  document.addEventListener("keydown", __playerEsc);\n'
        '  __fsDocHandlers.push(["keydown", __playerEsc]);\n'
        '  // V25 S12: the hardware/Telegram Back button closes an OPEN player\n'
        '  // settings menu BEFORE any navigation (submenu first — the same layer\n'
        '  // order as __playerEsc). Registered ONCE per player scope; the closer\n'
        '  // returns false when nothing is open (drained harmlessly by the\n'
        '  // modalClosers LIFO).\n'
        '  // V26 script-ordering fix: this bootstrap runs INSIDE <main>,\n'
        '  // BEFORE the trailing _SITE_NAV_JS on a full load — register\n'
        '  // through the deterministic __siteNavReady deferral (head-defined;\n'
        '  // drained the moment __SITE_NAV__ is published; immediate on SPA\n'
        '  // swaps where __SITE_NAV__ already exists). The OLD direct call\n'
        '  // silently never registered on full loads (the guard saw an\n'
        '  // undefined global) — Back then navigated instead of closing the\n'
        '  // open settings menu.\n'
        '  if(window.__siteNavReady){\n'
        '    window.__siteNavReady(function(nav){\n'
        '      nav.registerModalCloser(function(){\n'
        '        if(menuOpen()){\n'
        '          if(!menuBack()){ closeMenu(); }\n'
        '          return true;\n'
        '        }\n'
        '        return false;\n'
        '      });\n'
        '    });\n'
        '  }\n'
        '  function onPlayerKey(ev, el){\n'
        '    // Work Item C.5: keyboard controls active while the player area is\n'
        '    // focused or hovered - never while typing (inputs/textarea/select/\n'
        '    // contentEditable keep their native key behavior; BUTTON targets\n'
        '    // keep native Space/Enter activation).\n'
        '    var t = ev.target;\n'
        '    if(t && (t.tagName === "TEXTAREA" || t.tagName === "SELECT" ||\n'
        '             t.isContentEditable ||\n'
        '             (t.tagName === "INPUT" && t.type !== "button"))){\n'
        '      return;\n'
        '    }\n'
        '    var k = String(ev.key || "");\n'
        '    if(t && t.tagName === "BUTTON" &&\n'
        '       (k === " " || k === "Spacebar" || k === "Enter")){\n'
        '      return;\n'
        '    }\n'
        '    var active = document.activeElement;\n'
        '    var focused = !!(active && pbox && pbox.contains(active));\n'
        '    var hovered = false;\n'
        '    try{ hovered = !!(pbox && pbox.matches(":hover")); }catch(e){}\n'
        '    if(!focused && !hovered){ return; }\n'
        '    var handled = true;\n'
        '    if(k === " " || k === "Spacebar" || k === "k" || k === "K"){\n'
        '      if(el.paused){\n'
        '        var p = el.play();\n'
        '        if(p && p.catch){ p.catch(function(){}); }\n'
        '      } else { el.pause(); }\n'
        '    } else if(k === "j" || k === "J"){\n'
        '      try{ el.currentTime = Math.max(0, el.currentTime - 10); }catch(e){}\n'
        '    } else if(k === "l" || k === "L"){\n'
        '      try{\n'
        '        el.currentTime = Math.min((el.duration || Infinity),\n'
        '          el.currentTime + 10);\n'
        '      }catch(e){}\n'
        '    } else if(k === "ArrowLeft"){\n'
        '      try{ el.currentTime = Math.max(0, el.currentTime - 5); }catch(e){}\n'
        '    } else if(k === "ArrowRight"){\n'
        '      try{\n'
        '        el.currentTime = Math.min((el.duration || Infinity),\n'
        '          el.currentTime + 5);\n'
        '      }catch(e){}\n'
        '    } else if(k === "ArrowUp"){\n'
        '      el.volume = Math.min(1, el.volume + 0.1);\n'
        '      el.muted = false;\n'
        '    } else if(k === "ArrowDown"){\n'
        '      el.volume = Math.max(0, el.volume - 0.1);\n'
        '    } else if(k === "m" || k === "M"){\n'
        '      el.muted = !el.muted;\n'
        '    } else if(k === "f" || k === "F"){\n'
        '      toggleFullscreen();\n'
        '    } else if(k === "p" || k === "P"){\n'
        '      if(document.pictureInPictureEnabled &&\n'
        '         el.requestPictureInPicture){\n'
        '        if(document.pictureInPictureElement){\n'
        '          try{ document.exitPictureInPicture(); }catch(e){}\n'
        '        } else {\n'
        '          try{ el.requestPictureInPicture(); }catch(e){}\n'
        '        }\n'
        '      } else { handled = false; }\n'
        '    // V25 S12 NOTE: Escape is NOT handled here. __playerEsc (registered\n'
        '    // once at player scope, teardown-managed) is the SINGLE Escape\n'
        '    // authority: it peels the layers IN ORDER (settings SUBMENU first via\n'
        '    // menuBack(), then the whole menu, then video fullscreen, then the\n'
        '    // Mini App fullscreen). Handling Escape here TOO made the two\n'
        '    // document-level keydown handlers run in sequence — __playerEsc\n'
        '    // correctly reopened the ROOT menu and this handler immediately\n'
        '    // closed it, so Esc at a submenu closed EVERYTHING (browser-verified\n'
        '    // regression). One key, one owner.\n'
        '    } else {\n'
        '      handled = false;\n'
        '    }\n'
        '    if(handled){\n'
        '      ev.preventDefault();\n'
        '      // B17: keyboard interaction restores the control bar.\n'
        '      if(ctl && ctl.wake){ try{ ctl.wake(); }catch(e){} }\n'
        '    }\n'
        '  }\n'
        '  // V25 (§16): the ONE named outside-tap closer (the per-mount\n'
        '  // anonymous registration accumulated a new document click\n'
        '  // listener on every player rebuild; named + teardown-managed).\n'
        '  var __menuOutside = function(ev){\n'
        '    if(menuOpen() && ctl && ctl.menu &&\n'
        '       !ctl.menu.contains(ev.target)){\n'
        '      closeMenu();\n'
        '    }\n'
        '  };\n'
        '  // V25 (§11): the settings menu builders (root + speed submenu).\n'
        '  // speedMenuItems is shared by the direct speed button and the\n'
        '  // root’s navigable row; a stored invalid rate falls back to 1×\n'
        '  // (§10). 1× renders as “Normal”.\n'
        '  function currentSpeed(){\n'
        '    var cur = 1;\n'
        '    try{\n'
        '      cur = parseFloat(sessionStorage.getItem(ctl.speedKey)) || 1;\n'
        '    }catch(e){ cur = 1; }\n'
        '    if(!isFinite(cur) || cur <= 0){ cur = 1; }\n'
        '    return cur;\n'
        '  }\n'
        '  function speedMenuItems(el){\n'
        '    var cur = currentSpeed();\n'
        '    var items = [];\n'
        '    for(var i = 0; i < SPEEDS.length; i++){\n'
        '      (function(r){\n'
        '        items.push({\n'
        '          label: (r === 1 ? "Normal" : String(r)) + "×",\n'
        '          rate: r, checked: (r === cur),\n'
        '          onSelect: function(){ applySpeed(el, r, true); }\n'
        '        });\n'
        '      })(SPEEDS[i]);\n'
        '    }\n'
        '    return items;\n'
        '  }\n'
        '  function settingsRootItems(el){\n'
        '    var items = [];\n'
        '    if(ctl.qualityItems){\n'
        '      // §9: real variants ONLY (qualityItems is set exclusively\n'
        '      // when the HLS ladder / native variant list has >1 level).\n'
        '      var qitems = ctl.qualityItems() || [];\n'
        '      var qcur = "Auto";\n'
        '      for(var i = 0; i < qitems.length; i++){\n'
        '        if(qitems[i].checked){ qcur = qitems[i].label; }\n'
        '      }\n'
        '      items.push({label: "Quality", value: qcur,\n'
        '        sub: ctl.qualityItems()});\n'
        '        // NOTE: sub re-derives live checked state on every open\n'
        '    }\n'
        '    items.push({label: "Playback speed",\n'
        '      value: (currentSpeed() === 1 ? "Normal" : String(currentSpeed())) + "×",\n'
        '      sub: speedMenuItems(el)});\n'
        '    if(document.pictureInPictureEnabled && el.requestPictureInPicture){\n'
        '      items.push({\n'
        '        label: "Picture in picture", action: true,\n'
        '        onSelect: function(){\n'
        '          try{\n'
        '            if(document.pictureInPictureElement){\n'
        '              document.exitPictureInPicture();\n'
        '            } else { el.requestPictureInPicture(); }\n'
        '          }catch(e){}\n'
        '        }\n'
        '      });\n'
        '    }\n'
        '    return items;\n'
        '  }\n'
        '  function setupControls(el, j){\n'
        '    var bar = document.createElement("div");\n'
        '    bar.className = "pctl";\n'
        '    bar.id = "pctl";\n'
        '    var seek = document.createElement("input");\n'
        '    seek.type = "range";\n'
        '    seek.className = "pctlseek";\n'
        '    seek.id = "pseek";\n'
        '    seek.min = "0"; seek.max = "1000"; seek.step = "any";\n'
        '    seek.value = "0";\n'
        '    seek.setAttribute("aria-label", "Seek");\n'
        '    var row = document.createElement("div");\n'
        '    row.className = "pctlrow";\n'
        '    var play = document.createElement("button");\n'
        '    play.type = "button"; play.className = "pctlbtn"; play.id = "pplay";\n'
        '    play.setAttribute("aria-label", "Play");\n'
        '    play.innerHTML = ICONS.play;\n'
        '    var time = document.createElement("span");\n'
        '    time.className = "pctltime"; time.id = "ptime";\n'
        '    time.textContent = "0:00 / 0:00";\n'
        '    var spacer = document.createElement("div");\n'
        '    spacer.className = "pctlspacer";\n'
        '    var mute = document.createElement("button");\n'
        '    mute.type = "button"; mute.className = "pctlbtn"; mute.id = "pmute";\n'
        '    mute.setAttribute("aria-label", "Mute");\n'
        '    mute.innerHTML = ICONS.vol;\n'
        '    var vol = document.createElement("input");\n'
        '    vol.type = "range"; vol.className = "pctlvol"; vol.id = "pvol";\n'
        '    vol.min = "0"; vol.max = "1"; vol.step = "any"; vol.value = "1";\n'
        '    vol.setAttribute("aria-label", "Volume");\n'
        '    var speedBtn = document.createElement("button");\n'
        '    speedBtn.type = "button";\n'
        '    speedBtn.className = "pctlbtn"; speedBtn.id = "pspeed";\n'
        '    speedBtn.setAttribute("aria-haspopup", "menu");\n'
        '    speedBtn.setAttribute("aria-label", "Playback speed");\n'
        '    speedBtn.textContent = "1\\u00D7";\n'
        '    var qBtn = document.createElement("button");\n'
        '    qBtn.type = "button";\n'
        '    qBtn.className = "pctlbtn"; qBtn.id = "pquality";\n'
        '    qBtn.setAttribute("aria-haspopup", "menu");\n'
        '    qBtn.setAttribute("aria-label", "Quality");\n'
        '    qBtn.textContent = "Auto";\n'
        '    qBtn.hidden = true;\n'
        '    var pipBtn = document.createElement("button");\n'
        '    pipBtn.type = "button";\n'
        '    pipBtn.className = "pctlbtn"; pipBtn.id = "ppip";\n'
        '    pipBtn.setAttribute("aria-label", "Picture in picture");\n'
        '    pipBtn.innerHTML = ICONS.pip;\n'
        '    var gearBtn = document.createElement("button");\n'
        '    gearBtn.type = "button";\n'
        '    gearBtn.className = "pctlbtn plset"; gearBtn.id = "pset";\n'
        '    gearBtn.setAttribute("aria-haspopup", "menu");\n'
        '    gearBtn.setAttribute("aria-label", "Settings");\n'
        '    gearBtn.innerHTML = ICONS.settings;\n'
        '    var fsBtn = document.createElement("button");\n'
        '    fsBtn.type = "button";\n'
        '    fsBtn.className = "pctlbtn"; fsBtn.id = "pfs";\n'
        '    fsBtn.setAttribute("aria-label", "Fullscreen");\n'
        '    fsBtn.innerHTML = ICONS.fs;\n'
        '    row.appendChild(play); row.appendChild(time);\n'
        '    row.appendChild(spacer);\n'
        '    row.appendChild(mute); row.appendChild(vol);\n'
        '    row.appendChild(speedBtn); row.appendChild(qBtn);\n'
        '    if(document.pictureInPictureEnabled && el.requestPictureInPicture){\n'
        '      row.appendChild(pipBtn);\n'
        '    }\n'
        '    row.appendChild(gearBtn);\n'
        '    row.appendChild(fsBtn);\n'
        '    var menu = document.createElement("div");\n'
        '    menu.className = "pctlmenu"; menu.id = "pmenu";\n'
        '    menu.hidden = true;\n'
        '    menu.setAttribute("role", "menu");\n'
        '    bar.appendChild(seek); bar.appendChild(row);\n'
        '    pbox.appendChild(menu);\n'
        '    pbox.appendChild(bar);\n'
        '    // BOT-43 (Section 2 - the Telegram Mini App cinematic stage):\n'
        '    // the TOP overlay — Back + the now-playing title on a top\n'
        '    // gradient, mirroring the bottom bar\\u2019s interaction-aware\n'
        '    // auto-hide (visible while paused / on wake; fades only while\n'
        '    // playing; the ad stage owns the surface while a pre-roll\n'
        '    // runs). ONE stage: poster before playback, the centered play\n'
        '    // button, the buffering spinner, the bottom control bar and\n'
        '    // this top chrome - no browser-native surface ever leaks\n'
        '    // through.\n'
        '    var top = document.createElement("div");\n'
        '    top.className = "ptop";\n'
        '    top.id = "ptop";\n'
        '    var backBtn = document.createElement("button");\n'
        '    backBtn.type = "button";\n'
        '    backBtn.className = "ptopbtn";\n'
        '    backBtn.id = "pback";\n'
        '    backBtn.setAttribute("aria-label", "Back");\n'
        '    backBtn.innerHTML = ICONS.chev;\n'
        '    var ttl = document.createElement("div");\n'
        '    ttl.className = "ptoptitle";\n'
        '    ttl.id = "ptitle";\n'
        '    ttl.textContent = String(j.display_name || j.file_name || "");\n'
        '    top.appendChild(backBtn);\n'
        '    top.appendChild(ttl);\n'
        '    pbox.appendChild(top);\n'
        '    backBtn.addEventListener("click", function(ev){\n'
        '      ev.stopPropagation();\n'
        '      // the SAME marked-backlink walk the page\\u2019s Back link\n'
        '      // takes (history-aware; deep-link fallback = the link\\u2019s\n'
        '      // own href). The nav layer\\u2019s own backlink handler\n'
        '      // already emits PLAYER_BACK for that walk - this overlay\n'
        '      // only emits when IT performs the fallback itself (never\n'
        '      // a duplicate for one physical click).\n'
        '      var bl = document.querySelector(".backlink");\n'
        '      if(bl){ try{ bl.click(); }catch(e2){} }\n'
        '      else{\n'
        '        try{ if(window.__siteTel){\n'
        '          window.__siteTel("PLAYER_BACK", {from: "player"});\n'
        '        } }catch(e){}\n'
        '        try{ history.back(); }catch(e3){}\n'
        '      }\n'
        '    });\n'
        '    ctl = {\n'
        '      bar: bar, seek: seek, play: play, time: time, mute: mute,\n'
        '      vol: vol, speedBtn: speedBtn, qBtn: qBtn, pipBtn: pipBtn,\n'
        '      gearBtn: gearBtn, fsBtn: fsBtn, menu: menu, el: el,\n'
        '      top: top, backBtn: backBtn, ttl: ttl,\n'
        '      speedKey: speedKey(j), mo: null, keyHandler: null,\n'
        '      qualityItems: null, wake: null, stopIdle: null\n'
        '    };\n'
        '    // BOT-43 (Section 1): the custom bar owns the surface - native\n'
        '    // controls were NEVER set on this element (the mount path\n'
        '    // creates it controls-free); this is belt-and-braces against\n'
        '    // any external mutation re-enabling them mid-session.\n'
        '    try{ el.removeAttribute("controls"); }catch(e){}\n'
        '    var seekDragging = false;\n'
        '    var volDragging = false;\n'
        '    function setPlayIcon(){\n'
        '      play.innerHTML = el.paused ? ICONS.play : ICONS.pause;\n'
        '      play.setAttribute("aria-label", el.paused ? "Play" : "Pause");\n'
        '    }\n'
        '    function setMuteIcon(){\n'
        '      var off = el.muted || el.volume === 0;\n'
        '      mute.innerHTML = off ? ICONS.volMute\n'
        '        : (el.volume < 0.5 ? ICONS.volLow : ICONS.vol);\n'
        '      mute.setAttribute("aria-label", off ? "Unmute" : "Mute");\n'
        '    }\n'
        '    function paintSeek(){\n'
        '      var dur = el.duration || 0;\n'
        '      var frac = dur > 0 ? (el.currentTime / dur) : 0;\n'
        '      if(!seekDragging){\n'
        '        seek.value = String(Math.round(frac * 1000));\n'
        '        seek.style.setProperty("--pval", (frac * 100).toFixed(2) + "%");\n'
        '      }\n'
        '      var buf = 0;\n'
        '      try{\n'
        '        if(el.buffered && el.buffered.length && dur > 0){\n'
        '          buf = el.buffered.end(el.buffered.length - 1) / dur;\n'
        '        }\n'
        '      }catch(e){}\n'
        '      seek.style.setProperty("--pbuf",\n'
        '        (Math.max(frac, Math.min(1, buf)) * 100).toFixed(2) + "%");\n'
        '      time.textContent = fmtTime(el.currentTime) + " / " +\n'
        '        fmtTime(dur);\n'
        '    }\n'
        '    seek.addEventListener("input", function(){\n'
        '      seekDragging = true;\n'
        '      var dur = el.duration || 0;\n'
        '      var t = (parseFloat(seek.value) / 1000) * dur;\n'
        '      try{ el.currentTime = t; }catch(e){}\n'
        '      seek.style.setProperty("--pval",\n'
        '        (parseFloat(seek.value) / 10).toFixed(2) + "%");\n'
        '      time.textContent = fmtTime(t) + " / " + fmtTime(dur);\n'
        '    });\n'
        '    seek.addEventListener("change", function(){\n'
        '      seekDragging = false; paintSeek();\n'
        '    });\n'
        '    play.addEventListener("click", function(){\n'
        '      if(el.paused){\n'
        '        var p = el.play();\n'
        '        if(p && p.catch){ p.catch(function(){}); }\n'
        '      } else { el.pause(); }\n'
        '    });\n'
        '    el.addEventListener("play", function(){ setPlayIcon(); wake();\n'
        '      try{ if(window.__siteTel){\n'
        '        var _t = 0; try{ _t = el.currentTime || 0; }catch(e){}\n'
        '        window.__siteTel("PLAYER_PLAY", {position_s: _t});\n'
        '      } }catch(e){} });\n'
        '    el.addEventListener("pause", function(){ setPlayIcon(); wake();\n'
        '      try{ if(window.__siteTel){\n'
        '        var _t2 = 0; try{ _t2 = el.currentTime || 0; }catch(e){}\n'
        '        window.__siteTel("PLAYER_PAUSE", {position_s: _t2});\n'
        '      } }catch(e){} });\n'
        '    el.addEventListener("ended", function(){ wake(); });\n'
        '    el.addEventListener("timeupdate", paintSeek);\n'
        '    el.addEventListener("progress", paintSeek);\n'
        '    el.addEventListener("durationchange", paintSeek);\n'
        '    el.addEventListener("volumechange", function(){\n'
        '      if(!volDragging){\n'
        '        vol.value = String(el.muted ? 0 : el.volume);\n'
        '      }\n'
        '      vol.style.setProperty("--pvol",\n'
        '        ((el.muted ? 0 : el.volume) * 100).toFixed(0) + "%");\n'
        '      setMuteIcon();\n'
        '    });\n'
        '    vol.addEventListener("input", function(){\n'
        '      volDragging = true;\n'
        '      var v = parseFloat(vol.value);\n'
        '      if(isNaN(v)){ v = 1; }\n'
        '      el.volume = v;\n'
        '      el.muted = (v === 0);\n'
        '    });\n'
        '    vol.addEventListener("change", function(){ volDragging = false; });\n'
        '    mute.addEventListener("click", function(){\n'
        '      el.muted = !el.muted;\n'
        '      if(!el.muted && el.volume === 0){ el.volume = 0.5; }\n'
        '    });\n'
        '    speedBtn.addEventListener("click", function(ev){\n'
        '      ev.stopPropagation();\n'
        '      if(menuOpen() && ctl.menu.getAttribute("data-kind") === "speed"){\n'
        '        closeMenu(); return;\n'
        '      }\n'
        '      ctl.menu.setAttribute("data-kind", "speed");\n'
        '      // V25 (§11): the direct speed button opens the SPEED SUBMENU\n'
        '      // with a back row to the settings ROOT (the same traversal as\n'
        '      // the gear -> row path — one coherent menu state machine).\n'
        '      openMenu(speedMenuItems(el), {label: "Settings",\n'
        '        items: settingsRootItems(el)});\n'
        '    });\n'
        '    qBtn.addEventListener("click", function(ev){\n'
        '      ev.stopPropagation();\n'
        '      if(menuOpen() && ctl.menu.getAttribute("data-kind") === "quality"){\n'
        '        closeMenu(); return;\n'
        '      }\n'
        '      if(!ctl.qualityItems){ return; }\n'
        '      ctl.menu.setAttribute("data-kind", "quality");\n'
        '      openMenu(ctl.qualityItems(), {label: "Settings",\n'
        '        items: settingsRootItems(el)});\n'
        '    });\n'
        '    // B17 UX POLISH + V25 (§11): the mobile Settings sheet — ONE\n'
        '    // gear on phones (the inline buttons are CSS-hidden <=640px)\n'
        '    // opening the TWO-LEVEL menu: Quality -> <current>, Playback\n'
        '    // speed -> <current>; each row opens its submenu with a real\n'
        '    // back row. Quality appears ONLY when real variants exist (the\n'
        '    // honest §9 rule — no faked selector for a single source).\n'
        '    gearBtn.addEventListener("click", function(ev){\n'
        '      ev.stopPropagation();\n'
        '      if(menuOpen() && ctl.menu.getAttribute("data-kind") === "settings"){\n'
        '        closeMenu(); return;\n'
        '      }\n'
        '      ctl.menu.setAttribute("data-kind", "settings");\n'
        '      openMenu(settingsRootItems(el));\n'
        '    });\n'
        '    if(pipBtn.parentNode){\n'
        '      pipBtn.addEventListener("click", function(){\n'
        '        try{\n'
        '          if(document.pictureInPictureElement){\n'
        '            document.exitPictureInPicture();\n'
        '          } else {\n'
        '            el.requestPictureInPicture();\n'
        '          }\n'
        '        }catch(e){}\n'
        '      });\n'
        '    }\n'
        '    fsBtn.addEventListener("click", toggleFullscreen);\n'
        '    // V25 (§16): the fullscreenchange listeners live at player scope\n'
        '    // (named + teardown-managed) — the per-mount registration here\n'
        '    // was a duplicate-listener leak on every player rebuild.\n'
        '    // loading spinner (waiting/stalled -> visible; playing/canplay ->\n'
        '    // hidden)\n'
        '    var waitEl = document.createElement("div");\n'
        '    waitEl.className = "pwait"; waitEl.id = "pwait"; waitEl.hidden = true;\n'
        '    waitEl.innerHTML = "<div class=\\"spin\\"></div>";\n'
        '    pbox.appendChild(waitEl);\n'
        '    el.addEventListener("waiting", function(){ waitEl.hidden = false; });\n'
        '    el.addEventListener("stalled", function(){ waitEl.hidden = false; });\n'
        '    el.addEventListener("playing", function(){ waitEl.hidden = true; });\n'
        '    el.addEventListener("canplay", function(){ waitEl.hidden = true; });\n'
        '    el.addEventListener("seeked", function(){ waitEl.hidden = true; });\n'
        '    // hide the custom bar + the top overlay while the pre-roll ad\n'
        '    // stage is visible (the ad stage owns its own minimal UI)\n'
        '    if(window.MutationObserver && adStageEl){\n'
        '      ctl.mo = new MutationObserver(function(){\n'
        '        var adOn = !adStageEl.hidden;\n'
        '        bar.classList.toggle("adshidden", adOn);\n'
        '        top.classList.toggle("adshidden", adOn);\n'
        '      });\n'
        '      ctl.mo.observe(adStageEl,\n'
        '        {attributes: true, attributeFilter: ["hidden"]});\n'
        '      var __ad0 = !adStageEl.hidden;\n'
        '      bar.classList.toggle("adshidden", __ad0);\n'
        '      top.classList.toggle("adshidden", __ad0);\n'
        '    }\n'
        '    // click on the video surface toggles playback (standard UX)\n'
        '    el.addEventListener("click", function(){\n'
        '      if(el.paused){\n'
        '        var p = el.play();\n'
        '        if(p && p.catch){ p.catch(function(){}); }\n'
        '      } else { el.pause(); }\n'
        '    });\n'
        '    ctl.keyHandler = function(ev){ onPlayerKey(ev, el); };\n'
        '    document.addEventListener("keydown", ctl.keyHandler);\n'
        '    // V25 (§16): the ONE named outside-tap closer (registered at\n'
        '    // player scope — no per-mount anonymous accumulation).\n'
        '    document.addEventListener("click", __menuOutside);\n'
        '    setPlayIcon(); setMuteIcon(); paintSeek();\n'
        '    // ---- B17 UX POLISH: interaction-aware control auto-hide ------\n'
        '    // The bar fades + slides out after inactivity ONLY while the\n'
        '    // media is PLAYING. Mouse movement, touch and keyboard input\n'
        '    // restore it instantly; it stays pinned visible while paused\n'
        '    // or ended, while a menu is open and while a slider drag is in\n'
        '    // progress (the controls remain usable during seeking).\n'
        '    var IDLE_MS = 2800;\n'
        '    var idleTimer = null;\n'
        '    function clearIdle(){\n'
        '      if(idleTimer){ clearTimeout(idleTimer); idleTimer = null; }\n'
        '    }\n'
        '    function setIdle(v){\n'
        '      if(v){\n'
        '        if(el.paused || el.ended || menuOpen() || seekDragging ||\n'
        '           volDragging){ v = false; }\n'
        '        // the cursor resting on the control bar keeps it visible\n'
        '        try{ if(v && bar.matches(":hover")){ v = false; } }catch(e){}\n'
        '      }\n'
        '      try{\n'
        '        bar.classList.toggle("ctl-idle", v);\n'
        '        pbox.classList.toggle("ctl-idle", v);\n'
        '      }catch(e){}\n'
        '    }\n'
        '    function wake(){\n'
        '      clearIdle();\n'
        '      setIdle(false);\n'
        '      if(!el.paused && !el.ended){\n'
        '        idleTimer = setTimeout(function(){\n'
        '          idleTimer = null; setIdle(true);\n'
        '        }, IDLE_MS);\n'
        '      }\n'
        '    }\n'
        '    ctl.wake = wake;\n'
        '    ctl.stopIdle = function(){ clearIdle(); setIdle(false); };\n'
        '    pbox.addEventListener("pointermove", wake);\n'
        '    pbox.addEventListener("pointerdown", wake);\n'
        '    try{\n'
        '      pbox.addEventListener("touchstart", wake, {passive: true});\n'
        '    }catch(e){}\n'
        '    bar.addEventListener("focusin", wake);\n'
        '    seek.addEventListener("pointerdown", wake);\n'
        '    var savedRate = 1;\n'
        '    try{\n'
        '      savedRate = parseFloat(sessionStorage.getItem(ctl.speedKey)) || 1;\n'
        '    }catch(e){ savedRate = 1; }\n'
        '    if(!isFinite(savedRate) || savedRate <= 0){ savedRate = 1; }\n'
        '    applySpeed(el, savedRate);\n'
        '  }\n'
        '  // ---- v35 truthful media error states (spec 7/17) + BOT-16 retry ---\n'
        '  // Machine-readable states mirror the backend JSON error codes:\n'
        '  //   AUTH_EXPIRED / AUTH_INVALID / ACCESS_DENIED / UNLOCK_IN_TELEGRAM\n'
        '  //   MEDIA_UPSTREAM_ERROR / MEDIA_NOT_FOUND / MEDIA_UNSUPPORTED\n'
        '  //   NETWORK_INTERRUPTED / NETWORK_ERROR / PLAYBACK_ERROR /\n'
        '  //   PREPARING / STREAM_SUCCESS.\n'
        '  // BOT-16: ACCESS_DENIED is NO LONGER used for force_join_required -\n'
        '  // that denial renders the in-player Join Required gate instead (the\n'
        '  // state stays for every other locked reason). Temporary upstream\n'
        '  // failures offer Retry Stream (a fresh POST /site/api/stream that\n'
        '  // rebuilds the player in place); every failure keeps the canonical\n'
        '  // Telegram fallback for genuine Get File flows.\n'
        '  // V26.2-bot42: PREPARING = the honest temporary hls_preparing state\n'
        '  // (503 from the HLS surface while the background transcoding job\n'
        '  // runs - the player polls with bounded backoff inside\n'
        '  // ensureMasterReady; this state is the give-up surface after the\n'
        '  // bounded maximum). NETWORK_ERROR = the request never reached the\n'
        '  // server (a transport failure - distinct from a mid-stream drop).\n'
        '  var STATE_TEXT = {\n'
        '    AUTH_EXPIRED: ["Stream link expired",\n'
        '      "Your stream authorization expired \\u2014 retrying gives " +\n'
        '      "you a fresh one."],\n'
        '    AUTH_INVALID: ["Stream not authorized",\n'
        '      "This stream link is not valid for media playback."],\n'
        '    ACCESS_DENIED: ["Access required",\n'
        '      "Complete the access requirement in Telegram, then reload."],\n'
        '    // B23/P0-1: the Telegram payload Watch-Ad gate is waived\n'
        '    // SERVER-SIDE for website playback (app/web/site/authz.py) —\n'
        '    // watch_ad_required never reaches this player at all. This\n'
        '    // state is now ONLY the POINTS unlock path (a bot-side\n'
        '    // unlock, honestly completed in Telegram).\n'
        '    UNLOCK_IN_TELEGRAM: ["Unlock this payload in Telegram",\n'
        '      "Open this payload in the bot and unlock it with points " +\n'
        '      "there \\u2014 then reload this page."],\n'
        '    MEDIA_UPSTREAM_ERROR: ["Telegram could not serve this file",\n'
        '      "This is a temporary upstream issue \\u2014 not your account."],\n'
        '    MEDIA_NOT_FOUND: ["File no longer available",\n'
        '      "This file is no longer available from Telegram."],\n'
        '    MEDIA_UNSUPPORTED: ["Cannot play in this browser",\n'
        '      "The file\\u2019s format/codec is not supported here \\u2014 " +\n'
        '      "it is fine in Telegram."],\n'
        '    NETWORK_INTERRUPTED: ["Network interrupted",\n'
        '      "Your connection dropped during the stream."],\n'
        '    NETWORK_ERROR: ["Could not reach the server",\n'
        '      "The playback request failed to reach the server - check " +\n'
        '      "your connection and retry."],\n'
        '    PLAYBACK_ERROR: ["Playback error",\n'
        '      "The player could not render this stream."],\n'
        '    PREPARING: ["Preparing this video",\n'
        '      "This video is being optimized for playback - it happens " +\n'
        '      "once, and later plays are instant. Please wait a moment " +\n'
        '      "and retry."]\n'
        '  };\n'
        '  function currentCtx(){ return ctxData(); }\n'
        '  function tgButton(label){\n'
        '    var c = currentCtx();\n'
        '    if(!c || !c.payload_link){ return ""; }\n'
        '    return "<a class=\\"tgbtn\\" href=\\"" + String(c.payload_link) +\n'
        '      "\\" rel=\\"noopener\\">\\u27A8 " + (label || "Get this file in Telegram") +\n'
        '      "</a>";\n'
        '  }\n'
        '  function clearActions(){\n'
        '    var va = document.getElementById("vactions");\n'
        '    if(va){ va.hidden = true; va.innerHTML = ""; }\n'
        '  }\n'
        '  function showState(state, extraSub){\n'
        '    info("media_state=" + state);\n'
        '    var t = STATE_TEXT[state] || ["Playback failed",\n'
        '      "The stream could not be played."];\n'
        '    var sub = (extraSub ? extraSub + " " : "") + (t[1] || "");\n'
        '    // B17: the error heading carries the same stroke-icon system\n'
        '    // as every other player state (never a bare text-only title).\n'
        '    // V26.2-bot42: PREPARING is an honest IN-PROGRESS state (the clock\n'
        '    // icon + locked styling, never a hard denial).\n'
        '    show(state === "MEDIA_UPSTREAM_ERROR" ||\n'
        '         state === "NETWORK_INTERRUPTED" ||\n'
        '         state === "NETWORK_ERROR" ||\n'
        '         state === "PREPARING" ? "locked" : "deny",\n'
        '         (state === "PREPARING" ? ICONS.clock : ICONS.warn) +\n'
        '         "<span>" + t[0] + "</span>", sub);\n'
        '    var va = document.getElementById("vactions");\n'
        '    if(!va){ return; }\n'
        '    va.innerHTML = "";\n'
        '    // BOT-16: Retry re-issues POST /site/api/stream and rebuilds the\n'
        '    // player in place (never window.location.reload).\n'
        '    var retryable = (state === "MEDIA_UPSTREAM_ERROR" ||\n'
        '                     state === "NETWORK_INTERRUPTED" ||\n'
        '                     state === "NETWORK_ERROR" ||\n'
        '                     state === "AUTH_EXPIRED" ||\n'
        '                     state === "PREPARING" ||\n'
        '                     state === "PLAYBACK_ERROR");\n'
        '    if(retryable){\n'
        '      var b = document.createElement("button");\n'
        '      b.type = "button"; b.className = "partpill go";\n'
        '      b.innerHTML = ICONS.replay + "<span>Retry Stream</span>";\n'
        '      b.addEventListener("click", function(){\n'
        '        retryStream();\n'
        '      });\n'
        '      va.appendChild(b);\n'
        '    }\n'
        '    var tgA = tgButton(state === "UNLOCK_IN_TELEGRAM"\n'
        '      ? "Return to Telegram" : "");\n'
        '    if(tgA){\n'
        '      var d = document.createElement("div");\n'
        '      d.className = "vactions"; d.innerHTML = tgA;\n'
        '      va.appendChild(d.firstChild ? d.firstChild : d);\n'
        '    }\n'
        '    va.hidden = false;\n'
        '  }\n'
        '  function stateFromResponse(status, j){\n'
        '    var code = String((j && j.error) || "");\n'
        '    if(status === 401){\n'
        '      return code === "wrong_purpose" ? "AUTH_INVALID"\n'
        '        : "AUTH_EXPIRED"; }\n'
        '    if(status === 403){ return "ACCESS_DENIED"; }\n'
        '    if(status === 404){ return "MEDIA_NOT_FOUND"; }\n'
        '    if(status === 416){ return "PLAYBACK_ERROR"; }\n'
        '    if(status === 429){ return "NETWORK_INTERRUPTED"; }\n'
        '    if(status === 503 && code === "too_large_for_transport"){\n'
        '      return "MEDIA_UNSUPPORTED"; }\n'
        '    return "MEDIA_UPSTREAM_ERROR";\n'
        '  }\n'
        '  function probeStream(){\n'
        '    if(!__streamUrl){ showState("PLAYBACK_ERROR"); return; }\n'
        '    fetch(__streamUrl, {headers: {"Range": "bytes=0-0"}})\n'
        '    .then(function(r){\n'
        '      if(r.status === 200 || r.status === 206){\n'
        '        showState("PLAYBACK_ERROR"); return null;\n'
        '      }\n'
        '      return r.json().catch(function(){ return null; })\n'
        '        .then(function(j){\n'
        '          showState(stateFromResponse(r.status, j)); });\n'
        '    })\n'
        '    .catch(function(){ showState("NETWORK_INTERRUPTED"); });\n'
        '  }\n'
        '  function diagnosePlayer(el){\n'
        '    var code = el && el.error ? el.error.code : 0;\n'
        '    // V26 PLAYER_STREAM_ERROR telemetry: the media element errored\n'
        '    // (the honest state name is logged — the code alone is opaque).\n'
        '    try{ if(window.__siteTel){\n'
        '      window.__siteTel("PLAYER_STREAM_ERROR",\n'
        '        {error_code: code || 0});\n'
        '    } }catch(e){}\n'
        '    // 1 aborted, 2 network, 3 decode, 4 src-not-supported\n'
        '    if(code === 4){ showState("MEDIA_UNSUPPORTED"); return; }\n'
        '    if(code === 3){ showState("PLAYBACK_ERROR"); return; }\n'
        '    if(code === 2){ showState("NETWORK_INTERRUPTED"); return; }\n'
        '    probeStream();\n'
        '  }\n'
        '  // ---- BOT-16 Work Item C.3: resume / start-over upgrade ----------\n'
        '  // V25 (§7): the explicit playback intent — "startover" suppresses\n'
        '  // progress restoration for the CURRENT load (the Start Over →\n'
        '  // seek 0 → loadedmetadata re-fires (quality switch / HLS re-attach)\n'
        '  // → old progress restored → jump-back race). "resume" marks an\n'
        '  // explicit user resume. Cleared after first use.\n'
        '  var __playIntent = null;\n'
        '  var __resumePageHide = null;\n'
        '  function setupResume(el, j){\n'
        '    if(el.tagName !== "VIDEO" && el.tagName !== "AUDIO"){ return; }\n'
        '    try{\n'
        '      var c = ctxData();\n'
        '      var uid = (j.user && j.user.id) ? String(j.user.id) : "0";\n'
        '      var key = "plresume:" + uid + ":" + String(c.listing || "")\n'
        '        + ":" + String(c.file_pk || "");\n'
        '      var last = 0, saved = 0;\n'
        '      // (a) fires for BOTH the direct and the HLS paths (hls.js\n'
        '      // attaches media before loading the source; native HLS sets the\n'
        '      // src directly) - the offer logic itself is the v35 threshold.\n'
        '      el.addEventListener("loadedmetadata", function(){\n'
        '        // V25 (§7): the Start-Over race guard — an explicit startover\n'
        '        // intent must NOT be overridden by a re-fired loadedmetadata\n'
        '        // restoring the OLD saved position (the jump-back bug).\n'
        '        if(__playIntent === "startover"){ return; }\n'
        '        __playIntent = null;\n'
        '        try{\n'
        '          var raw = localStorage.getItem(key);\n'
        '          if(raw){\n'
        '            var st = JSON.parse(raw);\n'
        '            var dur = el.duration || 0;\n'
        '            if(st && dur > 0 && st.t > dur * 0.95){\n'
        '              // (c) watched (nearly) to the end: treat as completed -\n'
        '              // clear the key, do NOT offer Resume. B.4.4:\n'
        '              // the WATCHED marker outlives the cleared key.\n'
        '              localStorage.removeItem(key);\n'
        '              try{ localStorage.setItem("plwatched:" + uid\n'
        '                + ":" + String(c.listing || ""), "1");\n'
        '              }catch(e2){}\n'
        '            } else if(st && st.t > 10 && dur && st.t < dur - 5){\n'
        '              offerResume(el, key, st.t);\n'
        '            }\n'
        '          }\n'
        '        }catch(e){}\n'
        '      });\n'
        '      el.addEventListener("timeupdate", function(){\n'
        '        var now = Date.now();\n'
        '        if(now - saved > 5000 && el.currentTime > 5){\n'
        '          saved = now;\n'
        '          try{\n'
        '            localStorage.setItem(key, JSON.stringify({\n'
        '              t: Math.floor(el.currentTime), ts: now,\n'
        '              d: Math.floor(el.duration || 0) }));\n'
        '          }catch(e){}\n'
        '        }\n'
        '      });\n'
        '      el.addEventListener("ended", function(){\n'
        '        try{ localStorage.removeItem(key); }catch(e){}\n'
        '        // B.4.4: remember the WATCHED state (card checkmark).\n'
        '        try{ localStorage.setItem("plwatched:" + uid + ":" +\n'
        '          String(c.listing || ""), "1"); }catch(e2){}\n'
        '      });\n'
        '      // V25 (§16): ONE named pagehide writer (a re-mounted player\n'
        '      // replaced the element — the previous handler is removed so a\n'
        '      // stale detached element can never overwrite good progress).\n'
        '      if(__resumePageHide){\n'
        '        try{ window.removeEventListener("pagehide", __resumePageHide); }\n'
        '        catch(e){}\n'
        '      }\n'
        '      __resumePageHide = function(){\n'
        '        if(el.currentTime > 5 && __playIntent !== "startover"){\n'
        '          try{\n'
        '            localStorage.setItem(key, JSON.stringify({\n'
        '              t: Math.floor(el.currentTime), ts: Date.now(),\n'
        '              d: Math.floor(el.duration || 0) }));\n'
        '          }catch(e){}\n'
        '        }\n'
        '      };\n'
        '      window.addEventListener("pagehide", __resumePageHide);\n'
        '    }catch(e){}\n'
        '  }\n'
        '  function offerResume(el, key, t){\n'
        '    var bar = document.getElementById("resumebar");\n'
        '    if(!bar){ return; }\n'
        '    var mm = Math.floor(t / 60), ss = Math.floor(t % 60);\n'
        '    var label = (mm > 0 ? mm + "m " : "") + ss + "s";\n'
        '    bar.innerHTML = "";\n'
        '    var span = document.createElement("span");\n'
        '    // (d) the "Continue watching" indicator.\n'
        '    span.textContent = "Continue watching \\u2014 resume from " + label + "?";\n'
        '    var yes = document.createElement("button");\n'
        '    yes.className = "partpill go";\n'
        '    yes.textContent = "Resume";\n'
        '    yes.addEventListener("click", function(){\n'
        '      // V25 (§7): Resume records the intent, waits for media\n'
        '      // readiness, seeks to the saved position, preserves speed /\n'
        '      // volume / mute (element state untouched) and starts playback\n'
        '      // per the existing UX.\n'
        '      __playIntent = "resume";\n'
        '      var seekNow = function(){\n'
        '        try{ el.currentTime = t; }catch(e){}\n'
        '        bar.classList.remove("show");\n'
        '        var p = el.play();\n'
        '        if(p && p.catch){ p.catch(function(){}); }\n'
        '      };\n'
        '      if(el.readyState >= 1){ seekNow(); }\n'
        '      else{\n'
        '        el.addEventListener("loadedmetadata", function onMeta(){\n'
        '          el.removeEventListener("loadedmetadata", onMeta);\n'
        '          seekNow();\n'
        '        });\n'
        '      }\n'
        '    });\n'
        '    var no = document.createElement("button");\n'
        '    no.className = "partpill";\n'
        '    no.textContent = "Start over";\n'
        '    no.addEventListener("click", function(){\n'
        '      // V25 (§7): Start Over records the intent (suppresses any\n'
        '      // restoration race), clears the saved progress, seeks to 0\n'
        '      // and dismisses the dialog — playback restarts cleanly.\n'
        '      __playIntent = "startover";\n'
        '      try{ el.currentTime = 0; }catch(e){}\n'
        '      try{ localStorage.removeItem(key); }catch(e){}\n'
        '      bar.classList.remove("show");\n'
        '      var p = el.play();\n'
        '      if(p && p.catch){ p.catch(function(){}); }\n'
        '    });\n'
        '    bar.appendChild(span); bar.appendChild(yes);\n'
        '    bar.appendChild(no); bar.classList.add("show");\n'
        '  }\n'
        '  // B24 (Phase 2): expose teardown so the SPA-lite nav layer can\n'
        '  // pause + release the OLD player (video src, hls.js instance,\n'
        '  // blob URLs, document keydown/fullscreenchange listeners,\n'
        '  // tg.onEvent handlers) BEFORE main.innerHTML is swapped —\n'
        '  // otherwise a stale <video> + a fresh one coexist, hls.js keeps\n'
        '  // fetching for a detached element, and tg.onEvent handlers\n'
        '  // ACCUMULATE across navigations (the SDK pushes, never replaces).\n'
        '  // V25 (§16): the REAL lifecycle cleanup. teardownMedia releases\n'
        '  // the media element + hls.js; the registries below remove every\n'
        '  // NAMED document handler (Esc layering, fullscreenchange, the\n'
        '  // outside-tap closer, the player key handler via teardownMedia)\n'
        '  // and every tg.onEvent registration (the SDK pushes, never\n'
        '  // replaces — without offEvent the fullscreen handlers ACCUMULATE\n'
        '  // across SPA navigations). Open/fullscreen → navigate → open →\n'
        '  // exit, repeated: zero duplicated callbacks, zero stale refs.\n'
        '  window.__playerTeardown = function(){\n'
        '    // V26: clear the layer sentinels SYNCHRONOUSLY (no back()) — a\n'
        '    // history.back() inside a popstate-driven swap would consume a\n'
        '    // REAL navigation entry. Stale sentinel entries (same URL) cost\n'
        '    // one inert Back press at most — bounded, never a loop.\n'
        '    try{\n'
        '      if(window.__SITE_NAV__ && window.__SITE_NAV__.clearLayers){\n'
        '        window.__SITE_NAV__.clearLayers();\n'
        '      }\n'
        '    }catch(e){}\n'
        '    // V25 (§31): exit ANY in-viewport video fullscreen FIRST —\n'
        '    // teardownMedia never removed the .fsfake class or the\n'
        '    // html/body fsfake-scroll-lock classes, so an SPA navigation\n'
        '    // away from a fullscreen player left the page SCROLL-LOCKED\n'
        '    // with a frozen fixed player box = the giant unexplained blank\n'
        '    // region. The full layered exit also collapses element\n'
        '    // fullscreen; the Mini App layer is left to the Telegram\n'
        '    // client (§13).\n'
        '    try{ exitVideoFullscreen(); }catch(e){}\n'
        '    try{ teardownMedia(); destroyHls(); }catch(e){}\n'
        '    try{\n'
        '      for(var i = 0; i < __fsDocHandlers.length; i++){\n'
        '        try{\n'
        '          document.removeEventListener(__fsDocHandlers[i][0],\n'
        '                                   __fsDocHandlers[i][1]);\n'
        '        }catch(e){}\n'
        '      }\n'
        '      __fsDocHandlers.length = 0;\n'
        '    }catch(e){}\n'
        '    try{\n'
        '      var tg = tgWebApp();\n'
        '      if(tg && tg.offEvent){\n'
        '        for(var k = 0; k < __fsTgEvents.length; k++){\n'
        '          try{ tg.offEvent(__fsTgEvents[k][0], __fsTgEvents[k][1]); }\n'
        '          catch(e){}\n'
        '        }\n'
        '      }\n'
        '      __fsTgEvents.length = 0;\n'
        '    }catch(e){}\n'
        '    try{\n'
        '      if(__resumePageHide){\n'
        '        window.removeEventListener("pagehide", __resumePageHide);\n'
        '        __resumePageHide = null;\n'
        '      }\n'
        '    }catch(e){}\n'
        '    try{ tgFsIntent = false; }catch(e){}\n'
        '    try{ document.removeEventListener("click", __menuOutside); }catch(e){}\n'
        '    // V26 PLAYER telemetry: the player is being torn down —\n'
        '    // PLAYER_DESTROY for every teardown (SPA swap, rebuild) and\n'
        '    // PLAYER_CLOSE via sendBeacon for the page-unload case (a\n'
        '    // fetch during unload is unreliable; the beacon is not).\n'
        '    // BOT-43: the pair fires ONCE per player lifecycle (the\n'
        '    // __destroyReported sentinel; mountPlayer re-arms it) - a\n'
        '    // navigation burst calling __playerTeardown repeatedly\n'
        '    // reports exactly ONE destroy/close, never a duplicate.\n'
        '    try{ if(window.__siteTel){\n'
        '      if(!__destroyReported){\n'
        '        __destroyReported = true;\n'
        '        window.__siteTel("PLAYER_DESTROY");\n'
        '        if(window.__TEL_URL__ && navigator.sendBeacon){\n'
        '          try{\n'
        '            navigator.sendBeacon(window.__TEL_URL__, new Blob(\n'
        '              [JSON.stringify({event: "PLAYER_CLOSE"})],\n'
        '              {type: "application/json"}));\n'
        '          }catch(e){}\n'
        '        }\n'
        '      }\n'
        '    } }catch(e){}\n'
        '  };\n'
        '})();\n'
        "</script></div>")
    # PROMPT B (bot-25): B.2.1 the media sidebar — two columns at
    # >=1024px (player + metadata left, sticky 340px sidebar right);
    # below that the same sections stack below the metadata as
    # horizontal shelves (CSS .mediagrid). B.5.2: the hero poster gets a
    # preload hint in <head>.
    if sidebar:
        body = ('<div class="mediagrid"><div>' + body + '</div>'
                '<aside class="msidebar" aria-label="More to watch">'
                + sidebar + "</aside></div>")
    if poster_url:
        head_extra = ('<link rel="preload" as="image" href="'
                      + esc(poster_url) + '">'
                      + str(head_extra or ""))
    return _page(f"{part_label} — {title}", body, noindex=True,
                 user=user, categories=categories, age_ok=age_ok,
                 description=f"{part_label} of {title} — playback is "
                             "authorized inside the Telegram Mini App.",
                 head_extra=head_extra)


def _esc_js_attr(value: str) -> str:
    """Escape a value for safe embedding inside a JS string literal that
    is emitted into an HTML <script> block (poster URL etc.)."""
    return json.dumps(str(value))[1:-1].replace("</", "<\\/")


def json_stream_src() -> str:
    return json.dumps(site_url("site/api/stream"))


def json_script_src() -> str:
    return json.dumps(site_url("site/api/access"))


def json_video_ref(video_href: str) -> str:
    # video_href is the FULL path (site/payload/<opaque>/video/<token>) —
    # the API only needs the token segment.
    token = str(video_href).rstrip("/").rsplit("/", 1)[-1]
    return json.dumps(token)


# ---------------------------------------------------------------- errors
def not_found_page(message: str = "Payload not found.") -> str:
    body = ("<div class=\"centerwrap\"><div class=\"mbox\">"
            "<div class=\"glyph\">\U0001F50D</div><h1>Not found</h1>"
            "<p>" + esc(message) + "</p>"
            '<p class="maction"><a class="backlink" href="'
            + esc(site_url("site")) + '">' + _icon("chevron-left")
            + "All payloads</a></p>"
            "</div></div>")
    return _page("Not found", body, noindex=True,
                 description="Payload not found.")


def bad_request_page(message: str = "Invalid request.") -> str:
    body = ("<div class=\"centerwrap\"><div class=\"mbox\">"
            "<div class=\"glyph\">\u26A0\uFE0F</div><h1>Invalid link</h1>"
            "<p>" + esc(message) + "</p>"
            '<p class="maction"><a class="backlink" href="'
            + esc(site_url("site")) + '">' + _icon("chevron-left")
            + "All payloads</a></p>"
            "</div></div>")
    return _page("Invalid link", body, noindex=True,
                 description="Invalid link.")


def rate_limited_page() -> str:
    body = ("<div class=\"centerwrap\"><div class=\"mbox\">"
            "<div class=\"glyph\">\u23F3</div><h1>Slow down</h1>"
            "<p>Too many requests — try again in a moment.</p>"
            "</div></div>")
    return _page("Rate limited", body, noindex=True,
                 description="Too many requests.")


def session_expired_page(message: str = "") -> str:
    """B18-FINAL (bot-22.log pass / Issue K): the honest session-expired /
    handoff-expired screen — the user is NEVER left on a blank page when a
    media item or browser link expires. Reload re-authenticates through the
    Mini App bootstrap; the primary path back is Telegram (the minting
    surface). Used by the external-browser handoff consume (replay/expiry)
    and any state that must send the user home."""
    msg = esc(message) if message else (
        "This browser link has expired or was already used. Links from "
        "Telegram are single-use and short-lived for your security.")
    body = ("<div class=\"centerwrap\"><div class=\"mbox\">"
            "<div class=\"glyph\">\u23ED\uFE0F</div>"
            "<h1>Session expired</h1>"
            "<p>" + msg + "</p>"
            '<p class="maction"><a class="tgbtn" href="'
            + esc(site_url("site")) + '">'
            + _icon("rotate-cw") + "Reload</a></p>"
            '<p class="maction"><a class="backlink" href="'
            + esc(site_url("site")) + '">' + _icon("chevron-left")
            + "Return to Telegram</a></p>"
            "</div></div>")
    return _page("Session expired", body, noindex=True,
                 description="Session expired — return to Telegram.")
