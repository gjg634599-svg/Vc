"""MAIN MINI APP LINK on registered Network Bots (b10 §8/§29 — B10-B2).

STANDALONE MODULE — the same discipline as every other ``app/network/*``
module: never imports ``app.presentation.*``; every collaborator is
resolved through the injected runtime namespace ``ns`` at CALL time.

What this module owns
---------------------
* ``canonical_main_app_url`` — THE one canonical Main Mini App URL:
  ``bot_settings.website_public_base_url`` + ``/site`` (the project's
  existing public Website base; NEVER a second invented URL, NEVER a
  per-bot mini app). HTTPS-validated (spec §8F); empty string when the
  platform has no public base configured (the callers then render no
  button — never a fabricated link).
* ``validate_main_app_url`` (BOT-11 §2-§5) — the Change URL flow's
  validation gate: HTTPS-only, absolute, host present, no whitespace /
  control chars / unsupported schemes. Malformed URLs are NEVER stored.
* ``apply_main_app_link`` — best-effort ``setChatMenuButton`` (menu
  button type=web_app, text "Main App") through a registered bot's own
  client, honoring the explicit operator policy
  ``bot_settings.network_bots_menu_button_mode`` = ``auto`` (default) |
  ``preserve`` (never touch an existing configured menu button).
  Truthful logs: NETWORK_BOT_MENU_BUTTON_APPLIED / _FAILED reason=… /
  _SKIPPED reason=preserve|no_url|not_https — never secrets (the URL is
  public and secret-free by construction). BOT-11 (spec §9/§10): every
  outcome is ALSO persisted per-bot via ``db.update_network_bot_mini_app``
  (schema v35: mini_app_url / mini_app_last_applied_at /
  mini_app_last_apply_status / mini_app_last_apply_error).
* ``on_worker_started`` — the post-start hook wired in
  ``app/network/lifecycle.py`` (requirement C: the link survives
  restarts/re-registrations — every worker start reapplies it). BOT-11
  (spec §1): the hook ALSO persists the worker's getMe-derived
  ``can_manage_bots`` capability once per start (best-effort, isolated —
  the workers.py helper, never a second getMe policy).
* ``apply_main_app_link_to_all`` — the ADMIN "Apply Main App Link to All
  Registered Bots" action (iterates ACTIVE bots, reapplies, persists
  EVERY outcome, returns the §4 TRUTHFUL structured result). The main
  bot is applied too when its live client is provided (the wsmain panel
  passes it); an unreachable main bot lands under Failed with the reason.
* BOT-45/46 (master prompt §14 — MAIN MINI APP, ONE CANONICAL
  DESTINATION): ``MAIN_MINI_APP_BOT_USERNAME`` +
  ``build_main_mini_app_link()`` — the ONE canonical Telegram-form Main
  Mini App link (``https://t.me/<actual_bot_username>?startapp``; the
  named Direct Mini App form ``https://t.me/<bot>/<short_name>?
  startapp=<parameter>`` ONLY where actually configured). NEVER
  ``t.me/undefined``, an old bot, another bot, or an arbitrary Worker
  URL as the Telegram destination (``canonical_main_app_url`` stays the
  INTERNAL browser fallback). MINI_APP_LINK_BUILD telemetry (safe
  fields); ``None`` when unresolvable — callers then show the admin
  configuration error, never a broken URL.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger("payload-bot")

# The canonical public path of the MAIN Mini App (the Website's /site
# surface — app/web/site). NEVER a per-bot URL, NEVER secrets in it.
MAIN_APP_PATH = "/site"

# bot_settings keys.
SETTING_PUBLIC_BASE_URL = "website_public_base_url"       # existing (v31)
SETTING_MENU_BUTTON_MODE = "network_bots_menu_button_mode"  # b10 §8D

# BOT-45/46 (master prompt §14) — the ONE authoritative Main Mini App
# bot username configuration + the optional Named Direct Mini App form
# (short_name / startapp parameter — used ONLY where actually configured).
# bot_settings is this project's canonical operator-configuration store
# (the same surface as website_public_base_url; environment parsing is
# architecture-restricted to app/bootstrap/config.py — RULE F).
SETTING_MAIN_MINI_APP_BOT_USERNAME = "main_mini_app_bot_username"
SETTING_MAIN_MINI_APP_DIRECT_SHORT_NAME = "main_mini_app_direct_short_name"
SETTING_MAIN_MINI_APP_DIRECT_STARTAPP = "main_mini_app_direct_startapp_param"

MENU_BUTTON_MODE_AUTO = "auto"          # default: apply on every start
MENU_BUTTON_MODE_PRESERVE = "preserve"  # operator: never overwrite

MENU_BUTTON_TEXT = "Main App"

# ----------------------------------------------------------------------
# BOT-45/46 (master prompt §14) — username sanitization. "Do not guess the
# configured bot username": an explicit-but-garbage value is reported
# honestly and NEVER rendered as https://t.me/undefined?startapp.
# ----------------------------------------------------------------------
_BOT_USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{4,32}$")
_MINI_APP_SHORT_NAME_RE = re.compile(r"^[A-Za-z0-9_]{1,32}$")

# Placeholder-shaped usernames that must NEVER produce a t.me link
# (§14 explicitly forbids https://t.me/undefined?startapp and friends).
_BOT_USERNAME_SENTINELS = frozenset({
    "undefined", "null", "none", "username", "your_bot", "bot_username",
    "example_bot", "examplebot", "placeholder", "changeme", "todo",
    "yourbot", "put_your_bot", "put_your_bot_username",
    "put_your_bot_username_here", "main_bot", "mainbot",
    "mini_app_bot", "main_mini_app_bot",
})


def _db_get(db, name: str, default=None):
    return getattr(db, name, default)


async def _get_setting(db, key: str, default: str = "") -> str:
    getter = _db_get(db, "get_setting", None)
    if not callable(getter):
        return default
    try:
        return str(await getter(key, default) or default)
    except Exception:  # noqa: BLE001 — settings are best-effort
        return default


def validate_main_app_url(url) -> Tuple[bool, str]:
    """BOT-11 (spec §2-§5): the Main Mini App URL validation gate for the
    Change URL flow. Returns ``(ok, reason)`` — ``reason`` is the precise
    human-usable failure ("scheme_not_https", "whitespace",
    "control_characters", "no_host", "empty", "malformed"); "" when valid.

    HTTPS only, a valid absolute URL, a host present, no whitespace, no
    control characters, no unsupported schemes. A malformed URL is NEVER
    stored (the caller shows the reason and keeps the working value)."""
    from urllib.parse import urlsplit
    s = str(url or "")
    if not s.strip():
        return False, "empty"
    if s != s.strip() or any(ch.isspace() for ch in s):
        return False, "whitespace"
    if any(ord(ch) < 0x20 or ord(ch) == 0x7F for ch in s):
        return False, "control_characters"
    try:
        parts = urlsplit(s)
    except ValueError:
        return False, "malformed"
    if parts.scheme.lower() != "https":
        return False, "scheme_not_https"
    if not parts.netloc or not parts.hostname:
        return False, "no_host"
    return True, ""


async def canonical_main_app_url(db) -> str:
    """THE canonical Main Mini App URL ('' = not configured).

    ``<website_public_base_url>/site`` — HTTPS-validated (spec §8F: a
    mini app URL must be HTTPS; an http:// base is refused and reported
    honestly). Never raises; never a secret (the base URL is public).

    BOT-16 FIX — the base path is normalized EXACTLY ONCE through
    ``app.web.site.service.normalize_site_url``: production runs the site
    behind a ``/site`` prefix, the admin's ``website_public_base_url``
    legitimately ends with ``/site``, and the historical naive
    ``base + "/site"`` produced the broken ``https://host/site/site``
    menu button applied to every network bot (bot-16.log
    NETWORK_BOT_MENU_BUTTON_APPLIED url=.../site/site)."""
    base = (await _get_setting(db, SETTING_PUBLIC_BASE_URL, "")).strip()
    if not base:
        return ""
    try:
        from app.web.site.service import normalize_site_url
        url = normalize_site_url(base, MAIN_APP_PATH)
    except Exception:  # noqa: BLE001 — fall back to the naive shape
        url = base.rstrip("/") + MAIN_APP_PATH
    if not url.lower().startswith("https://"):
        logger.warning(
            "NETWORK_BOT_MAINAPP_URL_INVALID reason=not_https (the "
            "configured website_public_base_url is not an https URL — "
            "the Main Mini App link is NOT applied to network bots)")
        return ""
    return url


async def menu_button_mode(db) -> str:
    """The explicit operator policy for the Telegram menu button
    (b10 §8D: 'auto' applies/reapplies; 'preserve' never overwrites an
    existing configured menu button)."""
    mode = (await _get_setting(db, SETTING_MENU_BUTTON_MODE,
                               MENU_BUTTON_MODE_AUTO)).strip().lower()
    return mode if mode in (MENU_BUTTON_MODE_AUTO,
                            MENU_BUTTON_MODE_PRESERVE) \
        else MENU_BUTTON_MODE_AUTO


# ----------------------------------------------------------------------
# BOT-45/46 (master prompt §14) — MAIN MINI APP, ONE CANONICAL
# DESTINATION. The user-facing Telegram destination is the t.me form:
#   Main Mini App:   https://t.me/<actual_bot_username>?startapp
#   Named Direct:    https://t.me/<bot>/<short_name>?startapp=<parameter>
# NEVER the Worker URL (that stays an internal browser fallback via
# canonical_main_app_url), NEVER t.me/undefined, never another bot.
# ----------------------------------------------------------------------
def _sanitize_bot_username(raw) -> str:
    """Normalize a configured bot username (strip '@' / whitespace) and
    REFUSE anything that is not a plausible Telegram username — sentinel
    placeholders ("undefined", "your_bot", ...) and malformed values
    return '' (an honest unresolved state, never a broken t.me link)."""
    s = str(raw or "").strip().lstrip("@").strip()
    if not s:
        return ""
    if s.lower() in _BOT_USERNAME_SENTINELS:
        return ""
    if not _BOT_USERNAME_RE.match(s):
        return ""
    return s


def _sanitize_mini_app_short_name(raw) -> str:
    """The Named Direct Mini App short_name (BotFather-style: letters,
    digits, underscores). '' when not actually configured."""
    s = str(raw or "").strip()
    if not s:
        return ""
    if not _MINI_APP_SHORT_NAME_RE.match(s):
        logger.warning(
            "MINI_APP_LINK_CONFIG_INVALID key=%s value_len=%s reason="
            "not_a_short_name (the Named Direct Mini App form is NOT "
            "used — falling back to the main form)",
            SETTING_MAIN_MINI_APP_DIRECT_SHORT_NAME, len(s))
        return ""
    return s


def _sanitize_startapp_param(raw) -> str:
    """The direct link's startapp parameter (Telegram deep-link payload;
    no whitespace / control characters — percent-encoded at build time)."""
    s = str(raw or "").strip()
    if not s:
        return ""
    if any(ch.isspace() for ch in s) or any(
            ord(ch) < 0x20 or ord(ch) == 0x7F for ch in s):
        logger.warning(
            "MINI_APP_LINK_CONFIG_INVALID key=%s value_len=%s reason="
            "bad_startapp_param (the parameter is dropped, the link "
            "still opens the Mini App)",
            SETTING_MAIN_MINI_APP_DIRECT_STARTAPP, len(s))
        return ""
    return s


async def resolve_main_mini_app_bot_username(db=None, ns=None
                                              ) -> Optional[str]:
    """§14 MAIN_MINI_APP_BOT_USERNAME — the authoritative resolution
    chain (first resolvable tier wins; NEVER a guessed username):

    1. EXPLICIT CONFIG — the bot_settings row ``main_mini_app_bot_username``
       (the operator-set authoritative value; sanitized + sentinel-checked:
       a malformed explicit value is skipped honestly, never used).
    2. THE RUNTIME MAIN BOT'S OWN getMe USERNAME — the shared runtime
       namespace identity (``ns._MAIN_BOT_ME`` / ``ns.BOT_USERNAME``) that
       the main bot's post_init sets from its OWN live ``get_me()``;
       network workers share this namespace, so it is ALWAYS the MAIN
       bot's username — never a worker bot's, never "the old bot".
    3. LIVE getMe on the main bot client (``ns._mini_app_bot``) — last
       resort when the startup identity was never cached (best-effort,
       isolated; a failed call is an honest None).

    Returns ``None`` when nothing resolvable — the caller then shows the
    admin configuration error (NEVER a broken ``t.me/undefined`` link)."""
    # Tier 1 — explicit operator configuration.
    if db is not None:
        raw = await _get_setting(db, SETTING_MAIN_MINI_APP_BOT_USERNAME, "")
        explicit = _sanitize_bot_username(raw)
        if explicit:
            return explicit
        if str(raw or "").strip():
            logger.warning(
                "MINI_APP_LINK_CONFIG_INVALID key=%s value_len=%s "
                "reason=not_a_bot_username (the explicit value is "
                "refused honestly — resolution falls through to the "
                "runtime main-bot identity)",
                SETTING_MAIN_MINI_APP_BOT_USERNAME, len(str(raw or "")))
    # Tier 2 — the runtime MAIN bot's own identity (network workers share
    # the namespace, so this is the MAIN bot's username, not a worker's).
    for attr in ("_MAIN_BOT_ME", "BOT_USERNAME"):
        if ns is None:
            break
        candidate = _sanitize_bot_username(getattr(ns, attr, "") or "")
        if candidate:
            return candidate
    # Tier 3 — live getMe on the main bot client (best-effort, isolated).
    client = getattr(ns, "_mini_app_bot", None) if ns is not None else None
    get_me = getattr(client, "get_me", None)
    if callable(get_me):
        try:
            me_obj = await get_me()
            candidate = _sanitize_bot_username(
                getattr(me_obj, "username", "") or "")
            if candidate:
                return candidate
        except Exception as exc:  # noqa: BLE001 — honest None, never raises
            logger.info(
                "MAIN_MINI_APP_BOT_USERNAME_LIVE_GETME_FAILED error=%s "
                "(resolution returns None — no guessed username)",
                type(exc).__name__)
    return None


async def build_main_mini_app_link(db=None, ns=None) -> Optional[str]:
    """§14 — THE one canonical Main Mini App link (master prompt §14:
    one helper, one authoritative destination).

    Main Mini App form:
      ``https://t.me/<actual_bot_username>?startapp``
    Named Direct Mini App — ONLY where actually configured (short_name):
      ``https://t.me/<actual_bot_username>/<short_name>?startapp=<parameter>``

    NEVER ``t.me/undefined``, an old bot, another bot, or an arbitrary
    Worker URL as the Telegram destination (the Worker URL stays an
    internal browser fallback — ``canonical_main_app_url``).

    Emits MINI_APP_LINK_BUILD telemetry (safe fields, no secrets):
    ``bot_username``, ``link_type=main|direct``, ``startapp_present``,
    ``destination``. Returns ``None`` when the username is unresolvable
    (callers must handle None with an admin configuration error message —
    never a fabricated link). Never raises."""
    try:
        username = await resolve_main_mini_app_bot_username(db, ns)
        if not username:
            logger.info(
                "MINI_APP_LINK_UNRESOLVED reason=no_bot_username "
                "(MAIN_MINI_APP_BOT_USERNAME not configured and no runtime "
                "main-bot identity — callers must show the admin "
                "configuration error, never a broken URL)")
            return None
        short_name = ""
        startapp_param = ""
        if db is not None:
            short_name = _sanitize_mini_app_short_name(
                await _get_setting(
                    db, SETTING_MAIN_MINI_APP_DIRECT_SHORT_NAME, ""))
            startapp_param = _sanitize_startapp_param(
                await _get_setting(
                    db, SETTING_MAIN_MINI_APP_DIRECT_STARTAPP, ""))
        if short_name:
            destination = f"https://t.me/{username}/{short_name}"
            if startapp_param:
                from urllib.parse import quote
                destination += "?startapp=" + quote(
                    startapp_param, safe="")
            else:
                destination += "?startapp"
            link_type = "direct"
        else:
            destination = f"https://t.me/{username}?startapp"
            link_type = "main"
        logger.info(
            "MINI_APP_LINK_BUILD bot_username=%s link_type=%s "
            "startapp_present=true destination=%s (§14 canonical Main "
            "Mini App link — one authoritative Telegram destination)",
            username, link_type, destination)
        return destination
    except Exception as exc:  # noqa: BLE001 — never raise on link building
        logger.warning(
            "MINI_APP_LINK_UNRESOLVED reason=error error=%s (no link "
            "built — the callers show the admin configuration error)",
            type(exc).__name__)
        return None


def describe_main_mini_app_link(url) -> Dict[str, str]:
    """The §14 SAFE telemetry fields derived from a built link:
    ``bot_username`` / ``link_type=main|direct`` / ``startapp_present`` /
    ``destination`` (the URL itself is public and secret-free by
    construction). Pure, never raises — the MAIN_APP_OPEN emitters use
    this so the field set stays identical to MINI_APP_LINK_BUILD."""
    from urllib.parse import parse_qsl, urlsplit
    s = str(url or "")
    fields: Dict[str, str] = {
        "bot_username": "",
        "link_type": "main",
        "startapp_present": "false",
        "destination": s,
    }
    if not s:
        return fields
    try:
        parts = urlsplit(s)
    except ValueError:
        return fields
    segments = [p for p in str(parts.path or "").split("/") if p]
    if segments:
        fields["bot_username"] = segments[0]
    fields["link_type"] = "direct" if len(segments) >= 2 else "main"
    try:
        query = dict(parse_qsl(parts.query or "", keep_blank_values=True))
    except Exception:  # noqa: BLE001 — telemetry only
        query = {}
    fields["startapp_present"] = "true" if "startapp" in query else "false"
    return fields


async def _persist_mini_app_state(db, network_bot_id: int, *, url: str,
                                  status: str, error: str = "") -> None:
    """BOT-11 (spec §9/§10): persist the per-bot Mini App last-apply
    outcome (schema v35 columns) — best-effort + isolated (an adapter
    without the v35 method simply skips; a persistence failure NEVER
    changes the apply verdict). nid<=0 (the MAIN bot has no row) skips."""
    nid = int(network_bot_id or 0)
    if nid <= 0:
        return
    setter = _db_get(db, "update_network_bot_mini_app", None)
    if not callable(setter):
        return
    try:
        await setter(nid, url=str(url or ""), status=str(status or ""),
                     error=str(error or ""))
    except Exception as exc:  # noqa: BLE001 — persistence is best-effort
        logger.warning("MINI_APP_STATE_PERSIST_FAILED network_bot_id=%s "
                       "error=%s (the apply verdict is unchanged)", nid,
                       type(exc).__name__)


async def apply_main_app_link(db, bot_client, network_bot_id: int,
                              username: str = "") -> Dict[str, Any]:
    """Best-effort: configure the registered bot's Telegram MENU BUTTON
    to launch the MAIN Mini App (spec §8B) through the bot's own client.

    Returns a truthful result dict:
      {"ok": bool, "url": str, "menu_button": "<outcome>", "reason": str}
    Outcomes: applied | skipped_preserve | skipped_no_url |
    skipped_no_client | failed. Never raises; never logs secrets.

    BOT-11 (spec §9/§10): EVERY outcome is also persisted per-bot via
    ``db.update_network_bot_mini_app`` (url + applied_at + status +
    error) — the truthful state the admin panel badges render from."""
    nid = int(network_bot_id or 0)
    url = await canonical_main_app_url(db)
    if not url:
        logger.info("NETWORK_BOT_MENU_BUTTON_SKIPPED network_bot_id=%s "
                    "reason=no_url (website_public_base_url not "
                    "configured — no Main Mini App link applied)", nid)
        await _persist_mini_app_state(db, nid, url="", status="no_url",
                                      error="no_url")
        return {"ok": False, "url": "", "menu_button": "skipped_no_url",
                "reason": "no_url"}
    if bot_client is None:
        logger.info("NETWORK_BOT_MENU_BUTTON_SKIPPED network_bot_id=%s "
                    "reason=no_client (bot worker not running)", nid)
        await _persist_mini_app_state(db, nid, url=url,
                                      status="no_client",
                                      error="no_client")
        return {"ok": False, "url": url, "menu_button": "skipped_no_client",
                "reason": "no_client"}
    mode = await menu_button_mode(db)
    if mode == MENU_BUTTON_MODE_PRESERVE:
        # b10 §8D: the operator explicitly preserves existing configured
        # menu buttons — NO setChatMenuButton call is made at all.
        logger.info("NETWORK_BOT_MENU_BUTTON_SKIPPED network_bot_id=%s "
                    "reason=preserve (network_bots_menu_button_mode="
                    "preserve — existing menu buttons untouched)", nid)
        await _persist_mini_app_state(db, nid, url=url, status="preserve",
                                      error="preserve")
        return {"ok": True, "url": url, "menu_button": "skipped_preserve",
                "reason": "preserve"}
    setter = getattr(bot_client, "set_chat_menu_button", None)
    if not callable(setter):
        logger.info("NETWORK_BOT_MENU_BUTTON_SKIPPED network_bot_id=%s "
                    "reason=no_set_chat_menu_button (client transport "
                    "lacks the method)", nid)
        await _persist_mini_app_state(db, nid, url=url, status="no_client",
                                      error="no_set_chat_menu_button")
        return {"ok": False, "url": url,
                "menu_button": "skipped_no_client",
                "reason": "no_set_chat_menu_button"}
    try:
        from telegram import MenuButtonWebApp, WebAppInfo
        await setter(menu_button=MenuButtonWebApp(
            text=MENU_BUTTON_TEXT, web_app=WebAppInfo(url=url)))
        logger.info("NETWORK_BOT_MENU_BUTTON_APPLIED network_bot_id=%s "
                    "username=@%s url=%s text=%r (registered bot menu "
                    "button → MAIN Mini App)", nid, (username or ""),
                    url, MENU_BUTTON_TEXT)
        await _persist_mini_app_state(db, nid, url=url, status="applied",
                                      error="")
        return {"ok": True, "url": url, "menu_button": "applied",
                "reason": ""}
    except Exception as exc:  # noqa: BLE001 — best-effort, truthful reason
        logger.warning("NETWORK_BOT_MENU_BUTTON_FAILED network_bot_id=%s "
                       "reason=%s error=%s (best-effort — the worker "
                       "stays up)", nid, type(exc).__name__,
                       str(exc)[:120])
        await _persist_mini_app_state(db, nid, url=url, status="failed",
                                      error=type(exc).__name__)
        return {"ok": False, "url": url, "menu_button": "failed",
                "reason": type(exc).__name__}


async def on_worker_started(ns, network_bot_id: int) -> None:
    """The BotWorkerManager post-start hook (b10 §8C): (re)apply the Main
    Mini App link right after EVERY worker start — new registration,
    managed creation, legacy import AND the restart path. Never raises
    (the manager isolates it too — defense in depth).

    BOT-11 (spec §1): the same hook ALSO persists the worker's
    getMe-derived ``can_manage_bots`` capability ONCE per start — the
    workers.py helper (best-effort + isolated; a worker without the flag
    reported stores the honest NULL, never a fabricated value). This IS
    the sanctioned "worker start path" persistence site: lifecycle.py
    wires ``ns._net_on_worker_started`` into BotWorkerManager
    (on_worker_started=…), so every production worker start —
    registration, managed creation, reactivate (reactivate_network_bot
    restarts the worker → this hook fires) and restart — persists the
    capability. Best-effort + isolated (never kills the worker)."""
    try:
        nid = int(network_bot_id or 0)
        workers = _db_get(ns, "_net_workers", None)
        bot_client = None
        if workers is not None:
            try:
                bot_client = workers.get_bot_client(nid)
            except Exception:  # noqa: BLE001
                bot_client = None
        username = ""
        try:
            w = workers.get(nid) if workers is not None else None
            username = str(getattr(w, "username", "") or "")
        except Exception:  # noqa: BLE001
            username = ""
        db = _db_get(ns, "db", None)
        await apply_main_app_link(db, bot_client, nid, username)
        # BOT-11 (spec §1): capability persistence on every worker start.
        if db is not None:
            try:
                from app.network.workers import persist_worker_capability
                await persist_worker_capability(db, bot_client, nid)
            except Exception:  # noqa: BLE001 — isolated, never fatal
                logger.warning(
                    "MANAGED_BOT_CAPABILITY_PERSIST_FAILED "
                    "network_bot_id=%s (worker stays up)", nid,
                    exc_info=True)
    except Exception:  # noqa: BLE001 — never break the worker start
        pass


async def apply_main_app_link_to_all(ns,
                                     main_bot_client=None
                                     ) -> Dict[str, Any]:
    """ADMIN action (b10 §8E + BOT-11 spec §2-§5): 'Apply Main App Link
    to All Registered Bots' — iterate every ACTIVE network bot, reapply
    the button, persist EVERY per-bot outcome (schema v35), return the
    §4 TRUTHFUL structured result:

      {"url": <canonical>,
       "applied":   [nid, ...],                # registered bots applied
       "failed":    [(nid, reason), ...],
       "skipped":   [(nid, reason), ...],
       "main":      None | {"attempted": bool, "applied": bool,
                            "reason": str, "username": str},
       "outcomes":  [{"network_bot_id", "username", "outcome"}, ...],
       "total": int, "applied_count": int, "failed_count": int,
       "skipped_count": int, "offline_count": int,
       "reason": "no_url" | None}

    The bulk result is TRUTHFUL (§4): never "all updated" when one
    failed — the failed list carries the per-bot reason. ``main_bot_client``
    is the LIVE main bot client (the wsmain panel passes context.bot);
    when provided the MAIN bot is applied too and its outcome lands in
    ``main`` (an unreachable main bot is reported under Failed by the
    CALLER from ``main`` — the registered-bot lists never carry nid 0).
    Logs (spec §19, ids only): MINI_APP_BULK_APPLY_START /
    MINI_APP_APPLY_START / MINI_APP_APPLY_OK / MINI_APP_APPLY_FAILED /
    MINI_APP_BULK_APPLY_RESULT."""
    db = _db_get(ns, "db", None)
    workers = _db_get(ns, "_net_workers", None)
    url = await canonical_main_app_url(db)
    summary: Dict[str, Any] = {
        "url": url, "applied": [], "failed": [], "skipped": [],
        "main": None, "outcomes": [], "total": 0, "applied_count": 0,
        "failed_count": 0, "skipped_count": 0, "offline_count": 0,
        "reason": None,
    }
    if not url:
        summary["reason"] = "no_url"
        return summary
    logger.info("MINI_APP_BULK_APPLY_START url_configured=true "
                "(apply Main Mini App menu button to every ACTIVE "
                "registered bot)")
    # ---- the MAIN bot (BOT-11 §4): applied too when its live client is
    # provided; nid 0 never enters the registered-bot lists.
    main_client = main_bot_client
    if main_client is None:
        main_client = _db_get(ns, "_mini_app_bot", None)
    main_username = ""
    if main_client is not None:
        try:
            me = getattr(main_client, "get_me", None)
            me_obj = await me() if callable(me) else None
            main_username = str(getattr(me_obj, "username", "") or "")
        except Exception:  # noqa: BLE001 — best-effort label only
            main_username = ""
        logger.info("MINI_APP_APPLY_START network_bot_id=0 (main bot)")
        res_main = await apply_main_app_link(db, main_client, 0,
                                             main_username)
        ok_main = bool(res_main.get("ok"))
        logger.info("MINI_APP_APPLY_%s network_bot_id=0 (main bot)",
                    "OK" if ok_main else "FAILED")
        summary["main"] = {
            "attempted": True, "applied": ok_main,
            "reason": str(res_main.get("reason") or ""),
            "username": main_username,
        }
    else:
        summary["main"] = {"attempted": True, "applied": False,
                           "reason": "no_client", "username": ""}
    lister = _db_get(db, "list_network_bots", None)
    bots = []
    if callable(lister):
        try:
            bots = await lister()
        except Exception:  # noqa: BLE001 — honest empty summary
            bots = []
    for b in bots or []:
        if str((b or {}).get("status") or "") != "ACTIVE":
            continue
        nid = int((b or {}).get("id") or (b or {}).get("network_bot_id")
                  or 0)
        username = str((b or {}).get("username") or "")
        summary["total"] += 1
        bot_client = None
        if workers is not None:
            try:
                bot_client = workers.get_bot_client(nid)
            except Exception:  # noqa: BLE001
                bot_client = None
        logger.info("MINI_APP_APPLY_START network_bot_id=%s", nid)
        res = await apply_main_app_link(db, bot_client, nid, username)
        outcome = str(res.get("menu_button") or "failed")
        if outcome == "applied":
            summary["applied"].append(nid)
            summary["applied_count"] += 1
            logger.info("MINI_APP_APPLY_OK network_bot_id=%s username=%s",
                        nid, username)
        elif outcome in ("skipped_no_client", "skipped_no_url"):
            # A bot whose worker is not running / no URL — an honest
            # skipped entry (legacy surfaces counted these "offline").
            reason = str(res.get("reason") or outcome)
            summary["skipped"].append((nid, reason))
            summary["skipped_count"] += 1
            summary["offline_count"] += 1
            logger.info("MINI_APP_APPLY_SKIPPED network_bot_id=%s "
                        "reason=%s", nid, reason)
        elif outcome.startswith("skipped"):
            reason = str(res.get("reason") or outcome)
            summary["skipped"].append((nid, reason))
            summary["skipped_count"] += 1
            logger.info("MINI_APP_APPLY_SKIPPED network_bot_id=%s "
                        "reason=%s", nid, reason)
        else:
            reason = str(res.get("reason") or "failed")
            summary["failed"].append((nid, reason))
            summary["failed_count"] += 1
            logger.info("MINI_APP_APPLY_FAILED network_bot_id=%s "
                        "reason=%s", nid, reason)
        summary["outcomes"].append(
            {"network_bot_id": nid, "username": username,
             "outcome": outcome})
    logger.info(
        "MINI_APP_BULK_APPLY_RESULT applied=%s failed=%s skipped=%s "
        "total=%s main_applied=%s (per-bot state persisted for every "
        "outcome)", summary["applied_count"], summary["failed_count"],
        summary["skipped_count"], summary["total"],
        (summary["main"] or {}).get("applied"))
    return summary


__all__ = [
    "MAIN_APP_PATH",
    "SETTING_MENU_BUTTON_MODE",
    "SETTING_MAIN_MINI_APP_BOT_USERNAME",
    "SETTING_MAIN_MINI_APP_DIRECT_SHORT_NAME",
    "SETTING_MAIN_MINI_APP_DIRECT_STARTAPP",
    "MENU_BUTTON_MODE_AUTO",
    "MENU_BUTTON_MODE_PRESERVE",
    "MENU_BUTTON_TEXT",
    "canonical_main_app_url",
    "validate_main_app_url",
    "menu_button_mode",
    "resolve_main_mini_app_bot_username",
    "build_main_mini_app_link",
    "describe_main_mini_app_link",
    "apply_main_app_link",
    "on_worker_started",
    "apply_main_app_link_to_all",
]
