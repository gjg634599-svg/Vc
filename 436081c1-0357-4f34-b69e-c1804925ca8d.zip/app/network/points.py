"""NETWORK (N2): points ledger service.

STANDALONE MODULE — pure logic over an injected DB adapter (same
discipline as app/core/*). bot.py wires this service with the Database
class methods created by migration v29.

Spec requirements implemented here (§6 POINT SYSTEM, §7 POINT REWARD
RULES, §10 POINT DEBIT TRANSACTION):

  * REAL ledger (points_ledger) — every point movement is an auditable row
    with event_type / amount / reference / idempotency_key.
  * credit_points is IDEMPOTENT: the same event processed twice MUST NOT
    award twice (UNIQUE idempotency_key; INSERT OR IGNORE semantics with
    an inserted-rowcount result).
  * debit_points is ATOMIC + balance-safe: BEGIN IMMEDIATE → verify
    balance ≥ amount → insert the debit row → COMMIT. Any failure rolls
    back; a concurrent second debit that would overdraw is rejected by the
    write lock + balance re-check (no negative balances).
  * get_points = SUM(ledger) — the ledger is authoritative; there is no
    separate mutable balance column to drift.
  * Configurable values (spec §7): points per bot registration, max
    registration reward per user, max registered bots per user, point cost
    per payload unlock, points access enabled — ALL read from the caller
    (bot_settings) so admins can change them without corrupting history.
  * A point unlock (payload purchase) is a TRANSACTION: debit + unlock
    record commit together or not at all (spec §10); the unlock record is
    UNIQUE(payload_id, user_id) so a second unlock attempt for an already
    unlocked payload never debits again.

This module NEVER sends UI and NEVER talks to Telegram. It returns plain
result dicts the bot layer renders.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger("app.network.points")

# Ledger event types (spec §69 structured vocabulary)
EVENT_BOT_REGISTERED = "BOT_REGISTERED"
EVENT_PAYLOAD_UNLOCK = "PAYLOAD_UNLOCK"
EVENT_ADMIN_CREDIT = "ADMIN_CREDIT"
EVENT_ADMIN_DEBIT = "ADMIN_DEBIT"
# FILE DELIVERY v34 (spec §60): the +5 reward for a Network Bot that
# completed its Delivery Group setup (DELIVERY_READY) — awarded ONLY
# after the full verified chain, never at registration.
EVENT_DELIVERY_READY = "DELIVERY_READY"

REF_TYPE_NETWORK_BOT = "NETWORK_BOT"
REF_TYPE_PAYLOAD = "PAYLOAD"


class PointService:
    """Points ledger operations over the injected DB adapter.

    The adapter must provide (all created in migration v29 / bot.py):
        await db.points_balance(user_id) -> int
        await db.points_credit(user_id, amount, event_type, reference_type,
                               reference_id, idempotency_key, metadata)
            -> {"inserted": bool, "ledger_id": Optional[int]}
        await db.points_debit_atomic(user_id, amount, event_type,
                                     reference_type, reference_id,
                                     idempotency_key, metadata)
            -> {"ok": bool, "reason": str, "ledger_id": Optional[int]}
        await db.points_history(user_id, limit) -> List[dict]
        await db.point_unlock_record(payload_id, user_id) -> Optional[dict]
        await db.point_unlock_valid(payload_id, user_id) -> bool
        await db.point_unlock_purchase(payload_id, user_id, cost,
                                       ledger_id) -> dict
            (atomic: unlock insert + validity; assumes the CALLER already
             committed the debit in the SAME transaction when used via
             purchase_with_debit below)
        await db.points_purchase_transaction(payload_id, user_id, cost)
            -> {"ok": bool, "reason": str, "ledger_id": Optional[int]}
            (the full BEGIN IMMEDIATE debit+unlock transaction)
        await db.points_registration_reward_count(user_id) -> int
        await db.points_total_event_count(event_type) -> int
    """

    def __init__(self, db_adapter) -> None:
        self.db = db_adapter

    # ------------------------------------------------------------------
    # Balances / history
    # ------------------------------------------------------------------
    async def get_points(self, user_id: int) -> int:
        return int(await self.db.points_balance(int(user_id)))

    async def has_sufficient_points(self, user_id: int, amount: int) -> bool:
        return (await self.get_points(user_id)) >= int(amount)

    async def history(self, user_id: int, limit: int = 20
                      ) -> List[Dict[str, Any]]:
        return await self.db.points_history(int(user_id), int(limit))

    # ------------------------------------------------------------------
    # Credits (idempotent)
    # ------------------------------------------------------------------
    async def credit_points(self, user_id: int, amount: int, *,
                            event_type: str,
                            reference_type: Optional[str] = None,
                            reference_id: Optional[int] = None,
                            idempotency_key: str,
                            metadata: Optional[str] = None
                            ) -> Dict[str, Any]:
        """Credit points ONCE per idempotency_key.

        Returns {"inserted": bool, ...}: inserted=False means this exact
        event was already processed (duplicate) — never a double award.
        Negative/zero amounts are rejected here (credits are positive).
        """
        amount = int(amount)
        if amount <= 0:
            return {"inserted": False, "reason": "invalid_amount",
                    "ledger_id": None}
        res = await self.db.points_credit(
            int(user_id), amount, event_type,
            reference_type or "", reference_id,
            idempotency_key, metadata)
        if not res.get("inserted"):
            logger.info("POINTS_DUPLICATE_EVENT user_id=%s event=%s key=%s "
                        "(already processed — no second award)",
                        user_id, event_type, idempotency_key[:24])
        else:
            logger.info("POINTS_CREDITED user_id=%s event=%s amount=+%s "
                        "ref=%s:%s ledger_id=%s",
                        user_id, event_type, amount, reference_type,
                        reference_id, res.get("ledger_id"))
        return res

    async def debit_points(self, user_id: int, amount: int, *,
                           event_type: str,
                           reference_type: Optional[str] = None,
                           reference_id: Optional[int] = None,
                           idempotency_key: str,
                           metadata: Optional[str] = None
                           ) -> Dict[str, Any]:
        """Atomic balance-safe debit (spec §10).

        Returns {"ok": False, "reason": "insufficient_points"|"invalid_amount"
        |"duplicate", ...} on refusal — the caller must NOT grant the unlock.
        """
        amount = int(amount)
        if amount <= 0:
            return {"ok": False, "reason": "invalid_amount",
                    "ledger_id": None}
        res = await self.db.points_debit_atomic(
            int(user_id), amount, event_type,
            reference_type or "", reference_id,
            idempotency_key, metadata)
        if res.get("ok"):
            logger.info("POINTS_DEBITED user_id=%s event=%s amount=-%s "
                        "ref=%s:%s ledger_id=%s",
                        user_id, event_type, amount, reference_type,
                        reference_id, res.get("ledger_id"))
        else:
            logger.info("POINTS_REJECTED user_id=%s event=%s amount=-%s "
                        "reason=%s",
                        user_id, event_type, amount, res.get("reason"))
        return res

    # ------------------------------------------------------------------
    # Registration reward (+5, capped)
    # ------------------------------------------------------------------
    async def award_registration_reward(self, user_id: int,
                                        network_bot_id: int, *,
                                        points_per_bot: int,
                                        max_reward: int) -> Dict[str, Any]:
        """Award the registration reward for ONE verified activation.

        Idempotency key is derived from the bot identity, so re-processing
        the same activation can never double-award. The reward is REFUSED
        (no exception, honest reason) when it would exceed the configured
        maximum registration reward for the user — history is never
        corrupted by changing the settings later.
        """
        key = f"botreg:{int(network_bot_id)}:{int(user_id)}"
        already = await self.db.points_registration_reward_count(int(user_id))
        if int(points_per_bot) <= 0:
            return {"inserted": False, "reason": "reward_disabled"}
        if already + int(points_per_bot) > int(max_reward):
            return {"inserted": False,
                    "reason": "max_registration_reward_reached",
                    "awarded": already, "cap": int(max_reward)}
        return await self.credit_points(
            int(user_id), int(points_per_bot),
            event_type=EVENT_BOT_REGISTERED,
            reference_type=REF_TYPE_NETWORK_BOT,
            reference_id=int(network_bot_id),
            idempotency_key=key,
            metadata=f"network_bot_id={int(network_bot_id)}")

    # ------------------------------------------------------------------
    # Delivery-Ready reward (+5 — spec §60/§61)
    # ------------------------------------------------------------------
    async def award_delivery_ready_reward(self, user_id: int,
                                          network_bot_id: int, *,
                                          points_per_bot: int = 5,
                                          max_reward: int = 25
                                          ) -> Dict[str, Any]:
        """Award the setup reward ONLY after the Network Bot reached
        DELIVERY_READY (registered + Delivery Group configured + File
        Delivery Bot present + admin + required permissions + network
        bot present + identity + delivery capability verified — spec
        §60). The caller (the verification flow) must invoke this exactly
        at the DELIVERY_READY transition.

        Idempotency (spec §61 — never award twice across duplicate
        callbacks, restarts, repeated verification, worker restarts or
        retries):
          * the spec-mandated key ``network_setup_reward:<user>:<bot>``;
          * PLUS the legacy BOT_REGISTERED reward for the SAME bot is
            treated as already-awarded (spec §62: a pre-v34 bot that got
            its +5 at registration is never re-awarded when it later
            completes Delivery Group setup).
        """
        key = f"network_setup_reward:{int(user_id)}:{int(network_bot_id)}"
        if int(points_per_bot) <= 0:
            return {"inserted": False, "reason": "reward_disabled"}
        # Legacy double-award guard (spec §62).
        legacy = await self.db.points_ledger_has_event(
            int(user_id), EVENT_BOT_REGISTERED, REF_TYPE_NETWORK_BOT,
            int(network_bot_id))
        if legacy:
            return {"inserted": False, "reason": "legacy_reward_exists"}
        already = await self.db.points_registration_reward_count(int(user_id))
        if already + int(points_per_bot) > int(max_reward):
            return {"inserted": False,
                    "reason": "max_registration_reward_reached",
                    "awarded": already, "cap": int(max_reward)}
        return await self.credit_points(
            int(user_id), int(points_per_bot),
            event_type=EVENT_DELIVERY_READY,
            reference_type=REF_TYPE_NETWORK_BOT,
            reference_id=int(network_bot_id),
            idempotency_key=key,
            metadata=f"network_bot_id={int(network_bot_id)}")

    # ------------------------------------------------------------------
    # Payload unlock purchase (transactional debit + unlock)
    # ------------------------------------------------------------------
    async def purchase_payload_unlock(self, user_id: int, payload_id: int, *,
                                      cost: int) -> Dict[str, Any]:
        """One transaction: debit + unlock record (spec §10).

        Guarantees enforced by the DB transaction (db.points_purchase_...):
          * BEGIN IMMEDIATE (write lock — concurrent purchases serialize)
          * unlock already exists for (payload, user) → ok=True, debited=False
            (idempotent: never debits twice for the same payload)
          * balance < cost → ROLLBACK → ok=False reason=insufficient_points
          * insert ledger debit + point_unlocks row → COMMIT
        The caller is responsible for verifying access eligibility BEFORE
        invoking this (the Access Engine decides whether point access is a
        valid path; this method only moves value atomically).
        """
        cost = int(cost)
        if cost <= 0:
            return {"ok": False, "reason": "invalid_cost"}
        res = await self.db.points_purchase_transaction(
            int(payload_id), int(user_id), cost)
        if res.get("ok"):
            logger.info("POINTS_DEBITED user_id=%s event=%s amount=-%s "
                        "ref=%s:%s ledger_id=%s (payload unlock purchased)",
                        user_id, EVENT_PAYLOAD_UNLOCK, cost,
                        REF_TYPE_PAYLOAD, payload_id, res.get("ledger_id"))
        else:
            logger.info("POINTS_REJECTED user_id=%s event=%s amount=-%s "
                        "reason=%s payload_id=%s",
                        user_id, EVENT_PAYLOAD_UNLOCK, cost,
                        res.get("reason"), payload_id)
        return res

    async def payload_unlocked(self, payload_id: int, user_id: int) -> bool:
        """Does the user hold a valid point unlock for this payload?"""
        return bool(await self.db.point_unlock_valid(int(payload_id),
                                                     int(user_id)))


__all__ = [
    "PointService", "EVENT_BOT_REGISTERED", "EVENT_PAYLOAD_UNLOCK",
    "EVENT_ADMIN_CREDIT", "EVENT_ADMIN_DEBIT",
    "REF_TYPE_NETWORK_BOT", "REF_TYPE_PAYLOAD",
]
