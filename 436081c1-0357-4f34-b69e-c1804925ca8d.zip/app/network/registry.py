"""NETWORK (N1): bot registry — verified activation, identity, health.

STANDALONE MODULE — never imports the bot monolith (same discipline as
app/core/*). bot.py wires this service with its DB adapter + credential
vault + HTTP transport.

Spec sections implemented here:

§2 BOT REGISTRATION — VERIFIED ACTIVATION ONLY. The state machine below
    NEVER awards anything for a token-shaped string: every step must pass
    or the whole registration is refused with a safe reason and NOTHING
    persisted (no orphan credential, no partial record).

    submit → validate token with Telegram (getMe) → resolve identity →
    check duplicate (same Telegram bot re-registered) → check ownership
    authorization (consent flag) → check per-user limit (max 5, evaluated
    INSIDE the transaction that inserts) → insert (PENDING) → worker
    start + health check → ACTIVE → award (+5 via PointService, strictly
    after activation).

§4 BOT INVALIDATION — TOKEN_INVALID excludes from routing, stops worker
    activity; explicit re-registration/credential replacement recovers.

§5 MAX 5 PER USER — enforced in the DB transaction (INSERT ... SELECT
    WHERE count < limit) so two simultaneous registrations can never both
    succeed past the cap (transaction-safe server-side enforcement; UI
    checks are informational only).

§13 BOT REGISTRY — network_bots metadata (owner, telegram_bot_id,
    username, display_name, status, health timestamps, routing_weight,
    capabilities).

§14 BOT HEALTH — states HEALTHY / DEGRADED / TEMPORARILY_UNAVAILABLE /
    TOKEN_INVALID / DISABLED / UNKNOWN; transient failures never become
    permanent invalid states.

§15 USER ↔ BOT RELATIONSHIP — user_bot_memberships upserts (first start,
    last active, blocked status).

§57 OWNERSHIP / CONSENT — the registration requires an explicit consent
    confirmation before activation.

§3 TOKEN SECURITY — this module works with the encrypted vault only;
    the plaintext token exists transiently during validation and worker
    construction and is never logged (mask_token for diagnostics).

Token validation uses a DIRECT Telegram Bot API getMe call with the
candidate token (aiohttp httpx-free; the transport is injected so tests
can fake it). We do NOT build a PTB Application just to validate.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from app.network.credentials import ENCRYPTION_KEY_MISSING_GUIDANCE

logger = logging.getLogger("app.network.registry")

# Registry statuses (spec §13)
STATUS_PENDING = "PENDING"
STATUS_ACTIVE = "ACTIVE"
STATUS_DEGRADED = "DEGRADED"
STATUS_DISABLED = "DISABLED"
STATUS_TOKEN_INVALID = "TOKEN_INVALID"
STATUS_ERROR = "ERROR"
# b10 §5: removal is a DISTINCT terminal status — a removed bot is gone
# (never counts toward the per-user cap, never renders in My Network,
# never routes). DISABLED stays what it always was: an admin/owner
# PAUSE (re-enabling is possible).
STATUS_REMOVED = "REMOVED"


def _row_is_removed(row: Optional[Dict[str, Any]]) -> bool:
    """True when a registry row represents a REMOVED bot — including
    the b10 §5.7 LEGACY shape (rows removed under the old scheme carry
    status=DISABLED + last_error_code=REMOVED)."""
    if not row:
        return False
    status = str(row.get("status") or "")
    if status == STATUS_REMOVED:
        return True
    return (status == STATUS_DISABLED
            and str(row.get("last_error_code") or "").upper() == "REMOVED")

# Health states (spec §14)
HEALTHY = "HEALTHY"
DEGRADED = "DEGRADED"
TEMPORARILY_UNAVAILABLE = "TEMPORARILY_UNAVAILABLE"
H_TOKEN_INVALID = "TOKEN_INVALID"
H_DISABLED = "DISABLED"
UNKNOWN = "UNKNOWN"

# Registration failure reasons (safe, non-secret, user-explainable)
R_INVALID_TOKEN = "invalid_token"               # Telegram rejected getMe
R_TRANSPORT = "telegram_unreachable"            # network/transient — retryable
R_BAD_FORMAT = "bad_token_format"
R_DUPLICATE_BOT = "duplicate_bot"               # same telegram bot already registered
R_OWNERSHIP = "ownership_not_confirmed"         # consent missing
R_LIMIT = "registration_limit_reached"          # max 5 per user
R_DISABLED_PLATFORM = "network_disabled"
# GAP-CLOSURE spec §3: the dedicated persistent encryption key is missing
# — production fails CLOSED for new registrations (no ephemeral fallback).
R_ENCRYPTION_KEY_MISSING = "encryption_key_missing"

_TOKEN_RE_MIN = 20


def token_format_ok(token: str) -> bool:
    """Cheap client-side format sanity: '<digits>:<alphanumerics>'.
    This is NOT validation — Telegram's getMe is the authority."""
    if not token or len(token) < _TOKEN_RE_MIN:
        return False
    parts = token.split(":", 1)
    if len(parts) != 2 or not parts[0].isdigit() or not parts[1]:
        return False
    return True


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class BotRegistryService:
    """Registration / lifecycle operations over the injected adapters.

    Adapters (created in bot.py):
        vault: CredentialVault (encrypt/decrypt)
        db: provides network bot + membership + settings methods
        validate_token: async (token) -> {"ok": bool, "bot": dict|None,
            "reason": str}  — a DIRECT Telegram getMe call (transport
            injected; never uses the main bot's API context)
        probe_storage_access: async (token) -> {"mode": "full"|"partial"|"none",
            "channels": [...]} — registration-time capability probe
        get_setting_int(key, default) — configurable limits
    """

    @property
    def can_encrypt_tokens(self) -> bool:
        """v36: UI-facing readiness probe — True only when the dedicated
        NETWORK_TOKEN_ENCRYPTION_KEY is configured (registrations are
        refused fail-closed without it)."""
        return bool(getattr(self.vault, "can_encrypt", False))

    def __init__(self, db_adapter, vault, validate_token,
                 probe_storage_access=None) -> None:
        self.db = db_adapter
        self.vault = vault
        self._validate_token = validate_token
        self._probe_storage = probe_storage_access

    # ------------------------------------------------------------------
    # Registration state machine (spec §2)
    # ------------------------------------------------------------------
    async def attempt_registration(self, owner_user_id: int, token: str, *,
                                   consent_confirmed: bool,
                                   display_name: Optional[str] = None,
                                   management_mode: str = "USER_OWNED",
                                   credential_control: str = "OWNER",
                                   created_via: str = "user_flow",
                                   ) -> Dict[str, Any]:
        """Full verified-activation flow. Returns a result dict:

        {"ok": True, "network_bot_id": int, "telegram_bot_id": int,
         "username": str, "status": STATUS_PENDING, "awarded": {...}}

        or  {"ok": False, "reason": R_*} — on ANY failure NOTHING is
        persisted (no partial registration, no orphan credential) and the
        reason is safe to show the user.

        v34 (spec §27-§29): ``management_mode`` persists the USER_OWNED vs
        PLATFORM_MANAGED distinction atomically with the registration.
        Registration NO LONGER probes storage access (spec §47): payload
        eligibility is Delivery Group readiness, and a network bot needs
        NO Storage membership at all in the relay architecture (spec §48).
        """
        # Step 0: platform switch + cheap format gate
        if not await self.db.get_setting_bool("network_enabled", True):
            return {"ok": False, "reason": R_DISABLED_PLATFORM}
        if not token_format_ok(token):
            return {"ok": False, "reason": R_BAD_FORMAT}
        # GAP-CLOSURE spec §3: fail CLOSED before any Telegram traffic when
        # the dedicated persistent NETWORK_TOKEN_ENCRYPTION_KEY is missing
        # (never persist a credential encrypted with a rotating
        # BOT_TOKEN-derived key in production). Existing bots keep working.
        if not getattr(self.vault, "can_encrypt", True):
            logger.warning(
                "NETWORK_BOT_REGISTER_FAILED owner=%s reason=%s "
                "(dedicated encryption key not configured)",
                owner_user_id, R_ENCRYPTION_KEY_MISSING)
            return {"ok": False, "reason": R_ENCRYPTION_KEY_MISSING,
                    "guidance": ENCRYPTION_KEY_MISSING_GUIDANCE}

        # Step 1: validate with Telegram + resolve identity (getMe).
        val = await self._validate_token(token)
        if not val.get("ok"):
            reason = val.get("reason") or R_TRANSPORT
            logger.info("NETWORK_BOT_REGISTER_FAILED owner=%s reason=%s "
                        "(Telegram validation)", owner_user_id, reason)
            return {"ok": False, "reason": reason}
        bot_info = val["bot"]
        telegram_bot_id = int(bot_info["id"])
        username = (bot_info.get("username") or "").lstrip("@")
        if not username:
            return {"ok": False, "reason": R_INVALID_TOKEN}

        # Step 2: duplicate registration — the same Telegram bot may not
        # be registered twice (by anyone) — and definitely not by a
        # second user (spec §2 prevent list).
        # BOT-11 §5/§6/§7 (B11-A): the refusal stays a refusal, but it now
        # carries the EXISTING bot's current status + a pre-computed
        # recovery hint so the UI (B11-B) can offer the honest path
        # (reactivate a REMOVED same-owner bot / change the token /
        # other-owner dead end) instead of a bare dead end.
        existing = await self.db.get_network_bot_by_telegram_id(telegram_bot_id)
        if existing is not None:
            same_owner = int(existing["owner_user_id"]) == int(owner_user_id)
            removed = _row_is_removed(existing)
            logger.info("NETWORK_BOT_REGISTER_FAILED owner=%s reason=%s "
                        "telegram_bot_id=%s same_owner=%s existing_status=%s "
                        "removed=%s",
                        owner_user_id, R_DUPLICATE_BOT, telegram_bot_id,
                        same_owner,
                        str(existing.get("status") or "-") or "-", removed)
            return {"ok": False, "reason": R_DUPLICATE_BOT,
                    "same_owner": same_owner,
                    "existing_bot_id": int(existing["network_bot_id"]),
                    "existing_status": str(existing.get("status") or ""),
                    "existing_username": str(existing.get("username") or ""),
                    "removed": removed,
                    "hint": ("reactivate" if (same_owner and removed)
                             else ("change_token" if same_owner
                                   else "other_owner"))}

        # Step 3: explicit ownership/consent (spec §57)
        if not consent_confirmed:
            return {"ok": False, "reason": R_OWNERSHIP}

        # Step 4: per-user limit — enforced INSIDE the insert transaction
        # (spec §5: transaction-safe; concurrent attempts cannot exceed).
        max_bots = int(await self.db.get_setting_int(
            "max_registered_bots_per_user", 5))
        cap = await self.db.count_network_bots_for_owner(int(owner_user_id))
        if cap >= max_bots:
            return {"ok": False, "reason": R_LIMIT, "limit": max_bots,
                    "current": cap}

        # Step 5 (v34 spec §47): NO storage probe. The legacy
        # capabilities='storage:<mode>' value was ONLY ever consulted by
        # routing to decide payload eligibility; routing now uses the
        # authoritative Delivery-Group readiness predicate. New rows carry
        # the relay marker; legacy rows keep their historical value.
        caps = "delivery:relay"

        # Step 6: persist metadata + encrypted credential in ONE
        # transaction; the insert itself re-checks the per-user limit.
        encrypted = self.vault.encrypt(token)
        inserted = await self.db.insert_network_bot(
            owner_user_id=int(owner_user_id),
            telegram_bot_id=telegram_bot_id,
            username=username,
            display_name=display_name or (bot_info.get("first_name")
                                          or f"@{username}"),
            capabilities=caps,
            encrypted_token=encrypted,
            key_version=self.vault.key_version,
            max_bots_per_user=max_bots,
            management_mode=management_mode,
            credential_control=credential_control,
            created_via=created_via)
        if not inserted.get("inserted"):
            return {"ok": False, "reason": inserted.get("reason") or R_LIMIT,
                    "limit": max_bots}
        network_bot_id = int(inserted["network_bot_id"])
        logger.info("NETWORK_BOT_REGISTER_SUCCESS owner=%s "
                    "network_bot_id=%s telegram_bot_id=%s username=@%s "
                    "status=PENDING capabilities=%s",
                    owner_user_id, network_bot_id, telegram_bot_id,
                    username, caps or "-")
        return {"ok": True, "network_bot_id": network_bot_id,
                "telegram_bot_id": telegram_bot_id, "username": username,
                "status": STATUS_PENDING, "capabilities": caps,
                "management_mode": management_mode,
                "credential_control": credential_control}

    # ------------------------------------------------------------------
    # BOT-11 §5/§6/§7: honest recovery for a REMOVED same-owner bot
    # ------------------------------------------------------------------
    async def reactivate_removed_bot(self, owner_user_id: int, token: str, *,
                                     consent_confirmed: bool,
                                     existing_network_bot_id: Optional[int] = None,
                                     telegram_bot_id: Optional[int] = None
                                     ) -> Dict[str, Any]:
        """Reactivate a REMOVED bot owned by the SAME user (BOT-11 §5/§6/§7).

        Reactivation is NOT a new registration: the EXISTING row is
        revived — fresh token verified with Telegram (getMe) FIRST, then
        re-encrypted + stored on the existing row (network_bot_credentials
        INSERT OR REPLACE + status → PENDING + last_error_code cleared),
        NOTHING is awarded (no points — the reward was for the original
        activation), and the caller restarts the worker.

        Returns {"ok": True, "network_bot_id", "telegram_bot_id",
        "username", "reactivated": True} or {"ok": False, "reason": ...}
        with honest reasons: not_removed / wrong_owner / invalid_token /
        telegram_unreachable / ownership_not_confirmed /
        identity_mismatch / encryption_key_missing / bad_token_format /
        network_disabled. On ANY failure NOTHING is persisted.
        """
        # Same gates as a fresh registration (fail-closed, spec §2/§3).
        if not await self.db.get_setting_bool("network_enabled", True):
            return {"ok": False, "reason": R_DISABLED_PLATFORM}
        if not token_format_ok(token):
            return {"ok": False, "reason": R_BAD_FORMAT}
        if not getattr(self.vault, "can_encrypt", True):
            logger.warning(
                "NETWORK_BOT_REACTIVATE_FAILED owner=%s reason=%s "
                "(dedicated encryption key not configured)",
                owner_user_id, R_ENCRYPTION_KEY_MISSING)
            return {"ok": False, "reason": R_ENCRYPTION_KEY_MISSING,
                    "guidance": ENCRYPTION_KEY_MISSING_GUIDANCE}
        if not consent_confirmed:
            return {"ok": False, "reason": R_OWNERSHIP}

        # Step 1: verify the token FRESH with Telegram (getMe) — the
        # authority, exactly like a new registration (spec §2).
        val = await self._validate_token(token)
        if not val.get("ok"):
            reason = val.get("reason") or R_TRANSPORT
            logger.info("NETWORK_BOT_REACTIVATE_FAILED owner=%s reason=%s "
                        "(Telegram validation)", owner_user_id, reason)
            return {"ok": False, "reason": reason}
        bot_info = val["bot"]
        val_tg_id = int(bot_info["id"])
        username = (bot_info.get("username") or "").lstrip("@")
        if not username:
            return {"ok": False, "reason": R_INVALID_TOKEN}

        # Step 2: find the removed row — by explicit registry id, else by
        # the TOKEN's telegram id (the recovery-flow default).
        row: Optional[Dict[str, Any]] = None
        if existing_network_bot_id:
            try:
                row = await self.db.get_network_bot(int(existing_network_bot_id))
            except Exception:  # noqa: BLE001 — adapter without the reader
                row = None
        if row is None:
            try:
                row = await self.db.get_network_bot_by_telegram_id(
                    val_tg_id if telegram_bot_id is None
                    else int(telegram_bot_id))
            except Exception:  # noqa: BLE001
                row = None
        if row is None:
            logger.info("NETWORK_BOT_REACTIVATE_FAILED owner=%s "
                        "reason=not_removed telegram_bot_id=%s (no registry "
                        "row for this bot)", owner_user_id, val_tg_id)
            return {"ok": False, "reason": "not_removed"}
        nid = int(row["network_bot_id"])

        # Step 3: honest preconditions — REMOVED + same owner + identity.
        if not _row_is_removed(row):
            logger.info("NETWORK_BOT_REACTIVATE_FAILED owner=%s "
                        "reason=not_removed network_bot_id=%s "
                        "existing_status=%s (row is not removed — use the "
                        "normal registration/token-change path)",
                        owner_user_id, nid,
                        str(row.get("status") or "-"))
            return {"ok": False, "reason": "not_removed",
                    "existing_status": str(row.get("status") or ""),
                    "existing_bot_id": nid}
        if int(row["owner_user_id"]) != int(owner_user_id):
            logger.warning("NETWORK_BOT_REACTIVATE_FAILED owner=%s "
                           "reason=wrong_owner network_bot_id=%s (row "
                           "belongs to another owner)", owner_user_id, nid)
            return {"ok": False, "reason": "wrong_owner",
                    "existing_bot_id": nid}
        if int(row["telegram_bot_id"]) != val_tg_id:
            # The token belongs to a DIFFERENT bot than the target row —
            # never silently rebind a row to another Telegram identity.
            logger.warning("NETWORK_BOT_REACTIVATE_FAILED owner=%s "
                           "reason=identity_mismatch network_bot_id=%s "
                           "row_telegram_id=%s token_telegram_id=%s",
                           owner_user_id, nid,
                           int(row["telegram_bot_id"]), val_tg_id)
            return {"ok": False, "reason": "identity_mismatch",
                    "existing_bot_id": nid}

        # Step 4: re-encrypt + store the credential on the EXISTING row
        # (removal revoked/deleted the old credential → INSERT OR REPLACE)
        # + status PENDING + last_error_code cleared.
        encrypted = self.vault.encrypt(token)
        persisted = await self._reactivation_persist(
            nid, encrypted, self.vault.key_version)
        if not persisted:
            logger.error("NETWORK_BOT_REACTIVATE_FAILED owner=%s "
                         "reason=persist_failed network_bot_id=%s (the "
                         "credential/status update did not apply)",
                         owner_user_id, nid)
            return {"ok": False, "reason": "persist_failed",
                    "existing_bot_id": nid}
        logger.info("NETWORK_BOT_REACTIVATE_SUCCESS network_bot_id=%s "
                    "owner=%s telegram_bot_id=%s username=@%s status=PENDING "
                    "awarded=nothing (reactivation is not a new "
                    "registration)", nid, owner_user_id, val_tg_id,
                    username)
        return {"ok": True, "network_bot_id": nid,
                "telegram_bot_id": val_tg_id, "username": username,
                "reactivated": True, "status": STATUS_PENDING}

    async def _reactivation_persist(self, network_bot_id: int,
                                    encrypted_token: str,
                                    key_version: int) -> bool:
        """Persist the reactivation on the EXISTING row (no new insert).

        network_bot_credentials is keyed by network_bot_id and removal
        DELETED the row → INSERT OR REPLACE restores it atomically with
        the status transition (PENDING + last_error_code=NULL — the repo's
        update_network_bot_status COALESCEs last_error_code and cannot
        clear it). Implemented via the adapter's raw ``conn`` (the same
        pattern other raw-SQL sites use) WITHOUT touching
        repositories/network.py; falls back to repository methods for
        adapters without a conn (best-effort — honest False when neither
        path is available).
        """
        db = self.db
        conn = getattr(db, "conn", None)
        now = _now_iso()
        if conn is not None:
            try:
                async def _apply() -> None:
                    await conn.execute(
                        "INSERT OR REPLACE INTO network_bot_credentials "
                        "(network_bot_id, encrypted_token, key_version, "
                        "created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                        (int(network_bot_id), encrypted_token,
                         int(key_version), now, now))
                    await conn.execute(
                        "UPDATE network_bots SET status = ?, "
                        "last_error_code = NULL, updated_at = ? "
                        "WHERE id = ?",
                        (STATUS_PENDING, now, int(network_bot_id)))
                    await conn.commit()
                lock = getattr(db, "write_lock", None)
                if lock is not None:
                    async with lock:
                        await _apply()
                else:
                    await _apply()
                return True
            except Exception as exc:  # noqa: BLE001 — honest failure
                logger.error("NETWORK_BOT_REACTIVATE_PERSIST_FAILED "
                             "network_bot_id=%s error=%s",
                             int(network_bot_id), str(exc)[:160])
                return False
        # Best-effort fallback for adapters without a raw conn.
        try:
            await db.update_network_bot_status(int(network_bot_id),
                                               STATUS_PENDING)
            repl = getattr(db, "replace_network_bot_credential", None)
            if callable(repl):
                await repl(int(network_bot_id),
                           encrypted_token=encrypted_token,
                           key_version=int(key_version))
                return True
            return False
        except Exception as exc:  # noqa: BLE001
            logger.error("NETWORK_BOT_REACTIVATE_PERSIST_FAILED "
                         "network_bot_id=%s error=%s",
                         int(network_bot_id), str(exc)[:160])
            return False

    # ------------------------------------------------------------------
    # Lifecycle transitions
    # ------------------------------------------------------------------
    async def mark_active(self, network_bot_id: int) -> None:
        await self.db.update_network_bot_status(int(network_bot_id),
                                                STATUS_ACTIVE)
        logger.info("NETWORK_BOT_HEALTH network_bot_id=%s health=%s "
                    "status=%s", network_bot_id, HEALTHY, STATUS_ACTIVE)

    async def mark_token_invalid(self, network_bot_id: int,
                                 error_code: str = "TOKEN_INVALID") -> None:
        """Telegram reported the token invalid (spec §4): stop normal
        worker activity, exclude from routing. Requires explicit
        re-registration / credential replacement to recover."""
        await self.db.update_network_bot_status(
            int(network_bot_id), STATUS_TOKEN_INVALID,
            last_error_code=error_code)
        logger.warning("NETWORK_BOT_TOKEN_INVALID network_bot_id=%s",
                       network_bot_id)

    async def mark_health(self, network_bot_id: int, health: str, *,
                          error_code: Optional[str] = None) -> None:
        """Health bookkeeping (spec §14). Transient failures are recorded
        as TEMPORARILY_UNAVAILABLE and never flip status to
        TOKEN_INVALID/DISABLED by themselves."""
        await self.db.update_network_bot_health(
            int(network_bot_id), health, error_code=error_code)

    async def disable_bot(self, network_bot_id: int) -> None:
        await self.db.update_network_bot_status(int(network_bot_id),
                                                STATUS_DISABLED)
        logger.info("NETWORK_BOT_DISABLED network_bot_id=%s", network_bot_id)

    async def enable_bot(self, network_bot_id: int) -> None:
        """Re-enable a disabled bot (spec §58 'Re-enable where possible')."""
        await self.db.update_network_bot_status(int(network_bot_id),
                                                STATUS_PENDING)
        logger.info("NETWORK_BOT_ENABLED network_bot_id=%s "
                    "(re-enabled — worker restart required)", network_bot_id)

    async def remove_bot(self, network_bot_id: int, *,
                         stop_worker=None
                         ) -> Dict[str, Any]:
        """Remove a bot: stop routing/broadcast work, revoke the stored
        credential, PRESERVE history/analytics (spec §58).

        b10 §5: removal sets the DISTINCT terminal status REMOVED (never
        DISABLED — a removed bot is gone, not paused) with
        last_error_code=REMOVED, and is IDEMPOTENT-SAFE: a row that is
        already removed (REMOVED, or the legacy DISABLED+REMOVED shape)
        returns {"ok": True, "already": True} WITHOUT re-running the
        revocation, re-stopping a worker or re-logging NETWORK_BOT_REMOVED
        (the bot-10.log showed 4× NETWORK_BOT_REMOVED for the same bot).

        BOT-16 (removal lifecycle hardening) — on a FRESH removal every
        side-effect is now retired, each step individually best-effort
        (try/excepted, failures logged never raised — removal must never
        strand a half-removed bot because one cache write failed):
          * worker stop via the optional ``stop_worker`` async callable
            (the UI callers own the worker manager and pass it here, so
            the orchestrator logs MANAGED_BOT_WORKER_STOPPED/STOP_FAILED
            honestly and no future caller can forget to stop the worker);
          * credential revoked (existing, spec §58);
          * status → REMOVED + last_error_code=REMOVED (existing);
          * enabled=0 (repo ``disable_network_bot`` — every
            enabled-filtered surface, e.g. the website /network page,
            stops rendering the gone bot);
          * user_bot_memberships retired (repo ``retire_bot_memberships``
            → status='RETIRED' — a gone bot has no reachable users);
          * targeted global_payload_links deactivated (repo
            ``deactivate_global_links_for_bot`` — previously dead code,
            now wired; targeted clicks get the honest §13 message);
          * capability + Mini App state cleared (repo
            ``clear_network_bot_capability_state`` — can_manage_bots=NULL,
            mini_app_last_apply_status='CLEARED');
          * delivery-group retirement (existing BOT-13 §15 behavior);
          * removed_at written (repo ``set_network_bot_removed_at`` — the
            v37 schema column).
        Logs MANAGED_BOT_REMOVE_REQUEST at entry and ONE
        MANAGED_BOT_REMOVE_COMPLETE with structured per-step fields
        (network_bot_id, worker_stopped, links_deactivated,
        memberships_retired, enabled_cleared, credential_deleted,
        removed_at_set). The result dict carries the same fields.
        """
        nid = int(network_bot_id)
        logger.info("MANAGED_BOT_REMOVE_REQUEST network_bot_id=%s "
                    "worker_stop_hook=%s",
                    nid, "provided" if callable(stop_worker) else "absent")
        try:
            row = await self.db.get_network_bot(nid)
        except Exception:  # noqa: BLE001 — adapter without the reader
            row = None
        if _row_is_removed(row):
            return {"ok": True, "already": True}
        steps: Dict[str, Any] = {
            "worker_stopped": None,
            "links_deactivated": None,
            "memberships_retired": False,
            "enabled_cleared": False,
            "credential_deleted": False,
            "capability_cleared": False,
            "removed_at_set": False,
        }
        # --- 1. worker stop (caller-owned manager, orchestrated here) ----
        if callable(stop_worker):
            try:
                await stop_worker(nid)
                steps["worker_stopped"] = True
                logger.info("MANAGED_BOT_WORKER_STOPPED network_bot_id=%s",
                            nid)
            except Exception as exc:  # noqa: BLE001 — never block removal
                steps["worker_stopped"] = False
                logger.warning(
                    "MANAGED_BOT_WORKER_STOP_FAILED network_bot_id=%s "
                    "error=%s (removal continues — the REMOVED status "
                    "excludes the bot from routing regardless)",
                    nid, str(exc)[:160])
        # --- 2. core removal (spec §58 semantics, unchanged) --------------
        await self.db.revoke_network_bot_credential(nid)
        steps["credential_deleted"] = True
        await self.db.update_network_bot_status(
            nid, STATUS_REMOVED, last_error_code="REMOVED")
        # --- 3. enabled=0 --------------------------------------------------
        try:
            _disable = getattr(self.db, "disable_network_bot", None)
            if callable(_disable):
                await _disable(nid)
            else:
                # Raw-conn fallback for adapters without the repo method
                # (the same pattern _reactivation_persist uses).
                conn = getattr(self.db, "conn", None)
                if conn is not None:
                    await conn.execute(
                        "UPDATE network_bots SET enabled = 0, "
                        "updated_at = ? WHERE id = ?", (_now_iso(), nid))
                    await conn.commit()
            steps["enabled_cleared"] = True
        except Exception as exc:  # noqa: BLE001 — best-effort step
            logger.warning("MANAGED_BOT_REMOVE_STEP_FAILED "
                           "network_bot_id=%s step=enabled_clear error=%s",
                           nid, str(exc)[:160])
        # --- 4. retire user↔bot memberships --------------------------------
        try:
            _retire = getattr(self.db, "retire_bot_memberships", None)
            if callable(_retire):
                await _retire(nid)
                steps["memberships_retired"] = True
        except Exception as exc:  # noqa: BLE001 — best-effort step
            logger.warning("MANAGED_BOT_REMOVE_STEP_FAILED "
                           "network_bot_id=%s step=retire_memberships "
                           "error=%s", nid, str(exc)[:160])
        # --- 5. deactivate targeted global links (was dead code) ----------
        try:
            _deact = getattr(self.db, "deactivate_global_links_for_bot",
                             None)
            if callable(_deact):
                steps["links_deactivated"] = int(
                    await _deact(nid) or 0)
        except Exception as exc:  # noqa: BLE001 — best-effort step
            logger.warning("MANAGED_BOT_REMOVE_STEP_FAILED "
                           "network_bot_id=%s step=deactivate_links "
                           "error=%s", nid, str(exc)[:160])
        # --- 6. clear capability + Mini App state --------------------------
        try:
            _clear_cap = getattr(
                self.db, "clear_network_bot_capability_state", None)
            if callable(_clear_cap):
                await _clear_cap(nid)
                steps["capability_cleared"] = True
        except Exception as exc:  # noqa: BLE001 — best-effort step
            logger.warning("MANAGED_BOT_REMOVE_STEP_FAILED "
                           "network_bot_id=%s step=clear_capability_state "
                           "error=%s", nid, str(exc)[:160])
        # --- 7. removed_at (v37 schema column) ------------------------------
        try:
            _removed_at = getattr(self.db, "set_network_bot_removed_at",
                                  None)
            if callable(_removed_at):
                await _removed_at(nid)
                steps["removed_at_set"] = True
        except Exception as exc:  # noqa: BLE001 — best-effort step
            logger.warning("MANAGED_BOT_REMOVE_STEP_FAILED "
                           "network_bot_id=%s step=removed_at error=%s",
                           nid, str(exc)[:160])
        # b10 §2: a removed bot has no Delivery Group future — drop the
        # durable pending-setup row too (best-effort; older adapters
        # without the repo method simply keep theirs until the TTL).
        _clear_pending = getattr(self.db, "clear_pending_delivery_group",
                                  None)
        if callable(_clear_pending):
            try:
                await _clear_pending(nid)
            except Exception:  # noqa: BLE001 — never block removal
                pass
        # BOT-13 §15 (cached-state invalidation): the bot's VERIFIED
        # delivery group is retired as DELIVERY_UNAVAILABLE too — routing
        # already excludes the bot via its REMOVED status, but leaving a
        # DELIVERY_READY row for a gone bot is stale state (the exact
        # gap the remove-lifecycle spec calls out).
        _retire_group = getattr(self.db, "update_delivery_group_status",
                                None)
        if callable(_retire_group):
            try:
                await _retire_group(
                    nid, "DELIVERY_UNAVAILABLE",
                    last_error="network bot removed")
            except Exception:  # noqa: BLE001 — never block removal
                pass
        logger.info("NETWORK_BOT_REMOVED network_bot_id=%s "
                    "(credential revoked; delivery group retired; "
                    "analytics/history preserved)",
                    nid)
        logger.info(
            "MANAGED_BOT_REMOVE_COMPLETE network_bot_id=%s "
            "worker_stopped=%s links_deactivated=%s memberships_retired=%s "
            "enabled_cleared=%s credential_deleted=%s removed_at_set=%s",
            nid, steps["worker_stopped"], steps["links_deactivated"],
            steps["memberships_retired"], steps["enabled_cleared"],
            steps["credential_deleted"], steps["removed_at_set"])
        return {"ok": True, **steps}

    # ------------------------------------------------------------------
    # Decrypted token access (worker startup ONLY)
    # ------------------------------------------------------------------
    def decrypt_credential(self, encrypted_token: str) -> str:
        """Vault decrypt — used ONLY to construct the worker Application.
        Raises ValueError on tampering; never logs the plaintext."""
        return self.vault.decrypt(encrypted_token)

    # ------------------------------------------------------------------
    # User ↔ bot memberships (spec §15)
    # ------------------------------------------------------------------
    async def record_membership_start(self, network_bot_id: int,
                                      telegram_user_id: int) -> None:
        """Upsert the user↔bot relationship when a user starts a network
        bot — the reachability foundation for routing + broadcast."""
        await self.db.upsert_membership(int(network_bot_id),
                                        int(telegram_user_id))

    async def block_membership(self, network_bot_id: int,
                               telegram_user_id: int) -> None:
        """User blocked the bot → membership BLOCKED (unreachable)."""
        await self.db.block_membership(int(network_bot_id),
                                       int(telegram_user_id))


__all__ = [
    "BotRegistryService", "token_format_ok", "_row_is_removed",
    "STATUS_PENDING", "STATUS_ACTIVE", "STATUS_DEGRADED", "STATUS_DISABLED",
    "STATUS_TOKEN_INVALID", "STATUS_ERROR", "STATUS_REMOVED",
    "HEALTHY", "DEGRADED", "TEMPORARILY_UNAVAILABLE", "H_TOKEN_INVALID",
    "H_DISABLED", "UNKNOWN",
    "R_INVALID_TOKEN", "R_TRANSPORT", "R_BAD_FORMAT", "R_DUPLICATE_BOT",
    "R_OWNERSHIP", "R_LIMIT", "R_DISABLED_PLATFORM",
]
