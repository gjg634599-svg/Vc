"""NETWORK (N3): health-aware Global Payload router + opaque signed links.

STANDALONE MODULE — pure logic over injected adapters (same discipline as
app/core/*).

Spec sections implemented here:

§17 GLOBAL PAYLOAD LINK — network-level links pointing at the CENTRAL
    payload identity (never a bot-specific file_id). Opaque + signed.

§18 ROUTING — health-aware WEIGHTED RANDOM (never blind random):
    1. ACTIVE/healthy bots only
    2. eligible for the requested payload (storage access where needed)
    3. user has already interacted with the bot (reachability)
    4. not disabled
    5. acceptable health
    6. acceptable load (in-flight deliveries)
    7. routing weight applied
    8. randomized among equivalent candidates

§19 ROUTING FAILURE — exclude unhealthy, fall back; friendly temporary-
    unavailable when NO eligible bot exists; structured routing failure
    events recorded.

§16 REACHABILITY (HARD INVARIANT) — the router NEVER selects a bot the
    user cannot actually interact with: candidates are restricted to bots
    the user has an ACTIVE membership with. A bot the user has never
    started is only reachable via an explicit deep-link the USER taps
    (controlled start flow — the deep-link choice function below).

§20 NO BOT-TO-BOT REDIRECT LOOPS — every routing request carries a
    bounded fallback counter (`rk`); redirect depth is capped at
    MAX_REDIRECTS and the CURRENT bot always wins as the terminal choice
    (a payload request can never ping-pong A→B→A).

b10 §4 GLOBAL LINK TERMINAL CONTEXT — the MAIN bot
    (current_network_bot_id=None) is the terminal delivery context for a
    g-link: it owns the payload file references and ALWAYS delivers in
    its own context (never redirects, never refuses). A NETWORK bot that
    cannot serve redirects either to a strictly better reachable network
    bot or — when none exists — TERMINALLY to the MAIN bot via deep link
    ("deliver_via_main"); "unavailable" survives only when no main
    username is resolvable at all.

BOT-11 (spec §8/§12/§13/§16/§31) PER-LINK TARGETING — a Global Link
    minted with an explicit target routes DETERMINISTICALLY to that
    persisted target ('random' = ONE eligible bot selected and locked
    in at CREATION time; never re-rolled at click). Arrival at the
    target delivers in place (terminal); arrival elsewhere redirects to
    the target with the ORIGINAL signed argument (no rk bump — the
    target is stable, §12); a removed/disabled/token-invalid target is
    an honest target_unavailable (§13), and readiness is enforced only
    when the user actually ARRIVES at the target. Legacy untargeted
    links (target absent/0 with mode '') keep the exact pre-v35
    behavior. select_random_delivery_bot is the ONE centralized
    unbiased random pick (spec §8) shared by every mint site.

§22 FILE IDENTITY — this router NEVER touches file_ids. It only selects
    an execution context; delivery goes through the shared Delivery
    Engine / relay transport.

FILE DELIVERY v34 + V25 §1 CHANNEL-ONLY: a network bot is payload-
    eligible when it is registered, enabled, routable and holds a
    credential, AND the platform File Delivery Bot is operational (it
    performs every production file send: storage channel → user). The
    legacy Delivery-Group readiness requirement is REMOVED — no group
    membership, setup or verification gates routing (delivery groups are
    deprecated, V25 §1). The ``delivery_ready`` callable is injected by
    the wiring layer (app/network/file_delivery.is_delivery_ready) so
    the router stays a standalone module with no Telegram imports.

Link format (opaque + signed):
    g<code12>-<sig6>[_rkN]
      code12 : 12 chars of base62 (≥ 62^12 ≈ 3.2e21 possibilities)
      sig6   : first 6 hex chars of HMAC-SHA256(secret, code12) — signed
               identifiers; forgery is rejected before any DB lookup
      rkN    : optional routing-context fallback counter (bounded)

GAP-CLOSURE (spec §4 — Global Payload Link signing):
  * The signing secret is the DEDICATED persistent
    ``NETWORK_GLOBAL_LINK_SIGNING_KEY`` — never derived from BOT_TOKEN.
  * ``uses_dedicated_key`` tells the mint sites whether dedicated signing
    is live (spec §4: minting fails CLOSED with operator guidance when
    the dedicated key is missing — a rotating BOT_TOKEN must never be a
    long-lived security key).
  * ``legacy_secret`` keeps PRE-EXISTING links (BOT_TOKEN-signed) valid:
    ``parse`` accepts EITHER signature (timing-safe compare), so setting
    the dedicated key never breaks already-published links, and links
    survive BOT_TOKEN rotation when they carry the dedicated signature.
"""
from __future__ import annotations

import hashlib
import hmac
import logging
import random
import re
import secrets
from typing import Any, Dict, Iterable, List, Optional

logger = logging.getLogger("app.network.routing")

MAX_REDIRECTS = 2  # spec §20 — bounded fallback depth
_CODE_ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
_CODE_LEN = 12
_LINK_RE = re.compile(r"^g([A-Za-z0-9]{12})-([0-9a-f]{6})(?:_rk(\d{1,3}))?$")


class LinkSigningUnavailableError(Exception):
    """Global-link minting refused: no dedicated persistent signing key
    (spec §4 fail-closed). The message is the operator guidance."""

# Spec §4 operator guidance (minting fails closed without the dedicated
# persistent key; the key itself is NEVER logged).
LINK_SIGNING_KEY_MISSING_GUIDANCE = (
    "NETWORK_GLOBAL_LINK_SIGNING_KEY is not configured. Global Payload "
    "Links are cryptographically signed with this dedicated persistent "
    "secret so they survive BOT_TOKEN rotation. Generate one and set it "
    "in the environment, e.g.: "
    "python3 -c \"import secrets; print(secrets.token_urlsafe(48))\". "
    "Existing links keep working; creating NEW links is refused until "
    "the key is set.")

# Bot statuses eligible for routing (registry-owned vocabulary)
STATUS_ACTIVE = "ACTIVE"
STATUS_DEGRADED = "DEGRADED"
STATUS_DISABLED = "DISABLED"
STATUS_TOKEN_INVALID = "TOKEN_INVALID"
STATUS_ERROR = "ERROR"
STATUS_PENDING = "PENDING"
STATUS_REMOVED = "REMOVED"  # b10 §5: distinct terminal removal status
_ROUTABLE = (STATUS_ACTIVE, STATUS_DEGRADED)

# Membership statuses
MEMBER_ACTIVE = "ACTIVE"


# BOT-11 (spec §8): the ONE unbiased selector backing random-target
# Global Links (and the website Get File random delivery). SystemRandom
# = the OS CSPRNG — cryptographic-strength, cryptographically-unbiased
# choice (NOT random.choices, which is reproducible Mersenne Twister).
_SYSTEM_RANDOM = random.SystemRandom()


class GlobalPayloadLinks:
    """Opaque signed Global Payload Link codes.

    The DB (global_payload_links) is the authoritative mapping
    public_code → payload_id; this class only mints/validates the string
    form. Signing uses the DEDICATED persistent secret
    (NETWORK_GLOBAL_LINK_SIGNING_KEY) when provided; the legacy secret
    (BOT_TOKEN-derived) is kept for VERIFICATION ONLY so pre-existing
    links never break (spec §4).
    """

    def __init__(self, secret: str,
                 legacy_secret: Optional[str] = None,
                 *, dedicated: Optional[bool] = None) -> None:
        self._key = self._derive_key(secret)
        self._legacy_key = (self._derive_key(legacy_secret)
                            if legacy_secret else None)
        if dedicated is None:
            # An EXPLICIT secret is a dedicated key by intent (single-arg
            # constructions, tests, dual-key wirings). The ONLY non-dedicated
            # construction is the explicit dedicated=False — the production
            # no-key path where the secret is the rotating BOT_TOKEN.
            dedicated = True
        self.uses_dedicated_key = bool(dedicated)

    @staticmethod
    def _derive_key(secret: str) -> bytes:
        return hashlib.sha256(
            ("gplink:" + (secret or "gplink-default")).encode("utf-8")
        ).digest()

    def mint_code(self) -> str:
        """A fresh opaque public_code (code + signature).

        GAP-CLOSURE spec §4: raises ``LinkSigningUnavailableError`` when
        only the legacy BOT_TOKEN-derived secret is available — minting
        never silently derives a long-lived security key from a rotating
        bot token. Existing links still VERIFY through ``parse``."""
        if not self.uses_dedicated_key:
            logger.warning(
                "GLOBAL_LINK_MINT_REFUSED reason=signing_key_missing "
                "(dedicated NETWORK_GLOBAL_LINK_SIGNING_KEY required; "
                "existing links keep verifying)")
            raise LinkSigningUnavailableError(LINK_SIGNING_KEY_MISSING_GUIDANCE)
        code = "".join(secrets.choice(_CODE_ALPHABET) for _ in range(_CODE_LEN))
        return code + "-" + self.sign(code)

    def sign(self, code: str) -> str:
        return hmac.new(self._key, code.encode("ascii"),
                        hashlib.sha256).hexdigest()[:6]

    def _legacy_sign(self, code: str) -> Optional[str]:
        if self._legacy_key is None:
            return None
        return hmac.new(self._legacy_key, code.encode("ascii"),
                        hashlib.sha256).hexdigest()[:6]

    def parse(self, arg: str) -> Optional[Dict[str, Any]]:
        """Parse a /start deep-link argument into
        {"code": str, "fallback_count": int} — None when malformed or
        signature-invalid (signed identifiers; forged codes rejected).

        GAP-CLOSURE spec §4: accepts the DEDICATED signature AND (when a
        legacy secret was wired) the legacy BOT_TOKEN-derived signature —
        both compared timing-safely — so published links survive the key
        migration and BOT_TOKEN rotation."""
        if not arg:
            return None
        m = _LINK_RE.match(arg)
        if not m:
            return None
        code, sig, rk = m.group(1), m.group(2), m.group(3)
        ok = hmac.compare_digest(sig, self.sign(code))
        if not ok:
            legacy_sig = self._legacy_sign(code)
            if legacy_sig is not None:
                ok = hmac.compare_digest(sig, legacy_sig)
        if not ok:
            return None
        return {"code": code + "-" + sig,
                "fallback_count": int(rk) if rk else 0}

    def redirect_arg(self, code: str, fallback_count: int) -> str:
        """The /start argument that carries the routing context forward
        (bounded — a redirect counter above MAX_REDIRECTS is clamped)."""
        m = re.match(r"^([A-Za-z0-9]{12})-([0-9a-f]{6})$", code or "")
        if not m:
            return "g" + code
        rk = min(int(fallback_count) + 1, MAX_REDIRECTS + 1)
        return f"g{m.group(1)}-{m.group(2)}_rk{rk}"


# ----------------------------------------------------------------------
# BOT-11 (spec §8/§12/§16): centralized random selection + targeted mint
# ----------------------------------------------------------------------
async def _delivery_ready_via(db_adapter, bot_row: Dict[str, Any],
                              delivery_ready=None) -> bool:
    """The SAME delivery-readiness resolution NetworkRouter uses (spec
    §46/§47): the authoritative injected predicate when wired, else the
    fail-closed Delivery-Group DELIVERY_READY DB check. Shared by
    NetworkRouter._bot_delivery_ready and select_random_delivery_bot so
    there is exactly ONE definition."""
    if delivery_ready is not None:
        return bool(await delivery_ready(bot_row))
    group = await db_adapter.get_delivery_group_for_bot(
        int(bot_row["network_bot_id"]))
    return bool(group and str(group.get("status")) == "DELIVERY_READY")


async def select_random_delivery_bot(db, *, bot_rows=None, exclude_ids=None,
                                     delivery_ready=None
                                     ) -> Dict[str, Any]:
    """BOT-11 spec §8 — the ONE centralized unbiased random selection.

    Eligibility is the SAME predicate select_bot applies (routable
    ACTIVE/DEGRADED + enabled via NetworkRouter._bot_routable, plus
    delivery readiness via _delivery_ready_via / the injected
    predicate). When ``bot_rows`` is None the candidates load via
    db.get_delivery_eligible_bots() (the v35 DB-side pre-filter),
    falling back to db.list_network_bots() filtered by the same
    predicate (adapters without the v35 method / defensive parity).
    ``exclude_ids`` removes specific bots (never selected).

    Selection is random.SystemRandom().choice() — the OS CSPRNG, ONE
    uniform draw among the survivors (NOT weighted: spec §8 random is
    uniform by design; weighted routing stays in select_bot for the
    untargeted path).

    Returns {"selected": bot_row|None, "reason": "selected"|
    "no_eligible_bot", "eligible": int}. Logs NOTHING here — callers
    log (the router's contract).
    """
    rows = bot_rows
    if rows is None:
        rows = None
        try:
            rows = await db.get_delivery_eligible_bots()
        except Exception:  # noqa: BLE001 — pre-v35 adapter, fall back
            rows = None
        if not rows:
            rows = await db.list_network_bots()
    exclude = set(int(x) for x in (exclude_ids or []))
    survivors: List[Dict[str, Any]] = []
    for b in rows or []:
        try:
            if not NetworkRouter._bot_routable(b):
                continue
            if int(b["network_bot_id"]) in exclude:
                continue
            if not await _delivery_ready_via(db, b, delivery_ready):
                continue
            survivors.append(b)
        except Exception:  # noqa: BLE001 — a malformed row never breaks the pick
            continue
    if not survivors:
        # B24 (Phase 1/8): per-bot eligibility trace when NOTHING survives
        # so operators can see WHY count=0 without querying the DB (the
        # bot-27.log "count=0 reason=no_eligible_bot" was truthful but
        # opaque — this line names each candidate's routable/ready/
        # group_status so the operator knows which bot to fix).
        try:
            for b in rows or []:
                bid = int(b.get("network_bot_id") or 0)
                routable = NetworkRouter._bot_routable(b)
                gstat = "-"
                try:
                    g = await db.get_delivery_group_for_bot(bid)
                    gstat = (str(g.get("status") or "-")
                             if g else "no_group_row")
                except Exception:  # noqa: BLE001
                    gstat = "lookup_error"
                ready = await _delivery_ready_via(db, b, delivery_ready)
                logger.info(
                    "DELIVERY_BOT_ELIGIBILITY network_bot_id=%s routable=%s "
                    "delivery_ready=%s group_status=%s enabled=%s "
                    "bot_status=%s",
                    bid, routable, ready, gstat,
                    int(b.get("enabled") or 0),
                    str(b.get("status") or "-"))
        except Exception:  # noqa: BLE001 — the trace is additive
            pass
        return {"selected": None, "reason": "no_eligible_bot",
                "eligible": 0}
    picked = _SYSTEM_RANDOM.choice(survivors)
    return {"selected": picked, "reason": "selected",
            "eligible": len(survivors)}


async def mint_targeted_link(db, links: "GlobalPayloadLinks",
                             payload_id: int, *,
                             target_network_bot_id: int,
                             target_mode: str) -> str:
    """BOT-11 spec §12/§16 — mint + persist a Global Link WITH its
    delivery target. Returns the full code string ("code12-sig6").

    Fails CLOSED exactly like the untargeted mint: mint_code() raises
    LinkSigningUnavailableError when the dedicated persistent signing
    key is missing — the exception PROPAGATES to the caller (spec §4:
    never silently sign with a rotating BOT_TOKEN-derived key). The
    'random' mode is resolved by the CALLER (one pick at creation,
    persisted here — never re-rolled at click time)."""
    code = links.mint_code()  # LinkSigningUnavailableError propagates
    await db.create_global_payload_link(
        int(payload_id), code,
        target_network_bot_id=int(target_network_bot_id or 0),
        target_mode=str(target_mode or ""))
    return code


class NetworkRouter:
    """Health-aware weighted-random bot selection.

    Adapters (created in bot.py):
        await db.list_network_bots() -> List[dict]  (registry rows with
            status/enabled/routing_weight/capabilities/telegram_bot_id/...)
        await db.get_memberships_for_user(telegram_user_id) -> List[dict]
            (rows with network_bot_id + status)
        await db.get_active_network_bot_ids() -> List[int]
        await db.log_routing_event(event_type, request_id, payload_id,
                                   selected_bot_id, fallback_count, reason)
        await db.bump_global_link_click(public_code)
    """

    def __init__(self, db_adapter,
                 delivery_ready=None) -> None:
        self.db = db_adapter
        # v34 spec §46: THE authoritative delivery-ready predicate
        # (async (bot_row, group_row=None) -> bool). Injected by the wiring
        # layer so every selection path shares ONE definition.
        self.delivery_ready = delivery_ready

    # ------------------------------------------------------------------
    # Candidate selection
    # ------------------------------------------------------------------
    @staticmethod
    def _bot_routable(bot_row: Dict[str, Any]) -> bool:
        return (str(bot_row.get("status")) in _ROUTABLE
                and int(bot_row.get("enabled") or 0) == 1)

    async def _bot_delivery_ready(self, bot_row: Dict[str, Any]) -> bool:
        """Payload eligibility (spec §46/§47 — v34): Delivery Group
        readiness via the authoritative injected predicate. Fallback when
        no predicate is wired (tests/legacy): no bot is payload-eligible
        unless a verified delivery group exists — this is the honest
        fail-closed default, never the legacy storage capability.
        BOT-11: the resolution lives in the shared module helper
        _delivery_ready_via so select_random_delivery_bot uses the SAME
        definition (behavior unchanged)."""
        return await _delivery_ready_via(self.db, bot_row, self.delivery_ready)

    @staticmethod
    def _weighted_pick(candidates: List[Dict[str, Any]]) -> Optional[Dict]:
        """Weighted random among candidates (routing_weight >= 1;
        equal weights → uniform random — spec §18 step 7/8)."""
        if not candidates:
            return None
        weights = [max(1, int(c.get("routing_weight") or 1))
                   for c in candidates]
        return random.choices(candidates, weights=weights, k=1)[0]

    async def select_bot(self, telegram_user_id: int, *,
                         payload_id: Optional[int] = None,
                         current_network_bot_id: Optional[int] = None,
                         exclude_ids: Optional[Iterable[int]] = None,
                         require_delivery_ready: bool = True,
                         membership_rows: Optional[List[Dict[str, Any]]] = None,
                         bot_rows: Optional[List[Dict[str, Any]]] = None,
                         ) -> Dict[str, Any]:
        """Select ONE eligible bot for a payload request.

        Decision order (spec §18 + v34 §46):
          1. routable bots (ACTIVE/DEGRADED + enabled) — health-aware
          2. payload eligibility: DELIVERY-READY (verified private
             Delivery Group + operational File Delivery Bot) — the
             storage:full legacy assumption is GONE (spec §47)
          3. reachability: bots with an ACTIVE membership for this user
             (the CURRENT bot always counts — the user is interacting
             with it right now)
          4. weighted random among the survivors

        Returns {"selected": bot_row|None, "reason": str,
                 "candidates": int,
                 "routable": int, "delivery_ready": int,
                 "reachable": int} — the three counts (b10 §4
                 diagnostics) are the funnel BEFORE the reachability
                 intersection, so a "no eligible bot" decision can be
                 root-caused from the log alone (routable=0 → all bots
                 unhealthy/disabled; ready=0 → no verified Delivery
                 Group; reachable=0 → the user never started any bot).
        The caller renders the friendly temporary-unavailable response
        when selected is None (spec §19).
        """
        bots = bot_rows if bot_rows is not None \
            else await self.db.list_network_bots()
        exclude = set(int(x) for x in (exclude_ids or []))
        memberships = membership_rows if membership_rows is not None \
            else await self.db.get_memberships_for_user(int(telegram_user_id))
        reachable_ids = {int(m["network_bot_id"]) for m in memberships
                         if str(m.get("status")) == MEMBER_ACTIVE}
        if current_network_bot_id is not None:
            reachable_ids.add(int(current_network_bot_id))

        candidates = []
        n_routable = 0
        n_ready = 0
        for b in bots:
            if not self._bot_routable(b):
                continue
            n_routable += 1
            if int(b["network_bot_id"]) in exclude:
                continue
            if require_delivery_ready and not await self._bot_delivery_ready(b):
                continue
            n_ready += 1
            if int(b["network_bot_id"]) not in reachable_ids:
                continue
            candidates.append(b)
        # b10 §4 diagnostics: the selection funnel counts (exclude_ids is
        # a routing-internal knob — routable/ready describe the fleet's
        # health, reachable the user's memberships).
        counts = {"routable": n_routable, "delivery_ready": n_ready,
                  "reachable": len(reachable_ids)}

        if not candidates:
            reason = ("no_routable_bots" if n_routable == 0 else
                      "no_reachable_payload_eligible_bot")
            await self.db.log_routing_event(
                "GLOBAL_PAYLOAD_ROUTE_FAILED", None, payload_id, None, 0,
                reason)
            return {"selected": None, "reason": reason, "candidates": 0,
                    **counts}

        selected = self._weighted_pick(candidates)
        await self.db.log_routing_event(
            "GLOBAL_PAYLOAD_ROUTE", None, payload_id,
            int(selected["network_bot_id"]), 0,
            f"candidates={len(candidates)} weighted_random")
        return {"selected": selected, "reason": "selected",
                "candidates": len(candidates), **counts}

    async def select_random_delivery_bot(self, *, bot_rows=None,
                                         exclude_ids=None
                                         ) -> Dict[str, Any]:
        """BOT-11 spec §8 — the ONE centralized random selection through
        THIS router's wiring (the injected delivery_ready predicate is
        honored automatically). Thin delegate to the module function."""
        return await select_random_delivery_bot(
            self.db, bot_rows=bot_rows, exclude_ids=exclude_ids,
            delivery_ready=self.delivery_ready)

    # ------------------------------------------------------------------
    # Deep-link username choice (for PUBLISHED global links)
    # ------------------------------------------------------------------
    async def pick_link_bot_username(self, *,
                                     bot_rows: Optional[List[Dict[str, Any]]] = None
                                     ) -> Optional[str]:
        """Choose the bot username for a NEWLY rendered Global Payload Link
        (spec §17: the link must not permanently depend on one bot).

        Health-aware weighted random among DELIVERY-READY bots (spec §46
        — one predicate for every routing path) — membership-independent
        (a published link is tapped by NEW users; the chosen bot's /start
        deep-link IS the controlled start flow that creates the
        membership).
        """
        bots = bot_rows if bot_rows is not None \
            else await self.db.list_network_bots()
        eligible = [b for b in bots
                    if self._bot_routable(b)
                    and await self._bot_delivery_ready(b)]
        if not eligible:
            return None
        picked = self._weighted_pick(eligible)
        return (picked.get("username") or "").lstrip("@") or None

    # ------------------------------------------------------------------
    # Routing decision for an arriving g-link request
    # ------------------------------------------------------------------
    async def resolve_request(self, telegram_user_id: int,
                              public_code: str, *,
                              current_network_bot_id: Optional[int],
                              current_bot_username: str,
                              fallback_count: int,
                              membership_rows: Optional[List[Dict[str, Any]]] = None,
                              bot_rows: Optional[List[Dict[str, Any]]] = None,
                              main_bot_username: Optional[str] = None,
                              link_target_network_bot_id: Optional[int] = None,
                              raw_arg: Optional[str] = None,
                              ) -> Dict[str, Any]:
        """Decide what to do with a g<code> deep-link arrival.

        BOT-11 (spec §12/§13/§16/§31) — ``link_target_network_bot_id``:
          None (default) = LEGACY untargeted link → every outcome below,
          byte-identical to the pre-v35 behavior (zero regression).
          0 = explicit MAIN-bot target (target_mode 'main'): main arrival
          → deliver_current; a network-bot arrival → deliver_via_main.
          >0 = the PERSISTED network-bot target: the decision is
          DETERMINISTIC (never a re-roll) — a target that is
          REMOVED/DISABLED/TOKEN_INVALID/missing is an honest
          target_unavailable (§13); arrival AT the target is terminal
          (deliver_current — readiness enforced exactly there); arrival
          anywhere else redirects to the target via deliver_via_target
          with the ORIGINAL signed argument (``raw_arg`` when the caller
          passes it, else "g"+public_code — NO rk bump: the target is
          stable, §12, and redirecting to it is not a fallback hop).
          Health is NOT consulted for the redirect decision; the target's
          delivery readiness is checked only when the user ARRIVES at it.

        Outcomes:
          {"action": "deliver_current"} — the current bot serves the
              payload itself (terminal; NEVER redirects — no loop can
              form). Chosen when the current bot is routable and
              payload-eligible, when the fallback budget is exhausted,
              or — b10 §4 — whenever the arrival is at the MAIN bot:
              the MAIN bot owns the payload file references and is the
              TERMINAL delivery context by construction (the live
              bot-10.log showed the same payload delivered fine via
              plain /start on the main bot while the g-link answered
              "unavailable" because no NETWORK bot was delivery-ready).
          {"action": "deliver_via", "bot": row, "deep_arg": "g..._rkN"} —
              the current bot cannot serve (not routable / no storage
              access) and a strictly BETTER reachable candidate exists;
              the caller shows ONE controlled deep-link button. The
              incremented rk counter bounds the chain at MAX_REDIRECTS.
          {"action": "deliver_via_target", "bot": row,
           "deep_arg": str, "target_network_bot_id": int} — BOT-11 §12:
              targeted link arriving anywhere EXCEPT its persisted
              target; ONE deterministic deep-link button to the target
              (the caller logs GLOBAL_LINK_TARGET_RESOLVED).
          {"action": "target_unavailable", "reason":
           "target_removed"|"target_inactive"|"target_not_found"|
           "target_not_ready"} — BOT-11 §13: the persisted target is
              gone (REMOVED), paused/invalid (DISABLED/TOKEN_INVALID),
              unknown (no such row), or — ONLY on arrival AT the target —
              not routable/not delivery-ready. The caller renders the
              honest "no longer available" message and logs
              GLOBAL_LINK_TARGET_REMOVED/_INACTIVE/_NOT_READY.
          {"action": "deliver_via_main", "main_username": str,
           "deep_arg": "g..._rkN"} — b10 §4: the arrival is at a
              NETWORK bot that cannot serve and NO other eligible bot
              exists; the user gets ONE terminal deep-link button to
              the MAIN bot (which always delivers). Only returned when
              a main username is resolvable.
          {"action": "unavailable", "reason": str} — the ONLY remaining
              dead-end: a network-bot arrival with no eligible network
              bot AND no main fallback (reason
              "no_eligible_bot_no_main_fallback"); the caller shows the
              friendly temporary-unavailable message (spec §19).

        b10 §4 diagnostics: every outcome carries the select_bot funnel
        counts (routable / delivery_ready / reachable) so the caller can
        log GLOBAL_LINK_ROUTE_DECISION with them.
        """
        sel = await self.select_bot(
            int(telegram_user_id), payload_id=None,
            current_network_bot_id=current_network_bot_id,
            membership_rows=membership_rows, bot_rows=bot_rows)
        counts = {k: int(sel.get(k) or 0) for k in
                  ("routable", "delivery_ready", "reachable")}
        main_uname = (str(main_bot_username).lstrip("@")
                      if main_bot_username else "")

        # =================================================================
        # BOT-11 (spec §12/§13/§16): PER-LINK TARGETED resolution — runs
        # BEFORE (and completely independently of) the legacy untargeted
        # logic below. The persisted target is the admin's choice: it is
        # NEVER re-rolled and health is NOT consulted for the redirect
        # (readiness is enforced on ARRIVAL at the target).
        # =================================================================
        if link_target_network_bot_id is not None:
            target = int(link_target_network_bot_id)
            if target > 0:
                target_row = self._find_bot(bot_rows, target) \
                    if bot_rows is not None else \
                    await self._db_find_bot(target)
                if target_row is None:
                    return {"action": "target_unavailable",
                            "reason": "target_not_found", **counts}
                t_status = str(target_row.get("status") or "")
                if t_status == STATUS_REMOVED:
                    return {"action": "target_unavailable",
                            "reason": "target_removed", **counts}
                if t_status in (STATUS_DISABLED, STATUS_TOKEN_INVALID):
                    return {"action": "target_unavailable",
                            "reason": "target_inactive", **counts}
                # §12 stable target: the /start argument carried by the
                # redirect is the ORIGINAL signed form the caller
                # received (raw_arg — case preserved, no rk bump); the
                # reassembled "g"+code is the fallback when the caller
                # did not pass the raw form.
                stable_arg = raw_arg if (isinstance(raw_arg, str)
                                         and raw_arg) else ("g" + public_code)
                if current_network_bot_id is not None \
                        and int(current_network_bot_id) == target:
                    # Arrival AT the persisted target (§12 terminal —
                    # deliver_current only when the target can actually
                    # serve; honest target_unavailable otherwise). This
                    # is the ONLY place targeted readiness is enforced.
                    if self._bot_routable(target_row) \
                            and await self._bot_delivery_ready(target_row):
                        return {"action": "deliver_current",
                                "target_network_bot_id": target, **counts}
                    return {"action": "target_unavailable",
                            "reason": "target_not_ready", **counts}
                # Arrival at the MAIN bot or a DIFFERENT network bot →
                # the deterministic redirect to the PERSISTED target
                # (never a re-roll, never a health-based substitution).
                return {"action": "deliver_via_target", "bot": target_row,
                        "deep_arg": stable_arg,
                        "target_network_bot_id": target, **counts}
            # target == 0: the EXPLICIT MAIN-bot target (target_mode
            # 'main'). Main is the terminal delivery context by
            # construction — same shape as the b10 §4 main logic, but a
            # NETWORK-bot arrival redirects straight to main (the link
            # was minted for main; no health consultation).
            if current_network_bot_id is None:
                return {"action": "deliver_current", **counts}
            if main_uname:
                stable_arg = raw_arg if (isinstance(raw_arg, str)
                                         and raw_arg) else ("g" + public_code)
                return {"action": "deliver_via_main",
                        "main_username": main_uname,
                        "deep_arg": stable_arg, **counts}
            return {"action": "unavailable",
                    "reason": "no_eligible_bot_no_main_fallback", **counts}

        # =================================================================
        # LEGACY untargeted path — byte-identical to the pre-v35 behavior
        # (link_target_network_bot_id is None).
        # =================================================================

        # b10 §4 (THE bot-10.log §4 root cause): a MAIN-bot arrival
        # (current_network_bot_id=None) ALWAYS delivers in the current
        # context — first arrival AND after the fallback budget. The
        # main bot owns the payload file references; redirecting a user
        # who is ALREADY talking to the main bot to a network bot (or
        # worse, refusing delivery because none is delivery-ready) is
        # the bug. Terminal and loop-free by construction.
        if current_network_bot_id is None:
            return {"action": "deliver_current", **counts}

        # Fallback budget exhausted → the CURRENT network bot is the
        # terminal choice whenever it can serve at all (loop prevention
        # §20); when it cannot, the NEW main-bot terminal fallback
        # (b10 §4) beats an "unavailable" dead-end.
        if fallback_count >= MAX_REDIRECTS:
            current = self._find_bot(bot_rows, current_network_bot_id) \
                if bot_rows is not None else \
                await self._db_find_bot(current_network_bot_id)
            if current is not None and self._bot_routable(current):
                return {"action": "deliver_current", **counts}
            if main_uname:
                arg = GlobalPayloadLinks("").redirect_arg(
                    public_code, fallback_count)
                return {"action": "deliver_via_main",
                        "main_username": main_uname, "deep_arg": arg,
                        **counts}
            if sel["selected"] is not None \
                    and int(sel["selected"]["network_bot_id"]) != int(
                        current_network_bot_id or 0):
                return {"action": "unavailable",
                        "reason": "fallback_budget_exhausted", **counts}
            return {"action": "unavailable",
                    "reason": sel.get("reason") or "no_eligible_bot",
                    **counts}

        selected = sel["selected"]
        if selected is None:
            # Network-bot arrival, no eligible NETWORK bot at all → the
            # b10 §4 main-bot terminal fallback (never a dead-end when a
            # main username is resolvable).
            if main_uname:
                arg = GlobalPayloadLinks("").redirect_arg(
                    public_code, fallback_count)
                return {"action": "deliver_via_main",
                        "main_username": main_uname, "deep_arg": arg,
                        **counts}
            return {"action": "unavailable",
                    "reason": "no_eligible_bot_no_main_fallback", **counts}

        if int(selected["network_bot_id"]) == int(current_network_bot_id):
            return {"action": "deliver_current", **counts}

        # A different bot was selected. Redirect ONLY when the current bot
        # genuinely cannot serve (unroutable or payload-ineligible);
        # otherwise prefer delivering in the CURRENT context (the user is
        # here — no dead-ends, no ping-pong).
        current = self._find_bot(bot_rows, current_network_bot_id) \
            if bot_rows is not None else \
            await self._db_find_bot(current_network_bot_id)
        current_can_serve = (current is not None and self._bot_routable(current)
                             and await self._bot_delivery_ready(current))
        if current_can_serve:
            return {"action": "deliver_current", **counts}
        arg = GlobalPayloadLinks("").redirect_arg(public_code, fallback_count)
        return {"action": "deliver_via", "bot": selected, "deep_arg": arg,
                **counts}

    def _find_bot(self, bot_rows: Optional[List[Dict[str, Any]]],
                  network_bot_id: Optional[int]) -> Optional[Dict[str, Any]]:
        if bot_rows is None or network_bot_id is None:
            return None
        for b in bot_rows:
            if int(b["network_bot_id"]) == int(network_bot_id):
                return b
        return None

    async def _db_find_bot(self, network_bot_id: Optional[int]
                           ) -> Optional[Dict[str, Any]]:
        if network_bot_id is None:
            return None
        bots = await self.db.list_network_bots()
        return self._find_bot(bots, network_bot_id)


__all__ = [
    "NetworkRouter", "GlobalPayloadLinks", "MAX_REDIRECTS",
    "STATUS_ACTIVE", "STATUS_DEGRADED", "STATUS_DISABLED",
    "STATUS_TOKEN_INVALID", "STATUS_ERROR", "STATUS_PENDING",
    "STATUS_REMOVED",
    "MEMBER_ACTIVE",
    # BOT-11 (spec §8/§12/§16): centralized random selection + targeted mint
    "select_random_delivery_bot", "mint_targeted_link",
]
