"""FILE DELIVERY v34 — the CONTROL BOT application (spec §21).

A DEDICATED Telegram bot (CONTROL_BOT_TOKEN) that is the administrative
control plane. It runs IN-PROCESS as a second PTB Application (the same
discipline as network workers — NO separate microservice, spec §21/§79),
sharing the database, the admin authorization (env ADMIN_IDS + the DB
admins table — spec §22), and the Control UI handlers (one implementation,
also reachable from the main bot's admin panel).

It must NOT become the normal payload delivery bot: it registers NO
payload/user-facing handlers — only /start, /help, the ctl: callback
dispatch and the admin text inputs.
"""
from __future__ import annotations

import logging
from typing import Optional

from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CallbackQueryHandler,
    CommandHandler,
    MessageHandler,
    filters,
)

logger = logging.getLogger("payload-bot")


async def control_start_command(update: Update, context) -> None:
    """Control Bot /start — the admin control plane entry (spec §23)."""
    from app.presentation.telegram import runtime as _rt
    user = update.effective_user
    if not user:
        return
    if not await _rt.is_admin(int(user.id)):
        await _rt.safe_send_text(
            context.bot, update.effective_chat.id,
            "🛡 This is the platform Control Bot. Platform admins only.")
        logger.warning("CONTROL_BOT_UNAUTHORIZED_ACCESS user_id=%s",
                       int(user.id))
        return
    await _rt.render_control_panel(update, context)


async def control_help_command(update: Update, context) -> None:
    from app.presentation.telegram import runtime as _rt
    user = update.effective_user
    if not user or not await _rt.is_admin(int(user.id)):
        await _rt.safe_send_text(
            context.bot, update.effective_chat.id,
            "🛡 Platform admins only.")
        return
    await _rt.safe_send_text(
        context.bot, update.effective_chat.id,
        "🛡 Control Bot — platform administration.\n\n"
        "/start — the PLATFORM CONTROL panel\n\n"
        "Manages: File Delivery Bot, Managed Network Bots, health, "
        "credentials, reconciliation, settings.")


async def control_callback_guard(update: Update, context) -> None:
    """ctl: dispatch on the control bot — the SAME handlers as the main
    bot's admin area (server-side admin check inside)."""
    from app.presentation.telegram import runtime as _rt
    q = update.callback_query
    if not q or not q.data:
        return
    data = str(q.data)
    if not data.startswith("ctl:"):
        await _rt.safe_answer_callback(q, "Unknown control action.",
                                       show_alert=True)
        return
    # Audit every control-bot admin access (spec §36).
    logger.info("CONTROL_BOT_CALLBACK callback_data=%s user_id=%s",
                data[:60], q.from_user.id if q.from_user else 0)
    await _rt.handle_control_callback(update, context, data[len("ctl:")])


async def control_text_guard(update: Update, context) -> None:
    """Text inputs on the control bot: FDB token add/change, managed bot
    rotation/create (admin-only states, checked inside the handlers)."""
    from app.presentation.telegram import runtime as _rt
    user = update.effective_user
    msg = update.effective_message
    if not user or not msg or not msg.text:
        return
    if not await _rt.is_admin(int(user.id)):
        await _rt.safe_send_text(
            context.bot, update.effective_chat.id,
            "🛡 Platform admins only.")
        return
    consumed = await _rt.handle_control_owner_text(
        update, context, user, msg.text)
    if not consumed:
        consumed = await _rt.handle_control_text(
            update, context, user, msg.text)
    if not consumed:
        await _rt.safe_send_text(
            context.bot, update.effective_chat.id,
            "🛡 Send /start to open the platform control panel.")


async def build_control_bot_application(token: str, ns):
    """Build the Control Bot PTB Application (in-process, like workers)."""
    _builder = ApplicationBuilder().token(token)
    try:
        from app.bootstrap.application import ptb_local_api_endpoints
        _endpoints = ptb_local_api_endpoints()
    except Exception:  # noqa: BLE001
        _endpoints = None
    if _endpoints is not None:
        _builder = _builder.base_url(_endpoints["base_url"])
        _builder = _builder.base_file_url(_endpoints["base_file_url"])
    app = (
        _builder
        .concurrent_updates(True)
        .build()
    )
    app.bot_data["control_bot"] = True
    app.add_handler(CommandHandler("start", control_start_command))
    app.add_handler(CommandHandler("help", control_help_command))
    app.add_handler(CallbackQueryHandler(control_callback_guard))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,
                                   control_text_guard))
    return app


class ControlBotState:
    """The control bot's live application handle (started/stopped in the
    presentation post_init/post_shutdown — fail-isolated like workers)."""

    def __init__(self) -> None:
        self.application = None
        self.username: str = ""
        self.telegram_bot_id: Optional[int] = None

    @property
    def running(self) -> bool:
        return self.application is not None


async def start_control_bot(ns) -> Optional[ControlBotState]:
    """Start the dedicated Control Bot when CONTROL_BOT_TOKEN is set.

    Isolated: a failure here NEVER blocks the main bot's startup (the
    control surface remains available inside the main bot's admin area).
    """
    state = getattr(ns, "_control_bot_state", None)
    if state and state.running:
        return state
    from app.bootstrap.config import EnvDefaults as _EnvDefaults
    token = (_EnvDefaults.from_env().control_bot_token or "").strip()
    if not token:
        logger.info(
            "CONTROL_BOT_NOT_CONFIGURED (CONTROL_BOT_TOKEN not set — the "
            "control panel is available inside the main bot's admin area: "
            "panel:control)")
        return None
    try:
        app = await build_control_bot_application(token, ns)
        await app.initialize()
        await app.start()
        await app.updater.start_polling(
            allowed_updates=("*",), drop_pending_updates=False)
        me = await app.bot.get_me()
        state = ControlBotState()
        state.application = app
        state.username = (getattr(me, "username", "") or "").lstrip("@")
        state.telegram_bot_id = int(getattr(me, "id", 0) or 0)
        ns._control_bot_state = state
        logger.info("CONTROL_BOT_STARTED username=@%s bot_id=%s "
                    "(in-process admin control plane; credential never "
                    "logged)", state.username, state.telegram_bot_id)
        return state
    except Exception as exc:  # noqa: BLE001 — isolated startup
        logger.error("CONTROL_BOT_START_FAILED error=%s (the main bot "
                     "admin panel fallback remains available)", str(exc)[:200])
        return None


async def stop_control_bot(ns) -> None:
    state = getattr(ns, "_control_bot_state", None)
    if not state or not state.running:
        return
    try:
        app = state.application
        if app.updater and app.updater.running:
            await app.updater.stop()
        if app.running:
            await app.stop()
        await app.shutdown()
    except Exception as exc:  # noqa: BLE001
        logger.warning("CONTROL_BOT_STOP_ERROR %s", str(exc)[:160])
    finally:
        state.application = None
        ns._control_bot_state = None
        logger.info("CONTROL_BOT_STOPPED")
