"""NETWORK (N1): encrypted bot-token credential vault.

STANDALONE MODULE — never imports the bot monolith (same discipline as
app/core/*). bot.py wires this vault with its deployment secrets at call
time.

Spec §3 (BOT TOKEN SECURITY):
  * bot tokens are HIGHLY sensitive credentials
  * NEVER log / print / display / return tokens
  * authenticated encryption (or an equivalent secure design)
  * encryption keys come from deployment secrets/environment config and
    must NOT be stored beside the encrypted credentials
  * separate BOT METADATA (network_bots) from BOT CREDENTIAL
    (network_bot_credentials: encrypted_token + key_version)

Implementation:
  * Primary: ``cryptography.fernet.Fernet`` (AES + HMAC, authenticated
    encryption) with a key derived from the deployment secret
    NETWORK_TOKEN_ENCRYPTION_KEY.
  * Fallback (no ``cryptography`` package): a stdlib-only authenticated
    stream cipher: HMAC-SHA256 counter-mode keystream XOR +
    encrypt-then-MAC tag. This is a sound AEAD construction built ONLY
    from hashlib/hmac — no plaintext or tampered ciphertext can ever pass
    ``decrypt``.
  * Key derivation: SHA-256 of the configured secret (accepts raw Fernet
    keys, arbitrary passphrases, or hex — any non-empty string works and
    the SAME secret always derives the SAME key).
  * Key identity is tracked as ``key_version`` (integer) in the credential
    row so future rotation can re-encrypt lazily.
  * The secret NEVER lands in the database.

GAP-CLOSURE (spec §3 — network token encryption):
  * A DEDICATED persistent ``NETWORK_TOKEN_ENCRYPTION_KEY`` is required to
    ENCRYPT new credentials (``can_encrypt``): production fails CLOSED
    with explicit operator guidance when it is missing — no ephemeral
    production fallback.
  * LEGACY credentials encrypted with the old BOT_TOKEN-derived key
    (key_version=-1) keep DECRYPTING through the compatibility path so an
    existing deployment never silently loses its registered bots; a
    startup warning tells the operator to set the dedicated key and
    re-register (rotation guidance in docs/DEPLOYMENT.md).

v37 (bot-8 A1/A2 — the NETWORK_BOT_TOKEN_INVALID regression):
  * When the DEDICATED key is configured AND a ``bot_token_fallback`` was
    supplied, the vault keeps the legacy BOT_TOKEN-derived key as a
    DECRYPT-ONLY secondary. ``decrypt`` tries the dedicated key first,
    then the legacy key — so configuring the dedicated key (the operator
    action that previously broke every legacy credential at restart,
    NETWORK_BOT_TOKEN_INVALID network_bot_id=1 / workers=0) now keeps
    existing bots running.
  * ``decrypt_with_info`` reports WHICH key decrypted so the startup
    wiring can MIGRATE the credential to the dedicated key transparently
    (re-encrypt + persist + key_version=1) — the safe repair path. A
    credential that fails under BOTH keys is honestly
    CREDENTIAL_DECRYPT_FAILED (never silently replaced, never fabricated).
  * ``allow_ephemeral_fallback=True`` is the explicit TESTS-ONLY switch
    that restores the old permissive behavior.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import logging
import os
import re
from typing import Optional

logger = logging.getLogger("app.network.credentials")

KEY_VERSION = 1
# Per-process fallback marker (BOT_TOKEN-derived key).
KEY_VERSION_EPHEMERAL = -1

# The operator guidance shown when the dedicated key is missing (spec §3:
# fail closed in production; NEVER log the key itself).
ENCRYPTION_KEY_MISSING_GUIDANCE = (
    "NETWORK_TOKEN_ENCRYPTION_KEY is not configured. Network bot tokens "
    "are encrypted at rest with this dedicated persistent key. Generate "
    "one and set it in the environment, e.g.: "
    "python3 -c \"import secrets; print(secrets.token_urlsafe(48))\". "
    "Store it in your secret manager (it must survive restarts and stay "
    "independent of BOT_TOKEN). Existing legacy credentials keep "
    "decrypting; NEW registrations are refused until the key is set.")

_FERNET = None  # type: ignore[valid-type]
try:  # pragma: no cover - depends on deployment environment
    from cryptography.fernet import Fernet as _FernetCls
    _FERNET = _FernetCls
except Exception:  # noqa: BLE001 — optional dependency
    _FERNET = None

# Stdlib AEAD parameters for the fallback cipher.
_TAG_LEN = 32


class CredentialVault:
    """Encrypts/decrypts network bot tokens with authenticated encryption.

    All methods return/accept only ciphertext blobs (urlsafe base64 with a
    scheme prefix). Errors NEVER include token material.
    """

    def __init__(self, secret: Optional[str] = None,
                 bot_token_fallback: Optional[str] = None,
                 *,
                 allow_ephemeral_fallback: bool = False) -> None:
        self.key_version = KEY_VERSION
        self._fernet = None
        self._hmac_key: Optional[bytes] = None
        self._ephemeral = False
        # v37: legacy (BOT_TOKEN-derived) key kept for DECRYPT-ONLY when the
        # dedicated key is the primary — the A2 compatibility path.
        self._legacy_fernet = None
        self._legacy_hmac_key: Optional[bytes] = None
        if not secret:
            from app.bootstrap.config import EnvDefaults
            secret = EnvDefaults.from_env().network_token_encryption_key
        if not secret:
            secret = ""
        if not secret:
            # No dedicated persistent key (spec §3 fail-closed for WRITES):
            # keep the LEGACY BOT_TOKEN-derived key so existing key_version=-1
            # credentials keep decrypting, but refuse to ENCRYPT new ones
            # unless the caller explicitly opted into the ephemeral mode
            # (tests only).
            if bot_token_fallback:
                secret = bot_token_fallback
                self.key_version = KEY_VERSION_EPHEMERAL
                self._ephemeral = not allow_ephemeral_fallback
            else:
                # No secret at all (tests without BOT_TOKEN): derive from a
                # fixed test marker. Still authenticated; still never stored.
                secret = "__payload_network_test_key__"
                self.key_version = KEY_VERSION_EPHEMERAL
                self._ephemeral = not allow_ephemeral_fallback
        elif bot_token_fallback:
            # v37 A2: the dedicated key is the PRIMARY; the legacy
            # BOT_TOKEN-derived key stays available for DECRYPT-ONLY so
            # pre-existing key_version=-1 credentials survive the operator
            # setting the dedicated key (bot-8 startup 3 regression).
            legacy_raw = hashlib.sha256(
                bot_token_fallback.encode("utf-8")).digest()
            if _FERNET is not None:
                self._legacy_fernet = _FERNET(
                    base64.urlsafe_b64encode(legacy_raw))
            else:
                self._legacy_hmac_key = legacy_raw
        self._derive_key(secret)

    @property
    def can_encrypt(self) -> bool:
        """Whether NEW credentials may be encrypted with this vault.

        Production fail-closed (spec §3): False when only the legacy
        BOT_TOKEN-derived key is available (key_version=-1 without the
        explicit ephemeral allowance)."""
        return not self._ephemeral

    @property
    def encryption_key_missing(self) -> bool:
        """True when the dedicated NETWORK_TOKEN_ENCRYPTION_KEY is absent."""
        return self.key_version == KEY_VERSION_EPHEMERAL

    # ------------------------------------------------------------------
    def _derive_key(self, secret: str) -> None:
        """Derive the symmetric key material from the deployment secret."""
        raw = hashlib.sha256(secret.encode("utf-8")).digest()
        if _FERNET is not None:
            self._fernet = _FERNET(base64.urlsafe_b64encode(raw))
        else:  # stdlib fallback cipher
            self._hmac_key = raw

    # ------------------------------------------------------------------
    def encrypt(self, plaintext: str) -> str:
        """Encrypt a token string → urlsafe-b64 ciphertext blob.

        GAP-CLOSURE spec §3: raises ``ValueError`` with the operator
        guidance when the dedicated persistent key is missing (production
        fails CLOSED — never silently derives a security key from a
        rotating BOT_TOKEN)."""
        if not plaintext:
            raise ValueError("empty credential")
        if not self.can_encrypt:
            logger.warning(
                "NETWORK_TOKEN_ENCRYPT_REFUSED reason=encryption_key_missing "
                "key_version=%s (dedicated NETWORK_TOKEN_ENCRYPTION_KEY "
                "required; legacy credentials keep decrypting)",
                self.key_version)
            raise ValueError(ENCRYPTION_KEY_MISSING_GUIDANCE)
        if self._fernet is not None:
            blob = self._fernet.encrypt(plaintext.encode("utf-8"))
            return "f1:" + blob.decode("ascii")
        return "h1:" + self._xor_cipher(plaintext.encode("utf-8"))

    def decrypt(self, blob: str) -> str:
        """Decrypt a vault blob → token string. Raises ValueError on ANY
        tampering/failure (never includes token material in the error).

        v37 A2: tries the PRIMARY (dedicated) key first, then — when the
        vault was built with a bot-token fallback — the LEGACY key, so a
        legacy credential keeps working after the dedicated key is
        configured. Use :meth:`decrypt_with_info` to learn which key
        succeeded (for migration)."""
        return self.decrypt_with_info(blob)[0]

    def decrypt_with_info(self, blob: str) -> tuple:
        """Decrypt → ``(token, used_legacy_key: bool)``.

        ``used_legacy_key`` is True when the legacy BOT_TOKEN-derived
        secondary key decrypted the blob — the caller should re-encrypt
        with the dedicated key (migration) when ``can_encrypt``. Raises
        ValueError on any failure under BOTH keys."""
        if not blob:
            raise ValueError("empty ciphertext")
        primary_error: Optional[Exception] = None
        try:
            return self._decrypt_with(self._fernet, self._hmac_key, blob), False
        except ValueError as exc:
            primary_error = exc
        # v37 A2: legacy compatibility path (decrypt-only).
        if self._legacy_fernet is not None \
                or self._legacy_hmac_key is not None:
            try:
                return (self._decrypt_with(self._legacy_fernet,
                                           self._legacy_hmac_key, blob), True)
            except ValueError:
                pass
        raise primary_error or ValueError("credential decrypt failed")

    @staticmethod
    def _decrypt_with(fernet, hmac_key: Optional[bytes], blob: str) -> str:
        """Decrypt with ONE explicit key pair. Raises ValueError on ANY
        tampering/failure (never includes token material).

        V26 FINAL (Part 14 — the downloader-test finding): STRICT blob
        shape validation BEFORE any decode. The underlying base64
        decoders silently DISCARD trailing characters after the '='
        padding (verified live: ``<valid fernet token> + "x"`` still
        decrypts!), so a malformed/tampered token suffix must be
        rejected HERE — the urlsafe-base64 body may contain only
        [A-Za-z0-9_-] with at most 2 trailing '=' and no characters
        after them. Every AEAD surface (stream tokens, video refs, site
        sessions, network credentials) decodes through this chokepoint,
        so the strict rule covers them all."""
        try:
            if blob.startswith("f1:"):
                if fernet is None:
                    raise ValueError("ciphertext needs cryptography package")
                CredentialVault._require_strict_b64(blob[3:])
                return fernet.decrypt(
                    blob[3:].encode("ascii")).decode("utf-8")
            if blob.startswith("h1:"):
                if hmac_key is None:
                    raise ValueError("ciphertext needs the hmac fallback key")
                CredentialVault._require_strict_b64(blob[3:])
                try:
                    raw = base64.urlsafe_b64decode(
                        blob[3:].encode("ascii"))
                except Exception as exc:  # noqa: BLE001
                    raise ValueError("bad ciphertext encoding") from exc
                if len(raw) < 16 + _TAG_LEN:
                    raise ValueError("ciphertext too short")
                iv, ct, tag = raw[:16], raw[16:-_TAG_LEN], raw[-_TAG_LEN:]
                expect = hmac.new(hmac_key, iv + ct,
                                  hashlib.sha256).digest()
                if not hmac.compare_digest(tag, expect):
                    raise ValueError("credential authentication failed")
                out = bytearray()
                counter = 0
                while len(out) < len(ct):
                    block = hmac.new(
                        hmac_key, iv + counter.to_bytes(8, "big"),
                        hashlib.sha256).digest()
                    out.extend(block)
                    counter += 1
                keystream = bytes(out[:len(ct)])
                return bytes(a ^ b for a, b in zip(ct, keystream))\
                    .decode("utf-8")
        except ValueError:
            raise
        except Exception as exc:  # noqa: BLE001 — never leak token material
            raise ValueError("credential decrypt failed") from exc
        raise ValueError("unknown credential blob format")

    _STRICT_B64_RE = re.compile(r"\A[A-Za-z0-9_-]+={0,2}\Z")

    @classmethod
    def _require_strict_b64(cls, body: str) -> None:
        """The strict CANONICAL urlsafe-base64 body shape (see
        _decrypt_with): alphabet characters, padding only at the end,
        the padding count in {0, 1, 2} (never 3), and the TOTAL length
        (padding included) a multiple of 4 — exactly one canonical
        spelling per token. Rejects trailing garbage after the padding
        (``…T8=x``) AND padding-equivalent respellings (``…T8==``,
        ``…ABCD==``)."""
        if not body or not cls._STRICT_B64_RE.match(body):
            raise ValueError("bad ciphertext encoding")
        pad = len(body) - len(body.rstrip("="))
        if len(body) % 4 != 0 or pad > 2:
            raise ValueError("bad ciphertext encoding")

    # ------------------------------------------------------------------
    # Stdlib authenticated stream cipher (fallback)
    # ------------------------------------------------------------------
    def _xor_cipher(self, data: bytes) -> str:
        iv = os.urandom(16)
        keystream = self._keystream(iv, len(data))
        ct = bytes(a ^ b for a, b in zip(data, keystream))
        tag = hmac.new(self._hmac_key, iv + ct, hashlib.sha256).digest()
        return base64.urlsafe_b64encode(iv + ct + tag).decode("ascii")

    def _xor_uncipher(self, b64: str) -> bytes:
        try:
            raw = base64.urlsafe_b64decode(b64.encode("ascii"))
        except Exception as exc:  # noqa: BLE001
            raise ValueError("bad ciphertext encoding") from exc
        if len(raw) < 16 + _TAG_LEN:
            raise ValueError("ciphertext too short")
        iv, ct, tag = raw[:16], raw[16:-_TAG_LEN], raw[-_TAG_LEN:]
        expect = hmac.new(self._hmac_key, iv + ct, hashlib.sha256).digest()
        if not hmac.compare_digest(tag, expect):
            raise ValueError("credential authentication failed")
        keystream = self._keystream(iv, len(ct))
        return bytes(a ^ b for a, b in zip(ct, keystream))

    def _keystream(self, iv: bytes, length: int) -> bytes:
        out = bytearray()
        counter = 0
        while len(out) < length:
            block = hmac.new(
                self._hmac_key, iv + counter.to_bytes(8, "big"),
                hashlib.sha256).digest()
            out.extend(block)
            counter += 1
        return bytes(out[:length])


def mask_token(token: str) -> str:
    """Safe display form: only the numeric id prefix and 2 trailing chars
    (spec §3 — no token display, no token logging)."""
    if not token:
        return "(none)"
    head = token.split(":", 1)[0] if ":" in token else "?"
    tail = token[-2:] if len(token) >= 2 else ""
    return f"{head}:***{tail}"


__all__ = [
    "CredentialVault", "KEY_VERSION", "KEY_VERSION_EPHEMERAL", "mask_token",
    "ENCRYPTION_KEY_MISSING_GUIDANCE",
]
