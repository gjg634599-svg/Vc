"""NETWORK (N1): BotWorkerManager — many Telegram bot execution contexts.

STANDALONE MODULE — orchestrates PTB Application lifecycles for network
bots. bot.py provides the handler-registration callback so every worker
uses the SAME shared business logic (handlers, DB, services).

Spec sections implemented here:

§11/§12 NETWORK ARCHITECTURE + BOT WORKER MODEL — ONE platform, shared
    services, many bot execution contexts. A worker is
    ``BotWorker(bot_identity, shared_services)``: identity = network_bot_id
    / telegram_bot_id / username / PTB application; business logic is
    entirely shared (never copied per bot).

§59 FAILURE ISOLATION — starting/stopping/crashing one worker never
    touches the others; every lifecycle call is individually try/excepted
    and failures are reported per bot.

Lifecycle uses the PTB manual (custom) sequence — the MAIN application
keeps its existing ``run_polling`` flow untouched (zero regression):

    await app.initialize()
    await app.start()
    await app.updater.start_polling(...)   # background task, returns
    ...
    await app.updater.stop()
    await app.stop()
    await app.shutdown()

The registration of handlers happens through the injected
``register_handlers(app, network_bot_id)`` callback — bot.py passes its
shared user-facing handler set with the network context stamped into
``app.bot_data`` (network_bot_id + bot_username), so every handler can
scope its behavior (memberships, admin-guard, link building).
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Awaitable, Callable, Dict, List, Optional

logger = logging.getLogger("app.network.workers")

MAX_CONCURRENT_WORKERS = 200  # architectural headroom (spec §61: 5→500+)


class BotWorker:
    """One network bot execution context (spec §12)."""

    def __init__(self, network_bot_id: int, telegram_bot_id: int,
                 username: str, application) -> None:
        self.network_bot_id = int(network_bot_id)
        self.telegram_bot_id = int(telegram_bot_id)
        self.username = (username or "").lstrip("@")
        self.application = application
        self.running = False

    @property
    def bot(self):
        return self.application.bot if self.application else None


class BotWorkerManager:
    """Owns the lifecycle of every network bot worker application.

    Wiring (bot.py):
        build_worker_application: async (token, network_bot_id, username)
            -> PTB Application (handler registration included)
        on_worker_error: Optional async (network_bot_id, exc) -> None
        on_worker_started: Optional async (network_bot_id) -> None
            b10 §8 (B10-B2): fired AFTER a successful worker start (new
            registration, managed creation, legacy import AND the
            restart path) — the Main Mini App link reapply hook.
            Failures are isolated (never break the started worker).
    """

    def __init__(self, build_worker_application,
                 on_worker_error: Optional[
                     Callable[[int, Exception], Awaitable[None]]] = None,
                 on_worker_started: Optional[
                     Callable[[int], Awaitable[None]]] = None
                 ) -> None:
        self._build = build_worker_application
        self._on_error = on_worker_error
        self._on_started = on_worker_started
        self._workers: Dict[int, BotWorker] = {}

    # ------------------------------------------------------------------
    def get(self, network_bot_id: int) -> Optional[BotWorker]:
        return self._workers.get(int(network_bot_id))

    def get_by_telegram_id(self, telegram_bot_id: int) -> Optional[BotWorker]:
        for w in self._workers.values():
            if w.telegram_bot_id == int(telegram_bot_id):
                return w
        return None

    def get_by_username(self, username: str) -> Optional[BotWorker]:
        uname = (username or "").lstrip("@").lower()
        for w in self._workers.values():
            if w.username.lower() == uname:
                return w
        return None

    def list_workers(self) -> List[BotWorker]:
        return list(self._workers.values())

    def get_bot_client(self, network_bot_id: int):
        """bot-like client for the broadcast engine / delivery paths."""
        w = self._workers.get(int(network_bot_id))
        return w.bot if (w is not None and w.running) else None

    @property
    def active_count(self) -> int:
        return sum(1 for w in self._workers.values() if w.running)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def start_worker(self, network_bot_id: int, telegram_bot_id: int,
                           username: str, token: str) -> Optional[BotWorker]:
        """Initialize + start ONE worker. Failure is isolated and reported
        (returns None — never raises into the caller).

        B23-2 identity gate: right after ``await app.initialize()`` the
        LIVE bot identity (``app.bot.id`` / ``app.bot.username`` — set by
        PTB's initialize/get_me) is compared against the REGISTERED
        ``telegram_bot_id``. A mismatch means the credential does not
        belong to the registered bot (a pasted/wrong/rotated token): the
        partially-started app is shut down cleanly and the worker is
        REFUSED (NETWORK_BOT_IDENTITY_MISMATCH) — a wrong-identity worker
        would otherwise serve another bot's users under this row. An
        unknown id (degraded fakes / unparseable) is reported honestly
        and does NOT refuse."""
        nid = int(network_bot_id)
        if nid in self._workers and self._workers[nid].running:
            return self._workers[nid]  # idempotent
        if len(self._workers) >= MAX_CONCURRENT_WORKERS:
            logger.error("NETWORK_WORKER_LIMIT_REACHED limit=%s "
                         "(refusing network_bot_id=%s)",
                         MAX_CONCURRENT_WORKERS, nid)
            return None
        try:
            app = await self._build(token, nid, username)
            await app.initialize()
            # ---- B23-2: identity verification BEFORE start/polling -----
            actual_bot_id = 0
            actual_username = ""
            try:
                actual_bot_id = int(getattr(app.bot, "id", 0) or 0)
                actual_username = (getattr(app.bot, "username", "")
                                   or "").lstrip("@")
            except Exception:  # noqa: BLE001 — honest unknown, never a guess
                actual_bot_id, actual_username = 0, ""
            configured_bot_id = int(telegram_bot_id or 0)
            if actual_bot_id and configured_bot_id \
                    and actual_bot_id != configured_bot_id:
                identity_match = False
            elif actual_bot_id and configured_bot_id:
                identity_match = True
            else:
                identity_match = None  # honest unknown (degraded fakes)
            logger.info(
                "NETWORK_BOT_IDENTITY_CHECK network_bot_id=%s "
                "configured_bot_id=%s actual_bot_id=%s username=@%s "
                "identity_match=%s",
                nid, configured_bot_id or "-", actual_bot_id or "-",
                actual_username or "-",
                "True" if identity_match is True
                else ("False" if identity_match is False else "unknown"))
            if identity_match is False:
                logger.error(
                    "NETWORK_BOT_IDENTITY_MISMATCH network_bot_id=%s "
                    "configured_bot_id=%s actual_bot_id=%s username=@%s "
                    "(refusing to start this worker — the credential does "
                    "not belong to the registered bot)",
                    nid, configured_bot_id, actual_bot_id, actual_username)
                # Clean shutdown of the partially-started application
                # (same defensive cleanup as the existing failure path —
                # initialize() has run, so shutdown() is the matching
                # un initializer; nothing was started or polled yet).
                try:
                    await app.shutdown()
                except Exception:  # noqa: BLE001
                    pass
                return None
            await app.start()
            await app.updater.start_polling(
                allowed_updates=("*",),
                drop_pending_updates=False)
            worker = BotWorker(nid, telegram_bot_id, username, app)
            worker.running = True
            self._workers[nid] = worker
            logger.info("NETWORK_WORKER_STARTED network_bot_id=%s "
                        "telegram_bot_id=%s username=@%s (shared handlers)",
                        nid, telegram_bot_id, username)
            # b10 §8: the post-start hook (Main Mini App link reapply —
            # requirement C: survives restarts/re-registrations). Best-
            # effort + isolated: a hook failure NEVER kills the worker.
            if self._on_started is not None:
                try:
                    await self._on_started(nid)
                except Exception as exc:  # noqa: BLE001 — isolated
                    logger.warning(
                        "NETWORK_WORKER_STARTED_HOOK_FAILED "
                        "network_bot_id=%s error=%s (worker stays up)",
                        nid, type(exc).__name__)
            return worker
        except Exception as exc:  # noqa: BLE001 — per-bot isolation (§59)
            logger.error("NETWORK_WORKER_START_FAILED network_bot_id=%s "
                         "username=@%s error=%s",
                         nid, username, exc)
            if self._on_error is not None:
                try:
                    await self._on_error(nid, exc)
                except Exception:  # noqa: BLE001
                    pass
            # Defensive cleanup of a partially-started application.
            try:
                if "app" in locals() and app is not None:
                    await app.shutdown()
            except Exception:  # noqa: BLE001
                pass
            return None

    async def stop_worker(self, network_bot_id: int) -> bool:
        """Gracefully stop ONE worker (disable/remove). Returns success."""
        nid = int(network_bot_id)
        worker = self._workers.pop(nid, None)
        if worker is None:
            return True
        try:
            if worker.running and worker.application is not None:
                await worker.application.updater.stop()
                await worker.application.stop()
                await worker.application.shutdown()
            worker.running = False
            logger.info("NETWORK_WORKER_STOPPED network_bot_id=%s", nid)
            return True
        except Exception as exc:  # noqa: BLE001
            logger.warning("NETWORK_WORKER_STOP_FAILED network_bot_id=%s "
                           "error=%s (continuing — isolated)", nid, exc)
            return False

    async def stop_all(self) -> None:
        """Shutdown hook — stop every worker, isolated per bot."""
        for nid in list(self._workers.keys()):
            await self.stop_worker(nid)


# ----------------------------------------------------------------------
# BOT-11 (spec §1) — worker capability persistence (the worker start path)
# ----------------------------------------------------------------------
async def persist_worker_capability(db, bot_client,
                                    network_bot_id: int) -> Optional[bool]:
    """BOT-11 (spec §1): persist a worker bot's getMe-derived
    ``can_manage_bots`` capability (True→1 / False→0 / None→NULL) via
    ``db.set_network_bot_capability`` — ONE getMe on the ALREADY-STARTED
    worker client (the PTB application already called get_me during
    initialize; this is the cheap fresh read).

    Called from the worker start path — the ``on_worker_started`` hook
    area (bot_miniapp.on_worker_started resolves the db + the worker
    client through ``ns`` and invokes THIS helper; lifecycle.py wires
    the hook into BotWorkerManager, so every production worker start —
    registration, managed creation, reactivate, restart — persists the
    capability exactly once). Best-effort + isolated: a db without the
    v35 method, a missing client or a getMe failure NEVER raises (the
    honest NULL is persisted instead — never a fabricated value).
    Returns the persisted value (True/False/None) or None when skipped."""
    nid = int(network_bot_id or 0)
    if nid <= 0:
        return None
    setter = getattr(db, "set_network_bot_capability", None)
    if not callable(setter):
        return None
    if bot_client is None:
        # No running client → the honest unknown (NULL + checked_at).
        try:
            await setter(nid, None)
        except Exception:  # noqa: BLE001 — persistence is best-effort
            pass
        logger.info("MANAGED_BOT_CAPABILITY_RESULT network_bot_id=%s "
                    "can=None reason=no_running_worker", nid)
        return None
    getter = getattr(bot_client, "get_me", None)
    if not callable(getter):
        try:
            await setter(nid, None)
        except Exception:  # noqa: BLE001
            pass
        logger.info("MANAGED_BOT_CAPABILITY_RESULT network_bot_id=%s "
                    "can=None reason=no_get_me", nid)
        return None
    try:
        me = await getter()
    except Exception as exc:  # noqa: BLE001 — honest unknown
        try:
            await setter(nid, None)
        except Exception:  # noqa: BLE001
            pass
        logger.info("MANAGED_BOT_CAPABILITY_RESULT network_bot_id=%s "
                    "can=None reason=getMe_failed detail=%s", nid,
                    type(exc).__name__)
        return None
    raw = getattr(me, "can_manage_bots", None)
    can = None if raw is None else bool(raw)
    try:
        await setter(nid, can)
    except Exception:  # noqa: BLE001 — best-effort persistence
        pass
    logger.info("MANAGED_BOT_CAPABILITY_RESULT network_bot_id=%s can=%s",
                nid, "None" if can is None else ("True" if can else "False"))
    return can


__all__ = ["BotWorker", "BotWorkerManager", "MAX_CONCURRENT_WORKERS",
           "persist_worker_capability"]
