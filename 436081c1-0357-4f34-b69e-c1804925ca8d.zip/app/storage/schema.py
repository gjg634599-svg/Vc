"""SQLite schema + versioned migration chain (ARCHITECTURE DECOUPLING).

Storage-owned schema authority, extracted VERBATIM from the legacy
``bot.py`` monolith (SCHEMA_VERSION / SCHEMA_SQL / ``class Database``):
migrations no longer depend on the Telegram handler layer —
``app.storage`` imports only core constants + storage primitives.

Runtime context (ADMIN_IDS / DATABASE_FILE / RUNTIME_BUILD_ID /
WATCH_AD_UNLOCK_WINDOW / WATCH_AD_SESSION_HOURLY_CAP) is injected by the
composition (bot.py legacy facade today, app/bootstrap/application.py as
the authoritative wiring) via :func:`set_runtime_context` — the same
late-binding pattern the regression suites rely on. The logger uses the
shared ``payload-bot`` name, so log capture through ``bot.logger``
handlers keeps working unchanged.

Schema version 37 (BOT-16 — registered-bot removal lifecycle:
network_bots.removed_at + REMOVED documented as terminal). The migration
chain below is purely additive and idempotent.
"""
from __future__ import annotations

import asyncio
import logging
import os
import random as _random
import secrets as _secrets
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

import aiosqlite

from app.core.constants import (
    ACCESS_POLICY_FORCE_JOIN,
    ACCESS_POLICY_FORCE_JOIN_REFERRAL,
    NET_DEFAULT_MAX_BOTS,
    NET_DEFAULT_POINTS_PER_BOT,
    NET_DEFAULT_POINT_COST,
    NET_SETTING_BCAST_CONFIRM,
    NET_SETTING_BCAST_RATE,
    NET_SETTING_ENABLED,
    NET_SETTING_HEALTH_INTERVAL,
    NET_SETTING_MAX_BOTS,
    NET_SETTING_MAX_REWARD,
    NET_SETTING_POINTS_ACCESS,
    NET_SETTING_POINTS_PER_BOT,
    NET_SETTING_POINT_COST,
    PREVIEW_MODE_DISABLED,
    WATCH_AD_AD_CONTROL_DEFAULT,
    WATCH_AD_AD_CONTROL_KEY,
    WATCH_AD_AD_CONTROL_RANDOM,
    WATCH_AD_AD_CONTROL_THREE,
    WATCH_AD_AD_CONTROL_TWO,
    WATCH_AD_MAX_REQUIRED_ADS,
    WATCH_AD_PROVIDER_DEFAULT,
    WATCH_AD_RANDOM_MAX,
    WATCH_AD_RANDOM_MIN,
    WATCH_AD_SESSION_TTL,
    WATCH_AD_STATUS_EXPIRED,
    WATCH_AD_STATUS_PENDING,
    WATCH_AD_STATUS_REJECTED,
    WATCH_AD_STATUS_REWARDED,
    WATCH_ADS_GLOBAL_ENABLED_KEY,
    WATCH_ADS_SESSION_TTL_KEY,
)
from app.core.watch_ads.service import (
    WATCH_AD_TEMPLATE_SETTING_KEY,
    WATCH_AD_UNLOCK_TEMPLATE_DEFAULT,
)
from app.storage.database import DatabaseBase
from app.storage.dbutil import now_iso as _now_iso, safe_row_get as _safe_row_get

logger = logging.getLogger("payload-bot")

# ---------------------------------------------------------------------------
# Runtime context — injected by the composition root (late-bound, patchable).
# The defaults mirror the documented env defaults; the composition ALWAYS
# injects the parsed values at import time (immediately after config load).
# ---------------------------------------------------------------------------
ADMIN_IDS: list = []
DATABASE_FILE: str = ""
RUNTIME_BUILD_ID: str = "bot6-unknown"
WATCH_AD_UNLOCK_WINDOW: int = 180
WATCH_AD_SESSION_HOURLY_CAP: int = 10
WATCH_AD_TOKEN_BYTES: int = 16


def set_runtime_context(
    *,
    admin_ids: Optional[list] = None,
    database_file: Optional[str] = None,
    runtime_build_id: Optional[str] = None,
    watch_ad_unlock_window: Optional[int] = None,
    watch_ad_session_hourly_cap: Optional[int] = None,
) -> None:
    """Inject runtime configuration into the storage layer.

    Called once by the composition (bot.py import today) right after env
    parsing; the storage layer never imports the Telegram/entry layer.
    """
    global ADMIN_IDS, DATABASE_FILE, RUNTIME_BUILD_ID
    global WATCH_AD_UNLOCK_WINDOW, WATCH_AD_SESSION_HOURLY_CAP
    if admin_ids is not None:
        ADMIN_IDS = list(admin_ids)
    if database_file is not None:
        DATABASE_FILE = str(database_file)
    if runtime_build_id is not None:
        RUNTIME_BUILD_ID = str(runtime_build_id)
    if watch_ad_unlock_window is not None:
        WATCH_AD_UNLOCK_WINDOW = int(watch_ad_unlock_window)
    if watch_ad_session_hourly_cap is not None:
        WATCH_AD_SESSION_HOURLY_CAP = int(watch_ad_session_hourly_cap)


# ---------------------------------------------------------------------------
# Schema (extracted verbatim from bot.py)
# ---------------------------------------------------------------------------

SCHEMA_VERSION: int = 47


# ============================================================
# DATABASE SCHEMA
# ============================================================
SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER UNIQUE NOT NULL,
    username    TEXT,
    first_name  TEXT,
    joined_date TEXT NOT NULL,
    last_seen   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS indexed_files (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id    INTEGER NOT NULL,
    message_id    INTEGER NOT NULL,
    file_id       TEXT NOT NULL,
    file_unique_id TEXT,
    file_name     TEXT,
    caption       TEXT,
    media_type    TEXT,
    file_size     INTEGER,
    duration      INTEGER,
    upload_date   TEXT NOT NULL,
    views         INTEGER DEFAULT 0,
    downloads     INTEGER DEFAULT 0,
    -- PHASE 8 (v28): source reconciliation state (index verification).
    -- NULL = legacy row (treated as available). 'unavailable' = verification
    -- CONFIRMED the source message no longer exists. Rows are NEVER deleted
    -- and payload references are NEVER modified by reconciliation.
    source_status         TEXT,
    source_verified_at    TEXT,
    -- WEBSITE PHASE 2 (v30 part A): richer media metadata for the Payload
    -- Website / Mini App / player. All NULLABLE — legacy rows and partial
    -- captures stay NULL (metadata is never fabricated); re-indexing
    -- backfills only what the source message actually provides.
    -- thumb_* = the media's Telegram thumbnail (largest PhotoSize variant).
    mime_type             TEXT,
    width                 INTEGER,
    height                INTEGER,
    thumb_file_id         TEXT,
    thumb_file_unique_id  TEXT,
    -- V25 (§2/§3, bot-31.log): canonical re-point history. When the same
    -- file identity is re-sent to the storage channel AFTER the old
    -- canonical storage message was deleted, the canonical row is re-pointed
    -- to the NEW message (preserving pk/payload references) and the PREVIOUS
    -- reference is preserved here (NULL = never re-pointed). Additive +
    -- nullable: legacy rows stay NULL.
    prev_channel_id      INTEGER,
    prev_message_id      INTEGER,
    repointed_at         TEXT,
    UNIQUE(file_unique_id)
);

CREATE TABLE IF NOT EXISTS payloads (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    payload        TEXT UNIQUE NOT NULL,
    -- BOTV13: display_name is the editable human-readable title (e.g.
    -- "Kimmy Granger", "Summer Collection"). The `payload` column is the
    -- IMMUTABLE routing slug used for /start links, lookups, referral tokens,
    -- and collection c<code> routing. Changing display_name NEVER changes
    -- routing. NULL falls back to the slug (Title-Cased) for legacy rows.
    display_name   TEXT,
    index_id       INTEGER NOT NULL,
    status         TEXT DEFAULT 'active',
    delete_after   INTEGER,
    one_time       INTEGER DEFAULT 0,
    password       TEXT,
    expires_at     TEXT,
    max_clicks     INTEGER DEFAULT 0,
    current_clicks INTEGER DEFAULT 0,
    -- Access Engine V1: the single authorization policy for this payload.
    -- OPEN = no gate; FORCE_JOIN = require force-join channels;
    -- FORCE_JOIN_REFERRAL = force-join + referral unlock campaign.
    -- Future: PASSWORD / COUPON / PAYMENT / VIP / CUSTOM (architecture-ready).
    -- NULL is treated as ACCESS_POLICY_DEFAULT (FORCE_JOIN) for backward compat.
    access_policy        TEXT DEFAULT 'FORCE_JOIN',
    -- BOTV13 Phase 4: per-payload forward blocking (NULL=inherit global, 1=ON, 0=OFF).
    forward_blocking     INTEGER,
    -- WATCH_AD (v25): payload-level Watch Ads requirement. 0 = OFF (default for
    -- ALL existing payloads — migration never auto-enables it), 1 = users must
    -- complete a VERIFIED rewarded ad (Monetag Mini App + S2S postback) before
    -- this payload unlocks. INDEPENDENT of access_policy — never a replacement.
    watch_ads_enabled    INTEGER NOT NULL DEFAULT 0,
    -- WATCH_AD V4 (v27): per-payload override of the default ad mode.
    -- NULL = follow the global default (watch_ads_ad_control); one of
    -- 'short'|'two'|'three'|'random' = this payload uses that mode for NEWLY
    -- created ad sessions. NEVER changes required_ads of EXISTING sessions.
    watch_ads_ad_mode_override TEXT,
    -- BOT-13 §46 (website Get File control): per-payload Get File switch.
    -- 1 = the website renders the 📥 Get File button AND the server-side
    -- mint endpoint may generate a targeted Telegram link (legacy
    -- behavior — the backward-compatible default for ALL existing
    -- payloads); 0 = no button in ANY website surface AND the endpoint
    -- fails CLOSED with a truthful 'get_file_disabled' denial (no bot
    -- selection, no Global Link record, no delivery job). INDEPENDENT of
    -- website video playback (video keeps working with Get File OFF).
    show_get_file        INTEGER NOT NULL DEFAULT 1,
    -- BOT-13 §48 (per-payload delivery/access mode): where the website
    -- experience sends this payload's audience.
    --   'BOT'     = Telegram-first (legacy default): Get File drives the
    --                registered-bot delivery flow; the website player
    --                NEVER injects the website pre-roll; Watch Ads bot
    --                flow stays authoritative for ad-gated payloads.
    --   'WEBSITE' = Website Ads: video plays ON the website with the
    --                YouTube-style PRE_ROLL (when a VAST/direct provider
    --                is configured) — no Telegram redirect on play.
    --   'NONE'    = no website pre-roll, content plays directly.
    -- The mode NEVER gates the stream itself (signed URL, Range/206,
    -- seeking, 18+ and access checks all unchanged) and NEVER mixes with
    -- the Watch Ads reward system.
    video_ad_destination TEXT NOT NULL DEFAULT 'BOT',
    -- BOT-45/46 §5 (v47): the display_name PROVENANCE marker. NULL/'source'
    --   = display_name was derived from the CURRENT Telegram Storage source
    --   metadata (filename) — a live source re-resolve may refresh it when
    --   the source metadata changes (STORAGE_FILENAME_SOURCE).
    -- 'admin_override' = an administrator explicitly set the display name —
    --   PRESERVED verbatim; live source refresh NEVER overwrites it.
    display_name_origin TEXT,
    created_at     TEXT NOT NULL,
    updated_at     TEXT NOT NULL,
    FOREIGN KEY (index_id) REFERENCES indexed_files(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS payload_aliases (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    payload_id INTEGER NOT NULL,
    alias      TEXT UNIQUE NOT NULL,
    FOREIGN KEY (payload_id) REFERENCES payloads(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS payload_views (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    payload_id INTEGER NOT NULL,
    user_id    INTEGER,
    timestamp  TEXT NOT NULL,
    FOREIGN KEY (payload_id) REFERENCES payloads(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS force_join_channels (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id   INTEGER UNIQUE NOT NULL,
    channel_name TEXT,
    title        TEXT,
    -- Issue #47: persistent invite link management (prevents create/revoke loop)
    invite_link            TEXT,
    invite_link_created_at TEXT,
    invite_last_verified   TEXT,
    -- PHASE 8 (v28): invite-link health tracking (spec §12-§18).
    -- link_type: 'invite' (joinchat/+) | 'public' (username) | NULL
    -- link_health: healthy|link_expired|link_revoked|link_invalid|
    --   channel_invalid|bot_permission|temporary_error|unverifiable|no_link
    link_type                TEXT,
    link_health              TEXT,
    link_health_updated_at   TEXT,
    link_last_error          TEXT,
    link_expires_at          TEXT,
    link_validation_status   TEXT,
    -- B18 (v39) — link provenance: WHO minted the stored invite link.
    -- 'bot_created'  — the bot itself created it (export_chat_invite_link /
    --                  create_chat_invite_link / the transactional rotate);
    --                  provably valid at creation, revocation only happens
    --                  through our own rotate (tracked) — the Bot API has
    --                  NO getChatInviteLink, so provenance is the ONLY way
    --                  to distinguish a provably-ours link from a custom
    --                  admin-supplied one (trusted, not introspectable).
    -- 'custom'       — an admin supplied it via Set Custom Link.
    -- NULL           — legacy rows (pre-v39); treated as trusted-custom.
    link_provenance          TEXT,
    -- Issue #47: customizable force join text/buttons
    join_text              TEXT,
    join_text_entities     TEXT,
    verify_button_text     TEXT,
    channel_button_text    TEXT,
    -- Issue #47: media support for force join page
    media_file_id          TEXT,
    media_type             TEXT
);

-- BOT6 Phase 4: ONE canonical Force-Join dashboard per admin chat. The admin
-- FJ dashboard is a SINGLE persistent message — every config change (add /
-- remove / edit channel, change mode / batch / policy) EDITS this message
-- rather than sending a new one. Only recreated if Telegram confirms the old
-- message no longer exists. Persisted across restarts.
CREATE TABLE IF NOT EXISTS fj_dashboards (
    admin_chat_id        INTEGER PRIMARY KEY,
    dashboard_message_id INTEGER NOT NULL,
    updated_at           TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS storage_channels (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id  INTEGER UNIQUE NOT NULL,
    title       TEXT,
    username    TEXT,
    is_active   INTEGER DEFAULT 1,
    added_at    TEXT NOT NULL,
    last_scan   TEXT,
    -- Issue 26: incremental reindex state. NULL = never scanned yet (first scan
    -- will scan backwards from latest). After first scan, these hold the cursor
    -- so subsequent reindexes only scan NEW messages.
    last_scanned_message_id  INTEGER,
    last_indexed_message_id  INTEGER,
    last_media_message_id    INTEGER,
    last_reindex_time        TEXT
);

CREATE TABLE IF NOT EXISTS start_message (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    variant      TEXT UNIQUE NOT NULL,
    message_type TEXT DEFAULT 'text',
    file_id      TEXT,
    caption      TEXT,
    buttons_json TEXT,
    entities     TEXT
);

-- BOT6 Phase 25-26: admin-configurable Help / User Guide. Mirrors start_message
-- (text + optional media + buttons + entities). /help renders this for users;
-- admins edit it via the 📚 Help / User Guide dashboard option.
CREATE TABLE IF NOT EXISTS help_message (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    variant      TEXT UNIQUE NOT NULL DEFAULT 'default',
    message_type TEXT DEFAULT 'text',
    file_id      TEXT,
    caption      TEXT,
    buttons_json TEXT,
    entities     TEXT,
    enabled      INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS bot_settings (
    key   TEXT PRIMARY KEY,
    value TEXT
);

-- DEPRECATED (Issue 19): the `packs` table is kept ONLY for backward
-- compatibility with existing databases. No handler/callback/menu references
-- it. Range links (rSTART_END) fully replace it. Do NOT add new pack code.
CREATE TABLE IF NOT EXISTS packs (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    name             TEXT UNIQUE NOT NULL,
    start_message_id INTEGER NOT NULL,
    end_message_id   INTEGER NOT NULL,
    created_at       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS scheduled_broadcasts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    source_chat_id  INTEGER,
    source_message_id INTEGER,
    text_content TEXT,
    media_id     TEXT,
    media_type   TEXT,
    send_at      TEXT NOT NULL,
    status       TEXT DEFAULT 'Pending',
    created_at   TEXT NOT NULL,
    protect_content INTEGER DEFAULT 0,
    delete_after INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS broadcast_deletions (
    chat_id    INTEGER NOT NULL,
    message_id INTEGER NOT NULL,
    delete_at  TEXT NOT NULL,
    PRIMARY KEY (chat_id, message_id)
);

CREATE INDEX IF NOT EXISTS idx_indexed_file_unique   ON indexed_files(file_unique_id);
CREATE INDEX IF NOT EXISTS idx_indexed_channel_msg    ON indexed_files(channel_id, message_id);
CREATE INDEX IF NOT EXISTS idx_indexed_message_id     ON indexed_files(message_id);
CREATE INDEX IF NOT EXISTS idx_payloads_payload       ON payloads(payload);
CREATE INDEX IF NOT EXISTS idx_payloads_index         ON payloads(index_id);
CREATE INDEX IF NOT EXISTS idx_aliases_alias          ON payload_aliases(alias);
CREATE INDEX IF NOT EXISTS idx_views_payload          ON payload_views(payload_id);
CREATE INDEX IF NOT EXISTS idx_views_timestamp        on payload_views(timestamp);
CREATE INDEX IF NOT EXISTS idx_views_user             ON payload_views(user_id);
CREATE INDEX IF NOT EXISTS idx_storage_channel_id    ON storage_channels(channel_id);
CREATE INDEX IF NOT EXISTS idx_packs_name             ON packs(name);
CREATE INDEX IF NOT EXISTS idx_sched_bcast_status     ON scheduled_broadcasts(status, send_at);
CREATE INDEX IF NOT EXISTS idx_bcast_del_delete_at    ON broadcast_deletions(delete_at);

-- Issue 2 Critical Fix: explicit collection storage (replaces unreliable
-- rSTART_END range links). Each collection stores EVERY message_id explicitly
-- so delivery is always exact — no gaps, no missing files, no extra files,
-- no multi-channel collisions.
CREATE TABLE IF NOT EXISTS collections (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    collection_id TEXT UNIQUE NOT NULL,    -- short link code e.g. 'c7f3a9b2'
    channel_id    INTEGER NOT NULL,
    file_count    INTEGER DEFAULT 0,
    created_at    TEXT NOT NULL,
    created_by    INTEGER
);

CREATE TABLE IF NOT EXISTS collection_items (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    collection_id TEXT NOT NULL,
    channel_id    INTEGER NOT NULL,
    message_id    INTEGER NOT NULL,
    position      INTEGER DEFAULT 0,
    FOREIGN KEY (collection_id) REFERENCES collections(collection_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_collections_cid        ON collections(collection_id);
CREATE INDEX IF NOT EXISTS idx_coll_items_cid         ON collection_items(collection_id);
CREATE INDEX IF NOT EXISTS idx_coll_items_chan_msg    ON collection_items(channel_id, message_id);

-- Issue 34 Critical Fix: persistent auto-delete. Survives bot restart / crash /
-- VPS reboot / deployment restart. The in-memory asyncio.sleep timers are lost
-- on restart, so every scheduled deletion is also stored here. On startup the
-- bot deletes all due rows immediately, then re-schedules the remaining timers.
CREATE TABLE IF NOT EXISTS pending_deletions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id       INTEGER NOT NULL,
    message_id    INTEGER NOT NULL,
    delete_at     INTEGER NOT NULL,   -- unix epoch seconds
    deletion_type TEXT NOT NULL,      -- delivery | browse | admin_preview | status
    -- BOT-45/46 (v47): failed-delete retry accounting for the persistent
    -- auto-delete pass. attempts = bounded retry counter (0 = never
    -- failed); last_error = the classified reason of the most recent
    -- failure (never a raw exception / never a secret). DELETE FAILED is
    -- no longer silently settled: the row stays pending until a confirmed
    -- delete (or the idempotent 'already gone' result) or bounded give-up.
    attempts       INTEGER NOT NULL DEFAULT 0,
    last_error     TEXT
);
CREATE INDEX IF NOT EXISTS idx_pending_del_delete_at ON pending_deletions(delete_at);

-- Issue #53: Delivery records for Retrieve System. Stores the minimum info
-- needed to rebuild a delivery after auto-delete. Never stores Telegram
-- message IDs (those are ephemeral). Stores payload_code/collection_id +
-- user_id + type, so delivery can be reconstructed from the source of truth.
CREATE TABLE IF NOT EXISTS delivery_records (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    payload_code     TEXT,             -- payload name, m<msgid>, or c<collection_code>
    collection_code  TEXT,             -- collection code if delivery was a collection
    user_id          INTEGER NOT NULL,
    delivery_type    TEXT NOT NULL,    -- single | collection | browse | download_all
    delivered_at     TEXT NOT NULL,
    retrieve_count   INTEGER DEFAULT 0,
    max_retrieves    INTEGER DEFAULT 0,  -- 0 = unlimited
    retrieve_window_hours INTEGER DEFAULT 0,  -- 0 = no time limit
    chat_id          INTEGER NOT NULL,  -- where to send the recovery card
    recovery_message_id INTEGER          -- Issue #81: Telegram message_id of the recovery card
);
CREATE INDEX IF NOT EXISTS idx_deliv_records_user ON delivery_records(user_id);
CREATE INDEX IF NOT EXISTS idx_deliv_records_code ON delivery_records(payload_code);

-- Issue #57: Collection branding (title, description, banner).
-- Stored as a separate table keyed by collection_id so existing collections
-- are not affected. NULL = not set (use defaults).
CREATE TABLE IF NOT EXISTS collection_branding (
    collection_id      TEXT PRIMARY KEY,
    title              TEXT,
    description        TEXT,
    banner_file_id     TEXT,
    banner_type        TEXT
);

-- Issue #58: Source post branding. Stored per indexed_file for payload-level
-- branding (source message banner/caption/title).
CREATE TABLE IF NOT EXISTS source_branding (
    index_id           INTEGER PRIMARY KEY,
    source_message_id  INTEGER,
    banner_file_id     TEXT,
    banner_type        TEXT,
    source_caption     TEXT,
    source_title       TEXT
);

-- ============================================================
-- ISSUE #94: PAYLOAD REFERRAL GATE SYSTEM
-- ============================================================
-- Every payload MAY optionally require referrals before users can unlock
-- premium content. The gate is an OPTIONAL layer between Force Join and
-- Payload Delivery. Existing payloads are unaffected (gate OFF by default).
-- ============================================================

-- One campaign per payload with access_policy = FORCE_JOIN_REFERRAL.
CREATE TABLE IF NOT EXISTS referral_campaigns (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    payload_id          INTEGER UNIQUE NOT NULL,   -- payloads.id
    payload_code        TEXT NOT NULL,             -- payload name / m<id> / c<code>
    required_referrals  INTEGER DEFAULT 5,
    preview_mode        TEXT DEFAULT 'disabled',   -- disabled|thumbnail|description|custom
    unlock_mode         TEXT DEFAULT 'permanent',  -- permanent (future: timed)
    enabled             INTEGER DEFAULT 1,
    created_at          TEXT NOT NULL,
    -- Access Engine V1 preview media. The protected payload file is NEVER used
    -- as preview. Only admin-supplied media/text below is shown to locked users.
    preview_media_file_id TEXT,                    -- file_id of admin-supplied preview
    preview_media_type    TEXT,                    -- photo|video|animation|document
    preview_description   TEXT,                    -- admin-supplied preview text
    FOREIGN KEY (payload_id) REFERENCES payloads(id) ON DELETE CASCADE
);

-- Per-user-per-campaign referral link tokens (opaque, unambiguous).
CREATE TABLE IF NOT EXISTS referral_tokens (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id         INTEGER NOT NULL,
    inviter_user_id     INTEGER NOT NULL,
    token               TEXT UNIQUE NOT NULL,      -- 16-char hex
    created_at          TEXT NOT NULL,
    FOREIGN KEY (campaign_id) REFERENCES referral_campaigns(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_reftoken_token ON referral_tokens(token);
CREATE INDEX IF NOT EXISTS idx_reftoken_campaign_inviter ON referral_tokens(campaign_id, inviter_user_id);

-- Permanent referral history. NEVER deleted — analytics + fraud detection.
-- Access Engine V1: the ON DELETE CASCADE is INTENTIONALLY REMOVED so that
-- deleting a campaign can NEVER erase referral history. The FK is kept as a
-- referential hint but with ON DELETE RESTRICT semantics (history is sacred).
CREATE TABLE IF NOT EXISTS referral_history (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id         INTEGER NOT NULL,
    inviter_user_id     INTEGER NOT NULL,
    referred_user_id    INTEGER NOT NULL,
    qualified           INTEGER DEFAULT 0,         -- 1 = passed all checks
    qualified_at        TEXT,
    created_at          TEXT NOT NULL,
    UNIQUE(campaign_id, inviter_user_id, referred_user_id)
);
CREATE INDEX IF NOT EXISTS idx_refhist_campaign ON referral_history(campaign_id);
CREATE INDEX IF NOT EXISTS idx_refhist_inviter ON referral_history(inviter_user_id);
CREATE INDEX IF NOT EXISTS idx_refhist_referred ON referral_history(referred_user_id);

-- Per-user-per-campaign unlock progress. Controls payload access.
CREATE TABLE IF NOT EXISTS payload_unlocks (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    payload_id          INTEGER NOT NULL,
    campaign_id         INTEGER NOT NULL,
    user_id             INTEGER NOT NULL,
    required_referrals  INTEGER DEFAULT 5,
    completed_referrals INTEGER DEFAULT 0,
    unlocked            INTEGER DEFAULT 0,
    unlocked_at         TEXT,
    created_at          TEXT NOT NULL,
    -- BOTV7.1: Dashboard state tracking — the single dashboard message to edit.
    dashboard_msg_id    INTEGER,
    dashboard_chat_id   INTEGER,
    -- V9: Dashboard mode — determines the Telegram edit API to use.
    -- 'TEXT'    → dashboard was sent as a standalone text message  → editMessageText
    -- 'CAPTION' → dashboard was sent as a media caption            → editMessageCaption
    -- Prevents "There is no text in the message to edit" when editing a media message.
    dashboard_mode      TEXT,
    UNIQUE(payload_id, user_id),
    FOREIGN KEY (campaign_id) REFERENCES referral_campaigns(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_unlocks_user ON payload_unlocks(user_id);
CREATE INDEX IF NOT EXISTS idx_unlocks_payload ON payload_unlocks(payload_id);
CREATE INDEX IF NOT EXISTS idx_unlocks_campaign ON payload_unlocks(campaign_id);

-- ============================================================
-- ACCESS ENGINE V1 — ANALYTICS EVENT LOG
-- ============================================================
-- Append-only event log for access analytics. One row per event. Powers the
-- Campaign Views / Payload Opens / Preview Views / Referral Link Opens /
-- Qualified Referrals / Unlocks / Unlock Rate / Avg Unlock Time metrics.
CREATE TABLE IF NOT EXISTS access_events (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type    TEXT NOT NULL,    -- campaign_view|payload_open|preview_view|ref_link_open|qualified_referral|unlock
    payload_id    INTEGER,
    campaign_id   INTEGER,
    user_id       INTEGER,
    created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_access_events_type ON access_events(event_type);
CREATE INDEX IF NOT EXISTS idx_access_events_payload ON access_events(payload_id);
CREATE INDEX IF NOT EXISTS idx_access_events_campaign ON access_events(campaign_id);
CREATE INDEX IF NOT EXISTS idx_access_events_created ON access_events(created_at);

-- ============================================================
-- BOTV7.1: REFERRAL DASHBOARD CUSTOMIZATION
-- ============================================================
-- Stores global + per-campaign dashboard template overrides.
-- scope = 'global' for the default template, 'campaign' for per-campaign.
-- campaign_id is NULL for global, set for per-campaign overrides.
CREATE TABLE IF NOT EXISTS dashboard_settings (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    scope           TEXT NOT NULL DEFAULT 'global',
    campaign_id     INTEGER,
    key             TEXT NOT NULL,
    value           TEXT,
    updated_at      TEXT NOT NULL,
    UNIQUE(scope, campaign_id, key)
);
CREATE INDEX IF NOT EXISTS idx_dash_settings_scope ON dashboard_settings(scope);
CREATE INDEX IF NOT EXISTS idx_dash_settings_campaign ON dashboard_settings(campaign_id);

-- ============================================================
-- BOTV13 Phase 2: MULTI-ADMIN SYSTEM + ACTIVITY LOG
-- ============================================================
-- Granular permissions per admin. The owner (first ADMIN_IDS entry) always
-- has full access. Additional admins are added via the Admin Dashboard.
-- Permissions are stored as a JSON string for flexibility.
CREATE TABLE IF NOT EXISTS admins (
    user_id        INTEGER PRIMARY KEY,          -- Telegram user ID (immutable)
    username       TEXT,                         -- last-known @username (display only)
    first_name     TEXT,                         -- last-known first name (display only)
    permissions    TEXT DEFAULT '{}',            -- JSON: {"payload.view": true, ...}
    is_owner       INTEGER DEFAULT 0,            -- 1 = owner (full access, immutable)
    is_active      INTEGER DEFAULT 1,            -- 0 = disabled (cannot access bot)
    added_by       INTEGER,                      -- user_id of the admin who added them
    created_at     TEXT NOT NULL,
    updated_at     TEXT NOT NULL
);

-- Append-only admin activity log. Never deleted — audit trail.
CREATE TABLE IF NOT EXISTS admin_activity (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id       INTEGER NOT NULL,             -- who performed the action
    action         TEXT NOT NULL,                -- create|edit|rename|delete|enable|disable|...
    target_type    TEXT,                         -- payload|collection|admin|setting|...
    target_id      INTEGER,                      -- ID of the affected entity (if any)
    details        TEXT,                         -- JSON with old/new values, etc.
    created_at     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_admin_activity_admin ON admin_activity(admin_id);
CREATE INDEX IF NOT EXISTS idx_admin_activity_action ON admin_activity(action);
CREATE INDEX IF NOT EXISTS idx_admin_activity_created ON admin_activity(created_at);

-- ============================================================
-- BOTV13 PHASE 3: PROGRESSIVE FORCE JOIN  (v23: STABLE ACTIVE BATCH)
-- ============================================================
-- Per-USER force-join progress. The (user_id, payload_code) UNIQUE constraint
-- is preserved for backward compat, but the runtime stores ONE global row per
-- user (payload_code='') so progress is shared across all payloads.
--
-- v23 (BOTV13 Phase A): STABLE ACTIVE BATCH state machine.
--   active_batch        — JSON [chan_id, ...] of the CURRENT batch. Persisted
--                          and NEVER recalculated from the unjoined set. The
--                          same batch is shown until ALL its channels are joined.
--   completed_batches   — JSON [[chan_id,...], ...] of fully-joined batches.
--                          Used to advance the cursor and skip completed batches.
--   batch_cursor         — int: index into channel_order of the next un-batched
--                          channel (advances by batch_size when a batch completes).
--   unlocked_payload_ids — JSON [pid, ...] of payloads whose FJ batch completed.
--                          A payload in this list may be re-accessed WITHOUT
--                          requiring future batches ("future batches must NOT
--                          block the current payload"). NOT keyed by payload —
--                          this is a list inside the single per-user row.
--   presented (legacy)   — kept for backward compat / migration coalescing. The
--                          active_batch is the source of truth for "what to show".
--   requirement_identity — TEXT: 12-hex fingerprint of the CURRENT requirement
--                          config (mode|batch_size|sorted channel ids) — v44.
--                          When the admin changes the requirement (mode/batch
--                          size/channel set), the identity changes and the
--                          presentation state is re-derived deterministically
--                          (live membership stays the sole authorization
--                          authority — completion is never fabricated).
CREATE TABLE IF NOT EXISTS fj_progress (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id             INTEGER NOT NULL,
    payload_code        TEXT NOT NULL,              -- '' (global, per-user)
    channel_order       TEXT,                      -- JSON: [chan_id, ...] stable order
    presented           TEXT DEFAULT '[]',         -- JSON: [chan_id, ...] (legacy)
    active_batch        TEXT,                      -- JSON: [chan_id, ...] CURRENT batch (v23)
    completed_batches   TEXT DEFAULT '[]',         -- JSON: [[chan_id,...], ...] done (v23)
    batch_cursor        INTEGER DEFAULT 0,         -- next un-batched index (v23)
    unlocked_payload_ids TEXT DEFAULT '[]',        -- JSON: [pid, ...] unlocked (v23)
    requirement_identity TEXT,                     -- 12-hex config fingerprint (v44)
    created_at          TEXT NOT NULL,
    updated_at          TEXT NOT NULL,
    UNIQUE(user_id, payload_code)
);
CREATE INDEX IF NOT EXISTS idx_fj_progress_user ON fj_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_fj_progress_payload ON fj_progress(payload_code);

-- ============================================================
-- FJ GATE PRESENTATIONS (v46 — V26.2 Force-Join batching, bot-41 §16-§24)
-- ============================================================
-- One row per (user, gate_key): the PINNED BATCH a specific gated
-- playback/delivery presented to the user under the CURRENT requirement
-- identity. The pinned batch is exactly what the server DELIVERS to the
-- client for that gate — future batches are never sent (§23 leak rule).
-- Satisfaction is monotonic per pinned batch: once every pinned channel
-- is live-verified joined, that gate authorizes its content even while
-- LATER batches remain pending (progressive unlocking across gated
-- content — the operator's V26.2 product decision). A requirement
-- identity change (mode/batch_size/channel set) deterministically
-- re-arms every gate (the row is re-pinned on the next evaluation).
CREATE TABLE IF NOT EXISTS fj_gate_presentations (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id             INTEGER NOT NULL,
    gate_key            TEXT NOT NULL,              -- 'w|{listing}|{file_pk}' | 'b|p|{payload_id}' | 'b|a|{link_arg}'
    requirement_identity TEXT NOT NULL,             -- 12-hex config fingerprint at pin time
    pinned_batch        TEXT NOT NULL,              -- JSON: [chan_id, ...] the delivered batch
    created_at          TEXT NOT NULL,
    updated_at          TEXT NOT NULL,
    UNIQUE(user_id, gate_key)
);
CREATE INDEX IF NOT EXISTS idx_fj_gate_presentations_user
    ON fj_gate_presentations(user_id);

-- ============================================================
-- WATCH_AD (v25/v26) — secure rewarded-ad unlock sessions
-- ============================================================
-- One row per (user, payload) ad attempt. The token (32-char secure hex) is
-- the ONLY value exposed to the Mini App URL. Every session is hard-bound to
-- BOTH the Telegram user id AND the payload id — a reward for User A /
-- Payload A can never unlock User B or Payload B.
--
-- status lifecycle:
--   pending  -> rewarded   (ALL required ads server-verified via Monetag S2S
--                           postbacks — 'pending' with completed_ads>0 simply
--                           means a multi-ad session is still in progress)
--   pending  -> expired    (session TTL elapsed before verification)
--   rewarded -> expired    (unlock window elapsed — lazily flipped on access)
--   any      -> rejected   (cross-user telegram_id, payload disabled/deleted,
--                           watch ads disabled, or fraud signal)
-- A rewarded session grants access ONLY while unlock_expires_at > now.
-- reward_count gives idempotency: duplicate postbacks are counted, never
-- double-processed (replay / double-spend protection).
--
-- V2 (v26) Ads Control columns (multi-ad inside ONE session):
--   ad_control_mode — mode captured at session creation ('short'|'random'
--                     |'three'); stays STABLE for the session's lifetime so a
--                     global setting change never corrupts a live session.
--   required_ads    — server-decided number of verified rewards required
--                     (1 for short, random 1-3 for random, 3 for three).
--   completed_ads   — server-verified reward progress (0..required_ads).
--                     ONLY process_watch_ad_reward may increment it, and only
--                     once per distinct provider ymid (see
--                     watch_ad_reward_events) — never from the browser.
--   last_reward_at  — timestamp of the most recent verified reward.
CREATE TABLE IF NOT EXISTS watch_ad_sessions (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    token             TEXT UNIQUE NOT NULL,        -- 32-char secure random hex
    user_id           INTEGER NOT NULL,            -- Telegram user id (owner)
    payload_id        INTEGER NOT NULL,            -- payloads.id (binding)
    status            TEXT NOT NULL DEFAULT 'pending',
    provider          TEXT DEFAULT 'monetag',
    -- ymid sent to the Monetag SDK (== token for ad 1; token_N for ad N>=2;
    -- echoed back in the S2S postback and used for per-ad idempotency)
    ymid              TEXT,
    zone_id           TEXT,                        -- main zone from postback
    sub_zone_id       TEXT,                        -- delivering zone from postback
    request_var       TEXT,                        -- placement label from postback
    estimated_price   REAL,                        -- approx revenue (USD) from postback
    reward_count      INTEGER NOT NULL DEFAULT 0,  -- processed reward callbacks
    ad_control_mode   TEXT NOT NULL DEFAULT 'short',  -- v26: mode at creation
    required_ads      INTEGER NOT NULL DEFAULT 1,  -- v26: verified rewards needed
    completed_ads     INTEGER NOT NULL DEFAULT 0,  -- v26: verified rewards so far
    created_at        TEXT NOT NULL,
    rewarded_at       TEXT,
    last_reward_at    TEXT,                        -- v26: latest verified reward
    expires_at        TEXT,                        -- pending session validity (TTL)
    unlock_expires_at TEXT,                        -- rewarded unlock window end
    consumed_at       TEXT,                        -- first authorized delivery use
    launch_network_bot_id INTEGER                   -- V26: the network bot whose
                                                    -- Watch Ad button launched
                                                    -- this session (NULL = main
                                                    -- bot / legacy row)
);
CREATE INDEX IF NOT EXISTS idx_wad_sessions_token ON watch_ad_sessions(token);
CREATE INDEX IF NOT EXISTS idx_wad_sessions_user_payload ON watch_ad_sessions(user_id, payload_id);
CREATE INDEX IF NOT EXISTS idx_wad_sessions_status ON watch_ad_sessions(status);
CREATE INDEX IF NOT EXISTS idx_wad_sessions_created ON watch_ad_sessions(created_at);

-- ============================================================
-- WATCH_AD V2 (v26) — per-ad reward idempotency ledger
-- ============================================================
-- Exactly one row per DISTINCT provider ymid whose 'valued' reward was
-- ACCEPTED. The ymid is the Monetag S2S pass-through id we generate per ad
-- inside a session (token for ad 1, token_N for ad N>=2). The PRIMARY KEY on
-- ymid makes reward counting idempotent at the database level:
--   * Monetag postback retries (same ymid)  -> INSERT conflict -> duplicate,
--     never counted twice (replay protection).
--   * Two genuinely different ads            -> two distinct ymids -> each
--     counts exactly once.
--   * A reward for User A / Payload A        -> bound to their session; can
--     never be replayed against another user/payload (cross protection).
CREATE TABLE IF NOT EXISTS watch_ad_reward_events (
    ymid             TEXT PRIMARY KEY,          -- provider pass-through id (unique per ad)
    session_id       INTEGER NOT NULL,          -- watch_ad_sessions.id
    user_id          INTEGER NOT NULL,          -- session owner (binding)
    payload_id       INTEGER NOT NULL,          -- payload binding
    ad_index         INTEGER,                   -- 1-based ad slot inside the session
    event_type       TEXT,                      -- impression / click from postback
    estimated_price  REAL,                      -- approx revenue (USD) from postback
    created_at       TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_wad_reward_events_session ON watch_ad_reward_events(session_id);
CREATE INDEX IF NOT EXISTS idx_wad_reward_events_user_payload ON watch_ad_reward_events(user_id, payload_id);

-- ============================================================
-- WATCH_AD V4 (v27) — postback monitoring log (admin Status panel)
-- ============================================================
-- One row per incoming provider (Monetag) S2S postback with its FINAL
-- classification. Powers the Watch Ads admin Status/Monitoring panel
-- (postback counts: total / rewarded / duplicate / invalid / errors, recent
-- errors, recent rewards). The FULL session token is NEVER stored — only a
-- short prefix for correlation with WATCH_AD_* logs. Pruned by the cleanup
-- loop (keeps recent rows only).
CREATE TABLE IF NOT EXISTS watch_ad_postback_log (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at        TEXT NOT NULL,
    ymid_prefix       TEXT,              -- first 10 chars of the ymid (token_N)
    user_id           INTEGER,           -- session owner (when resolved)
    payload_id        INTEGER,           -- payload binding (when resolved)
    ad_index          INTEGER,           -- 1-based ad slot (when resolved)
    event_type        TEXT,              -- impression / click
    reward_event_type TEXT,              -- valued / non_valued
    result            TEXT NOT NULL,     -- rewarded|duplicate|non_valued|unknown|
                                         -- expired|rejected|inactive|error|foreign
    http_status       INTEGER            -- status answered to the provider
);
CREATE INDEX IF NOT EXISTS idx_wad_postback_log_created ON watch_ad_postback_log(created_at);
CREATE INDEX IF NOT EXISTS idx_wad_postback_log_result ON watch_ad_postback_log(result);

-- ============================================================
-- NETWORK PLATFORM (v29) — multi-bot expansion (spec §60)
-- ONE central platform + shared business logic + many bot execution
-- contexts. All tables are ADDITIVE; nothing above changes.
-- ============================================================

-- Bot METADATA (spec §3/§13 — separated from credentials).
CREATE TABLE IF NOT EXISTS network_bots (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_user_id     INTEGER NOT NULL,
    telegram_bot_id   INTEGER NOT NULL UNIQUE,   -- same Telegram bot cannot register twice
    username          TEXT,
    display_name      TEXT,
    status            TEXT DEFAULT 'PENDING',    -- PENDING|ACTIVE|DEGRADED|DISABLED|TOKEN_INVALID|ERROR|REMOVED (v37/BOT-16: REMOVED is the TERMINAL removal state — b10 §5; a removed bot never renders, never routes, never counts; DISABLED stays an admin/owner PAUSE)
    health            TEXT DEFAULT 'UNKNOWN',    -- HEALTHY|DEGRADED|TEMPORARILY_UNAVAILABLE|TOKEN_INVALID|DISABLED|UNKNOWN
    enabled           INTEGER DEFAULT 1,
    routing_weight    INTEGER DEFAULT 1,
    capabilities      TEXT,                      -- e.g. 'storage:full' (LEGACY pre-v34 routing hint — kept for history; routing now uses Delivery Group readiness, spec §47)
    management_mode   TEXT DEFAULT 'USER_OWNED', -- USER_OWNED|PLATFORM_MANAGED (v34 spec §27)
    credential_control TEXT DEFAULT 'OWNER',    -- OWNER|PLATFORM (who may replace the credential)
    created_via       TEXT DEFAULT '',          -- user_flow|create_wizard|admin_control_bot
    created_at        TEXT NOT NULL,
    updated_at        TEXT NOT NULL,
    last_health_check TEXT,
    last_error_code   TEXT,
    last_activity     TEXT,
    -- BOT-11 (spec §1/§7): persisted bot-management capability (from
    -- getMe.can_manage_bots; NULL = unknown/unchecked — NEVER fabricated)
    -- + the check timestamp.
    can_manage_bots        INTEGER,               -- NULL=unknown | 1=True | 0=False
    capability_checked_at  TEXT,
    -- BOT-11 (spec §9/§10): per-bot Mini App application state (truthful
    -- last-apply outcome; the canonical URL itself lives in settings).
    mini_app_url               TEXT DEFAULT '',
    mini_app_last_applied_at   TEXT,
    mini_app_last_apply_status TEXT DEFAULT '',
    mini_app_last_apply_error  TEXT DEFAULT '',
    -- BOT-16 (v37): durable removal timestamp — WHEN the bot was removed
    -- (audit/observability next to the REMOVED status). NULL = never
    -- removed; legacy pre-v37 removed rows keep NULL (their audit trail
    -- lives in last_error_code='REMOVED' + control_audit_events).
    removed_at        TEXT,
    -- V25 FINAL (v42, bot-35.log): the per-bot DELIVERY CHANNEL — the
    -- private channel BOTH the File Delivery Bot and this Network Bot
    -- administer; Stage A (FDB copies Storage -> Delivery Channel) writes
    -- messages here, Stage B (Network Bot copies Delivery Channel ->
    -- user) reads them. Migrated from legacy network_delivery_groups
    -- rows; NULL = not yet configured (delivery fails honestly with a
    -- remediation hint until an admin configures it).
    delivery_channel_chat_id INTEGER
);
CREATE INDEX IF NOT EXISTS idx_network_bots_owner ON network_bots(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_network_bots_status ON network_bots(status);

-- Bot CREDENTIAL (spec §3): encrypted token + key version ONLY.
-- The encryption key lives in deployment secrets — NEVER in this DB.
CREATE TABLE IF NOT EXISTS network_bot_credentials (
    network_bot_id    INTEGER PRIMARY KEY,
    encrypted_token   TEXT NOT NULL,
    key_version       INTEGER NOT NULL,
    created_at        TEXT NOT NULL,
    updated_at        TEXT NOT NULL,
    FOREIGN KEY (network_bot_id) REFERENCES network_bots(id) ON DELETE CASCADE
);

-- User <-> bot reachability (spec §15 — the hard invariant for routing
-- AND broadcast targeting).
CREATE TABLE IF NOT EXISTS user_bot_memberships (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    network_bot_id    INTEGER NOT NULL,
    telegram_user_id  INTEGER NOT NULL,
    first_started_at  TEXT NOT NULL,
    last_active_at    TEXT NOT NULL,
    blocked_at        TEXT,
    status            TEXT DEFAULT 'ACTIVE',     -- ACTIVE|BLOCKED|INACTIVE
    UNIQUE(network_bot_id, telegram_user_id)
);
CREATE INDEX IF NOT EXISTS idx_memberships_bot ON user_bot_memberships(network_bot_id);
CREATE INDEX IF NOT EXISTS idx_memberships_user ON user_bot_memberships(telegram_user_id);
CREATE INDEX IF NOT EXISTS idx_memberships_status ON user_bot_memberships(network_bot_id, status);

-- Points LEDGER (spec §6): append-only, auditable, idempotent.
CREATE TABLE IF NOT EXISTS points_ledger (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id           INTEGER NOT NULL,
    event_type        TEXT NOT NULL,             -- BOT_REGISTERED|PAYLOAD_UNLOCK|ADMIN_CREDIT|ADMIN_DEBIT
    amount            INTEGER NOT NULL,          -- +credit / -debit
    reference_type    TEXT,
    reference_id      INTEGER,
    idempotency_key   TEXT NOT NULL UNIQUE,      -- same event NEVER awards twice
    metadata          TEXT,
    created_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_points_ledger_user ON points_ledger(user_id);
CREATE INDEX IF NOT EXISTS idx_points_ledger_event ON points_ledger(event_type);

-- Point unlocks (spec §8/§10): permanent per (user, payload), mirror of
-- the referral unlock semantics.
CREATE TABLE IF NOT EXISTS point_unlocks (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    payload_id        INTEGER NOT NULL,
    user_id           INTEGER NOT NULL,
    points_spent      INTEGER NOT NULL,
    ledger_id         INTEGER NOT NULL,
    unlocked_at       TEXT NOT NULL,
    UNIQUE(payload_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_point_unlocks_user ON point_unlocks(user_id);

-- Global Payload Links (spec §17/§55): opaque signed code -> payload.
-- BOT-11 (spec §12/§16/§31): PER-LINK delivery target — 0 = main bot /
-- legacy untargeted links (existing behavior); >0 = the persisted
-- network_bot_id of the admin's chosen delivery bot ('random' mode locks
-- ONE bot at creation; never re-rolled at click time). target_mode
-- records the admin's chosen mode at mint time (''|main|random|bot).
CREATE TABLE IF NOT EXISTS global_payload_links (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    payload_id        INTEGER NOT NULL,
    public_code       TEXT NOT NULL UNIQUE,      -- code12-sig6 (opaque + signed)
    target_network_bot_id INTEGER NOT NULL DEFAULT 0,
    target_mode       TEXT DEFAULT '',           -- ''|main|random|bot
    active            INTEGER DEFAULT 1,
    clicks            INTEGER DEFAULT 0,
    last_click_at     TEXT,
    created_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_gpl_payload ON global_payload_links(payload_id);
-- NOTE: idx_gpl_target is NOT in SCHEMA_SQL on purpose: the top-level
-- executescript below runs BEFORE the v35 migration block adds the
-- target_network_bot_id column on an upgraded v34 database — creating the
-- index here would crash every production upgrade with "no such column".
-- The index is created in the `current < 35` migration block AFTER the
-- columns exist (and on fresh databases too — all blocks run when
-- current=0). Caught by test_bot11_global_links.py A6.

-- Routing events (spec §19/§69): structured routing decisions/failures.
CREATE TABLE IF NOT EXISTS network_routing_events (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type        TEXT NOT NULL,
    request_id        TEXT,
    payload_id        INTEGER,
    selected_bot_id   INTEGER,
    fallback_count    INTEGER DEFAULT 0,
    reason            TEXT,
    created_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_routing_events_created ON network_routing_events(created_at);

-- Network broadcasts (spec §38): ONE owner broadcast -> per-bot jobs ->
-- per-user durable deliveries.
CREATE TABLE IF NOT EXISTS broadcasts (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    method            TEXT NOT NULL,             -- TEXT|COPY|COPY_MULTI|FORWARD|FORWARD_MULTI|
                                                 -- PHOTO|VIDEO|DOCUMENT|AUDIO|ALBUM|
                                                 -- PAYLOAD_ANNOUNCEMENT|TEMPLATE
    text_content      TEXT,
    source_chat_id    INTEGER,                   -- central broadcast source chat
    source_message_ids TEXT,                      -- JSON list (albums / multi)
    media_id          TEXT,                       -- per-bot resolved references are NEVER shared (spec §30)
    media_type        TEXT,
    payload_id        INTEGER,
    target_mode       TEXT DEFAULT 'ALL_BOTS',    -- ALL_BOTS|SELECTED_BOTS|USERS_OF_BOT|ALL_REACHABLE
    target_bot_ids    TEXT,                       -- JSON list for SELECTED_BOTS
    protect_content   INTEGER DEFAULT 0,
    status            TEXT DEFAULT 'PENDING',    -- PENDING|RUNNING|PAUSED|COMPLETED|CANCELLED|FAILED
    error             TEXT,
    created_by        INTEGER NOT NULL,
    created_at        TEXT NOT NULL,
    started_at        TEXT,
    finished_at       TEXT
);
CREATE INDEX IF NOT EXISTS idx_broadcasts_status ON broadcasts(status);

CREATE TABLE IF NOT EXISTS broadcast_bot_jobs (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    broadcast_id      INTEGER NOT NULL,
    network_bot_id    INTEGER NOT NULL,
    status            TEXT DEFAULT 'PENDING',    -- PENDING|RUNNING|PAUSED|COMPLETED|CANCELLED|FAILED
    total             INTEGER DEFAULT 0,
    sent              INTEGER DEFAULT 0,
    failed            INTEGER DEFAULT 0,
    blocked           INTEGER DEFAULT 0,
    last_error        TEXT,
    created_at        TEXT NOT NULL,
    updated_at        TEXT,
    UNIQUE(broadcast_id, network_bot_id),
    FOREIGN KEY (broadcast_id) REFERENCES broadcasts(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_bbj_broadcast ON broadcast_bot_jobs(broadcast_id);

CREATE TABLE IF NOT EXISTS broadcast_deliveries (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    broadcast_id      INTEGER NOT NULL,
    network_bot_id    INTEGER NOT NULL,
    user_id           INTEGER NOT NULL,
    status            TEXT DEFAULT 'PENDING',    -- PENDING|SENT|FAILED|BLOCKED|UNAVAILABLE|CANCELLED|RETRYING
    telegram_message_id INTEGER,
    attempts          INTEGER DEFAULT 0,
    error_code        TEXT,
    error_message     TEXT,
    created_at        TEXT NOT NULL,
    sent_at           TEXT,
    last_attempt_at   TEXT,
    UNIQUE(broadcast_id, network_bot_id, user_id),
    FOREIGN KEY (broadcast_id) REFERENCES broadcasts(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_bd_status ON broadcast_deliveries(broadcast_id, status);
CREATE INDEX IF NOT EXISTS idx_bd_pending ON broadcast_deliveries(broadcast_id, network_bot_id, status);

-- WEBSITE PHASE 3 (v31, planned v30 part B): the Website PRESENTATION layer.
-- ONE listing row per Website card, referencing the CANONICAL Payload system
-- (never copying media): payload_id -> payloads.id (single-file Payload) or
-- collection_id -> collections.collection_id (multi-file Payload). Exactly
-- ONE canonical reference per listing (CHECK). NO foreign keys ON PURPOSE:
-- deleting a canonical payload/collection never cascades into Website state
-- and never blocks Telegram-side deletion; a listing whose canonical side
-- disappeared simply stops rendering publicly. Deleting a listing NEVER
-- touches the canonical Payload/Collection/indexed media (§18).
-- opaque_id (16 hex, secrets-generated) is the ONLY public identifier —
-- database ids, Telegram ids, message ids and file_id values are NEVER
-- exposed in Website URLs (§7/§20).
CREATE TABLE IF NOT EXISTS website_payloads (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    opaque_id            TEXT UNIQUE NOT NULL,
    payload_id           INTEGER,
    collection_id        TEXT,
    title                TEXT,
    description          TEXT,
    tags                 TEXT,
    thumb_file_id        TEXT,
    thumb_file_unique_id TEXT,
    position             INTEGER DEFAULT 0,
    published            INTEGER DEFAULT 0,
    created_by           INTEGER,
    created_at           TEXT NOT NULL,
    updated_at           TEXT NOT NULL,
    CHECK ((payload_id IS NULL) <> (collection_id IS NULL))
);
CREATE INDEX IF NOT EXISTS idx_website_payloads_pub ON website_payloads(published, position, id);
CREATE INDEX IF NOT EXISTS idx_website_payloads_pid ON website_payloads(payload_id);
CREATE INDEX IF NOT EXISTS idx_website_payloads_cid ON website_payloads(collection_id);

-- ============================================================
-- v33 (GAP-CLOSURE): Website CATEGORY SYSTEM (spec §26-§29) + the
-- centralized ADS PLATFORM (spec §35-§56) + download-pack settings.
-- ADDITIVE ONLY: no existing table is altered; canonical Payload data
-- is never copied (categories REFERENCE website_payloads rows).
-- ============================================================

-- Categories: professionally managed, configurable (spec §26).
CREATE TABLE IF NOT EXISTS website_categories (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    name           TEXT NOT NULL,
    slug           TEXT UNIQUE NOT NULL,
    icon           TEXT DEFAULT '',
    sort_order     INTEGER NOT NULL DEFAULT 0,
    enabled        INTEGER NOT NULL DEFAULT 1,
    visible        INTEGER NOT NULL DEFAULT 1,
    description    TEXT DEFAULT '',
    age_restricted INTEGER NOT NULL DEFAULT 0,
    created_at     TEXT NOT NULL,
    updated_at     TEXT NOT NULL
);

-- Payload -> category membership (spec §27): references EXISTING website
-- listing rows — never duplicates media; the canonical Payload stays
-- authoritative. NO FK on purpose (listing deletion never blocks category
-- cleanup; stale memberships simply stop matching published listings).
CREATE TABLE IF NOT EXISTS website_payload_categories (
    listing_id  INTEGER NOT NULL,
    category_id INTEGER NOT NULL,
    position    INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL,
    PRIMARY KEY (listing_id, category_id)
);
CREATE INDEX IF NOT EXISTS idx_wpc_cat ON website_payload_categories(category_id, position);

-- Ads: campaigns (spec §47) — the ONLY ad authority. No ad is ever
-- hard-coded into a page (spec §35).
CREATE TABLE IF NOT EXISTS ad_campaigns (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    name                    TEXT NOT NULL,
    status                  TEXT NOT NULL DEFAULT 'draft',  -- draft|active|paused|ended
    priority                INTEGER NOT NULL DEFAULT 0,
    start_at                TEXT,
    end_at                  TEXT,
    frequency_cap_per_user  INTEGER NOT NULL DEFAULT 0,     -- 0 = uncapped
    frequency_cap_hours     INTEGER NOT NULL DEFAULT 24,
    placements              TEXT,    -- JSON list of placement keys (null = all)
    categories              TEXT,    -- JSON list of category slugs (null = all)
    devices                 TEXT,    -- JSON list: mobile|desktop (null = all)
    enabled                 INTEGER NOT NULL DEFAULT 1,
    created_at              TEXT NOT NULL,
    updated_at              TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ad_campaigns_status ON ad_campaigns(status, enabled, priority);

-- Creatives (spec §36/§48): video | banner_image | banner_responsive |
-- html (explicitly-supported SAFE html) | provider (Monetag adapter).
-- URLs are validated (HTTPS only; javascript:/data:/file: rejected) at
-- every write AND at render time.
CREATE TABLE IF NOT EXISTS ad_creatives (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id       INTEGER NOT NULL,
    kind              TEXT NOT NULL,
    title             TEXT DEFAULT '',
    video_url         TEXT,
    image_desktop_url TEXT,
    image_mobile_url  TEXT,
    html_content      TEXT,
    click_url         TEXT,
    alt_text          TEXT DEFAULT '',
    duration_seconds  INTEGER NOT NULL DEFAULT 0,
    skip_enabled      INTEGER NOT NULL DEFAULT 1,
    skip_after_seconds INTEGER NOT NULL DEFAULT 5,
    provider_zone     TEXT,          -- Monetag zone (adapter integration)
    enabled           INTEGER NOT NULL DEFAULT 1,
    created_at        TEXT NOT NULL,
    updated_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ad_creatives_campaign ON ad_creatives(campaign_id, enabled);

-- Placement toggles (spec §49): admin-controlled; a disabled placement
-- slot collapses completely (never a blank box).
CREATE TABLE IF NOT EXISTS ad_placements (
    key         TEXT PRIMARY KEY,
    enabled     INTEGER NOT NULL DEFAULT 0,
    updated_at  TEXT NOT NULL
);

-- Ad events (spec §51): impressions/clicks/quartiles/completion/skip/
-- failure — opaque creative ids only, bounded writes, no PII.
CREATE TABLE IF NOT EXISTS ad_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    creative_id INTEGER NOT NULL,
    campaign_id INTEGER NOT NULL,
    placement   TEXT NOT NULL,
    user_id     INTEGER,
    event       TEXT NOT NULL,
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ad_events_creative ON ad_events(creative_id, event);
CREATE INDEX IF NOT EXISTS idx_ad_events_time ON ad_events(created_at);

-- Server-side frequency state (spec §42/§52): keyed by the AUTHENTICATED
-- Telegram identity (never client-supplied ids). One row per
-- (user, placement, window) with the window key 'D<yyyymmdd>' for daily
-- caps and 'S' for the session-independent cooldown stamp.
CREATE TABLE IF NOT EXISTS ad_frequency_state (
    user_id        INTEGER NOT NULL,
    placement      TEXT NOT NULL,
    window_key     TEXT NOT NULL,
    count          INTEGER NOT NULL DEFAULT 0,
    last_shown_at  TEXT,
    PRIMARY KEY (user_id, placement, window_key)
);

-- ============================================================
-- v34 (TRUSTED FILE DELIVERY): the relay delivery architecture.
-- Storage -> File Delivery Bot -> private Delivery Group ->
-- temporary relay -> Network Bot -> User -> FDB cleanup.
-- ADDITIVE ONLY; the canonical Payload/media systems are untouched.
-- ============================================================

-- File Delivery Bot singleton: the platform-owned trusted relay
-- authority (spec §21/§24/§37). The credential is the VAULT-ENCRYPTED
-- blob — plaintext tokens NEVER touch this table (spec §26).
CREATE TABLE IF NOT EXISTS file_delivery_bot (
    id                INTEGER PRIMARY KEY CHECK (id = 1),
    username          TEXT,
    telegram_bot_id   INTEGER,
    encrypted_token   TEXT,                    -- vault blob 'f1:.../h1:...'
    key_version       INTEGER NOT NULL DEFAULT 0,
    status            TEXT NOT NULL DEFAULT 'UNCONFIGURED',
                      -- UNCONFIGURED|READY|DEGRADED|DISABLED|TOKEN_INVALID
    storage_access    TEXT NOT NULL DEFAULT 'unknown',  -- full|partial|none|unknown
    worker_state      TEXT NOT NULL DEFAULT 'stopped',  -- stopped|running
    last_health_check TEXT,
    last_error        TEXT,
    created_at        TEXT NOT NULL,
    updated_at        TEXT NOT NULL
);

-- Delivery Groups (spec §39-§43): EXACTLY ONE private group per Network
-- Bot. The Telegram group membership boundary IS the isolation boundary
-- (spec §59) — no shared relay groups, no topic-based isolation.
CREATE TABLE IF NOT EXISTS network_delivery_groups (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    network_bot_id          INTEGER NOT NULL UNIQUE,
    owner_user_id           INTEGER NOT NULL,
    delivery_group_chat_id  INTEGER NOT NULL UNIQUE,
    title                   TEXT DEFAULT '',
    status                  TEXT NOT NULL DEFAULT 'DELIVERY_SETUP_REQUIRED',
                            -- DELIVERY_SETUP_REQUIRED|DELIVERY_VERIFYING|
                            -- DELIVERY_READY|DELIVERY_DEGRADED|
                            -- DELIVERY_UNAVAILABLE
    checks                  TEXT,      -- JSON detail of last verification
    verified_at             TEXT,
    last_checked_at         TEXT,
    last_error              TEXT,
    created_at              TEXT NOT NULL,
    updated_at              TEXT NOT NULL,
    FOREIGN KEY (network_bot_id) REFERENCES network_bots(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_ndg_status ON network_delivery_groups(status);

-- b10 §2/§3 (B10-B2): DURABLE pending Delivery-Group setup intent, keyed
-- by network_bot_id. The bot-10.log root cause: the wizard armed the
-- pending state ONLY in the MAIN app's user_data — the WORKER app (where
-- /setup and group messages arrive) has its own per-application memory,
-- so detection saw pending=False and silently returned. This row is the
-- SHARED intent (both applications read it; survives worker restarts).
-- chat_id remembers the LAST detected candidate group so Check Again
-- (dg:verify) can re-run the REAL verification before an association
-- exists. Rows EXPIRE (repo-side pruning: older than 24h) and are
-- cleared at DELIVERY_READY / bot removal.
CREATE TABLE IF NOT EXISTS network_dg_pending_setup (
    network_bot_id  INTEGER PRIMARY KEY,
    owner_user_id   INTEGER NOT NULL,
    chat_id         INTEGER,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);

-- Durable delivery jobs (spec §53-§56): the crash-safe relay state machine.
-- CREATED -> RELAY_CREATING -> RELAYED -> DELIVERING -> DELIVERED ->
-- DELETE_PENDING -> DELETED (+ FAILED / EXPIRED). Attempts + retry
-- scheduling make retries and crash recovery reconcilable; the Storage
-- master (channel_id + message_id) is the permanent recovery reference.
CREATE TABLE IF NOT EXISTS delivery_jobs (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id                 INTEGER NOT NULL,
    network_bot_id          INTEGER NOT NULL,
    payload_id              INTEGER,
    payload_code            TEXT,
    file_pk                 INTEGER,
    storage_chat_id         INTEGER,
    storage_message_id      INTEGER,
    delivery_group_chat_id  INTEGER,
    relay_message_id        INTEGER,
    status                  TEXT NOT NULL DEFAULT 'CREATED',
    attempts                INTEGER NOT NULL DEFAULT 0,
    max_attempts            INTEGER NOT NULL DEFAULT 5,
    next_retry_at           TEXT,
    last_error              TEXT,
    created_at              TEXT NOT NULL,
    updated_at              TEXT NOT NULL,
    relay_created_at        TEXT,
    delivered_at            TEXT,
    deleted_at              TEXT,
    -- BOT-12 §9: the user-facing message id produced by the final
    -- copy_message (group → user). Diagnostic evidence for duplicate-
    -- delivery audits (a retried job that lands twice is visible here).
    user_message_id         INTEGER,
    -- B17 (v38) — direct-delivery architecture audit columns:
    --   delivery_mode: HOW the file actually reached the user
    --     ('network_relay' | 'fdb_direct' | 'handoff'); NULL for legacy rows.
    --   handoff_token: the one-time t.me/<fdb>?start=dl<token> deep-link
    --     token while the job waits in HANDOFF_PENDING.
    --   handoff_sent_at: when the handoff button was sent (TTL basis).
    delivery_mode           TEXT,
    handoff_token           TEXT,
    handoff_sent_at         TEXT,
    -- V25 FINAL (v42, bot-35.log): the durable Stage-A identity — WHERE
    -- the Delivery Channel message lives. delivery_channel_id is the
    -- channel the FDB wrote to; delivery_message_id is the message the
    -- Network Bot's user-facing copy READ FROM (Stage B). Persisted for
    -- retry/reconciliation: a Stage-B "message to copy not found"
    -- self-heals by re-running Stage A; a re-uploaded source re-creates
    -- the channel message and the job becomes retryable again.
    delivery_channel_id     INTEGER,
    delivery_message_id     INTEGER,
    -- B18 (v39) — truthful Mode-A metrics: when a job settles via Mode B
    -- (fdb_direct) or Mode C (handoff) AFTER Mode A was attempted and
    -- failed/skipped, the honest reason is preserved here. Metrics can
    -- then distinguish "Mode A failed -> fallback delivered" (mode_a_failure
    -- IS NOT NULL) from "clean Mode-B delivery" (NULL) without parsing
    -- logs. Values: the layered verdict (e.g. storage_master_inaccessible,
    -- transient, capability_cached_no, no_delivery_group, group_lost).
    mode_a_failure          TEXT,
    mode_a_failure_at       TEXT,
    -- V26.x Phase 3 (v45) — Delivery Channel source cleanup marker: 1
    -- while the Delivery Channel SOURCE message for this job exists
    -- (set at Stage A; cleared only after the confirmed FDB delete of
    -- the exact (delivery_channel_id, delivery_message_id)). The
    -- sweeper reconciles DELIVERED rows with the flag set. The Storage
    -- Channel master is NEVER touched; the USER delivery TTL cleanup
    -- is an independent pass.
    channel_cleanup_pending INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (network_bot_id) REFERENCES network_bots(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_djobs_pending ON delivery_jobs(status, next_retry_at);
CREATE INDEX IF NOT EXISTS idx_djobs_relay ON delivery_jobs(status, relay_message_id);
CREATE INDEX IF NOT EXISTS idx_djobs_user ON delivery_jobs(user_id, created_at);

-- Control Bot audit events (spec §36): safe structured trail. Event names
-- + actor/bot ids ONLY — never tokens, never secrets, never initData.
CREATE TABLE IF NOT EXISTS control_audit_events (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    event           TEXT NOT NULL,
    actor_user_id   INTEGER,
    network_bot_id  INTEGER,
    detail          TEXT,
    created_at      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cae_event ON control_audit_events(event, id);

-- ==========================================================================
-- B18-FINAL v40 (bot-22.log pass): WEBSITE MEDIA ENGAGEMENT + the signed
-- external-browser handoff. Views are counted ONLY for video files and
-- ONLY after a meaningful playback threshold, deduplicated per viewer
-- (page refreshes never inflate counts). Reactions (like/dislike) are
-- ONE per (file, user) — switching updates atomically; removing returns
-- to no reaction. The handoff table backs the SINGLE-USE replay-protected
-- Mini App -> external browser session transfer.
-- ==========================================================================
CREATE TABLE IF NOT EXISTS media_view_events (
    file_pk       INTEGER NOT NULL,
    viewer_key    TEXT NOT NULL,
    last_view_at  REAL NOT NULL,
    PRIMARY KEY (file_pk, viewer_key)
);
CREATE TABLE IF NOT EXISTS media_reactions (
    file_pk      INTEGER NOT NULL,
    user_id      INTEGER NOT NULL,
    reaction     TEXT NOT NULL CHECK (reaction IN ('like','dislike')),
    reacted_at   REAL NOT NULL,
    PRIMARY KEY (file_pk, user_id)
);
CREATE INDEX IF NOT EXISTS idx_media_reactions_file ON media_reactions(file_pk);
CREATE TABLE IF NOT EXISTS website_handoffs (
    nonce       TEXT PRIMARY KEY,
    user_id     INTEGER NOT NULL,
    target      TEXT NOT NULL,
    expires_at  REAL NOT NULL,
    used_at     REAL,
    created_at  REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_website_handoffs_exp ON website_handoffs(expires_at);
"""


class Database(DatabaseBase):
    """Async SQLite wrapper: auto-creates tables, runs migrations, exposes
    parameterised helper queries (SQL-injection safe).

    ARCHITECTURE PHASE: all domain repositories now live in
    app/storage/repositories/* (composed by app.storage.database.
    DatabaseBase). What remains here is the source-pinned legacy core
    documented in docs/BOT_COMPATIBILITY.md: the v1→v29 migration chain
    (init_schema / _migrate / schema audits) and the Watch Ads
    session/reward transaction methods whose bodies and log formats
    are frozen by the regression suites.
    """

    def __init__(self, db_path: str) -> None:
        self.db_path = db_path
        self._db: Optional[aiosqlite.Connection] = None
        # BOTV13 Fix: serialise ALL explicit-transaction writes (BEGIN IMMEDIATE
        # blocks) so no two coroutines can ever interleave inside each other's
        # open transaction on the shared aiosqlite connection. This is the root
        # fix for `cannot start a transaction within a transaction`.
        self._write_lock: asyncio.Lock = asyncio.Lock()

    async def init_schema(self) -> None:
        """Create tables, run migrations, then VERIFY the critical columns
        actually exist (defense-in-depth: do NOT trust schema_meta alone).

        BOTV13 Phase A runtime fix: if schema_meta says version=23 but the
        v23 columns are missing (partial migration, different DB file, swallowed
        exception, CWD mismatch, stale container), the verification detects it,
        repairs it idempotently, verifies again, and FAILS LOUDLY if still
        missing — so the bot never starts with an incompatible schema that
        later surfaces as "no such column: active_batch" mid-delivery.
        """
        await self.conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_meta (key TEXT PRIMARY KEY, value TEXT);"
        )
        await self.conn.commit()
        await self.conn.executescript(SCHEMA_SQL)
        await self.conn.commit()
        await self._migrate()
        # DEFENSE-IN-DEPTH: verify critical columns exist regardless of what
        # schema_meta claims. Repair if missing. Fail loudly if still missing.
        await self._verify_critical_schema()
        # WATCH_AD V3 (production fix): the DEDICATED, COMPLETE Watch Ads
        # schema audit — every watch_ad_sessions column + the reward ledger
        # referenced by this source, verified/repaired/fail-loud INDEPENDENT
        # of schema_meta. Closes the live failure where a DB stamped v26 was
        # missing last_reward_at (version-gated migration never re-runs).
        await self._verify_watch_ads_schema()
        # Log the actual runtime database path + version so operators can
        # confirm the bot is using the DB they think it is (multiple .db
        # files / wrong working directory / container volume mismatch).
        try:
            cur = await self.conn.execute(
                "SELECT value FROM schema_meta WHERE key='version';"
            )
            row = await cur.fetchone()
            v = row["value"] if row else "?"
        except Exception:  # noqa: BLE001
            v = "?"
        logger.info(
            "Database schema initialised. DATABASE_FILE=%s "
            "DATABASE_REALPATH=%s DATABASE_SCHEMA_VERSION=%s WORKING_DIR=%s",
            self.db_path, os.path.realpath(self.db_path), v, os.getcwd())
        # BOTV13 PHASE 6 (§2): UNCONDITIONAL + idempotent template seed —
        # runs on every database (fresh AND already-stamped v27), never
        # overwrites a custom template, never blocks startup.
        try:
            cur_tpl = await self.conn.execute(
                "SELECT value FROM bot_settings WHERE key = ?",
                (WATCH_AD_TEMPLATE_SETTING_KEY,))
            if not await cur_tpl.fetchone():
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES (?, ?)",
                    (WATCH_AD_TEMPLATE_SETTING_KEY,
                     WATCH_AD_UNLOCK_TEMPLATE_DEFAULT))
                await self.conn.commit()
                logger.info("WATCH_AD_TEMPLATE_SEED default template "
                            "inserted (key=%s).",
                            WATCH_AD_TEMPLATE_SETTING_KEY)
        except Exception as e:  # noqa: BLE001
            logger.debug("watch_ads template seed: %s", e)

    WATCH_AD_SESSION_COLUMNS: List[Tuple[str, str, str]] = [
        ("watch_ad_sessions", "id", None),                # PK — no ALTER possible
        ("watch_ad_sessions", "token", None),             # v25 base
        ("watch_ad_sessions", "user_id", None),           # v25 base
        ("watch_ad_sessions", "payload_id", None),        # v25 base
        ("watch_ad_sessions", "status", None),            # v25 base
        ("watch_ad_sessions", "provider", None),          # v25 base
        ("watch_ad_sessions", "ymid", None),              # v25 base
        ("watch_ad_sessions", "zone_id", None),           # v25 base (postback write)
        ("watch_ad_sessions", "sub_zone_id", None),       # v25 base (postback write)
        ("watch_ad_sessions", "request_var", None),       # v25 base (postback write)
        ("watch_ad_sessions", "estimated_price", None),   # v25 base (postback write)
        ("watch_ad_sessions", "reward_count", "INTEGER NOT NULL DEFAULT 0"),
        ("watch_ad_sessions", "created_at", None),
        ("watch_ad_sessions", "rewarded_at", None),
        ("watch_ad_sessions", "expires_at", None),
        ("watch_ad_sessions", "unlock_expires_at", None),
        ("watch_ad_sessions", "consumed_at", None),
        # v26 columns (the production gap lived exactly here):
        ("watch_ad_sessions", "ad_control_mode", "TEXT NOT NULL DEFAULT 'short'"),
        ("watch_ad_sessions", "required_ads", "INTEGER NOT NULL DEFAULT 1"),
        ("watch_ad_sessions", "completed_ads", "INTEGER NOT NULL DEFAULT 0"),
        ("watch_ad_sessions", "last_reward_at", "TEXT"),
        # V26 (Network Bot Watch Ads): the launch context so the verified
        # reward notification + auto-resume DELIVER through the bot the
        # user is actually talking to. Additive/nullable/idempotent.
        ("watch_ad_sessions", "launch_network_bot_id", "INTEGER"),
    ]

    WATCH_AD_LEDGER_TABLE = "watch_ad_reward_events"

    WATCH_AD_LEDGER_SQL = """
        CREATE TABLE IF NOT EXISTS watch_ad_reward_events (
            ymid             TEXT PRIMARY KEY,
            session_id       INTEGER NOT NULL,
            user_id          INTEGER NOT NULL,
            payload_id       INTEGER NOT NULL,
            ad_index         INTEGER,
            event_type       TEXT,
            estimated_price  REAL,
            created_at       TEXT NOT NULL
        )"""

    WATCH_AD_LEDGER_COLUMNS: List[Tuple[str, str, str]] = [
        ("watch_ad_reward_events", "ymid", None),          # PK
        ("watch_ad_reward_events", "session_id", None),
        ("watch_ad_reward_events", "user_id", None),
        ("watch_ad_reward_events", "payload_id", None),
        ("watch_ad_reward_events", "ad_index", None),
        ("watch_ad_reward_events", "event_type", None),
        ("watch_ad_reward_events", "estimated_price", None),
        ("watch_ad_reward_events", "created_at", None),
    ]

    async def _verify_watch_ads_schema(self) -> None:
        """WATCH_AD V3 (production fix): the COMPLETE Watch Ads schema audit.

        Root cause this closes (bot.log 2026-09-07): the live DB reached
        schema_meta_version=26 while `watch_ad_sessions.last_reward_at` (and
        ad_control_mode) were absent — the version-gated migration can never
        re-run on a stamped DB, and CRITICAL_COLUMNS was incomplete, so the
        bot started "healthy" and process_watch_ad_reward() failed on EVERY
        postback with `sqlite3.OperationalError: no such column:
        last_reward_at`, silently discarding genuine Monetag rewards.

        This audit is authoritative INDEPENDENT of schema_meta:
          1. Audits every watch_ad_sessions column actually referenced by
             this source (the full SQL contract, 21 columns).
          2. Audits the watch_ad_reward_events ledger table + its columns.
          3. Repairs idempotently (ALTER ADD COLUMN only where the column
             does not exist; CREATE TABLE IF NOT EXISTS for the ledger).
          4. Re-verifies after repair.
          5. FAILS LOUDLY (RuntimeError) if anything is still missing — the
             bot must never start a supposedly healthy Watch Ads system on
             a schema the reward processor cannot write to.

        Logs WATCH_AD_SCHEMA_VERIFY per column (PASS/FAIL) and
        WATCH_AD_SCHEMA_REPAIR for every applied repair.
        """
        async def _repair_column(table: str, column: str,
                                 definition: Optional[str]) -> bool:
            """Returns True when the column now exists (repaired or present)."""
            if await self._column_exists(table, column):
                return True
            if definition is None:
                # Base/PK column that cannot be ALTERed into existence — a
                # missing base column means the table itself is wrong; the
                # only safe repair is the full CREATE TABLE IF NOT EXISTS
                # scaffold (no-op on an existing table) — so if it is still
                # missing afterwards this is an unrepairable corruption.
                return False
            try:
                await self.conn.execute(
                    f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
                await self.conn.commit()
                logger.info(
                    "WATCH_AD_SCHEMA_REPAIR action=add_column table=%s "
                    "column=%s definition=%r", table, column, definition)
                return await self._column_exists(table, column)
            except Exception as e:  # noqa: BLE001
                logger.error(
                    "WATCH_AD_SCHEMA_REPAIR action=add_column FAILED table=%s "
                    "column=%s exc=%s.%s reason=%s", table, column,
                    type(e).__module__, type(e).__name__, e, exc_info=True)
                return False

        # 0) Ensure both tables exist at all (a v25-shaped DB without the
        # ledger, or a restored DB missing the session table entirely).
        # v27: the postback monitoring log is ALSO ensured here — a stamped
        # DB can miss it exactly like the ledger (V3 lesson applied).
        postback_log_sql = """
            CREATE TABLE IF NOT EXISTS watch_ad_postback_log (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at        TEXT NOT NULL,
                ymid_prefix       TEXT,
                user_id           INTEGER,
                payload_id        INTEGER,
                ad_index          INTEGER,
                event_type        TEXT,
                reward_event_type TEXT,
                result            TEXT NOT NULL,
                http_status       INTEGER
            )"""
        for table, create_sql in (
                ("watch_ad_sessions", None),  # scaffolded by SCHEMA_SQL already
                (self.WATCH_AD_LEDGER_TABLE, self.WATCH_AD_LEDGER_SQL),
                ("watch_ad_postback_log", postback_log_sql)):
            if not await self._table_exists(table):
                if create_sql is None:
                    # watch_ad_sessions is created by SCHEMA_SQL (executed
                    # before migrations); if it is STILL missing the DB is
                    # fundamentally broken -> caught by the column audit.
                    logger.error("WATCH_AD_SCHEMA_VERIFY table=%s MISSING "
                                 "(no session table) — unrepairable", table)
                    continue
                try:
                    await self.conn.execute(create_sql)
                    if table == self.WATCH_AD_LEDGER_TABLE:
                        await self.conn.execute(
                            "CREATE INDEX IF NOT EXISTS idx_wad_reward_events_session "
                            "ON watch_ad_reward_events(session_id)")
                        await self.conn.execute(
                            "CREATE INDEX IF NOT EXISTS idx_wad_reward_events_user_payload "
                            "ON watch_ad_reward_events(user_id, payload_id)")
                    elif table == "watch_ad_postback_log":
                        await self.conn.execute(
                            "CREATE INDEX IF NOT EXISTS idx_wad_postback_log_created "
                            "ON watch_ad_postback_log(created_at)")
                        await self.conn.execute(
                            "CREATE INDEX IF NOT EXISTS idx_wad_postback_log_result "
                            "ON watch_ad_postback_log(result)")
                    await self.conn.commit()
                    logger.info("WATCH_AD_SCHEMA_REPAIR action=create_table "
                                "table=%s", table)
                except Exception as e:  # noqa: BLE001
                    logger.error(
                        "WATCH_AD_SCHEMA_REPAIR action=create_table FAILED "
                        "table=%s exc=%s.%s reason=%s", table,
                        type(e).__module__, type(e).__name__, e, exc_info=True)
        # 0b) v27 audit line: the postback log must exist (created by SCHEMA_SQL
        # on fresh DBs, the v27 migration on upgraded DBs, or the ensure above
        # on stamped-but-partial DBs) — reported like every other contract.
        _pb_ok = await self._table_exists("watch_ad_postback_log")
        logger.info("WATCH_AD_SCHEMA_VERIFY watch_ad_postback_log=%s",
                    "PASS" if _pb_ok else "FAIL")

        # 1) Audit + repair every session column, then re-verify.
        report: List[str] = []
        still_missing: List[str] = []
        for table, column, definition in self.WATCH_AD_SESSION_COLUMNS:
            ok = await _repair_column(table, column, definition)
            report.append(f"{table}.{column}={'PASS' if ok else 'FAIL'}")
            if not ok:
                still_missing.append(f"{table}.{column}")
        # 2) Audit + repair every ledger column, then re-verify.
        for table, column, definition in self.WATCH_AD_LEDGER_COLUMNS:
            ok = await _repair_column(table, column, definition)
            report.append(f"{table}.{column}={'PASS' if ok else 'FAIL'}")
            if not ok:
                still_missing.append(f"{table}.{column}")
        # 3) Emit the explicit per-column startup report (spec §5).
        logger.info("WATCH_AD_SCHEMA_VERIFY %s", " | ".join(report))
        if still_missing:
            raise RuntimeError(
                f"FATAL: Watch Ads schema is missing required columns even "
                f"after idempotent repair: {', '.join(still_missing)}. "
                f"DATABASE_FILE={self.db_path} "
                f"DATABASE_REALPATH={os.path.realpath(self.db_path)}. "
                f"The reward processor (process_watch_ad_reward) writes these "
                f"columns — starting anyway would repeat the live production "
                f"failure (OperationalError -> every Monetag reward rejected). "
                f"Restore from a known-good backup or rebuild the table."
            )

    async def _migrate(self) -> None:
        cur = await self.conn.execute(
            "SELECT value FROM schema_meta WHERE key='version';"
        )
        row = await cur.fetchone()
        current = int(row["value"]) if row else 0

        if current < 2:
            # v1 -> v2: add new columns to existing tables (idempotent).
            await self._add_column_if_missing("payloads", "delete_after", "INTEGER")
            await self._add_column_if_missing("payloads", "one_time", "INTEGER DEFAULT 0")
            await self._add_column_if_missing("force_join_channels", "title", "TEXT")
            # New tables (storage_channels / start_message / bot_settings) are
            # created by executescript(SCHEMA_SQL) above via IF NOT EXISTS.
            logger.info("Applied v2 migrations (payloads.delete_after/one_time, "
                        "force_join_channels.title, new tables).")

        if current < 3:
            # v2 -> v3: historical migration that added the legacy `packs` table
            # + the idx_indexed_message_id index. Issue 19: the packs table is
            # DEPRECATED — no handler/callback/menu references it. Range links
            # (rSTART_END) fully replace it. It is kept in the schema only so
            # existing databases/data are preserved. Both are created by
            # executescript(SCHEMA_SQL) above via CREATE ... IF NOT EXISTS.
            logger.info("Applied v3 migrations (DEPRECATED packs table + idx_indexed_message_id).")

        if current < 4:
            # v3 -> v4: add broadcast tables (scheduled_broadcasts,
            # broadcast_deletions) + protection/broadcast settings seeds.
            # All tables/indexes are created by executescript(SCHEMA_SQL) via IF NOT EXISTS.
            logger.info("Applied v4 migrations (scheduled_broadcasts, "
                        "broadcast_deletions tables + settings seeds).")

        if current < 5:
            # v4 -> v5 (Issue 26): incremental reindex state columns on storage_channels.
            # These enable the new cursor-based reindex model: first scan goes
            # backwards from latest; subsequent scans only process NEW messages.
            # Existing data (payloads, indexed_files, channels, settings) is never
            # touched — only new columns are added.
            await self._add_column_if_missing("storage_channels", "last_scanned_message_id", "INTEGER")
            await self._add_column_if_missing("storage_channels", "last_indexed_message_id", "INTEGER")
            await self._add_column_if_missing("storage_channels", "last_media_message_id", "INTEGER")
            await self._add_column_if_missing("storage_channels", "last_reindex_time", "TEXT")
            logger.info("Applied v5 migrations (storage_channels incremental reindex state columns).")

        if current < 6:
            # v5 -> v6 (Issue 2 Critical Fix): explicit collection storage.
            # Creates collections + collection_items tables so delivery is always
            # exact (no range inference). Old range links (rSTART_END) are kept
            # working via backward-compat shim that auto-migrates them to
            # explicit collections on first open. Existing data is never touched.
            # Tables/indexes are created by executescript(SCHEMA_SQL) via IF NOT EXISTS.
            logger.info("Applied v6 migrations (collections + collection_items tables).")

        if current < 7:
            # v6 -> v7 (Issue 34 Critical Fix): persistent auto-delete table.
            # pending_deletions stores every scheduled message deletion so the
            # bot can recover them after restart/crash. Table + index are
            # created by executescript(SCHEMA_SQL) via IF NOT EXISTS.
            logger.info("Applied v7 migrations (pending_deletions table for persistent auto-delete).")

        if current < 8:
            # v7 -> v8 (Issue #47): Force Join system overhaul.
            # Adds persistent invite link columns + customizable text/buttons + media support.
            await self._add_column_if_missing("force_join_channels", "invite_link", "TEXT")
            await self._add_column_if_missing("force_join_channels", "invite_link_created_at", "TEXT")
            await self._add_column_if_missing("force_join_channels", "invite_last_verified", "TEXT")
            await self._add_column_if_missing("force_join_channels", "join_text", "TEXT")
            await self._add_column_if_missing("force_join_channels", "verify_button_text", "TEXT")
            await self._add_column_if_missing("force_join_channels", "channel_button_text", "TEXT")
            await self._add_column_if_missing("force_join_channels", "media_file_id", "TEXT")
            await self._add_column_if_missing("force_join_channels", "media_type", "TEXT")
            logger.info("Applied v8 migrations (force_join_channels: invite links, custom text, media).")

        if current < 9:
            # v8 -> v9 (Issues #49-#59): Retrieve system + Branding + Broadcast fix.
            # New tables: delivery_records, collection_branding, source_branding.
            # All created by executescript(SCHEMA_SQL) via IF NOT EXISTS.
            # Also add retrieve settings to bot_settings (seeded in post_init).
            logger.info("Applied v9 migrations (delivery_records, collection_branding, source_branding tables).")

        if current < 10:
            # v9 -> v10 (Issues #49-#62 production hardening):
            # - Retrieve modes (Issue #50) now actually enforced: new delivery
            #   records read retrieve_limit / retrieve_window_hours from settings.
            # - Global Branding admin panel (Issue #54) + Collection Branding UI
            #   (Issue #57) + Source Post Branding toggle (Issue #58).
            # - Retrieve analytics (Issue #55): most-retrieved payloads/collections.
            # CRITICAL FIX: re-run the recovery_message_id column add here (not in
            # the v9 block). Production DBs that reached schema_meta=9 via an
            # earlier v9 build are missing this column because the column-add was
            # a late addition to the v9 block and `if current < 9` is False for
            # them. Running it in v10 (current < 10) guarantees it is added.
            # _add_column_if_missing is idempotent, so DBs that already have it
            # are untouched. This fixes the startup/runtime crash:
            #   sqlite3.OperationalError: no such column: recovery_message_id
            await self._add_column_if_missing("delivery_records", "recovery_message_id", "INTEGER")
            logger.info("Applied v10 migrations (recovery_message_id column + retrieve enforcement + branding UI + analytics).")

        if current < 11:
            # v10 -> v11 (Issue #84): Reply-based retrieve system.
            # - Branding UI removed (Global Branding panel, Collection Branding
            #   panel, source_branding toggle all deleted from admin UI).
            # - Branding DB tables (collection_branding, source_branding) KEPT
            #   for migration compat — resolve_branding() is now a no-op stub.
            # - New retrieve message text/button settings seeded in post_init
            #   (retrieve_message_text / retrieve_message_button).
            # No structural schema changes — all new state in bot_settings.
            logger.info("Applied v11 migrations (reply-based retrieve system; branding UI removed).")

        if current < 12:
            # v11 -> v12 (Issues #85-#93 production hardening):
            # - Reindex probe now falls back to forward_message (Issue #85).
            # - Force-join keyboard only shows unjoined channels (Issue #93).
            # - Force-join media sends route through protected wrapper (Issue #88).
            # - Retrieve edit failures logged + standalone fallback (Issues #89/#90).
            # - Preview button uses preview_retrieve (no-op) not retrieve:0 (#92).
            # - Dead branding settings cleaned from bot_settings (Issue #91).
            # No structural schema changes. Clean up obsolete branding keys so
            # they don't linger in bot_settings forever (harmless but untidy).
            try:
                for dead_key in ("branding_enabled", "branding_text",
                                 "branding_media_file_id", "branding_media_type",
                                 "source_branding_enabled"):
                    await self.conn.execute(
                        "DELETE FROM bot_settings WHERE key = ?", (dead_key,)
                    )
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.debug("v12 branding cleanup: %s", e)
            logger.info("Applied v12 migrations (reindex probe fix + force-join filter + protection + retrieve hardening + branding cleanup).")

        if current < 13:
            # v12 -> v13 (Issue #94): Payload Referral Gate System.
            # New tables: referral_campaigns, referral_tokens, referral_history,
            # payload_unlocks. All created by executescript(SCHEMA_SQL) via IF NOT EXISTS.
            # Existing payloads are UNAFFECTED — gate is OFF by default. No
            # existing data is touched.
            logger.info("Applied v13 migrations (referral gate system tables).")

        if current < 14:
            # v13 -> v14 (Access Engine V1): Centralized authorization layer.
            # This migration is NON-DESTRUCTIVE and fully backward compatible:
            #
            # 1. payloads.access_policy column added (default FORCE_JOIN).
            #    Existing payloads behaved exactly like FORCE_JOIN before (force
            #    join was the only gate), so this preserves 100% of existing
            #    behaviour. No existing payload link changes.
            #
            # 2. Existing referral campaigns (from v13) get their payload's
            #    access_policy upgraded to FORCE_JOIN_REFERRAL so the Access
            #    Engine continues to enforce referral unlocking for them. The
            #    campaign row itself is untouched.
            #
            # 3. referral_campaigns.preview_mode value 'first_file' (which leaked
            #    the protected file) is migrated to 'disabled'. The protected
            #    payload file is NEVER used as preview under the Access Engine.
            #
            # 4. referral_campaigns gains preview_media_file_id / preview_media_type
            #    / preview_description columns (admin-supplied preview only).
            #
            # 5. referral_history is REBUILT without ON DELETE CASCADE so that
            #    history can NEVER be erased by a campaign deletion. Data is
            #    preserved 1:1. This is a standard SQLite table rebuild
            #    (create new -> copy -> drop old -> rename).
            #
            # 6. access_events analytics table created (IF NOT EXISTS in schema).
            await self._add_column_if_missing("payloads", "access_policy",
                                               "TEXT DEFAULT 'FORCE_JOIN'")
            await self._add_column_if_missing("referral_campaigns",
                                               "preview_media_file_id", "TEXT")
            await self._add_column_if_missing("referral_campaigns",
                                               "preview_media_type", "TEXT")
            await self._add_column_if_missing("referral_campaigns",
                                               "preview_description", "TEXT")

            # Backfill: payloads that already had an enabled referral campaign
            # become FORCE_JOIN_REFERRAL (preserves their v13 referral behaviour).
            # All other payloads stay FORCE_JOIN (their existing behaviour).
            await self.conn.execute(
                """UPDATE payloads SET access_policy = ?
                   WHERE access_policy IS NULL
                      OR access_policy = 'FORCE_JOIN'""",
                (ACCESS_POLICY_FORCE_JOIN,),
            )
            await self.conn.execute(
                """UPDATE payloads SET access_policy = ?
                   WHERE id IN (SELECT payload_id FROM referral_campaigns
                                WHERE enabled = 1)""",
                (ACCESS_POLICY_FORCE_JOIN_REFERRAL,),
            )

            # Migrate the leaky 'first_file' preview mode -> 'disabled'.
            await self.conn.execute(
                """UPDATE referral_campaigns SET preview_mode = ?
                   WHERE preview_mode = 'first_file' OR preview_mode IS NULL""",
                (PREVIEW_MODE_DISABLED,),
            )

            # Rebuild referral_history WITHOUT ON DELETE CASCADE.
            # SQLite cannot ALTER a FK; we rebuild the table. History rows are
            # copied 1:1. If the table does not yet exist (fresh-ish DB), this
            # is a no-op guard.
            try:
                cur = await self.conn.execute(
                    "SELECT sql FROM sqlite_master WHERE type='table' AND name='referral_history'"
                )
                rh_row = await cur.fetchone()
                if rh_row and "ON DELETE CASCADE" in (rh_row["sql"] or ""):
                    await self.conn.executescript("""
                        CREATE TABLE IF NOT EXISTS referral_history_new (
                            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                            campaign_id         INTEGER NOT NULL,
                            inviter_user_id     INTEGER NOT NULL,
                            referred_user_id    INTEGER NOT NULL,
                            qualified           INTEGER DEFAULT 0,
                            qualified_at        TEXT,
                            created_at          TEXT NOT NULL,
                            UNIQUE(campaign_id, inviter_user_id, referred_user_id)
                        );
                        INSERT OR IGNORE INTO referral_history_new
                            (id, campaign_id, inviter_user_id, referred_user_id,
                             qualified, qualified_at, created_at)
                            SELECT id, campaign_id, inviter_user_id, referred_user_id,
                                   qualified, qualified_at, created_at
                            FROM referral_history;
                        DROP TABLE referral_history;
                        ALTER TABLE referral_history_new RENAME TO referral_history;
                        CREATE INDEX IF NOT EXISTS idx_refhist_campaign ON referral_history(campaign_id);
                        CREATE INDEX IF NOT EXISTS idx_refhist_inviter ON referral_history(inviter_user_id);
                        CREATE INDEX IF NOT EXISTS idx_refhist_referred ON referral_history(referred_user_id);
                    """)
                    logger.info("v14: rebuilt referral_history (removed ON DELETE CASCADE; history preserved).")
            except Exception as e:  # noqa: BLE001
                logger.warning("v14 referral_history rebuild skipped: %s", e)

            await self.conn.commit()
            logger.info("Applied v14 migrations (Access Engine V1: access_policy + preview media + history rebuild + analytics).")

        if current < 15:
            # v14 -> v15 (BOTV7.1): Referral Dashboard Customization.
            # New table: dashboard_settings (global + per-campaign overrides).
            # Created by executescript(SCHEMA_SQL) via IF NOT EXISTS.
            # Non-destructive: no existing data is touched.
            logger.info("Applied v15 migrations (Referral Dashboard Customization: dashboard_settings table).")

        if current < 16:
            # v15 -> v16 (BOTV7.1): Dashboard state tracking + preview auto-delete.
            # Adds dashboard_msg_id, dashboard_chat_id columns to payload_unlocks
            # so the dashboard can be edited in-place (single persistent message).
            # Adds preview_auto_delete setting to bot_settings.
            await self._add_column_if_missing("payload_unlocks", "dashboard_msg_id", "INTEGER")
            await self._add_column_if_missing("payload_unlocks", "dashboard_chat_id", "INTEGER")
            logger.info("Applied v16 migrations (Dashboard state tracking: payload_unlocks.dashboard_msg_id/dashboard_chat_id).")

        if current < 17:
            # v16 -> v17 (V9): Dashboard mode tracking.
            # Adds dashboard_mode column ('TEXT' | 'CAPTION') to payload_unlocks so
            # the Dashboard Controller knows whether to call editMessageText or
            # editMessageCaption. Prevents "There is no text in the message to edit"
            # when the dashboard was sent as a media caption.
            # Existing rows default to 'TEXT' (the historical behaviour).
            await self._add_column_if_missing("payload_unlocks", "dashboard_mode", "TEXT")
            # Backfill existing rows: any saved dashboard without a mode is TEXT.
            await self.conn.execute(
                "UPDATE payload_unlocks SET dashboard_mode = 'TEXT' "
                "WHERE dashboard_mode IS NULL AND dashboard_msg_id IS NOT NULL"
            )
            logger.info("Applied v17 migrations (Dashboard mode tracking: payload_unlocks.dashboard_mode).")

        if current < 18:
            # v17 -> v18 (BOTV13): Separate routing slug from display name.
            # Adds `display_name TEXT` column to payloads. The `payload` column
            # becomes the IMMUTABLE routing slug (start links, lookups, referral
            # tokens, collection c<code> routing). `display_name` is the editable
            # human-readable title shown in the Payload Manager, Referral Dashboard,
            # Unlock Dashboard, and Analytics. Changing display_name NEVER changes
            # routing. Existing rows are backfilled from the slug so they display
            # exactly as before (the Title-Casing resolver still applies).
            await self._add_column_if_missing("payloads", "display_name", "TEXT")
            await self.conn.execute(
                "UPDATE payloads SET display_name = payload WHERE display_name IS NULL"
            )
            await self.conn.commit()
            logger.info("Applied v18 migrations (Routing/display split: payloads.display_name).")

        if current < 19:
            # v18 -> v19 (BOTV13 Part 2): Smart post-unlock referral notifications.
            # Adds `last_thank_you_sent TEXT` to payload_unlocks so the bot can
            # rate-limit appreciation notifications to at most one per 24 hours
            # per campaign+inviter. After unlock, progress notifications stop
            # (completed_referrals is capped at required_referrals), but analytics
            # continue recording. This column tracks the last appreciation send.
            await self._add_column_if_missing("payload_unlocks", "last_thank_you_sent", "TEXT")
            logger.info("Applied v19 migrations (Smart post-unlock: payload_unlocks.last_thank_you_sent).")

        if current < 20:
            # v19 -> v20 (BOTV13 Phase 2): Multi-admin system + activity log.
            # Creates `admins` and `admin_activity` tables (IF NOT EXISTS, so
            # safe to re-run). Seeds the owner from the first ADMIN_IDS env
            # entry. Existing admin access is preserved (the env-based
            # ADMIN_IDS list still works as a fallback).
            # The tables are created by executescript(SCHEMA_SQL) above, but
            # we seed the owner row here.
            owner_id = ADMIN_IDS[0] if ADMIN_IDS else 0
            if owner_id:
                now_iso = _now_iso()
                await self.conn.execute(
                    """INSERT OR IGNORE INTO admins
                       (user_id, permissions, is_owner, is_active, added_by, created_at, updated_at)
                       VALUES (?, '{}', 1, 1, ?, ?, ?)""",
                    (owner_id, owner_id, now_iso, now_iso),
                )
                await self.conn.commit()
            logger.info("Applied v20 migrations (Multi-admin: admins + admin_activity tables, owner seeded).")

        if current < 21:
            # v20 -> v21 (BOTV13 Phase 4): Per-payload forward blocking.
            # Adds `forward_blocking INTEGER` to payloads. NULL = inherit global,
            # 1 = explicitly ON, 0 = explicitly OFF. Three-state semantics so
            # payloads using NULL automatically follow the global setting when it
            # changes. Existing payloads default to NULL (inherit global) so
            # their behavior is unchanged unless the admin explicitly changes it.
            await self._add_column_if_missing("payloads", "forward_blocking", "INTEGER")
            logger.info("Applied v21 migrations (Per-payload forward_blocking: payloads.forward_blocking).")

        if current < 22:
            # v21 -> v22 (BOTV13 Phase 5): Telegram entity preservation.
            # Adds `entities TEXT` (JSON) to start_message (SINGULAR — the
            # existing table) so text_link, bold, italic, code, etc. survive
            # EDIT → SAVE → PREVIEW cycles.
            # Also adds `join_text_entities TEXT` to force_join_channels for FJ text.
            # NULL = no entities (backward compat — old messages work as before).
            await self._add_column_if_missing("start_message", "entities", "TEXT")
            await self._add_column_if_missing("force_join_channels", "join_text_entities", "TEXT")
            logger.info("Applied v22 migrations (Entity preservation: start_message.entities, force_join_channels.join_text_entities).")

        if current < 23:
            # v22 -> v23 (BOTV13 Phase A): STABLE ACTIVE BATCH for Force Join.
            # Adds columns to fj_progress so the current batch is PERSISTED
            # and never recalculated from the unjoined set (the prior bug):
            #   - active_batch         TEXT  (JSON [chan_id, ...])
            #   - completed_batches    TEXT  (JSON [[chan_id,...], ...])
            #   - batch_cursor         INTEGER (next un-batched index)
            #   - unlocked_payload_ids  TEXT  (JSON [pid, ...]) payloads whose
            #       FJ batch completed — re-access does NOT require future batches.
            # NON-DESTRUCTIVE: ALTER TABLE ADD COLUMN. Existing rows keep NULL/0
            # defaults and are lazily backfilled by _get_or_init_fj_progress on
            # the user's next visit. No data is lost; no table is dropped.
            # The (user_id, payload_code) UNIQUE constraint is preserved.
            await self._add_column_if_missing("fj_progress", "active_batch", "TEXT")
            await self._add_column_if_missing("fj_progress", "completed_batches", "TEXT DEFAULT '[]'")
            await self._add_column_if_missing("fj_progress", "batch_cursor", "INTEGER DEFAULT 0")
            await self._add_column_if_missing("fj_progress", "unlocked_payload_ids", "TEXT DEFAULT '[]'")
            # Idempotent backfill: any row with NULL defaults gets safe values
            # so JSON parsing never fails. Safe to re-run.
            try:
                await self.conn.execute(
                    "UPDATE fj_progress SET completed_batches = '[]' "
                    "WHERE completed_batches IS NULL"
                )
                await self.conn.execute(
                    "UPDATE fj_progress SET batch_cursor = 0 "
                    "WHERE batch_cursor IS NULL"
                )
                await self.conn.execute(
                    "UPDATE fj_progress SET unlocked_payload_ids = '[]' "
                    "WHERE unlocked_payload_ids IS NULL"
                )
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.debug("v23 backfill: %s", e)
            logger.info("Applied v23 migrations (FJ STABLE ACTIVE BATCH: fj_progress.active_batch/completed_batches/batch_cursor/unlocked_payload_ids).")

        if current < 24:
            # v23 -> v24 (BOT6 Phase 4): canonical FJ dashboard table. The
            # CREATE IF NOT EXISTS in SCHEMA_SQL already covers fresh DBs; the
            # migration marker keeps versioned upgrades on the same path.
            try:
                await self.conn.execute(
                    "CREATE TABLE IF NOT EXISTS fj_dashboards ("
                    "admin_chat_id INTEGER PRIMARY KEY, "
                    "dashboard_message_id INTEGER NOT NULL, "
                    "updated_at TEXT NOT NULL)"
                )
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.debug("v24 fj_dashboards ensure: %s", e)
            logger.info("Applied v24 migrations (canonical FJ dashboard table).")

        if current < 25:
            # v24 -> v25 (WATCH_AD): payload-level Watch Ads requirement.
            #   1. payloads.watch_ads_enabled INTEGER NOT NULL DEFAULT 0 —
            #      NON-DESTRUCTIVE: every existing payload stays OFF.
            #   2. watch_ad_sessions table — secure, replay-protected ad
            #      sessions hard-bound to (user_id, payload_id).
            # Global config keys reuse the EXISTING bot_settings table:
            #   watch_ads_mini_app_url / watch_ads_monetag_sdk /
            #   watch_ads_unlock_window (seeded later in post_init).
            # Idempotent + transactional: ALTER ADD COLUMN + CREATE IF NOT
            # EXISTS are safe to re-run; backfill normalizes NULLs to 0.
            await self._add_column_if_missing(
                "payloads", "watch_ads_enabled", "INTEGER NOT NULL DEFAULT 0")
            try:
                await self.conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS watch_ad_sessions (
                        id                INTEGER PRIMARY KEY AUTOINCREMENT,
                        token             TEXT UNIQUE NOT NULL,
                        user_id           INTEGER NOT NULL,
                        payload_id        INTEGER NOT NULL,
                        status            TEXT NOT NULL DEFAULT 'pending',
                        provider          TEXT DEFAULT 'monetag',
                        ymid              TEXT,
                        zone_id           TEXT,
                        sub_zone_id       TEXT,
                        request_var       TEXT,
                        estimated_price   REAL,
                        reward_count      INTEGER NOT NULL DEFAULT 0,
                        created_at        TEXT NOT NULL,
                        rewarded_at       TEXT,
                        expires_at        TEXT,
                        unlock_expires_at TEXT,
                        consumed_at       TEXT
                    )
                    """
                )
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_wad_sessions_token "
                    "ON watch_ad_sessions(token)")
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_wad_sessions_user_payload "
                    "ON watch_ad_sessions(user_id, payload_id)")
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_wad_sessions_status "
                    "ON watch_ad_sessions(status)")
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_wad_sessions_created "
                    "ON watch_ad_sessions(created_at)")
                # Idempotent backfill: normalize NULL -> 0 for legacy rows.
                await self.conn.execute(
                    "UPDATE payloads SET watch_ads_enabled = 0 "
                    "WHERE watch_ads_enabled IS NULL")
                # Seed the global unlock-window default (absent only on
                # pre-v25 databases; idempotent — never overwrites).
                cur_w = await self.conn.execute(
                    "SELECT value FROM bot_settings WHERE key = 'watch_ads_unlock_window'")
                if not await cur_w.fetchone():
                    await self.conn.execute(
                        "INSERT OR IGNORE INTO bot_settings (key, value) "
                        "VALUES ('watch_ads_unlock_window', ?)",
                        (str(WATCH_AD_UNLOCK_WINDOW),))
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.debug("v25 watch_ad_sessions ensure: %s", e)
            logger.info(
                "Applied v25 migrations (WATCH_AD: payloads.watch_ads_enabled "
                "DEFAULT 0 + watch_ad_sessions table). Existing payloads stay "
                "Watch Ads OFF."
            )

        if current < 26:
            # v25 -> v26 (WATCH_AD V2 — Ads Control / multi-ad / OR semantics):
            #   1. watch_ad_sessions gains (ad_control_mode, required_ads,
            #      completed_ads, last_reward_at) — NON-DESTRUCTIVE ALTER ADD
            #      COLUMN with defaults. Existing sessions are fully preserved:
            #      a legacy pending session backfills to required_ads=1 /
            #      completed_ads=0, which behaves EXACTLY like v25 (one
            #      verified reward unlocks); a legacy rewarded session stays
            #      rewarded (its unlock window is unchanged).
            #   2. watch_ad_reward_events — per-ymid idempotency ledger so
            #      duplicate/retried Monetag postbacks can never double-count
            #      a multi-ad reward (PK on ymid; transactional insert).
            #   3. bot_settings: seed 'watch_ads_ad_control' = 'short' ONLY
            #      when absent (INSERT OR IGNORE — the DB value is
            #      authoritative and is never overwritten, not by this
            #      migration and not by any environment variable).
            # All statements are idempotent (ADD COLUMN IF-style guard +
            # CREATE IF NOT EXISTS + OR IGNORE) and run on the existing
            # production database without touching any other table.
            for _col, _typ in (
                ("ad_control_mode", "TEXT NOT NULL DEFAULT 'short'"),
                ("required_ads", "INTEGER NOT NULL DEFAULT 1"),
                ("completed_ads", "INTEGER NOT NULL DEFAULT 0"),
                ("last_reward_at", "TEXT"),
            ):
                await self._add_column_if_missing("watch_ad_sessions", _col, _typ)
            try:
                await self.conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS watch_ad_reward_events (
                        ymid             TEXT PRIMARY KEY,
                        session_id       INTEGER NOT NULL,
                        user_id          INTEGER NOT NULL,
                        payload_id       INTEGER NOT NULL,
                        ad_index         INTEGER,
                        event_type       TEXT,
                        estimated_price  REAL,
                        created_at       TEXT NOT NULL
                    )
                    """
                )
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_wad_reward_events_session "
                    "ON watch_ad_reward_events(session_id)")
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_wad_reward_events_user_payload "
                    "ON watch_ad_reward_events(user_id, payload_id)")
                # Idempotent backfills: normalize legacy NULLs to safe values.
                await self.conn.execute(
                    "UPDATE watch_ad_sessions SET ad_control_mode = 'short' "
                    "WHERE ad_control_mode IS NULL")
                await self.conn.execute(
                    "UPDATE watch_ad_sessions SET required_ads = 1 "
                    "WHERE required_ads IS NULL OR required_ads < 1")
                await self.conn.execute(
                    "UPDATE watch_ad_sessions SET completed_ads = 0 "
                    "WHERE completed_ads IS NULL OR completed_ads < 0")
                # Seed the Ads Control default ONLY when absent (never
                # overwrites an admin-saved mode).
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES ('watch_ads_ad_control', ?)",
                    (WATCH_AD_AD_CONTROL_DEFAULT,))
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.debug("v26 watch ads ads-control ensure: %s", e)
            logger.info(
                "Applied v26 migrations (WATCH_AD V2: ads-control columns on "
                "watch_ad_sessions + watch_ad_reward_events ledger + "
                "watch_ads_ad_control setting seed). Existing sessions keep "
                "their state; a legacy pending session still unlocks after ONE "
                "verified reward."
            )

        if current < 27:
            # v26 -> v27 (WATCH_AD V4 — Global Watch Ads admin controls).
            #   1. payloads.watch_ads_ad_mode_override TEXT — per-payload
            #      override of the default ad mode (NULL = follow global).
            #      NON-DESTRUCTIVE: NULL for every existing payload, so all
            #      payloads keep following the global default exactly as
            #      before (the user's "Payload B: Override = global" case).
            #   2. watch_ad_postback_log — postback monitoring log (admin
            #      Status/Monitoring panel). Tokens are stored as PREFIXES
            #      only.
            #   3. Settings seeds (INSERT OR IGNORE — never overwrite admin
            #      values): watch_ads_global_enabled='1' (ON by default =
            #      exact pre-v27 behavior), watch_ads_session_ttl (default =
            #      the WATCH_AD_SESSION_TTL env value).
            try:
                await self._add_column_if_missing(
                    "payloads", "watch_ads_ad_mode_override", "TEXT")
                await self.conn.execute(
                    """CREATE TABLE IF NOT EXISTS watch_ad_postback_log (
                        id                INTEGER PRIMARY KEY AUTOINCREMENT,
                        created_at        TEXT NOT NULL,
                        ymid_prefix       TEXT,
                        user_id           INTEGER,
                        payload_id        INTEGER,
                        ad_index          INTEGER,
                        event_type        TEXT,
                        reward_event_type TEXT,
                        result            TEXT NOT NULL,
                        http_status       INTEGER
                    )""")
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_wad_postback_log_created "
                    "ON watch_ad_postback_log(created_at)")
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_wad_postback_log_result "
                    "ON watch_ad_postback_log(result)")
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES (?, '1')", (WATCH_ADS_GLOBAL_ENABLED_KEY,))
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES (?, ?)",
                    (WATCH_ADS_SESSION_TTL_KEY, str(max(1, WATCH_AD_SESSION_TTL))))
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.error("v27 watch ads global-controls migration failed: %s", e)
            logger.info(
                "Applied v27 migrations (WATCH_AD V4: payloads."
                "watch_ads_ad_mode_override + watch_ad_postback_log + "
                "global enabled/session TTL setting seeds). Global ON by "
                "default — every existing payload keeps its exact behavior "
                "and follows the global default ad mode."
            )

        if current < 28:
            # v27 -> v28 (PHASE 8 — Index verification + Force-Join link health).
            #   1. indexed_files.source_status / source_verified_at —
            #      reconciliation state. NULL = legacy row = available (exact
            #      pre-v28 behavior for every existing row and every query).
            #   2. force_join_channels link-health columns (link_type,
            #      link_health, link_health_updated_at, link_last_error,
            #      link_expires_at, link_validation_status).
            #   3. Indexes for the new access patterns (source_status filter,
            #      link_health filter).
            #   4. Setting seeds (INSERT OR IGNORE — never overwrite admin
            #      values): fj_link_auto_rotate (ON by default — matches the
            #      existing auto-recreate behavior on confirmed-dead links,
            #      now transactional), fj_link_health_cache_ttl (300s).
            # NON-DESTRUCTIVE: ADD COLUMN only where the column is missing;
            # CREATE INDEX IF NOT EXISTS; no table is ever dropped/renamed and
            # no existing row is modified. Restart-safe and idempotent.
            try:
                await self._add_column_if_missing(
                    "indexed_files", "source_status", "TEXT")
                await self._add_column_if_missing(
                    "indexed_files", "source_verified_at", "TEXT")
                await self._add_column_if_missing(
                    "force_join_channels", "link_type", "TEXT")
                await self._add_column_if_missing(
                    "force_join_channels", "link_health", "TEXT")
                await self._add_column_if_missing(
                    "force_join_channels", "link_health_updated_at", "TEXT")
                await self._add_column_if_missing(
                    "force_join_channels", "link_last_error", "TEXT")
                await self._add_column_if_missing(
                    "force_join_channels", "link_expires_at", "TEXT")
                await self._add_column_if_missing(
                    "force_join_channels", "link_validation_status", "TEXT")
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_indexed_files_source_status "
                    "ON indexed_files(source_status)")
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_fjc_link_health "
                    "ON force_join_channels(link_health)")
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES ('fj_link_auto_rotate', '1')")
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES ('fj_link_health_cache_ttl', '300')")
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.error("v28 index-verification/link-health migration failed: %s", e)
            logger.info(
                "Applied v28 migrations (indexed_files.source_status/"
                "source_verified_at + force_join_channels link-health columns "
                "+ verification indexes + FJ auto-rotate/cache setting seeds). "
                "All existing rows keep NULL = legacy-available semantics.")

        if current < 29:
            # v28 -> v29 (NETWORK PLATFORM — additive multi-bot expansion).
            #   All 10 new tables (network_bots, network_bot_credentials,
            #   user_bot_memberships, points_ledger, point_unlocks,
            #   global_payload_links, network_routing_events, broadcasts,
            #   broadcast_bot_jobs, broadcast_deliveries) + indexes are
            #   created by executescript(SCHEMA_SQL) above via
            #   CREATE ... IF NOT EXISTS — identical on fresh and existing
            #   databases. NO existing table/column/row is touched.
            #   Setting seeds (INSERT OR IGNORE — never overwrite admin
            #   values): network_enabled, max_registered_bots_per_user=5,
            #   points_per_bot_registration=5, max_registration_reward=25
            #   (derived default), points_access_enabled, payload_point_cost=1,
            #   network_health_check_interval=300,
            #   network_broadcast_rate_per_bot=25,
            #   network_broadcast_confirm_threshold=1000.
            # NON-DESTRUCTIVE + IDEMPOTENT: safe to run twice; safe on a
            # live Phase 8 database (spec §81).
            try:
                seeds = [
                    (NET_SETTING_ENABLED, "1"),
                    (NET_SETTING_MAX_BOTS, str(NET_DEFAULT_MAX_BOTS)),
                    (NET_SETTING_POINTS_PER_BOT, str(NET_DEFAULT_POINTS_PER_BOT)),
                    (NET_SETTING_MAX_REWARD, str(
                        NET_DEFAULT_MAX_BOTS * NET_DEFAULT_POINTS_PER_BOT)),
                    (NET_SETTING_POINTS_ACCESS, "1"),
                    (NET_SETTING_POINT_COST, str(NET_DEFAULT_POINT_COST)),
                    (NET_SETTING_HEALTH_INTERVAL, "300"),
                    (NET_SETTING_BCAST_RATE, "25"),
                    (NET_SETTING_BCAST_CONFIRM, "1000"),
                ]
                for k, v in seeds:
                    await self.conn.execute(
                        "INSERT OR IGNORE INTO bot_settings (key, value) "
                        "VALUES (?, ?)", (k, v))
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.error("v29 network-platform migration failed: %s", e)
            logger.info(
                "Applied v29 migrations (NETWORK PLATFORM: 10 additive "
                "tables for bot registry / credentials / memberships / "
                "points ledger / point unlocks / global payload links / "
                "routing events / network broadcasts + configurable "
                "setting seeds). Existing rows and behavior unchanged.")

        if current < 30:
            # v29 -> v30 (WEBSITE PHASE 2 — Part A: richer indexed media
            # metadata for the Payload Website / Mini App / player).
            #   indexed_files gains five NULLABLE columns:
            #     mime_type              — Telegram-reported content type
            #     width / height         — intrinsic media dimensions
            #     thumb_file_id          — thumbnail Bot API reference
            #     thumb_file_unique_id   — thumbnail cross-bot identity
            #   (the thumbnail's own identity follows the SAME discipline as
            #   the media itself: file_unique_id = identity/dedup ONLY,
            #   file_id = the bot-scoped transport reference).
            # NON-DESTRUCTIVE + IDEMPOTENT + RESTART-SAFE: _add_column_if_missing
            # re-verifies on every start; NO existing table, column, row or
            # payload reference is touched; legacy rows keep NULL metadata
            # (never fabricated — only a re-index of the live source message
            # backfills real values). Fresh databases receive the columns
            # from SCHEMA_SQL; existing v29 databases receive them here —
            # the documented v27->v28->v29 pattern.
            await self._add_column_if_missing("indexed_files", "mime_type", "TEXT")
            await self._add_column_if_missing("indexed_files", "width", "INTEGER")
            await self._add_column_if_missing("indexed_files", "height", "INTEGER")
            await self._add_column_if_missing("indexed_files", "thumb_file_id", "TEXT")
            await self._add_column_if_missing(
                "indexed_files", "thumb_file_unique_id", "TEXT")
            logger.info(
                "Applied v30 migrations (WEBSITE PHASE 2 part A: indexed_files "
                "mime_type/width/height/thumb_file_id/thumb_file_unique_id — "
                "additive, nullable, non-destructive; legacy rows stay NULL).")

        if current < 31:
            # v30 -> v31 (WEBSITE PHASE 3 — the planned "v30 part B": the
            # Website Payload presentation platform). A SEPARATE block so a
            # database already stamped at 30 re-enters migration and receives
            # the new presentation table + setting seed (restart-safe).
            #   website_payloads: ONE listing row per Website card, referencing
            #     the CANONICAL Payload system (payloads.id for single-file
            #     Payloads, collections.collection_id for multi-file Payloads)
            #     — NEVER a copy of media. No FK by design: Website listings
            #     are presentation state; canonical/Telegram state is never
            #     blocked or cascaded by them, and deleting a listing never
            #     touches the canonical system.
            #   bot_settings seeds: website_enabled ('false' — the Website is
            #     OFF until the admin explicitly enables it: opt-in, honest
            #     default) + website_public_base_url ('' → relative links).
            # ADDITIVE / IDEMPOTENT / RESTART-SAFE / NON-DESTRUCTIVE: CREATE
            # IF NOT EXISTS + INSERT OR IGNORE only; no existing table,
            # column, row, Telegram flow or payload reference is touched.
            try:
                await self.conn.executescript(SCHEMA_SQL)
            except Exception as e:  # noqa: BLE001
                logger.error("v31 website-payload migration failed: %s", e)
            try:
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES ('website_enabled', 'false')")
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES ('website_public_base_url', '')")
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.error("v31 website setting seeds failed: %s", e)
            logger.info(
                "Applied v31 migrations (WEBSITE PHASE 3: website_payloads "
                "presentation table + website_enabled/website_public_base_url "
                "setting seeds — additive, idempotent, non-destructive; "
                "Website starts OFF until the admin enables it).")

        if current < 32:
            # v31 -> v32 (WEBSITE PHASE 4 — Media Gateway settings). A
            # SEPARATE block so a database already stamped at 31 re-enters
            # migration and receives the streaming/cache seeds
            # (restart-safe). SETTINGS-ONLY: no table, no column, no row of
            # the canonical/Telegram system is touched — the streaming
            # cache lives on the FILESYSTEM (MEDIA_CACHE_ROOT / the
            # database directory's media_cache/), never in the schema.
            #   website_stream_enabled — the Phase 4 streaming toggle
            #     (independent of website_enabled: the GLOBAL Website
            #     ON/OFF gate is ALWAYS checked first in the presentation
            #     handlers; Telegram is never gated by either flag).
            #   website_cache_enabled / website_cache_max_bytes /
            #     website_cache_ttl_seconds — the shared bounded cache.
            #   website_stream_token_ttl — short-lived stream tokens
            #     (seconds; hard-clamped to [30, 3600] at use sites).
            #   website_max_concurrent_streams — gateway concurrency cap.
            # INSERT OR IGNORE only: an admin who already tuned a value
            # keeps it (never overwritten — the documented seed pattern).
            try:
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES ('website_stream_enabled', 'true')")
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES ('website_cache_enabled', 'true')")
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES ('website_cache_max_bytes', '2147483648')")
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES ('website_cache_ttl_seconds', '3600')")
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES ('website_stream_token_ttl', '300')")
                await self.conn.execute(
                    "INSERT OR IGNORE INTO bot_settings (key, value) "
                    "VALUES ('website_max_concurrent_streams', '32')")
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.error("v32 website stream settings seeds failed: %s", e)
            logger.info(
                "Applied v32 migrations (WEBSITE PHASE 4: streaming/cache "
                "setting seeds — settings-only, additive, idempotent; no "
                "schema DDL, no Telegram-side behavior touched).")

        if current < 33:
            # v32 -> v33 (GAP-CLOSURE: Website CATEGORY SYSTEM spec §26-§29
            # + the centralized ADS PLATFORM spec §35-§56 + download-pack
            # settings). ADDITIVE ONLY: new tables + setting seeds; no
            # existing table/column is altered; the canonical Payload /
            # Collection / indexed media system is untouched. Idempotent
            # (CREATE TABLE IF NOT EXISTS + INSERT OR IGNORE) so a database
            # already stamped 33 that somehow lost a seed re-receives it.
            try:
                now = _now_iso()
                # --- category system tables ---------------------------------
                await self.conn.execute(
                    """CREATE TABLE IF NOT EXISTS website_categories (
                        id             INTEGER PRIMARY KEY AUTOINCREMENT,
                        name           TEXT NOT NULL,
                        slug           TEXT UNIQUE NOT NULL,
                        icon           TEXT DEFAULT '',
                        sort_order     INTEGER NOT NULL DEFAULT 0,
                        enabled        INTEGER NOT NULL DEFAULT 1,
                        visible        INTEGER NOT NULL DEFAULT 1,
                        description    TEXT DEFAULT '',
                        age_restricted INTEGER NOT NULL DEFAULT 0,
                        created_at     TEXT NOT NULL,
                        updated_at     TEXT NOT NULL)""")
                await self.conn.execute(
                    """CREATE TABLE IF NOT EXISTS website_payload_categories (
                        listing_id  INTEGER NOT NULL,
                        category_id INTEGER NOT NULL,
                        position    INTEGER NOT NULL DEFAULT 0,
                        created_at  TEXT NOT NULL,
                        PRIMARY KEY (listing_id, category_id))""")
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_wpc_cat ON "
                    "website_payload_categories(category_id, position)")
                # --- ads platform tables ------------------------------------
                await self.conn.execute(
                    """CREATE TABLE IF NOT EXISTS ad_campaigns (
                        id                      INTEGER PRIMARY KEY AUTOINCREMENT,
                        name                    TEXT NOT NULL,
                        status                  TEXT NOT NULL DEFAULT 'draft',
                        priority                INTEGER NOT NULL DEFAULT 0,
                        start_at                TEXT,
                        end_at                  TEXT,
                        frequency_cap_per_user  INTEGER NOT NULL DEFAULT 0,
                        frequency_cap_hours     INTEGER NOT NULL DEFAULT 24,
                        placements              TEXT,
                        categories              TEXT,
                        devices                 TEXT,
                        enabled                 INTEGER NOT NULL DEFAULT 1,
                        created_at              TEXT NOT NULL,
                        updated_at              TEXT NOT NULL)""")
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_ad_campaigns_status ON "
                    "ad_campaigns(status, enabled, priority)")
                await self.conn.execute(
                    """CREATE TABLE IF NOT EXISTS ad_creatives (
                        id                INTEGER PRIMARY KEY AUTOINCREMENT,
                        campaign_id       INTEGER NOT NULL,
                        kind              TEXT NOT NULL,
                        title             TEXT DEFAULT '',
                        video_url         TEXT,
                        image_desktop_url TEXT,
                        image_mobile_url  TEXT,
                        html_content      TEXT,
                        click_url         TEXT,
                        alt_text          TEXT DEFAULT '',
                        duration_seconds  INTEGER NOT NULL DEFAULT 0,
                        skip_enabled      INTEGER NOT NULL DEFAULT 1,
                        skip_after_seconds INTEGER NOT NULL DEFAULT 5,
                        provider_zone     TEXT,
                        enabled           INTEGER NOT NULL DEFAULT 1,
                        created_at        TEXT NOT NULL,
                        updated_at        TEXT NOT NULL)""")
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_ad_creatives_campaign ON "
                    "ad_creatives(campaign_id, enabled)")
                await self.conn.execute(
                    """CREATE TABLE IF NOT EXISTS ad_placements (
                        key         TEXT PRIMARY KEY,
                        enabled     INTEGER NOT NULL DEFAULT 0,
                        updated_at  TEXT NOT NULL)""")
                await self.conn.execute(
                    """CREATE TABLE IF NOT EXISTS ad_events (
                        id          INTEGER PRIMARY KEY AUTOINCREMENT,
                        creative_id INTEGER NOT NULL,
                        campaign_id INTEGER NOT NULL,
                        placement   TEXT NOT NULL,
                        user_id     INTEGER,
                        event       TEXT NOT NULL,
                        created_at  TEXT NOT NULL)""")
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_ad_events_creative ON "
                    "ad_events(creative_id, event)")
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_ad_events_time ON "
                    "ad_events(created_at)")
                await self.conn.execute(
                    """CREATE TABLE IF NOT EXISTS ad_frequency_state (
                        user_id        INTEGER NOT NULL,
                        placement      TEXT NOT NULL,
                        window_key     TEXT NOT NULL,
                        count          INTEGER NOT NULL DEFAULT 0,
                        last_shown_at  TEXT,
                        PRIMARY KEY (user_id, placement, window_key))""")
                # --- seeds: default categories (spec §26) -------------------
                for _name, _slug, _icon, _order, _adult in (
                    ("Movies", "movies", "\U0001F3AC", 10, 0),
                    ("Anime", "anime", "\u2728", 20, 0),
                    ("18+", "adult", "\U0001F51E", 30, 1),
                    ("Shorts", "shorts", "\u26A1", 40, 0),
                ):
                    await self.conn.execute(
                        "INSERT OR IGNORE INTO website_categories "
                        "(name, slug, icon, sort_order, enabled, visible, "
                        " description, age_restricted, created_at, updated_at)"
                        " VALUES (?, ?, ?, ?, 1, 1, '', ?, ?, ?)",
                        (_name, _slug, _icon, _order, _adult, now, now))
                # --- seeds: placement registry (spec §37/§49) — default OFF
                # (ads are strictly opt-in: an admin enables placements
                # explicitly; disabled slots collapse completely).
                for _key in (
                    "AD_TOP", "AD_HOME_HERO", "AD_HOME_BETWEEN_CONTENT",
                    "AD_CATEGORY_TOP", "AD_CATEGORY_BETWEEN",
                    "AD_PAYLOAD_DETAIL", "AD_VIDEO_BEFORE",
                    "AD_VIDEO_MIDROLL", "AD_VIDEO_END",
                    "AD_SIDEBAR", "AD_FOOTER",
                ):
                    await self.conn.execute(
                        "INSERT OR IGNORE INTO ad_placements (key, enabled, "
                        "updated_at) VALUES (?, 0, ?)", (_key, now))
                # --- seeds: ads + session + pack settings -------------------
                for _k, _v in (
                    ("ads_enabled", "false"),
                    ("ads_exempt_user_ids", ""),
                    ("ads_video_cooldown_minutes", "10"),
                    ("ads_video_session_cap", "3"),
                    ("ads_video_daily_cap", "20"),
                    ("ads_video_first_only", "false"),
                    ("ads_video_every_n", "0"),
                    ("ads_video_probability", "100"),
                    ("ads_midroll_enabled", "false"),
                    ("ads_midroll_min_video_seconds", "120"),
                    ("ads_midroll_positions", "50"),
                    ("ads_postroll_enabled", "false"),
                    ("ads_impression_min_interval", "0"),
                ):
                    await self.conn.execute(
                        "INSERT OR IGNORE INTO bot_settings (key, value) "
                        "VALUES (?, ?)", (_k, _v))
                for _k, _v in (
                    ("website_session_ttl_seconds", "43200"),
                    ("website_pack_enabled", "true"),
                    ("website_pack_max_files", "50"),
                    ("website_pack_max_bytes", "2147483648"),
                ):
                    await self.conn.execute(
                        "INSERT OR IGNORE INTO bot_settings (key, value) "
                        "VALUES (?, ?)", (_k, _v))
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.error("v33 category/ads migrations failed: %s", e)
            logger.info(
                "Applied v33 migrations (GAP-CLOSURE: website categories + "
                "ads platform + pack settings — additive, idempotent; no "
                "existing table altered, no Telegram-side behavior touched).")

        if current < 34:
            # v33 -> v34 (TRUSTED FILE DELIVERY — spec §20-§66): platform-
            # managed network bots + ONE private Delivery Group per bot +
            # durable relay delivery jobs + the File Delivery Bot singleton
            # + Control Bot audit events. ADDITIVE ONLY: new tables via
            # SCHEMA_SQL (executed above on every start), new nullable/
            # defaulted columns via _add_column_if_missing, setting seeds via
            # INSERT OR IGNORE. Existing network bots are NOT deleted and NOT
            # re-awarded — their legacy storage:full capability simply stops
            # being consulted by routing; each bot must complete Delivery
            # Group setup to become DELIVERY_READY (spec §62).
            try:
                # --- network_bots management metadata (spec §28) ---------
                await self._add_column_if_missing(
                    "network_bots", "management_mode",
                    "TEXT DEFAULT 'USER_OWNED'")
                await self._add_column_if_missing(
                    "network_bots", "credential_control",
                    "TEXT DEFAULT 'OWNER'")
                await self._add_column_if_missing(
                    "network_bots", "created_via", "TEXT DEFAULT ''")
                # --- v34 tables are in SCHEMA_SQL (idempotent) ------------
                await self.conn.executescript(SCHEMA_SQL)
                # --- delivery settings seeds (spec §57/§53 retries) ------
                for _k, _v in (
                    ("delivery_relay_ttl_seconds", "900"),
                    ("delivery_max_attempts", "5"),
                    ("delivery_retry_base_seconds", "30"),
                    ("delivery_sweep_interval_seconds", "60"),
                ):
                    await self.conn.execute(
                        "INSERT OR IGNORE INTO bot_settings (key, value) "
                        "VALUES (?, ?)", (_k, _v))
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.error("v34 file-delivery migrations failed: %s", e)
            logger.info(
                "Applied v34 migrations (TRUSTED FILE DELIVERY: network_bots "
                "management metadata + network_delivery_groups + "
                "delivery_jobs + file_delivery_bot + control_audit_events "
                "+ relay TTL/retry settings — additive, idempotent; no "
                "existing row deleted; legacy storage capabilities retained "
                "as history only).")

        if current < 35:
            # v34 -> v35 (BOT-11 production fixes — Global Link per-bot
            # targeting + persisted bot capabilities + Mini App apply
            # state): ADDITIVE ONLY, exactly the v34 discipline — new
            # defaulted columns via _add_column_if_missing, new index +
            # fresh-DB CREATE TABLE shapes via executescript(SCHEMA_SQL)
            # (idempotent), setting seeds via INSERT OR IGNORE. Existing
            # global_payload_links rows keep target_network_bot_id=0 /
            # target_mode='' = the LEGACY untargeted routing behavior
            # (byte-identical — zero regression for published links).
            try:
                # --- global_payload_links per-link target (spec §12/§16) --
                await self._add_column_if_missing(
                    "global_payload_links", "target_network_bot_id",
                    "INTEGER NOT NULL DEFAULT 0")
                await self._add_column_if_missing(
                    "global_payload_links", "target_mode",
                    "TEXT DEFAULT ''")
                # --- network_bots capability persistence (spec §1/§7) -----
                await self._add_column_if_missing(
                    "network_bots", "can_manage_bots", "INTEGER")
                await self._add_column_if_missing(
                    "network_bots", "capability_checked_at", "TEXT")
                # --- network_bots Mini App apply state (spec §9/§10) ------
                await self._add_column_if_missing(
                    "network_bots", "mini_app_url", "TEXT DEFAULT ''")
                await self._add_column_if_missing(
                    "network_bots", "mini_app_last_applied_at", "TEXT")
                await self._add_column_if_missing(
                    "network_bots", "mini_app_last_apply_status",
                    "TEXT DEFAULT ''")
                await self._add_column_if_missing(
                    "network_bots", "mini_app_last_apply_error",
                    "TEXT DEFAULT ''")
                # --- v35 index + fresh-DB table shapes (idempotent) --------
                await self.conn.executescript(SCHEMA_SQL)
                # idx_gpl_target lives HERE (not in SCHEMA_SQL): on an
                # upgraded v34 database the column exists only AFTER the
                # _add_column_if_missing calls above — the top-level
                # executescript would crash before reaching this block.
                await self.conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_gpl_target "
                    "ON global_payload_links(target_network_bot_id)")
                # --- seeds (spec §6/§9: honest defaults) -------------------
                for _k, _v in (
                    # website Get File: when NO registered delivery bot is
                    # eligible, fall back to the MAIN bot deep link (0 =
                    # refuse instead; never a dead button silently).
                    ("website_get_file_allow_main_fallback", "0"),
                    # registered-bots menu-button policy: auto|main|off
                    # (may already exist from b10 §8 — INSERT OR IGNORE is
                    # safe and never overwrites an operator choice).
                    ("network_bots_menu_button_mode", "auto"),
                ):
                    await self.conn.execute(
                        "INSERT OR IGNORE INTO bot_settings (key, value) "
                        "VALUES (?, ?)", (_k, _v))
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.error("v35 global-link targeting migrations failed: %s", e)
            logger.info(
                "Applied v35 migrations (BOT-11: global_payload_links "
                "target_network_bot_id/target_mode + idx_gpl_target; "
                "network_bots can_manage_bots/capability_checked_at + "
                "mini_app apply-state columns; website_get_file_allow_main_"
                "fallback + network_bots_menu_button_mode seeds — additive, "
                "idempotent; legacy links keep target=0 untargeted routing).")

        if current < 36:
            # v35 -> v36 (BOT-13 — per-payload website delivery controls +
            # delivery-job audit column): ADDITIVE ONLY, the same
            # discipline as v33-v35. New defaulted columns via
            # _add_column_if_missing, fresh-DB shapes via
            # executescript(SCHEMA_SQL) (idempotent), setting seeds via
            # INSERT OR IGNORE. Existing payloads keep their CURRENT
            # behavior: show_get_file=1 (Get File stays available) and
            # video_ad_destination='BOT' (no website pre-roll unless the
            # operator opts a payload into WEBSITE mode) — the defaults
            # are chosen so NO existing deployment changes behavior.
            try:
                # --- per-payload Get File switch (spec §46) ---------------
                await self._add_column_if_missing(
                    "payloads", "show_get_file",
                    "INTEGER NOT NULL DEFAULT 1")
                # --- per-payload delivery/access mode (spec §47/§48) -----
                await self._add_column_if_missing(
                    "payloads", "video_ad_destination",
                    "TEXT NOT NULL DEFAULT 'BOT'")
                # --- delivery_jobs duplicate-audit column (spec §9) ------
                await self._add_column_if_missing(
                    "delivery_jobs", "user_message_id", "INTEGER")
                # --- fresh-DB table shapes (idempotent) -------------------
                await self.conn.executescript(SCHEMA_SQL)
                # --- seeds ------------------------------------------------
                for _k, _v in (
                    # managed-bot capability cache TTL: a persisted
                    # can_manage_bots=0 older than this auto-refreshes via
                    # a live getMe before any refusal (never a permanent
                    # False — spec §2/§18).
                    ("network_capability_ttl_seconds", "300"),
                ):
                    await self.conn.execute(
                        "INSERT OR IGNORE INTO bot_settings (key, value) "
                        "VALUES (?, ?)", (_k, _v))
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.error("v36 per-payload delivery-control migrations "
                             "failed: %s", e)
            logger.info(
                "Applied v36 migrations (BOT-13: payloads.show_get_file + "
                "payloads.video_ad_destination (per-payload Get File ON/OFF "
                "+ BOT/WEBSITE/NONE delivery mode — backward-compatible "
                "defaults 1/'BOT'); delivery_jobs.user_message_id audit "
                "column; network_capability_ttl_seconds seed — additive, "
                "idempotent).")

        if current < 37:
            # v36 -> v37 (BOT-16 — registered-bot removal lifecycle): the
            # production leak where a REMOVED bot kept appearing in
            # "Registered Bots", Network Control counts, health lists, the
            # delivery center, the mini-app panel and the public /network
            # page. ADDITIVE ONLY, the same discipline as v33-v36:
            #   1. network_bots.removed_at TEXT NULL — the durable removal
            #      timestamp written by registry.remove_bot (NULL = never
            #      removed; legacy pre-v37 removed rows keep NULL — their
            #      audit trail is last_error_code='REMOVED' +
            #      control_audit_events).
            #   2. The status-vocabulary comment now documents REMOVED as
            #      the TERMINAL removal state (b10 §5).
            # New defaulted column via _add_column_if_missing; fresh-DB
            # CREATE TABLE shape via executescript(SCHEMA_SQL) (idempotent).
            # NO setting seeds and NO existing row is modified.
            try:
                await self._add_column_if_missing(
                    "network_bots", "removed_at", "TEXT")
                # --- fresh-DB table shapes (idempotent) -------------------
                await self.conn.executescript(SCHEMA_SQL)
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.error("v37 removal-lifecycle migration failed: %s", e)
            logger.info(
                "Applied v37 migrations (BOT-16: network_bots.removed_at "
                "removal timestamp + REMOVED documented as the terminal "
                "registry status — additive, idempotent; existing rows keep "
                "removed_at=NULL, no row modified).")

        if current < 38:
            # v37 -> v38 (B17 — DIRECT DELIVERY ARCHITECTURE): bot-18.log
            # proved the FDB-authored relay + network-bot copyMessage chain
            # fundamentally invalid on Telegram (bots can never copy
            # messages authored by another bot — "Message to copy not
            # found" on every relay id, instantly, forever; the B16
            # protect=off(relay) fix and the self-heal loop both attacked
            # symptoms). v38 adds the audit columns for the NEW layered
            # delivery modes (network_relay / fdb_direct / handoff) and the
            # one-time deep-link handoff token + its timestamp. ADDITIVE
            # ONLY — no existing row changes, legacy rows keep NULLs.
            try:
                await self._add_column_if_missing(
                    "delivery_jobs", "delivery_mode", "TEXT")
                await self._add_column_if_missing(
                    "delivery_jobs", "handoff_token", "TEXT")
                await self._add_column_if_missing(
                    "delivery_jobs", "handoff_sent_at", "TEXT")
                # --- fresh-DB table shapes (idempotent) -------------------
                await self.conn.executescript(SCHEMA_SQL)
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.error("v38 direct-delivery migration failed: %s", e)
            logger.info(
                "Applied v38 migrations (B17: delivery_jobs.delivery_mode + "
                "handoff_token + handoff_sent_at — direct-delivery "
                "architecture audit columns; additive, idempotent).")

        if current < 39:
            # v38 -> v39 (B18 — bot-19.log root causes, honest delivery
            # metrics + force-join link provenance). bot-19.log proved two
            # production problems this migration serves:
            #   1. NETWORK DELIVERY: jobs 34/35 fell back from Mode A to
            #      Mode B and were logged NETWORK_DELIVERY_SUCCESS — with
            #      no durable record that Mode A EVER failed. Metrics
            #      could not distinguish "network bot delivered" from
            #      "FDB fallback delivered" without log parsing.
            #      -> delivery_jobs.mode_a_failure / mode_a_failure_at
            #         (ADDITIVE; NULL on every legacy row and every clean
            #         network_relay delivery).
            #   2. FORCE JOIN: the Bot API has NO getChatInviteLink, so
            #      link health cannot introspect invite hashes. The ONLY
            #      durable fact about a stored link is WHO created it:
            #      bot-created links are provably valid until our own
            #      rotate revokes them; custom links are trusted, not
            #      introspectable.
            #      -> force_join_channels.link_provenance
            #         ('bot_created' | 'custom' | NULL=legacy-trusted).
            # ADDITIVE ONLY — no existing row is modified; legacy rows keep
            # NULLs (honest: unknown/legacy provenance).
            try:
                await self._add_column_if_missing(
                    "delivery_jobs", "mode_a_failure", "TEXT")
                await self._add_column_if_missing(
                    "delivery_jobs", "mode_a_failure_at", "TEXT")
                await self._add_column_if_missing(
                    "force_join_channels", "link_provenance", "TEXT")
                # --- fresh-DB table shapes (idempotent) -------------------
                await self.conn.executescript(SCHEMA_SQL)
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.error("v39 honest-metrics migration failed: %s", e)
            logger.info(
                "Applied v39 migrations (B18: delivery_jobs.mode_a_failure "
                "+ mode_a_failure_at (truthful Mode-A vs fallback metrics) "
                "+ force_join_channels.link_provenance — additive, "
                "idempotent; legacy rows keep NULLs).")

        if current < 40:
            # v39 -> v40 (B18-FINAL — bot-22.log pass: website media
            # engagement + the signed external-browser handoff).
            #   1. media_view_events — per-(file, viewer) view dedupe rows:
            #      a view COUNTS once per viewer per dedupe window (refresh
            #      and repeated page opens never inflate counts). VIDEOS
            #      ONLY (enforced by the API layer — photos and documents
            #      never receive video view counts).
            #   2. media_reactions — ONE like-or-dislike per (file, user),
            #      atomic switch semantics (like -> dislike replaces the
            #      row inside one transaction; a repeat click removes it).
            #   3. website_handoffs — SINGLE-USE replay-protected handoff
            #      nonces for the Mini App -> external browser session
            #      transfer (Telegram.WebApp.openLink; the AEAD token in
            #      the URL never carries a raw user id).
            # ADDITIVE ONLY — new tables, no existing row modified.
            try:
                # --- fresh-DB table shapes (idempotent) -------------------
                await self.conn.executescript(SCHEMA_SQL)
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001
                logger.error("v40 media-engagement migration failed: %s", e)
            logger.info(
                "Applied v40 migrations (B18-FINAL: media_view_events + "
                "media_reactions + website_handoffs — website media "
                "engagement (views after a meaningful playback threshold, "
                "per-viewer dedupe; one like/dislike per user per file, "
                "atomic switching) and the single-use external-browser "
                "handoff store; additive, idempotent).")

        if current < 41:
            # v40 -> v41 (V25 §2/§3 — bot-31.log storage-indexing pass).
            #   indexed_files gains the canonical re-point history columns:
            #     prev_channel_id / prev_message_id — the PREVIOUS canonical
            #       storage reference, preserved when a row is re-pointed to a
            #       new storage message because the old one was deleted and
            #       the SAME file identity was re-sent (Scenario B).
            #     repointed_at — ISO timestamp of the re-point.
            #   ADDITIVE / NULLABLE / IDEMPOTENT / RESTART-SAFE (the
            #   _add_column_if_missing pattern): no existing table, row,
            #   payload reference or index is touched; legacy rows keep NULL
            #   (never re-pointed). Fresh databases receive the columns from
            #   SCHEMA_SQL; existing v40 databases receive them here.
            await self._add_column_if_missing(
                "indexed_files", "prev_channel_id", "INTEGER")
            await self._add_column_if_missing(
                "indexed_files", "prev_message_id", "INTEGER")
            await self._add_column_if_missing(
                "indexed_files", "repointed_at", "TEXT")
            logger.info(
                "Applied v41 migrations (V25: indexed_files re-point history "
                "prev_channel_id/prev_message_id/repointed_at — additive, "
                "nullable, non-destructive; legacy rows stay NULL).")

        if current < 42:
            # v41 -> v42 (V25 FINAL — bot-35.log two-stage architecture).
            #   network_bots.delivery_channel_chat_id — the per-bot DELIVERY
            #     CHANNEL (Storage -> FDB -> Delivery Channel -> Network
            #     Bot -> User). LEGACY MIGRATION: every existing
            #     network_delivery_groups row's chat is TRANSFERRED to the
            #     owning network bot's delivery_channel_chat_id (the old
            #     group WAS the intended Delivery Channel — bot-35.log's
            #     DELIVERY_GROUP_VERIFY chat_id=-1001879503489 evidence).
            #     The legacy group TABLE rows survive untouched as compat
            #     data; no production path reads them for routing anymore.
            #   delivery_jobs.delivery_channel_id / delivery_message_id —
            #     the durable Stage-A identity (which channel message the
            #     Network Bot's user-facing copy reads from).
            #   ADDITIVE / NULLABLE / IDEMPOTENT / RESTART-SAFE: no existing
            #     row is modified except the one-time chat TRANSFER (NULL
            #     delivery_channel_chat_id only, so re-running is a no-op).
            await self._add_column_if_missing(
                "network_bots", "delivery_channel_chat_id", "INTEGER")
            await self._add_column_if_missing(
                "delivery_jobs", "delivery_channel_id", "INTEGER")
            await self._add_column_if_missing(
                "delivery_jobs", "delivery_message_id", "INTEGER")
            try:
                migrated = await self.conn.execute_fetchall(
                    "SELECT nb.id AS nid, g.delivery_group_chat_id AS chat "
                    "FROM network_bots nb JOIN network_delivery_groups g "
                    "ON g.network_bot_id = nb.id "
                    "WHERE nb.delivery_channel_chat_id IS NULL "
                    "  AND g.delivery_group_chat_id IS NOT NULL")
                for row in migrated:
                    await self.conn.execute(
                        "UPDATE network_bots SET delivery_channel_chat_id = ?, "
                        "updated_at = ? WHERE id = ?",
                        (int(row["chat"]), _now_iso(), int(row["nid"])))
                    await self.conn.commit()
                    logger.info(
                        "DELIVERY_CHANNEL_MIGRATED network_bot_id=%s "
                        "delivery_channel_chat_id=%s (legacy delivery-group "
                        "chat transferred to the Delivery Channel "
                        "configuration; the group row survives as compat "
                        "data only)", int(row["nid"]), int(row["chat"]))
            except Exception as e:  # noqa: BLE001 — transfer is best-effort
                logger.error("v42 delivery-channel migration transfer "
                             "failed: %s", e)
            logger.info(
                "Applied v42 migrations (V25 FINAL: network_bots."
                "delivery_channel_chat_id + delivery_jobs."
                "delivery_channel_id/delivery_message_id — the two-stage "
                "Delivery Channel architecture; legacy group chats "
                "transferred where present).")

        if current < 43:
            # v42 -> v43 (V26 — Network Bot Watch Ads).
            #   watch_ad_sessions.launch_network_bot_id — the network bot
            #     whose [🎬 Watch Ad] button launched the session (NULL = the
            #     main bot / a legacy pre-V26 row). Recorded at session
            #     creation/reuse so the VERIFIED-reward notification and the
            #     auto-resume delivery run through the bot the user is
            #     actually talking to (the user clicked THAT bot's payload
            #     link — the main bot may have no chat with them at all and
            #     its DM would fail Forbidden).
            #   ADDITIVE / NULLABLE / IDEMPOTENT / RESTART-SAFE: no existing
            #     row is modified; legacy rows keep NULL (main-bot semantics,
            #     the pre-V26 behavior preserved exactly).
            await self._add_column_if_missing(
                "watch_ad_sessions", "launch_network_bot_id", "INTEGER")
            logger.info(
                "Applied v43 migrations (V26: watch_ad_sessions."
                "launch_network_bot_id — Network Bot Watch Ads launch "
                "context for reward routing; additive, nullable, "
                "non-destructive; legacy rows stay NULL = main bot).")

        if current < 44:
            # v43 -> v44 (V26 remaining — Force Join requirement identity).
            #   fj_progress.requirement_identity — TEXT: 12-hex fingerprint
            #     of the CURRENT requirement configuration
            #     (mode|batch_size|sorted channel ids). When the admin
            #     changes the requirement (mode / batch size / channel
            #     set), the identity changes and the FJ service re-derives
            #     the PRESENTATION state (order / cursor / active batch)
            #     deterministically — while the live Telegram membership
            #     checks remain the sole AUTHORIZATION authority (a config
            #     change can never fabricate or destroy completion).
            #   ADDITIVE / NULLABLE / IDEMPOTENT / RESTART-SAFE: legacy rows
            #     keep NULL; the service ADOPTS the current identity on the
            #     first read WITHOUT touching any other column (legacy
            #     production progress survives byte-identically).
            await self._add_column_if_missing(
                "fj_progress", "requirement_identity", "TEXT")
            logger.info(
                "Applied v44 migrations (V26: fj_progress."
                "requirement_identity — Force Join requirement-identity "
                "state; additive, nullable, non-destructive; legacy rows "
                "stay NULL and adopt the current identity on first read).")

        if current < 45:
            # v44 -> v45 (V26.x Phase 3 — Delivery Channel source cleanup).
            #   delivery_jobs.channel_cleanup_pending — INTEGER NOT NULL
            #     DEFAULT 0: the durable marker that a Delivery Channel
            #     SOURCE message exists for this job (set at Stage A,
            #     cleared ONLY after the FDB's delete of the exact
            #     (delivery_channel_id, delivery_message_id) is confirmed
            #     — or proven already gone). The sweeper reconciles
            #     DELIVERED rows with the flag set (a crash between the
            #     confirmed user delivery and the channel deletion is
            #     recovered on the next pass). The Storage Channel master
            #     is NEVER touched; the USER delivery TTL cleanup stays a
            #     completely independent pass.
            #   ADDITIVE / DEFAULTED / IDEMPOTENT / RESTART-SAFE: legacy
            #     rows read 0 (no cleanup owed for historical messages —
            #     the pre-v45 production behavior, preserved verbatim).
            await self._add_column_if_missing(
                "delivery_jobs", "channel_cleanup_pending",
                "INTEGER NOT NULL DEFAULT 0")
            logger.info(
                "Applied v45 migrations (V26.x: delivery_jobs."
                "channel_cleanup_pending — Delivery Channel source "
                "cleanup marker; additive, defaulted, non-destructive; "
                "legacy rows stay 0 = no cleanup owed).")

        if current < 46:
            # v45 -> v46 (V26.2 — Force-Join progressive batching, bot-41
            #   §16-§24). fj_gate_presentations — the per-gate PINNED BATCH
            #   store: one row per (user_id, gate_key) recording which
            #   batch that specific gated playback/delivery presented
            #   under the current requirement identity. The Website and
            #   the File Delivery Bot share the SAME global fj_progress
            #   requirement state (never resetting each other, §21) while
            #   each gated content keeps its own pinned presentation
            #   (stable across refresh / SPA navigation / reopen / Verify,
            #   §17-§18). Future batches are NEVER delivered to the client
            #   (§23) — only the pinned batch is. NEW TABLE (fresh DBs get
            #   it from SCHEMA_SQL; legacy DBs get it here) — additive,
            #   idempotent, restart-safe; no existing table or row is
            #   touched.
            await self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS fj_gate_presentations (
                    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id             INTEGER NOT NULL,
                    gate_key            TEXT NOT NULL,
                    requirement_identity TEXT NOT NULL,
                    pinned_batch        TEXT NOT NULL,
                    created_at           TEXT NOT NULL,
                    updated_at           TEXT NOT NULL,
                    UNIQUE(user_id, gate_key)
                )
                """)
            await self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_fj_gate_presentations_user "
                "ON fj_gate_presentations(user_id)")
            await self.conn.commit()
            logger.info(
                "Applied v46 migrations (V26.2: fj_gate_presentations — "
                "per-gate pinned Force-Join batches for progressive "
                "batching on the Website and the File Delivery Bot; new "
                "table, additive, idempotent, non-destructive).")

        if current < 47:
            # v46 -> v47 (BOT-45/46 — final consolidated production round).
            #   payloads.display_name_origin — TEXT, NULLABLE: the display
            #     name PROVENANCE. NULL/'source' = derived from the CURRENT
            #     Telegram Storage source (a live re-resolve refreshes it);
            #     'admin_override' = explicitly admin-set (PRESERVED verbatim,
            #     never overwritten by source refresh). Fixes the Storage
            #     canonical-filename staleness: the wizard showed the
            #     scan-time indexed_files.file_name instead of the CURRENT
            #     Telegram source filename (image_9 evidence).
            #   pending_deletions.attempts / .last_error — the failed-delete
            #     retry accounting for the persistent auto-delete pass
            #     (BOT-45/46 Auto Delete inconsistency: rows whose Telegram
            #     delete failed were settled anyway → zombie rows deleted
            #     idempotently every sweep; now a delete settles ONLY after
            #     a confirmed delete / already-gone, with bounded retry).
            #   ADDITIVE / NULLABLE / DEFAULTED / IDEMPOTENT / RESTART-SAFE:
            #   no existing row is modified; legacy payloads rows keep NULL
            #   origin (treated as 'source' with the CURRENT value preserved
            #   until an explicit refresh event); legacy pending_deletions
            #   rows read attempts=0 (never failed).
            await self._add_column_if_missing(
                "payloads", "display_name_origin", "TEXT")
            await self._add_column_if_missing(
                "pending_deletions", "attempts",
                "INTEGER NOT NULL DEFAULT 0")
            await self._add_column_if_missing(
                "pending_deletions", "last_error", "TEXT")
            logger.info(
                "Applied v47 migrations (BOT-45/46: payloads."
                "display_name_origin provenance + pending_deletions."
                "attempts/last_error retry accounting — additive, "
                "nullable/defaulted, non-destructive).")

        if current < SCHEMA_VERSION:
            await self.conn.execute(
                "INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('version', ?);",
                (str(SCHEMA_VERSION),),
            )
            await self.conn.commit()
            logger.info("Database migrated -> version %d", SCHEMA_VERSION)

    async def create_watch_ad_session(self, user_id: int, payload_id: int,
                                      provider: str = WATCH_AD_PROVIDER_DEFAULT
                                      ) -> Optional[aiosqlite.Row]:
        """Create a NEW secure ad session bound to (user_id, payload_id).

        The token is 32-char secure random hex (unguessable, unenumerable).
        expires_at = now + WATCH_AD_SESSION_TTL. The same token doubles as the
        `ymid` passed to the Monetag SDK for ad 1 (ads N>=2 use token_N) so
        the S2S postback maps back to this exact session. Enforces the hourly
        per-(user, payload) cap BEFORE the insert (anti-spam: no unlimited
        simultaneous sessions). Returns None when the cap is hit.

        V2 (v26) Ads Control — the mode is resolved SERVER-SIDE and stored on
        the session at creation time:
          short  -> required_ads = 1 (short-ad preference; provider controls
                    the actual creative/duration)
          two    -> required_ads = 2 (V4: exactly two sequential ads)
          random -> required_ads = random 1..3 (server-side, per session)
          three  -> required_ads = 3
        V4 (v27) per-payload override: when the payload has a valid
        watch_ads_ad_mode_override, THAT mode wins over the global default
        (global = defaults, payload = override). The stored values are
        STABLE for the session's lifetime — later global/override changes
        only affect NEWLY created sessions. The session TTL is the
        admin-configurable watch_ads_session_ttl (clamped).
        """
        now = datetime.now(timezone.utc)
        hour_ago = (now - timedelta(hours=1)).isoformat()
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM watch_ad_sessions "
            "WHERE user_id = ? AND payload_id = ? AND created_at >= ?",
            (user_id, payload_id, hour_ago),
        )
        row = await cur.fetchone()
        if row and int(row["c"]) >= WATCH_AD_SESSION_HOURLY_CAP:
            logger.info(
                "WATCH_AD_SESSION_CAP user_id=%s payload_id=%s sessions_last_hour=%s cap=%s",
                user_id, payload_id, int(row["c"]), WATCH_AD_SESSION_HOURLY_CAP,
            )
            return None
        # V4 (v27): resolve the mode — per-payload override first, then the
        # global default. Both are validated; junk values fall back to the
        # global mode (never to an arbitrary count).
        # WATCH_AD V5 (§35): MODE_RESOLVED is logged SEPARATELY from the
        # SESSION_CREATE line with configured_mode (the raw admin value as
        # stored), resolved_mode (the validated effective mode) and the
        # per-session random roll — a random->1 bug can no longer hide:
        # every 'random' session shows its exact server-side randint result
        # at creation time, before anything else happens.
        mode_source = "global"
        configured_mode = (await self.get_setting(WATCH_AD_AD_CONTROL_KEY)
                           or "").strip().lower()
        mode = await self.get_watch_ads_ad_control()
        try:
            override = await self.get_payload_watch_ads_ad_mode_override(payload_id)
        except Exception:  # noqa: BLE001  # stamped DB pre-repair — safe fallback
            override = None
        if override and override != mode:
            mode = override
            mode_source = "payload_override"
            configured_mode = override
        if mode == WATCH_AD_AD_CONTROL_THREE:
            required_ads = 3
        elif mode == WATCH_AD_AD_CONTROL_TWO:
            required_ads = 2
        elif mode == WATCH_AD_AD_CONTROL_RANDOM:
            required_ads = _random.randint(WATCH_AD_RANDOM_MIN,
                                           WATCH_AD_RANDOM_MAX)
        else:  # short (and any legacy/unknown value)
            required_ads = 1
        required_ads = max(1, min(WATCH_AD_MAX_REQUIRED_ADS, int(required_ads)))
        # V4 (v27): admin-configurable session TTL (clamped), stable for this
        # session's lifetime.
        session_ttl = await self.get_watch_ads_session_ttl()
        expires_dt = now + timedelta(seconds=session_ttl)
        for _attempt in range(5):  # retry on token collision (practically impossible)
            token = _secrets.token_hex(WATCH_AD_TOKEN_BYTES)
            try:
                await self.conn.execute(
                    """INSERT INTO watch_ad_sessions
                       (token, user_id, payload_id, status, provider, ymid,
                        reward_count, ad_control_mode, required_ads,
                        completed_ads, created_at, expires_at)
                       VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, 0, ?, ?)""",
                    (token, user_id, payload_id, WATCH_AD_STATUS_PENDING,
                     provider, token, mode, int(required_ads),
                     now.isoformat(),
                     expires_dt.isoformat()),
                )
                await self.conn.commit()
                row = await self.get_watch_ad_session_by_token(token)
                # WATCH_AD V5.1 (§5): MODE_RESOLVED is the DEFINITIVE session
                # identity record — logged AFTER the row exists so it carries
                # build id + PID + DB path + session id + token prefix +
                # creation time together with the mode resolution (configured
                # value, validated value, the exact random roll, source).
                # Production debugging no longer needs to guess WHICH build
                # created a session or WHY required_ads has its value.
                logger.info(
                    "WATCH_AD_MODE_RESOLVED build_id=%s pid=%s db=%s "
                    "session=%s token=%s… user_id=%s payload_id=%s "
                    "configured_mode=%s resolved_mode=%s required_ads=%s "
                    "mode_source=%s created_at=%s",
                    RUNTIME_BUILD_ID, os.getpid(), DATABASE_FILE,
                    int(row["id"]) if row else "-", token[:6], user_id,
                    payload_id, configured_mode or "-", mode, required_ads,
                    mode_source, now.isoformat(),
                )
                logger.info(
                    "WATCH_AD_SESSION_CREATE user_id=%s payload_id=%s "
                    "token=%s… ad_control_mode=%s required_ads=%s "
                    "mode_source=%s session_ttl=%s expires_at=%s",
                    user_id, payload_id, token[:6], mode, required_ads,
                    mode_source, session_ttl, expires_dt.isoformat(),
                )
                return row
            except Exception as e:  # noqa: BLE001
                # v26 fix: this branch used to be a SILENT `continue` — any DB
                # error (e.g. a v25 database missing the v26 columns) degraded
                # every Watch Ads screen to "temporarily unavailable" with
                # ZERO diagnostics. Now every failure is logged with the
                # structured code + context (spec §17); the user still only
                # ever sees the safe generic message.
                logger.error(
                    "WATCH_AD_CREATE_SESSION_FAILED user_id=%s payload_id=%s "
                    "ad_control_mode=%s required_ads=%s attempt=%s "
                    "exc=%s.%s reason=%s",
                    user_id, payload_id, mode, required_ads, _attempt + 1,
                    type(e).__module__, type(e).__name__, e,
                )
                try:
                    if self.conn.in_transaction:
                        await self.conn.execute("ROLLBACK")
                except Exception:  # noqa: BLE001
                    pass
                continue
        logger.error(
            "WATCH_AD_CREATE_SESSION_FAILED user_id=%s payload_id=%s "
            "ad_control_mode=%s required_ads=%s reason=all_insert_attempts_failed "
            "— Watch Ads will report temporarily unavailable until the DB "
            "error above is fixed",
            user_id, payload_id, mode, required_ads,
        )
        return None

    async def get_or_create_watch_ad_session(self, user_id: int, payload_id: int
                                             ) -> Tuple[Optional[aiosqlite.Row], bool]:
        """Reuse a live pending session when possible, else create a new one.

        Returns (session_row, created_new). Reuse guarantees that repeated
        [🎬 Watch Ad] presses never spawn unlimited parallel sessions; the
        hourly cap guards creation. A session that is already `rewarded` is NOT
        returned here — the unlock window is evaluated by
        watch_ad_unlock_valid() instead.

        WATCH_AD V5.1 (§6): reuse is EXPLICIT. When an existing pending
        session is returned, WATCH_AD_SESSION_REUSE logs its ORIGINAL
        required_ads / completed_ads / mode / creation + expiry times, so an
        OLD session (e.g. a pre-restart random→1 roll) can never be mistaken
        for a freshly rolled one — and a mode-change-during-session is
        observably a no-op for the reused row.
        """
        now_iso = datetime.now(timezone.utc).isoformat()
        cur = await self.conn.execute(
            "SELECT * FROM watch_ad_sessions WHERE user_id = ? AND payload_id = ? "
            "AND status = ? AND expires_at > ? ORDER BY id DESC LIMIT 1",
            (user_id, payload_id, WATCH_AD_STATUS_PENDING, now_iso),
        )
        row = await cur.fetchone()
        if row:
            _mode = _safe_row_get(row, "ad_control_mode") or "-"
            try:
                _ovr = await self.get_payload_watch_ads_ad_mode_override(payload_id)
            except Exception:  # noqa: BLE001
                _ovr = None
            _msrc = "payload_override" if (_ovr and _ovr == _mode) else "global"
            logger.info(
                "WATCH_AD_SESSION_REUSE session=%s token=%s… user_id=%s "
                "payload_id=%s ad_control_mode=%s mode_source=%s "
                "required_ads=%s completed_ads=%s created_at=%s expires_at=%s "
                "(existing pending session returned unchanged — admin mode "
                "changes affect NEW sessions only)",
                int(row["id"]), row["token"][:6], user_id, payload_id,
                _mode, _msrc,
                max(1, int(_safe_row_get(row, "required_ads") or 1)),
                max(0, int(_safe_row_get(row, "completed_ads") or 0)),
                _safe_row_get(row, "created_at") or "-",
                _safe_row_get(row, "expires_at") or "-")
            return row, False
        session = await self.create_watch_ad_session(user_id, payload_id)
        return session, session is not None

    async def process_watch_ad_reward(self, token: str, *,
                                      event_type: str = "",
                                      reward_event_type: str = "",
                                      estimated_price: Optional[float] = None,
                                      telegram_id: Optional[int] = None,
                                      zone_id: Optional[str] = None,
                                      sub_zone_id: Optional[str] = None,
                                      request_var: Optional[str] = None,
                                      ymid_raw: str = "",
                                      ad_index: Optional[int] = None
                                      ) -> Dict[str, Any]:
        """THE single server-side reward processor (Monetag S2S postback).

        Idempotent, transactional, replay-protected. Result dict:
          result: rewarded | duplicate | non_valued | unknown | expired |
                  rejected | inactive | error
          complete: True only when the session's required_ads verified-reward
                    count has been reached AND the unlock window started.
          completed_ads / required_ads: server-side reward progress.

        V2 (v26) multi-ad rules — per-ad idempotency ledger:
          Every accepted 'valued' reward INSERTs one row into
          watch_ad_reward_events keyed on the provider ymid (token for ad 1,
          token_N for ad N>=2). A retried/duplicated postback (same ymid)
          collides on the PRIMARY KEY inside the SAME BEGIN IMMEDIATE
          transaction and is classified as duplicate — it can NEVER increment
          completed_ads twice (double-count / replay / double-spend proof).
          Race-safe: two concurrent postbacks serialize on the write lock +
          BEGIN IMMEDIATE; the second one sees the first's committed event row.
          completed_ads is only incremented for a session that is still
          'pending'; once it reaches required_ads the session flips to
          'rewarded' and any further postbacks are duplicates.

        Legacy compatibility: sessions created before v26 (or by a legacy
          caller) have required_ads=1 and ymid==token, so a single valued
          postback completes them exactly like v25.

        Rules enforced (in order):
          1. Unknown token            -> unknown (postback for a foreign ymid)
          2. Already rewarded         -> duplicate (counted, never re-processed)
          3. Expired/rejected session -> expired/rejected
          4. Pending TTL elapsed      -> expired
          5. Payload missing/disabled or Watch Ads OFF -> rejected (no usable
             unlock is ever granted for a gone/inactive payload)
          6. Monetag telegram_id present AND != session owner -> rejected
             (cross-user session usage)
          7. reward_event_type == non_valued -> non_valued (unpaid/fraud
             traffic — explicitly NOT rewarded, session stays pending so a
             legitimate later valued event can still reward it)
          8. valued impression/click  -> per-ad reward recorded. When
             completed_ads reaches required_ads the session becomes REWARDED
             and the unlock window starts (complete=True).
        """
        result: Dict[str, Any] = {"result": "unknown", "session_id": None,
                                  "user_id": None, "payload_id": None,
                                  "unlock_expires_at": None,
                                  "complete": False,
                                  "completed_ads": 0, "required_ads": 1,
                                  # V26 (Network Bot Watch Ads): the launch
                                  # context so the reward notification /
                                  # auto-resume routes through the bot the
                                  # user is actually talking to.
                                  "launch_network_bot_id": None}
        if not token:
            return result
        now = datetime.now(timezone.utc)
        now_iso = now.isoformat()
        try:
            async with self.write_lock:
                # Safety: never nest transactions. WATCH_AD V5 (concurrency
                # fix, defense-in-depth): even with all Watch-Ads writes now
                # serialized on this lock, a lock-free writer elsewhere in
                # the codebase could have an implicit transaction QUEUED on
                # the aiosqlite worker thread between our check and BEGIN —
                # the exact production "cannot start a transaction within a
                # transaction" race. Roll any stray transaction back and
                # retry the BEGIN (bounded) instead of failing the reward.
                for _begin_attempt in range(3):
                    if self.conn.in_transaction:
                        try:
                            await self.conn.execute("ROLLBACK")
                        except Exception:  # noqa: BLE001  # already closed
                            pass
                    try:
                        await self.conn.execute("BEGIN IMMEDIATE")
                        break
                    except Exception as _begin_err:  # noqa: BLE001
                        if ("within a transaction" in str(_begin_err)
                                and _begin_attempt < 2):
                            logger.warning(
                                "WATCH_AD_REWARD_TXN_BEGIN_RETRY attempt=%s "
                                "reason=stray_implicit_transaction (rolled "
                                "back and retried)", _begin_attempt + 1)
                            continue
                        raise
                session = await self.get_watch_ad_session_by_token(token)
                if not session:
                    await self.conn.execute("ROLLBACK")
                    logger.info(
                        "WATCH_AD_SESSION_INVALID token=%s… reason=unknown_token "
                        "(postback for a foreign/already-rotated ymid)",
                        token[:6])
                    return result
                sid = int(session["id"])
                result["session_id"] = sid
                result["user_id"] = int(session["user_id"])
                result["payload_id"] = int(session["payload_id"])
                # V26: the launch context rides along on every outcome.
                try:
                    result["launch_network_bot_id"] = (
                        int(_safe_row_get(session, "launch_network_bot_id"))
                        if _safe_row_get(session, "launch_network_bot_id")
                        else None)
                except Exception:  # noqa: BLE001
                    result["launch_network_bot_id"] = None
                status = session["status"]
                required_ads = max(1, int(_safe_row_get(session, "required_ads") or 1))
                completed_ads = max(0, int(_safe_row_get(session, "completed_ads") or 0))
                result["required_ads"] = required_ads
                result["completed_ads"] = completed_ads
                logger.info(
                    "WATCH_AD_REWARD_TRANSACTION_START session=%s token=%s… "
                    "user_id=%s payload_id=%s ymid=%s ad_control_mode=%s "
                    "required_ads=%s completed_ads=%s status=%s",
                    sid, token[:6], result["user_id"], result["payload_id"],
                    (ymid_raw or "-")[:12],
                    _safe_row_get(session, "ad_control_mode"), required_ads,
                    completed_ads, status)
                if status == WATCH_AD_STATUS_REWARDED:
                    # Duplicate postback / retry: count it, never double-unlock.
                    await self.conn.execute(
                        "UPDATE watch_ad_sessions SET reward_count = reward_count + 1 "
                        "WHERE id = ?", (sid,))
                    await self.conn.execute("COMMIT")
                    result["result"] = "duplicate"
                    result["complete"] = True
                    result["completed_ads"] = required_ads
                    result["unlock_expires_at"] = session["unlock_expires_at"]
                    await self._log_access_event_locked(
                        "ad_reward_duplicate",
                        payload_id=result["payload_id"], user_id=result["user_id"])
                    logger.info("WATCH_AD_POSTBACK_DUPLICATE session=%s token=%s… "
                                "reason=already_rewarded (idempotent, no double "
                                "count / no double unlock)", sid, token[:6])
                    return result
                if status == WATCH_AD_STATUS_EXPIRED:
                    await self.conn.execute("ROLLBACK")
                    result["result"] = "expired"
                    return result
                if status == WATCH_AD_STATUS_REJECTED:
                    await self.conn.execute("ROLLBACK")
                    result["result"] = "rejected"
                    return result
                # Pending: check session TTL.
                if session["expires_at"] and session["expires_at"] <= now_iso:
                    await self.conn.execute(
                        "UPDATE watch_ad_sessions SET status = ? WHERE id = ?",
                        (WATCH_AD_STATUS_EXPIRED, sid))
                    await self.conn.execute("COMMIT")
                    result["result"] = "expired"
                    await self._log_access_event_locked("ad_unlock_expired",
                                                payload_id=result["payload_id"],
                                                user_id=result["user_id"])
                    return result
                # Payload must still exist, be active, and have Watch Ads ON.
                payload = await self.get_payload_by_id(result["payload_id"])
                if (not payload or payload["status"] != "active"
                        or not _safe_row_get(payload, "watch_ads_enabled")):
                    await self.conn.execute(
                        "UPDATE watch_ad_sessions SET status = ? WHERE id = ?",
                        (WATCH_AD_STATUS_REJECTED, sid))
                    await self.conn.execute("COMMIT")
                    result["result"] = "inactive"
                    await self._log_access_event_locked("ad_unlock_rejected",
                                                payload_id=result["payload_id"],
                                                user_id=result["user_id"])
                    logger.info("WATCH_AD_PAYLOAD_INACTIVE session=%s payload=%s "
                                "user=%s reason=payload_missing_or_disabled "
                                "— no unlock granted", sid, result["payload_id"],
                                result["user_id"])
                    return result
                # Cross-user usage: Monetag's telegram_id must match the owner.
                if telegram_id is not None and str(telegram_id).isdigit() \
                        and int(telegram_id) != int(session["user_id"]):
                    await self.conn.execute(
                        "UPDATE watch_ad_sessions SET status = ? WHERE id = ?",
                        (WATCH_AD_STATUS_REJECTED, sid))
                    await self.conn.execute("COMMIT")
                    result["result"] = "rejected"
                    await self._log_access_event_locked("ad_unlock_rejected",
                                                payload_id=result["payload_id"],
                                                user_id=result["user_id"])
                    logger.warning(
                        "WATCH_AD_CROSS_USER session=%s token=%s… owner=%s "
                        "claimed=%s reason=telegram_id_mismatch — rejected",
                        sid, token[:6], session["user_id"], telegram_id)
                    return result
                # Unpaid / fraudulent / unconfirmed traffic: do NOT reward.
                # ONLY an explicit Monetag 'valued' event grants the unlock
                # (non_valued = unpaid/fraud; empty = unconfirmed — the
                # session stays pending so a later valued event can reward).
                if reward_event_type.strip().lower() != "valued":
                    await self.conn.execute("ROLLBACK")
                    result["result"] = "non_valued"
                    logger.info(
                        "WATCH_AD_POSTBACK_REJECTED session=%s token=%s… "
                        "reason=reward_event_type_not_valued value=%r "
                        "— unpaid/unconfirmed traffic never unlocks",
                        sid, token[:6], reward_event_type)
                    return result
                # ---- V2 (v26): per-ad idempotency ledger ----
                # The ymid uniquely identifies ONE provider ad inside this
                # session (token for ad 1, token_N for ad N>=2). INSERT OR
                # IGNORE + rowcount makes each distinct ad count exactly
                # once; Monetag retries (same ymid) land here as duplicates.
                ledger_ymid = (ymid_raw or token).strip()
                cur_ev = await self.conn.execute(
                    """INSERT OR IGNORE INTO watch_ad_reward_events
                       (ymid, session_id, user_id, payload_id, ad_index,
                        event_type, estimated_price, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (ledger_ymid, sid, result["user_id"], result["payload_id"],
                     int(ad_index) if ad_index else None, event_type,
                     estimated_price, now_iso))
                if cur_ev is None or cur_ev.rowcount == 0:
                    # Already-processed ymid -> duplicate (replay protection).
                    await self.conn.execute("ROLLBACK")
                    result["result"] = "duplicate"
                    await self._log_access_event_locked(
                        "ad_reward_duplicate",
                        payload_id=result["payload_id"], user_id=result["user_id"])
                    logger.info("WATCH_AD_POSTBACK_DUPLICATE session=%s token=%s… "
                                "ymid=%s reason=replayed_ymid (per-ad ledger "
                                "hit — no progress change)", sid, token[:6],
                                ledger_ymid[:12])
                    return result
                # ---- V2 (v26): accept this reward + advance progress ----
                if completed_ads >= required_ads:
                    # Defensive: progress already full but status still pending
                    # (corrupt state) — treat as duplicate, never over-count.
                    await self.conn.execute("ROLLBACK")
                    result["result"] = "duplicate"
                    logger.warning("Watch Ad reward ignored (progress already full, "
                                   "session=%s)", sid)
                    return result
                new_completed = completed_ads + 1
                complete = new_completed >= required_ads
                if complete:
                    # FINAL required reward verified: flip the session to
                    # rewarded and start the unlock window.
                    window = await self.get_setting_int(
                        "watch_ads_unlock_window", WATCH_AD_UNLOCK_WINDOW)
                    unlock_exp = (now + timedelta(seconds=max(30, int(window)))).isoformat()
                    await self.conn.execute(
                        """UPDATE watch_ad_sessions SET
                               status = ?, rewarded_at = ?, unlock_expires_at = ?,
                               reward_count = reward_count + 1,
                               completed_ads = ?, last_reward_at = ?,
                               zone_id = ?, sub_zone_id = ?, request_var = ?,
                               estimated_price = ?
                           WHERE id = ?""",
                        (WATCH_AD_STATUS_REWARDED, now_iso, unlock_exp,
                         new_completed, now_iso,
                         zone_id, sub_zone_id, request_var,
                         estimated_price, sid))
                    result["unlock_expires_at"] = unlock_exp
                else:
                    # Multi-ad session still in progress: keep status pending
                    # (the unlock is NOT granted yet — no partial unlocks).
                    await self.conn.execute(
                        """UPDATE watch_ad_sessions SET
                               reward_count = reward_count + 1,
                               completed_ads = ?, last_reward_at = ?,
                               zone_id = ?, sub_zone_id = ?, request_var = ?,
                               estimated_price = ?
                           WHERE id = ?""",
                        (new_completed, now_iso,
                         zone_id, sub_zone_id, request_var,
                         estimated_price, sid))
                await self.conn.execute("COMMIT")
                result["result"] = "rewarded"
                result["complete"] = complete
                result["completed_ads"] = new_completed
                await self._log_access_event_locked(
                    "ad_rewarded", payload_id=result["payload_id"],
                    user_id=result["user_id"])
                logger.info(
                    "WATCH_AD_REWARD_TRANSACTION_COMMIT session=%s token=%s… "
                    "user_id=%s payload_id=%s result=rewarded "
                    "ad_control_mode=%s required_ads=%s completed_ads=%s "
                    "complete=%s unlock_expires=%s",
                    sid, token[:6], result["user_id"], result["payload_id"],
                    _safe_row_get(session, "ad_control_mode"), required_ads,
                    new_completed, complete,
                    result["unlock_expires_at"] or "-")
                # WATCH_AD V5 (§34): explicit per-ad lifecycle events. The ad
                # that just verified = new_completed (1-based; the provider
                # ad_index is only a hint — ymid suffix is the authority).
                logger.info(
                    "WATCH_AD_REWARD_VERIFIED session=%s token=%s… user_id=%s "
                    "payload_id=%s ad_index=%s ymid=%s completed_ads=%s "
                    "required_ads=%s mode=%s source=server",
                    sid, token[:6], result["user_id"], result["payload_id"],
                    new_completed, (ledger_ymid or "-")[:12], new_completed,
                    required_ads,
                    _safe_row_get(session, "ad_control_mode"))
                logger.info(
                    "Watch Ad reward verified for user %s / payload %s "
                    "(event=%s value=%s zone=%s price=%s ad=%s/%s mode=%s "
                    "complete=%s unlock_expires=%s)",
                    result["user_id"], result["payload_id"], event_type,
                    reward_event_type, zone_id, estimated_price, new_completed,
                    required_ads, _safe_row_get(session, "ad_control_mode"), complete,
                    result["unlock_expires_at"] or "-",
                )
                if complete:
                    await self._log_access_event_locked(
                        "ad_unlock_granted", payload_id=result["payload_id"],
                        user_id=result["user_id"])
                    logger.info(
                        "WATCH_AD_UNLOCK session=%s token=%s… user_id=%s "
                        "payload_id=%s required_ads=%s completed_ads=%s "
                        "unlock_expires=%s reason=all_required_rewards_verified",
                        sid, token[:6], result["user_id"], result["payload_id"],
                        required_ads, new_completed,
                        result["unlock_expires_at"] or "-")
                    logger.info(
                        "WATCH_AD_FINAL_UNLOCK session=%s token=%s… user_id=%s "
                        "payload_id=%s required_ads=%s completed_ads=%s "
                        "unlock_expires=%s mode=%s source=server",
                        sid, token[:6], result["user_id"], result["payload_id"],
                        required_ads, new_completed,
                        result["unlock_expires_at"] or "-",
                        _safe_row_get(session, "ad_control_mode"))
                    logger.info(
                        "WATCH_AD_AUTO_CLOSE_READY session=%s token=%s… "
                        "user_id=%s payload_id=%s — /api/watch-ad/status now "
                        "reports 'rewarded'; the Mini App will show 'Your "
                        "payload is unlocked.' + the Continue button and "
                        "calls Telegram.WebApp.close() only on the user's "
                        "Continue tap (server-verified only, never a timer)",
                        sid, token[:6], result["user_id"], result["payload_id"])
                else:
                    # WATCH_AD V5 (§34): intermediate reward — the Mini App is
                    # expected to auto-advance to the next ad INSIDE the same
                    # session (it learns this from its next status poll).
                    logger.info(
                        "WATCH_AD_NEXT_AD session=%s token=%s… user_id=%s "
                        "payload_id=%s completed_ads=%s required_ads=%s "
                        "next_ad_index=%s next_ymid=%s mode=%s source=server",
                        sid, token[:6], result["user_id"], result["payload_id"],
                        new_completed, required_ads, new_completed + 1,
                        (token[:6] + "_" + str(new_completed + 1)),
                        _safe_row_get(session, "ad_control_mode"))
                return result
        except Exception as e:  # noqa: BLE001
            try:
                if self.conn.in_transaction:
                    await self.conn.execute("ROLLBACK")
            except Exception:  # noqa: BLE001
                pass
            logger.error(
                "WATCH_AD_REWARD_PROCESS_FAILED token=%s… ymid=%s exc=%s.%s "
                "reason=%s",
                token[:6], (ymid_raw or "-")[:12], type(e).__module__,
                type(e).__name__, e, exc_info=True)
            result["result"] = "error"
            return result

    async def count_watch_ad_payloads(self) -> int:
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM payloads WHERE watch_ads_enabled = 1")
        row = await cur.fetchone()
        return int(row["c"]) if row else 0

    async def reconcile_watch_ad_sessions(self,
                                          unlock_window: int) -> Dict[str, int]:
        """WATCH_AD V4 (v27): repair/reconcile STUCK sessions (admin control,
        confirmation-gated). Two idempotent, non-destructive repairs:

          1. pending sessions whose completed_ads ALREADY reached
             required_ads (a reward race left the status unflipped) ->
             status='rewarded' + rewarded_at/last_reward_at=now +
             unlock_expires_at=now+window. Exactly the same state the reward
             transaction itself would have written — never invents rewards.
          2. pending sessions whose TTL elapsed without the lazy-expiry paths
             running -> status='expired' (no unlock granted).

        Returns {"repaired": n, "expired": n}. Never touches rewarded/
        consumed sessions, referral data, payloads or users.
        """
        out = {"repaired": 0, "expired": 0}
        now = datetime.now(timezone.utc)
        now_iso = now.isoformat()
        unlock_exp = (now + timedelta(seconds=max(30, int(unlock_window)))).isoformat()
        try:
            async with self.write_lock:
                if self.conn.in_transaction:
                    await self.conn.execute("ROLLBACK")
                await self.conn.execute("BEGIN IMMEDIATE")
                cur = await self.conn.execute(
                    """UPDATE watch_ad_sessions
                       SET status = 'rewarded', rewarded_at = ?,
                           last_reward_at = COALESCE(last_reward_at, ?),
                           unlock_expires_at = COALESCE(unlock_expires_at, ?)
                       WHERE status = 'pending'
                         AND completed_ads >= required_ads""",
                    (now_iso, now_iso, unlock_exp))
                out["repaired"] = max(0, cur.rowcount or 0)
                cur = await self.conn.execute(
                    """UPDATE watch_ad_sessions
                       SET status = 'expired'
                       WHERE status = 'pending' AND expires_at <= ?""",
                    (now_iso,))
                out["expired"] = max(0, cur.rowcount or 0)
                await self.conn.commit()
        except Exception as e:  # noqa: BLE001
            try:
                if self.conn.in_transaction:
                    await self.conn.execute("ROLLBACK")
            except Exception:  # noqa: BLE001
                pass
            logger.error("WATCH_AD_RECONCILE_FAILED exc=%s.%s reason=%s",
                         type(e).__module__, type(e).__name__, e)
            raise
        if out["repaired"] or out["expired"]:
            logger.info("WATCH_AD_RECONCILE repaired=%s expired=%s "
                        "(admin-triggered, idempotent)",
                        out["repaired"], out["expired"])
        return out
