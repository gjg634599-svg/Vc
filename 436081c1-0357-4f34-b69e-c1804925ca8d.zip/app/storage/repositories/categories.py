"""Website CATEGORY repository (GAP-CLOSURE v33, spec §26-§29).

Categories are the professionally managed, configurable grouping layer of
the Website: Movies / Anime / 18+ / Shorts by default, fully admin-managed
(name, slug, icon, order, enabled, visibility, description, age flag).
A category membership REFERENCES an existing ``website_payloads`` listing
row — media is NEVER duplicated and the canonical Payload stays the single
authority (spec §27).

18+ protection (spec §29): ``age_restricted`` is a BACKEND property. The
category-filtered feed and the generic feed REFUSE age-restricted listings
unless the caller explicitly passes ``include_age_restricted=True`` (the
presentation layer only sets that after a confirmed age gate tied to the
AUTHENTICATED identity) — hiding the category in the frontend is never the
only protection.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Optional, Tuple

import aiosqlite

from app.storage.dbutil import now_iso as _now_iso

logger = logging.getLogger("payload-bot")

# Editable category columns (whitelist — never built from user input).
_CATEGORY_EDITABLE_FIELDS = frozenset({
    "name", "slug", "icon", "sort_order", "enabled", "visible",
    "description", "age_restricted",
})

_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,40}$")


def _valid_slug(slug: str) -> bool:
    return bool(_SLUG_RE.match(str(slug or "").strip().lower()))


def _norm_slug(slug: str) -> str:
    s = str(slug or "").strip().lower()
    s = re.sub(r"[^a-z0-9-]+", "-", s).strip("-")
    return s[:40]


class WebsiteCategoriesRepoMixin:
    """website_categories + website_payload_categories (v33)."""

    # ------------------------------------------------------------- CRUD
    async def create_website_category(
        self, *, name: str, slug: str, icon: str = "",
        sort_order: int = 0, enabled: int = 1, visible: int = 1,
        description: str = "", age_restricted: int = 0,
    ) -> Optional[int]:
        """Create a category; returns the new id (None on conflicts)."""
        name = str(name or "").strip()[:60]
        slug = _norm_slug(slug)
        if not name or not _valid_slug(slug):
            return None
        now = _now_iso()
        try:
            cur = await self.conn.execute(
                """INSERT INTO website_categories
                   (name, slug, icon, sort_order, enabled, visible,
                    description, age_restricted, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (name, slug, str(icon or "")[:16], int(sort_order or 0),
                 1 if int(enabled) else 0, 1 if int(visible) else 0,
                 str(description or "")[:500],
                 1 if int(age_restricted) else 0, now, now))
            await self.conn.commit()
            return int(cur.lastrowid)
        except aiosqlite.IntegrityError:
            return None  # duplicate slug

    async def get_website_category_by_slug(
            self, slug: str) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM website_categories WHERE slug = ?",
            (str(slug or "").strip().lower(),))
        return await cur.fetchone()

    async def get_website_category(
            self, category_id: int) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM website_categories WHERE id = ?",
            (int(category_id),))
        return await cur.fetchone()

    async def list_website_categories(
            self, *, include_disabled: bool = False
    ) -> List[aiosqlite.Row]:
        cond = "" if include_disabled else "WHERE enabled = 1"
        cur = await self.conn.execute(
            f"SELECT * FROM website_categories {cond} "
            "ORDER BY sort_order ASC, id ASC")
        return list(await cur.fetchall())

    async def update_website_category_fields(
            self, category_id: int, fields: Dict[str, Any]) -> bool:
        """Update whitelisted category fields only."""
        if not fields:
            return False
        allowed = {k: v for k, v in fields.items()
                   if k in _CATEGORY_EDITABLE_FIELDS}
        if not allowed:
            return False
        if "slug" in allowed:
            allowed["slug"] = _norm_slug(allowed["slug"])
            if not _valid_slug(allowed["slug"]):
                return False
        if "name" in allowed:
            allowed["name"] = str(allowed["name"] or "").strip()[:60]
            if not allowed["name"]:
                return False
        sets = ", ".join(f"{k} = ?" for k in allowed)
        params = list(allowed.values())
        try:
            await self.conn.execute(
                f"UPDATE website_categories SET {sets}, updated_at = ? "
                "WHERE id = ?",
                [*params, _now_iso(), int(category_id)])
            await self.conn.commit()
            return True
        except aiosqlite.IntegrityError:
            return False

    async def delete_website_category(self, category_id: int) -> bool:
        """Delete a category + its memberships (never listings/media)."""
        try:
            await self.conn.execute(
                "DELETE FROM website_payload_categories WHERE category_id = ?",
                (int(category_id),))
            await self.conn.execute(
                "DELETE FROM website_categories WHERE id = ?",
                (int(category_id),))
            await self.conn.commit()
            return True
        except Exception as exc:  # noqa: BLE001
            logger.warning("delete category failed: %s", exc)
            return False

    # ------------------------------------------------- membership mgmt
    async def set_website_payload_categories(
            self, listing_id: int, category_ids: List[int]) -> bool:
        """REPLACE the category membership set of one listing (spec §27:
        assign EXISTING payloads to categories — never duplicating media)."""
        try:
            await self.conn.execute(
                "DELETE FROM website_payload_categories WHERE listing_id = ?",
                (int(listing_id),))
            for pos, cid in enumerate(category_ids or []):
                await self.conn.execute(
                    """INSERT OR IGNORE INTO website_payload_categories
                       (listing_id, category_id, position, created_at)
                       VALUES (?, ?, ?, ?)""",
                    (int(listing_id), int(cid), int(pos), _now_iso()))
            await self.conn.commit()
            return True
        except Exception as exc:  # noqa: BLE001
            logger.warning("set listing categories failed: %s", exc)
            return False

    async def add_website_payload_to_category(
            self, listing_id: int, category_id: int,
            position: Optional[int] = None) -> bool:
        try:
            # B23-3 (5.10): the outer COALESCE's third argument was
            # unreachable — the inner subselect is itself COALESCEd
            # (MAX(position)+1 on an EMPTY category → 0), so it can never
            # return NULL. Two-arg form; ordering semantics unchanged
            # (first insert into a category lands at position 0).
            cur = await self.conn.execute(
                """INSERT OR IGNORE INTO website_payload_categories
                   (listing_id, category_id, position, created_at)
                   VALUES (?, ?, COALESCE(?, (
                       SELECT COALESCE(MAX(position) + 1, 0) FROM
                       website_payload_categories WHERE category_id = ?
                   )), ?)""",
                (int(listing_id), int(category_id), position,
                 int(category_id), _now_iso()))
            await self.conn.commit()
            return bool(cur.rowcount)
        except Exception as exc:  # noqa: BLE001
            logger.warning("add listing to category failed: %s", exc)
            return False

    async def remove_website_payload_from_category(
            self, listing_id: int, category_id: int) -> bool:
        try:
            cur = await self.conn.execute(
                "DELETE FROM website_payload_categories "
                "WHERE listing_id = ? AND category_id = ?",
                (int(listing_id), int(category_id)))
            await self.conn.commit()
            return bool(cur.rowcount)
        except Exception as exc:  # noqa: BLE001
            logger.warning("remove listing from category failed: %s", exc)
            return False

    async def list_website_categories_for_listing(
            self, listing_id: int) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            """SELECT c.* FROM website_payload_categories m
               JOIN website_categories c ON c.id = m.category_id
               WHERE m.listing_id = ?
               ORDER BY m.position ASC, c.sort_order ASC""",
            (int(listing_id),))
        return list(await cur.fetchall())

    async def list_website_listing_ids_for_category(
            self, category_id: int, *, limit: int = 500
    ) -> List[int]:
        cur = await self.conn.execute(
            """SELECT m.listing_id FROM website_payload_categories m
               WHERE m.category_id = ? ORDER BY m.position ASC, m.listing_id
               DESC LIMIT ?""",
            (int(category_id), int(limit)))
        return [int(r["listing_id"]) for r in await cur.fetchall()]

    async def category_payload_counts(self) -> Dict[int, int]:
        """listing count per category id (admin views)."""
        cur = await self.conn.execute(
            """SELECT category_id, COUNT(*) AS n FROM
               website_payload_categories GROUP BY category_id""")
        return {int(r["category_id"]): int(r["n"])
                for r in await cur.fetchall()}
