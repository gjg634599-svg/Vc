"""indexed files, storage channels and reindex cursor state — media repository (ARCHITECTURE PHASE).

Verbatim method bodies extracted from the legacy ``Database`` class in
bot.py; SQL, transactions, locking and concurrency behavior unchanged.
Composed into ``app.storage.database.DatabaseBase``.
"""
from __future__ import annotations

import aiosqlite
import hashlib
import logging
from typing import Any, Dict, List, Optional, Set, Tuple
from app.storage.dbutil import now_iso as _now_iso
from app.core.payload.service import sanitize_slug as _sanitize_slug

logger = logging.getLogger("payload-bot")


def _uid_hash16(value: Any) -> str:
    """BOT-43: short stable digest of a raw Telegram file id for SAFE
    telemetry (sha256 hex[:16]) — raw file_id / file_unique_id values are
    NEVER logged."""
    try:
        return hashlib.sha256(
            str(value or "").encode("utf-8", "replace")).hexdigest()[:16]
    except Exception:  # noqa: BLE001 — hashing must never break the caller
        return "-"


class MediaRepoMixin:
    """indexed files, storage channels and reindex cursor state."""

    async def add_indexed_file(
        self, channel_id: int, message_id: int, info: Dict[str, Any]
    ) -> int:
        now = _now_iso()
        cur = await self.conn.execute(
            """
            INSERT INTO indexed_files
                (channel_id, message_id, file_id, file_unique_id, file_name, caption,
                 media_type, file_size, duration, upload_date, views, downloads,
                 mime_type, width, height, thumb_file_id, thumb_file_unique_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?, ?, ?, ?)
            """,
            (
                channel_id,
                message_id,
                info["file_id"],
                info.get("file_unique_id"),
                info.get("file_name"),
                info.get("caption"),
                info.get("media_type"),
                info.get("file_size"),
                info.get("duration"),
                now,
                # WEBSITE PHASE 2 (v30 part A): additive richer metadata —
                # legacy 7-key callers persist NULL here (never fabricated).
                info.get("mime_type"),
                info.get("width"),
                info.get("height"),
                info.get("thumb_file_id"),
                info.get("thumb_file_unique_id"),
            ),
        )
        await self.conn.commit()
        return int(cur.lastrowid)
    async def update_indexed_file(self, file_pk: int, info: Dict[str, Any]) -> None:
        # V26.2 (bot-41 §5): IDENTITY HARDENING — the canonical Telegram
        # media identity (file_unique_id) must survive filename/caption/
        # title changes and may never be NULLed by a partial info dict.
        # The full-refresh semantics stay for every mutable column, but a
        # missing/empty file_unique_id in ``info`` now PRESERVES the stored
        # identity instead of overwriting it with NULL (the latent hazard
        # the bot-41 investigation flagged on this full-row writer).
        _fresh_unique = str(info.get("file_unique_id") or "").strip()
        if not _fresh_unique:
            await self.conn.execute(
                """
                UPDATE indexed_files SET
                    file_id       = ?,
                    file_name     = ?,
                    caption       = ?,
                    media_type    = ?,
                    file_size     = ?,
                    duration      = ?,
                    mime_type     = ?,
                    width         = ?,
                    height        = ?,
                    thumb_file_id = ?,
                    thumb_file_unique_id = ?
                WHERE id = ?
                """,
                (
                    info["file_id"],
                    info.get("file_name"),
                    info.get("caption"),
                    info.get("media_type"),
                    info.get("file_size"),
                    info.get("duration"),
                    info.get("mime_type"),
                    info.get("width"),
                    info.get("height"),
                    info.get("thumb_file_id"),
                    info.get("thumb_file_unique_id"),
                    file_pk,
                ),
            )
            await self.conn.commit()
            return
        await self.conn.execute(
            """
            UPDATE indexed_files SET
                file_id       = ?,
                file_unique_id = ?,
                file_name     = ?,
                caption       = ?,
                media_type    = ?,
                file_size     = ?,
                duration      = ?,
                mime_type     = ?,
                width         = ?,
                height        = ?,
                thumb_file_id = ?,
                thumb_file_unique_id = ?
            WHERE id = ?
            """,
            (
                info["file_id"],
                _fresh_unique,
                info.get("file_name"),
                info.get("caption"),
                info.get("media_type"),
                info.get("file_size"),
                info.get("duration"),
                # WEBSITE PHASE 2 (v30 part A): the edited-message path is a
                # full refresh (same semantics as the pre-v30 columns): the
                # fresh source values win, including NULLs (the message's
                # media may have changed type).
                info.get("mime_type"),
                info.get("width"),
                info.get("height"),
                info.get("thumb_file_id"),
                info.get("thumb_file_unique_id"),
                file_pk,
            ),
        )
        await self.conn.commit()

    # V26 Phase 8 — the mutable-metadata refresh contract (column, info key)
    _MUTABLE_META_FIELDS: Tuple[Tuple[str, str], ...] = (
        ("file_name", "file_name"),
        ("caption", "caption"),
        ("file_size", "file_size"),
        ("duration", "duration"),
        ("mime_type", "mime_type"),
        ("width", "width"),
        ("height", "height"),
        ("thumb_file_id", "thumb_file_id"),
        ("thumb_file_unique_id", "thumb_file_unique_id"),
    )

    @staticmethod
    def _mutable_meta_differs(cur: Any, fresh: Any) -> bool:
        """Value comparison for the mutable-metadata refresh: numerics
        compare numerically (int 1000 == str '1000' — no phantom rewrite),
        everything else compares as text; None never reaches here."""
        if cur is None or fresh is None:
            return True
        try:
            if isinstance(cur, (int, float)) or isinstance(fresh, (int, float)):
                return float(cur) != float(fresh)
        except (TypeError, ValueError):
            pass
        return str(cur) != str(fresh)

    async def refresh_indexed_file_mutable_metadata(
            self, file_pk: int,
            info: Dict[str, Any]) -> Dict[str, Tuple[Any, Any]]:
        """V26 Phase 8 — refresh the MUTABLE metadata of an EXISTING
        canonical indexed row from a freshly-fetched source message (the
        reindex duplicate path).

        Production bug this fixes: filename X → the Telegram message was
        edited to rename the file to Y → reindex → the system still
        showed X. The reindex treated an exact-identity duplicate as a
        blind skip (the batch insert is INSERT OR IGNORE and the metadata
        backfill only fills NULLs), so an EDITED filename/caption/size
        never reached the canonical row — and that one row feeds the
        Payload Manager, the website cards/player and the delivery zip.

        Identity discipline (the canonical contract):
          * IMMUTABLE — never written here: id (pk), file_id, file_unique_id,
            channel_id, message_id, upload_date, views/downloads, payload
            references (file_id freshness is repaired separately by
            repair_indexed_file_file_id BEFORE this runs; the canonical
            source reference may only move through the guarded Scenario-B
            repoint path).
          * MUTABLE — refreshed from the fresh source, PRESENT values only:
            file_name, caption, file_size, duration, mime_type, width,
            height, thumb_file_id, thumb_file_unique_id. A fresh None NEVER
            erases a known value (a partial fetch must not destroy
            metadata — the same discipline as backfill_indexed_file_metadata).

        Returns the changes actually applied as ``{column: (old, new)}``
        (an EMPTY dict = nothing changed — an idempotent no-op).
        """
        row = await self.get_indexed_file_by_id(int(file_pk))
        if row is None:
            return {}
        cur_vals: Dict[str, Any] = dict(row) if not isinstance(row, dict) \
            else row
        changes: Dict[str, Tuple[Any, Any]] = {}
        for col, key in self._MUTABLE_META_FIELDS:
            fresh = info.get(key)
            if fresh is None:
                continue  # never erase known metadata with a partial fetch
            cur = cur_vals.get(col)
            if self._mutable_meta_differs(cur, fresh):
                changes[col] = (cur, fresh)
        if not changes:
            return {}
        sets = ", ".join(f"{col} = ?" for col in changes)
        params: List[Any] = [new for (_, new) in changes.values()]
        params.append(int(file_pk))
        async with self.write_lock:
            await self.conn.execute(
                f"UPDATE indexed_files SET {sets} WHERE id = ?", params)
            await self.conn.commit()
        return changes

    async def replace_indexed_source_media(
            self, file_pk: int, info: Dict[str, Any]) -> bool:
        """BOT-43 (SOURCE_MEDIA_REPLACEMENT): the guarded IN-PLACE media swap
        for a canonical indexed row whose SOURCE message now carries a
        DIFFERENT media object (same channel_id + message_id, NEW
        file_unique_id — the admin replaced the file in the edited post).

        Called ONLY by :meth:`attempt_source_media_replacement` after every
        guard passed. What is PRESERVED (never written here): id (pk),
        channel_id, message_id, upload_date, views, downloads,
        source_status / prev_* re-point history and EVERY payload
        foreign-key reference (the row is UPDATED in place, never
        re-inserted — that is what keeps payload FKs resolving).
        What is UPDATED from the fresh source fetch: file_id,
        file_unique_id, file_name, caption, media_type, file_size,
        duration, mime_type, width, height, thumb_file_id,
        thumb_file_unique_id. Identity fields are never blanked:
        file_id / file_unique_id / media_type / file_name / file_size come
        from ``info`` (the caller guarded them non-empty); the optional
        metadata fields keep the STORED value when the fresh fetch has
        none (COALESCE — a partial fetch never destroys metadata).

        Returns True when the row actually changed.
        """
        _fresh_uid = str(info.get("file_unique_id") or "").strip()
        _fresh_fid = str(info.get("file_id") or "").strip()
        _fresh_mtype = str(info.get("media_type") or "").strip()
        if not (_fresh_uid and _fresh_fid and _fresh_mtype):
            return False  # never blank out identity fields
        async with self.write_lock:
            cur = await self.conn.execute(
                """
                UPDATE indexed_files SET
                    file_id = ?,
                    file_unique_id = ?,
                    file_name = ?,
                    caption = COALESCE(?, caption),
                    media_type = ?,
                    file_size = ?,
                    duration = COALESCE(?, duration),
                    mime_type = COALESCE(?, mime_type),
                    width = COALESCE(?, width),
                    height = COALESCE(?, height),
                    thumb_file_id = COALESCE(?, thumb_file_id),
                    thumb_file_unique_id = COALESCE(?, thumb_file_unique_id)
                WHERE id = ?
                """,
                (
                    _fresh_fid,
                    _fresh_uid,
                    info.get("file_name"),
                    info.get("caption"),
                    _fresh_mtype,
                    info.get("file_size"),
                    info.get("duration"),
                    info.get("mime_type"),
                    info.get("width"),
                    info.get("height"),
                    info.get("thumb_file_id"),
                    info.get("thumb_file_unique_id"),
                    int(file_pk),
                ),
            )
            await self.conn.commit()
            try:
                return bool(cur.rowcount)
            except Exception:  # noqa: BLE001 — rowcount unavailable
                return False

    async def attempt_source_media_replacement(
            self, channel_id: int, message_id: int, info: Dict[str, Any],
            known_unique_ids: Optional[Set[str]] = None) -> bool:
        """BOT-43 (SOURCE_MEDIA_REPLACEMENT): the guarded orchestration for
        the SAME-SOURCE / NEW-IDENTITY case (production bot-43 evidence:
        same channel_id+message_id with a NEW file_unique_id silently
        INSERTED A SECOND indexed_files row — only UNIQUE(file_unique_id)
        exists — and ``get_indexed_file_by_channel_message`` kept serving
        the OLD identity forever).

        A replacement is attempted ONLY when ALL of these hold (otherwise
        the honest skip is logged and False is returned so the caller falls
        through to the NORMAL insert path — the UNIQUE(file_unique_id)
        semantics stay intact):
          * a canonical row exists for the EXACT (channel_id, message_id)
            (ORDER BY id ASC);
          * that row has a stored, non-empty file_unique_id (NULL
            identities belong to the identity-REPAIR path, never here);
          * the fresh fetch carries a DIFFERENT, non-empty file_unique_id
            (a same-identity fetch is the plain duplicate path);
          * the fresh media_type and file_id are present and non-empty;
          * the row's stored (channel_id, message_id) EXACTLY equals the
            scanned pair (asserted — the lookup guarantees it);
          * the NEW file_unique_id is not already owned by ANOTHER row
            (identity conflict → INDEX_REPLACE_SOURCE_MEDIA_FAILED
            reason=identity_conflict, NO replacement).

        On success the canonical row is swapped in place
        (:meth:`replace_indexed_source_media`) and, in batched scans, the
        preload set semantics are maintained: ``known_unique_ids.discard(
        old_uid)`` + ``known_unique_ids.add(new_uid)`` so a later message
        in the SAME scan carrying the OLD uid re-inserts as a genuinely
        new canonical row and one carrying the NEW uid dedups correctly.

        Telemetry (INFO, ids hashed — raw file ids never logged):
          INDEX_REPLACE_SOURCE_MEDIA_START / _COMPLETE / _FAILED /
          _SKIPPED. Returns True iff the row was replaced.
        """
        if not info:
            return False
        try:
            canon = await self.get_indexed_file_by_channel_message(
                int(channel_id), int(message_id))
            if canon is None:
                return False  # genuinely new source message — normal insert
            file_pk = int(canon["id"])
            old_uid = str(canon["file_unique_id"] or "").strip()
            new_uid = str(info.get("file_unique_id") or "").strip()
            new_fid = str(info.get("file_id") or "").strip()
            new_mtype = str(info.get("media_type") or "").strip()
            old_name = canon["file_name"]
            new_name = info.get("file_name")
            if not old_uid:
                logger.info(
                    "INDEX_REPLACE_SOURCE_MEDIA_SKIPPED channel_id=%s "
                    "message_id=%s file_pk=%s reason=no_stored_identity "
                    "(NULL identities belong to the identity-repair path)",
                    int(channel_id), int(message_id), file_pk)
                return False
            if not new_uid:
                logger.info(
                    "INDEX_REPLACE_SOURCE_MEDIA_SKIPPED channel_id=%s "
                    "message_id=%s file_pk=%s reason=missing_fresh_identity",
                    int(channel_id), int(message_id), file_pk)
                return False
            if new_uid == old_uid:
                logger.info(
                    "INDEX_REPLACE_SOURCE_MEDIA_SKIPPED channel_id=%s "
                    "message_id=%s file_pk=%s reason=same_identity "
                    "(the exact-identity duplicate path owns this)",
                    int(channel_id), int(message_id), file_pk)
                return False
            if not new_mtype:
                logger.info(
                    "INDEX_REPLACE_SOURCE_MEDIA_SKIPPED channel_id=%s "
                    "message_id=%s file_pk=%s reason=missing_media_type",
                    int(channel_id), int(message_id), file_pk)
                return False
            if not new_fid:
                logger.info(
                    "INDEX_REPLACE_SOURCE_MEDIA_SKIPPED channel_id=%s "
                    "message_id=%s file_pk=%s reason=missing_fresh_file_id",
                    int(channel_id), int(message_id), file_pk)
                return False
            if (int(canon["channel_id"]) != int(channel_id)
                    or int(canon["message_id"]) != int(message_id)):
                # Defense in depth — the lookup predicate guarantees it.
                logger.info(
                    "INDEX_REPLACE_SOURCE_MEDIA_SKIPPED channel_id=%s "
                    "message_id=%s file_pk=%s reason=source_pair_mismatch",
                    int(channel_id), int(message_id), file_pk)
                return False
            # The NEW identity must not be owned by ANOTHER row.
            owner = await self.get_indexed_file_by_unique_id(new_uid)
            if owner is not None and int(owner["id"]) != file_pk:
                logger.info(
                    "INDEX_REPLACE_SOURCE_MEDIA_FAILED channel_id=%s "
                    "message_id=%s file_pk=%s reason=identity_conflict "
                    "(the new file_unique_id is already owned by "
                    "file_pk=%s — the UNIQUE(file_unique_id) semantics "
                    "stay intact; falling through to the normal path)",
                    int(channel_id), int(message_id), file_pk,
                    int(owner["id"]))
                return False
            logger.info(
                "INDEX_REPLACE_SOURCE_MEDIA_START channel_id=%s "
                "message_id=%s file_pk=%s old_file_unique_id_hash=%s "
                "new_file_unique_id_hash=%s old_filename=%r "
                "new_filename=%r",
                int(channel_id), int(message_id), file_pk,
                _uid_hash16(old_uid), _uid_hash16(new_uid),
                old_name, new_name)
            replaced = await self.replace_indexed_source_media(file_pk, info)
            if not replaced:
                logger.info(
                    "INDEX_REPLACE_SOURCE_MEDIA_FAILED channel_id=%s "
                    "message_id=%s file_pk=%s reason=no_row_change "
                    "(concurrent writer? canonical state wins)",
                    int(channel_id), int(message_id), file_pk)
                return False
            logger.info(
                "INDEX_REPLACE_SOURCE_MEDIA_COMPLETE channel_id=%s "
                "message_id=%s file_pk=%s old_file_unique_id_hash=%s "
                "new_file_unique_id_hash=%s old_filename=%r "
                "new_filename=%r result=ok (the canonical row was updated "
                "in place — pk, payload references and stats preserved)",
                int(channel_id), int(message_id), file_pk,
                _uid_hash16(old_uid), _uid_hash16(new_uid),
                old_name, new_name)
            # Batched-scan preload semantics: the OLD uid is gone from
            # THIS scan's perspective; the NEW uid must dedup correctly.
            if known_unique_ids is not None:
                known_unique_ids.discard(old_uid)
                known_unique_ids.add(new_uid)
            return True
        except Exception as e:  # noqa: BLE001 — replacement never breaks the scan
            logger.info(
                "INDEX_REPLACE_SOURCE_MEDIA_FAILED channel_id=%s "
                "message_id=%s file_pk=- reason=%s (falling through to "
                "the normal insert path)",
                int(channel_id), int(message_id), type(e).__name__)
            return False

    async def propagate_renamed_file_defaults(
            self, index_pk: int, old_name: Any, new_name: Any
    ) -> Dict[str, List[int]]:
        """BOT-43 (§B): propagate an EDITED filename to the DERIVED display
        defaults — never over an admin-curated value.

        Called by the indexing layer right after a mutable-metadata refresh
        that changed ``file_name``. Two derived layers, ONE transaction:

        1. ``payloads.display_name`` — for payloads pointing at this
           ``index_id``: when display_name is NULL/empty OR equals
           ``sanitize_slug(old_name)`` (the auto-payload creation default),
           it is updated to ``sanitize_slug(new_name)``.
        2. ``website_payloads.title`` — for listings created from a SINGLE
           payload (``payload_id`` set, ``collection_id`` NULL) whose title
           still equals the OLD file_name-derived default: a title equal to
           the RAW old filename becomes the RAW new filename; a title equal
           to ``sanitize_slug(old_name)`` — or NULL/empty — becomes
           ``sanitize_slug(new_name)``. Collection/package listings
           (``collection_id`` set) are NEVER touched — their title is the
           admin-curated package display name.

        Returns ``{"payload_ids": [...], "listing_ids": [...]}`` (the rows
        actually updated; empty lists = nothing was a derived default).
        """
        _old_name = str(old_name or "").strip()
        _new_name = str(new_name or "").strip()
        if not _old_name or not _new_name or _old_name == _new_name:
            return {"payload_ids": [], "listing_ids": []}
        old_slug = _sanitize_slug(_old_name)
        new_slug = _sanitize_slug(_new_name)
        now = _now_iso()
        payload_ids: List[int] = []
        listing_ids: List[int] = []
        async with self.write_lock:
            try:
                if self.conn.in_transaction:
                    logger.warning(
                        "propagate_renamed_file_defaults: in_transaction on "
                        "entry — safety ROLLBACK.")
                    await self.conn.execute("ROLLBACK")
            except Exception:  # noqa: BLE001
                pass
            try:
                await self.conn.execute("BEGIN IMMEDIATE")
                # 1) payloads.display_name — only the creation default.
                if new_slug:
                    cur = await self.conn.execute(
                        "SELECT id FROM payloads WHERE index_id = ? AND "
                        "(display_name IS NULL OR display_name = '' OR "
                        "display_name = ?) ORDER BY id ASC",
                        (int(index_pk), old_slug))
                    rows = await cur.fetchall()
                    payload_ids = [int(r["id"]) for r in rows]
                    if payload_ids:
                        await self.conn.executemany(
                            "UPDATE payloads SET display_name = ? WHERE id = ?",
                            [(new_slug, pid) for pid in payload_ids])
                # 2) website_payloads.title — single-payload listings only.
                cur = await self.conn.execute(
                    "SELECT w.id AS wid, w.title AS title FROM "
                    "website_payloads w JOIN payloads p ON p.id = w.payload_id "
                    "WHERE p.index_id = ? AND w.collection_id IS NULL "
                    "ORDER BY w.id ASC",
                    (int(index_pk),))
                rows = await cur.fetchall()
                title_updates: List[Tuple[str, int]] = []
                for r in rows:
                    title = r["title"]
                    if title is None or str(title).strip() == "":
                        if new_slug:
                            title_updates.append((new_slug, int(r["wid"])))
                    elif str(title) == old_slug:
                        if new_slug:
                            title_updates.append((new_slug, int(r["wid"])))
                    elif str(title) == _old_name:
                        title_updates.append((_new_name, int(r["wid"])))
                    # any OTHER value = admin-curated — NEVER touched
                listing_ids = [wid for (_, wid) in title_updates]
                if title_updates:
                    await self.conn.executemany(
                        "UPDATE website_payloads SET title = ?, updated_at = ? "
                        "WHERE id = ?",
                        [(t, now, wid) for (t, wid) in title_updates])
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001 — propagation is best-effort
                try:
                    await self.conn.execute("ROLLBACK")
                except Exception:  # noqa: BLE001
                    pass
                logger.error("propagate_renamed_file_defaults(%s) failed: %s",
                             int(index_pk), e)
                return {"payload_ids": [], "listing_ids": []}
        return {"payload_ids": payload_ids, "listing_ids": listing_ids}

    async def repair_indexed_file_file_id(self, file_pk: int, fresh_file_id: str) -> bool:
        """PHASE 7 HOTFIX: atomically refresh a CANONICAL indexed file's
        file_id after a bot-token change (or any proven-stale id).

        Identity discipline (hotfix contract):
          * ONLY the file_id column changes — the id (pk), file_unique_id,
            channel_id/message_id (source recovery reference), media_type,
            file_name, stats and every payload foreign-key reference are
            PRESERVED. The canonical row is never replaced or re-inserted.
          * file_unique_id is a dedup/identity value and is NEVER written to
            the file_id column (it is not sendable).
          * The caller must only pass a file_id freshly obtained by the
            CURRENT bot from the file's original source message (verified
            against file_unique_id / media_type by the recovery helpers).
          * The UPDATE is guarded (file_id IS NOT ?) and runs under the DB
            write lock, so concurrent delivery/indexing repairs converge
            idempotently: the second writer sees the row already current.
        Returns True when the row actually changed (was stale).
        """
        if not fresh_file_id:
            return False
        async with self.write_lock:
            cur = await self.conn.execute(
                "UPDATE indexed_files SET file_id = ? WHERE id = ? AND file_id IS NOT ?",
                (str(fresh_file_id), int(file_pk), str(fresh_file_id)),
            )
            await self.conn.commit()
            try:
                return bool(cur.rowcount)
            except Exception:  # noqa: BLE001 — rowcount unavailable
                return False
    async def get_indexed_file_by_id(self, index_id: int) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM indexed_files WHERE id = ?", (index_id,)
        )
        return await cur.fetchone()
    async def list_indexed_files_missing_identity(
            self, limit: int = 50) -> List[aiosqlite.Row]:
        """V26.2 (bot-41 §5/§6): rows whose canonical Telegram media
        identity is NULL/empty (the bot-41 ``file_unique_id=-`` shape).
        Ordered oldest-first so a bounded repair pass is deterministic."""
        cur = await self.conn.execute(
            """
            SELECT id, channel_id, message_id, file_name, media_type,
                   file_size
            FROM indexed_files
            WHERE file_unique_id IS NULL OR file_unique_id = ''
            ORDER BY id ASC LIMIT ?
            """,
            (int(limit),),
        )
        return await cur.fetchall()
    async def repair_indexed_file_identity(
            self, file_pk: int, fresh_file_unique_id: str) -> str:
        """V26.2 (bot-41 §6): SAFE media identity backfill for a canonical
        indexed row whose file_unique_id is NULL/empty.

        Identity discipline (mirrors repair_indexed_file_file_id):
          * the UPDATE is GUARDED — it only fills a missing identity
            (``file_unique_id IS NULL OR file_unique_id = ''``); an
            existing identity is NEVER overwritten (Telegram itself must
            provide a genuinely different media object for an identity
            change — handled by reindexing, never by this method);
          * the CALLER must verify the fresh identity was obtained from
            the row's OWN (channel_id, message_id) via the existing
            Telegram fetch mechanism, and that it is not already owned
            by a DIFFERENT row (identity conflict);
          * only the file_unique_id column changes — pk, source refs,
            payload references, stats and metadata are all preserved.
        Returns "repaired" | "already_present" | "not_found".
        """
        _fresh = str(fresh_file_unique_id or "").strip()
        if not _fresh:
            return "not_found"
        async with self.write_lock:
            cur = await self.conn.execute(
                """
                UPDATE indexed_files SET file_unique_id = ?
                WHERE id = ?
                  AND (file_unique_id IS NULL OR file_unique_id = '')
                """,
                (_fresh, int(file_pk)),
            )
            await self.conn.commit()
            try:
                if bool(cur.rowcount):
                    return "repaired"
            except Exception:  # noqa: BLE001 — rowcount unavailable
                pass
            row = await self.get_indexed_file_by_id(int(file_pk))
            if row is None:
                return "not_found"
            return ("already_present" if str(
                row["file_unique_id"] or "").strip() == _fresh
                else "identity_divergent")
    async def repoint_indexed_file_source(self, file_pk: int,
                                          new_channel_id: int,
                                          new_message_id: int,
                                          info: Dict[str, Any]) -> bool:
        """V25 (§2/§3 — bot-31.log Scenario B): re-point a CANONICAL indexed
        file to a NEW storage message carrying the SAME file identity.

        Preconditions enforced by the CALLER (indexing.py):
          * the canonical row's OLD source message was CONFIRMED deleted
            (probe returned False — never a transient verdict);
          * the fresh media info comes from the new message and its
            file_unique_id matches the canonical row's identity (exact
            Telegram identity), with a matching media_type.

        What changes (and what NEVER changes):
          * channel_id/message_id -> the new usable storage reference;
          * file_id -> the fresh current-bot transport reference;
          * caption/file_name/file_size/duration + rich metadata ->
            refreshed from the new source message;
          * source_status -> 'available' (the new source exists), with
            source_verified_at = now;
          * prev_channel_id/prev_message_id/repointed_at -> the PREVIOUS
            reference is PRESERVED (the historical relationship survives);
          * the row id (pk), file_unique_id, upload_date, views/downloads
            and EVERY payload foreign-key reference are UNTOUCHED — this is
            the property that makes re-pointing safe: payloads keep pointing
            at the same canonical row, which is now deliverable again.

        Idempotence: re-pointing to the same (channel, message) twice is a
        no-op for the reference columns (the prev_* history keeps the FIRST
        original reference, not an echo of the current one).
        Returns True when the row actually changed.
        """
        if not info or not info.get("file_id"):
            return False
        now = _now_iso()
        async with self.write_lock:
            cur = await self.conn.execute(
                "UPDATE indexed_files SET "
                "  channel_id = ?, message_id = ?, file_id = ?, "
                "  caption = ?, file_name = ?, file_size = ?, duration = ?, "
                "  mime_type = COALESCE(?, mime_type), "
                "  width = COALESCE(?, width), height = COALESCE(?, height), "
                "  thumb_file_id = COALESCE(?, thumb_file_id), "
                "  thumb_file_unique_id = COALESCE(?, thumb_file_unique_id), "
                "  source_status = 'available', source_verified_at = ?, "
                "  prev_channel_id = COALESCE(prev_channel_id, channel_id), "
                "  prev_message_id = COALESCE(prev_message_id, message_id), "
                "  repointed_at = ? "
                "WHERE id = ? AND (channel_id IS NOT ? OR message_id IS NOT ? "
                "                  OR file_id IS NOT ?)",
                (
                    int(new_channel_id), int(new_message_id),
                    str(info["file_id"]),
                    info.get("caption"),
                    info.get("file_name"),
                    info.get("file_size"),
                    info.get("duration"),
                    info.get("mime_type"),
                    info.get("width"),
                    info.get("height"),
                    info.get("thumb_file_id"),
                    info.get("thumb_file_unique_id"),
                    now,
                    now,
                    int(file_pk),
                    int(new_channel_id), int(new_message_id),
                    str(info["file_id"]),
                ),
            )
            await self.conn.commit()
            try:
                return bool(cur.rowcount)
            except Exception:  # noqa: BLE001 — rowcount unavailable
                return False
    async def get_indexed_file_by_unique_id(self, file_unique_id: str) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM indexed_files WHERE file_unique_id = ?", (file_unique_id,)
        )
        return await cur.fetchone()
    async def all_indexed_unique_ids(self) -> Set[str]:
        """PHASE 7 (Task 1): preload the exact-identity set for fast in-memory
        duplicate checks during a scan (one query instead of one SELECT per
        message). Only NON-NULL unique ids are included — NULL identity rows
        fall back to the per-message channel+msg check, exactly like before.
        """
        cur = await self.conn.execute(
            "SELECT file_unique_id FROM indexed_files WHERE file_unique_id IS NOT NULL"
        )
        rows = await cur.fetchall()
        return {r["file_unique_id"] for r in rows}
    async def add_indexed_files_batch(
        self, rows: List[Tuple[int, int, Dict[str, Any]]]
    ) -> int:
        """PHASE 7 (Task 1): insert MANY indexed files in ONE short
        write-locked transaction (BEGIN IMMEDIATE + executemany + COMMIT).

        Each item is (channel_id, message_id, info). Rows whose
        file_unique_id is already present are INSERT OR IGNORE'd (the
        UNIQUE(file_unique_id) constraint is the exact-identity guard).
        Returns the number of rows actually inserted (cursor rowcount).

        The transaction is held only for the duration of the executemany
        (milliseconds) — the slow Telegram fetches happen outside — so other
        bot writers are never blocked for long. Restart-safe: a crash before
        COMMIT simply never happened; the cursor stays behind and a rescan
        re-inserts.
        """
        if not rows:
            return 0
        now = _now_iso()
        payload_rows = [
            (
                int(ch), int(mid),
                info["file_id"], info.get("file_unique_id"),
                info.get("file_name"), info.get("caption"),
                info.get("media_type"), info.get("file_size"),
                info.get("duration"), now,
                # WEBSITE PHASE 2 (v30 part A): additive metadata columns —
                # legacy 7-key rows persist NULL (never fabricated).
                info.get("mime_type"), info.get("width"),
                info.get("height"), info.get("thumb_file_id"),
                info.get("thumb_file_unique_id"),
            )
            for ch, mid, info in rows
        ]
        async with self.write_lock:
            try:
                if self.conn.in_transaction:
                    logger.warning("add_indexed_files_batch: in_transaction on entry — safety ROLLBACK.")
                    await self.conn.execute("ROLLBACK")
            except Exception:  # noqa: BLE001
                pass
            try:
                await self.conn.execute("BEGIN IMMEDIATE")
                cur = await self.conn.executemany(
                    """
                    INSERT OR IGNORE INTO indexed_files
                        (channel_id, message_id, file_id, file_unique_id, file_name,
                         caption, media_type, file_size, duration, upload_date,
                         views, downloads, mime_type, width, height,
                         thumb_file_id, thumb_file_unique_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?, ?, ?, ?)
                    """,
                    payload_rows,
                )
                inserted = cur.rowcount if cur.rowcount is not None else 0
                await self.conn.commit()
                return int(inserted)
            except Exception as e:  # noqa: BLE001
                try:
                    await self.conn.execute("ROLLBACK")
                except Exception:  # noqa: BLE001
                    pass
                logger.error("add_indexed_files_batch failed (%s rows): %s",
                             len(rows), e)
                return 0
    async def backfill_indexed_file_metadata(self, file_pk: int,
                                              info: Dict[str, Any]) -> int:
        """WEBSITE PHASE 2 (v30 part A): fill MISSING metadata columns of a
        canonical indexed row from freshly-fetched source values.

        Used on the duplicate/re-index path (the file was already indexed;
        the source message was just re-fetched). Fill-missing semantics:
          * only columns that are currently NULL are written;
          * only fresh values that are not None are written (partial
            metadata never erases known metadata — nothing is fabricated);
          * the canonical row (pk, file_id, file_unique_id, source refs,
            payload references, stats) is NEVER touched — same discipline
            as repair_indexed_file_file_id.
        Idempotent: re-running converges to the same state; returns the
        number of metadata COLUMNS actually filled (0 = nothing was
        missing — either the row already carries them or the fresh info
        provides no new values).
        """
        fills: List[Tuple[str, Any]] = [
            (col, info.get(key))
            for col, key in (
                ("mime_type", "mime_type"),
                ("width", "width"),
                ("height", "height"),
                ("thumb_file_id", "thumb_file_id"),
                ("thumb_file_unique_id", "thumb_file_unique_id"),
            )
            if info.get(key) is not None
        ]
        if not fills:
            return 0
        sets = ", ".join(f"{col} = ?" for col, _ in fills)
        params = [val for _, val in fills]
        # Guarded per-column: only overwrite NULLs (fill-missing, never
        # clobber previously captured or admin-curated values). The guards
        # and the SET run in ONE atomic UPDATE: a row is either untouched
        # or gains every listed column (all guards matched together).
        null_guards = " AND ".join(f"{col} IS NULL" for col, _ in fills)
        params.append(int(file_pk))
        async with self.write_lock:
            cur = await self.conn.execute(
                f"UPDATE indexed_files SET {sets} WHERE id = ? AND {null_guards}",
                params,
            )
            await self.conn.commit()
            try:
                rows_updated = int(cur.rowcount or 0)
            except Exception:  # noqa: BLE001 — rowcount unavailable
                rows_updated = 0
        if rows_updated:
            logger.info(
                "BOT6_INDEX_METADATA_BACKFILL file_pk=%s columns=%s "
                "result=filled_missing", file_pk,
                ",".join(col for col, _ in fills))
            return len(fills)
        return 0
    async def indexed_files_metadata_coverage(self) -> Dict[str, int]:
        """WEBSITE PHASE 2 (v30 part A): metadata coverage counters for the
        Storage Statistics panel and Phase 3 website analytics — how many
        indexed rows carry mime_type / dimensions / thumbnail references
        (NULL = legacy or not provided by the source; never fabricated)."""
        cur = await self.conn.execute(
            """
            SELECT COUNT(*) AS total,
                   SUM(CASE WHEN mime_type IS NOT NULL THEN 1 ELSE 0 END) AS with_mime,
                   SUM(CASE WHEN width IS NOT NULL AND height IS NOT NULL
                            THEN 1 ELSE 0 END) AS with_dims,
                   SUM(CASE WHEN thumb_file_id IS NOT NULL
                            THEN 1 ELSE 0 END) AS with_thumb,
                   SUM(CASE WHEN thumb_file_unique_id IS NOT NULL
                            THEN 1 ELSE 0 END) AS with_thumb_identity
            FROM indexed_files
            """
        )
        row = await cur.fetchone()
        return {
            "total": int(row["total"] or 0) if row else 0,
            "with_mime": int(row["with_mime"] or 0) if row else 0,
            "with_dims": int(row["with_dims"] or 0) if row else 0,
            "with_thumb": int(row["with_thumb"] or 0) if row else 0,
            "with_thumb_identity": int(row["with_thumb_identity"] or 0)
            if row else 0,
        }
    async def count_indexed_files_like_pairs(self, limit: int = 10
                                             ) -> List[aiosqlite.Row]:
        """PHASE 7 (Task 1): NEAR-identical but DISTINCT indexed files.

        Groups indexed_files by (media_type, file_size) with >1 row and
        DISTINCT non-null file_unique_id — same size + same type but
        DIFFERENT Telegram file identity. These are exactly the files the
        indexing NEVER skips or merges: similar is NOT duplicate. Reported
        for transparency in the Duplicate Detection panel (display only —
        nothing is ever deleted or replaced).
        """
        cur = await self.conn.execute(
            """
            SELECT media_type, file_size, COUNT(*) AS cnt,
                   COUNT(DISTINCT file_unique_id) AS distinct_ids
            FROM indexed_files
            WHERE file_size IS NOT NULL AND file_unique_id IS NOT NULL
            GROUP BY media_type, file_size
            HAVING COUNT(*) > 1 AND COUNT(DISTINCT file_unique_id) > 1
            ORDER BY cnt DESC LIMIT ?
            """,
            (limit,),
        )
        return await cur.fetchall()
    async def count_indexed_files_without_unique_id(self) -> int:
        """Files indexed with NULL identity (legacy rows) — the fallback
        channel+message identity keeps them exact-safe."""
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM indexed_files WHERE file_unique_id IS NULL"
        )
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def indexed_files_media_type_stats(self) -> List[aiosqlite.Row]:
        """PHASE 7 (Task 1): per-media-type counts + view/download totals."""
        cur = await self.conn.execute(
            """
            SELECT media_type, COUNT(*) AS cnt,
                   COALESCE(SUM(views), 0) AS views,
                   COALESCE(SUM(downloads), 0) AS downloads
            FROM indexed_files GROUP BY media_type ORDER BY cnt DESC
            """
        )
        return await cur.fetchall()
    async def get_indexed_file_by_channel_msg(
        self, channel_id: int, message_id: int
    ) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM indexed_files WHERE channel_id = ? AND message_id = ?",
            (channel_id, message_id),
        )
        return await cur.fetchone()
    async def increment_file_downloads(self, index_id: int) -> None:
        await self.conn.execute(
            "UPDATE indexed_files SET downloads = downloads + 1 WHERE id = ?",
            (index_id,),
        )
        await self.conn.commit()
    async def increment_file_views(self, index_id: int) -> None:
        await self.conn.execute(
            "UPDATE indexed_files SET views = views + 1 WHERE id = ?", (index_id,)
        )
        await self.conn.commit()
    async def delete_indexed_file(self, index_id: int) -> bool:
        cur = await self.conn.execute(
            "DELETE FROM indexed_files WHERE id = ?", (index_id,)
        )
        await self.conn.commit()
        return cur.rowcount > 0
    async def clear_indexed_files_for_channel(self, channel_id: int) -> Tuple[bool, int]:
        """Issue 23: delete ALL indexed_files rows belonging to a single channel.

        Uses an explicit transaction so a failure rolls back — never leaves a
        partial delete. Only indexed_files rows are touched; users, analytics,
        settings, broadcasts, payloads and other channels are never affected.
        Returns (success, removed_count).
        """
        # BOTV13 fix: serialise under the write lock to prevent nested transactions.
        # B23-3 (5.1): the shared DatabaseBase.write_lock property — one
        # consistent lock name across every repository mixin.
        async with self.write_lock:
            try:
                if self.conn.in_transaction:
                    logger.warning("clear_indexed_files: in_transaction on entry — safety ROLLBACK.")
                    await self.conn.execute("ROLLBACK")
            except Exception:  # noqa: BLE001
                pass
            try:
                await self.conn.execute("BEGIN IMMEDIATE")
                cur = await self.conn.execute(
                    "DELETE FROM indexed_files WHERE channel_id = ?", (channel_id,)
                )
                removed = cur.rowcount if cur.rowcount is not None else 0
                await self.conn.commit()
                logger.info("Cleared %d indexed_files for channel %s", removed, channel_id)
                return True, int(removed)
            except Exception as e:  # noqa: BLE001
                try:
                    await self.conn.rollback()
                except Exception:  # noqa: BLE001
                    pass
                logger.error("clear_indexed_files_for_channel(%s) failed: %s", channel_id, e)
                return False, 0
    async def get_recent_files(self, limit: int = 10) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM indexed_files ORDER BY id DESC LIMIT ?", (limit,)
        )
        return await cur.fetchall()
    async def get_files_sorted(self, sort: str = "newest", limit: int = 10,
                                offset: int = 0) -> List[aiosqlite.Row]:
        """Sorted + paginated file listing for the Recent Files panel."""
        order_map = {
            "newest": "id DESC",
            "oldest": "id ASC",
            "largest": "file_size DESC",
            "downloads": "downloads DESC, id DESC",
        }
        order = order_map.get(sort, "id DESC")
        cur = await self.conn.execute(
            f"SELECT * FROM indexed_files ORDER BY {order} LIMIT ? OFFSET ?",
            (limit, offset),
        )
        return await cur.fetchall()
    @staticmethod
    def _escape_like(term: str) -> str:
        """PHASE 5: LIKE-metacharacter escaping for the legacy admin file
        search (mirrors PayloadsRepoMixin._search_escape_like; kept local
        to avoid a cross-mixin import for one three-replace call)."""
        return ((term or "").replace("\\", "\\\\")
                .replace("%", "\\%").replace("_", "\\_"))

    async def search_files_by_name(self, query: str, limit: int = 10) -> List[aiosqlite.Row]:
        """PHASE 5: user input LIKE-ESCAPED + ESCAPE clause — a literal % or
        _ in an admin search can no longer widen into a full-table match."""
        like = f"%{self._escape_like(query.lower())}%"
        cur = await self.conn.execute(
            "SELECT * FROM indexed_files WHERE LOWER(file_name) LIKE ? "
            "ESCAPE '\\' ORDER BY id DESC LIMIT ?", (like, limit)
        )
        return await cur.fetchall()
    async def count_indexed_files(self) -> int:
        cur = await self.conn.execute("SELECT COUNT(*) AS c FROM indexed_files")
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def count_indexed_files_for_channel(self, channel_id: int) -> int:
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM indexed_files WHERE channel_id = ?", (channel_id,)
        )
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def count_indexed_files_by_source_status(
            self, channel_id: int) -> Tuple[int, int]:
        """PHASE 8 (v28): (available, unavailable) counts for a channel.

        NULL/absent source_status = legacy row = AVAILABLE (pre-v28 rows keep
        their exact pre-v28 meaning)."""
        cur = await self.conn.execute(
            "SELECT SUM(CASE WHEN source_status IS NULL OR source_status != 'unavailable' "
            "THEN 1 ELSE 0 END) AS a, "
            "SUM(CASE WHEN source_status = 'unavailable' THEN 1 ELSE 0 END) AS u "
            "FROM indexed_files WHERE channel_id = ?", (channel_id,))
        row = await cur.fetchone()
        avail = int(row["a"] or 0) if row else 0
        unavail = int(row["u"] or 0) if row else 0
        return avail, unavail
    async def mark_indexed_file_source_status(self, file_pk: int, status: str,
                                               *, note: Optional[str] = None) -> None:
        """PHASE 8 (v28): set the reconciliation state of one indexed file.

        ONLY the verification/reconciliation engine sets this. The row is
        NEVER deleted and every other column (file_id, identity, payload
        references, stats) is untouched.
        """
        await self.conn.execute(
            "UPDATE indexed_files SET source_status = ?, source_verified_at = ? "
            "WHERE id = ?",
            (status, note or _now_iso(), int(file_pk)),
        )
        await self.conn.commit()
    async def max_message_id_for_channel(self, channel_id: int) -> Optional[int]:
        cur = await self.conn.execute(
            "SELECT MAX(message_id) AS m FROM indexed_files WHERE channel_id = ?",
            (channel_id,),
        )
        row = await cur.fetchone()
        return int(row["m"]) if row and row["m"] is not None else None
    async def message_ids_desc_for_channel(self, channel_id: int,
                                            limit: int = 40) -> List[int]:
        """V25 §12 (bot-34.log gap-truncation class): this channel's
        DISTINCT indexed message_ids, NEWEST FIRST, capped at ``limit``.

        Deliberately INCLUDES source_status='unavailable' rows — dead rows
        are exactly the seed candidates the latest-id discovery must be
        able to SKIP PAST. Production evidence (bot-34.log
        INDEX_VERIFY_WALK_TRUNCATED): db_max 868 was a dead orphan, the
        next DB-recorded id was live and 730 live messages existed above
        the truncated latest=9 — the discovery seed needs every recorded
        id (dead ones included) to re-seed the walk past a dead maximum.
        Pure SQL, no ORM.
        """
        cur = await self.conn.execute(
            "SELECT DISTINCT message_id FROM indexed_files "
            "WHERE channel_id = ? ORDER BY message_id DESC LIMIT ?",
            (channel_id, max(1, int(limit))),
        )
        rows = await cur.fetchall()
        return [int(r["message_id"]) for r in rows if r["message_id"] is not None]
    async def get_indexed_file_by_message_id(self, message_id: int) -> Optional[aiosqlite.Row]:
        """Resolve a file by its storage-channel message_id (for m<link> delivery).

        Issue 20: multi-channel collision fix. If the same message_id exists in
        multiple storage channels, prefer a file from an ACTIVE storage channel
        (deterministic) so Channel A msg 28 and Channel B msg 28 never collide.

        V25 FINAL §12 (bot-35.log message 872): when the message_id is
        AMBIGUOUS (the same id exists in multiple channels), the
        resolution is flagged in the log — the link:single/search admin
        flows disambiguate with the candidate list instead of silently
        accepting the heuristic pick; m<link> legacy links keep the
        deterministic behavior (they carry no channel context).
        """
        cur = await self.conn.execute(
            "SELECT i.* FROM indexed_files i "
            "LEFT JOIN storage_channels s ON s.channel_id = i.channel_id "
            "WHERE i.message_id = ? "
            "ORDER BY (CASE WHEN s.is_active = 1 THEN 0 ELSE 1 END), i.id ASC LIMIT 1",
            (message_id,),
        )
        row = await cur.fetchone()
        if row is not None:
            try:
                n = await self.conn.execute_fetchall(
                    "SELECT channel_id FROM indexed_files WHERE message_id = ?",
                    (message_id,))
                channels = {int(r["channel_id"]) for r in n}
                if len(channels) > 1:
                    logger.warning(
                        "INDEXED_FILE_MESSAGE_ID_AMBIGUOUS message_id=%s "
                        "channels=%s picked_channel=%s picked_file_pk=%s "
                        "(the same message id exists in MULTIPLE channels — "
                        "the deterministic active-channel pick was used; the "
                        "exact channel+message identity is the stable source "
                        "reference)",
                        int(message_id), sorted(channels),
                        int(row["channel_id"]), int(row["id"]))
            except Exception:  # noqa: BLE001 — ambiguity probe is best-effort
                pass
        return row

    async def get_indexed_file_by_channel_message(
            self, channel_id: int, message_id: int) -> Optional[aiosqlite.Row]:
        """V25 FINAL §12 — EXACT resolution by the stable source identity:
        (channel_id, message_id). No heuristic, no title match, no
        cross-channel substitution — the caller gets the one canonical
        row for THIS channel's message or None."""
        cur = await self.conn.execute(
            "SELECT * FROM indexed_files WHERE channel_id = ? AND "
            "message_id = ? ORDER BY id ASC LIMIT 1",
            (int(channel_id), int(message_id)))
        return await cur.fetchone()

    async def get_indexed_file_candidates_by_message(
            self, message_id: int) -> list:
        """V25 FINAL §12 — every indexed row sharing a message_id, with the
        storage-channel title for disambiguation UIs (the admin picks the
        exact channel instead of a heuristic guessing the identity)."""
        cur = await self.conn.execute(
            "SELECT i.*, COALESCE(s.title, '') AS channel_title, "
            "COALESCE(s.is_active, 0) AS channel_active "
            "FROM indexed_files i "
            "LEFT JOIN storage_channels s ON s.channel_id = i.channel_id "
            "WHERE i.message_id = ? "
            "ORDER BY (CASE WHEN s.is_active = 1 THEN 0 ELSE 1 END), "
            "i.channel_id ASC",
            (int(message_id),))
        return [dict(r) for r in await cur.fetchall()]
    async def resolve_channel_for_range(self, start_id: int, end_id: int) -> Optional[int]:
        """Issue 20: pick the single channel that owns a message-id range.

        Collections (rSTART_END) are channel-scoped. When the same message_ids
        exist in multiple channels, choose the channel with the most indexed
        files in [start_id, end_id] (tie-broken by active-then-id). Returns the
        channel_id, or None if no files exist in the range.
        """
        cur = await self.conn.execute(
            "SELECT i.channel_id, COUNT(*) AS c "
            "FROM indexed_files i "
            "LEFT JOIN storage_channels s ON s.channel_id = i.channel_id "
            "WHERE i.message_id BETWEEN ? AND ? "
            "GROUP BY i.channel_id "
            "ORDER BY c DESC, (CASE WHEN s.is_active = 1 THEN 0 ELSE 1 END), i.channel_id ASC "
            "LIMIT 1",
            (start_id, end_id),
        )
        row = await cur.fetchone()
        return int(row["channel_id"]) if row else None
    async def files_in_message_range(self, start_id: int, end_id: int,
                                     channel_id: Optional[int] = None) -> List[aiosqlite.Row]:
        """Return all indexed_files whose message_id is within [start_id, end_id].

        Issue 20: when channel_id is given, scope to that channel only (prevents
        multi-channel collisions where Channel A msg 28 and Channel B msg 28
        would otherwise be mixed into one collection).
        """
        if channel_id is not None:
            cur = await self.conn.execute(
                "SELECT * FROM indexed_files WHERE channel_id = ? AND message_id BETWEEN ? AND ? "
                "ORDER BY message_id ASC",
                (channel_id, start_id, end_id),
            )
        else:
            cur = await self.conn.execute(
                "SELECT * FROM indexed_files WHERE message_id BETWEEN ? AND ? "
                "ORDER BY message_id ASC",
                (start_id, end_id),
            )
        return await cur.fetchall()
    async def count_files_in_message_range(self, start_id: int, end_id: int,
                                           channel_id: Optional[int] = None) -> int:
        if channel_id is not None:
            cur = await self.conn.execute(
                "SELECT COUNT(*) AS c FROM indexed_files "
                "WHERE channel_id = ? AND message_id BETWEEN ? AND ?",
                (channel_id, start_id, end_id),
            )
        else:
            cur = await self.conn.execute(
                "SELECT COUNT(*) AS c FROM indexed_files WHERE message_id BETWEEN ? AND ?",
                (start_id, end_id),
            )
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def add_storage_channel(self, channel_id: int, title: Optional[str],
                                 username: Optional[str]) -> bool:
        try:
            await self.conn.execute(
                """
                INSERT INTO storage_channels (channel_id, title, username, is_active, added_at)
                VALUES (?, ?, ?, 1, ?)
                """,
                (channel_id, title, username, _now_iso()),
            )
            await self.conn.commit()
            return True
        except aiosqlite.IntegrityError:
            return False
    async def remove_storage_channel(self, channel_id: int) -> bool:
        cur = await self.conn.execute(
            "DELETE FROM storage_channels WHERE channel_id = ?", (channel_id,)
        )
        await self.conn.commit()
        return cur.rowcount > 0
    async def set_storage_channel_active(self, channel_id: int, is_active: int) -> None:
        await self.conn.execute(
            "UPDATE storage_channels SET is_active = ? WHERE channel_id = ?",
            (is_active, channel_id),
        )
        await self.conn.commit()
    async def list_storage_channels(self, active_only: bool = False) -> List[aiosqlite.Row]:
        if active_only:
            cur = await self.conn.execute(
                "SELECT * FROM storage_channels WHERE is_active = 1 ORDER BY id"
            )
        else:
            cur = await self.conn.execute(
                "SELECT * FROM storage_channels ORDER BY id"
            )
        return await cur.fetchall()
    async def get_storage_channel(self, channel_id: int) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM storage_channels WHERE channel_id = ?", (channel_id,)
        )
        return await cur.fetchone()
    async def touch_storage_channel(self, channel_id: int) -> None:
        await self.conn.execute(
            "UPDATE storage_channels SET last_scan = ? WHERE channel_id = ?",
            (_now_iso(), channel_id),
        )
        await self.conn.commit()
    async def update_reindex_state(self, channel_id: int,
                                   last_scanned_message_id: Optional[int] = None,
                                   last_indexed_message_id: Optional[int] = None,
                                   last_media_message_id: Optional[int] = None) -> None:
        """Persist the incremental-reindex cursor for a storage channel.

        Called after every reindex run so subsequent scans only process NEW
        messages. Only updates columns that are not None (partial update safe).
        Also stamps last_scan + last_reindex_time with the current time.
        """
        sets = ["last_scan = ?", "last_reindex_time = ?"]
        params: List[Any] = [_now_iso(), _now_iso()]
        if last_scanned_message_id is not None:
            sets.append("last_scanned_message_id = ?")
            params.append(last_scanned_message_id)
        if last_indexed_message_id is not None:
            sets.append("last_indexed_message_id = ?")
            params.append(last_indexed_message_id)
        if last_media_message_id is not None:
            sets.append("last_media_message_id = ?")
            params.append(last_media_message_id)
        params.append(channel_id)
        await self.conn.execute(
            f"UPDATE storage_channels SET {', '.join(sets)} WHERE channel_id = ?",
            params,
        )
        await self.conn.commit()
    async def get_reindex_state(self, channel_id: int) -> Optional[aiosqlite.Row]:
        """Fetch the incremental-reindex cursor for a storage channel."""
        cur = await self.conn.execute(
            "SELECT last_scanned_message_id, last_indexed_message_id, "
            "last_media_message_id, last_reindex_time "
            "FROM storage_channels WHERE channel_id = ?",
            (channel_id,),
        )
        return await cur.fetchone()
    async def reset_reindex_state(self, channel_id: int) -> None:
        """Reset the incremental-reindex cursor to NULL (next scan = first scan).

        Called when indexed files are cleared so the subsequent reindex
        re-indexes all content via the backward first-scan model, instead of
        skipping already-indexed messages that no longer exist.
        """
        await self.conn.execute(
            "UPDATE storage_channels SET "
            "last_scanned_message_id = NULL, "
            "last_indexed_message_id = NULL, "
            "last_media_message_id = NULL "
            "WHERE channel_id = ?",
            (channel_id,),
        )
        await self.conn.commit()
