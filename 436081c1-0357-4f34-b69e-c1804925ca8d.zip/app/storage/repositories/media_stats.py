"""Website media engagement — views + like/dislike (B18-FINAL v40).

The engagement repository for the website media experience (bot-22.log
final pass):

* ``media_view_events`` — per-(file_pk, viewer_key) rows. A view COUNTS
  once per viewer per dedupe window (default 6h): repeated page opens and
  refreshes within the window NEVER inflate the count. Views are recorded
  ONLY for video files (the API layer enforces the media type — photos and
  documents never receive video view counts).
* ``media_reactions`` — ONE like-or-dislike per (file_pk, user_id). The
  switch (like -> dislike or vice versa) happens inside ONE transaction;
  a repeat click on the active reaction removes it (back to no reaction).

Counts are always computed from the tables (no denormalized counters —
they can never drift from the rows). All methods are parameterized and
injection-safe; the repository NEVER exposes Telegram user ids through
the API layer (counts only + the caller's own reaction state).
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, Iterable, List, Optional

import aiosqlite

logger = logging.getLogger("payload-bot")

# Default per-viewer view dedupe window (seconds). Refresh/reload inside
# this window never counts a second view for the same viewer.
MEDIA_VIEW_DEDUPE_WINDOW_DEFAULT = 6 * 3600
# Hard bounds for the window (admin-tunable via settings is NOT exposed —
# the product constant keeps the semantics predictable).
MEDIA_VIEW_DEDUPE_WINDOW_MIN = 600       # 10 minutes
MEDIA_VIEW_DEDUPE_WINDOW_MAX = 7 * 86400  # 7 days
# Oppportunistic cleanup: expired handoffs older than this are pruned.
_WEBSITE_HANDOFF_RETENTION_SECONDS = 3600


def clamp_view_dedupe_window(seconds: Optional[int]) -> int:
    try:
        w = int(seconds or MEDIA_VIEW_DEDUPE_WINDOW_DEFAULT)
    except (TypeError, ValueError):
        w = MEDIA_VIEW_DEDUPE_WINDOW_DEFAULT
    return max(MEDIA_VIEW_DEDUPE_WINDOW_MIN,
               min(MEDIA_VIEW_DEDUPE_WINDOW_MAX, w))


class MediaStatsRepoMixin:
    """Website media engagement (views + reactions) + browser handoffs."""

    # ------------------------------------------------------------------
    # Views
    # ------------------------------------------------------------------
    async def record_media_view(self, file_pk: int, viewer_key: str,
                                *, dedupe_window_seconds:
                                Optional[int] = None) -> bool:
        """Record a (threshold-qualified) media view for one viewer.

        Returns True ONLY when this call actually COUNTED (the viewer had
        no view of this file inside the dedupe window). Inside-window
        repeats return False after refreshing last_view_at (so a later
        window starts from the LAST open, not the first).

        Atomicity: INSERT .. ON CONFLICT DO UPDATE .. WHERE in one
        statement; ``changes()`` distinguishes a fresh insert (counted)
        from an in-window refresh (not counted).
        """
        fpk = int(file_pk or 0)
        key = str(viewer_key or "").strip()
        if fpk <= 0 or not key:
            return False
        window = clamp_view_dedupe_window(dedupe_window_seconds)
        now = time.time()
        cutoff = now - window
        cur = await self.conn.execute(
            """
            INSERT INTO media_view_events (file_pk, viewer_key, last_view_at)
            VALUES (?, ?, ?)
            ON CONFLICT(file_pk, viewer_key) DO UPDATE
              SET last_view_at = excluded.last_view_at
              WHERE media_view_events.last_view_at < ?
            """,
            (fpk, key[:128], now, cutoff),
        )
        await self.conn.commit()
        counted = bool(cur.rowcount and int(cur.rowcount) > 0)
        if counted:
            logger.info("MEDIA_VIEW_COUNTED file_pk=%s window=%ss "
                        "(viewer key never logged)", fpk, window)
        return counted

    async def media_view_count(self, file_pk: int) -> int:
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM media_view_events WHERE file_pk = ?",
            (int(file_pk or 0),))
        row = await cur.fetchone()
        return int(row["c"]) if row else 0

    # ------------------------------------------------------------------
    # Reactions (like / dislike) — one per (file, user), atomic switching
    # ------------------------------------------------------------------
    async def get_media_reaction(self, file_pk: int,
                                 user_id: int) -> Optional[str]:
        """The caller's OWN reaction state: 'like' | 'dislike' | None."""
        cur = await self.conn.execute(
            "SELECT reaction FROM media_reactions "
            "WHERE file_pk = ? AND user_id = ?",
            (int(file_pk or 0), int(user_id or 0)))
        row = await cur.fetchone()
        return str(row["reaction"]) if row else None

    async def set_media_reaction(self, file_pk: int, user_id: int,
                                 reaction: Optional[str]) -> Dict[str, Any]:
        """Set (or clear) the user's single reaction for one file.

        ``reaction`` is 'like' | 'dislike' | None (None/removal). The whole
        operation is ONE transaction under the shared write lock — a
        like->dislike switch can never land as two rows or a lost update.
        Returns the post-operation truth: {"reaction", "likes",
        "dislikes"} for THIS file.
        """
        fpk = int(file_pk or 0)
        uid = int(user_id or 0)
        if fpk <= 0 or uid <= 0:
            return {"reaction": None, "likes": 0, "dislikes": 0}
        want = str(reaction or "").strip().lower() or None
        if want not in (None, "like", "dislike"):
            want = None
        now = time.time()
        # The shared connection serializes writers; the write lock keeps
        # the BEGIN..COMMIT block indivisible for every concurrent caller.
        # B23-3 (5.1): the SHARED DatabaseBase lock — the old defensive
        # fallback minted a PRIVATE second lock when the shared attribute
        # was missing (a bare host), silently defeating mutual exclusion
        # against every other writer.
        async with self.write_lock:
            try:
                await self.conn.execute("BEGIN IMMEDIATE")
                if want is None:
                    await self.conn.execute(
                        "DELETE FROM media_reactions "
                        "WHERE file_pk = ? AND user_id = ?", (fpk, uid))
                else:
                    await self.conn.execute(
                        """
                        INSERT INTO media_reactions
                            (file_pk, user_id, reaction, reacted_at)
                        VALUES (?, ?, ?, ?)
                        ON CONFLICT(file_pk, user_id) DO UPDATE
                          SET reaction = excluded.reaction,
                              reacted_at = excluded.reacted_at
                        """,
                        (fpk, uid, want, now))
                cur = await self.conn.execute(
                    """
                    SELECT
                      SUM(CASE WHEN reaction = 'like' THEN 1 ELSE 0 END)
                        AS likes,
                      SUM(CASE WHEN reaction = 'dislike' THEN 1 ELSE 0 END)
                        AS dislikes
                    FROM media_reactions WHERE file_pk = ?
                    """,
                    (fpk,))
                row = await cur.fetchone()
                await self.conn.execute("COMMIT")
            except BaseException:
                # B23-3 (5.9): BaseException (not just Exception) — a
                # CancelledError between BEGIN and COMMIT must ALSO roll
                # back, and the row extraction below must never run on a
                # half-open transaction (the old code extracted `row`
                # OUTSIDE the lock, so a cancellation produced an
                # UnboundLocalError that masked the real error).
                try:
                    await self.conn.execute("ROLLBACK")
                except Exception:  # noqa: BLE001
                    pass
                raise
            likes = int(row["likes"] or 0) if row else 0
            dislikes = int(row["dislikes"] or 0) if row else 0
        logger.info("MEDIA_REACTION_SET file_pk=%s reaction=%s "
                    "likes=%s dislikes=%s (user id never logged beyond "
                    "the authenticated session)", fpk, want or "none",
                    likes, dislikes)
        return {"reaction": want, "likes": likes, "dislikes": dislikes}

    async def media_stats(self, file_pk: int) -> Dict[str, int]:
        """{views, likes, dislikes} for one file (views = video views)."""
        fpk = int(file_pk or 0)
        if fpk <= 0:
            return {"views": 0, "likes": 0, "dislikes": 0}
        cur = await self.conn.execute(
            """
            SELECT
              (SELECT COUNT(*) FROM media_view_events
                WHERE file_pk = :fpk) AS views,
              (SELECT COUNT(*) FROM media_reactions
                WHERE file_pk = :fpk AND reaction = 'like') AS likes,
              (SELECT COUNT(*) FROM media_reactions
                WHERE file_pk = :fpk AND reaction = 'dislike') AS dislikes
            """,
            {"fpk": fpk})
        row = await cur.fetchone()
        if not row:
            return {"views": 0, "likes": 0, "dislikes": 0}
        return {"views": int(row["views"] or 0),
                "likes": int(row["likes"] or 0),
                "dislikes": int(row["dislikes"] or 0)}

    async def media_stats_for_files(
            self, file_pks: Iterable[int]) -> Dict[int, Dict[str, int]]:
        """Batch stats for list rendering: {file_pk: {views,likes,dislikes}}."""
        pks = [int(p) for p in (file_pks or []) if p and int(p) > 0]
        out: Dict[int, Dict[str, int]] = {p: {"views": 0, "likes": 0,
                                               "dislikes": 0} for p in pks}
        # Bounded IN-chunks (the site caps rendered files anyway).
        for i in range(0, len(pks), 100):
            chunk = pks[i:i + 100]
            marks = ",".join("?" for _ in chunk)
            cur = await self.conn.execute(
                f"SELECT file_pk, COUNT(*) AS c FROM media_view_events "
                f"WHERE file_pk IN ({marks}) GROUP BY file_pk",
                tuple(chunk))
            async for row in cur:
                out[int(row["file_pk"])]["views"] = int(row["c"] or 0)
            cur = await self.conn.execute(
                f"SELECT file_pk, reaction, COUNT(*) AS c FROM media_reactions "
                f"WHERE file_pk IN ({marks}) GROUP BY file_pk, reaction",
                tuple(chunk))
            async for row in cur:
                r = str(row["reaction"] or "")
                if r == "like":
                    out[int(row["file_pk"])]["likes"] = int(row["c"] or 0)
                elif r == "dislike":
                    out[int(row["file_pk"])]["dislikes"] = int(row["c"] or 0)
        return out

    # ------------------------------------------------------------------
    # External-browser handoffs (single-use, replay-protected)
    # ------------------------------------------------------------------
    async def create_website_handoff(self, nonce: str, user_id: int,
                                     target: str, expires_at: float) -> bool:
        """Persist a freshly minted handoff nonce (pending, unused)."""
        try:
            await self.conn.execute(
                "INSERT INTO website_handoffs "
                "(nonce, user_id, target, expires_at, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (str(nonce), int(user_id or 0), str(target or "")[:512],
                 float(expires_at), time.time()))
            await self.conn.commit()
            return True
        except Exception as exc:  # noqa: BLE001 — mint fails closed
            logger.warning("WEBSITE_HANDOFF_MINT_FAILED error_class=%s "
                           "(nonce never logged)", type(exc).__name__)
            return False

    async def consume_website_handoff(self, nonce: str) -> Optional[Dict[str, Any]]:
        """Consume a handoff SINGLE-USE: returns {user_id, target} only for
        a fresh, unexpired, unused nonce; None for any replay/expiry/unknown
        (the nonce row is marked used exactly once — changes()==1 wins)."""
        tok = str(nonce or "").strip()
        if not tok:
            return None
        now = time.time()
        cur = await self.conn.execute(
            "UPDATE website_handoffs SET used_at = ? "
            "WHERE nonce = ? AND used_at IS NULL AND expires_at > ?",
            (now, tok[:256], now))
        await self.conn.commit()
        if not cur.rowcount or int(cur.rowcount) != 1:
            return None
        cur = await self.conn.execute(
            "SELECT user_id, target FROM website_handoffs WHERE nonce = ?",
            (tok[:256],))
        row = await cur.fetchone()
        if not row:
            return None
        return {"user_id": int(row["user_id"] or 0),
                "target": str(row["target"] or "")}

    async def prune_website_handoffs(self) -> int:
        """Opportunistic cleanup of long-expired handoff rows."""
        try:
            cutoff = time.time() - _WEBSITE_HANDOFF_RETENTION_SECONDS
            cur = await self.conn.execute(
                "DELETE FROM website_handoffs WHERE expires_at < ?",
                (cutoff,))
            await self.conn.commit()
            return int(cur.rowcount or 0)
        except Exception:  # noqa: BLE001 — cleanup is best-effort
            return 0
