"""user accounts and user-id enumeration — users repository (ARCHITECTURE PHASE).

Verbatim method bodies extracted from the legacy ``Database`` class in
bot.py; SQL, transactions, locking and concurrency behavior unchanged.
Composed into ``app.storage.database.DatabaseBase``.
"""
from __future__ import annotations

from typing import List, Optional
from app.storage.dbutil import now_iso as _now_iso

class UsersRepoMixin:
    """user accounts and user-id enumeration."""

    async def first_active_admin_id(self) -> Optional[int]:
        """Owner or first active DB admin — the internal recovery-chat
        resolution (never the recipient's chat)."""
        cur = await self.conn.execute(
            "SELECT user_id FROM admins WHERE is_active = 1 "
            "ORDER BY is_owner DESC, created_at ASC LIMIT 1")
        row = await cur.fetchone()
        return int(row["user_id"]) if row else None

    async def user_exists(self, user_id: int) -> bool:
        cur = await self.conn.execute(
            "SELECT 1 FROM users WHERE user_id = ?", (user_id,)
        )
        return await cur.fetchone() is not None
    async def upsert_user(self, user_id: int, username: Optional[str], first_name: Optional[str]) -> None:
        now = _now_iso()
        await self.conn.execute(
            """
            INSERT INTO users (user_id, username, first_name, joined_date, last_seen)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username   = excluded.username,
                first_name = excluded.first_name,
                last_seen  = excluded.last_seen
            """,
            (user_id, username, first_name, now, now),
        )
        # BOT7: keep the admins table display info in sync (Telegram usernames
        # change; the admin list should show the current one). User ID remains
        # the canonical identity.
        await self.conn.execute(
            """
            UPDATE admins SET username = ?, first_name = ?, updated_at = ?
            WHERE user_id = ? OR user_id = ?
            """,
            (username, first_name, now, user_id, str(user_id)),
        )
        await self.conn.commit()
    async def total_users(self) -> int:
        cur = await self.conn.execute("SELECT COUNT(*) AS c FROM users")
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def all_user_ids(self) -> List[int]:
        cur = await self.conn.execute("SELECT user_id FROM users")
        rows = await cur.fetchall()
        return [int(r["user_id"]) for r in rows]
