"""Verification / reconciliation read queries (ARCHITECTURE PROPER BREAKDOWN).

Storage-owned, read-only queries used by the verification engine
(app/core/verification/engine.py). Every SQL statement the engine needs
lives HERE (RULE E: domain/application modules never execute SQL
directly — they call repository methods).
"""
from __future__ import annotations

from typing import Any, List


class VerificationRepoMixin:
    """Read-only verification snapshot queries over indexed_files/payloads."""

    async def verification_channel_rows(self, channel_id: int) -> List[Any]:
        """Full indexed_files snapshot for one channel (verification Phase B)."""
        cur = await self.conn.execute(
            "SELECT id, channel_id, message_id, file_id, file_unique_id, "
            "file_name, media_type, file_size, source_status, source_verified_at "
            "FROM indexed_files WHERE channel_id = ? ORDER BY id",
            (channel_id,))
        return list(await cur.fetchall())

    async def verification_duplicate_identities(self) -> List[Any]:
        """file_unique_id values carried by more than one indexed row."""
        cur = await self.conn.execute(
            "SELECT file_unique_id, COUNT(*) AS c FROM indexed_files "
            "WHERE file_unique_id IS NOT NULL GROUP BY file_unique_id "
            "HAVING c > 1")
        return list(await cur.fetchall())

    async def verification_null_identity_duplicates(self) -> List[Any]:
        """(channel, message) pairs duplicated with NULL identity."""
        cur = await self.conn.execute(
            "SELECT channel_id, message_id, COUNT(*) AS c FROM indexed_files "
            "WHERE file_unique_id IS NULL GROUP BY channel_id, message_id "
            "HAVING c > 1")
        return list(await cur.fetchall())

    async def verification_broken_payload_refs(self, limit: int = 50) -> List[Any]:
        """Payloads pointing at index rows that no longer exist."""
        cur = await self.conn.execute(
            "SELECT p.id AS pid, p.payload, p.index_id FROM payloads p "
            "LEFT JOIN indexed_files f ON f.id = p.index_id "
            "WHERE f.id IS NULL LIMIT ?", (limit,))
        return list(await cur.fetchall())

    async def verification_payloads_on_unavailable(self) -> int:
        """Payload count bound to source_status='unavailable' rows."""
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM payloads p JOIN indexed_files f "
            "ON f.id = p.index_id WHERE f.source_status = 'unavailable'")
        row = await cur.fetchone()
        return int(row["c"]) if row else 0

    async def verification_cross_channel_orphans(self) -> int:
        """Indexed rows whose channel is not a configured storage channel."""
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM indexed_files i WHERE i.channel_id NOT IN "
            "(SELECT channel_id FROM storage_channels)")
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
