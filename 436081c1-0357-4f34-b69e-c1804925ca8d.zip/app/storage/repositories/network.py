"""network bots, credentials, memberships, points ledger, global links, routing events — network repository (ARCHITECTURE PHASE).

Verbatim method bodies extracted from the legacy ``Database`` class in
bot.py; SQL, transactions, locking and concurrency behavior unchanged.
Composed into ``app.storage.database.DatabaseBase``.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional
from app.storage.dbutil import now_iso as _now_iso

logger = logging.getLogger("payload-bot")


def _iso_days_ago(days: int) -> str:
    """ISO timestamp N days before now (UTC) — the analytics window."""
    from datetime import datetime, timedelta, timezone
    dt = datetime.now(timezone.utc) - timedelta(days=int(days))
    return dt.strftime("%Y-%m-%dT%H:%M:%S")


class NetworkRepoMixin:
    """network bots, credentials, memberships, points ledger, global links, routing events."""

    async def list_network_bots(self, *, include_removed: bool = False
                                ) -> List[Dict[str, Any]]:
        """All network bots (registry order).

        BOT-16 (removal lifecycle): by default REMOVED bots are EXCLUDED —
        both the v37 terminal status (status='REMOVED') AND the b10 §5.7
        legacy shape (status='DISABLED' AND last_error_code='REMOVED'),
        the exact predicate network_ui._is_removed_bot /
        registry._row_is_removed encode. Every leak in the BOT-16 evidence
        (admin Registered Bots list, Network Control counts, health lists,
        capability refresh, delivery center, mini-app panel, public
        /network page) flows through this list — ONE filter heals them all.
        Pass ``include_removed=True`` for audit/restore surfaces that
        genuinely need the full table. ``get_network_bot`` /
        ``get_network_bot_by_telegram_id`` stay UNFILTERED (stale-callback
        guards + reactivate_removed_bot depend on reading removed rows)."""
        where = "" if include_removed else (
            " WHERE NOT (status = 'REMOVED' OR "
            "(status = 'DISABLED' AND last_error_code = 'REMOVED'))")
        cur = await self.conn.execute(
            f"SELECT *, id AS network_bot_id FROM network_bots{where} "
            f"ORDER BY id ASC")
        return [dict(r) for r in await cur.fetchall()]
    async def get_network_bot(self, network_bot_id: int) -> Optional[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT *, id AS network_bot_id FROM network_bots WHERE id = ?", (int(network_bot_id),))
        row = await cur.fetchone()
        return dict(row) if row else None
    async def get_network_bot_by_telegram_id(
            self, telegram_bot_id: int) -> Optional[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT *, id AS network_bot_id FROM network_bots WHERE telegram_bot_id = ?",
            (int(telegram_bot_id),))
        row = await cur.fetchone()
        return dict(row) if row else None
    async def count_network_bots_for_owner(self, owner_user_id: int) -> int:
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM network_bots WHERE owner_user_id = ? "
            "AND status NOT IN ('DISABLED', 'REMOVED')",
            (int(owner_user_id),))
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def list_network_bots_for_owner(
            self, owner_user_id: int, *, include_removed: bool = False
            ) -> List[Dict[str, Any]]:
        """Bots owned by one user. BOT-16: REMOVED bots (incl. the legacy
        DISABLED+REMOVED shape) are excluded by default — My Network / the
        Delivery Group center never list a removed bot (the b10 §5 leak
        fixed at the repository level)."""
        where = "" if include_removed else (
            " AND NOT (status = 'REMOVED' OR "
            "(status = 'DISABLED' AND last_error_code = 'REMOVED'))")
        cur = await self.conn.execute(
            f"SELECT *, id AS network_bot_id FROM network_bots "
            f"WHERE owner_user_id = ?{where} ORDER BY id ASC",
            (int(owner_user_id),))
        return [dict(r) for r in await cur.fetchall()]
    async def insert_network_bot(self, *, owner_user_id: int,
                                 telegram_bot_id: int, username: str,
                                 display_name: str, capabilities: str,
                                 encrypted_token: str, key_version: int,
                                 max_bots_per_user: int,
                                 management_mode: str = "USER_OWNED",
                                 credential_control: str = "OWNER",
                                 created_via: str = "user_flow"
                                 ) -> Dict[str, Any]:
        """Transaction-safe registration insert (spec §5): the per-user
        limit is RE-CHECKED inside the same write-locked transaction, so
        two concurrent registrations can never both pass the cap.

        v34 (spec §27-§29): the management metadata (USER_OWNED vs
        PLATFORM_MANAGED) is persisted atomically with the registration.

        b10 §5: the cap counts neither DISABLED (paused) nor REMOVED
        (gone) bots — a removed slot is immediately reusable.
        """
        now = _now_iso()
        async with self.write_lock:
            try:
                await self.conn.execute("BEGIN IMMEDIATE")
                cur = await self.conn.execute(
                    "SELECT COUNT(*) AS c FROM network_bots "
                    "WHERE owner_user_id = ? "
                    "AND status NOT IN ('DISABLED', 'REMOVED')",
                    (int(owner_user_id),))
                row = await cur.fetchone()
                existing = int(row["c"]) if row else 0
                if existing >= int(max_bots_per_user):
                    await self.conn.execute("ROLLBACK")
                    return {"inserted": False,
                            "reason": "registration_limit_reached",
                            "current": existing}
                await self.conn.execute(
                    """INSERT INTO network_bots
                       (owner_user_id, telegram_bot_id, username,
                        display_name, status, health, enabled,
                        routing_weight, capabilities, management_mode,
                        credential_control, created_via, created_at, updated_at)
                       VALUES (?, ?, ?, ?, 'PENDING', 'UNKNOWN', 1, 1, ?, ?, ?, ?, ?, ?)""",
                    (int(owner_user_id), int(telegram_bot_id), username,
                     display_name, capabilities, str(management_mode),
                     str(credential_control), str(created_via or ""),
                     now, now))
                cur = await self.conn.execute("SELECT last_insert_rowid() AS i")
                nid = int((await cur.fetchone())["i"])
                await self.conn.execute(
                    """INSERT INTO network_bot_credentials
                       (network_bot_id, encrypted_token, key_version,
                        created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?)""",
                    (nid, encrypted_token, int(key_version), now, now))
                await self.conn.execute("COMMIT")
                return {"inserted": True, "network_bot_id": nid}
            except Exception:
                try:
                    await self.conn.execute("ROLLBACK")
                except Exception:  # noqa: BLE001
                    pass
                raise
    async def update_network_bot_status(self, network_bot_id: int,
                                        status: str, *,
                                        last_error_code: Optional[str] = None
                                        ) -> None:
        await self.conn.execute(
            "UPDATE network_bots SET status = ?, updated_at = ?, "
            "last_error_code = COALESCE(?, last_error_code) WHERE id = ?",
            (status, _now_iso(), last_error_code, int(network_bot_id)))
        await self.conn.commit()
    async def update_network_bot_health(self, network_bot_id: int,
                                        health: str, *,
                                        error_code: Optional[str] = None
                                        ) -> None:
        await self.conn.execute(
            "UPDATE network_bots SET health = ?, last_health_check = ?, "
            "updated_at = ? WHERE id = ?",
            (health, _now_iso(), _now_iso(), int(network_bot_id)))
        if error_code:
            await self.conn.execute(
                "UPDATE network_bots SET last_error_code = ? WHERE id = ?",
                (error_code, int(network_bot_id)))
        await self.conn.commit()
    async def update_network_bot_capabilities(self, network_bot_id: int,
                                              capabilities: str) -> None:
        await self.conn.execute(
            "UPDATE network_bots SET capabilities = ?, updated_at = ? "
            "WHERE id = ?",
            (capabilities, _now_iso(), int(network_bot_id)))
        await self.conn.commit()
    async def bump_network_bot_activity(self, network_bot_id: int) -> None:
        await self.conn.execute(
            "UPDATE network_bots SET last_activity = ?, updated_at = ? "
            "WHERE id = ?", (_now_iso(), _now_iso(), int(network_bot_id)))
        await self.conn.commit()
    async def get_network_bot_credential(self, network_bot_id: int
                                         ) -> Optional[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT encrypted_token, key_version FROM "
            "network_bot_credentials WHERE network_bot_id = ?",
            (int(network_bot_id),))
        row = await cur.fetchone()
        return dict(row) if row else None
    async def revoke_network_bot_credential(self, network_bot_id: int) -> None:
        """Remove Bot removal (spec §58): revoke the stored credential;
        history/analytics rows are preserved."""
        await self.conn.execute(
            "DELETE FROM network_bot_credentials WHERE network_bot_id = ?",
            (int(network_bot_id),))
        await self.conn.commit()
    async def count_active_network_bots(self) -> int:
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM network_bots WHERE status = 'ACTIVE' "
            "AND enabled = 1")
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def update_network_bot_management(self, network_bot_id: int, *,
                                            management_mode: Optional[str] = None,
                                            credential_control: Optional[str] = None) -> None:
        """Update management metadata (v34 spec §27-§29). Platform admin
        operations only — the user-facing flows never write here."""
        sets, args = [], []
        if management_mode is not None:
            sets.append("management_mode = ?")
            args.append(str(management_mode))
        if credential_control is not None:
            sets.append("credential_control = ?")
            args.append(str(credential_control))
        if not sets:
            return
        args.append(int(network_bot_id))
        async with self.write_lock:
            await self.conn.execute(
                f"UPDATE network_bots SET {', '.join(sets)} WHERE id = ?",
                tuple(args))
            await self.conn.commit()
    async def replace_network_bot_credential(self, network_bot_id: int, *,
                                             encrypted_token: str,
                                             key_version: int) -> None:
        """Atomically REPLACE the stored credential (v34 rotate path,
        spec §25 'never destroy the working credential first' — callers
        validate the NEW token BEFORE calling this)."""
        now = _now_iso()
        async with self.write_lock:
            await self.conn.execute(
                "UPDATE network_bot_credentials SET encrypted_token = ?, "
                "key_version = ?, updated_at = ? WHERE network_bot_id = ?",
                (encrypted_token, int(key_version), now, int(network_bot_id)))
            await self.conn.commit()
    async def list_network_bots_by_management(self, management_mode: str,
                                               *, include_removed: bool = False
                                               ) -> List[Dict[str, Any]]:
        """Bots by management mode. BOT-16: REMOVED bots (incl. the legacy
        DISABLED+REMOVED shape) are excluded by default — the Managed
        Network Bots panel/list/counts never render a removed bot.
        ``include_removed=True`` is for the audit-trail footer (the count
        of removed managed bots) and restore tooling."""
        where = "" if include_removed else (
            " AND NOT (status = 'REMOVED' OR "
            "(status = 'DISABLED' AND last_error_code = 'REMOVED'))")
        rows = await self.conn.execute_fetchall(
            f"SELECT *, id AS network_bot_id FROM network_bots "
            f"WHERE management_mode = ?{where} ORDER BY id",
            (str(management_mode),))
        return [dict(r) for r in rows]

    async def get_delivery_eligible_bots(self) -> List[Dict[str, Any]]:
        """BOT-11 (spec §8/§12) + V25 FINAL (bot-35.log): network bots that
        are routable (status IN ACTIVE/DEGRADED) + enabled=1 + HAVE a
        configured Delivery Channel (delivery_channel_chat_id IS NOT
        NULL — the two-stage architecture's Stage A writes there and
        Stage B reads from there; a bot without one can never deliver a
        file, so it is honestly ineligible). The legacy delivery-group
        JOIN stays REMOVED — the group table is compat data, never read
        for routing. The DB-level pre-filter for the ONE centralized
        random selection; the router re-applies the authoritative
        predicate (routable + injected delivery_ready — FDB health) on
        top, so an injected predicate is always honored. Row shape
        mirrors list_network_bots (SELECT *, id AS network_bot_id)."""
        rows = await self.conn.execute_fetchall(
            """SELECT nb.*, nb.id AS network_bot_id
               FROM network_bots nb
               WHERE nb.status IN ('ACTIVE', 'DEGRADED')
                 AND nb.enabled = 1
                 AND nb.delivery_channel_chat_id IS NOT NULL
               ORDER BY nb.id ASC""")
        return [dict(r) for r in rows]

    async def set_delivery_channel(self, network_bot_id: int,
                                   chat_id: int) -> None:
        """V25 FINAL (v42): persist the per-bot DELIVERY CHANNEL (the
        private channel both the FDB and the Network Bot administer).

        Called by the production verification chain
        (FileDeliveryBotManager.verify_delivery_channel) AFTER the live
        probes pass — never with an unverified chat. A NULL/0 chat_id
        CLEARS the configuration (honest "not configured"). The legacy
        network_delivery_groups row (if any) is left untouched as
        compat data."""
        cid = int(chat_id) if chat_id else None
        if cid is None:
            await self.conn.execute(
                "UPDATE network_bots SET delivery_channel_chat_id = NULL, "
                "updated_at = ? WHERE id = ?",
                (_now_iso(), int(network_bot_id)))
        else:
            await self.conn.execute(
                "UPDATE network_bots SET delivery_channel_chat_id = ?, "
                "updated_at = ? WHERE id = ?",
                (cid, _now_iso(), int(network_bot_id)))
        await self.conn.commit()

    async def set_network_bot_capability(self, network_bot_id: int,
                                         can_manage_bots: Optional[bool]
                                         ) -> None:
        """BOT-11 (spec §1/§7): persist the getMe-derived bot-management
        capability (True→1 / False→0 / None→NULL unknown-unchecked) plus
        capability_checked_at=now. NEVER called with a fabricated value —
        None is the honest 'could not check' state."""
        val: Optional[int]
        if can_manage_bots is None:
            val = None
        else:
            val = 1 if bool(can_manage_bots) else 0
        await self.conn.execute(
            "UPDATE network_bots SET can_manage_bots = ?, "
            "capability_checked_at = ?, updated_at = ? WHERE id = ?",
            (val, _now_iso(), _now_iso(), int(network_bot_id)))
        await self.conn.commit()

    async def update_network_bot_mini_app(self, network_bot_id: int, *,
                                          url: str, status: str,
                                          error: str = "") -> None:
        """BOT-11 (spec §9/§10): persist the per-bot Mini App last-apply
        outcome (url + applied_at + status + error) — the truthful state
        the admin panel badges render from."""
        await self.conn.execute(
            "UPDATE network_bots SET mini_app_url = ?, "
            "mini_app_last_applied_at = ?, mini_app_last_apply_status = ?, "
            "mini_app_last_apply_error = ?, updated_at = ? WHERE id = ?",
            (str(url or ""), _now_iso(), str(status or ""),
             str(error or ""), _now_iso(), int(network_bot_id)))
        await self.conn.commit()

    async def upsert_network_bot_credential(self, network_bot_id: int, *,
                                            encrypted_token: str,
                                            key_version: int) -> None:
        """BOT-11 (spec §5-§7 — duplicate-bot REACTIVATION): (re)insert the
        stored credential for an EXISTING network bot. remove_bot DELETES
        the credential row (spec §58), so reactivating a previously
        removed same-owner bot must re-persist the NEW token the owner
        just supplied — replace_network_bot_credential (UPDATE-only)
        cannot restore a deleted row. INSERT ... ON CONFLICT keeps it
        idempotent for the paused-bot (row still present) case."""
        now = _now_iso()
        async with self.write_lock:
            await self.conn.execute(
                """INSERT INTO network_bot_credentials
                   (network_bot_id, encrypted_token, key_version,
                    created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(network_bot_id) DO UPDATE SET
                       encrypted_token = excluded.encrypted_token,
                       key_version = excluded.key_version,
                       updated_at = excluded.updated_at""",
                (int(network_bot_id), encrypted_token, int(key_version),
                 now, now))
            await self.conn.commit()
    async def upsert_membership(self, network_bot_id: int,
                                telegram_user_id: int) -> None:
        now = _now_iso()
        await self.conn.execute(
            """INSERT INTO user_bot_memberships
               (network_bot_id, telegram_user_id, first_started_at,
                last_active_at, status)
               VALUES (?, ?, ?, ?, 'ACTIVE')
               ON CONFLICT(network_bot_id, telegram_user_id) DO UPDATE SET
                   last_active_at = excluded.last_active_at,
                   status = 'ACTIVE', blocked_at = NULL""",
            (int(network_bot_id), int(telegram_user_id), now, now))
        await self.conn.commit()
    async def block_membership(self, network_bot_id: int,
                               telegram_user_id: int) -> None:
        await self.conn.execute(
            "UPDATE user_bot_memberships SET status = 'BLOCKED', "
            "blocked_at = ? WHERE network_bot_id = ? AND telegram_user_id = ?",
            (_now_iso(), int(network_bot_id), int(telegram_user_id)))
        await self.conn.commit()
    async def get_memberships_for_user(self, telegram_user_id: int
                                       ) -> List[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT * FROM user_bot_memberships WHERE telegram_user_id = ?",
            (int(telegram_user_id),))
        return [dict(r) for r in await cur.fetchall()]
    async def get_memberships_for_bot(self, network_bot_id: int,
                                      only_active: bool = True
                                      ) -> List[Dict[str, Any]]:
        q = ("SELECT * FROM user_bot_memberships WHERE network_bot_id = ?"
             + (" AND status = 'ACTIVE'" if only_active else ""))
        cur = await self.conn.execute(q, (int(network_bot_id),))
        return [dict(r) for r in await cur.fetchall()]
    async def count_reachable_users(self, network_bot_ids: Optional[List[int]] = None
                                    ) -> int:
        if network_bot_ids:
            marks = ",".join("?" for _ in network_bot_ids)
            cur = await self.conn.execute(
                f"SELECT COUNT(DISTINCT telegram_user_id) AS c FROM "
                f"user_bot_memberships WHERE status = 'ACTIVE' "
                f"AND network_bot_id IN ({marks})",
                [int(x) for x in network_bot_ids])
        else:
            cur = await self.conn.execute(
                "SELECT COUNT(DISTINCT telegram_user_id) AS c FROM "
                "user_bot_memberships WHERE status = 'ACTIVE'")
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def points_balance(self, user_id: int) -> int:
        cur = await self.conn.execute(
            "SELECT COALESCE(SUM(amount), 0) AS s FROM points_ledger "
            "WHERE user_id = ?", (int(user_id),))
        row = await cur.fetchone()
        return int(row["s"]) if row else 0
    async def points_credit(self, user_id: int, amount: int, event_type: str,
                            reference_type: str, reference_id: Optional[int],
                            idempotency_key: str, metadata: Optional[str]
                            ) -> Dict[str, Any]:
        """Idempotent credit (spec §6): UNIQUE(idempotency_key) means the
        same event processed twice NEVER awards twice."""
        try:
            cur = await self.conn.execute(
                """INSERT INTO points_ledger
                   (user_id, event_type, amount, reference_type, reference_id,
                    idempotency_key, metadata, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (int(user_id), event_type, int(amount), reference_type,
                 reference_id, idempotency_key, metadata, _now_iso()))
            await self.conn.commit()
            if cur.lastrowid:
                return {"inserted": True, "ledger_id": int(cur.lastrowid)}
            return {"inserted": True, "ledger_id": None}
        except Exception as exc:  # noqa: BLE001 — UNIQUE violation = duplicate
            if "UNIQUE" in str(exc):
                # Roll back the failed-statement transaction: a dangling
                # open transaction would break the NEXT explicit
                # BEGIN IMMEDIATE (v34 — exposed by the delivery-ready
                # duplicate-award path immediately followed by a
                # registration insert).
                try:
                    await self.conn.execute("ROLLBACK")
                except Exception:  # noqa: BLE001 — nothing to roll back
                    pass
                return {"inserted": False, "ledger_id": None,
                        "reason": "duplicate_event"}
            raise
    async def points_debit_atomic(self, user_id: int, amount: int,
                                  event_type: str, reference_type: str,
                                  reference_id: Optional[int],
                                  idempotency_key: str, metadata: Optional[str]
                                  ) -> Dict[str, Any]:
        """Atomic balance-safe debit (spec §10): BEGIN IMMEDIATE → verify
        balance → insert debit row → COMMIT. Never a negative balance."""
        async with self.write_lock:
            try:
                await self.conn.execute("BEGIN IMMEDIATE")
                cur = await self.conn.execute(
                    "SELECT COALESCE(SUM(amount), 0) AS s FROM points_ledger "
                    "WHERE user_id = ?", (int(user_id),))
                row = await cur.fetchone()
                balance = int(row["s"]) if row else 0
                if balance < int(amount):
                    await self.conn.execute("ROLLBACK")
                    return {"ok": False, "reason": "insufficient_points",
                            "balance": balance, "ledger_id": None}
                cur2 = await self.conn.execute(
                    """INSERT INTO points_ledger
                       (user_id, event_type, amount, reference_type,
                        reference_id, idempotency_key, metadata, created_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (int(user_id), event_type, -int(amount), reference_type,
                     reference_id, idempotency_key, metadata, _now_iso()))
                await self.conn.execute("COMMIT")
                return {"ok": True, "ledger_id": int(cur2.lastrowid or 0)}
            except Exception as exc:  # noqa: BLE001
                try:
                    await self.conn.execute("ROLLBACK")
                except Exception:  # noqa: BLE001
                    pass
                if "UNIQUE" in str(exc):
                    return {"ok": False, "reason": "duplicate_event",
                            "ledger_id": None}
                raise
    async def points_purchase_transaction(self, payload_id: int,
                                          user_id: int, cost: int
                                          ) -> Dict[str, Any]:
        """The full point-unlock transaction (spec §10): debit + unlock
        record commit TOGETHER or not at all. Idempotent per (payload,
        user): an existing unlock returns ok without a second debit."""
        async with self.write_lock:
            try:
                await self.conn.execute("BEGIN IMMEDIATE")
                cur = await self.conn.execute(
                    "SELECT id, points_spent FROM point_unlocks "
                    "WHERE payload_id = ? AND user_id = ?",
                    (int(payload_id), int(user_id)))
                existing = await cur.fetchone()
                if existing is not None:
                    await self.conn.execute("ROLLBACK")
                    return {"ok": True, "debited": False, "reason":
                            "already_unlocked",
                            "ledger_id": None}
                cur = await self.conn.execute(
                    "SELECT COALESCE(SUM(amount), 0) AS s FROM points_ledger "
                    "WHERE user_id = ?", (int(user_id),))
                row = await cur.fetchone()
                balance = int(row["s"]) if row else 0
                if balance < int(cost):
                    await self.conn.execute("ROLLBACK")
                    return {"ok": False, "reason": "insufficient_points",
                            "balance": balance, "ledger_id": None}
                cur2 = await self.conn.execute(
                    """INSERT INTO points_ledger
                       (user_id, event_type, amount, reference_type,
                        reference_id, idempotency_key, metadata, created_at)
                       VALUES (?, 'PAYLOAD_UNLOCK', ?, 'PAYLOAD', ?, ?, ?, ?)""",
                    (int(user_id), -int(cost), int(payload_id),
                     f"unlock:{int(payload_id)}:{int(user_id)}",
                     f"payload_id={int(payload_id)}", _now_iso()))
                ledger_id = int(cur2.lastrowid or 0)
                await self.conn.execute(
                    """INSERT INTO point_unlocks
                       (payload_id, user_id, points_spent, ledger_id,
                        unlocked_at)
                       VALUES (?, ?, ?, ?, ?)""",
                    (int(payload_id), int(user_id), int(cost), ledger_id,
                     _now_iso()))
                await self.conn.execute("COMMIT")
                return {"ok": True, "debited": True, "ledger_id": ledger_id}
            except Exception as exc:  # noqa: BLE001
                try:
                    await self.conn.execute("ROLLBACK")
                except Exception:  # noqa: BLE001
                    pass
                if "UNIQUE" in str(exc):
                    return {"ok": True, "debited": False,
                            "reason": "already_unlocked", "ledger_id": None}
                raise
    async def point_unlock_record(self, payload_id: int, user_id: int
                                  ) -> Optional[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT * FROM point_unlocks WHERE payload_id = ? AND user_id = ?",
            (int(payload_id), int(user_id)))
        row = await cur.fetchone()
        return dict(row) if row else None
    async def point_unlock_valid(self, payload_id: int, user_id: int) -> bool:
        cur = await self.conn.execute(
            "SELECT 1 FROM point_unlocks WHERE payload_id = ? AND user_id = ?",
            (int(payload_id), int(user_id)))
        return await cur.fetchone() is not None
    async def points_history(self, user_id: int, limit: int = 20
                             ) -> List[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT event_type, amount, created_at FROM points_ledger "
            "WHERE user_id = ? ORDER BY id DESC LIMIT ?",
            (int(user_id), int(limit)))
        return [dict(r) for r in await cur.fetchall()]
    async def points_registration_reward_count(self, user_id: int) -> int:
        cur = await self.conn.execute(
            "SELECT COALESCE(SUM(amount), 0) AS s FROM points_ledger "
            "WHERE user_id = ? AND event_type = 'BOT_REGISTERED'",
            (int(user_id),))
        row = await cur.fetchone()
        return int(row["s"]) if row else 0
    async def points_ledger_has_event(self, user_id: int, event_type: str,
                                      reference_type: str, reference_id: int
                                      ) -> bool:
        """v34 spec §62 guard: did THIS user already receive the legacy
        BOT_REGISTERED reward for THIS network bot?"""
        cur = await self.conn.execute(
            "SELECT 1 FROM points_ledger WHERE user_id = ? AND "
            "event_type = ? AND reference_type = ? AND reference_id = ? "
            "LIMIT 1",
            (int(user_id), str(event_type), str(reference_type),
             int(reference_id)))
        return bool(await cur.fetchone())
    async def points_totals(self) -> Dict[str, int]:
        cur = await self.conn.execute(
            """SELECT
                 COALESCE(SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END), 0) AS awarded,
                 COALESCE(SUM(CASE WHEN amount < 0 THEN -amount ELSE 0 END), 0) AS spent
               FROM points_ledger""")
        row = await cur.fetchone()
        return {"awarded": int(row["awarded"]), "spent": int(row["spent"])}
    async def create_global_payload_link(self, payload_id: int,
                                         public_code: str,
                                         target_network_bot_id: int = 0,
                                         target_mode: str = ""
                                         ) -> int:
        """Persist a Global Payload Link row (spec §17).

        BOT-11 (spec §12/§16): the link's DELIVERY TARGET is persisted at
        mint time — ``target_network_bot_id`` 0 = main bot / legacy
        untargeted behavior (the pre-v35 single-argument callers keep
        exactly that), >0 = the admin's chosen network bot (a 'random'
        mint has ONE bot selected and locked in at creation; never
        re-rolled at click time). ``target_mode`` records the admin's
        chosen mode (''|main|random|bot)."""
        cur = await self.conn.execute(
            """INSERT INTO global_payload_links
               (payload_id, public_code, target_network_bot_id,
                target_mode, active, created_at)
               VALUES (?, ?, ?, ?, 1, ?)""",
            (int(payload_id), public_code, int(target_network_bot_id or 0),
             str(target_mode or ""), _now_iso()))
        await self.conn.commit()
        return int(cur.lastrowid or 0)
    async def get_global_payload_link(self, public_code: str
                                      ) -> Optional[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT * FROM global_payload_links WHERE public_code = ?",
            (public_code,))
        row = await cur.fetchone()
        return dict(row) if row else None
    async def get_global_links_for_payload(self, payload_id: int
                                           ) -> List[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT * FROM global_payload_links WHERE payload_id = ? "
            "ORDER BY id DESC", (int(payload_id),))
        return [dict(r) for r in await cur.fetchall()]
    async def bump_global_link_click(self, public_code: str) -> None:
        await self.conn.execute(
            "UPDATE global_payload_links SET clicks = clicks + 1, "
            "last_click_at = ? WHERE public_code = ?",
            (_now_iso(), public_code))
        await self.conn.commit()
    async def deactivate_global_payload_link(self, link_id: int) -> None:
        await self.conn.execute(
            "UPDATE global_payload_links SET active = 0 WHERE id = ?",
            (int(link_id),))
        await self.conn.commit()

    async def deactivate_global_links_for_bot(self,
                                              target_network_bot_id: int
                                              ) -> int:
        """BOT-11 (spec §13 — link safety): a REMOVED delivery bot must not
        keep targeted links pointing at it. Deactivates every
        global_payload_links row whose target is this bot (clicks then get
        the honest "no longer available" §13 message). Returns the number
        of rows deactivated.

        BOT-16: previously DEAD CODE (never called) — now wired into
        registry.remove_bot, so removal deactivates the targeted links."""
        cur = await self.conn.execute(
            "UPDATE global_payload_links SET active = 0 "
            "WHERE target_network_bot_id = ?",
            (int(target_network_bot_id),))
        await self.conn.commit()
        return int(cur.rowcount or 0)

    async def disable_network_bot(self, network_bot_id: int) -> None:
        """BOT-16 (removal lifecycle): set enabled=0 on a REMOVED bot —
        the website /network page and every enabled-filtered surface
        (pages.py filters ``enabled``) would otherwise keep rendering the
        gone bot. Idempotent (no-op on already-disabled rows)."""
        await self.conn.execute(
            "UPDATE network_bots SET enabled = 0, updated_at = ? "
            "WHERE id = ?",
            (_now_iso(), int(network_bot_id)))
        await self.conn.commit()

    async def retire_bot_memberships(self, network_bot_id: int) -> int:
        """BOT-16 (removal lifecycle): retire every user↔bot membership
        row for a REMOVED bot — a gone bot has no reachable users (spec
        §15 reachability honesty; RETIRED joins ACTIVE|BLOCKED|INACTIVE in
        the membership status vocabulary). Returns the retired row count.
        History is preserved (rows are updated, never deleted)."""
        cur = await self.conn.execute(
            "UPDATE user_bot_memberships SET status = 'RETIRED' "
            "WHERE network_bot_id = ?",
            (int(network_bot_id),))
        await self.conn.commit()
        return int(cur.rowcount or 0)

    async def clear_network_bot_capability_state(
            self, network_bot_id: int) -> None:
        """BOT-16 (removal lifecycle): clear the persisted capability +
        Mini App apply state on removal — can_manage_bots=NULL (unknown,
        never a stale True/False on a gone bot), capability_checked_at=now
        (the clear is itself a check event), mini_app_url='' and
        mini_app_last_apply_status='CLEARED' (the admin panel renders a
        truthful cleared state, never a stale CONFIGURED)."""
        now = _now_iso()
        await self.conn.execute(
            "UPDATE network_bots SET can_manage_bots = NULL, "
            "capability_checked_at = ?, mini_app_url = '', "
            "mini_app_last_apply_status = 'CLEARED', updated_at = ? "
            "WHERE id = ?",
            (now, now, int(network_bot_id)))
        await self.conn.commit()

    async def set_network_bot_removed_at(self, network_bot_id: int) -> None:
        """BOT-16 (v37): write the durable removal timestamp — WHEN the
        bot was removed, next to the REMOVED status. NULL = never removed
        (legacy pre-v37 removed rows keep NULL; their audit trail lives
        in last_error_code='REMOVED' + control_audit_events)."""
        await self.conn.execute(
            "UPDATE network_bots SET removed_at = ?, updated_at = ? "
            "WHERE id = ?",
            (_now_iso(), _now_iso(), int(network_bot_id)))
        await self.conn.commit()

    async def list_global_payload_links(self, limit: int = 50
                                        ) -> List[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT * FROM global_payload_links ORDER BY id DESC LIMIT ?",
            (int(limit),))
        return [dict(r) for r in await cur.fetchall()]
    async def log_routing_event(self, event_type: str,
                                request_id: Optional[str],
                                payload_id: Optional[int],
                                selected_bot_id: Optional[int],
                                fallback_count: int, reason: str) -> None:
        try:
            await self.conn.execute(
                """INSERT INTO network_routing_events
                   (event_type, request_id, payload_id, selected_bot_id,
                    fallback_count, reason, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (event_type, request_id, payload_id, selected_bot_id,
                 int(fallback_count or 0), str(reason)[:300], _now_iso()))
            await self.conn.commit()
        except Exception as exc:  # noqa: BLE001 — analytics must never break routing
            logger.warning("routing event insert failed: %s", exc)

    # GAP-CLOSURE spec §8 (NETWORK ANALYTICS): the routing_events table was
    # write-only; these aggregations surface real, non-fabricated metrics
    # for the admin analytics dashboard. All queries are bounded (LIMIT)
    # and read ONLY what was actually recorded.
    async def network_analytics_summary(self, days: int = 7) -> Dict[str, Any]:
        """Aggregated network analytics over the last ``days`` days:
        routing attempts/successes/failures, fallback depth, per-bot
        selection counts, recent failure reasons, global-link clicks and
        broadcast failure classifications. Never fabricates metrics —
        absent data reads as zero."""
        days = max(1, min(90, int(days)))
        since = _iso_days_ago(days)
        out: Dict[str, Any] = {"days": days}
        try:
            cur = await self.conn.execute(
                """SELECT event_type, COUNT(*) AS n FROM
                   network_routing_events WHERE created_at >= ?
                   GROUP BY event_type ORDER BY n DESC""",
                (since,))
            by_type = {str(r["event_type"]): int(r["n"])
                       for r in await cur.fetchall()}
        except Exception:  # noqa: BLE001 — analytics never breaks the panel
            by_type = {}
        attempts = sum(by_type.values())
        routed = by_type.get("GLOBAL_PAYLOAD_ROUTE", 0)
        failed = by_type.get("GLOBAL_PAYLOAD_ROUTE_FAILED", 0)
        out["routing_events_by_type"] = by_type
        out["routing_attempts"] = attempts
        out["routing_successes"] = routed
        out["routing_failures"] = failed
        out["routing_success_rate"] = (
            round(routed / attempts, 3) if attempts else None)
        try:
            cur = await self.conn.execute(
                """SELECT COALESCE(MAX(fallback_count), 0) AS max_fb FROM
                   network_routing_events WHERE created_at >= ?""",
                (since,))
            row = await cur.fetchone()
            out["max_fallback_depth"] = int(row["max_fb"]) if row else 0
        except Exception:  # noqa: BLE001
            out["max_fallback_depth"] = 0
        # per-bot selection counts (JOIN network_bots for usernames)
        try:
            cur = await self.conn.execute(
                """SELECT nb.username AS username, COUNT(*) AS n FROM
                   network_routing_events e
                   LEFT JOIN network_bots nb
                     ON nb.id = e.selected_bot_id
                   WHERE e.created_at >= ? AND e.selected_bot_id IS NOT NULL
                   GROUP BY e.selected_bot_id ORDER BY n DESC LIMIT 10""",
                (since,))
            out["top_bots"] = [
                {"username": (str(r["username"]) if r["username"] else "?"),
                 "routed": int(r["n"])}
                for r in await cur.fetchall()]
        except Exception:  # noqa: BLE001
            out["top_bots"] = []
        # recent failure reasons (deduplicated, bounded)
        try:
            cur = await self.conn.execute(
                """SELECT reason, COUNT(*) AS n FROM network_routing_events
                   WHERE created_at >= ? AND event_type LIKE '%FAILED'
                   GROUP BY reason ORDER BY n DESC LIMIT 8""",
                (since,))
            out["recent_errors"] = [
                {"reason": str(r["reason"] or "?")[:120], "count": int(r["n"])}
                for r in await cur.fetchall()]
        except Exception:  # noqa: BLE001
            out["recent_errors"] = []
        # global link clicks (total + within window)
        try:
            cur = await self.conn.execute(
                "SELECT COALESCE(SUM(clicks), 0) AS c, COUNT(*) AS links "
                "FROM global_payload_links")
            row = await cur.fetchone()
            out["global_link_clicks_total"] = int(row["c"])
            out["global_links"] = int(row["links"])
        except Exception:  # noqa: BLE001
            out["global_link_clicks_total"] = 0
            out["global_links"] = 0
        # broadcast delivery failures within the window (spec §8): the
        # durable broadcast_deliveries ledger is the authoritative source
        # (statuses + error codes; FloodWait surfaces as C_FLOOD_WAIT).
        try:
            cur = await self.conn.execute(
                """SELECT COALESCE(error_code, status) AS code, COUNT(*) AS n
                   FROM broadcast_deliveries
                   WHERE status IN ('FAILED', 'BLOCKED', 'UNAVAILABLE')
                     AND created_at >= ?
                   GROUP BY code ORDER BY n DESC LIMIT 8""",
                (since,))
            out["broadcast_failures"] = [
                {"classification": str(r["code"] or "?"),
                 "count": int(r["n"])}
                for r in await cur.fetchall()]
        except Exception:  # noqa: BLE001 — old DBs / missing table
            out["broadcast_failures"] = []
        # FloodWait observability (spec §8)
        flood = 0
        for item in out["broadcast_failures"]:
            if "flood" in str(item.get("classification", "")).lower():
                flood += int(item.get("count", 0))
        out["floodwait_events"] = flood
        # deliveries (sent) within the window
        try:
            cur = await self.conn.execute(
                """SELECT COUNT(*) AS n FROM broadcast_deliveries
                   WHERE status = 'SENT' AND created_at >= ?""",
                (since,))
            row = await cur.fetchone()
            out["broadcast_deliveries_sent"] = int(row["n"]) if row else 0
        except Exception:  # noqa: BLE001
            out["broadcast_deliveries_sent"] = 0
        return out
