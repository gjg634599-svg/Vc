"""referral campaigns, tokens, unlock records, progress, history, access events — referrals repository (ARCHITECTURE PHASE).

Verbatim method bodies extracted from the legacy ``Database`` class in
bot.py; SQL, transactions, locking and concurrency behavior unchanged.
Composed into ``app.storage.database.DatabaseBase``.
"""
from __future__ import annotations

import secrets as _secrets

import aiosqlite
import logging
from typing import Any, Dict, List, Optional, Tuple
from app.core.constants import (
    REFERRAL_TOKEN_LENGTH,
    ACCESS_POLICY_DEFAULT,
    PREVIEW_MODE_DEFAULT,
    REFERRAL_REQUIRED_DEFAULT,
    ENABLE_ANALYTICS,
)
from app.storage.dbutil import now_iso as _now_iso

logger = logging.getLogger("payload-bot")


class ReferralsRepoMixin:
    """referral campaigns, tokens, unlock records, progress, history, access events."""

    async def get_referral_campaign_by_payload(self, payload_id: int) -> Optional[aiosqlite.Row]:
        """Get the referral campaign for a payload (if gate enabled)."""
        cur = await self.conn.execute(
            "SELECT * FROM referral_campaigns WHERE payload_id = ?", (payload_id,)
        )
        return await cur.fetchone()
    async def get_referral_campaign_by_id(self, campaign_id: int) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM referral_campaigns WHERE id = ?", (campaign_id,)
        )
        return await cur.fetchone()
    async def create_referral_campaign(self, payload_id: int, payload_code: str,
                                        required_referrals: int = REFERRAL_REQUIRED_DEFAULT,
                                        preview_mode: str = PREVIEW_MODE_DEFAULT,
                                        unlock_mode: str = "permanent") -> int:
        """Create a referral campaign for a payload. Returns campaign_id.

        Access Engine V1: default preview_mode is 'disabled' — the protected
        payload file is NEVER used as preview. Only admin-supplied media is.
        """
        now = _now_iso()
        cur = await self.conn.execute(
            """INSERT INTO referral_campaigns
               (payload_id, payload_code, required_referrals, preview_mode, unlock_mode, enabled, created_at)
               VALUES (?, ?, ?, ?, ?, 1, ?)""",
            (payload_id, payload_code, required_referrals, preview_mode, unlock_mode, now),
        )
        await self.conn.commit()
        return int(cur.lastrowid)
    async def update_referral_campaign(self, campaign_id: int, **kwargs) -> None:
        """Update campaign fields. Accepted: required_referrals, preview_mode,
        unlock_mode, enabled, preview_media_file_id, preview_media_type,
        preview_description."""
        allowed = ("required_referrals", "preview_mode", "unlock_mode", "enabled",
                   "preview_media_file_id", "preview_media_type", "preview_description")
        sets, params = [], []
        for k, v in kwargs.items():
            if k in allowed:
                sets.append(f"{k} = ?")
                params.append(v)
        if not sets:
            return
        params.append(campaign_id)
        await self.conn.execute(
            f"UPDATE referral_campaigns SET {', '.join(sets)} WHERE id = ?", params
        )
        await self.conn.commit()
    async def delete_referral_campaign(self, campaign_id: int) -> None:
        """Hard-delete a campaign row.

        Access Engine V1: this is now DEFENSIVE ONLY. referral_history has no
        ON DELETE CASCADE (rebuilt in v14), so deleting the campaign will NOT
        erase history. payload_unlocks still cascade (they are reset-able
        progress). Admin destructive actions use disable/reset instead of
        delete — this method is retained for true cleanup but is gated behind
        confirmation in the UI.
        """
        await self.conn.execute("DELETE FROM referral_campaigns WHERE id = ?", (campaign_id,))
        await self.conn.commit()
    async def is_referral_gate_enabled(self, payload_id: int) -> bool:
        """Check if a payload has the referral gate enabled."""
        cur = await self.conn.execute(
            "SELECT 1 FROM referral_campaigns WHERE payload_id = ? AND enabled = 1",
            (payload_id,),
        )
        return await cur.fetchone() is not None
    async def get_or_create_referral_token(self, campaign_id: int, inviter_user_id: int) -> str:
        """Get the existing referral token for (campaign, inviter) or create one."""
        cur = await self.conn.execute(
            "SELECT token FROM referral_tokens WHERE campaign_id = ? AND inviter_user_id = ?",
            (campaign_id, inviter_user_id),
        )
        row = await cur.fetchone()
        if row:
            return row["token"]
        token = generate_referral_token()
        now = _now_iso()
        await self.conn.execute(
            "INSERT INTO referral_tokens (campaign_id, inviter_user_id, token, created_at) VALUES (?, ?, ?, ?)",
            (campaign_id, inviter_user_id, token, now),
        )
        await self.conn.commit()
        return token
    async def lookup_referral_token(self, token: str) -> Optional[aiosqlite.Row]:
        """Look up a referral token → (campaign_id, inviter_user_id)."""
        cur = await self.conn.execute(
            "SELECT * FROM referral_tokens WHERE token = ?", (token,)
        )
        return await cur.fetchone()
    async def get_or_create_unlock_record(self, payload_id: int, campaign_id: int,
                                           user_id: int, required_referrals: int = 5) -> aiosqlite.Row:
        """Get the unlock progress record for (payload, user), creating if needed."""
        cur = await self.conn.execute(
            "SELECT * FROM payload_unlocks WHERE payload_id = ? AND user_id = ?",
            (payload_id, user_id),
        )
        row = await cur.fetchone()
        if row:
            return row
        now = _now_iso()
        await self.conn.execute(
            """INSERT INTO payload_unlocks
               (payload_id, campaign_id, user_id, required_referrals, completed_referrals, unlocked, created_at)
               VALUES (?, ?, ?, ?, 0, 0, ?)""",
            (payload_id, campaign_id, user_id, required_referrals, now),
        )
        await self.conn.commit()
        cur = await self.conn.execute(
            "SELECT * FROM payload_unlocks WHERE payload_id = ? AND user_id = ?",
            (payload_id, user_id),
        )
        return await cur.fetchone()
    async def is_payload_unlocked(self, payload_id: int, user_id: int) -> bool:
        """Check if a user has unlocked a payload."""
        cur = await self.conn.execute(
            "SELECT unlocked FROM payload_unlocks WHERE payload_id = ? AND user_id = ?",
            (payload_id, user_id),
        )
        row = await cur.fetchone()
        return bool(row and row["unlocked"])
    async def save_dashboard_msg(self, payload_id: int, user_id: int,
                                  chat_id: int, msg_id: int,
                                  mode: str = "TEXT") -> None:
        """Save the dashboard message ID + mode for edit-in-place updates.

        mode: 'TEXT' (standalone text message → editMessageText) or
              'CAPTION' (media caption → editMessageCaption).
        """
        await self.conn.execute(
            "UPDATE payload_unlocks SET dashboard_msg_id = ?, dashboard_chat_id = ?, dashboard_mode = ? "
            "WHERE payload_id = ? AND user_id = ?",
            (msg_id, chat_id, mode, payload_id, user_id),
        )
        await self.conn.commit()
    async def get_dashboard_msg(self, payload_id: int, user_id: int) -> Optional[Tuple[int, int, str]]:
        """Get the saved dashboard message (chat_id, msg_id, mode) or None.

        mode is 'TEXT' or 'CAPTION' (defaults to 'TEXT' for legacy rows).
        """
        cur = await self.conn.execute(
            "SELECT dashboard_chat_id, dashboard_msg_id, dashboard_mode FROM payload_unlocks "
            "WHERE payload_id = ? AND user_id = ?",
            (payload_id, user_id),
        )
        row = await cur.fetchone()
        if row and row["dashboard_msg_id"] and row["dashboard_chat_id"]:
            mode = row["dashboard_mode"] if row["dashboard_mode"] else "TEXT"
            return int(row["dashboard_chat_id"]), int(row["dashboard_msg_id"]), str(mode)
        return None
    async def clear_dashboard_msg(self, payload_id: int, user_id: int) -> None:
        """Clear the saved dashboard message (e.g. after unlock)."""
        await self.conn.execute(
            "UPDATE payload_unlocks SET dashboard_msg_id = NULL, dashboard_chat_id = NULL, "
            "dashboard_mode = NULL WHERE payload_id = ? AND user_id = ?",
            (payload_id, user_id),
        )
        await self.conn.commit()
    async def increment_unlock_progress(self, payload_id: int, campaign_id: int,
                                         inviter_user_id: int) -> Tuple[int, bool]:
        """Increment inviter's completed_referrals. Returns (new_count, just_unlocked).
        Just_unlocked is True if this increment caused the unlock threshold to be reached."""
        rec = await self.get_or_create_unlock_record(payload_id, campaign_id, inviter_user_id)
        new_count = int(rec["completed_referrals"]) + 1
        required = int(rec["required_referrals"])
        just_unlocked = False
        if new_count >= required and not rec["unlocked"]:
            await self.conn.execute(
                "UPDATE payload_unlocks SET completed_referrals = ?, unlocked = 1, unlocked_at = ? WHERE id = ?",
                (new_count, _now_iso(), rec["id"]),
            )
            just_unlocked = True
        else:
            await self.conn.execute(
                "UPDATE payload_unlocks SET completed_referrals = ? WHERE id = ?",
                (new_count, rec["id"]),
            )
        await self.conn.commit()
        return new_count, just_unlocked
    async def reset_unlock_progress(self, payload_id: int, user_id: int) -> None:
        """Reset a user's unlock progress for a payload (admin action)."""
        await self.conn.execute(
            "UPDATE payload_unlocks SET completed_referrals = 0, unlocked = 0, unlocked_at = NULL WHERE payload_id = ? AND user_id = ?",
            (payload_id, user_id),
        )
        await self.conn.commit()
    async def reset_campaign_unlocks(self, campaign_id: int) -> int:
        """Reset ALL unlock progress for a campaign. Returns rows affected."""
        cur = await self.conn.execute(
            "UPDATE payload_unlocks SET completed_referrals = 0, unlocked = 0, unlocked_at = NULL WHERE campaign_id = ?",
            (campaign_id,),
        )
        await self.conn.commit()
        return cur.rowcount
    async def record_referral(self, campaign_id: int, inviter_user_id: int,
                               referred_user_id: int, qualified: bool = False) -> bool:
        """Record a referral attempt. Returns True if inserted (new), False if duplicate."""
        now = _now_iso()
        try:
            await self.conn.execute(
                """INSERT INTO referral_history
                   (campaign_id, inviter_user_id, referred_user_id, qualified, qualified_at, created_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (campaign_id, inviter_user_id, referred_user_id,
                 1 if qualified else 0, _now_iso() if qualified else None, now),
            )
            await self.conn.commit()
            return True
        except aiosqlite.IntegrityError:
            # UNIQUE(campaign_id, inviter_user_id, referred_user_id) — duplicate.
            return False
    async def mark_referral_qualified(self, campaign_id: int, inviter_user_id: int,
                                       referred_user_id: int) -> None:
        """Mark a referral as qualified (passed all checks)."""
        await self.conn.execute(
            "UPDATE referral_history SET qualified = 1, qualified_at = ? WHERE campaign_id = ? AND inviter_user_id = ? AND referred_user_id = ?",
            (_now_iso(), campaign_id, inviter_user_id, referred_user_id),
        )
        await self.conn.commit()
    async def is_already_referred(self, campaign_id: int, inviter_user_id: int,
                                   referred_user_id: int) -> bool:
        """Check if a referral already exists (prevents duplicates)."""
        cur = await self.conn.execute(
            "SELECT 1 FROM referral_history WHERE campaign_id = ? AND inviter_user_id = ? AND referred_user_id = ?",
            (campaign_id, inviter_user_id, referred_user_id),
        )
        return await cur.fetchone() is not None
    async def has_user_qualified_for_campaign(self, campaign_id: int, user_id: int) -> bool:
        """Check if ``user_id`` has already QUALIFIED AS A REFERRED USER in
        this campaign (referred_user_id match, qualified=1).

        B23-3 (5.3) — semantics pinned to the caller's contract
        (app/core/referral/service.py qualify_referral step 3: "Already
        qualified as a referred user for this campaign (no re-counting)"):
        a user who arrives via ANOTHER inviter's link must not be counted
        twice as a referral. The check is therefore on the REFERRED side
        ONLY — being an INVITER (having referred others) must NOT block a
        user from being legitimately referred by someone else, which is
        why the query deliberately has no ``OR inviter_user_id = ?``.
        """
        cur = await self.conn.execute(
            "SELECT 1 FROM referral_history WHERE campaign_id = ? AND referred_user_id = ? AND qualified = 1 LIMIT 1",
            (campaign_id, user_id),
        )
        return await cur.fetchone() is not None
    async def campaign_stats(self, campaign_id: int) -> Dict[str, int]:
        """Get aggregate stats for a campaign."""
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM referral_history WHERE campaign_id = ?", (campaign_id,)
        )
        total_referrals = (await cur.fetchone())["c"]
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM referral_history WHERE campaign_id = ? AND qualified = 1",
            (campaign_id,),
        )
        qualified_referrals = (await cur.fetchone())["c"]
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM payload_unlocks WHERE campaign_id = ? AND unlocked = 1",
            (campaign_id,),
        )
        unlocks = (await cur.fetchone())["c"]
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM payload_unlocks WHERE campaign_id = ?", (campaign_id,)
        )
        total_participants = (await cur.fetchone())["c"]
        return {
            "total_referrals": total_referrals,
            "qualified_referrals": qualified_referrals,
            "unlocks": unlocks,
            "total_participants": total_participants,
        }
    async def top_referrers(self, campaign_id: int, limit: int = 10) -> List[aiosqlite.Row]:
        """Top referrers for a campaign by qualified referral count."""
        cur = await self.conn.execute(
            """SELECT inviter_user_id, COUNT(*) AS qualified_count
               FROM referral_history
               WHERE campaign_id = ? AND qualified = 1
               GROUP BY inviter_user_id
               ORDER BY qualified_count DESC LIMIT ?""",
            (campaign_id, limit),
        )
        return await cur.fetchall()
    async def qualify_referral_atomic(self, campaign_id: int, inviter_user_id: int,
                                       referred_user_id: int, payload_id: int,
                                       required_referrals: int) -> Tuple[bool, int, bool, bool]:
        """Atomically record + qualify a referral and bump unlock progress.

        BOTV13 Fix: the entire BEGIN IMMEDIATE / COMMIT window is serialised
        under `self.write_lock` (the shared DatabaseBase lock) so no two
        coroutines can ever interleave inside
        each other's open transaction on the shared aiosqlite connection. This
        is the root fix for `cannot start a transaction within a transaction`.
        An `in_transaction` safety check is performed before BEGIN so a stray
        open transaction (from a crashed prior call) is rolled back first.

        BOTV13 Part 2: Smart post-unlock behavior. Once unlocked,
        `completed_referrals` is NO LONGER incremented (it stays at
        `required_referrals` forever, so the dashboard always shows 5/5, never
        6/5, 7/5, 8/5). The referral is still RECORDED in referral_history
        (analytics continue). Returns a 4th value `already_unlocked` so the
        caller can send an appreciation notification instead of a progress one.

        Returns: (qualified, new_count, just_unlocked, already_unlocked)
          - qualified: True if this referral was newly recorded.
          - new_count: the inviter's completed_referrals (capped at required).
          - just_unlocked: True if the threshold was reached exactly now.
          - already_unlocked: True if the inviter was already unlocked before
            this referral (caller should send appreciation, not progress).
        """
        logger.info("Referral trace [qualify_referral_atomic]: ENTER campaign=%s inviter=%s referred=%s payload=%s required=%s", campaign_id, inviter_user_id, referred_user_id, payload_id, required_referrals)

        if not inviter_user_id or inviter_user_id <= 0:
            logger.error("Referral trace [qualify_referral_atomic]: ABORT — inviter_user_id=%s is invalid", inviter_user_id)
            return False, 0, False, False
        now = _now_iso()
        # BOTV13 Fix: serialise the explicit-transaction window.
        # B23-3 (5.1): the shared DatabaseBase.write_lock property — one
        # consistent lock name across every repository mixin.
        async with self.write_lock:
            # Safety: if the connection is somehow already in a transaction
            # (e.g. a prior call crashed before COMMIT/ROLLBACK), roll it back
            # first so our BEGIN IMMEDIATE cannot raise "cannot start a
            # transaction within a transaction".
            try:
                if self.conn.in_transaction:
                    logger.warning("Referral txn: connection was in_transaction on entry — issuing safety ROLLBACK.")
                    await self.conn.execute("ROLLBACK")
            except Exception:  # noqa: BLE001
                pass
            await self.conn.execute("BEGIN IMMEDIATE")
            try:
                # 1. Insert referral history (duplicate -> no-op via ON CONFLICT).
                # Analytics ALWAYS record — even after unlock.
                cur = await self.conn.execute(
                    """INSERT INTO referral_history
                       (campaign_id, inviter_user_id, referred_user_id, qualified,
                        qualified_at, created_at)
                       VALUES (?, ?, ?, 1, ?, ?)
                       ON CONFLICT(campaign_id, inviter_user_id, referred_user_id)
                       DO NOTHING""",
                    (campaign_id, inviter_user_id, referred_user_id, now, now),
                )
                inserted = cur.rowcount > 0
                if not inserted:
                    await self.conn.execute("ROLLBACK")
                    return False, 0, False, False

                # 2. Ensure the inviter's unlock record exists (idempotent).
                await self.conn.execute(
                    """INSERT INTO payload_unlocks
                       (payload_id, campaign_id, user_id, required_referrals,
                        completed_referrals, unlocked, created_at)
                       VALUES (?, ?, ?, ?, 0, 0, ?)
                       ON CONFLICT(payload_id, user_id) DO NOTHING""",
                    (payload_id, campaign_id, inviter_user_id, required_referrals, now),
                )

                # 3. Read the CURRENT unlocked state BEFORE the UPDATE so we can
                #    determine `already_unlocked` (was the inviter already
                #    unlocked before this referral?).
                cur = await self.conn.execute(
                    "SELECT unlocked, completed_referrals FROM payload_unlocks "
                    "WHERE payload_id = ? AND user_id = ?",
                    (payload_id, inviter_user_id),
                )
                current = await cur.fetchone()
                was_unlocked = bool(current["unlocked"]) if current else False

                # 4. Atomic increment via UPDATE. BOTV13 Part 2: only increment
                #    completed_referrals if NOT already unlocked (caps at required).
                #    The CASE expression flips `unlocked` and stamps `unlocked_at`
                #    the moment the threshold is reached. RETURNING reads back the
                #    new completed_referrals + unlocked without a separate SELECT.
                cur = await self.conn.execute(
                    """UPDATE payload_unlocks
                       SET completed_referrals = CASE
                           WHEN unlocked = 1 THEN completed_referrals
                           ELSE completed_referrals + 1
                       END,
                           unlocked = CASE
                               WHEN completed_referrals + 1 >= required_referrals
                                    AND unlocked = 0 THEN 1
                               ELSE unlocked
                           END,
                           unlocked_at = CASE
                               WHEN completed_referrals + 1 >= required_referrals
                                    AND unlocked = 0 THEN ?
                               ELSE unlocked_at
                           END
                       WHERE payload_id = ? AND user_id = ?
                       RETURNING completed_referrals, unlocked""",
                    (now, payload_id, inviter_user_id),
                )
                row = await cur.fetchone()
                await self.conn.commit()
                if not row:
                    # Unlock record vanished mid-transaction (shouldn't happen).
                    return True, 0, False, was_unlocked
                new_count = int(row["completed_referrals"])
                new_unlocked = int(row["unlocked"])
                # just_unlocked: the threshold was reached exactly now (was NOT
                # unlocked before, IS unlocked now).
                just_unlocked = (not was_unlocked and new_unlocked == 1
                                 and required_referrals > 0)
                # already_unlocked: the inviter was already unlocked before this
                # referral. The caller should send appreciation, not progress.
                already_unlocked = was_unlocked
                return True, new_count, just_unlocked, already_unlocked
            except Exception:
                try:
                    await self.conn.execute("ROLLBACK")
                except Exception:  # noqa: BLE001
                    pass
                raise
    async def get_access_policy(self, payload_id: int) -> str:
        """Read a payload's access_policy (default FORCE_JOIN for legacy rows)."""
        cur = await self.conn.execute(
            "SELECT access_policy FROM payloads WHERE id = ?", (payload_id,)
        )
        row = await cur.fetchone()
        if not row or not row["access_policy"]:
            return ACCESS_POLICY_DEFAULT
        return row["access_policy"]
    async def set_access_policy(self, payload_id: int, policy: str) -> None:
        await self.conn.execute(
            "UPDATE payloads SET access_policy = ?, updated_at = ? WHERE id = ?",
            (policy, _now_iso(), payload_id),
        )
        await self.conn.commit()
    async def count_active_referral_campaigns(self) -> int:
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM referral_campaigns WHERE enabled = 1"
        )
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def list_referral_campaigns(self, limit: int = 50) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            """SELECT rc.*, p.payload AS payload_name
               FROM referral_campaigns rc
               JOIN payloads p ON p.id = rc.payload_id
               ORDER BY rc.id DESC LIMIT ?""",
            (limit,),
        )
        return await cur.fetchall()
    async def avg_unlock_time_seconds(self, campaign_id: int) -> Optional[float]:
        """Average seconds between a campaign's creation and each unlock."""
        cur = await self.conn.execute(
            """SELECT AVG((julianday(u.unlocked_at) - julianday(rc.created_at)) * 86400.0)
                      AS avg_sec
               FROM payload_unlocks u
               JOIN referral_campaigns rc ON rc.id = u.campaign_id
               WHERE u.campaign_id = ? AND u.unlocked = 1 AND u.unlocked_at IS NOT NULL""",
            (campaign_id,),
        )
        row = await cur.fetchone()
        if not row or row["avg_sec"] is None:
            return None
        return float(row["avg_sec"])
    async def top_campaigns(self, limit: int = 10) -> List[aiosqlite.Row]:
        """Top campaigns by qualified referral count."""
        cur = await self.conn.execute(
            """SELECT rc.id AS campaign_id, rc.payload_id, rc.payload_code,
                      rc.required_referrals, rc.enabled,
                      COUNT(rh.id) AS qualified_count
               FROM referral_campaigns rc
               LEFT JOIN referral_history rh
                 ON rh.campaign_id = rc.id AND rh.qualified = 1
               GROUP BY rc.id
               ORDER BY qualified_count DESC LIMIT ?""",
            (limit,),
        )
        return await cur.fetchall()
    async def _log_access_event_locked(self, event_type: str, *,
                                       payload_id: Optional[int] = None,
                                       campaign_id: Optional[int] = None,
                                       user_id: Optional[int] = None) -> None:
        """INSERT+COMMIT WITHOUT acquiring write_lock.

        ONLY for callers that ALREADY hold self.write_lock (inside
        process_watch_ad_reward / watch_ad_unlock_valid / reconcile). Using
        the public log_access_event there would self-deadlock (asyncio.Lock
        is not re-entrant); using this helper anywhere else would reintroduce
        the V5 concurrency race it exists to fix.

        V26 Phase 6: the admin 📊 Analytics toggle is AUTHENTIC — when
        bot_settings.analytics_enabled is OFF the collection STOPS here
        (the single choke point for BOTH the public and the locked
        callers): the event is dropped BEFORE the INSERT and the analytics
        panels honestly stop growing (no decorative toggle). The setting
        read is a plain SELECT that never acquires the write lock, so the
        reward-transaction discipline above is unchanged; a failed read
        NEVER breaks the caller (collection continues on the safe default).
        """
        try:
            if not await self.get_setting_bool(
                    "analytics_enabled", ENABLE_ANALYTICS):
                return
        except Exception:  # noqa: BLE001 — gating must never break callers
            pass
        try:
            await self.conn.execute(
                """INSERT INTO access_events
                   (event_type, payload_id, campaign_id, user_id, created_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (event_type, payload_id, campaign_id, user_id, _now_iso()),
            )
            await self.conn.commit()
        except Exception as e:  # noqa: BLE001
            logger.debug("access_event log failed (%s): %s", event_type, e)
    async def log_access_event(self, event_type: str, *,
                                payload_id: Optional[int] = None,
                                campaign_id: Optional[int] = None,
                                user_id: Optional[int] = None) -> None:
        """Append a single access analytics event (fire-and-forget, best-effort).

        WATCH_AD V5 (concurrency fix): serialized under write_lock so an
        analytics INSERT can never interleave with an open reward
        transaction on the shared aiosqlite connection (its implicit
        transaction would either join the reward txn or — far worse — its
        COMMIT would commit the reward txn EARLY, breaking exactly-once
        semantics). Callers that already hold the lock must use
        _log_access_event_locked instead (see its docstring).
        """
        async with self.write_lock:
            await self._log_access_event_locked(
                event_type, payload_id=payload_id, campaign_id=campaign_id,
                user_id=user_id)
    async def access_event_count(self, event_type: str,
                                  campaign_id: Optional[int] = None) -> int:
        if campaign_id is not None:
            cur = await self.conn.execute(
                "SELECT COUNT(*) AS c FROM access_events WHERE event_type = ? AND campaign_id = ?",
                (event_type, campaign_id),
            )
        else:
            cur = await self.conn.execute(
                "SELECT COUNT(*) AS c FROM access_events WHERE event_type = ?",
                (event_type,),
            )
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def campaign_full_analytics(self, campaign_id: int) -> Dict[str, Any]:
        """Aggregate analytics for one campaign (used by the analytics panel)."""
        stats = await self.campaign_stats(campaign_id)
        views = await self.access_event_count("campaign_view", campaign_id)
        opens = await self.access_event_count("payload_open", campaign_id)
        preview_views = await self.access_event_count("preview_view", campaign_id)
        ref_opens = await self.access_event_count("ref_link_open", campaign_id)
        unlocks = stats["unlocks"]
        participants = stats["total_participants"]
        unlock_rate = (unlocks / participants * 100.0) if participants > 0 else 0.0
        avg_time = await self.avg_unlock_time_seconds(campaign_id)
        return {
            **stats,
            "campaign_views": views,
            "payload_opens": opens,
            "preview_views": preview_views,
            "ref_link_opens": ref_opens,
            "unlock_rate": round(unlock_rate, 1),
            "avg_unlock_seconds": avg_time,
        }

# ---- Issue #94: Referral link helpers ----

def generate_referral_token() -> str:
    """Generate a unique 16-char hex referral token."""
    return _secrets.token_hex(REFERRAL_TOKEN_LENGTH // 2)
