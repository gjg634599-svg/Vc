"""Website presentation repository (WEBSITE PHASE 3, v31).

``website_payloads`` is the ONE presentation-layer table for the Website
Payload Platform. Every row is a *listing* that REFERENCES the canonical
Payload system — it NEVER copies media rows:

  payload_id     -> payloads.id                      (single-file Payload)
  collection_id  -> collections.collection_id        (multi-file Payload)

Exactly ONE of the two canonical references is set (CHECK constraint) —
mirroring how the Telegram router treats named payloads vs ``c<code>``
collection links. Deliberately NO foreign keys: deleting a canonical
payload/collection must never cascade into (nor be blocked by) Website
presentation state, and deleting a listing must never touch the canonical
system. A listing whose canonical reference has disappeared simply stops
rendering publicly (the feed/detail queries only return listings whose
canonical side still resolves) — honest, never fabricated.

opaque_id (16 hex chars, ``secrets``-generated) is the ONLY public Website
identifier. Database ids, Telegram ids, message ids and ``file_id`` values
are NEVER exposed in Website URLs (spec §7/§20).

Composed into ``app.storage.database.DatabaseBase`` (like every repo mixin);
shares the PayloadsRepoMixin search tokenization helpers — ONE search
system, no parallel engine.
"""
from __future__ import annotations

import logging
import secrets
from typing import Any, Dict, List, Optional, Tuple

import aiosqlite

from app.storage.dbutil import now_iso as _now_iso

logger = logging.getLogger("payload-bot")

# Public opaque identifier length (hex chars). Unguessable, unenumerable —
# the same discipline as collection codes / watch-ad session tokens.
WEBSITE_OPAQUE_ID_LEN = 16

# Feed/search page bounds (DB-side pagination; never the whole catalog).
WEBSITE_PAGE_SIZE_DEFAULT = 12
WEBSITE_PAGE_SIZE_MAX = 60

# Editable listing columns (whitelist — update_website_payload_fields
# rejects anything; column names never come from user input).
_WEBSITE_EDITABLE_FIELDS = frozenset({
    "title", "description", "tags", "position", "published",
    "thumb_file_id", "thumb_file_unique_id",
})

# WEBSITE PHASE 3 UX: feed/search ordering whitelist. The keys are the only
# accepted values of the optional ``order`` parameter (and of the public
# ``?sort=`` query string) — the SQL fragments are fixed constants chosen
# from this table, NEVER built from user input. The default (None/"curated")
# preserves the exact pre-UX ordering: position ASC, id DESC.
_WEBSITE_ORDER_BY = {
    "curated": "ORDER BY w.position ASC, w.id DESC",
    "newest": "ORDER BY w.id DESC",
    "title": "ORDER BY eff_title COLLATE NOCASE ASC, w.id DESC",
}


def generate_website_opaque_id() -> str:
    """Generate a fresh unguessable public Website identifier."""
    return secrets.token_hex(WEBSITE_OPAQUE_ID_LEN // 2)


def _normalize_tags(tags: Optional[str]) -> Optional[str]:
    """Normalize a comma/space separated tag string (bounded, trimmed)."""
    if tags is None:
        return None
    raw = str(tags).strip()
    if not raw:
        return None
    parts = [p.strip().lstrip("#") for p in raw.replace(",", " ").split()]
    parts = [p for p in parts if p][:24]  # bounded tag count
    return " ".join(parts[:24])


class WebsiteRepoMixin:
    """website_payloads presentation listings (WEBSITE PHASE 3, v31)."""

    # ------------------------------------------------------------------
    async def create_website_payload(
        self, *, payload_id: Optional[int] = None,
        collection_id: Optional[str] = None,
        title: Optional[str] = None, description: Optional[str] = None,
        tags: Optional[str] = None,
        thumb_file_id: Optional[str] = None,
        thumb_file_unique_id: Optional[str] = None,
        position: Optional[int] = None, published: int = 0,
        created_by: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        """Create a Website listing referencing the CANONICAL Payload system.

        Exactly one of payload_id / collection_id must be set. Returns the
        created row as a dict (incl. the public opaque_id) or None when the
        canonical reference combination is invalid. The canonical Payload /
        Collection / indexed media rows are NEVER modified here.
        """
        payload_id = int(payload_id) if payload_id is not None else None
        collection_id = (str(collection_id).strip() or None) if collection_id else None
        if (payload_id is None) == (collection_id is None):
            return None  # exactly one canonical reference required
        title = (str(title).strip() or None) if title else None
        if title is not None:
            title = title[:200]
        description = (str(description).strip() or None) if description else None
        if description is not None:
            description = description[:2000]
        tags = _normalize_tags(tags)
        position = int(position) if position is not None else 0
        published = 1 if published else 0
        now = _now_iso()
        async with self.write_lock:
            try:
                if self.conn.in_transaction:
                    logger.warning(
                        "create_website_payload: in_transaction on entry — "
                        "safety ROLLBACK.")
                    await self.conn.execute("ROLLBACK")
            except Exception:  # noqa: BLE001
                pass
            opaque_id = generate_website_opaque_id()
            # Regenerate on the (astronomically unlikely) opaque collision.
            for _ in range(3):
                try:
                    await self.conn.execute(
                        "INSERT INTO website_payloads (opaque_id, payload_id, "
                        "collection_id, title, description, tags, thumb_file_id, "
                        "thumb_file_unique_id, position, published, created_by, "
                        "created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (opaque_id, payload_id, collection_id, title, description,
                         tags, thumb_file_id, thumb_file_unique_id, position,
                         published, created_by, now, now))
                    await self.conn.commit()
                    break
                except aiosqlite.IntegrityError:
                    opaque_id = generate_website_opaque_id()
            else:
                logger.error("create_website_payload: opaque_id collision "
                             "exhausted retries — listing NOT created.")
                return None
        row = await self.get_website_payload_by_opaque(opaque_id)
        return dict(row) if row else None

    # ------------------------------------------------------------------
    async def get_website_payload_by_opaque(
            self, opaque_id: str) -> Optional[aiosqlite.Row]:
        """Fetch a listing by its PUBLIC opaque identifier (never by DB id)."""
        cur = await self.conn.execute(
            "SELECT * FROM website_payloads WHERE opaque_id = ?",
            (str(opaque_id or "").strip(),))
        return await cur.fetchone()

    async def get_website_payload_by_dbid(
            self, dbid: int) -> Optional[aiosqlite.Row]:
        """Fetch a listing by internal DB id (admin-side only)."""
        cur = await self.conn.execute(
            "SELECT * FROM website_payloads WHERE id = ?", (int(dbid),))
        return await cur.fetchone()

    async def find_website_payload_for_canonical(
            self, *, payload_id: Optional[int] = None,
            collection_id: Optional[str] = None) -> Optional[aiosqlite.Row]:
        """Existing listing for a canonical payload/collection (wizard guard)."""
        if payload_id is not None:
            cur = await self.conn.execute(
                "SELECT * FROM website_payloads WHERE payload_id = ? "
                "ORDER BY id LIMIT 1", (int(payload_id),))
            return await cur.fetchone()
        if collection_id:
            cur = await self.conn.execute(
                "SELECT * FROM website_payloads WHERE collection_id = ? "
                "ORDER BY id LIMIT 1", (str(collection_id),))
            return await cur.fetchone()
        return None

    # ------------------------------------------------------------------
    # BOT-43 (spec §11 — work-stream B): the AUTHORITATIVE package
    # association primitives. website_payloads rows with a non-null
    # collection_id ARE the Website's package associations; the package
    # picker's checkmarks and its Continue/diff-save derive from THESE
    # rows (never from transient client state).
    # ------------------------------------------------------------------
    async def list_website_collection_codes(self) -> List[str]:
        """Every package (collection) code currently associated with the
        Website — the AUTHORITATIVE package-picker state.

        Deterministic order (position ASC, id ASC — the curated feed
        order); legacy duplicate listings collapse to the first
        occurrence. Pure read; NEVER touches the canonical system.
        """
        cur = await self.conn.execute(
            "SELECT collection_id FROM website_payloads "
            "WHERE collection_id IS NOT NULL "
            "ORDER BY position ASC, id ASC")
        rows = await cur.fetchall()
        out: List[str] = []
        for r in rows:
            code = str(r["collection_id"] or "").strip()
            if code and code not in out:
                out.append(code)
        return out

    async def _collection_default_title(self, collection_id: str) -> str:
        """The DEFAULT Website listing title for a package — the exact
        fallback chain the wizard publish applies through the
        presentation layer's ``_package_display_name`` (wrapper payload
        display_name → collection branding title → first indexed file
        name → ``Package c<code>``), computed at STORAGE level in ONE
        query so ``apply_website_collection_diff`` can insert honest
        default-titled rows without importing the presentation layer.

        (One tightening vs the presentation chain: an EMPTY file name at
        a chain level falls through to the next candidate here — a
        listing title is never blank.)"""
        code = str(collection_id or "").strip()
        cur = await self.conn.execute(
            """
            SELECT COALESCE(
              (SELECT TRIM(p.display_name) FROM payloads p
                 WHERE p.payload = ?
                   AND TRIM(COALESCE(p.display_name,'')) <> ''
                 ORDER BY p.id ASC LIMIT 1),
              (SELECT TRIM(cb.title) FROM collection_branding cb
                 WHERE cb.collection_id = ?
                   AND TRIM(COALESCE(cb.title,'')) <> ''),
              (SELECT TRIM(i.file_name) FROM collection_items ci
                 JOIN indexed_files i
                   ON i.channel_id = ci.channel_id
                  AND i.message_id = ci.message_id
                 WHERE ci.collection_id = ?
                   AND TRIM(COALESCE(i.file_name,'')) <> ''
                 ORDER BY ci.position ASC LIMIT 1),
              ?)
            """,
            (f"c{code}", code, code, f"Package c{code}"))
        row = await cur.fetchone()
        title = str(row[0]).strip() if row else ""
        return title[:200] or f"Package c{code}"

    async def apply_website_collection_diff(
            self, added: Optional[List[str]] = None,
            removed: Optional[List[str]] = None, *,
            created_by: Optional[int] = None) -> Dict[str, int]:
        """BOT-43 (spec §11): apply a package-association DIFF in ONE
        transactional update (the picker selection IS the desired
        Website association set).

        ``added``   — collection codes to ASSOCIATE: one website_payloads
                      row referencing the collection (default title from
                      the package display-name chain, published=1) is
                      INSERTed per not-yet-listed code.
        ``removed`` — collection codes to DISASSOCIATE: the
                      website_payloads row(s) referencing each code are
                      DELETED — and NOTHING else. NEVER collections,
                      collection_items, indexed_files, storage or any
                      canonical Payload row.

        Every ADDED code is validated against the canonical collections
        table first — one unknown code ROLLS BACK the whole diff and
        raises ``ValueError`` (never a partial state, never a listing
        for a non-existent package). Already-listed added codes are
        skipped (idempotent — never a duplicate listing).

        Returns ``{"added": n, "removed": m, "skipped_existing": k}``.
        Transaction discipline: the shared write_lock + BEGIN IMMEDIATE
        all-or-nothing pattern (create_collection).
        """
        added = list(dict.fromkeys(
            str(c).strip() for c in (added or []) if str(c).strip()))
        removed = list(dict.fromkeys(
            str(c).strip() for c in (removed or []) if str(c).strip()))
        if not added and not removed:
            return {"added": 0, "removed": 0, "skipped_existing": 0}
        now = _now_iso()
        n_added = n_removed = n_skipped = 0
        async with self.write_lock:
            try:
                if self.conn.in_transaction:
                    logger.warning(
                        "apply_website_collection_diff: in_transaction on "
                        "entry — safety ROLLBACK.")
                    await self.conn.execute("ROLLBACK")
            except Exception:  # noqa: BLE001
                pass
            try:
                await self.conn.execute("BEGIN IMMEDIATE")
                # 1) Validate EVERY added code against the canonical
                #    collections table — never trusted client state. One
                #    unknown code aborts the WHOLE diff (rolled back
                #    below — nothing partial ever lands).
                for code in added:
                    cur = await self.conn.execute(
                        "SELECT 1 FROM collections WHERE collection_id = ?",
                        (code,))
                    if await cur.fetchone() is None:
                        raise ValueError(
                            "apply_website_collection_diff: unknown "
                            f"collection {code!r} — nothing applied")
                # 2) Removals: delete ONLY the website_payloads rows
                #    referencing each code (the Website association).
                for code in removed:
                    cur = await self.conn.execute(
                        "DELETE FROM website_payloads "
                        "WHERE collection_id = ?", (code,))
                    n_removed += max(0, int(cur.rowcount or 0))
                # 3) Additions: one listing per not-yet-listed code with
                #    the package's OWN display-name default title (the
                #    same chain website_wizard_publish uses) and the
                #    same INSERT shape as create_website_payload.
                for code in added:
                    cur = await self.conn.execute(
                        "SELECT 1 FROM website_payloads "
                        "WHERE collection_id = ? LIMIT 1", (code,))
                    if await cur.fetchone() is not None:
                        n_skipped += 1  # already associated — idempotent
                        continue
                    title = await self._collection_default_title(code)
                    opaque_id = generate_website_opaque_id()
                    for _attempt in range(3):
                        try:
                            await self.conn.execute(
                                "INSERT INTO website_payloads (opaque_id, "
                                "payload_id, collection_id, title, "
                                "description, tags, thumb_file_id, "
                                "thumb_file_unique_id, position, published, "
                                "created_by, created_at, updated_at) "
                                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                                (opaque_id, None, code, title, None, None,
                                 None, None, 0, 1,
                                 (int(created_by)
                                  if created_by is not None else None),
                                 now, now))
                            n_added += 1
                            break
                        except aiosqlite.IntegrityError:
                            opaque_id = generate_website_opaque_id()
                    else:
                        raise RuntimeError(
                            "apply_website_collection_diff: opaque_id "
                            "collision exhausted retries")
                await self.conn.commit()
                return {"added": n_added, "removed": n_removed,
                        "skipped_existing": n_skipped}
            except Exception:
                try:
                    await self.conn.rollback()
                except Exception:  # noqa: BLE001
                    pass
                logger.error("apply_website_collection_diff failed "
                             "(added=%s removed=%s)", added, removed,
                             exc_info=True)
                raise

    # ------------------------------------------------------------------
    _WEBSITE_FEED_SELECT = (
        "SELECT w.id AS wdbid, w.opaque_id, w.title, w.description, w.tags, "
        "w.position, w.published, w.payload_id, w.collection_id, "
        "w.thumb_file_id, w.thumb_file_unique_id, "
        "COALESCE(w.title, p.display_name, p.payload, w.collection_id) "
        "  AS eff_title, "
        "CASE WHEN w.collection_id IS NOT NULL THEN ("
        "  SELECT COUNT(*) FROM collection_items ci "
        "  WHERE ci.collection_id = w.collection_id) "
        " ELSE 1 END AS file_count, "
        "i.file_unique_id, i.file_name, i.media_type, i.mime_type, "
        "i.file_size, i.width, i.height, "
        # B24 (Phase 4): the canonical payload's index_id so the listing
        # enrichment can detect A.4 multi-file expansion (a single-file
        # Payload whose canonical indexed_file is a MEMBER of a collection)
        # and aggregate the collection's per-type media counts for the
        # truthful outer-card badge ("3 videos · 2 photos" not "1 video").
        "p.index_id AS p_index_id "
    )
    _WEBSITE_FEED_FROM = (
        "FROM website_payloads w "
        "LEFT JOIN payloads p ON p.id = w.payload_id "
        "LEFT JOIN indexed_files i ON i.id = p.index_id "
    )

    async def list_website_payloads_paged(
            self, page: int = 1, page_size: int = WEBSITE_PAGE_SIZE_DEFAULT,
            *, query: Optional[str] = None,
            published_only: bool = True,
            order: Optional[str] = None,
            category_slug: Optional[str] = None,
            include_age_restricted: bool = False
    ) -> Tuple[List[aiosqlite.Row], int]:
        """Website feed / search — DB-side pagination, deterministic order.

        ONE search system: when ``query`` is given the tokenization + escaped
        LIKE prefilter reuse the PayloadsRepoMixin helpers (the exact same
        ``_search_tokens`` / ``_search_escape_like`` primitives as
        ``search_payloads_paged``), applied over the Website presentation
        join (website title/tags/description + canonical payload name).

        Honest visibility: only listings whose canonical reference still
        resolves render publicly (live payload+file, or an existing
        collection). Deterministic ordering: position ASC, id DESC
        (``order=None``/"curated", the exact pre-UX default) or one of the
        whitelisted alternates "newest" (id DESC) / "title" (eff_title
        COLLATE NOCASE ASC, id DESC) — every branch is deterministic.
        Exactly TWO queries (rows + COUNT) per page — N+1-free.
        """
        page = max(1, int(page or 1))
        page_size = max(1, min(WEBSITE_PAGE_SIZE_MAX, int(page_size or
                                                           WEBSITE_PAGE_SIZE_DEFAULT)))
        offset = (page - 1) * page_size
        conds: List[str] = []
        params: List[Any] = []
        if published_only:
            conds.append("w.published = 1")
        conds.append(
            "(w.collection_id IS NOT NULL "
            "OR (p.id IS NOT NULL AND i.id IS NOT NULL))")
        # GAP-CLOSURE spec §26/§29: category filtering + 18+ protection.
        # Age-restricted listings are excluded from EVERY feed (generic or
        # category) unless the caller explicitly passes
        # include_age_restricted=True — which only the presentation layer
        # does for an identity-confirmed age gate. Backend-mandatory, never
        # just frontend hiding.
        if not include_age_restricted:
            conds.append(
                "NOT EXISTS (SELECT 1 FROM website_payload_categories m2 "
                "JOIN website_categories c2 ON c2.id = m2.category_id "
                "WHERE m2.listing_id = w.id AND c2.age_restricted = 1)")
        if category_slug is not None:
            slug = str(category_slug).strip().lower()
            if not slug:
                return [], 0
            # The category must exist AND be enabled+visible.
            conds.append(
                "EXISTS (SELECT 1 FROM website_payload_categories m "
                "JOIN website_categories c ON c.id = m.category_id "
                "WHERE m.listing_id = w.id AND c.slug = ? "
                "AND c.enabled = 1 AND c.visible = 1)")
            params.append(slug)
        if query is not None:
            tokens = self._search_tokens(query)  # shared canonical helpers
            if not tokens:
                return [], 0
            for tok in tokens:
                pat = f"%{self._search_escape_like(tok)}%"
                conds.append(
                    "(LOWER(COALESCE(w.title, '')) LIKE ? ESCAPE '\\' "
                    "OR LOWER(COALESCE(p.display_name, '')) LIKE ? ESCAPE '\\' "
                    "OR LOWER(COALESCE(p.payload, '')) LIKE ? ESCAPE '\\' "
                    "OR LOWER(COALESCE(w.description, '')) LIKE ? ESCAPE '\\' "
                    "OR LOWER(COALESCE(w.tags, '')) LIKE ? ESCAPE '\\')")
                params.extend([pat, pat, pat, pat, pat])
        where = ("WHERE " + " AND ".join(conds)) if conds else ""
        # WEBSITE PHASE 3 UX: whitelisted order (fixed SQL fragments chosen
        # from _WEBSITE_ORDER_BY — user input NEVER reaches the SQL text).
        # Unknown/None values fall back to the original curated ordering.
        order_sql = _WEBSITE_ORDER_BY.get(str(order or "curated").strip().lower(),
                                          _WEBSITE_ORDER_BY["curated"])
        cur = await self.conn.execute(
            f"{self._WEBSITE_FEED_SELECT}{self._WEBSITE_FEED_FROM}{where} "
            f"{order_sql} LIMIT ? OFFSET ?",
            [*params, page_size, offset])
        rows = await cur.fetchall()
        cur2 = await self.conn.execute(
            f"SELECT COUNT(*) AS c {self._WEBSITE_FEED_FROM}{where}", params)
        row2 = await cur2.fetchone()
        total = int(row2["c"]) if row2 else 0
        return rows, total

    # ------------------------------------------------------------------
    # B24 (Phase 4): the LISTING MEDIA-COUNTS enrichment. The feed/search/
    # shelf SQL returns file_count = 1 + the CANONICAL file's media_type
    # for every single-file Payload — even when the canonical file is a
    # MEMBER of a collection (the A.4 multi-file expansion the detail page
    # does). This batch-loads the per-type media counts for a page of
    # listing rows in TWO queries (not N+1) so the outer card badge renders
    # the truthful "3 videos · 2 photos" instead of "1 video".
    # ------------------------------------------------------------------
    async def batch_listing_media_types(
            self, rows: List[dict]) -> Dict[str, Dict[str, int]]:
        """Return ``{opaque_id: {media_kind: count}}`` for the given listing
        rows. Handles BOTH collection listings (``collection_id`` set) AND
        single-file Payloads whose canonical indexed_file belongs to a
        collection (A.4 expansion). Deleted/unavailable files (no matching
        indexed_files row) are excluded — the counts reflect deliverable
        files only. Pure read; never raises (defensive — empty dict on error).
        """
        out: Dict[str, Dict[str, int]] = {}
        try:
            coll_ids: List[str] = []
            idx_ids: List[int] = []
            row_by_opaque: Dict[str, dict] = {}
            for r in rows or []:
                if not isinstance(r, dict):
                    continue
                op = str(r.get("opaque_id") or "")
                if not op:
                    continue
                row_by_opaque[op] = r
                cid = r.get("collection_id")
                if cid:
                    coll_ids.append(str(cid))
                pid = r.get("p_index_id")
                if pid and not cid:
                    try:
                        idx_ids.append(int(pid))
                    except (TypeError, ValueError):
                        pass
            # 2) A.4 detection FIRST: which single-file payload index_ids
            #    are themselves collection members? (lexicographically
            #    smallest collection_id wins — matches
            #    find_collection_id_for_index_id). V25 (§5/§6 PRODUCTION
            #    FIX): the DETECTED collection ids are folded into the
            #    per-type count query below — the B24 code only counted
            #    collections referenced by COLLECTION listings, so an A.4
            #    multi-file payload card received an EMPTY media_counts
            #    and collapsed back to the legacy "1 video" badge (the
            #    exact bot-27 class of bug surviving in the listing path).
            idx_to_coll: Dict[int, str] = {}
            if idx_ids:
                uniq = list(set(idx_ids))
                placeholders = ",".join("?" for _ in uniq)
                cur = await self.conn.execute(
                    "SELECT i.id AS idx, ci.collection_id "
                    "FROM indexed_files i "
                    "JOIN collection_items ci "
                    "  ON ci.channel_id = i.channel_id "
                    " AND ci.message_id = i.message_id "
                    "WHERE i.id IN (" + placeholders + ") "
                    "ORDER BY ci.collection_id ASC",
                    tuple(uniq))
                for row in await cur.fetchall():
                    idx_to_coll[int(row["idx"])] = str(row["collection_id"])
            # 1) per-type counts for every referenced collection — the
            #    listing's own collection_id OR an A.4-detected collection
            all_coll_ids = set(coll_ids) | set(idx_to_coll.values())
            coll_counts: Dict[str, Dict[str, int]] = {}
            if all_coll_ids:
                placeholders = ",".join("?" for _ in all_coll_ids)
                cur = await self.conn.execute(
                    "SELECT ci.collection_id, i.media_type "
                    "FROM collection_items ci "
                    "LEFT JOIN indexed_files i "
                    "  ON i.channel_id = ci.channel_id "
                    " AND i.message_id = ci.message_id "
                    "WHERE ci.collection_id IN (" + placeholders + ") "
                    "  AND i.id IS NOT NULL",
                    tuple(all_coll_ids))
                for row in await cur.fetchall():
                    cid = str(row["collection_id"])
                    mt = str(row["media_type"] or "").lower()
                    # classify via the same _media_kind logic (inline to
                    # avoid a storage→web layering violation)
                    if mt in ("video", "animation"):
                        k = mt
                    elif mt in ("audio", "voice"):
                        k = "audio"
                    elif mt in ("photo", "image"):
                        k = "photo"
                    elif mt == "document":
                        k = "document"
                    else:
                        k = "file"
                    coll_counts.setdefault(cid, {})
                    coll_counts[cid][k] = coll_counts[cid].get(k, 0) + 1
            # 3) assemble per-row counts
            for op, r in row_by_opaque.items():
                cid = r.get("collection_id")
                if cid:
                    out[op] = dict(coll_counts.get(str(cid), {}))
                else:
                    pid = r.get("p_index_id")
                    try:
                        pid_int = int(pid) if pid else 0
                    except (TypeError, ValueError):
                        pid_int = 0
                    if pid_int and pid_int in idx_to_coll:
                        out[op] = dict(coll_counts.get(idx_to_coll[pid_int], {}))
                    else:
                        # true single-file payload — one file of the
                        # canonical media_type
                        mt = str(r.get("media_type") or "").lower()
                        if mt in ("video", "animation"):
                            k = mt
                        elif mt in ("audio", "voice"):
                            k = "audio"
                        elif mt in ("photo", "image"):
                            k = "photo"
                        elif mt == "document":
                            k = "document"
                        else:
                            k = "file"
                        out[op] = {k: 1}
        except Exception:  # noqa: BLE001 — enrichment is additive
            pass
        return out

    # ------------------------------------------------------------------
    # PROMPT B (bot-25 UX pass): the HOME SHELF + MEDIA SIDEBAR queries.
    # Additive + READ-ONLY, built on the SAME visibility contract as the
    # feed (published + live canonical + age-restricted excluded unless
    # the caller explicitly includes them). No authorization decision
    # ever moves here: every card still routes through the server
    # pipeline on click.
    # ------------------------------------------------------------------
    _SHELF_VIS = (
        "w.published = 1 "
        "AND (w.collection_id IS NOT NULL "
        "     OR (p.id IS NOT NULL AND i.id IS NOT NULL))")

    def _shelf_age_guard(self, include_age_restricted: bool,
                         alias: str = "w", m_alias: str = "m2",
                         c_alias: str = "c2") -> str:
        """The age-restriction guard (18+ listings hidden without
        age_ok). ``alias``/``m_alias``/``c_alias`` re-scope the guard to
        a subquery's table aliases (V26 Phase 7 older-history NOT IN
        subquery) — the default aliases keep the direct callers
        unchanged."""
        if include_age_restricted:
            return ""
        return (f"AND NOT EXISTS (SELECT 1 FROM "
                f"website_payload_categories {m_alias} "
                f"JOIN website_categories {c_alias} "
                f"ON {c_alias}.id = {m_alias}.category_id "
                f"WHERE {m_alias}.listing_id = {alias}.id "
                f"AND {c_alias}.age_restricted = 1) ")

    async def trending_website_listings(
            self, limit: int = 6, *, days: int = 7,
            include_age_restricted: bool = False) -> List[aiosqlite.Row]:
        """Trending: listings ranked by 7-day media views.

        A listing's views aggregate over its canonical file (payload) or
        ALL member files (collection) via media_view_events.last_view_at.
        Deterministic tie-break (views DESC, w.id DESC). Zero-view
        listings never appear."""
        import time as _time
        cutoff = _time.strftime(
            "%Y-%m-%dT%H:%M:%S",
            _time.gmtime(_time.time() - int(days) * 86400))
        cur = await self.conn.execute(
            f"""
            {self._WEBSITE_FEED_SELECT},
              (SELECT COUNT(*) FROM media_view_events mve
                 WHERE mve.last_view_at >= ?
                   AND (mve.file_pk = i.id OR mve.file_pk IN (
                        SELECT ci2.id FROM collection_items ci2x
                        JOIN indexed_files ci2 ON ci2.channel_id =
                          ci2x.channel_id AND ci2.message_id = ci2x.message_id
                        WHERE ci2x.collection_id = w.collection_id))) AS views7
            {self._WEBSITE_FEED_FROM}
            WHERE {self._SHELF_VIS} {self._shelf_age_guard(include_age_restricted)}
            GROUP BY w.id
            HAVING views7 > 0
            ORDER BY views7 DESC, w.id DESC
            LIMIT ?
            """,
            (cutoff, int(limit)))
        return await cur.fetchall()

    async def recently_added_website_listings(
            self, limit: int = 12, *,
            include_age_restricted: bool = False,
            recent_cutoff: Optional[str] = None) -> List[aiosqlite.Row]:
        """Recently added: the feed's deterministic 'newest' order (id
        DESC) — the Recently Added shelf.

        V25 §21 Recent→Normal lifecycle: with ``recent_cutoff`` (the ISO
        instant exactly 24h ago, computed SERVER-side in UTC — the client
        clock is never consulted) the shelf returns ONLY payloads younger
        than 24 hours: ``created_at`` strictly AFTER the cutoff, so a
        payload created exactly at the boundary is already Normal. The
        classification is COMPUTED from the canonical ``created_at`` on
        every call — never a stored ``is_recent`` boolean that could go
        stale (no database rewrite is needed merely to age a payload
        out). ``julianday()`` normalizes every legacy ISO shape (naive,
        +00:00, non-UTC offsets) to true chronological order; an
        unparseable timestamp (julianday NULL) never enters the Recent
        shelf (safe fallback: the older-content query owns it). The
        ordering is the CANONICAL ``created_at`` DESC (julianday-
        normalized, ``w.id DESC`` deterministic tie-break) — not the
        insertion id — so backdated/imported rows sort truthfully and a
        newer Recent payload is never buried under an older one."""
        recent_sql = ""
        params: List[Any] = []
        if recent_cutoff:
            recent_sql = (" AND julianday(w.created_at) > julianday(?) ")
            params.append(str(recent_cutoff))
        cur = await self.conn.execute(
            f"{self._WEBSITE_FEED_SELECT} {self._WEBSITE_FEED_FROM} "
            f"WHERE {self._SHELF_VIS} "
            f"{self._shelf_age_guard(include_age_restricted)}"
            f"{recent_sql}"
            f"ORDER BY COALESCE(julianday(w.created_at), 0) DESC, "
            f"w.id DESC LIMIT ?",
            (*params, int(limit)))
        return await cur.fetchall()

    async def older_website_listings(
            self, limit: int = 24, *,
            include_age_restricted: bool = False,
            recent_cutoff: Optional[str] = None) -> List[aiosqlite.Row]:
        """Normal/older content (V25 §21): everything beyond the 24h
        Recent window, newest first — the shelf a payload moves to when
        it ages out of Recent. Disjoint from the Recent shelf by the
        SAME cutoff predicate (``<=`` vs ``>``) so a payload crossing the
        24h boundary moves between shelves with NO duplicate cards and
        NO disappearance. Unparseable/legacy timestamps (julianday NULL)
        land HERE (COALESCE 0) — never dropped from the page; they sort
        after every parseable timestamp by the deterministic id
        tie-break. Ordering: canonical ``created_at`` DESC."""
        recent_sql = ""
        params: List[Any] = []
        if recent_cutoff:
            recent_sql = (" AND COALESCE(julianday(w.created_at), 0) "
                          "<= julianday(?) ")
            params.append(str(recent_cutoff))
        cur = await self.conn.execute(
            f"{self._WEBSITE_FEED_SELECT} {self._WEBSITE_FEED_FROM} "
            f"WHERE {self._SHELF_VIS} "
            f"{self._shelf_age_guard(include_age_restricted)}"
            f"{recent_sql}"
            f"ORDER BY COALESCE(julianday(w.created_at), 0) DESC, "
            f"w.id DESC LIMIT ?",
            (*params, int(limit)))
        return await cur.fetchall()

    async def older_history_website_listings(
            self, exclude_newest: int = 10, limit: int = 24, *,
            include_age_restricted: bool = False
    ) -> List[aiosqlite.Row]:
        """V26 Phase 7 — OLDER HISTORY: every visible listing beyond the
        newest ``exclude_newest`` (the PRIMARY RECENT shelf's members),
        newest first — the horizontal history shelf an upload moves to
        when a NEWER arrival pushes it out of the primary ten.

        The exclusion is IDENTITY-BASED, not time-based: ``NOT IN`` over
        the EXACT ordering the primary shelf uses (canonical
        ``COALESCE(julianday(w.created_at), 0) DESC, w.id DESC,
        LIMIT exclude_newest`` with the same published/live-canonical
        visibility and the same age-restriction guard), so the two
        shelves are exactly COMPLEMENTARY for this viewer: a listing is
        in precisely one of them, the boundary is deterministic (the
        shared ORDER BY + tie-break — identical created_at values can
        never split ambiguously), and the push-out happens purely by
        COMPUTATION on render (no database rewrite, no row is ever
        deleted — historical rows stay fully browsable here and via the
        paginated Library/Search feed). Unparseable legacy timestamps
        (julianday NULL → COALESCE 0) sort after every parseable one and
        are owned HERE — never dropped from the page.
        """
        guard2 = self._shelf_age_guard(
            include_age_restricted, alias="w2", m_alias="m3",
            c_alias="c3")
        cur = await self.conn.execute(
            f"{self._WEBSITE_FEED_SELECT} {self._WEBSITE_FEED_FROM} "
            f"WHERE {self._SHELF_VIS} "
            f"{self._shelf_age_guard(include_age_restricted)}"
            f"AND w.id NOT IN ("
            f"  SELECT w2.id FROM website_payloads w2 "
            f"  LEFT JOIN payloads p2 ON p2.id = w2.payload_id "
            f"  LEFT JOIN indexed_files i2 ON i2.id = p2.index_id "
            f"  WHERE w2.published = 1 "
            f"    AND (w2.collection_id IS NOT NULL "
            f"         OR (p2.id IS NOT NULL AND i2.id IS NOT NULL)) "
            f"    {guard2}"
            f"  ORDER BY COALESCE(julianday(w2.created_at), 0) DESC, "
            f"  w2.id DESC LIMIT ?) "
            f"ORDER BY COALESCE(julianday(w.created_at), 0) DESC, "
            f"w.id DESC LIMIT ?",
            (int(exclude_newest), int(limit)))
        return await cur.fetchall()

    async def newest_in_category(
            self, category_slug: str, limit: int = 6, *,
            include_age_restricted: bool = False
    ) -> List[aiosqlite.Row]:
        """New in [category]: the newest listings inside ONE category."""
        cur = await self.conn.execute(
            f"{self._WEBSITE_FEED_SELECT} {self._WEBSITE_FEED_FROM} "
            f"WHERE {self._SHELF_VIS} "
            f"{self._shelf_age_guard(include_age_restricted)} "
            f"AND EXISTS (SELECT 1 FROM website_payload_categories m "
            f" JOIN website_categories c ON c.id = m.category_id "
            f" WHERE m.listing_id = w.id AND c.slug = ? "
            f"   AND c.enabled = 1 AND c.visible = 1) "
            f"ORDER BY w.id DESC LIMIT ?",
            (str(category_slug).strip().lower(), int(limit)))
        return await cur.fetchall()

    async def related_website_listings(
            self, listing_dbid: int, *, category_slug: Optional[str] = None,
            tags: Optional[List[str]] = None, limit: int = 6,
            include_age_restricted: bool = False) -> List[aiosqlite.Row]:
        """Related payloads for the media sidebar / because-you-watched.

        Same-category candidates first (the feed visibility contract);
        shared-tag ranking (>=2 common tags preferred) is applied on the
        returned rows — SQL stays simple + deterministic."""
        cat = ""
        params: List[Any] = []
        if category_slug:
            cat = ("AND EXISTS (SELECT 1 FROM website_payload_categories m "
                   "JOIN website_categories c ON c.id = m.category_id "
                   "WHERE m.listing_id = w.id AND c.slug = ? "
                   "AND c.enabled = 1 AND c.visible = 1) ")
            params.append(str(category_slug).strip().lower())
        cur = await self.conn.execute(
            f"{self._WEBSITE_FEED_SELECT} {self._WEBSITE_FEED_FROM} "
            f"WHERE {self._SHELF_VIS} "
            f"{self._shelf_age_guard(include_age_restricted)} {cat} "
            f"AND w.id != ? ORDER BY w.id DESC LIMIT ?",
            [*params, int(listing_dbid), max(int(limit) * 3, 18)])
        rows = await cur.fetchall()
        if not tags:
            return rows[:int(limit)]
        want = {str(t).strip().lower() for t in tags if str(t).strip()}
        if not want:
            return rows[:int(limit)]

        def _shared(row) -> int:
            have = {t.strip().lower() for t in
                    str(row["tags"] or "").replace(";", ",").split(",")
                    if t.strip()}
            return len(want & have)

        ranked = sorted(rows, key=lambda r: (-_shared(r), -int(r["wdbid"])))
        chosen = [r for r in ranked if _shared(r) >= 2][:int(limit)]
        for r in ranked:
            if len(chosen) >= int(limit):
                break
            if r not in chosen:
                chosen.append(r)
        return chosen[:int(limit)]

    async def recently_viewed_website_listings(
            self, viewer_key: str, limit: int = 12, *,
            include_age_restricted: bool = False
    ) -> List[aiosqlite.Row]:
        """Continue-Watching candidates: THIS viewer's most recent view
        events mapped to listings (payload canonical file or collection
        member). The resume POSITION itself stays client-side (the
        plresume localStorage store) — the shelf hydrates from it and
        hides when nothing has a live resume."""
        cur = await self.conn.execute(
            f"""
            {self._WEBSITE_FEED_SELECT},
              (SELECT MAX(mve.last_view_at) FROM media_view_events mve
                 WHERE mve.viewer_key = ?
                   AND (mve.file_pk = i.id OR mve.file_pk IN (
                        SELECT ci2.id FROM collection_items ci2x
                        JOIN indexed_files ci2 ON ci2.channel_id =
                          ci2x.channel_id AND ci2.message_id = ci2x.message_id
                        WHERE ci2x.collection_id = w.collection_id))
              ) AS last_view
            {self._WEBSITE_FEED_FROM}
            WHERE {self._SHELF_VIS}
              {self._shelf_age_guard(include_age_restricted)}
            AND last_view IS NOT NULL
            ORDER BY last_view DESC, w.id DESC
            LIMIT ?
            """,
            (str(viewer_key), int(limit)))
        return await cur.fetchall()

    async def listing_categories_of(self, listing_dbid: int
                                    ) -> List[aiosqlite.Row]:
        """The categories of ONE listing (the most-viewed-category shelf
        + card 18+ badge lookup + the V26 FINAL nav-chain breadcrumb).

        V26 FINAL fix: the ORDER BY referenced a non-existent ``position``
        column (the schema column is ``sort_order``) — every call raised
        ``no such column: c.position`` and the callers swallowed it, so
        the most-viewed-category shelf silently degraded and the nav
        breadcrumb lost its category step."""
        cur = await self.conn.execute(
            "SELECT c.slug, c.name, c.age_restricted "
            "FROM website_payload_categories m "
            "JOIN website_categories c ON c.id = m.category_id "
            "WHERE m.listing_id = ? AND c.enabled = 1 AND c.visible = 1 "
            "ORDER BY c.sort_order, c.id", (int(listing_dbid),))
        return await cur.fetchall()

    async def update_website_payload_fields(
            self, dbid: int, fields: Dict[str, Any]) -> bool:
        """Update whitelisted listing fields (title/description/tags/position/
        published/thumb refs). Presentation-layer ONLY — the canonical
        Payload is never touched. Returns True when a row changed."""
        clean: Dict[str, Any] = {}
        for key, value in (fields or {}).items():
            if key not in _WEBSITE_EDITABLE_FIELDS:
                raise ValueError(f"non-editable website field: {key}")
            if key in ("title", "description", "tags", "thumb_file_id",
                       "thumb_file_unique_id") and value is not None:
                value = str(value)
            if key == "title" and value:
                value = str(value).strip()[:200] or None
            if key == "description" and value:
                value = str(value).strip()[:2000] or None
            if key == "tags":
                value = _normalize_tags(value)
            if key in ("position", "published") and value is not None:
                value = int(value)
            clean[key] = value
        if not clean:
            return False
        sets = ", ".join(f"{k} = ?" for k in clean)
        async with self.write_lock:
            cur = await self.conn.execute(
                f"UPDATE website_payloads SET {sets}, updated_at = ? "
                "WHERE id = ?",
                [*clean.values(), _now_iso(), int(dbid)])
            await self.conn.commit()
        return cur.rowcount > 0

    # ------------------------------------------------------------------
    async def delete_website_payload(self, dbid: int) -> bool:
        """Delete a Website LISTING (presentation-layer only).

        NEVER deletes the canonical Payload, indexed media, Collection,
        Telegram source or media identity (spec §18) — this is a single-row
        DELETE on website_payloads.
        """
        async with self.write_lock:
            cur = await self.conn.execute(
                "DELETE FROM website_payloads WHERE id = ?", (int(dbid),))
            await self.conn.commit()
        return cur.rowcount > 0

    async def count_website_payloads(
            self, published_only: bool = False) -> int:
        cond = "WHERE published = 1" if published_only else ""
        cur = await self.conn.execute(
            f"SELECT COUNT(*) AS c FROM website_payloads {cond}")
        row = await cur.fetchone()
        return int(row["c"]) if row else 0

    async def list_website_payloads_admin(
            self, page: int = 1, page_size: int = 10
    ) -> Tuple[List[aiosqlite.Row], int]:
        """Admin management listing (ALL listings incl. unpublished) with a
        canonical-resolution marker so the admin sees dangling listings."""
        page = max(1, int(page or 1))
        page_size = max(1, min(50, int(page_size or 10)))
        offset = (page - 1) * page_size
        cur = await self.conn.execute(
            "SELECT w.id AS wdbid, w.opaque_id, w.title, w.position, "
            "w.published, w.payload_id, w.collection_id, w.created_at, "
            "COALESCE(w.title, p.display_name, p.payload, w.collection_id) "
            "  AS eff_title, "
            "CASE WHEN w.collection_id IS NOT NULL THEN ("
            "  SELECT COUNT(*) FROM collection_items ci "
            "  WHERE ci.collection_id = w.collection_id) "
            " WHEN p.id IS NOT NULL THEN 1 ELSE 0 END AS file_count, "
            "CASE WHEN w.collection_id IS NOT NULL THEN "
            "  (SELECT COUNT(*) FROM collections cc "
            "   WHERE cc.collection_id = w.collection_id) "
            " WHEN p.id IS NOT NULL THEN "
            "  (SELECT COUNT(*) FROM payloads pp WHERE pp.id = w.payload_id) "
            " ELSE 0 END AS canonical_alive "
            "FROM website_payloads w "
            "LEFT JOIN payloads p ON p.id = w.payload_id "
            "ORDER BY w.position ASC, w.id DESC LIMIT ? OFFSET ?",
            (page_size, offset))
        rows = await cur.fetchall()
        cur2 = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM website_payloads")
        row2 = await cur2.fetchone()
        total = int(row2["c"]) if row2 else 0
        return rows, total
