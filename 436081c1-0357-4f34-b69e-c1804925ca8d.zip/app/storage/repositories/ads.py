"""ADS repository (GAP-CLOSURE v33, spec §35-§56).

The persistent side of the centralized Ads Platform: campaigns,
creatives, placement toggles, events, and the server-side frequency
state keyed by the AUTHENTICATED Telegram identity (spec §52 — never
client-supplied ids).

Security invariants:
  * creative URLs are validated on EVERY write AND read (HTTPS only;
    javascript:/data:/file: rejected — spec §48)
  * events carry opaque creative ids only; no PII beyond the Telegram
    user id (the same identity the whole platform already stores)
  * frequency state is keyed by user_id + placement + window
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, List, Optional
from urllib.parse import urlsplit

import aiosqlite

from app.storage.dbutil import now_iso as _now_iso

logger = logging.getLogger("payload-bot")

# The placement registry (spec §37/§49) — the complete fixed vocabulary.
AD_PLACEMENT_KEYS = (
    "AD_TOP", "AD_HOME_HERO", "AD_HOME_BETWEEN_CONTENT",
    "AD_CATEGORY_TOP", "AD_CATEGORY_BETWEEN", "AD_PAYLOAD_DETAIL",
    "AD_VIDEO_BEFORE", "AD_VIDEO_MIDROLL", "AD_VIDEO_END",
    "AD_SIDEBAR", "AD_FOOTER",
)

# Creative kinds (spec §36).
AD_CREATIVE_KINDS = (
    "video", "banner_image", "banner_responsive", "html", "provider",
)

# Event vocabulary (spec §51) — bounded, no spam.
AD_EVENT_TYPES = (
    "impression", "click", "start", "q25", "q50", "q75", "complete",
    "skip", "failure",
)

_URL_SCHEME_RE = re.compile(r"^https?://", re.IGNORECASE)


def validate_ad_url(url: Optional[str]) -> Optional[str]:
    """HTTPS-only URL validation (spec §48). Rejects javascript:, data:,
    file: and any non-http(s) scheme; returns the normalized URL or None."""
    if url is None:
        return None
    raw = str(url).strip()
    if not raw:
        return None
    if not _URL_SCHEME_RE.match(raw):
        return None
    parts = urlsplit(raw)
    if not parts.hostname or "." not in parts.hostname:
        return None
    if parts.scheme.lower() != "https":
        return None  # HTTPS only (http rejected)
    return raw[:2000]


def _parse_json_list(raw: Optional[str]) -> Optional[List[str]]:
    if raw is None or str(raw).strip() == "":
        return None
    try:
        val = json.loads(str(raw))
        if isinstance(val, list):
            return [str(v) for v in val][:32]
    except Exception:  # noqa: BLE001
        return None
    return None


class AdsRepoMixin:
    """ad_campaigns / ad_creatives / ad_placements / ad_events /
    ad_frequency_state (v33)."""

    # -------------------------------------------------------- campaigns
    async def create_ad_campaign(
        self, *, name: str, status: str = "draft", priority: int = 0,
        start_at: Optional[str] = None, end_at: Optional[str] = None,
        frequency_cap_per_user: int = 0, frequency_cap_hours: int = 24,
        placements: Optional[List[str]] = None,
        categories: Optional[List[str]] = None,
        devices: Optional[List[str]] = None, enabled: int = 1,
    ) -> Optional[int]:
        name = str(name or "").strip()[:80]
        if not name:
            return None
        status = status if status in ("draft", "active", "paused", "ended") \
            else "draft"
        now = _now_iso()
        try:
            cur = await self.conn.execute(
                """INSERT INTO ad_campaigns
                   (name, status, priority, start_at, end_at,
                    frequency_cap_per_user, frequency_cap_hours,
                    placements, categories, devices, enabled,
                    created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (name, status, int(priority), start_at, end_at,
                 int(frequency_cap_per_user or 0),
                 max(1, int(frequency_cap_hours or 24)),
                 json.dumps(placements) if placements else None,
                 json.dumps(categories) if categories else None,
                 json.dumps(devices) if devices else None,
                 1 if int(enabled) else 0, now, now))
            await self.conn.commit()
            return int(cur.lastrowid)
        except Exception as exc:  # noqa: BLE001
            logger.warning("create ad campaign failed: %s", exc)
            return None

    async def get_ad_campaign(self, campaign_id: int
                              ) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM ad_campaigns WHERE id = ?", (int(campaign_id),))
        return await cur.fetchone()

    async def list_ad_campaigns(self, *, include_disabled: bool = True
                                ) -> List[aiosqlite.Row]:
        cond = "" if include_disabled else "WHERE enabled = 1"
        cur = await self.conn.execute(
            f"SELECT * FROM ad_campaigns {cond} "
            "ORDER BY priority DESC, id DESC")
        return list(await cur.fetchall())

    async def update_ad_campaign_fields(
            self, campaign_id: int, fields: Dict[str, Any]) -> bool:
        allowed_keys = {"name", "status", "priority", "start_at", "end_at",
                        "frequency_cap_per_user", "frequency_cap_hours",
                        "placements", "categories", "devices", "enabled"}
        allowed = {}
        for k, v in (fields or {}).items():
            if k not in allowed_keys:
                continue
            if k in ("placements", "categories", "devices"):
                if v is None or (isinstance(v, list) and not v):
                    allowed[k] = None
                elif isinstance(v, list):
                    allowed[k] = json.dumps([str(x) for x in v][:32])
                else:
                    allowed[k] = json.dumps([str(v)])
            elif k == "status":
                if v in ("draft", "active", "paused", "ended"):
                    allowed[k] = v
            elif k == "enabled":
                allowed[k] = 1 if int(v) else 0
            elif k in ("frequency_cap_per_user", "priority"):
                allowed[k] = max(0, int(v or 0))
            elif k == "frequency_cap_hours":
                allowed[k] = max(1, int(v or 24))
            else:
                allowed[k] = str(v)[:80] if v else None
        if not allowed:
            return False
        sets = ", ".join(f"{k} = ?" for k in allowed)
        try:
            await self.conn.execute(
                f"UPDATE ad_campaigns SET {sets}, updated_at = ? WHERE id = ?",
                [*allowed.values(), _now_iso(), int(campaign_id)])
            await self.conn.commit()
            return True
        except Exception as exc:  # noqa: BLE001
            logger.warning("update ad campaign failed: %s", exc)
            return False

    async def delete_ad_campaign(self, campaign_id: int) -> bool:
        try:
            await self.conn.execute(
                "DELETE FROM ad_creatives WHERE campaign_id = ?",
                (int(campaign_id),))
            await self.conn.execute(
                "DELETE FROM ad_campaigns WHERE id = ?", (int(campaign_id),))
            await self.conn.commit()
            return True
        except Exception as exc:  # noqa: BLE001
            logger.warning("delete ad campaign failed: %s", exc)
            return False

    # ------------------------------------------------------- creatives
    async def create_ad_creative(
        self, *, campaign_id: int, kind: str, title: str = "",
        video_url: Optional[str] = None,
        image_desktop_url: Optional[str] = None,
        image_mobile_url: Optional[str] = None,
        html_content: Optional[str] = None,
        click_url: Optional[str] = None, alt_text: str = "",
        duration_seconds: int = 0, skip_enabled: int = 1,
        skip_after_seconds: int = 5, provider_zone: Optional[str] = None,
        enabled: int = 1,
    ) -> Optional[int]:
        """Create a creative with STRICT URL validation (HTTPS only)."""
        if kind not in AD_CREATIVE_KINDS:
            return None
        v_video = validate_ad_url(video_url) if video_url else None
        v_desktop = validate_ad_url(image_desktop_url) \
            if image_desktop_url else None
        v_mobile = validate_ad_url(image_mobile_url) \
            if image_mobile_url else None
        v_click = validate_ad_url(click_url) if click_url else None
        if video_url and not v_video:
            return None
        if image_desktop_url and not v_desktop:
            return None
        if image_mobile_url and not v_mobile:
            return None
        if click_url and not v_click:
            return None
        # kind-specific requirements
        if kind == "video" and not v_video:
            return None
        if kind == "banner_image" and not (v_desktop or v_mobile):
            return None
        if kind == "html" and not (html_content or "").strip():
            return None
        if kind == "provider" and not (provider_zone or "").strip():
            return None
        now = _now_iso()
        try:
            cur = await self.conn.execute(
                """INSERT INTO ad_creatives
                   (campaign_id, kind, title, video_url, image_desktop_url,
                    image_mobile_url, html_content, click_url, alt_text,
                    duration_seconds, skip_enabled, skip_after_seconds,
                    provider_zone, enabled, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (int(campaign_id), kind, str(title or "")[:120],
                 v_video, v_desktop, v_mobile,
                 str(html_content or "")[:20000] if html_content else None,
                 v_click, str(alt_text or "")[:200],
                 max(0, min(600, int(duration_seconds or 0))),
                 1 if int(skip_enabled) else 0,
                 max(0, min(60, int(skip_after_seconds or 0))),
                 str(provider_zone or "")[:64] if provider_zone else None,
                 1 if int(enabled) else 0, now, now))
            await self.conn.commit()
            return int(cur.lastrowid)
        except Exception as exc:  # noqa: BLE001
            logger.warning("create ad creative failed: %s", exc)
            return None

    async def get_ad_creative(self, creative_id: int
                              ) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM ad_creatives WHERE id = ?", (int(creative_id),))
        return await cur.fetchone()

    async def list_ad_creatives(
            self, campaign_id: Optional[int] = None,
            *, include_disabled: bool = True) -> List[aiosqlite.Row]:
        if campaign_id is None:
            cond = "" if include_disabled else "WHERE enabled = 1"
            cur = await self.conn.execute(
                f"SELECT * FROM ad_creatives {cond} ORDER BY id DESC")
        else:
            cond = "" if include_disabled else "AND enabled = 1"
            cur = await self.conn.execute(
                f"SELECT * FROM ad_creatives WHERE campaign_id = ? {cond} "
                "ORDER BY id DESC", (int(campaign_id),))
        return list(await cur.fetchall())

    async def update_ad_creative_fields(
            self, creative_id: int, fields: Dict[str, Any]) -> bool:
        allowed_keys = {"title", "video_url", "image_desktop_url",
                        "image_mobile_url", "html_content", "click_url",
                        "alt_text", "duration_seconds", "skip_enabled",
                        "skip_after_seconds", "provider_zone", "enabled"}
        allowed: Dict[str, Any] = {}
        for k, v in (fields or {}).items():
            if k not in allowed_keys:
                continue
            if k.endswith("_url"):
                if v is None or str(v).strip() == "":
                    allowed[k] = None
                else:
                    val = validate_ad_url(str(v))
                    if val is None:
                        return False  # invalid URL -> refuse the whole update
                    allowed[k] = val
            elif k == "enabled":
                allowed[k] = 1 if int(v) else 0
            elif k == "skip_enabled":
                allowed[k] = 1 if int(v) else 0
            elif k == "duration_seconds":
                allowed[k] = max(0, min(600, int(v or 0)))
            elif k == "skip_after_seconds":
                allowed[k] = max(0, min(60, int(v or 0)))
            elif k == "html_content":
                allowed[k] = str(v or "")[:20000] if v else None
            else:
                allowed[k] = str(v or "")[:200] if v else ""
        if not allowed:
            return False
        sets = ", ".join(f"{k} = ?" for k in allowed)
        try:
            await self.conn.execute(
                f"UPDATE ad_creatives SET {sets}, updated_at = ? WHERE id = ?",
                [*allowed.values(), _now_iso(), int(creative_id)])
            await self.conn.commit()
            return True
        except Exception as exc:  # noqa: BLE001
            logger.warning("update ad creative failed: %s", exc)
            return False

    async def delete_ad_creative(self, creative_id: int) -> bool:
        try:
            await self.conn.execute(
                "DELETE FROM ad_creatives WHERE id = ?", (int(creative_id),))
            await self.conn.commit()
            return True
        except Exception as exc:  # noqa: BLE001
            logger.warning("delete ad creative failed: %s", exc)
            return False

    # ------------------------------------------------------ placements
    async def get_ad_placement_enabled(self, key: str) -> bool:
        cur = await self.conn.execute(
            "SELECT enabled FROM ad_placements WHERE key = ?",
            (str(key),))
        row = await cur.fetchone()
        return bool(row and int(row["enabled"]))

    async def set_ad_placement_enabled(self, key: str, enabled: bool) -> bool:
        if key not in AD_PLACEMENT_KEYS:
            return False
        await self.conn.execute(
            """INSERT INTO ad_placements (key, enabled, updated_at)
               VALUES (?, ?, ?)
               ON CONFLICT(key) DO UPDATE SET enabled = excluded.enabled,
                   updated_at = excluded.updated_at""",
            (str(key), 1 if enabled else 0, _now_iso()))
        await self.conn.commit()
        return True

    async def list_ad_placements(self) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM ad_placements ORDER BY key ASC")
        return list(await cur.fetchall())

    # --------------------------------------------------------- events
    async def log_ad_event(self, creative_id: int, campaign_id: int,
                           placement: str, user_id: Optional[int],
                           event: str) -> None:
        if event not in AD_EVENT_TYPES:
            return
        try:
            await self.conn.execute(
                """INSERT INTO ad_events
                   (creative_id, campaign_id, placement, user_id, event,
                    created_at) VALUES (?, ?, ?, ?, ?, ?)""",
                (int(creative_id), int(campaign_id), str(placement)[:40],
                 int(user_id) if user_id else None, event, _now_iso()))
            await self.conn.commit()
        except Exception as exc:  # noqa: BLE001 — analytics never blocks ads
            logger.warning("ad event insert failed: %s", exc)

    async def ad_analytics_summary(self, days: int = 7) -> Dict[str, Any]:
        """Aggregated ad metrics (spec §51) — impressions, clicks, CTR,
        video quartiles/completions, skips, failures. Real rows only."""
        from app.storage.repositories.network import _iso_days_ago
        since = _iso_days_ago(days)
        out: Dict[str, Any] = {"days": days}
        try:
            cur = await self.conn.execute(
                """SELECT event, COUNT(*) AS n FROM ad_events
                   WHERE created_at >= ? GROUP BY event""",
                (since,))
            by_event = {str(r["event"]): int(r["n"])
                        for r in await cur.fetchall()}
        except Exception:  # noqa: BLE001
            by_event = {}
        out["events"] = by_event
        out["impressions"] = by_event.get("impression", 0)
        out["clicks"] = by_event.get("click", 0)
        out["video_starts"] = by_event.get("start", 0)
        out["completions"] = by_event.get("complete", 0)
        out["skips"] = by_event.get("skip", 0)
        out["failures"] = by_event.get("failure", 0)
        out["ctr"] = (round(out["clicks"] / out["impressions"], 4)
                      if out["impressions"] else None)
        # per-creative rows (top 20)
        try:
            cur = await self.conn.execute(
                """SELECT creative_id, COUNT(*) AS impressions,
                          SUM(CASE WHEN event = 'click' THEN 1 ELSE 0 END)
                              AS clicks
                   FROM ad_events WHERE created_at >= ?
                     AND event IN ('impression', 'click')
                   GROUP BY creative_id ORDER BY impressions DESC LIMIT 20""",
                (since,))
            out["per_creative"] = [
                {"creative_id": int(r["creative_id"]),
                 "impressions": int(r["impressions"]),
                 "clicks": int(r["clicks"] or 0)}
                for r in await cur.fetchall()]
        except Exception:  # noqa: BLE001
            out["per_creative"] = []
        return out

    # ------------------------------------------------- frequency state
    async def ad_frequency_get(self, user_id: int, placement: str,
                               window_key: str) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            """SELECT * FROM ad_frequency_state
               WHERE user_id = ? AND placement = ? AND window_key = ?""",
            (int(user_id), str(placement), str(window_key)))
        return await cur.fetchone()

    async def ad_frequency_bump(self, user_id: int, placement: str,
                                window_key: str) -> int:
        """Atomically increment the (user, placement, window) counter and
        return the NEW count."""
        now = _now_iso()
        try:
            await self.conn.execute(
                """INSERT INTO ad_frequency_state
                   (user_id, placement, window_key, count, last_shown_at)
                   VALUES (?, ?, ?, 1, ?)
                   ON CONFLICT(user_id, placement, window_key)
                   DO UPDATE SET count = count + 1, last_shown_at = ?""",
                (int(user_id), str(placement), str(window_key), now, now))
            await self.conn.commit()
            row = await self.ad_frequency_get(user_id, placement, window_key)
            return int(row["count"]) if row else 1
        except Exception as exc:  # noqa: BLE001
            logger.warning("ad frequency bump failed: %s", exc)
            return 0

    async def ad_frequency_counts(self, user_id: int,
                                  window_key: str
                                  ) -> Dict[str, int]:
        """count per placement for one user+window (session cap checks)."""
        cur = await self.conn.execute(
            """SELECT placement, count FROM ad_frequency_state
               WHERE user_id = ? AND window_key = ?""",
            (int(user_id), str(window_key)))
        return {str(r["placement"]): int(r["count"])
                for r in await cur.fetchall()}

    async def list_ad_exempt_users(self) -> List[int]:
        """The ads_exempt list is stored as a bot_settings JSON/CSV list —
        backend-controlled only (spec §46: never localStorage)."""
        cur = await self.conn.execute(
            "SELECT value FROM bot_settings WHERE key = 'ads_exempt_user_ids'")
        row = await cur.fetchone()
        if not row or not str(row["value"] or "").strip():
            return []
        raw = str(row["value"])
        ids: List[int] = []
        try:
            val = json.loads(raw)
            if isinstance(val, list):
                ids = [int(x) for x in val if str(x).strip().isdigit()]
        except Exception:  # noqa: BLE001 — CSV fallback
            ids = [int(x) for x in raw.replace(",", " ").split()
                   if x.strip().isdigit()]
        return ids[:500]
