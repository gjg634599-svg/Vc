"""Idempotent SQLite migration primitives (ARCHITECTURE PHASE).

The versioned migration CHAIN itself (the ``if current < N`` blocks up
to the current SCHEMA_VERSION) lives in ``Database._migrate`` in
app/storage/schema.py — its structure is pinned by the regression
suites (see docs/ARCHITECTURE_AUDIT.md §3). This module provides the
reusable primitives that ``DatabaseBase`` (and any future migration
code) composes, plus the documentation registry recording every schema
step.
"""
from __future__ import annotations

import logging
from typing import Optional

import aiosqlite

logger = logging.getLogger("payload-bot")

# The additive schema chain (documentation registry — the authoritative
# executor is Database._migrate in app/storage/schema.py; the current
# SCHEMA_VERSION = 42). Steps v33-v42 were added directly in
# app/storage/schema.py's chain (BOT-13 era onward); this registry
# records them alongside v25-v32.
SCHEMA_STEPS: tuple[tuple[int, str], ...] = (
    (25, "WATCH_AD v25: watch_ads settings columns"),
    (26, "WATCH_AD v26: ad_control_mode / required_ads / completed_ads / last_reward_at"),
    (27, "WATCH_AD v27: global watch-ads admin controls"),
    (28, "PHASE 8: indexed_files source status, FJ link health, index jobs KV"),
    (29, "NETWORK PLATFORM: 10 network tables + 9 setting seeds"),
    (30, "WEBSITE PHASE 2 part A: indexed_files mime_type/width/height/thumb columns"),
    (31, "WEBSITE PHASE 3 (planned v30 part B): website_payloads presentation "
         "table + website_enabled setting seed"),
    (32, "WEBSITE PHASE 4 (Media Gateway): settings-only streaming/cache seeds "
         "(stream+cache toggles, cache size/TTL, stream token TTL, "
         "concurrency cap) — no DDL; the streaming cache is filesystem state"),
    (33, "GAP-CLOSURE: website categories + related columns (schema.py chain)"),
    (34, "TRUSTED FILE DELIVERY: network management metadata + delivery "
         "groups/jobs/audit tables (schema.py chain)"),
    (35, "BOT-11: global_payload_links per-link targeting + network_bots "
         "capability/mini-app state columns (schema.py chain)"),
    (36, "BOT-13: payloads.show_get_file / video_ad_destination + "
         "delivery_jobs.user_message_id + capability TTL seed (schema.py chain)"),
    (37, "BOT-16: network_bots.removed_at removal timestamp; REMOVED "
         "documented as the terminal registry status (removal lifecycle)"),
    (38, "B17: delivery_jobs.delivery_mode / handoff_token / "
         "handoff_sent_at — the direct-delivery audit trail (Mode A/B/C "
         "routing + the single-use deep-link handoff); also covered by "
         "CRITICAL_COLUMNS defense-in-depth in app/storage/database.py"),
    (39, "B18 (bot-19.log): delivery_jobs.mode_a_failure / "
         "mode_a_failure_at — durable truthful metrics distinguishing "
         "Mode-A failure + fallback delivery from a clean network_relay "
         "delivery; force_join_channels.link_provenance — WHO minted the "
         "stored invite link ('bot_created' provably valid until our own "
         "rotate / 'custom' trusted, not introspectable — the Bot API has "
         "NO getChatInviteLink)"),
    (40, "B18-FINAL (bot-22.log): media_view_events + media_reactions + "
         "website_handoffs — website media engagement (per-video views "
         "counted once per viewer per dedupe window after a meaningful "
         "playback threshold; one like/dislike per user per file with "
         "atomic switching) and the single-use replay-protected "
         "external-browser handoff store (Telegram.WebApp.openLink path; "
         "the AEAD handoff token never carries a raw user id)"),
    (41, "V25-FINAL (bot-31.log): indexed_files.prev_channel_id / "
         "prev_message_id / repointed_at — the additive canonical "
         "re-point trail. When a storage message is CONFIRMED deleted "
         "and the SAME file identity arrives in a new message, the "
         "canonical row re-points to the new message and preserves the "
         "previous reference as history (pk / payload refs / upload "
         "date unchanged; dead records can never block re-upload). "
         "Executor: Database._migrate in app/storage/schema.py"),
    (42, "V25-FINAL (bot-35.log): the two-stage DELIVERY CHANNEL "
         "architecture. network_bots.delivery_channel_chat_id — the "
         "per-bot Delivery Channel (Stage A: FDB copies Storage → "
         "Delivery Channel; Stage B: Network Bot copies Delivery Channel "
         "→ User); legacy network_delivery_groups chats are TRANSFERRED "
         "to this column (the old group WAS the intended Delivery "
         "Channel — the group table rows survive as compat data, never "
         "read for routing). delivery_jobs.delivery_channel_id / "
         "delivery_message_id — the durable Stage-A identity for retry, "
         "self-heal and reconciliation. Executor: Database._migrate in "
         "app/storage/schema.py"),
)


async def table_exists(conn: aiosqlite.Connection, table: str) -> bool:
    cur = await conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
        (table,))
    return await cur.fetchone() is not None


async def column_exists(conn: aiosqlite.Connection,
                        table: str, column: str) -> bool:
    cur = await conn.execute(f"PRAGMA table_info({table})")
    rows = await cur.fetchall()
    return any(r[1] == column for r in rows)


async def add_column_if_missing(conn: aiosqlite.Connection, table: str,
                                column: str, definition: str) -> None:
    if not await column_exists(conn, table, column):
        await conn.execute(
            f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
        await conn.commit()
        logger.info("Migration: added column %s.%s", table, column)


async def read_schema_version(conn: aiosqlite.Connection) -> Optional[str]:
    try:
        cur = await conn.execute(
            "SELECT value FROM schema_meta WHERE key='version';")
        row = await cur.fetchone()
        return row["value"] if row else None
    except Exception:  # noqa: BLE001 — not yet stamped
        return None


async def stamp_schema_version(conn: aiosqlite.Connection, version: int) -> None:
    await conn.execute(
        "INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('version', ?)",
        (str(version),))
    await conn.commit()
