"""Application service container (ARCHITECTURE PHASE).

Composes the shared services over the repositories. Two construction modes:

* ``ServiceContainer.bind_legacy(bot_module)`` — the compatibility bridge:
  the container resolves services through the bot.py facade namespace at
  call time (so the regression suites' monkey-patching semantics keep
  working unchanged).
* ``create_container(db, ...)`` — the clean-composition mode future
  entrypoints (web-only deployments, tests) use directly.
"""
from __future__ import annotations

from types import SimpleNamespace
from typing import Any, Callable

from app.core.access.engine import make_access_points_service
from app.core.access.engine import AccessResult  # noqa: F401
from app.core.delivery.service import make_delivery_service
from app.core.force_join.service import make_force_join_service
from app.core.payload.service import make_payload_service
from app.core.referral.service import make_referral_service
from app.core.watch_ads.service import make_watch_ads_service


class ServiceContainer:
    """Explicit, lazy composition of the shared business-logic services."""

    def __init__(self, db: Any) -> None:
        self.db = db

    # -- clean mode ----------------------------------------------------
    def access_points(self) -> SimpleNamespace:
        return make_access_points_service(self.db)

    def watch_ads(self, *, MINI_APP_BASE_URL=None, WATCH_AD_UNLOCK_WINDOW=900,
                  MINI_APP_DEV_ALLOW_HTTP=True) -> SimpleNamespace:
        return make_watch_ads_service(
            self.db, MINI_APP_BASE_URL=MINI_APP_BASE_URL,
            WATCH_AD_UNLOCK_WINDOW=WATCH_AD_UNLOCK_WINDOW,
            MINI_APP_DEV_ALLOW_HTTP=MINI_APP_DEV_ALLOW_HTTP)

    def payload(self, *, BOT_USERNAME="", one_time_default=None) -> SimpleNamespace:
        return make_payload_service(
            self.db, BOT_USERNAME=BOT_USERNAME,
            one_time_default=one_time_default)

    def force_join(self, *, ENABLE_FORCE_JOIN=True, get_join_request_policy=None,
                   _consume_join_request=None, _has_pending_join_request=None,
                   _prune_join_requests=None, PENDING_JOIN_REQUESTS=None
                   ) -> SimpleNamespace:
        return make_force_join_service(
            self.db, ENABLE_FORCE_JOIN=ENABLE_FORCE_JOIN,
            get_join_request_policy=get_join_request_policy,
            _consume_join_request=_consume_join_request,
            _has_pending_join_request=_has_pending_join_request,
            _prune_join_requests=_prune_join_requests,
            PENDING_JOIN_REQUESTS=PENDING_JOIN_REQUESTS)

    def referral(self, **kw: Any) -> SimpleNamespace:
        return make_referral_service(self.db, **kw)

    def delivery(self, **kw: Any) -> SimpleNamespace:
        return make_delivery_service(self.db, **kw)

    # -- legacy bridge ---------------------------------------------------
    @staticmethod
    def bind_legacy(bot_module: Any) -> "LegacyServiceBridge":
        return LegacyServiceBridge(bot_module)


class LegacyServiceBridge:
    """Resolves services through the bot.py compatibility facade namespace
    at CALL time (late binding — monkey-patch friendly)."""

    def __init__(self, bot: Any) -> None:
        self._bot = bot

    def __getattr__(self, name: str) -> Any:
        return getattr(self._bot, name)


def create_container(db: Any) -> ServiceContainer:
    return ServiceContainer(db)


# ---------------------------------------------------------------------------
# ARCHITECTURE DECOUPLING — authoritative application composition
# ---------------------------------------------------------------------------
# The service-construction bodies previously embedded ad hoc in bot.py's
# ``_svc_make_*`` stubs and the Website/Media wiring section now live HERE
# (§4: the container is the composition boundary; §8: the Media Gateway
# construction is an application-level path, no longer a hidden bot.py
# dependency).
#
# Late-binding contract: every factory takes ``ns`` — the legacy bot.py
# namespace — and resolves attributes AT CALL TIME. This preserves the
# regression suites' monkey-patching semantics exactly (patching
# ``B.db``, ``B.access_engine``, ``B._net_registry``,
# ``B._website_gateway_singleton`` ... keeps working unchanged). The
# container never imports bot.py: the namespace is injected by the
# composition (bot.py itself / app/bootstrap.application).
# ---------------------------------------------------------------------------
import os as _os
import time as _time
from types import SimpleNamespace as _NS

from app.web.auth import make_web_auth_service


def legacy_service_factories(ns: Any) -> Any:
    """Service factory closures over the legacy namespace (§4).

    bot.py's ``_svc_make_*`` names delegate to these closures — the
    dependency composition is owned by the container; the legacy layer
    keeps thin compatibility delegators.
    """
    def _payload_service():
        return make_payload_service(
            db=ns.db, BOT_USERNAME=ns.BOT_USERNAME,
            one_time_default=ns.one_time_default)

    def _referral_service():
        return make_referral_service(
            db=ns.db, access_engine=ns.access_engine,
            auto_deliver_unlocked_payload=ns.auto_deliver_unlocked_payload,
            _build_progress_bar_styled=ns._build_progress_bar_styled,
            _maybe_send_appreciation=ns._maybe_send_appreciation,
            safe_send_text=ns.safe_send_text,
            build_start_link=ns.build_start_link,
            _referral_dedup_locks=ns._referral_dedup_locks,
            _referral_dedup_locks_guard=ns._referral_dedup_locks_guard,
            BOT_USERNAME=ns.BOT_USERNAME)

    def _watch_ads_service():
        return make_watch_ads_service(
            db=ns.db, MINI_APP_BASE_URL=ns.MINI_APP_BASE_URL,
            WATCH_AD_UNLOCK_WINDOW=ns.WATCH_AD_UNLOCK_WINDOW,
            MINI_APP_DEV_ALLOW_HTTP=ns.MINI_APP_DEV_ALLOW_HTTP)

    def _access_points_service():
        return make_access_points_service(db=ns.db)

    def _force_join_service():
        # ARCHITECTURE PROPER BREAKDOWN (RULE C): the Telegram error classes
        # + ChatMemberStatus are injected as a PORT — the domain service
        # itself imports no Telegram framework classes. The presentation
        # runtime namespace carries them (imported by state.py).
        telegram_types = _NS(
            Forbidden=ns.Forbidden, BadRequest=ns.BadRequest,
            NetworkError=ns.NetworkError, RetryAfter=ns.RetryAfter,
            TelegramError=ns.TelegramError, TimedOut=ns.TimedOut,
            ChatMemberStatus=ns.ChatMemberStatus)
        return make_force_join_service(
            db=ns.db, ENABLE_FORCE_JOIN=ns.ENABLE_FORCE_JOIN,
            get_join_request_policy=ns.get_join_request_policy,
            _consume_join_request=ns._consume_join_request,
            _has_pending_join_request=ns._has_pending_join_request,
            _prune_join_requests=ns._prune_join_requests,
            PENDING_JOIN_REQUESTS=ns.PENDING_JOIN_REQUESTS,
            telegram_types=telegram_types)

    def _delivery_service():
        return make_delivery_service(
            db=ns.db, safe_send_text=ns.safe_send_text,
            render_retrieve_message=ns.render_retrieve_message,
            _get_owner_id=ns._get_owner_id,
            schedule_auto_delete=ns.schedule_auto_delete,
            resolve_delete_after=ns.resolve_delete_after)

    def _web_auth_service():
        return make_web_auth_service(db=ns.db, BOT_TOKEN=ns.BOT_TOKEN)

    def _keyboards():
        # Late import: the presentation layer is imported only when the
        # keyboards service is actually constructed (RULE G/H — the
        # application layer never imports presentation at module level).
        from app.presentation.telegram.keyboards import make_keyboards
        return make_keyboards(
            db=ns.db, BOT_USERNAME=ns.BOT_USERNAME,
            _force_channel_label=ns._force_channel_label,
            _get_or_create_invite_link=ns._get_or_create_invite_link,
            build_link=ns.build_link)

    def _network_ui():
        # Late import: same RULE G/H discipline as _keyboards above.
        from app.presentation.telegram.network_ui import make_network_ui
        return make_network_ui(
            db=ns.db, BOT_USERNAME=ns.BOT_USERNAME,
            _point_access_active=ns._point_access_active,
            _point_cost=ns._point_cost,
            access_engine=ns.access_engine,
            finalize_delivery=ns.finalize_delivery,
            is_admin=ns.is_admin,
            safe_answer_callback=ns.safe_answer_callback,
            safe_edit_text=ns.safe_edit_text,
            safe_send_text=ns.safe_send_text,
            _net_registry=ns._net_registry,
            _net_points=ns._net_points,
            _net_router=ns._net_router,
            _net_links=ns._net_links,
            _net_broadcast=ns._net_broadcast,
            _net_workers=ns._net_workers)

    def _delivery_ui():
        # FILE DELIVERY v34 (spec §41-§43/§72-§73): Delivery Group wizard +
        # Create Network Bot wizard + the group-detection hook.
        from app.presentation.telegram.delivery_ui import make_delivery_ui
        return make_delivery_ui(
            db=ns.db, is_admin=ns.is_admin,
            safe_answer_callback=ns.safe_answer_callback,
            safe_edit_text=ns.safe_edit_text,
            safe_send_text=ns.safe_send_text,
            _net_registry=ns._net_registry,
            _net_points=ns._net_points,
            _net_workers=ns._net_workers,
            _fdb=getattr(ns, "_fdb", None))

    def _control_ui():
        # FILE DELIVERY v34 (spec §21-§26): the Control Bot panel handlers.
        from app.presentation.telegram.control_ui import make_control_ui
        return make_control_ui(
            db=ns.db, is_admin=ns.is_admin,
            safe_answer_callback=ns.safe_answer_callback,
            safe_edit_text=ns.safe_edit_text,
            safe_send_text=ns.safe_send_text,
            _fdb=getattr(ns, "_fdb", None),
            _net_registry=ns._net_registry,
            _net_workers=ns._net_workers,
            _net_delivery_jobs=getattr(ns, "_net_delivery_jobs", None),
            _net_points=ns._net_points)

    return _NS(
        payload_service=_payload_service,
        referral_service=_referral_service,
        watch_ads_service=_watch_ads_service,
        access_points_service=_access_points_service,
        force_join_service=_force_join_service,
        delivery_service=_delivery_service,
        web_auth_service=_web_auth_service,
        keyboards=_keyboards,
        network_ui=_network_ui,
        delivery_ui=_delivery_ui,
        control_ui=_control_ui,
    )


# --- WEBSITE / MEDIA composition (§8 — the clean application-level path) ---

def website_media_gateway(ns: Any):
    """WEBSITE PHASE 4 → ARCHITECTURE DECOUPLING: the Media Gateway
    singleton construction — now an APPLICATION-LEVEL composition path
    (moved from bot.py's hidden ``_website_media_gateway``).

    Composition (spec §1/§6): the EXISTING Phase 1 media stack
    (resolver → sources → single-retry repair, bound to the PRODUCTION
    recovery transports — fetch_channel_media over the live bot, the
    canonical admin-chat resolver, best-effort temp-message cleanup) +
    the shared bounded StreamCache (identity = file_unique_id; root =
    MEDIA_CACHE_ROOT or <db dir>/media_cache) + app.media.gateway
    (authorization/Range/HEAD/GET planning). The web layer NEVER gets a
    second resolver, a second repair, or a second engine.

    Singleton state lives on the legacy namespace
    (``ns._website_gateway_singleton`` / ``ns._website_gateway_failed``)
    so the regression suites' patching semantics are preserved.
    """
    if getattr(ns, "_website_gateway_singleton", None) is not None:
        return ns._website_gateway_singleton
    if getattr(ns, "_website_gateway_failed", False):
        return None
    try:
        from app.media.config import MediaTransportConfig
        from app.media.stack import create_media_stack
        from app.media.streamcache import StreamCache
        from app.media.gateway import make_media_gateway
        from app.web.site.stream import make_listing_resolver

        cfg = MediaTransportConfig.from_env()

        async def _fetch_source_media(admin_chat_id: int, channel_id: int,
                                      message_id: int):
            # Production recovery transport: the SAME internal fetch the
            # delivery engine uses (copy/forward into an ADMIN chat,
            # immediately deleted — hide_delivery_source can NOT block
            # it because it is never user-visible).
            bot = getattr(ns, "_mini_app_bot", None)
            if bot is None:
                return None, None
            return await ns.fetch_channel_media(
                bot, int(admin_chat_id), int(channel_id), int(message_id))

        async def _delete_message(chat_id: int, message_id: int) -> None:
            bot = getattr(ns, "_mini_app_bot", None)
            if bot is None:
                return
            try:
                await bot.delete_message(int(chat_id), int(message_id))
            except Exception:  # noqa: BLE001 — best-effort cleanup
                pass

        stack = create_media_stack(
            ns.db, ns.BOT_TOKEN, config=cfg,
            fetch_source_media=_fetch_source_media,
            resolve_admin_chat_id=ns._recovery_admin_chat_id,
            delete_message=_delete_message)

        from app.bootstrap.config import EnvDefaults as _EnvDefaults
        cache_root = _EnvDefaults.from_env().media_cache_root or (
            _os.path.join(_os.path.dirname(_os.path.abspath(ns.db.db_path)),
                         "media_cache") if ns.db is not None and getattr(
                             ns.db, "db_path", None) else "media_cache")
        cache = StreamCache(cache_root)

        resolver = make_listing_resolver(ns.db)

        async def _access_check(user_id: int, payload_id):
            # The EXISTING Access Engine — injected, never duplicated —
            # interpreted through the WEBSITE playback authorization
            # chokepoint (B23/P0-1, app/web/site/authz.py): the gateway's
            # per-request re-verification enforces every engine reason
            # EXCEPT "watch_ad_required", which is waived for website
            # playback (the TELEGRAM payload Watch-Ad gate never blocks
            # /site/media — bot-23.log: the waiver at ISSUANCE without
            # the same waiver HERE left the player mounting a stream the
            # gateway then refused with 403). GAP-CLOSURE: the LIVE bot
            # still backs Force-Join membership checks.
            from app.web.site.authz import authorize_website_playback
            bot = getattr(ns, "_mini_app_bot", None)
            verdict = await authorize_website_playback(
                _GatewayDeps(ns), bot, int(user_id),
                payload_id=payload_id)
            return verdict.result if not verdict.authorized \
                else _GatewayOk(verdict.result)

        class _GatewayOk:
            """Authorized verdict wrapper: the gateway reads .authorized
            (+ .reason for the failure log); the underlying engine result
            is preserved for any future consumer."""
            def __init__(self, result):
                self.authorized = True
                self.reason = getattr(result, "reason", "ok")
                self._result = result

        class _GatewayDeps:
            """The deps shape authorize_website_playback expects (it only
            reads .access_engine)."""
            def __init__(self, ns):
                self._ns = ns

            @property
            def access_engine(self):
                async def _engine(bot, uid, payload_id=None, **kw):
                    return await self._ns.access_engine(
                        bot, uid, payload_id=payload_id, **kw)
                return _engine

        gw = make_media_gateway(
            ns.db, stack=stack, listing_resolver=resolver,
            access_check=_access_check, bot_token=ns.BOT_TOKEN, cache=cache)
        ns._website_gateway_singleton = gw
        ns.logger.info(
            "WEBSITE media gateway ready (transport %s, cache root %s)",
            cfg.api_mode, cache_root)
        return gw
    except Exception as e:  # noqa: BLE001 — honest unavailability
        ns.logger.error(
            "WEBSITE media gateway construction failed — streaming will "
            "report unavailable until fixed: %s", e, exc_info=True)
        ns._website_gateway_failed = True
        return None


async def website_network_bot_tokens(ns: Any):
    """WEBSITE PHASE 3 §11: ACTIVE network bot tokens for multi-token
    initData validation (a Mini App launched from a network bot signs its
    initData with THAT bot's token). Reuses the existing credential
    registry/vault; degrades to main-token-only when network services are
    unavailable. Tokens never leave this boundary (never logged).

    Cache state lives on the legacy namespace
    (``ns._website_net_token_cache``) — patching semantics preserved.
    """
    now_ts = _time.time()
    try:
        if now_ts - float(ns._website_net_token_cache.get("ts") or 0.0) \
                < ns._WEBSITE_NET_TOKEN_CACHE_TTL:
            return list(ns._website_net_token_cache.get("tokens") or [])
    except Exception:  # noqa: BLE001
        pass
    tokens = []
    try:
        if getattr(ns, "_net_registry", None) is not None \
                and getattr(ns, "db", None) is not None:
            for nb in await ns.db.list_network_bots():
                if str(nb.get("status", "")).upper() != "ACTIVE":
                    continue
                cred = await ns.db.get_network_bot_credential(int(nb["id"]))
                if not cred:
                    continue
                tok = ns._net_registry.decrypt_credential(
                    cred["encrypted_token"])
                if tok:
                    tokens.append({
                        "token": tok,
                        "bot_id": int(nb.get("telegram_bot_id") or 0),
                    })
    except Exception:  # noqa: BLE001 — degrade to main-token-only
        ns.logger.debug("website network token enumeration unavailable",
                        exc_info=True)
        tokens = []
    ns._website_net_token_cache["ts"] = now_ts
    ns._website_net_token_cache["tokens"] = tokens
    return list(tokens)


def _make_hls_resolver(ns: Any):
    """BOT-16 — the HLS wiring resolver for app/web/site/hls.py.

    Resolves (listing_opaque, file_pk) → {"file_unique_id", "source_path_fn"}
    where source_path_fn materializes a LOCAL file for ffmpeg:

      1. a COMPLETE StreamCache entry → its ``data`` file (zero download);
      2. otherwise a coalesced cache FILL (ONE upstream download per
         identity — the same machinery /site/media uses, never a second
         downloader) → the data file;
      3. cache disabled/failed → a bounded spool download under the
         transcode cache root (reused across jobs by identity digest).

    Never raises (returns None on any resolution failure — the HLS route
    answers honestly). Late-bound to the gateway singleton so tests can
    patch ns._website_media_gateway.
    """
    import asyncio as _asyncio
    import hashlib as _hashlib
    import os as _os

    async def _hls_resolver(listing_opaque: str, file_pk: int):
        gw = getattr(ns, "_website_media_gateway", None)
        # V26.2 (bot-41 root cause): in the REAL runtime namespace
        # ``ns._website_media_gateway`` is the zero-arg FACADE FUNCTION
        # (website_admin._website_media_gateway → the singleton), not the
        # singleton itself. The issuance path (stream.py _gateway) already
        # tolerates BOTH shapes; this resolver used to require the singleton
        # shape and therefore returned None for EVERY file — the exact
        # bot-40/bot-41 production signature (WEBSITE_HLS_SOURCE
        # file_unique_id=- source_available=no → HLS_UNAVAILABLE
        # media_identity_unresolvable) with the DB identity fully intact.
        # Mirror the issuance path's dual-shape discipline here.
        if callable(gw) and not hasattr(gw, "handle_stream_request"):
            try:
                gw = gw()
            except Exception:  # noqa: BLE001 — fail closed, honest None
                ns.logger.debug("website media gateway facade call failed",
                                exc_info=True)
                gw = None
        if gw is None or not hasattr(gw, "handle_stream_request"):
            return None
        rl = getattr(gw, "listing_resolver", None)
        if not callable(rl):
            return None
        try:
            target = await rl(str(listing_opaque or ""), int(file_pk or 0))
        except Exception:  # noqa: BLE001 — honest None, never a crash
            return None
        if not isinstance(target, dict) or not target.get("file_unique_id"):
            return None
        fuid = str(target["file_unique_id"])
        parent_row = target.get("parent_row")
        if parent_row is None:
            # BOT-40: the RAW /site/media path tolerates a missing
            # ``parent_row`` by re-resolving through the SAME indexed-row
            # lookup (gateway._resolve_handle). The HLS resolver now uses
            # the EXACT same discipline — never a second resolution system,
            # just the one asymmetry that made a playable file 404 here.
            _db = getattr(ns, "db", None)
            _lookup = getattr(_db, "get_indexed_file_by_unique_id", None)
            if callable(_lookup):
                try:
                    parent_row = await _lookup(fuid)
                except Exception:  # noqa: BLE001 — honest None
                    parent_row = None
        if parent_row is None:
            return None
        size_hint = target.get("file_size")

        async def source_path_fn() -> str:
            cache = getattr(gw, "cache", None)
            stack = getattr(gw, "stack", None)
            from app.media.streamcache import _safe_subdir

            def _cache_data() -> str:
                return _os.path.join(_safe_subdir(cache.root, fuid), "data")

            # 1) already-complete cache entry
            if cache is not None:
                try:
                    p = await cache.probe(fuid)
                except Exception:  # noqa: BLE001
                    p = None
                if p and p.get("complete"):
                    return _cache_data()
            # 2) coalesced cache fill (the SAME download machinery)
            if cache is not None and stack is not None:
                try:
                    handle = await stack.resolve(parent_row)
                    size = size_hint
                    try:
                        size = await stack.size(handle)
                    except Exception:  # noqa: BLE001 — hint fallback
                        pass

                    def _upstream():
                        return stack.open(handle)

                    async for _chunk in cache.stream(
                            fuid, _upstream, start=0, end=None,
                            size_hint=size):
                        pass  # drain to completion (bounded by cache LRU)
                    try:
                        p = await cache.probe(fuid)
                    except Exception:  # noqa: BLE001
                        p = None
                    if p and p.get("complete"):
                        return _cache_data()
                except Exception:  # noqa: BLE001
                    ns.logger.warning(
                        "WEBSITE_HLS_CACHE_FILL_FAILED file_unique_id=%s",
                        fuid[:16], exc_info=True)
            # 3) spool fallback (cache disabled/failed)
            if stack is not None:
                from app.media.transcode import get_transcode_manager
                mgr = get_transcode_manager()
                spool_dir = _os.path.join(mgr.cache_root, "spool")
                _os.makedirs(spool_dir, exist_ok=True)
                spool_path = _os.path.join(
                    spool_dir,
                    _hashlib.sha256(fuid.encode("utf-8")).hexdigest()
                    + ".bin")
                if _os.path.isfile(spool_path) and (
                        size_hint is None
                        or _os.path.getsize(spool_path) == int(size_hint)):
                    return spool_path
                handle = await stack.resolve(parent_row)
                tmp_path = spool_path + ".part"
                with open(tmp_path, "wb") as fh:
                    async for chunk in stack.open(handle):
                        fh.write(chunk)
                _os.replace(tmp_path, spool_path)
                return spool_path
            raise RuntimeError(
                "no local media source available for transcoding")

        return {"file_unique_id": fuid, "source_path_fn": source_path_fn}

    return _hls_resolver


def website_deps_factory(ns: Any):
    """WEBSITE PHASE 3/4: request-time dependency snapshot for the Website
    presentation layer (app/web/site/pages.py). Late binding to the SAME
    singletons every Telegram flow uses — the Website NEVER gets a second
    engine. PHASE 4 adds the lazy Media Gateway singleton (stack + shared
    cache + gateway — built once per process, see website_media_gateway).
    """
    # NOTE: the original factory captured the bot.py function OBJECTS at
    # call time (late binding through the legacy namespace — patching
    # B._website_media_gateway / B._website_network_bot_tokens keeps
    # working). Preserved exactly: bind ns.* attribute values here.
    # V25 FINAL (two-stage, browser-caught defect): the Website Get-File
    # eligibility MUST use the SAME authoritative v42 delivery-ready
    # predicate the network router uses (lifecycle.py wires
    # ns._net_router.delivery_ready). Before this, the website call sites
    # ran select_random_delivery_bot(deps.db) with NO predicate, whose
    # fail-closed fallback consults the LEGACY network_delivery_groups
    # table (status == DELIVERY_READY) — a FRESH v42 bot (verified
    # Delivery Channel, delivery_channel_chat_id set, no legacy group
    # row) was wrongly ineligible: WEBSITE_GET_FILE_NO_ELIGIBLE_BOT
    # despite a fully configured bot. The legacy group table is compat
    # data and must never gate routing (is_delivery_ready contract).
    from app.network.file_delivery import is_delivery_ready as _is_dr

    async def _website_delivery_ready(bot_row, group_row=None):
        fdb = getattr(ns, "_fdb", None)
        if fdb is None:
            # Network services not initialized (or unavailable) — fail
            # closed: without the Stage-A FDB no delivery can be promised.
            return False
        return await _is_dr(ns.db, fdb, bot_row, group_row=group_row)

    return _NS(
        db=ns.db,
        bot_token=ns.BOT_TOKEN,
        access_engine=ns.access_engine,
        network_tokens=ns._website_network_bot_tokens,
        media_gateway=ns._website_media_gateway,
        delivery_ready=_website_delivery_ready,
        # BOT-11 (spec §6-§18): the production Global Payload Links signer
        # — the SAME ns._net_links singleton the network router mints
        # through (init_network_services, post_init). Late-bound lambda:
        # the deps snapshot may be taken before network services init, and
        # an unconfigured signer (dedicated key missing) honestly refuses
        # minting via LinkSigningUnavailableError — never a fabricated link.
        net_links=lambda: getattr(ns, "_net_links", None),
        # GAP-CLOSURE: the live bot reference for Force-Join membership
        # checks on the website (late-bound — _mini_app_bot is set when
        # the mini-app server starts in post_init). Without it the Access
        # Engine fails CLOSED for every non-admin user (bot=None means
        # "cannot verify membership" → deny), which silently broke
        # website streaming for all FJ-gated payloads.
        bot_ref=lambda: getattr(ns, "_mini_app_bot", None),
        # GAP-CLOSURE spec §24: the website Force-Join gate uses the SAME
        # authoritative batch view as the Telegram side (late-bound).
        # B24 (Phase 5): ``payload_id`` is threaded through so the per-payload
        # HTML pages (handle_site_payload / handle_site_payload_video) can
        # pass the REAL payload_id — the canonical FJ service then records
        # the payload unlock correctly (so reopening an already-unlocked
        # payload takes the fast-path instead of spuriously advancing to
        # the next batch). Top-level non-payload pages pass payload_id=None
        # (symmetric with the Telegram gate-page renderer forcejoin.py:151).
        fj_active=lambda: ns.force_join_active(),
        fj_unjoined=lambda uid, bot, payload_id=None: ns._unjoined_for_access(
            uid, payload_id=payload_id, bot=bot),
        # V26.2 (bot-41 §16-§24): the PER-GATE progressive-batching view —
        # the pinned batch THIS gate presented (website keys:
        # "w|{listing}|{file_pk}" per video, "w|{listing}" for pack-level).
        # Late-bound through the same namespace facades as fj_unjoined.
        fj_gate_unjoined=lambda uid, gate_key, bot, payload_id=None:
            ns.fj_gate_unjoined(uid, str(gate_key),
                                payload_id=payload_id, bot=bot),
        # BOT-16: the HLS transcoding resolver (late-bound through the
        # gateway singleton — see _make_hls_resolver). The /site/hls
        # route honestly 503s (hls_not_wired) when absent.
        hls_resolver=_make_hls_resolver(ns),
        # GAP-CLOSURE spec §46: backend-controlled ad exemption.
        is_admin=ns.is_admin,
    )


def website_admin_deps(ns: Any):
    """WEBSITE PHASE 3/4: admin-side dependency snapshot for the Website
    Control handlers (app/bot/handlers/website.py) — late binding to the
    canonical resolvers/helpers, never module-state duplication. PHASE 4
    adds the Media Gateway (real cache/stream admin controls)."""
    async def _main_app_apply_all(main_bot_client=None):
        # BOT-11 (spec §2-§5): the structured Main Mini App bulk apply for
        # the wsmain admin panel — the SAME production applier
        # (app/network/bot_miniapp.py), ns-late-bound so it works before
        # and after network services initialize. main_bot_client is the
        # LIVE main bot (context.bot) when the panel wants the Main Bot
        # line applied too (spec §4).
        from app.network import bot_miniapp as _bot_miniapp
        return await _bot_miniapp.apply_main_app_link_to_all(
            ns, main_bot_client=main_bot_client)
    return _NS(
        db=ns.db,
        resolve_payload_link=ns._resolve_routing_id,
        is_admin=ns.is_admin,
        log_admin_action=ns.log_admin_action,
        safe_edit_text=ns.safe_edit_text,
        safe_send_text=ns.safe_send_text,
        safe_answer_callback=ns.safe_answer_callback,
        reply_protected=ns.reply_protected,
        media_gateway=ns._website_media_gateway,
        main_app_apply_all=_main_app_apply_all,
    )
