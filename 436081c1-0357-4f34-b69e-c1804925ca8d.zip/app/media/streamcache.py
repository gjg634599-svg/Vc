"""WEBSITE PHASE 4 — the shared bounded STREAMING CACHE.

Design contract (spec §14–§18):

  * CACHE IDENTITY is the canonical media identity — ``file_unique_id``
    (via :mod:`app.media.cachekeys` — hashed into the on-disk path). A
    repaired ``file_id`` NEVER changes the logical entry: the same bytes,
    the same identity, the same cache entry. No duplicate entries from
    Telegram re-issuing file_ids.
  * BOUNDED: configurable cache root, configurable maximum total size,
    configurable TTL. Deterministic eviction (LRU by last access, oldest
    first) runs after fills and on demand.
  * ACTIVE-READER PROTECTION (mandatory): every reader increments a
    refcount; cleanup/eviction NEVER deletes an entry with readers > 0.
    A purged-and-doomed entry is deleted only after its last reader
    finishes.
  * CONCURRENCY / COALESCING: the FIRST reader of uncached media becomes
    the filler — it pulls the upstream stream ONCE, writes through to the
    cache file, and serves its own window from the passing bytes. Every
    later concurrent reader (full GET or overlapping range) reads the
    already-committed prefix from disk and follows the fill progress via a
    per-entry condition — NO duplicate upstream downloads.
  * HONEST FALLBACK: the cache is an optimization, never canonical
    storage. Any cache failure (disk error, stalled fill, fill abort)
    degrades the reader to DIRECT streaming of the remainder through the
    SAME injected upstream factory — canonical Payload/index records are
    never touched by cache failures.
  * MEMORY SAFETY: bounded chunk buffers only; disk reads/writes run in
    worker threads (``asyncio.to_thread``) so the event loop never blocks
    and no whole file is ever held in RAM.

On-disk layout (restart-safe):
    <root>/<sha256(file_unique_id)>/data        — the bytes committed so far
    <root>/<sha256(file_unique_id)>/meta.json   — {size, complete, created_at}
    A partial ``data`` file (crash mid-fill) is recovered as a partial entry
    (available = actual file size) — still perfectly servable as a prefix.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import time
from typing import AsyncIterator, Callable, Dict, Optional, Tuple

from app.media.cachekeys import cache_key

logger = logging.getLogger("payload-bot")

DEFAULT_CACHE_MAX_BYTES = 2 * 1024 * 1024 * 1024  # 2 GiB
DEFAULT_CACHE_TTL_SECONDS = 3600
DEFAULT_CACHE_CHUNK_SIZE = 1024 * 1024
DEFAULT_FOLLOW_IDLE_TIMEOUT = 60.0

UpstreamFactory = Callable[[], AsyncIterator[bytes]]


class CacheEntryState:
    """In-memory state of one cache entry (event-loop confined)."""

    __slots__ = ("key", "dir_path", "data_path", "meta_path", "size",
                 "available", "complete", "readers", "filling",
                 "fill_failed_gen", "doomed", "created_at", "last_access",
                 "cond")

    def __init__(self, key: str, dir_path: str) -> None:
        self.key = key
        self.dir_path = dir_path
        self.data_path = os.path.join(dir_path, "data")
        self.meta_path = os.path.join(dir_path, "meta.json")
        self.size: Optional[int] = None
        self.available = 0          # bytes committed to disk
        self.complete = False
        self.readers = 0            # ACTIVE-READER refcount (never evict >0)
        self.filling = False        # exactly one filler at a time
        self.fill_failed_gen = 0    # bumped on each aborted fill
        self.doomed = False         # purged while readers active
        self.created_at = time.time()
        self.last_access = time.time()
        self.cond: Optional[asyncio.Condition] = None

    def touch(self) -> None:
        self.last_access = time.time()


def _safe_subdir(root: str, file_unique_id: str) -> str:
    """Deterministic, traversal-proof entry directory (hash of identity)."""
    digest = hashlib.sha256(str(file_unique_id).encode("utf-8")).hexdigest()
    return os.path.join(root, digest)


class StreamCache:
    """Bounded shared streaming cache (see module docstring)."""

    def __init__(self, root: str, *,
                 max_bytes: int = DEFAULT_CACHE_MAX_BYTES,
                 ttl_seconds: int = DEFAULT_CACHE_TTL_SECONDS,
                 chunk_size: int = DEFAULT_CACHE_CHUNK_SIZE,
                 follow_idle_timeout: float = DEFAULT_FOLLOW_IDLE_TIMEOUT
                 ) -> None:
        self.root = str(root)
        self.max_bytes = int(max_bytes)
        self.ttl_seconds = int(ttl_seconds)
        self.chunk_size = max(64 * 1024, int(chunk_size))
        self.follow_idle_timeout = float(follow_idle_timeout)
        self._entries: Dict[str, CacheEntryState] = {}
        self._state_lock = asyncio.Lock()
        self._broken = False
        # Observability counters (spec §29).
        self.stats_hits = 0
        self.stats_misses = 0
        self.stats_evictions = 0
        self.stats_fills = 0
        self.stats_fallbacks = 0

    # ------------------------------------------------------------- helpers
    def _ensure_root(self) -> None:
        os.makedirs(self.root, exist_ok=True)

    async def _load_or_create(self, file_unique_id: str,
                              size_hint: Optional[int]
                              ) -> Optional[CacheEntryState]:
        """Find (or restart-safely load) the entry for an identity."""
        if self._broken:
            return None
        key = cache_key(str(file_unique_id))
        async with self._state_lock:
            entry = self._entries.get(key)
            if entry is not None:
                entry.touch()
                return entry
        dir_path = _safe_subdir(self.root, file_unique_id)
        state = CacheEntryState(key, dir_path)
        try:
            def _probe() -> Optional[Tuple[int, Optional[int], bool, float]]:
                os.makedirs(dir_path, exist_ok=True)  # entry dir (bounded
                # count: one hashed dir per identity)
                if not os.path.isfile(state.data_path):
                    return None
                available = os.path.getsize(state.data_path)
                size: Optional[int] = None
                complete = False
                created_at = 0.0
                if os.path.isfile(state.meta_path):
                    try:
                        with open(state.meta_path, "r",
                                  encoding="utf-8") as fh:
                            meta = json.load(fh)
                        size = int(meta.get("size") or 0) or None
                        complete = bool(meta.get("complete"))
                        try:  # PHASE 5: TTL clock honesty across restarts
                            created_at = float(meta.get("created_at") or 0.0)
                        except (TypeError, ValueError):
                            created_at = 0.0
                    except Exception:  # noqa: BLE001 — corrupt meta: partial
                        complete = False
                if complete and size is not None and size != available:
                    complete = False  # honest: meta disagrees with bytes
                if size is not None and available > size:
                    # PHASE 5 corruption reset: the data file is LONGER than
                    # any known upstream size — the Phase 4 abort-restart
                    # append bug ([stale prefix][full copy]) or external
                    # tampering. Cached bytes are UNTRUSTABLE: reset the
                    # entry to empty (the cache is an optimization, never
                    # canonical storage — a re-fill is always safe).
                    logger.warning(
                        "MEDIA_CACHE_CORRUPT_RESET data_bytes=%s "
                        "meta_size=%s (over-long entry discarded — "
                        "refilling from upstream)", available, size)
                    with open(state.data_path, "r+b") as fh:
                        fh.truncate(0)
                    return 0, None, False, 0.0
                if not (0.0 < created_at <= time.time()):
                    created_at = 0.0  # absent/absurd — caller uses now()
                return available, size, complete, created_at
            probed = await asyncio.to_thread(_probe)
        except OSError as e:
            self._mark_broken(e)
            return None
        if probed is not None:
            state.available, state.size, state.complete = probed[0:3]
            if probed[3]:
                # PHASE 5: a persisted entry keeps its ORIGINAL creation
                # time — and its idle clock starts there (conservative: an
                # entry idle since before the restart ages out honestly
                # instead of getting a fresh TTL on every process start).
                state.created_at = probed[3]
                state.last_access = probed[3]
        async with self._state_lock:
            existing = self._entries.get(key)
            if existing is not None:  # raced another reader — use theirs
                existing.touch()
                return existing
            state.cond = asyncio.Condition()
            self._entries[key] = state
            return state

    def _mark_broken(self, err: Exception) -> None:
        """Cache failure safety (spec §18): degrade to passthrough mode."""
        if not self._broken:
            logger.warning(
                "MEDIA_CACHE_ERROR reason=root_unavailable detail=%s "
                "(cache disabled for this process — direct streaming)",
                type(err).__name__)
            self._broken = True

    # ------------------------------------------------------------- reading
    async def _disk_read(self, entry: CacheEntryState, start: int,
                         limit: int) -> AsyncIterator[bytes]:
        """Bounded chunked disk read [start, limit) — seek + read loop."""
        pos = int(start)
        limit = int(limit)
        chunk = self.chunk_size
        f = await asyncio.to_thread(open, entry.data_path, "rb")
        try:
            if pos > 0:
                await asyncio.to_thread(f.seek, pos)
            while pos < limit:
                want = min(chunk, limit - pos)
                data = await asyncio.to_thread(f.read, want)
                if not data:
                    break  # file shorter than expected (honest partial stop)
                pos += len(data)
                yield data
        finally:
            await asyncio.to_thread(f.close)

    async def _disk_append(self, entry: CacheEntryState, data: bytes
                           ) -> None:
        """Append committed bytes + persist progress counters."""
        def _append() -> None:
            with open(entry.data_path, "ab") as fh:
                fh.write(data)
        await asyncio.to_thread(_append)
        entry.available += len(data)

    def _write_meta(self, entry: CacheEntryState) -> None:
        def _wm() -> None:
            tmp = entry.meta_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"size": entry.size, "complete": entry.complete,
                           "created_at": entry.created_at}, fh)
            os.replace(tmp, entry.meta_path)
        try:
            asyncio.get_running_loop().run_in_executor(None, _wm)
        except RuntimeError:  # pragma: no cover — no loop (tests)
            _wm()

    async def _rmtree_entry(self, entry: CacheEntryState) -> None:
        """Disk-only removal of one entry dir (idempotent, best effort).
        PHASE 5: NEVER called while ``_state_lock`` is held — an eviction
        sweep of a large cache can never stall new streams site-wide.

        GAP-CLOSURE (LCK3 de-flake): the fire-and-forget ``_write_meta``
        executor task can land AFTER the rmtree and recreate files inside
        the directory being removed (meta.json[.tmp] left behind → the
        entry dir survives with zero registry entries). Two-step removal:
        delete once, then re-check after a scheduling beat and delete
        again — tolerant of late meta writes, still best-effort."""
        def _rm() -> None:
            try:
                import shutil
                shutil.rmtree(entry.dir_path, ignore_errors=True)
            except Exception:  # noqa: BLE001 — best effort
                pass
        await asyncio.to_thread(_rm)
        # Let any in-flight _write_meta executor task land, then sweep the
        # directory once more (idempotent; ignores a missing dir).
        await asyncio.sleep(0)
        await asyncio.to_thread(_rm)
        self.stats_evictions += 1
        logger.info("MEDIA_CACHE_EVICT key=%s reason=%s", entry.key,
                    "purge" if entry.doomed else "policy")

    async def _delete_entry(self, entry: CacheEntryState) -> None:
        """Remove one entry from disk + memory (callers check readers).
        PHASE 5: the registry pop happens under the state lock (brief,
        synchronous); the directory removal happens OUTSIDE it. Idempotent
        — an entry already removed from the registry still gets its dir
        cleaned (the purged-and-doomed reader-exit path relies on this)."""
        async with self._state_lock:
            if self._entries.get(entry.key) is entry:
                self._entries.pop(entry.key, None)
        await self._rmtree_entry(entry)

    # ------------------------------------------------------------- public
    async def probe(self, file_unique_id: str) -> Dict[str, object]:
        """READ-ONLY lookup (never creates state): is the identity served
        by the cache right now? Used by the Media Gateway to route range
        requests (fully cached / actively filling → cache; else direct)."""
        try:
            key = cache_key(str(file_unique_id))
        except ValueError:
            return {"exists": False, "complete": False, "filling": False,
                    "available": 0}
        async with self._state_lock:
            entry = self._entries.get(key)
            if entry is not None:
                return {"exists": True, "complete": entry.complete,
                        "filling": entry.filling,
                        "available": entry.available}
        if self._broken:
            return {"exists": False, "complete": False, "filling": False,
                    "available": 0}
        dir_path = _safe_subdir(self.root, file_unique_id)

        def _disk_probe() -> Dict[str, object]:
            data_path = os.path.join(dir_path, "data")
            meta_path = os.path.join(dir_path, "meta.json")
            if not os.path.isfile(data_path):
                return {"exists": False, "complete": False, "filling": False,
                        "available": 0}
            available = os.path.getsize(data_path)
            complete = False
            if os.path.isfile(meta_path):
                try:
                    with open(meta_path, "r", encoding="utf-8") as fh:
                        meta = json.load(fh)
                    size = int(meta.get("size") or 0)
                    complete = bool(meta.get("complete")) and \
                        (size == available)
                except Exception:  # noqa: BLE001
                    complete = False
            return {"exists": True, "complete": complete, "filling": False,
                    "available": available}
        try:
            return await asyncio.to_thread(_disk_probe)
        except OSError:
            return {"exists": False, "complete": False, "filling": False,
                    "available": 0}

    def entry_is_cached(self, file_unique_id: str) -> bool:
        """True when the identity already has state (complete or filling)."""
        try:
            return cache_key(str(file_unique_id)) in self._entries
        except ValueError:
            return False

    async def stream(self, file_unique_id: str,
                     upstream_factory: UpstreamFactory, *,
                     start: int = 0, end: Optional[int] = None,
                     size_hint: Optional[int] = None
                     ) -> AsyncIterator[bytes]:
        """Serve [start, end] (inclusive; end=None -> EOF) for one identity.

        Guarantees: at most ONE concurrent upstream fill per identity; later
        readers follow the fill from disk; any failure degrades HONESTLY to
        direct streaming of the remainder via ``upstream_factory``; the
        caller's chunk buffers stay bounded.
        """
        if start < 0:
            raise ValueError("range start must be >= 0")
        if end is not None and end < start:
            raise ValueError("range end must be >= start (inclusive)")
        entry = await self._load_or_create(file_unique_id, size_hint)
        if entry is None:  # cache broken/unavailable -> direct passthrough
            self.stats_fallbacks += 1
            async for chunk in _direct_skip(upstream_factory, start, end,
                                            self.chunk_size):
                yield chunk
            return
        if entry.complete:
            self.stats_hits += 1
        else:
            self.stats_misses += 1
        entry.readers += 1  # ACTIVE-READER protection starts HERE
        try:
            async for chunk in self._serve_entry(entry, upstream_factory,
                                                 start, end):
                yield chunk
        finally:
            entry.readers -= 1
            if entry.doomed and entry.readers <= 0 and not entry.filling:
                await self._delete_entry(entry)

    async def _serve_entry(self, entry: CacheEntryState,
                           upstream_factory: UpstreamFactory,
                           start: int, end: Optional[int]
                           ) -> AsyncIterator[bytes]:
        pos = int(start)
        # Track the fill-failure GENERATION this reader has already seen: a
        # follower only treats a fill as aborted when the generation CHANGES
        # after it started following (never on arrival — a fresh reader has
        # simply not seen any abort yet).
        followed_gen = entry.fill_failed_gen
        while True:
            entry.touch()
            # ---- serve whatever is already committed to disk -------------
            if pos < entry.available:
                limit = entry.available if end is None else \
                    min(entry.available, end + 1)
                if limit > pos:
                    async for chunk in self._disk_read(entry, pos, limit):
                        yield chunk
                    pos = limit
            # ---- termination checks --------------------------------------
            if end is not None and pos > end:
                return  # requested window fully served
            if entry.complete:
                if entry.size is not None and pos >= entry.size:
                    return  # EOF (full GET) — nothing more exists
                if entry.available <= pos:
                    return  # complete but disk is short (honest stop)
                continue
            # ---- need bytes beyond `available` ---------------------------
            if entry.filling:
                # Follow the active fill: wait for progress, completion or
                # a fill failure (bounded idle wait — never an infinite hang).
                async with entry.cond:
                    try:
                        await asyncio.wait_for(
                            entry.cond.wait_for(
                                lambda: (entry.available > pos
                                         or entry.complete
                                         or entry.fill_failed_gen
                                         != followed_gen)),
                            timeout=self.follow_idle_timeout)
                    except asyncio.TimeoutError:
                        logger.warning(
                            "MEDIA_CACHE_FOLLOW_TIMEOUT key=%s "
                            "(fill stalled — falling back to direct stream)",
                            entry.key)
                    gen = entry.fill_failed_gen
                if (entry.available <= pos and not entry.complete
                        and gen != followed_gen):
                    # fill ABORTED without progress -> direct remainder
                    self.stats_fallbacks += 1
                    async for chunk in _direct_skip(upstream_factory, pos,
                                                    end, self.chunk_size):
                        yield chunk
                    return
                followed_gen = gen
                if entry.available <= pos and not entry.complete:
                    # stalled filler + no failure signal yet -> direct too
                    self.stats_fallbacks += 1
                    async for chunk in _direct_skip(upstream_factory, pos,
                                                    end, self.chunk_size):
                        yield chunk
                    return
                continue  # progress/completion — loop serves new bytes
            # ---- become THE filler (single upstream download) ------------
            async with entry.cond:
                if entry.filling or entry.complete:
                    continue  # someone else won the race — follow instead
                entry.filling = True
            self.stats_fills += 1
            logger.info("MEDIA_CACHE_FILL_START key=%s window_start=%s",
                        entry.key, pos)
            # PHASE 5 fill-restart correctness: align the data file with
            # the committed prefix BEFORE any append. A Phase 4 aborted
            # fill + later re-fill could append a full second copy after a
            # stale prefix ([prefix][full new copy]) — unbounded disk growth
            # and WRONG BYTES served after a process restart (probe trusted
            # getsize). Re-fills now RESUME from the committed prefix: the
            # upstream prefix up to resume_base is streamed but discarded
            # (never re-appended, never served twice).
            resume_base = await self._align_disk_prefix(entry)
            fill_pos = 0      # bytes consumed from upstream (disk or not)
            disk_failed = False
            try:
                upstream = upstream_factory()
                try:
                    async for chunk in upstream:
                        fill_pos += len(chunk)
                        chunk_start = fill_pos - len(chunk)
                        wrote = False
                        if not disk_failed and fill_pos > resume_base:
                            # Only bytes BEYOND the committed prefix are
                            # persisted; a straddling chunk is split.
                            persist = (chunk if chunk_start >= resume_base
                                       else chunk[resume_base - chunk_start:])
                            try:
                                await self._disk_append(entry, persist)
                                wrote = True
                                entry.available = fill_pos
                            except OSError as e:
                                # First write failure: stop persisting this
                                # entry (the cache is an optimization, never
                                # canonical storage) — THIS reader keeps
                                # being served from the passing bytes; the
                                # entry is dropped so future requests go
                                # direct. Log ONCE per fill.
                                disk_failed = True
                                logger.warning(
                                    "MEDIA_CACHE_ERROR key=%s "
                                    "reason=write_failed detail=%s "
                                    "(fill continues un-persisted)",
                                    entry.key, type(e).__name__)
                        if end is None:
                            if pos < fill_pos:
                                lo = pos - chunk_start
                                data = chunk[lo:] if lo > 0 else chunk
                                pos = fill_pos
                                yield data
                        else:
                            chunk_end = chunk_start + len(chunk) - 1
                            if chunk_end >= pos and chunk_start <= end:
                                lo = max(0, pos - chunk_start)
                                hi = min(len(chunk) - 1, end - chunk_start)
                                if hi >= lo:
                                    data = chunk[lo:hi + 1]
                                    pos = chunk_start + hi + 1
                                    yield data
                        if wrote and entry.cond is not None:
                            async with entry.cond:
                                entry.cond.notify_all()
                    if disk_failed:
                        # honest degradation: drop the un-persisted entry —
                        # followers + future requests stream directly.
                        # PHASE 5: doomed=True — the last reader's exit
                        # removes the partial dir too (no orphan dirs
                        # invisible to every future sweep).
                        entry.doomed = True
                        async with self._state_lock:
                            self._entries.pop(entry.key, None)
                        if entry.cond is not None:
                            async with entry.cond:
                                entry.cond.notify_all()
                    else:
                        entry.complete = True
                        if entry.size is None:
                            entry.size = entry.available
                        self._write_meta(entry)
                        logger.info(
                            "MEDIA_CACHE_FILL_COMPLETE key=%s size=%s",
                            entry.key, entry.size)
                        # PHASE 5: enforce the advertised cache policy (size
                        # cap + TTL) after every successful fill — the
                        # module's "eviction runs after fills" promise,
                        # previously dead policy in production (cleanup had
                        # no production caller; the cap/TTL were fictional).
                        # Best-effort: a policy failure NEVER fails the fill.
                        try:
                            await self.cleanup()
                        except Exception:  # noqa: BLE001 — best effort
                            pass
                finally:
                    try:
                        await upstream.aclose()
                    except Exception:  # noqa: BLE001 — best effort
                        pass
            except (asyncio.CancelledError, GeneratorExit):
                # Client disconnected mid-fill: keep the partial prefix on
                # disk (still useful — the next reader RESUMES from it),
                # wake followers, DO NOT mark complete.
                # PHASE 5: bump the failure generation so followers see the
                # abort IMMEDIATELY instead of stalling for the full
                # follow_idle_timeout before their direct fallback.
                entry.fill_failed_gen += 1
                raise
            except Exception as e:  # noqa: BLE001 — upstream failed mid-fill
                entry.fill_failed_gen += 1
                if entry.cond is not None:
                    async with entry.cond:
                        entry.cond.notify_all()
                logger.warning(
                    "MEDIA_CACHE_FILL_ABORT key=%s available=%s reason=%s "
                    "(partial prefix kept; readers fall back to direct)",
                    entry.key, entry.available, type(e).__name__)
                # The filler already yielded bytes for THIS reader: serve the
                # remainder directly (one honest retry of the remainder).
                self.stats_fallbacks += 1
                async for chunk in _direct_skip(upstream_factory, pos, end,
                                                self.chunk_size):
                    yield chunk
                return
            finally:
                entry.filling = False
                if entry.cond is not None:
                    async with entry.cond:
                        entry.cond.notify_all()
            if end is None:
                return  # full GET fully streamed
            continue  # range window may still need a re-check loop pass

    # ------------------------------------------------------ maintenance
    async def _align_disk_prefix(self, entry: CacheEntryState) -> int:
        """PHASE 5: enforce the fill-restart invariant — the data file is
        EXACTLY ``entry.available`` bytes before appends begin.

        * file longer than the committed prefix (legacy Phase 4
          abort-restart corruption, or external tampering) -> TRUNCATED to
          the prefix (self-heal; wrong-byte serving becomes impossible);
        * file shorter than the state -> the state shrinks honestly;
        * file missing -> fresh fill from byte 0;
        * OSError -> best-effort passthrough (the fill's own appends will
          fail honestly through the disk_failed path).

        Returns the aligned resume base."""
        def _align():
            try:
                if not os.path.isfile(entry.data_path):
                    return 0
                size = os.path.getsize(entry.data_path)
                if (entry.size is not None and size > int(entry.size)):
                    # PHASE 5 in-process net: over-long vs the KNOWN
                    # upstream size — untrustable bytes, reset to empty.
                    logger.warning(
                        "MEDIA_CACHE_ALIGN key=%s state_available=%s "
                        "disk_size=%s action=reset (disk exceeds known "
                        "upstream size — entry discarded)",
                        entry.key, entry.available, size)
                    with open(entry.data_path, "r+b") as fh:
                        fh.truncate(0)
                    return 0
                if size == entry.available:
                    return entry.available
                if size > entry.available:
                    logger.warning(
                        "MEDIA_CACHE_ALIGN key=%s state_available=%s "
                        "disk_size=%s action=truncate (data-file/state "
                        "mismatch repaired before fill)",
                        entry.key, entry.available, size)
                    with open(entry.data_path, "r+b") as fh:
                        fh.truncate(entry.available)
                    return entry.available
                return size
            except OSError:
                return None
        try:
            out = await asyncio.to_thread(_align)
        except OSError:  # pragma: no cover — to_thread re-raise
            out = None
        if out is None:
            return int(entry.available or 0)
        out = int(out)
        if out != entry.available:
            logger.warning(
                "MEDIA_CACHE_ALIGN key=%s state_available=%s aligned=%s "
                "(short data file — state shrunk honestly)",
                entry.key, entry.available, out)
            entry.available = out
        return out

    async def cleanup(self) -> Dict[str, int]:
        """Deterministic eviction: TTL + size cap, LRU order. NEVER removes
        entries with active readers (mandatory spec §17).

        PHASE 5: victim SELECTION happens under the state lock (brief,
        synchronous — pop + doom); directory removal happens OUTSIDE the
        lock, so a large sweep can never stall new streams site-wide. A
        popped entry cannot gain new readers (fresh state would be created
        instead), and existing readers keep active-reader protection."""
        if self._broken:
            return {"evicted": 0, "skipped_active": 0, "bytes": 0}
        now = time.time()
        evicted = 0
        skipped = 0
        victims: list = []
        async with self._state_lock:
            ordered = sorted(self._entries.values(),
                             key=lambda e: e.last_access)
            total = sum(e.available for e in ordered)
            for entry in ordered:
                if entry.readers > 0:
                    skipped += 1
                    continue  # ACTIVE-READER PROTECTION
                if ((now - entry.last_access) > self.ttl_seconds
                        or total > self.max_bytes):
                    self._entries.pop(entry.key, None)
                    entry.doomed = True
                    victims.append(entry)
                    total -= entry.available
                    evicted += 1
        # PHASE 5: disk removal OUTSIDE the state lock.
        for entry in victims:
            await self._rmtree_entry(entry)
        if evicted:
            logger.info("MEDIA_CACHE_CLEANUP evicted=%s skipped_active=%s",
                        evicted, skipped)
        return {"evicted": evicted, "skipped_active": skipped,
                "bytes": await self.total_bytes()}

    async def purge(self) -> Dict[str, int]:
        """Admin purge: delete every non-active entry; active entries are
        doomed and removed when their last reader finishes (the reader-exit
        ``_delete_entry`` path — idempotent, dir removal guaranteed).
        PHASE 5: same lock discipline as ``cleanup``."""
        removed = 0
        doomed = 0
        victims: list = []
        async with self._state_lock:
            for entry in list(self._entries.values()):
                if entry.readers > 0:
                    entry.doomed = True
                    doomed += 1
                    continue
                self._entries.pop(entry.key, None)
                entry.doomed = True
                victims.append(entry)
                removed += 1
        for entry in victims:
            await self._rmtree_entry(entry)
        logger.info("MEDIA_CACHE_PURGE removed=%s doomed_active=%s",
                    removed, doomed)
        return {"removed": removed, "doomed_active": doomed}

    async def total_bytes(self) -> int:
        async with self._state_lock:
            return sum(e.available for e in self._entries.values())

    def stats(self) -> Dict[str, int]:
        """Safe operational counters (never secrets)."""
        return {
            "entries": len(self._entries),
            "bytes": sum(e.available for e in self._entries.values()),
            "active_readers": sum(e.readers for e in self._entries.values()),
            "hits": self.stats_hits,
            "misses": self.stats_misses,
            "fills": self.stats_fills,
            "evictions": self.stats_evictions,
            "fallbacks": self.stats_fallbacks,
            "broken": 1 if self._broken else 0,
        }

    @property
    def broken(self) -> bool:
        return self._broken


async def _direct_skip(upstream_factory: UpstreamFactory, start: int,
                       end: Optional[int],
                       chunk_size: int) -> AsyncIterator[bytes]:
    """Direct passthrough of [start, end]: stream the upstream from byte 0,
    DISCARD the prefix before ``start`` (bounded memory — the discarded
    bytes are never accumulated), yield the window, stop after ``end``.

    This is the honest cloud-range strategy: no full-file buffering, no
    full-file download (reading STOPS at the window's end), bounded RAM.
    """
    pos = 0
    upstream = upstream_factory()
    try:
        async for chunk in upstream:
            if end is not None and pos > end:
                break  # window served — stop transferring upstream bytes
            chunk_start = pos
            chunk_end = chunk_start + len(chunk) - 1
            pos += len(chunk)
            if chunk_end < start:
                continue  # entirely before the window — discard
            if end is not None and chunk_start > end:
                break
            lo = max(0, start - chunk_start)
            hi = (len(chunk) - 1 if end is None
                  else min(len(chunk) - 1, end - chunk_start))
            if hi >= lo:
                yield chunk[lo:hi + 1]
    finally:
        try:
            await upstream.aclose()
        except Exception:  # noqa: BLE001 — best effort
            pass
