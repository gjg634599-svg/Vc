"""Media transport selection — THE authoritative cloud/local decision
(GAP-CLOSURE spec §10–§16).

One :class:`MediaTransportSelector` owns every cloud/local decision. No
handler, gateway or page may scatter its own transport choice.

Decision graph (spec §10)::

                MEDIA REQUEST
                     |
                     v
            Transport Selector
                     |
            Local configured?
             /              \\
           NO                YES
            |                  |
            v                  v
          CLOUD         Local reachable?
                          /          \\
                        NO            YES
                        |              |
                        v              v
                      CLOUD          LOCAL

Size policy (spec §11) — ONE configuration constant
(``MEDIA_CLOUD_MAX_BYTES``) feeds every size decision:

  SMALL (<= cloud-safe limit)
    → Cloud works; Local preferred when healthy (AUTO)
    → Local configured but down → SAFE fallback to Cloud
  LARGE (> cloud-safe limit)
    → Local healthy → Local
    → Local unavailable → controlled "Local Bot API required" state
    → Cloud is NEVER asked to pretend it can serve a large file

Fallback discipline (spec §16): ONLY transport-class failures fall back
(connection refused, timeout, DNS/network failure, local server
unavailable). Deterministic rejections — invalid media
(:class:`FileIdInvalidError`), authorization failures / malformed
requests (:class:`MediaBadRequestError`), permanent Telegram errors —
NEVER trigger a fallback; they surface honestly.

Local health (spec §14): the :class:`LocalBotApiHealthMonitor` tracks
DISABLED / UNKNOWN / HEALTHY / DEGRADED / UNAVAILABLE with a startup
probe, cached state, retry/backoff, and a recovery probe. Health
transitions need NO application restart: when the local server returns,
the next decision probe flips the state back to HEALTHY and large media
uses Local again.

PURE asyncio/stdlib: no aiohttp, no telegram imports (the probe HTTP
call is injected).
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Optional

from app.media.config import (
    DEFAULT_LOCAL_HEALTHY_TTL_SECONDS,
    DEFAULT_LOCAL_PROBE_TIMEOUT_SECONDS,
    DEFAULT_LOCAL_UNAVAILABLE_BACKOFF_SECONDS,
    MediaTransportConfig,
    MODE_AUTO,
    MODE_CLOUD,
    MODE_LOCAL,
)
from app.media.errors import (
    FileIdInvalidError,
    MediaBadRequestError,
    MediaSourceUnavailableError,
    MediaTooLargeError,
    MediaTransportError,
)

logger = logging.getLogger("payload-bot")

# Health states (spec §14).
LOCAL_DISABLED = "DISABLED"        # no local server configured
LOCAL_UNKNOWN = "UNKNOWN"          # configured, not yet probed
LOCAL_HEALTHY = "HEALTHY"          # probe succeeded
LOCAL_DEGRADED = "DEGRADED"        # reachable, but recent transport errors
LOCAL_UNAVAILABLE = "UNAVAILABLE"  # probe failed / repeated errors

# Transports.
TRANSPORT_CLOUD = "cloud"
TRANSPORT_LOCAL = "local"

# How many consecutive transport failures flip HEALTHY → DEGRADED, and
# DEGRADED → UNAVAILABLE.
_DEGRADED_AFTER_FAILURES = 1
_UNAVAILABLE_AFTER_FAILURES = 3


ProbeFn = Callable[[float], Awaitable[bool]]


@dataclass
class TransportSelection:
    """One authoritative transport decision (spec §10/§11)."""
    transport: str                 # "cloud" | "local"
    reason: str                    # stable machine-readable reason
    local_state: str               # the monitor's state at decision time
    too_large: bool = False        # size exceeds EVERY usable transport
    cloud_fallback_allowed: bool = False  # AUTO small-media safety net

    @property
    def is_local(self) -> bool:
        return self.transport == TRANSPORT_LOCAL


class LocalBotApiHealthMonitor:
    """Local Bot API runtime health (spec §14).

    States: DISABLED (not configured) | UNKNOWN (not yet probed) |
    HEALTHY | DEGRADED | UNAVAILABLE. Cached state + TTL for HEALTHY,
    exponential-ish backoff for UNAVAILABLE (bounded so a recovery probe
    always eventually happens), and a failure/success note API the media
    stack calls as real traffic flows. Never blocks cloud operation: the
    decision path probes with a SHORT timeout and treats probe failure as
    UNAVAILABLE, not as an error.
    """

    def __init__(self, config: MediaTransportConfig, *,
                 probe_fn: Optional[ProbeFn] = None,
                 healthy_ttl: float = DEFAULT_LOCAL_HEALTHY_TTL_SECONDS,
                 unavailable_backoff: float =
                 DEFAULT_LOCAL_UNAVAILABLE_BACKOFF_SECONDS,
                 probe_timeout: float = DEFAULT_LOCAL_PROBE_TIMEOUT_SECONDS,
                 clock: Callable[[], float] = time.monotonic) -> None:
        self._config = config
        self._probe_fn = probe_fn
        self._healthy_ttl = float(healthy_ttl)
        self._unavailable_backoff = float(unavailable_backoff)
        self._probe_timeout = float(probe_timeout)
        self._clock = clock
        self._state: str = (LOCAL_DISABLED if not config.local_configured
                            else LOCAL_UNKNOWN)
        self._state_since: float = self._clock()
        self._last_probe: float = 0.0
        self._last_probe_ok: Optional[bool] = None
        self._consecutive_failures: int = 0
        self._last_failure_kind: str = ""
        self._probe_count: int = 0

    # ---------------------------------------------------------------- state
    @property
    def state(self) -> str:
        return self._state

    @property
    def configured(self) -> bool:
        return self._state != LOCAL_DISABLED

    def describe(self) -> str:
        """Safe admin/summary line (never URLs/tokens)."""
        return (f"local_health={self._state} probes={self._probe_count} "
                f"consecutive_failures={self._consecutive_failures} "
                f"last_failure_kind={self._last_failure_kind or '-'}")

    # ------------------------------------------------------------- probing
    async def probe(self, *, force: bool = False) -> str:
        """Probe now (or return cached state when fresh enough).

        HEALTHY state is trusted for ``healthy_ttl`` seconds; UNAVAILABLE
        state is re-probed at most every ``unavailable_backoff`` seconds
        (the recovery probe — spec §14 scenario "Local returns → health
        recovery", no restart needed). UNKNOWN always probes.
        """
        if self._state == LOCAL_DISABLED:
            return LOCAL_DISABLED
        if self._probe_fn is None:
            # No probe transport injected: treat configured-but-unprobed
            # honestly as UNKNOWN (never fake HEALTHY).
            return self._state

        now = self._clock()
        if not force:
            # HEALTHY is trusted while the last PROBE is fresh (probe
            # freshness window). DEGRADED / UNAVAILABLE are trusted from
            # the moment the state was ENTERED (traffic notes do not count
            # as probes): DEGRADED = a short "avoid Local for small media"
            # window after real transport errors; UNAVAILABLE = the
            # retry/backoff window before the recovery probe re-runs.
            if self._state == LOCAL_HEALTHY and \
                    (now - self._last_probe) < self._healthy_ttl:
                return LOCAL_HEALTHY
            if self._state == LOCAL_DEGRADED and \
                    (now - self._state_since) < self._healthy_ttl:
                return LOCAL_DEGRADED
            if self._state == LOCAL_UNAVAILABLE and \
                    (now - self._state_since) < self._unavailable_backoff:
                return LOCAL_UNAVAILABLE

        self._probe_count += 1
        self._last_probe = now
        try:
            ok = bool(await self._probe_fn(self._probe_timeout))
        except Exception:  # noqa: BLE001 — probe failures are state, not errors
            ok = False
        self._last_probe_ok = ok
        if ok:
            self._apply_transition(LOCAL_HEALTHY)
            self._consecutive_failures = 0
        else:
            self._apply_transition(LOCAL_UNAVAILABLE)
            self._consecutive_failures += 1
        return self._state

    async def current_state(self) -> str:
        """The freshest state the caller may use (probe when stale)."""
        return await self.probe()

    # ------------------------------------------------------- traffic notes
    def note_transport_success(self) -> None:
        """Real traffic flowed through the local server successfully."""
        if self._state in (LOCAL_DEGRADED, LOCAL_UNAVAILABLE, LOCAL_UNKNOWN):
            self._apply_transition(LOCAL_HEALTHY)
        self._consecutive_failures = 0

    def note_transport_failure(self, exc: Optional[BaseException] = None
                               ) -> None:
        """Real traffic through the local server failed (transport-class).

        DEGRADED after the first failure (still reachable — maybe);
        UNAVAILABLE after repeated failures so AUTO stops offering Local
        until the recovery probe succeeds.
        """
        if self._state == LOCAL_DISABLED:
            return
        self._consecutive_failures += 1
        self._last_failure_kind = (getattr(exc, "reason", None)
                                    or type(exc).__name__
                                    if exc is not None else "unknown")
        if self._consecutive_failures >= _UNAVAILABLE_AFTER_FAILURES:
            self._apply_transition(LOCAL_UNAVAILABLE)
        else:
            self._apply_transition(LOCAL_DEGRADED)

    # ------------------------------------------------------------ internal
    def _apply_transition(self, new_state: str) -> None:
        if new_state == self._state:
            self._state_since = self._clock()
            return
        old = self._state
        self._state = new_state
        self._state_since = self._clock()
        logger.info(
            "MEDIA_LOCAL_HEALTH state %s -> %s (%s)", old, new_state,
            self.describe())


class MediaTransportSelector:
    """THE single authoritative cloud/local transport decision (spec §10).

    ``select(size)`` answers one question — "which transport serves this
    request?" — for every caller (gateway, stack, admin status). Handlers
    never re-implement the decision.
    """

    def __init__(self, config: MediaTransportConfig,
                 monitor: LocalBotApiHealthMonitor) -> None:
        self._config = config
        self._monitor = monitor

    @property
    def monitor(self) -> LocalBotApiHealthMonitor:
        return self._monitor

    @property
    def config(self) -> MediaTransportConfig:
        return self._config

    async def select(self, size: Optional[int]) -> TransportSelection:
        """Decide the transport for a media request (spec §10/§11).

        ``size`` may be None (unknown before getFile); the decision then
        only depends on mode + health, and an oversized file surfaced
        later by the cloud source's own honest ``MediaTooLargeError``.
        """
        mode = self._config.api_mode
        limit = int(self._config.cloud_download_limit_bytes)
        oversized = size is not None and size > limit

        # ---- MODE CLOUD: force cloud (spec §13) --------------------------
        if mode == MODE_CLOUD:
            if oversized:
                return TransportSelection(
                    transport=TRANSPORT_CLOUD, reason="cloud_mode_too_large",
                    local_state=LOCAL_DISABLED, too_large=True)
            return TransportSelection(
                transport=TRANSPORT_CLOUD, reason="cloud_mode",
                local_state=LOCAL_DISABLED)

        # ---- MODE LOCAL: require local, fail clearly (spec §13) ----------
        if mode == MODE_LOCAL:
            state = await self._monitor.current_state()
            return TransportSelection(
                transport=TRANSPORT_LOCAL, reason="local_mode",
                local_state=state)

        # ---- MODE AUTO (recommended production mode, spec §13) -----------
        if not self._config.local_configured:
            # The "no Local Bot API today" deployment (spec §12): AUTO
            # without a URL degrades to cloud; small media works normally.
            if oversized:
                return TransportSelection(
                    transport=TRANSPORT_CLOUD,
                    reason="auto_no_local_too_large",
                    local_state=LOCAL_DISABLED, too_large=True)
            return TransportSelection(
                transport=TRANSPORT_CLOUD, reason="auto_no_local",
                local_state=LOCAL_DISABLED)

        state = await self._monitor.current_state()

        if state in (LOCAL_HEALTHY,):
            # Local reachable → LOCAL (both sizes; spec §10 graph).
            return TransportSelection(
                transport=TRANSPORT_LOCAL,
                reason=f"auto_local_{state.lower()}",
                local_state=state,
                cloud_fallback_allowed=not oversized)

        if state == LOCAL_DEGRADED:
            # Reachable-but-flaky: keep large media on Local (cloud cannot
            # serve it anyway); prefer Cloud for small media so a flaky
            # local server never degrades the small-file experience.
            if oversized:
                return TransportSelection(
                    transport=TRANSPORT_LOCAL,
                    reason="auto_degraded_large",
                    local_state=state)
            return TransportSelection(
                transport=TRANSPORT_CLOUD, reason="auto_degraded_small",
                local_state=state)

        # UNKNOWN (probe could not run) or UNAVAILABLE:
        # small → cloud fallback; large → controlled unavailable.
        if oversized:
            return TransportSelection(
                transport=TRANSPORT_CLOUD,
                reason="auto_local_unavailable_too_large",
                local_state=state, too_large=True)
        return TransportSelection(
            transport=TRANSPORT_CLOUD,
            reason=f"auto_local_{state.lower()}_small_fallback",
            local_state=state, cloud_fallback_allowed=True)

    # ---------------------------------------------------------- fallback
    @staticmethod
    def can_fallback_to_cloud(exc: BaseException,
                              selection: TransportSelection) -> bool:
        """Whether a local-transport failure may SAFELY fall back to cloud
        (spec §16).

        SAFE (transport-class): connection refused, timeout, DNS/network
        failure, local server unavailable — ``MediaSourceUnavailableError``.
        NEVER: invalid media (``FileIdInvalidError``), authorization
        failures / malformed requests / permanent Telegram errors
        (``MediaBadRequestError``), or size failures
        (``MediaTooLargeError`` — cloud cannot serve large files, so a
        "fallback" would be a lie).
        """
        if not selection.cloud_fallback_allowed:
            return False
        if isinstance(exc, (FileIdInvalidError, MediaBadRequestError,
                            MediaTooLargeError)):
            return False
        if isinstance(exc, MediaSourceUnavailableError):
            return bool(exc.retryable)
        if isinstance(exc, MediaTransportError):
            return False
        # Non-taxonomy exceptions (e.g. raw network errors from the HTTP
        # client): retryable transport noise — allow the fallback.
        return True

    async def status(self) -> dict:
        """Safe admin/observability summary (no URLs, no tokens)."""
        state = await self._monitor.current_state() \
            if self._config.local_configured else LOCAL_DISABLED
        sel_small = await self.select(1024)
        sel_large = await self.select(self._config.cloud_download_limit_bytes
                                      + 1)
        return {
            "mode": self._config.api_mode,
            "local_configured": self._config.local_configured,
            "local_health": state,
            "monitor": self._monitor.describe(),
            "small_media_transport": sel_small.transport,
            "small_media_reason": sel_small.reason,
            "large_media_transport": sel_large.transport,
            "large_media_too_large": sel_large.too_large,
            "cloud_limit_bytes": int(self._config.cloud_download_limit_bytes),
        }


def default_local_probe_fn(config: MediaTransportConfig,
                           bot_token: str,
                           http: Any) -> ProbeFn:
    """Build the production probe: ``getMe`` against the local server.

    Uses the SAME injected HTTP client the media sources use (token-safe,
    scrubbed errors). Returns True only when the local server answers OK.
    """
    url = config.local_getme_url(bot_token)

    async def _probe(timeout: float) -> bool:
        try:
            status, body = await http.get_json(url)
        except Exception:  # noqa: BLE001 — probe failures are state
            return False
        return bool(status == 200 and isinstance(body, dict)
                    and body.get("ok"))

    return _probe


def make_transport_selector(config: MediaTransportConfig, bot_token: str,
                            *, http: Any = None,
                            probe_fn: Optional[ProbeFn] = None,
                            clock: Callable[[], float] = time.monotonic
                            ) -> MediaTransportSelector:
    """Compose the selector + monitor (the create_media_stack wiring)."""
    if probe_fn is None and http is not None and config.local_configured:
        probe_fn = default_local_probe_fn(config, bot_token, http)
    monitor = LocalBotApiHealthMonitor(config, probe_fn=probe_fn,
                                        clock=clock)
    return MediaTransportSelector(config, monitor)
