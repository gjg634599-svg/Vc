"""Media stack composition (WEBSITE PHASE 1).

``create_media_stack`` composes the media layer over the repositories:

    resolver → sources (local? cloud) → repair → open_with_repair

``open_with_repair`` is THE retry policy of the platform (spec §23):
upstream wrong-file-id → ONE source recovery → atomic DB repair → ONE
retry. Never a second recovery, never a loop; a failure AFTER bytes were
already yielded is never retried (a partially-yielded stream cannot be
transparently restarted — the HTTP layer re-requests a range instead).

The file_id plumbing stays INSIDE the stack: web code holds handles only
(identity + source refs); sources resolve the CURRENT file_id through the
db-backed provider at call time, so a repaired row is picked up by the
very next open/size without any web-side state.

Production wiring (Phase 3/4) binds ``fetch_source_media`` /
``resolve_admin_chat_id`` / ``delete_message`` to the existing delivery
transports (fetch_channel_media / _recovery_admin_chat_id); tests bind
fakes. NOTHING in this module imports bot.py.
"""
from __future__ import annotations

import logging
from types import SimpleNamespace
from typing import Any, AsyncIterator, Callable, Optional

from app.media.config import MediaTransportConfig
from app.media.errors import (
    FileIdInvalidError,
    MediaRecoveryFailedError,
    MediaSourceUnavailableError,
    MediaTooLargeError,
)
from app.media.httpclient import AioHttpMediaClient
from app.media.interfaces import MediaHandle
from app.media.resolver import IndexedFileMediaResolver
from app.media.cachekeys import cache_key, range_key  # noqa: F401 re-export
from app.media.repair import make_media_repair_service
from app.media.sources.local_botapi import LocalBotApiSource
from app.media.sources.telegram_cloud import TelegramCloudSource
from app.media.transport import (
    MediaTransportSelector,
    TRANSPORT_CLOUD,
    TRANSPORT_LOCAL,
    make_transport_selector,
)

logger = logging.getLogger("payload-bot")

HTTPClientFactory = Callable[[], Any]


def _lazy_range(factory):
    """Lazy range generator: the transport selection happens at FIRST
    iteration (async-generator call convention — calling open_range()
    never awaits anything)."""
    async def _gen():
        agen = await factory()
        try:
            async for chunk in agen:
                yield chunk
        finally:
            try:
                await agen.aclose()
            except Exception:  # noqa: BLE001
                pass
    return _gen()


async def _db_file_id_provider(db: Any, file_unique_id: str) -> Optional[str]:
    """file_unique_id → the CURRENT file_id of the canonical row (None when
    the row is gone). Repair-transparent by construction."""
    row = await db.get_indexed_file_by_unique_id(str(file_unique_id))
    if row is None:
        return None
    return row["file_id"] if "file_id" in row.keys() else None


async def open_with_repair(source: Any, handle: MediaHandle,
                           repair: Any = None
                           ) -> AsyncIterator[bytes]:
    """Stream ``handle`` from ``source`` with the single-retry repair policy.

    The FIRST upstream ``FileIdInvalidError`` (it can only occur before any
    byte is yielded — getFile precedes every download) triggers exactly one
    recovery+repair; the stream is then re-opened (the provider now returns
    the fresh file_id). Any subsequent identity failure — or a failure with
    no repair service, or after bytes were yielded — raises
    ``MediaRecoveryFailedError`` (honest, never a loop).
    """
    agen = source.open(handle)
    yielded = False
    retried = False
    try:
        while True:
            try:
                chunk = await agen.__anext__()
            except StopAsyncIteration:
                return
            except FileIdInvalidError as exc:
                if yielded or retried or repair is None:
                    detail = ("bytes already yielded — cannot transparently "
                              "restart a partial stream" if yielded else
                              "already retried once" if retried else
                              "no repair service bound")
                    logger.warning(
                        "MEDIA_UPSTREAM_ERROR origin=media-retry "
                        "reason=recovery_exhausted detail=%s", detail)
                    raise MediaRecoveryFailedError(
                        "file_id invalid and retry not permitted",
                        detail=detail) from exc
                retried = True
                logger.info(
                    "DELIVERY_FILE_ID_INVALID origin=%s file_unique_id=%s "
                    "(stored file_id rejected — recovering from the original "
                    "source message)", "media",
                    handle.file_unique_id)
                info = await repair.repair(handle)
                if not info:
                    raise MediaRecoveryFailedError(
                        "file_id recovery failed",
                        detail="source recovery refused (see "
                               "DELIVERY_SOURCE_RECOVERY log)") from exc
                logger.info(
                    "DELIVERY_FILE_ID_REPAIRED origin=media "
                    "file_unique_id=%s — retrying stream once",
                    handle.file_unique_id)
                agen = source.open(handle)
                continue
            else:
                yielded = True
                yield chunk
    finally:
        # Consumer cancellation / early break: release the inner generator's
        # resources (HTTP response / disk handle). Safe no-op when exhausted.
        try:
            await agen.aclose()
        except Exception:  # noqa: BLE001
            pass


async def open_range_with_repair(source: Any, handle: MediaHandle,
                                 start: int,
                                 end: Optional[int] = None,
                                 repair: Any = None
                                 ) -> AsyncIterator[bytes]:
    """The ranged transport under the SAME single-retry repair policy
    (WEBSITE PHASE 4: the Media Gateway's native-seek path).

    Identical discipline to :func:`open_with_repair`: the FIRST upstream
    ``FileIdInvalidError`` before any byte is yielded triggers exactly one
    recovery+repair and one re-open of the RANGE window; anything after
    bytes were yielded, a second failure, or a missing repair service
    raises ``MediaRecoveryFailedError`` — never a loop. The policy lives
    HERE (the stack owns retry policy); callers never re-implement it.
    """
    agen = source.open_range(handle, start, end)
    yielded = False
    retried = False
    try:
        while True:
            try:
                chunk = await agen.__anext__()
            except StopAsyncIteration:
                return
            except FileIdInvalidError as exc:
                if yielded or retried or repair is None:
                    detail = ("bytes already yielded — cannot transparently "
                              "restart a partial range stream" if yielded
                              else "already retried once" if retried else
                              "no repair service bound")
                    logger.warning(
                        "MEDIA_UPSTREAM_ERROR origin=media-range-retry "
                        "reason=recovery_exhausted detail=%s", detail)
                    raise MediaRecoveryFailedError(
                        "file_id invalid and retry not permitted (range)",
                        detail=detail) from exc
                retried = True
                logger.info(
                    "DELIVERY_FILE_ID_INVALID origin=media-range "
                    "file_unique_id=%s (recovering)", handle.file_unique_id)
                info = await repair.repair(handle)
                if not info:
                    raise MediaRecoveryFailedError(
                        "file_id recovery failed (range)",
                        detail="source recovery refused") from exc
                logger.info(
                    "DELIVERY_FILE_ID_REPAIRED origin=media-range "
                    "file_unique_id=%s — retrying range once",
                    handle.file_unique_id)
                agen = source.open_range(handle, start, end)
                continue
            else:
                yielded = True
                yield chunk
    finally:
        try:
            await agen.aclose()
        except Exception:  # noqa: BLE001
            pass


async def size_with_repair(source: Any, handle: MediaHandle,
                           repair: Any = None) -> Optional[int]:
    """``source.size`` under the same single-retry repair policy."""
    try:
        return await source.size(handle)
    except FileIdInvalidError as exc:
        if repair is None:
            raise MediaRecoveryFailedError(
                "file_id invalid and no repair service bound") from exc
        logger.info(
            "DELIVERY_FILE_ID_INVALID origin=media-size "
            "file_unique_id=%s (recovering)", handle.file_unique_id)
        info = await repair.repair(handle)
        if not info:
            raise MediaRecoveryFailedError(
                "file_id recovery failed during size resolution") from exc
        logger.info(
            "DELIVERY_FILE_ID_REPAIRED origin=media-size "
            "file_unique_id=%s — retrying size once", handle.file_unique_id)
        try:
            return await source.size(handle)
        except FileIdInvalidError as exc2:
            raise MediaRecoveryFailedError(
                "file_id still invalid after one repair (size)") from exc2


def create_media_stack(db: Any, bot_token: str, *,
                       config: Optional[MediaTransportConfig] = None,
                       http_client_factory: Optional[HTTPClientFactory] = None,
                       fetch_source_media=None,
                       resolve_admin_chat_id=None,
                       delete_message=None,
                       selector: Optional[MediaTransportSelector] = None
                       ) -> SimpleNamespace:
    """Compose the media stack.

    PHASE 5 release hardening: ``bot_token`` is positional-or-keyword.
    The keyword-only form introduced in Phase 1 made bot.py's Phase 4
    gateway wiring (``create_media_stack(db, BOT_TOKEN, ...)``) raise
    ``TypeError`` at construction time, so the production Media Gateway
    never built and Website streaming reported unavailable. Relaxing the
    parameter keeps every existing keyword call site valid (all Phase 1–4
    tests and the QA drivers pass ``bot_token=``) while fixing the
    positional production call — verified by the Phase 5 suite, which now
    invokes bot.py's real ``_website_media_gateway`` builder.

    ``http_client_factory`` injects the transport client (tests); the
    default is the token-safe aiohttp client. ``fetch_source_media`` etc.
    bind the recovery transport — when omitted the stack still streams but
    refuses wrong-file-id with ``MediaRecoveryFailedError`` (no repair).
    """
    cfg = config if config is not None else MediaTransportConfig.from_env()
    chunk = cfg.clamped_chunk_size()

    if http_client_factory is not None:
        http = http_client_factory()
    else:
        http = AioHttpMediaClient(timeout_seconds=cfg.http_timeout_seconds,
                                  chunk_size=chunk)

    async def provider(file_unique_id: str) -> Optional[str]:
        return await _db_file_id_provider(db, file_unique_id)

    # GAP-CLOSURE (spec §10): ONE authoritative MediaTransportSelector —
    # every cloud/local decision flows through it. In cloud mode (the
    # legacy default) the selector degrades to "cloud always", so the
    # stack's observable behavior for existing deployments is IDENTICAL.
    local_source: Optional[LocalBotApiSource] = None
    if cfg.local_configured:
        local_source = LocalBotApiSource(cfg, bot_token,
                                          file_id_provider=provider, http=http)
    cloud_source = TelegramCloudSource(cfg, bot_token,
                                        file_id_provider=provider, http=http)
    if selector is None:
        selector = make_transport_selector(cfg, bot_token, http=http)

    sources: list = ([] if local_source is None else [local_source]) + \
        [cloud_source]
    primary = local_source if (
        local_source is not None
        and selector.config.api_mode in ("local",)) else cloud_source

    repair = None
    if fetch_source_media is not None and resolve_admin_chat_id is not None:
        repair = make_media_repair_service(
            db, fetch_source_media=fetch_source_media,
            resolve_admin_chat_id=resolve_admin_chat_id,
            delete_message=delete_message)

    resolver = IndexedFileMediaResolver(db)

    async def _select_source(handle: MediaHandle):
        """The authoritative decision for this handle (spec §10/§11).

        Returns (selection, source). A too-large decision raises the
        honest MediaTooLargeError — cloud is NEVER asked to pretend it
        can serve a large file (spec §11)."""
        from app.media.transport import TransportSelection
        selection: TransportSelection = await selector.select(
            getattr(handle, "size", None))
        if selection.too_large:
            raise MediaTooLargeError(
                f"file exceeds the cloud Bot API limit "
                f"({selector.config.cloud_download_limit_bytes} bytes) and "
                f"no healthy Local Bot API is available",
                limit=int(selector.config.cloud_download_limit_bytes))
        if selection.is_local:
            if local_source is None:  # defensive: never crash, use cloud
                return selection, cloud_source
            return selection, local_source
        return selection, cloud_source

    def _note_outcome(source: Any, exc: Optional[BaseException]) -> None:
        """Feed real traffic outcomes back into the local health monitor
        (spec §14: no restart needed for health transitions)."""
        if local_source is None or source is not local_source:
            return
        if exc is None:
            selector.monitor.note_transport_success()
        else:
            selector.monitor.note_transport_failure(exc)

    async def _open_selected(handle: MediaHandle) -> AsyncIterator[bytes]:
        """open() through the selector with the spec §16 fallback rules.

        The AUTO-mode safety net: when the selected LOCAL transport fails
        with a SAFE transport-class error BEFORE any byte was yielded, and
        the selection allows a cloud fallback (small media), the stream
        transparently re-opens through cloud — exactly once. Deterministic
        rejections (invalid media / bad request / too large) surface
        honestly instead."""
        selection, source = await _select_source(handle)
        agen = open_with_repair(source, handle, repair)
        yielded = False
        fell_back = False
        try:
            while True:
                try:
                    chunk = await agen.__anext__()
                except StopAsyncIteration:
                    _note_outcome(source, None)
                    return
                except Exception as exc:  # noqa: BLE001
                    _note_outcome(source, exc)
                    if (not yielded and not fell_back
                            and source is local_source
                            and selector.can_fallback_to_cloud(exc,
                                                               selection)):
                        fell_back = True
                        logger.warning(
                            "MEDIA_TRANSPORT_FALLBACK file_unique_id=%s "
                            "from=local to=cloud reason=%s (auto safety "
                            "net, small media)",
                            handle.file_unique_id,
                            getattr(exc, "reason", type(exc).__name__))
                        try:
                            await agen.aclose()
                        except Exception:  # noqa: BLE001
                            pass
                        source = cloud_source
                        agen = open_with_repair(cloud_source, handle, repair)
                        continue
                    raise
                else:
                    yielded = True
                    yield chunk
        finally:
            try:
                await agen.aclose()
            except Exception:  # noqa: BLE001
                pass

    async def _open_range_selected(handle: MediaHandle, start: int,
                                   end: Optional[int]
                                   ) -> AsyncIterator[bytes]:
        """open_range under the selector + the §16 fallback rules."""
        selection, source = await _select_source(handle)
        agen = open_range_with_repair(source, handle, start, end, repair)
        yielded = False
        fell_back = False
        try:
            while True:
                try:
                    chunk = await agen.__anext__()
                except StopAsyncIteration:
                    _note_outcome(source, None)
                    return
                except Exception as exc:  # noqa: BLE001
                    _note_outcome(source, exc)
                    if (not yielded and not fell_back
                            and source is local_source
                            and selector.can_fallback_to_cloud(exc,
                                                               selection)):
                        fell_back = True
                        logger.warning(
                            "MEDIA_TRANSPORT_FALLBACK file_unique_id=%s "
                            "from=local to=cloud range=%s-%s reason=%s",
                            handle.file_unique_id, start, end,
                            getattr(exc, "reason", type(exc).__name__))
                        try:
                            await agen.aclose()
                        except Exception:  # noqa: BLE001
                            pass
                        source = cloud_source
                        agen = open_range_with_repair(cloud_source, handle,
                                                      start, end, repair)
                        continue
                    raise
                else:
                    yielded = True
                    yield chunk
        finally:
            try:
                await agen.aclose()
            except Exception:  # noqa: BLE001
                pass

    async def _size_selected(handle: MediaHandle) -> Optional[int]:
        """size() through the selector (+ small-media cloud fallback)."""
        selection, source = await _select_source(handle)
        try:
            result = await size_with_repair(source, handle, repair)
            _note_outcome(source, None)
            return result
        except Exception as exc:  # noqa: BLE001
            _note_outcome(source, exc)
            if (source is local_source
                    and selector.can_fallback_to_cloud(exc, selection)):
                logger.warning(
                    "MEDIA_TRANSPORT_FALLBACK file_unique_id=%s "
                    "from=local to=cloud phase=size reason=%s",
                    handle.file_unique_id,
                    getattr(exc, "reason", type(exc).__name__))
                return await size_with_repair(cloud_source, handle, repair)
            raise

    def open(handle: MediaHandle) -> AsyncIterator[bytes]:
        # Async-generator surface, same call convention as the sources:
        # `async for chunk in stack.open(handle)` — no await needed.
        return _open_selected(handle)

    def open_range(handle: MediaHandle, start: int,
                   end: Optional[int] = None) -> AsyncIterator[bytes]:
        # Ranged transport errors surface immediately (no repair wrapper:
        # getFile identity failures inside open_range still raise
        # FileIdInvalidError for the caller to classify).
        async def _raw_range():
            selection, source = await _select_source(handle)
            return source.open_range(handle, start, end)
        return _lazy_range(_raw_range)

    def open_range_with_retry(handle: MediaHandle, start: int,
                              end: Optional[int] = None
                              ) -> AsyncIterator[bytes]:
        # WEBSITE PHASE 4: the native-seek range path under the platform's
        # single-retry repair policy (used by the Media Gateway) — now
        # selector-aware (spec §10).
        return _open_range_selected(handle, start, end)

    async def size(handle: MediaHandle) -> Optional[int]:
        return await _size_selected(handle)

    async def select_transport(size: Optional[int] = None):
        """Expose the authoritative decision to callers (gateway/admin)."""
        return await selector.select(size)

    async def transport_status() -> dict:
        """Runtime health-aware status (spec §14 observability)."""
        return await selector.status()

    async def close() -> None:
        closer = getattr(http, "close", None)
        if closer is not None:
            await closer()

    async def resolve(payload_file_row) -> MediaHandle:
        return await resolver.resolve(payload_file_row)

    return SimpleNamespace(
        config=cfg,
        bot_token=str(bot_token or ""),
        http=http,
        resolver=resolver,
        resolve=resolve,
        sources=tuple(sources),
        primary_source=primary,
        local_source=local_source,
        cloud_source=cloud_source,
        selector=selector,
        repair=repair,
        open=open,
        open_range=open_range,
        open_range_with_retry=open_range_with_retry,
        size=size,
        select_transport=select_transport,
        transport_status=transport_status,
        close=close,
        cache_key=cache_key,
        range_key=range_key,
        describe=cfg.describe,
    )
