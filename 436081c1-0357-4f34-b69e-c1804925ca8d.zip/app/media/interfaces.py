"""Media abstraction — FOUNDATION ONLY (ARCHITECTURE PHASE).

Defines the contracts the NEXT phase (Payload Web / YouTube-style streaming)
will implement: MediaSource / MediaHandle / MediaResolver. Deliberately NOT
implemented here — no streaming gateway, no HTTP Range, no cache, no
downloads into RAM. The abstraction exists so the next phase can add
TelegramSource / LocalBotApiSource / CacheSource without touching business
logic, and it NEVER exposes Telegram bot tokens to web code.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass
from typing import AsyncIterator, Optional


@dataclass(frozen=True)
class MediaHandle:
    """An open, byte-addressable view of one stored file.

    ``file_unique_id`` is the cross-bot IDENTITY (deduplication only — it is
    never sent through a send API). Delivery-grade ``file_id`` stays scoped
    to the owning bot context and is NOT part of the web contract.
    """
    file_unique_id: str
    source_channel_id: int
    source_message_id: int
    file_name: Optional[str] = None
    mime_type: Optional[str] = None
    size: Optional[int] = None


class MediaSource(abc.ABC):
    """A provider of media bytes (future: TelegramSource, LocalBotApiSource,
    CacheSource, MTProtoSource). Implementations must not leak credentials
    through this interface."""

    @abc.abstractmethod
    async def open(self, handle: MediaHandle) -> AsyncIterator[bytes]:
        """Yield the file's bytes in order. Implementations decide chunking."""

    @abc.abstractmethod
    async def size(self, handle: MediaHandle) -> Optional[int]:
        """Total size in bytes when known (needed for HTTP Range later)."""


class MediaResolver(abc.ABC):
    """Resolves payload file records to MediaHandles without exposing bot
    credentials to callers (web routes will depend on THIS, not on Telegram
    client objects)."""

    @abc.abstractmethod
    async def resolve(self, payload_file_row) -> MediaHandle:
        """Map an indexed_files row to a MediaHandle."""
