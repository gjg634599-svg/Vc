"""WEBSITE PHASE 4 — short-lived STREAM authorization tokens.

The Media Gateway's authorization credential (spec §4/§5). A stream token is
minted ONLY after the full chain succeeded:

    Mini App initData (verified) -> canonical Payload/video resolution ->
    existing Access Engine (authorized) -> stream token

Token binding (ALL mandatory):
  * user        — the HMAC-verified Telegram user id
  * payload     — the listing's opaque id (the canonical Website Payload)
  * media       — the canonical file pk inside that listing's ordered files
  * purpose     — "stream" (media bytes) or "thumb" (thumbnail bytes);
                  a stream token cannot fetch thumbnails and vice versa
  * expiration  — short configurable lifetime (default 300 s), after which
                  every request fails closed

Construction: opaque AEAD through the EXISTING CredentialVault
(app/network/credentials.py — Fernet primary, stdlib HMAC-CTR fallback, key
derived from NETWORK_TOKEN_ENCRYPTION_KEY / the deployment BOT_TOKEN). NO
new cryptography; NO bot tokens, NO Telegram file_id values, NO DB secrets
ever enter the plaintext — only the five binding fields above plus a random
nonce (uniqueness per mint; the AEAD construction already randomizes
ciphertext).

Replay policy (spec §4 "prevent replay outside the intended lifetime/
context"): the token IS reusable within its short lifetime BY DESIGN — a
browser video player issues MANY Range requests against the SAME token
(seeking). Outside the lifetime, the binding user/payload/media/purpose all
fail closed, and every Media Gateway request independently RE-VERIFIES the
Access Engine verdict (app/media/gateway.py) so a revoked user cannot ride
an unexpired token.

Thumb tokens: PUBLIC listing artwork binds user_id=0 / file_pk=0 with
purpose="thumb" — they authorize ONLY the published listing's thumbnail
descriptor (never arbitrary media, never stream purpose). Media STREAM
tokens require a real user id + file pk (enforced by the gateway).

Fail-closed decode: tampered / wrong key / malformed / expired / wrong
version -> None. NEVER raises; NEVER logs token material.
"""
from __future__ import annotations

import os
import time
from types import SimpleNamespace
from typing import Any, Dict, Optional

from app.network.credentials import CredentialVault

# Default stream-token lifetime (seconds). Short by design (spec §5): the
# player requests a fresh token per page view; seeks inside one viewing
# session reuse the token. Configurable via the website_stream_token_ttl
# bot_setting (minutes granularity in the admin panel; seconds here).
STREAM_TOKEN_TTL_DEFAULT = 300  # 5 minutes

PURPOSE_STREAM = "stream"
PURPOSE_THUMB = "thumb"
_VALID_PURPOSES = frozenset({PURPOSE_STREAM, PURPOSE_THUMB})

# Hard clamps: a stream token must never live long (public-ish URL surface).
_TTL_MIN = 30
_TTL_MAX = 3600
# B17 FINAL VERIFICATION FIX — the long-form ceiling: a transcoded movie's
# HLS SEGMENT token legitimately needs hours (the player fetches segments
# throughout playback; stream.py asks for ≥6 h). The Access Engine still
# re-verifies EVERY segment request, so extending the ceiling never
# bypasses revocation — it only stops a >1 h movie 401-ing on late segment
# fetches (the silent clamp bug: the 6 h ask was capped to 3600 s).
STREAM_TOKEN_TTL_LONGFORM_MAX = 6 * 3600


def clamp_stream_ttl(seconds: int, *,
                     max_seconds: Optional[int] = None) -> int:
    """Clamp a configured stream-token TTL into the safe window.

    ``max_seconds`` lets the long-form HLS surface raise the ceiling —
    every request still re-runs the Access Engine, so revocation is
    enforced per request regardless of the TTL.
    """
    try:
        hi = _TTL_MAX if max_seconds is None \
            else max(_TTL_MAX, int(max_seconds))
        n = int(seconds)
    except (TypeError, ValueError):
        return STREAM_TOKEN_TTL_DEFAULT
    return max(_TTL_MIN, min(hi, n))


def make_stream_token_codec(bot_token: Optional[str] = None,
                            *, ttl_seconds: int = STREAM_TOKEN_TTL_DEFAULT):
    """Build the encode/decode pair bound to the deployment's vault key.

    Same vault derivation as the Phase 3 video-ref codec (identical key ->
    identical fail-closed discipline; different plaintext FORMAT so a
    video-ref can never be replayed as a stream token and vice versa).
    """
    ttl = clamp_stream_ttl(ttl_seconds)
    vault = CredentialVault(bot_token_fallback=bot_token,
                                allow_ephemeral_fallback=True)

    def encode_stream_token(user_id: int, listing_opaque_id: str,
                            file_pk: int, *, purpose: str = PURPOSE_STREAM,
                            ttl_override: Optional[int] = None,
                            ttl_max_seconds: Optional[int] = None) -> str:
        """Mint an opaque, authenticated, short-lived stream token."""
        if purpose not in _VALID_PURPOSES:
            raise ValueError(f"invalid stream purpose: {purpose!r}")
        life = clamp_stream_ttl(ttl_override if ttl_override is not None
                                else ttl, max_seconds=ttl_max_seconds)
        expires_at = int(time.time()) + life
        nonce = os.urandom(8).hex()
        plaintext = (f"s1|{int(user_id)}|{str(listing_opaque_id)}"
                     f"|{int(file_pk)}|{str(purpose)}|{expires_at}|{nonce}")
        return vault.encrypt(plaintext)

    def decode_stream_token(token: str) -> Optional[Dict[str, Any]]:
        """Validate + decode. Fails CLOSED (None) on tampering, wrong key,
        malformed input, expiry, or unknown purpose — never raises."""
        try:
            raw = vault.decrypt(str(token or ""))
        except Exception:  # noqa: BLE001 — any failure fails closed
            return None
        parts = raw.split("|")
        if len(parts) != 7 or parts[0] != "s1":
            return None
        try:
            user_id = int(parts[1])
            file_pk = int(parts[3])
            expires_at = int(parts[5])
        except ValueError:
            return None
        if user_id < 0 or file_pk < 0:
            return None
        if parts[4] not in _VALID_PURPOSES:
            return None
        if expires_at < time.time():
            return None
        return {
            "user_id": user_id,
            "listing": parts[2],
            "file_pk": file_pk,
            "purpose": parts[4],
            "expires_at": expires_at,
            "nonce": parts[6],
        }

    return SimpleNamespace(
        encode_stream_token=encode_stream_token,
        decode_stream_token=decode_stream_token,
        ttl_seconds=ttl,
        clamp_stream_ttl=clamp_stream_ttl,
    )
