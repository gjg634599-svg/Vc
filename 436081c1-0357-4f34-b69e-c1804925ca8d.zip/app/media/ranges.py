"""HTTP Range header parsing (WEBSITE PHASE 4 — Media Gateway).

PURE stdlib RFC 7233 ``Range`` parser for single byte ranges — the exact
surface the Media Gateway needs. Multiple ranges are NOT supported (the
gateway deliberately ignores them and serves a full 200 response — the
documented single-range behavior of every major streaming server).

Semantics implemented (spec §7):
  ``bytes=0-1023``     -> (0, 1023)               inclusive window
  ``bytes=1024-``      -> (1024, size-1)          open-ended
  ``bytes=-1024``      -> (size-1024, size-1)     suffix (last 1024 bytes;
                          a suffix longer than the file is the whole file)
  ``bytes=0-0``        -> (0, 0)                  single byte
  end > size-1         -> clamped to size-1       (206, not 416)
  start >= size        -> UNSATISFIABLE           (416)
  ``bytes=-0``         -> UNSATISFIABLE           (RFC: suffix length 0)
  malformed / multi / other units -> None          (ignore -> 200 full)

The function NEVER raises for hostile input — a bad header is data, not an
exception. ``RangeNotSatisfiableError`` is returned as a sentinel because
callers must answer 416 with ``Content-Range: bytes */<size>``.
"""
from __future__ import annotations

import re
from typing import Optional, Tuple

from app.media.errors import RangeNotSatisfiableError

# One optional OWS, "bytes=", then exactly one int-int / int- / -int spec.
_RANGE_RE = re.compile(
    r"^[ \t]*bytes[ \t]*=[ \t]*(?P<spec>[0-9]+-[0-9]*|-[0-9]+)[ \t]*$")

# Sentinel returned for unsatisfiable ranges (start beyond EOF / suffix 0).
UNSATISFIABLE = RangeNotSatisfiableError


def parse_range_header(header: Optional[str], size: Optional[int]
                       ) -> object:
    """Parse a single-range ``Range`` header against a known file size.

    Returns:
      ``(start, end)`` — the inclusive byte window to serve (206);
      ``None``         — malformed / multiple / non-byte ranges: IGNORE the
                         header and answer a normal 200 (spec §25
                         "malformed range" + "multiple Range if unsupported");
      ``UNSATISFIABLE`` (the RangeNotSatisfiableError CLASS, not an
                         instance) — the range lies outside the file: answer
                         416 with ``Content-Range: bytes */<size>``.

    ``size=None`` (unknown size): only fully-bounded numeric ranges can be
    validated structurally; open-ended/suffix ranges are ignored (a 200 full
    response is always safe when the size is unknown). Callers that do not
    know the size should not advertise ``Accept-Ranges`` at all.
    """
    if not header or size is None or int(size) < 0:
        return None
    size = int(size)
    raw = str(header).strip()
    if "," in raw:
        return None  # multiple ranges: unsupported -> ignored (200 full)
    m = _RANGE_RE.match(raw)
    if not m:
        return None  # malformed / non-"bytes" unit -> ignored (200 full)
    spec = m.group("spec")
    if spec.startswith("-"):
        # suffix form: bytes=-N (last N bytes)
        try:
            suffix = int(spec[1:])
        except ValueError:  # pragma: no cover — regex guarantees digits
            return None
        if suffix <= 0:
            return UNSATISFIABLE  # bytes=-0: unsatisfiable per RFC 7233
        if suffix > size:
            suffix = size  # suffix longer than file -> whole file
        return (size - suffix, size - 1)
    first_txt, _, last_txt = spec.partition("-")
    try:
        start = int(first_txt)
    except ValueError:  # pragma: no cover — regex guarantees digits
        return None
    if start >= size:
        return UNSATISFIABLE  # entirely beyond EOF -> 416
    if start < 0:  # pragma: no cover — regex guarantees >= 0
        return None
    if last_txt == "":
        return (start, size - 1)  # open-ended
    try:
        end = int(last_txt)
    except ValueError:  # pragma: no cover — regex guarantees digits
        return None
    if end < start:
        return None  # invalid byte-range-spec (last < first) -> ignore
    if end > size - 1:
        end = size - 1  # clamp to EOF (still satisfiable)
    return (start, end)


def content_range_header(start: int, end: int, size: int) -> str:
    """``Content-Range`` header value for a 206 response."""
    return f"bytes {int(start)}-{int(end)}/{int(size)}"


def unsatisfiable_content_range(size: int) -> str:
    """``Content-Range`` header value for a 416 response."""
    return f"bytes */{int(size)}"


def format_range_request(start: int, end: Optional[int]) -> str:
    """Render a Range header VALUE for upstream requests (local source)."""
    if end is None:
        return f"bytes={int(start)}-"
    return f"bytes={int(start)}-{int(end)}"


__all__ = [
    "parse_range_header", "content_range_header",
    "unsatisfiable_content_range", "format_range_request", "UNSATISFIABLE",
]
