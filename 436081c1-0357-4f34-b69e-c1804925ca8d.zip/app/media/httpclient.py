"""Token-safe HTTP client for media transports (WEBSITE PHASE 1).

Bot tokens travel in the URL PATH (…/bot<token>/getFile). Therefore this
client's error surfaces NEVER include URLs: transport failures raise
``ScrubbedNetworkError`` carrying only a safe caller-supplied ``origin``
label ("cloud-getfile", "local-file", …). Non-200 statuses are RETURNED,
never raised, so callers can classify Bot API bodies themselves.

The default implementation wraps aiohttp lazily (module import stays
aiohttp-free); tests inject fakes with the same two-method surface:
``get_json(url, params) -> (status, body|None)``
``open_stream(url, headers) -> StreamResponse``
"""
from __future__ import annotations

import logging
from typing import Any, AsyncIterator, Dict, Mapping, Optional, Tuple

logger = logging.getLogger("payload-bot")


class ScrubbedNetworkError(Exception):
    """Transport-layer failure (DNS/timeout/connection). Message contains
    ONLY the safe origin label — never the URL (token!)."""

    def __init__(self, origin: str, kind: str) -> None:
        super().__init__(f"{origin}: {kind}")
        self.origin = origin
        self.kind = kind


class StreamResponse:
    """Minimal response surface the sources consume.

    ``status``/``headers`` are plain values; ``chunks()`` is an async
    generator of byte chunks; ``read_error_text()`` reads a bounded error
    body (<= 4 KiB) and closes the response; ``close()`` releases it.
    """

    def __init__(self, status: int, headers: Mapping[str, str],
                 _chunks_fn, _close_fn=None,
                 _error_text_fn=None) -> None:
        self.status = status
        self.headers: Dict[str, str] = dict(headers or {})
        self._chunks_fn = _chunks_fn
        self._close_fn = _close_fn
        self._error_text_fn = _error_text_fn
        self._closed = False

    async def chunks(self) -> AsyncIterator[bytes]:
        try:
            async for chunk in self._chunks_fn():
                yield chunk
        finally:
            await self.close()

    async def read_error_text(self, limit: int = 4096) -> str:
        if self._error_text_fn is not None:
            try:
                text = str(await self._error_text_fn(limit))
                await self.close()
                return text[:limit]
            except Exception:  # noqa: BLE001
                return ""
        await self.close()
        return ""

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._close_fn is not None:
            try:
                await self._close_fn()
            except Exception:  # noqa: BLE001
                pass


class AioHttpMediaClient:
    """Default client over aiohttp (lazy import; one shared session).

    Satisfies the duck-typed media HTTP surface. ``close()`` must be awaited
    when the owning stack shuts down.

    PHASE 5 timeout profiles (large-file streaming correctness):
      * metadata calls (``get_json`` / getFile): bounded TOTAL timeout —
        a metadata exchange must never hang; small responses finish in
        seconds;
      * body streams (``open_stream`` / iter_chunked): ``sock_connect`` +
        ``sock_read`` bounds with ``total=None``. aiohttp's ``total``
        covers the WHOLE transfer including streamed body reads (verified
        empirically against aiohttp 3.13.3), so a former ``total=30``
        killed every transfer longer than 30 s — mid-stream aborts for
        Local Bot API multi-GB files and slow cloud fetches. With
        ``sock_read`` a STALLED connection (no data for the timeout) still
        fails promptly, cancellation propagates from the reader, and a
        healthy slow transfer is never truncated.
    """

    def __init__(self, *, timeout_seconds: int = 30,
                 chunk_size: int = 1024 * 1024) -> None:
        self._timeout_seconds = int(timeout_seconds)
        self._chunk_size = int(chunk_size)
        self._session: Any = None
        self._json_timeout: Any = None
        self._stream_timeout: Any = None

    def _get_session(self):
        if self._session is None:
            import aiohttp  # lazy: keeps module import aiohttp-free
            # Session default = the STREAM profile (long transfers legal);
            # metadata calls override per-request with the bounded profile.
            self._session = aiohttp.ClientSession(
                timeout=self._get_stream_timeout())
        return self._session

    def _get_json_timeout(self):
        if self._json_timeout is None:
            import aiohttp
            self._json_timeout = aiohttp.ClientTimeout(
                total=self._timeout_seconds)
        return self._json_timeout

    def _get_stream_timeout(self):
        if self._stream_timeout is None:
            import aiohttp
            self._stream_timeout = aiohttp.ClientTimeout(
                total=None,
                sock_connect=max(1, self._timeout_seconds),
                sock_read=max(1, self._timeout_seconds))
        return self._stream_timeout

    async def close(self) -> None:
        if self._session is not None:
            try:
                await self._session.close()
            except Exception:  # noqa: BLE001
                pass
            self._session = None

    async def get_json(self, url: str,
                       params: Optional[Mapping[str, str]] = None, *,
                       timeout_seconds: Optional[int] = None
                       ) -> Tuple[int, Optional[Dict[str, Any]]]:
        """JSON GET with the bounded metadata profile.

        B17 — ``timeout_seconds`` overrides the default metadata bound for
        the getFile phase ONLY: a local telegram-bot-api server downloads
        the file from the Telegram DC BEFORE answering getFile, so big
        files need minutes, not the generic 30 s (bot-18.log root cause
        of STREAM_PREFLIGHT_FAIL on the 856 MB / 599 MB videos).
        """
        import aiohttp  # lazy
        session = self._get_session()
        timeout: Any = self._get_json_timeout()
        if timeout_seconds is not None and int(timeout_seconds) >= 1:
            timeout = aiohttp.ClientTimeout(total=int(timeout_seconds))
        try:
            async with session.get(url, params=params,
                                   timeout=timeout) as resp:
                body: Optional[Dict[str, Any]] = None
                try:
                    parsed = await resp.json(content_type=None)
                    if isinstance(parsed, dict):
                        body = parsed
                except Exception:  # noqa: BLE001 — non-JSON body
                    body = None
                return int(resp.status), body
        except Exception as e:  # noqa: BLE001 — scrub URL (contains token)
            raise ScrubbedNetworkError("media-http", type(e).__name__) from e

    async def open_stream(self, url: str, *,
                          headers: Optional[Mapping[str, str]] = None
                          ) -> StreamResponse:
        import aiohttp  # lazy
        session = self._get_session()
        try:
            resp = await session.get(url, headers=headers)
        except Exception as e:  # noqa: BLE001 — scrub URL (contains token)
            raise ScrubbedNetworkError("media-http", type(e).__name__) from e

        async def _chunks():
            async for chunk in resp.content.iter_chunked(self._chunk_size):
                yield chunk

        async def _error_text(limit: int) -> str:
            try:
                raw = await resp.content.read(limit)
                return raw.decode("utf-8", errors="replace")
            except Exception:  # noqa: BLE001
                return ""

        return StreamResponse(
            int(resp.status), resp.headers, _chunks,
            _close_fn=resp.release, _error_text_fn=_error_text)
