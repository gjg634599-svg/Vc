"""MediaResolver implementation (WEBSITE PHASE 1).

Maps an ``indexed_files`` row to the web-facing ``MediaHandle`` contract
from ``app/media/interfaces.py`` — WITHOUT exposing the delivery-grade
file_id (it is bot-scoped and stays behind the sources' injected
file-id provider).

Identity rules enforced here:
  * ``file_unique_id`` is REQUIRED for streaming (it is the cache identity
    and the dedup key). NULL-identity legacy rows are refused honestly.
  * ``source_channel_id`` + ``source_message_id`` are carried as the durable
    recovery reference (indexed_files.channel_id / message_id).
"""
from __future__ import annotations

from typing import Any, Mapping

from app.media.errors import UnresolvableMediaError
from app.media.interfaces import MediaHandle, MediaResolver


def _row_get(row: Any, key: str, default=None):
    """aiosqlite.Row / Mapping safe getter (IndexError-safe on rows)."""
    try:
        if hasattr(row, "keys"):
            if key in row.keys():
                return row[key]
            return default
        return row.get(key, default)
    except Exception:  # noqa: BLE001
        return default


def handle_from_mapping(row: Mapping[str, Any]) -> MediaHandle:
    """Pure synchronous row→handle mapping for plain dicts (listings/tests).

    Same contract as :class:`IndexedFileMediaResolver` — a single shared
    mapping function so the async resolver and any dict-based caller can
    never diverge."""
    if row is None:
        raise UnresolvableMediaError("no media row provided",
                                     reason="missing_row")
    unique_id = _row_get(row, "file_unique_id")
    if not unique_id:
        raise UnresolvableMediaError(
            "indexed file has no file_unique_id (NULL identity rows are "
            "not streamable — re-index the channel to backfill identity)",
            reason="missing_identity")
    channel_id = _row_get(row, "channel_id")
    message_id = _row_get(row, "message_id")
    if channel_id is None or message_id is None:
        raise UnresolvableMediaError(
            "indexed file has no source reference (channel/message)",
            reason="missing_source_ref")
    size = _row_get(row, "file_size")
    return MediaHandle(
        file_unique_id=str(unique_id),
        source_channel_id=int(channel_id),
        source_message_id=int(message_id),
        file_name=_row_get(row, "file_name"),
        mime_type=_row_get(row, "mime_type"),
        size=(int(size) if size is not None else None),
    )


class IndexedFileMediaResolver(MediaResolver):
    """Resolve ``indexed_files`` rows to ``MediaHandle``s.

    ``mime_type`` is read opportunistically: the column arrives with the
    Phase 2 indexer upgrade; older schemas simply yield ``None``.
    """

    def __init__(self, db=None) -> None:
        # db retained for future row reloads; resolution itself is pure.
        self._db = db

    async def resolve(self, payload_file_row) -> MediaHandle:
        return handle_from_mapping(payload_file_row)
