"""Local Bot API media source (WEBSITE PHASE 1).

``LocalBotApiSource`` streams files through a self-hosted Local Bot API
server reachable over a PRIVATE network (WireGuard / firewall — spec §17).
The local server removes the cloud 20 MB download cap, which makes it THE
transport for large-file streaming.

Two read modes, in priority order:
  1. DISK (config.local_file_root set): ``getFile`` returns a server-side
     absolute ``file_path``; when that path (or its root-relative form) is
     inside the configured mount, bytes are read directly from the shared
     filesystem with TRUE SEEKS (open_range is native here).
  2. HTTP: ``{local_api_url}/file/bot<token>/<file_path>`` — works without
     a shared mount; ranges use the HTTP ``Range`` header and REQUIRE a 206
     response (a server/proxy that ignores Range raises
     ``RangeUnsupportedError`` honestly).

Containment rule for disk reads: the resolved real path must stay INSIDE
``local_file_root`` (``realpath``-based check) and be a regular file — a
compromised server response can never make the app read arbitrary files.
Bot tokens live ONLY in URL construction; disk reads never need one.
"""
from __future__ import annotations

import asyncio
import logging
import os
from typing import Any, AsyncIterator, Optional

from app.media.config import MediaTransportConfig
from app.media.errors import (
    RangeNotSatisfiableError,
    RangeUnsupportedError,
    UnresolvableMediaError,
)
from app.media.interfaces import MediaHandle, MediaSource
from app.media.sources._base import (
    FileIdProvider,
    getfile,
    raise_for_stream_status,
    resolve_file_id,
)

logger = logging.getLogger("payload-bot")

ORIGIN = "local"


def _realpath(path: str) -> str:
    return os.path.realpath(os.path.abspath(path))


def _under_root(path: str, root: str) -> bool:
    try:
        return os.path.commonpath([_realpath(path), _realpath(root)]) == \
            _realpath(root)
    except ValueError:  # different drives / mixed separators
        return False


class _DiskChunkReader:
    """Bounded, cancellation-safe chunked disk reader (threaded I/O).

    ``limit`` bounds the total bytes served (range windows); ``start`` is
    the seek offset. One open file handle per stream, closed in ``finally``.
    """

    def __init__(self, path: str, *, chunk_size: int, start: int = 0,
                 limit: Optional[int] = None) -> None:
        self._path = path
        self._chunk_size = int(chunk_size)
        self._start = int(start)
        self._limit = limit

    async def chunks(self) -> AsyncIterator[bytes]:
        f = await asyncio.to_thread(open, self._path, "rb")
        try:
            if self._start > 0:
                await asyncio.to_thread(f.seek, self._start)
            remaining = self._limit
            while True:
                if remaining is not None and remaining <= 0:
                    break
                want = self._chunk_size if remaining is None else \
                    min(self._chunk_size, remaining)
                data = await asyncio.to_thread(f.read, want)
                if not data:
                    break
                if remaining is not None:
                    remaining -= len(data)
                yield data
        finally:
            await asyncio.to_thread(f.close)


class LocalBotApiSource(MediaSource):
    """Local Bot API transport (private network; unbounded file sizes)."""

    def __init__(self, config: MediaTransportConfig, bot_token: str, *,
                 file_id_provider: FileIdProvider,
                 http: Any = None) -> None:
        if not config.local_api_url:
            raise ValueError(
                "LocalBotApiSource requires a configured "
                "TELEGRAM_LOCAL_API_URL (TELEGRAM_API_MODE=local or auto)")
        self._config = config
        self._token = str(bot_token or "")
        self._file_id_provider = file_id_provider
        self._http = http

    # ------------------------------------------------------------------ api
    async def size(self, handle: MediaHandle) -> Optional[int]:
        file_id = await resolve_file_id(self._file_id_provider, handle,
                                         origin=ORIGIN)
        result = await getfile(
            self._http, self._config.local_getfile_url(self._token),
            file_id, origin=ORIGIN,
            timeout_seconds=getattr(self._config,
                                    "getfile_timeout_seconds", None))
        size = result.get("file_size")
        return int(size) if size is not None else None

    async def open(self, handle: MediaHandle) -> AsyncIterator[bytes]:
        file_id = await resolve_file_id(self._file_id_provider, handle,
                                         origin=ORIGIN)
        result = await getfile(
            self._http, self._config.local_getfile_url(self._token),
            file_id, origin=ORIGIN,
            timeout_seconds=getattr(self._config,
                                    "getfile_timeout_seconds", None))
        disk_path = self._resolve_disk_path(result.get("file_path"))
        size = result.get("file_size")
        size = int(size) if size is not None else None
        logger.info("MEDIA_STREAM_START origin=%s file_unique_id=%s "
                    "size=%s mode=%s", ORIGIN, handle.file_unique_id, size,
                    "disk" if disk_path else "http")
        try:
            if disk_path is not None:
                reader = _DiskChunkReader(
                    disk_path, chunk_size=self._config.clamped_chunk_size())
                async for chunk in reader.chunks():
                    yield chunk
            else:
                url = self._config.local_file_url(
                    self._token, str(result.get("file_path") or ""))
                resp = await self._http.open_stream(url)
                try:
                    if resp.status != 200:
                        await raise_for_stream_status(resp, origin=ORIGIN)
                    async for chunk in resp.chunks():
                        yield chunk
                finally:
                    await resp.close()
            logger.info("MEDIA_STREAM_END origin=%s file_unique_id=%s",
                        ORIGIN, handle.file_unique_id)
        finally:
            pass  # readers/responses close themselves (finally inside)

    async def open_range(self, handle: MediaHandle, start: int,
                         end: Optional[int] = None) -> AsyncIterator[bytes]:
        if start < 0:
            raise ValueError("range start must be >= 0")
        if end is not None and end < start:
            raise ValueError("range end must be >= start (inclusive)")
        file_id = await resolve_file_id(self._file_id_provider, handle,
                                         origin=ORIGIN)
        result = await getfile(
            self._http, self._config.local_getfile_url(self._token),
            file_id, origin=ORIGIN,
            timeout_seconds=getattr(self._config,
                                    "getfile_timeout_seconds", None))
        size = result.get("file_size")
        size = int(size) if size is not None else None
        if size is not None and start >= size:
            raise RangeNotSatisfiableError(
                f"range start {start} beyond file size {size}")
        limit = None if end is None else (end - start + 1)

        disk_path = self._resolve_disk_path(result.get("file_path"))
        if disk_path is not None:
            reader = _DiskChunkReader(
                disk_path, chunk_size=self._config.clamped_chunk_size(),
                start=start, limit=limit)
            async for chunk in reader.chunks():
                yield chunk
            return

        url = self._config.local_file_url(
            self._token, str(result.get("file_path") or ""))
        range_header = f"bytes={int(start)}-" + \
            (str(int(end)) if end is not None else "")
        resp = await self._http.open_stream(url, headers={"Range": range_header})
        try:
            if resp.status == 416:
                await resp.read_error_text()
                raise RangeNotSatisfiableError(
                    f"local server rejected range {range_header}")
            if resp.status != 206:
                # Server ignored the Range header (full-body 200). Serving it
                # would mean draining/skipping unbounded bytes — refuse
                # honestly instead (set MEDIA_LOCAL_FILE_ROOT, or front the
                # local server with a Range-capable proxy).
                await resp.read_error_text()
                raise RangeUnsupportedError(
                    "local file endpoint ignored the Range request "
                    f"(status {resp.status}) — shared-filesystem mode "
                    "(MEDIA_LOCAL_FILE_ROOT) provides native seeks")
            logger.info(
                "MEDIA_RANGE_REQUEST origin=%s file_unique_id=%s range=%s",
                ORIGIN, handle.file_unique_id, range_header)
            async for chunk in resp.chunks():
                yield chunk
        finally:
            await resp.close()

    # -------------------------------------------------------------- helpers
    def _resolve_disk_path(self, file_path: Optional[str]) -> Optional[str]:
        """Map a server-side ``file_path`` to a readable local path under
        ``local_file_root`` — with realpath containment. Returns None when
        disk mode is unavailable (falls back to HTTP)."""
        root = self._config.local_file_root
        if not root or not file_path:
            return None
        file_path = str(file_path)
        candidates = []
        if os.path.isabs(file_path):
            candidates.append(file_path)  # same-host / identical layout
        candidates.append(os.path.join(  # root-mounted layout
            root, file_path.lstrip(os.sep)))
        for cand in candidates:
            if not _under_root(cand, root):
                continue
            if not os.path.isfile(cand):
                continue
            return _realpath(cand)
        return None


def disk_containment_check(path: str, root: str) -> bool:
    """Exported for tests: the realpath containment predicate."""
    return _under_root(path, root)
