"""Shared source plumbing (WEBSITE PHASE 1)."""
from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable, Optional

from app.media.errors import (
    FileIdInvalidError,
    MediaBadRequestError,
    MediaNotFoundError,
    MediaSourceUnavailableError,
    MediaTooLargeError,
    UnresolvableMediaError,
    classify_botapi_error,
    is_file_gone_text,
)
from app.media.httpclient import ScrubbedNetworkError

logger = logging.getLogger("payload-bot")

# file_unique_id -> current file_id (the db-backed provider keeps this
# fresh across repairs WITHOUT web code ever seeing a file_id).
FileIdProvider = Callable[[str], Awaitable[Optional[str]]]


async def resolve_file_id(file_id_provider: FileIdProvider,
                          handle, *, origin: str) -> str:
    """Look up the CURRENT bot-scoped file_id for a handle's identity.

    The provider is db-backed (``get_indexed_file_by_unique_id``), so a
    repaired row yields the fresh file_id on the next call automatically.
    """
    file_id = None
    try:
        file_id = await file_id_provider(str(handle.file_unique_id))
    except Exception as e:  # noqa: BLE001 — db unavailable: honest refusal
        raise MediaSourceUnavailableError(
            f"file-id lookup failed for {origin}: {type(e).__name__}",
            retryable=True) from e
    if not file_id:
        raise UnresolvableMediaError(
            f"no indexed file row for identity (media unavailable via "
            f"{origin})", reason="row_missing")
    return str(file_id)


def _safe_desc(desc: str, limit: int = 120) -> str:
    """Sanitized upstream description for logs: bounded length, no URLs
    (Telegram error texts never carry the token -- the token lives in the
    request URL -- but strip anything URL-shaped anyway; secrets stay
    scrubbed by construction)."""
    import re as _re
    s = str(desc or "").replace("\n", " ").replace("\r", " ").strip()
    s = _re.sub(r"https?://\S+", "<url>", s)
    return s[:limit]


async def getfile(http: Any, url: str, file_id: str, *, origin: str,
                  timeout_seconds: Optional[int] = None) -> dict:
    """Call a Bot API getFile endpoint and return the ``result`` object.

    B17 — ``timeout_seconds``: the getFile phase gets its OWN generous
    bound (MEDIA_GETFILE_TIMEOUT, default 600 s): a local telegram-bot-api
    server downloads the file from the Telegram DC BEFORE answering, so
    an ~856 MB file needs minutes — the generic 30 s metadata bound is
    exactly what killed large-file playback in bot-18.log
    (MEDIA_UPSTREAM_ERROR kind=TimeoutError phase=getfile →
    STREAM_PREFLIGHT_FAIL → dead player). Tolerant of injected fakes
    whose ``get_json`` lacks the override kwarg (degrades to default).

    Classifies every failure into the media taxonomy; maps transport errors
    to ``MediaSourceUnavailableError`` (retryable) — NEVER to identity
    failures (the probe discipline of the delivery engine).

    PRODUCTION BUG FIX (small-file "Stream ended or expired", spec §6):
    at the getFile phase the ONLY caller-controlled parameter is the
    file_id. A deterministic 400 that is not a recognized size-cap
    rejection is, in practice, a stale/foreign/expired file_id (Telegram
    has used several wordings across the years — e.g. "wrong file id
    specified", "file identifier is not valid", "PERSISTENT_ID_INVALID"
    — a fixed marker list can never be complete). Such a 400 is therefore
    classified as ``FileIdInvalidError`` (probable_stale=True) so the
    platform's SINGLE-RETRY repair pipeline runs: recover from the
    canonical Storage source, verify file_unique_id, repair atomically,
    retry exactly once. If the repair fails the caller raises the honest
    MediaRecoveryFailedError — never a loop, never a wrong "expired"
    story for the user.
    """
    status: Optional[int] = None
    body: Optional[dict] = None
    try:
        if timeout_seconds is not None:
            try:
                status, body = await http.get_json(
                    url, params={"file_id": file_id},
                    timeout_seconds=int(timeout_seconds))
            except TypeError:
                # Fake client without the override kwarg — default bound.
                status, body = await http.get_json(
                    url, params={"file_id": file_id})
        else:
            status, body = await http.get_json(url, params={"file_id": file_id})
    except ScrubbedNetworkError as e:
        logger.warning("MEDIA_UPSTREAM_ERROR origin=%s kind=%s "
                       "phase=getfile retryable=True", origin, e.kind)
        raise MediaSourceUnavailableError(
            f"{origin} getFile unreachable ({e.kind})", status=0,
            retryable=True) from e
    if not (isinstance(body, dict) and body.get("ok")
            and isinstance(body.get("result"), dict)):
        desc = ""
        if isinstance(body, dict):
            desc = str(body.get("description") or "")
        if not desc:
            desc = f"HTTP {status}" if status is not None else "empty body"
        err = classify_botapi_error(status, desc, origin=origin)
        if isinstance(err, (FileIdInvalidError, MediaTooLargeError)):
            logger.info(
                "MEDIA_UPSTREAM_ERROR origin=%s phase=getfile reason=%s "
                "desc=%s", origin, err.reason, _safe_desc(desc))
        elif isinstance(err, MediaNotFoundError):
            logger.warning(
                "MEDIA_UPSTREAM_ERROR origin=%s phase=getfile reason=%s "
                "status=%s desc=%s", origin, err.reason, status,
                _safe_desc(desc))
        elif isinstance(err, MediaBadRequestError) and status == 400:
            # §6: unrecognized deterministic 400 at the getFile phase ==
            # probable stale/foreign file_id → route through the ONE
            # repair+retry (log keeps the exact wording for diagnosis).
            logger.warning(
                "MEDIA_UPSTREAM_ERROR origin=%s phase=getfile "
                "reason=bad_request_desc=%s probable_file_id_stale=True "
                "status=%s (routing through single-retry repair)",
                origin, _safe_desc(desc), status)
            stale = FileIdInvalidError(
                f"file_id rejected by {origin}: {_safe_desc(desc)} "
                f"(probable stale/foreign file_id)", origin=origin)
            stale.probable = True
            raise stale
        else:
            logger.warning(
                "MEDIA_UPSTREAM_ERROR origin=%s phase=getfile reason=%s "
                "status=%s desc=%s", origin, err.reason, status,
                _safe_desc(desc))
        raise err
    return body["result"]


async def raise_for_stream_status(resp: Any, *, origin: str) -> None:
    """Classify a non-200 stream response from a Bot API file endpoint."""
    text = await resp.read_error_text()
    desc = ""
    # Local server errors are JSON bodies; strip to the description field.
    if text:
        import json as _json
        try:
            parsed = _json.loads(text)
            if isinstance(parsed, dict):
                desc = str(parsed.get("description") or "")
        except Exception:  # noqa: BLE001
            desc = ""
    if not desc:
        desc = f"HTTP {resp.status}"
    err = classify_botapi_error(resp.status, desc, origin=origin)
    logger.warning("MEDIA_UPSTREAM_ERROR origin=%s phase=download "
                   "reason=%s status=%s", origin, err.reason, resp.status)
    raise err
