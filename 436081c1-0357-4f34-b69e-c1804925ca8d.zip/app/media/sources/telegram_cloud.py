"""Cloud Bot API media source (WEBSITE PHASE 1).

``TelegramCloudSource`` streams files through the PUBLIC cloud Bot API
(``getFile`` + the file download endpoint). The cloud endpoint is hard-capped
(~20 MB per file) — larger files raise ``MediaTooLargeError`` with honest
guidance to configure a Local Bot API server (TELEGRAM_API_MODE=local).

Identity/transport rules:
  * file_ids are resolved at CALL time through the injected db-backed
    provider (file_unique_id → current file_id) — repairs become visible on
    the next open/size without any web-side state.
  * Bot tokens exist ONLY inside this module's URL construction. Errors are
    scrubbed (safe origin labels); handles never carry tokens or file_ids.
  * Ranges are NOT supported on the cloud file endpoint — honest
    ``RangeUnsupportedError`` (the local source is the ranged transport).
"""
from __future__ import annotations

import logging
from typing import Any, AsyncIterator, Optional

from app.media.config import MediaTransportConfig
from app.media.errors import (
    MediaTooLargeError,
    RangeUnsupportedError,
)
from app.media.interfaces import MediaHandle, MediaSource
from app.media.sources._base import (
    FileIdProvider,
    getfile,
    raise_for_stream_status,
    resolve_file_id,
)

logger = logging.getLogger("payload-bot")

ORIGIN = "cloud"


class TelegramCloudSource(MediaSource):
    """Cloud Bot API transport (bounded to the documented download cap)."""

    def __init__(self, config: MediaTransportConfig, bot_token: str, *,
                 file_id_provider: FileIdProvider,
                 http: Any = None) -> None:
        self._config = config
        self._token = str(bot_token or "")
        self._file_id_provider = file_id_provider
        self._http = http

    # ------------------------------------------------------------------ api
    async def size(self, handle: MediaHandle) -> Optional[int]:
        file_id = await resolve_file_id(self._file_id_provider, handle,
                                         origin=ORIGIN)
        if handle.size is not None and handle.size > \
                self._config.cloud_download_limit_bytes:
            raise self._too_large(handle.size)
        result = await self._getfile(handle, file_id)
        return self._checked_size(result, file_id)

    async def open(self, handle: MediaHandle) -> AsyncIterator[bytes]:
        file_id = await resolve_file_id(self._file_id_provider, handle,
                                         origin=ORIGIN)
        if handle.size is not None and handle.size > \
                self._config.cloud_download_limit_bytes:
            raise self._too_large(handle.size)
        result = await self._getfile(handle, file_id)
        size = self._checked_size(result, file_id)
        file_path = result.get("file_path")
        if not file_path:
            raise self._too_large(size if size is not None else
                                  self._config.cloud_download_limit_bytes)
        url = self._config.cloud_file_url(self._token, str(file_path))
        resp = await self._http.open_stream(url)
        try:
            if resp.status != 200:
                await raise_for_stream_status(resp, origin=ORIGIN)
            logger.info(
                "MEDIA_STREAM_START origin=%s file_unique_id=%s size=%s",
                ORIGIN, handle.file_unique_id, size)
            async for chunk in resp.chunks():
                yield chunk
            logger.info("MEDIA_STREAM_END origin=%s file_unique_id=%s",
                        ORIGIN, handle.file_unique_id)
        finally:
            await resp.close()

    async def open_range(self, handle: MediaHandle, start: int,
                         end: Optional[int] = None) -> AsyncIterator[bytes]:
        raise RangeUnsupportedError(
            "the cloud Bot API file endpoint is not a ranged transport — "
            "configure TELEGRAM_API_MODE=local (Local Bot API) for "
            "seekable large-file streaming")
        yield b""  # pragma: no cover — makes this an async generator

    # -------------------------------------------------------------- helpers
    async def _getfile(self, handle: MediaHandle, file_id: str) -> dict:
        """getFile with too-large enrichment: the upstream 'file is too big'
        rejection is re-raised with the Local Bot API guidance (the operator
        must know the remedy, not just the cap)."""
        try:
            return await getfile(
                self._http, self._config.cloud_getfile_url(self._token),
                file_id, origin=ORIGIN,
                timeout_seconds=getattr(self._config,
                                    "getfile_timeout_seconds", None))
        except MediaTooLargeError as e:
            raise self._too_large(handle.size, detail=str(e)) from e

    def _checked_size(self, result: dict, file_id: str) -> Optional[int]:
        size = result.get("file_size")
        size = int(size) if size is not None else None
        if size is not None and size > self._config.cloud_download_limit_bytes:
            raise self._too_large(size)
        return size

    def _too_large(self, size: Optional[int],
                   detail: Optional[str] = None) -> MediaTooLargeError:
        msg = (f"file ({size or '?'} bytes) exceeds the cloud Bot API "
               f"download limit ({self._config.cloud_download_limit_bytes} "
               "bytes) — enable a Local Bot API server "
               "(TELEGRAM_API_MODE=local) for large-file streaming")
        if detail:
            msg = f"{detail} — {msg}"
        return MediaTooLargeError(
            msg, limit=self._config.cloud_download_limit_bytes)
