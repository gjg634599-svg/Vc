"""MIME resolution with the spec §17 priority order (GAP-CLOSURE).

THE bug being fixed: a video sent as a Telegram *document* arrives with
``mime_type=application/octet-stream``. The old logic trusted the MIME
string alone, so a KNOWN video (``media_type=video``) was branded
"Not streamable" merely because Telegram reported a generic container
type.

Priority order (spec §17):
    1. ``media_type``      — the Telegram structural type (video,
                             animation, audio, photo, document…). A known
                             video is a video, whatever the container
                             claims.
    2. Telegram metadata   — the indexed ``mime_type`` WHEN it is a real,
                             specific media type (video/*, audio/*,
                             image/*). Generic containers
                             (application/octet-stream, application/binary)
                             are NOT trusted to describe the media.
    3. MIME                — any other specific MIME (e.g. application/pdf)
                             passes through honestly.
    4. extension           — the file name extension disambiguates the
                             container when the MIME is generic.

PURE module: no aiohttp, no telegram, no DB imports.
"""
from __future__ import annotations

from typing import Optional

# Generic "unknown container" MIME values that must never describe media.
_GENERIC_MIMES = {
    "application/octet-stream",
    "application/binary",
    "application/x-binary",
    "binary/octet-stream",
    "",
}

# media_type → default content type when nothing more specific is known.
_MEDIA_TYPE_DEFAULTS = {
    "video": "video/mp4",
    "animation": "video/mp4",
    "audio": "audio/mpeg",
    "photo": "image/jpeg",
    "image": "image/jpeg",
    "sticker": "image/webp",
    "voice": "audio/ogg",
    "video_note": "video/mp4",
}

# media_type values that are inherently playable by the web player.
_PLAYABLE_MEDIA_TYPES = frozenset({
    "video", "animation", "video_note", "audio", "voice", "photo", "image",
})

# Extension → content type (the priority-4 disambiguation).
_EXTENSION_CONTENT_TYPES = {
    ".mp4": "video/mp4",
    ".m4v": "video/mp4",
    ".mov": "video/quicktime",
    ".mkv": "video/x-matroska",
    ".webm": "video/webm",
    ".avi": "video/x-msvideo",
    ".flv": "video/x-flv",
    ".3gp": "video/3gpp",
    ".ts": "video/mp2t",
    ".mpg": "video/mpeg",
    ".mpeg": "video/mpeg",
    ".wmv": "video/x-ms-wmv",
    ".mp3": "audio/mpeg",
    ".m4a": "audio/mp4",
    ".aac": "audio/aac",
    ".ogg": "audio/ogg",
    ".opus": "audio/ogg",
    ".oga": "audio/ogg",
    ".flac": "audio/flac",
    ".wav": "audio/wav",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
    ".gif": "image/gif",
    ".bmp": "image/bmp",
    ".avif": "image/avif",
    ".pdf": "application/pdf",
    ".txt": "text/plain",
}


def _normalize_mime(mime: Optional[str]) -> str:
    return str(mime or "").strip().lower()


def _is_specific_media_mime(mime: str) -> bool:
    """A MIME that actually describes playable media (priority 2)."""
    return mime.startswith(("video/", "audio/", "image/"))


def _extension_of(file_name: Optional[str]) -> str:
    name = str(file_name or "").strip().lower()
    if not name or "." not in name:
        return ""
    return "." + name.rsplit(".", 1)[1].rsplit("?", 1)[0]


def effective_content_type(media_type: Optional[str],
                           mime_type: Optional[str],
                           file_name: Optional[str] = None) -> str:
    """The content type the HTTP layer must serve, per the §17 priority.

    A KNOWN video (``media_type=video``) with a generic MIME is served as
    ``video/mp4`` (or its extension-derived container) — never
    ``application/octet-stream`` — so browsers treat it as playable.
    """
    mtype = str(media_type or "").strip().lower()
    mime = _normalize_mime(mime_type)
    ext = _extension_of(file_name)

    # Priority 2/3: a SPECIFIC MIME wins — but only when it is not a
    # generic container claim.
    if mime and mime not in _GENERIC_MIMES and "/" in mime:
        return mime

    # Priority 4 (while the MIME is generic): the extension disambiguates.
    if ext:
        ext_type = _EXTENSION_CONTENT_TYPES.get(ext)
        if ext_type is not None:
            # If the media_type ALSO implies a default, prefer the type
            # family they agree on; otherwise the extension is the more
            # specific signal for generic-MIME documents.
            default = _MEDIA_TYPE_DEFAULTS.get(mtype)
            if default is None or default.split("/")[0] == ext_type.split("/")[0]:
                return ext_type
            # Disagreement (e.g. media_type=photo but extension .mp4):
            # the structural type wins (priority 1).
            return default

    # Priority 1: the structural Telegram media type.
    if mtype in _MEDIA_TYPE_DEFAULTS:
        return _MEDIA_TYPE_DEFAULTS[mtype]

    # Honest fallback for genuinely unknown binaries (documents with no
    # recognizable extension — never a fake video/mp4 claim).
    return "application/octet-stream"


def is_streamable_media(media_type: Optional[str],
                        mime_type: Optional[str],
                        file_name: Optional[str] = None) -> bool:
    """Whether the web player can play this media (spec §17: a known video
    MUST NOT become "Not streamable" merely because the MIME is generic).

    Priority 1: the structural ``media_type`` (video/animation/audio/
    photo/image/…) decides playability — a generic
    ``application/octet-stream`` MIME cannot veto it.
    Priority 2/3: otherwise a specific video/*, audio/* or image/* MIME
    (including generic-MIME documents whose MIME says video) grants it.
    Priority 4: a recognizable playable extension (``film.mp4`` sent as a
    generic document) grants it — the file IS served with that content
    type, so the browser can play it.
    """
    mtype = str(media_type or "").strip().lower()
    mime = _normalize_mime(mime_type)

    # Priority 1 — the structural type is authoritative.
    if mtype in _PLAYABLE_MEDIA_TYPES:
        return True

    # Priority 2/3 — a specific playable MIME (works for documents whose
    # Telegram metadata reports e.g. video/mp4).
    if _is_specific_media_mime(mime):
        return True

    # Priority 4 — the extension identifies a playable container.
    ext = _extension_of(file_name)
    if ext:
        ext_type = _EXTENSION_CONTENT_TYPES.get(ext)
        if ext_type is not None and _is_specific_media_mime(ext_type):
            return True

    return False
