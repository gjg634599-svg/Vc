"""Media abstraction package.

ARCHITECTURE PHASE: ``interfaces.py`` defines the contracts.
WEBSITE PHASE 1 (this build): the contracts are implemented —
``config`` (transport configuration), ``errors`` (taxonomy + classifiers),
``cachekeys`` (cache identity discipline), ``resolver`` (rows → handles),
``httpclient`` (token-safe HTTP), ``repair`` (file-id recovery), ``sources``
(cloud + Local Bot API), ``stack`` (composition + retry policy).

Import surface stays import-light: importing ``app.media`` imports NOTHING
(submodules are imported explicitly by their consumers), so dependency
isolation (architecture test D/C pattern) remains trivial.
"""
