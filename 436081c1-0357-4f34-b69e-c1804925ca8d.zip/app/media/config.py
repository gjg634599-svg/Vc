"""Media transport configuration (WEBSITE PHASE 1).

Reads the Local Bot API / media environment through the existing
configuration architecture (env vars, sane defaults, fail-fast validation).
PURE stdlib: importable without aiohttp/telegram/bot.py.

Environment variables:
  TELEGRAM_API_MODE          cloud | local | auto         (default: cloud)
                              auto = RECOMMENDED production mode: use the
                              Local Bot API when healthy/appropriate,
                              otherwise the cloud Bot API (spec §10/§13).
  TELEGRAM_LOCAL_API_URL     http://PRIVATE_IP:8081     (required for local;
                              optional for auto — auto without it degrades
                              to pure cloud, which is the "no Local server
                              today" deployment)
  TELEGRAM_API_ID            integer (optional; carried for Local Bot API /
                             future MTProto deployments — never logged)
  TELEGRAM_API_HASH          secret (optional; NEVER logged)
  MEDIA_LOCAL_FILE_ROOT      shared-filesystem mount of the Local Bot API
                             working directory (enables true disk seeks)
  MEDIA_CLOUD_MAX_BYTES      cloud getFile/download cap (default 20 MiB)
  MEDIA_STREAM_CHUNK_SIZE    bytes per streamed chunk (default 1 MiB,
                             clamped to [64 KiB, 8 MiB])
  MEDIA_HTTP_TIMEOUT         per-request timeout seconds (default 30)
  MEDIA_GETFILE_TIMEOUT      getFile metadata timeout seconds (default
                             600) — bot-18.log: a local Bot API server
                             must DOWNLOAD an 856 MB file from the
                             Telegram DC BEFORE getFile answers, so the
                             generic 30 s bound killed every large-file
                             playback (MEDIA_UPSTREAM_ERROR kind=TimeoutError
                             phase=getfile → 503 → dead player). This
                             bound applies ONLY to the getFile phase;
                             stalled connections still fail via sock_read.

Security: the Local Bot API URL must stay on a PRIVATE network (behind
WireGuard / a firewall) — a public-looking host logs a warning (spec §17).
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any, Mapping, Optional, Tuple
from urllib.parse import urlsplit

logger = logging.getLogger("payload-bot")

CLOUD_API_BASE_URL = "https://api.telegram.org"
CLOUD_DOWNLOAD_LIMIT_BYTES = 20 * 1024 * 1024  # the documented cloud cap

DEFAULT_STREAM_CHUNK_SIZE = 1024 * 1024
MIN_STREAM_CHUNK_SIZE = 64 * 1024
MAX_STREAM_CHUNK_SIZE = 8 * 1024 * 1024
DEFAULT_HTTP_TIMEOUT_SECONDS = 30
# B17 — the getFile phase bound. A local telegram-bot-api server downloads
# the file from the Telegram DC BEFORE responding to getFile; an ~856 MB
# file needs minutes, not 30 seconds (bot-18.log, jobs AgADUiQAAml2MFU /
# AgADyB8AAnV00FA). 600 s covers ~1.4 MB/s worst-case DC throughput.
DEFAULT_GETFILE_TIMEOUT_SECONDS = 600

MODE_CLOUD = "cloud"
MODE_LOCAL = "local"
MODE_AUTO = "auto"  # GAP-CLOSURE spec §13: the recommended production mode

# AUTO-mode health probe cadence (spec §14: startup probe, cached state,
# retry/backoff, recovery probe — never blocking cloud operation).
DEFAULT_LOCAL_PROBE_TIMEOUT_SECONDS = 2.0
DEFAULT_LOCAL_HEALTHY_TTL_SECONDS = 60.0     # healthy state cache TTL
DEFAULT_LOCAL_UNAVAILABLE_BACKOFF_SECONDS = 15.0  # retry/backoff cadence

# Hosts that never warrant the "public exposure" warning.
_PRIVATE_HOST_SUFFIXES = (".local", ".internal", ".lan", ".home", ".home.arpa")


def _looks_private(host: str) -> bool:
    """Best-effort private-network check (RFC1918 / loopback / link-local /
    CGNAT / ULA / unix sockets). Not a security control — a log hint only."""
    if not host:
        return True
    h = host.strip("[]").lower()
    if h in ("localhost", "::1", "") or h.startswith("127."):
        return True
    if h.startswith("/"):  # unix socket path
        return True
    if h.endswith(_PRIVATE_HOST_SUFFIXES):
        return True
    try:
        parts = [int(p) for p in h.split(".")]
        if len(parts) != 4:
            return False
        a, b = parts[0], parts[1]
        return (
            a == 10
            or (a == 192 and b == 168)
            or (a == 172 and 16 <= b <= 31)
            or (a == 169 and b == 254)
            or (a == 100 and 64 <= b <= 127)
            or (a == 192 and b == 0)  # 192.0.0.0/24 (protocol) — harmless
        )
    except ValueError:
        return h.startswith(("fc", "fd"))  # ULA IPv6


@dataclass(frozen=True)
class MediaTransportConfig:
    """Immutable media transport configuration."""

    api_mode: str = MODE_CLOUD
    local_api_url: Optional[str] = None
    local_file_root: Optional[str] = None
    api_id: Optional[str] = None
    api_hash: Optional[str] = None
    cloud_download_limit_bytes: int = CLOUD_DOWNLOAD_LIMIT_BYTES
    stream_chunk_size: int = DEFAULT_STREAM_CHUNK_SIZE
    http_timeout_seconds: int = DEFAULT_HTTP_TIMEOUT_SECONDS
    getfile_timeout_seconds: int = DEFAULT_GETFILE_TIMEOUT_SECONDS
    cloud_api_base: str = CLOUD_API_BASE_URL

    # ---- derived --------------------------------------------------------
    @property
    def local_mode(self) -> bool:
        return self.api_mode == MODE_LOCAL

    @property
    def auto_mode(self) -> bool:
        """GAP-CLOSURE spec §10/§13: health-aware automatic selection."""
        return self.api_mode == MODE_AUTO

    @property
    def local_configured(self) -> bool:
        """A Local Bot API server is configured (any mode except pure cloud
        without a URL). In AUTO mode without a URL the deployment degrades
        to cloud — small media still works TODAY (spec §12)."""
        return bool(self.local_api_url)

    def validate(self) -> "MediaTransportConfig":
        if self.api_mode not in (MODE_CLOUD, MODE_LOCAL, MODE_AUTO):
            raise ValueError(
                f"TELEGRAM_API_MODE must be '{MODE_CLOUD}', '{MODE_LOCAL}' or "
                f"'{MODE_AUTO}', got {self.api_mode!r}")
        if self.api_mode in (MODE_LOCAL, MODE_AUTO) and self.local_api_url:
            parts = urlsplit(self.local_api_url)
            if parts.scheme not in ("http", "https") or not parts.hostname:
                raise ValueError(
                    "TELEGRAM_LOCAL_API_URL must be an http(s) URL with a host")
            if not _looks_private(parts.hostname):
                logger.warning(
                    "TELEGRAM_LOCAL_API_URL host %s looks PUBLIC — the Local "
                    "Bot API must sit on a private network (WireGuard/firewall), "
                    "never exposed directly to the internet (spec §17).",
                    parts.hostname)
        if self.api_mode == MODE_LOCAL:
            if not self.local_api_url:
                raise ValueError(
                    "TELEGRAM_API_MODE=local requires TELEGRAM_LOCAL_API_URL "
                    "(e.g. http://PRIVATE_IP:8081)")
        if self.cloud_download_limit_bytes < 1024:
            raise ValueError("MEDIA_CLOUD_MAX_BYTES must be >= 1024")
        if self.http_timeout_seconds < 1:
            raise ValueError("MEDIA_HTTP_TIMEOUT must be >= 1 second")
        if self.getfile_timeout_seconds < 1:
            raise ValueError("MEDIA_GETFILE_TIMEOUT must be >= 1 second")
        return self

    def clamped_chunk_size(self) -> int:
        return max(MIN_STREAM_CHUNK_SIZE,
                   min(MAX_STREAM_CHUNK_SIZE, int(self.stream_chunk_size)))

    def local_getfile_url(self, bot_token: str) -> str:
        if not self.local_api_url:
            raise ValueError("local mode not configured")
        return f"{self.local_api_url}/bot{bot_token}/getFile"

    def local_getme_url(self, bot_token: str) -> str:
        """Health-probe endpoint for the Local Bot API monitor (spec §14)."""
        if not self.local_api_url:
            raise ValueError("local mode not configured")
        return f"{self.local_api_url}/bot{bot_token}/getMe"

    def local_file_url(self, bot_token: str, file_path: str) -> str:
        if not self.local_api_url:
            raise ValueError("local mode not configured")
        base = self.local_api_url.rstrip("/")
        return f"{base}/file/bot{bot_token}/{file_path.lstrip('/')}"

    def cloud_getfile_url(self, bot_token: str) -> str:
        return f"{self.cloud_api_base}/bot{bot_token}/getFile"

    def cloud_file_url(self, bot_token: str, file_path: str) -> str:
        return f"{self.cloud_api_base}/file/bot{bot_token}/{file_path.lstrip('/')}"

    def describe(self) -> str:
        """Safe log/admin summary — NEVER includes api_hash or bot tokens."""
        root = self.local_file_root or "-"
        url_host = (urlsplit(self.local_api_url).hostname
                    if self.local_api_url else "-")
        return (f"mode={self.api_mode} local_host={url_host} "
                f"file_root={root} api_id_set={bool(self.api_id)} "
                f"api_hash_set={bool(self.api_hash)} "
                f"cloud_limit={self.cloud_download_limit_bytes} "
                f"chunk={self.clamped_chunk_size()} "
                f"timeout={self.http_timeout_seconds}s")

    # ---- construction ----------------------------------------------------
    @classmethod
    def from_env(cls, env: Optional[Mapping[str, str]] = None,
                 *, environ: Optional[Mapping[str, str]] = None
                 ) -> "MediaTransportConfig":
        """Build + validate from the environment (or an injected mapping)."""
        source: Mapping[str, str] = env if env is not None else (
            environ if environ is not None else os.environ)

        def _get(key: str) -> Optional[str]:
            v = source.get(key)
            if v is None:
                return None
            v = str(v).strip()
            return v or None

        mode = (_get("TELEGRAM_API_MODE") or MODE_CLOUD).strip().lower()
        chunk_raw = _get("MEDIA_STREAM_CHUNK_SIZE")
        chunk = int(chunk_raw) if chunk_raw and chunk_raw.isdigit() else \
            DEFAULT_STREAM_CHUNK_SIZE
        limit_raw = _get("MEDIA_CLOUD_MAX_BYTES")
        limit = int(limit_raw) if limit_raw and limit_raw.isdigit() else \
            CLOUD_DOWNLOAD_LIMIT_BYTES
        timeout_raw = _get("MEDIA_HTTP_TIMEOUT")
        timeout = int(timeout_raw) if timeout_raw and timeout_raw.isdigit() \
            else DEFAULT_HTTP_TIMEOUT_SECONDS
        getfile_raw = _get("MEDIA_GETFILE_TIMEOUT")
        getfile_timeout = int(getfile_raw) if getfile_raw \
            and getfile_raw.isdigit() else DEFAULT_GETFILE_TIMEOUT_SECONDS
        api_id = _get("TELEGRAM_API_ID")
        if api_id is not None and not api_id.isdigit():
            raise ValueError("TELEGRAM_API_ID must be numeric")

        cfg = cls(
            api_mode=mode,
            local_api_url=_get("TELEGRAM_LOCAL_API_URL"),
            local_file_root=_get("MEDIA_LOCAL_FILE_ROOT"),
            api_id=api_id,
            api_hash=_get("TELEGRAM_API_HASH"),
            cloud_download_limit_bytes=limit,
            stream_chunk_size=chunk,
            http_timeout_seconds=timeout,
            getfile_timeout_seconds=getfile_timeout,
        )
        return cfg.validate()


def config_from_mapping(env: Mapping[str, Any]) -> MediaTransportConfig:
    """Test/wiring helper: build a validated config from any mapping."""
    return MediaTransportConfig.from_env(
        {k: str(v) for k, v in env.items() if v is not None})


def public_host_hint(url: str) -> Tuple[bool, str]:
    """(is_private, host) — exported for tests of the warning heuristic."""
    host = urlsplit(url).hostname or ""
    return _looks_private(host), host
