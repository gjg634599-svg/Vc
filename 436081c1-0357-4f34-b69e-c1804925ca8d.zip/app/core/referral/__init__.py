"""Referral domain service."""
