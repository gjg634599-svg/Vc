"""Force Join domain service."""
