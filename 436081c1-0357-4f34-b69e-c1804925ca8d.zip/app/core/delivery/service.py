"""Delivery domain service (ARCHITECTURE PHASE).

The delivery-domain helpers extracted from bot.py: the recovery-card
builder, the admin recovery chat resolver and the retrieve message/button/
text resolvers.

HONEST SCOPE: ``_deliver_files_core`` remains in bot.py — its in-function
structure (the Watch Ads delivery gate BEFORE the intro message and any
send_file/send_album call) is source-pinned by the Phase 7 regression suite
(docs/ARCHITECTURE_AUDIT.md §3). ``_dispatch_delivery_arg`` (Telegram
update-argument dispatch) also stays in bot.py as adapter code. The helpers
here are the canonical implementations; bot.py keeps thin wrappers.
"""
from __future__ import annotations

import logging
from types import SimpleNamespace

import aiosqlite

from app.core.constants import (
    AUTO_DELETE_DEFAULT, DEFAULT_RETRIEVE_BUTTON, DEFAULT_RETRIEVE_TEXT,
)
from app.core.dbutil import safe_row_get as _safe_row_get
from typing import Any, Dict, List, Optional

logger = logging.getLogger("payload-bot")


def make_delivery_service(db, safe_send_text=None, render_retrieve_message=None,
                          _get_owner_id=None, schedule_auto_delete=None,
                          resolve_delete_after=None):
    """Bind the verbatim implementations to explicit dependencies
    (call-time late binding - no globals)."""
    async def create_recovery_card(bot, chat_id: int, user_id: int,
                                    payload_code: str, delivery_type: str,
                                    collection_code: Optional[str] = None,
                                    title: Optional[str] = None,
                                    description: Optional[str] = None,
                                    banner_file_id: Optional[str] = None,
                                    banner_type: Optional[str] = None,
                                    existing_record_id: Optional[int] = None,
                                    existing_msg_id: Optional[int] = None,
                                    reply_to_message_id: Optional[int] = None) -> None:
        """Issue #84: Reply-based retrieve system (replaces branding card architecture).

        This is now a thin backward-compat wrapper around render_retrieve_message().
        All delivery paths MUST call render_retrieve_message() directly. This wrapper
        exists only so any legacy call sites still resolve. The reply_to_message_id
        parameter is the key addition: the retrieve message is attached (via Telegram
        reply) to the delivered content, not sent as a standalone card.

        The retrieve message is NEVER auto-deleted — only delivered media is. It
        remains available according to the retrieve settings (limit / window).
        """
        await render_retrieve_message(
            bot, chat_id=chat_id, user_id=user_id,
            payload_code=payload_code, delivery_type=delivery_type,
            collection_code=collection_code,
            reply_to_message_id=reply_to_message_id,
            existing_record_id=existing_record_id,
            existing_msg_id=existing_msg_id,
        )

    async def _recovery_admin_chat_id() -> Optional[int]:
        """An internal chat the bot may fetch source messages into (owner or
        first active DB admin). NEVER the recipient's chat — recovery is
        internal and never visible to users."""
        owner = _get_owner_id()
        if owner:
            return owner
        try:
            # RULE E: SQL lives in the storage repository.
            admin_id = await db.first_active_admin_id()
            if admin_id:
                return admin_id
        except Exception as e:  # noqa: BLE001
            logger.warning("BOT6_DELIVERY_SOURCE_RECOVERY admin_chat_lookup_failed "
                           "error=%s", e)
        return None

    async def get_retrieve_text() -> str:
        """Admin-configurable retrieve message body.
        Supports the {timer} placeholder."""
        return await db.get_setting("retrieve_message_text") or DEFAULT_RETRIEVE_TEXT

    async def get_retrieve_button() -> str:
        """Admin-configurable retrieve button label."""
        return await db.get_setting("retrieve_message_button") or DEFAULT_RETRIEVE_BUTTON

    def _format_retrieve_text(template: str, count: int = 0,
                               timer_seconds: Optional[int] = None) -> str:
        """Substitute {count} and {timer} placeholders in retrieve text.
        {timer} → "X seconds" (>0) or "will not be automatically deleted" (0).

        BOT6 FIX: if the template does NOT contain {timer} (e.g. the admin stored
        a custom text with a literal "20 seconds" hardcoded), we regex-replace any
        hardcoded "N seconds"/"N second"/"N s" pattern with the effective timer text.
        This ensures the rendered text ALWAYS matches the actual scheduler timer,
        regardless of whether the admin used {timer} or hardcoded a value."""
        import re as _re
        result = template.replace("{count}", str(count) if count > 0 else "")
        if timer_seconds is not None:
            if timer_seconds > 0:
                timer_text = f"{timer_seconds} seconds"
            else:
                timer_text = "will not be automatically deleted"
        else:
            # Fallback: resolve the global default at call time (never hardcode 20).
            # Callers should always pass timer_seconds; this is a defensive default.
            timer_text = "20 seconds"
        if "{timer}" in result:
            result = result.replace("{timer}", timer_text)
        else:
            # Template has no {timer} placeholder — replace any hardcoded timer
            # pattern ("N seconds", "N second", "N s", "Never") with the effective
            # timer text so the rendered text matches the actual scheduler.
            result = _re.sub(r'\d+\s*second[s]?', timer_text, result, flags=_re.IGNORECASE)
            if timer_seconds == 0:
                # Also replace literal "Never" if the effective timer is 0 but the
                # template had a numeric value (unlikely but safe).
                pass
        return result

    return SimpleNamespace(
        create_recovery_card=create_recovery_card,
        _recovery_admin_chat_id=_recovery_admin_chat_id,
        get_retrieve_text=get_retrieve_text,
        get_retrieve_button=get_retrieve_button,
        _format_retrieve_text=_format_retrieve_text,
    )
