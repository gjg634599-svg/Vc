"""Delivery domain service."""
