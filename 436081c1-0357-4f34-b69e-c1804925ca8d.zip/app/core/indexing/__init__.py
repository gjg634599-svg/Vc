"""Durable indexing engine (PHASE 8 — canonical).

The implementation lives in ``app.core.indexing.engine``; this package
__init__ re-exports the public surface.
"""
from app.core.indexing.engine import *  # noqa: F401,F403
