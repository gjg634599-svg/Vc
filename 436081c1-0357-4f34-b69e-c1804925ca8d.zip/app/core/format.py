"""Pure presentation/formatting helpers (ARCHITECTURE PHASE)."""
from __future__ import annotations

import re

from types import SimpleNamespace

from datetime import datetime
from typing import Optional

def format_size(size: Optional[int]) -> str:
    if not size:
        return "Unknown"
    size = float(size)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"

def truncate(text: Optional[str], limit: int = 1024) -> Optional[str]:
    if text and len(text) > limit:
        return text[: limit - 1] + "\u2026"
    return text

def format_duration(seconds: Optional[int]) -> str:
    if not seconds:
        return "-"
    mins, secs = divmod(int(seconds), 60)
    hours, mins = divmod(mins, 60)
    if hours:
        return f"{hours:d}:{mins:02d}:{secs:02d}"
    return f"{mins:d}:{secs:02d}"

def media_emoji(media_type: Optional[str]) -> str:
    return {
        "video": "\U0001F3AC",      # 🎬
        "document": "\U0001F4C4",    # 📄
        "audio": "\U0001F3B5",       # 🎵
        "voice": "\U0001F3A4",       # 🎤
        "animation": "\U0001F3AC",  # 🎬
        "photo": "\U0001F4F7",       # 📷
        "video_note": "\U0001F3AC",
        "sticker": "\U0001F3AB",
    }.get(media_type or "", "\U0001F4CE")

def media_type_label(media_type: Optional[str]) -> str:
    """Return a human-readable media-type label (e.g. 'Video', 'Document')."""
    return MEDIA_TYPE_LABELS.get(media_type or "", "File")

def fmt_ts(iso_str: Optional[str]) -> str:
    """Format an ISO timestamp into a clean, human-readable date/time."""
    if not iso_str:
        return "-"
    try:
        dt = datetime.fromisoformat(iso_str)
        return dt.strftime("%d %b %Y %H:%M UTC")
    except (ValueError, TypeError):
        return iso_str[:19] if len(iso_str) > 19 else iso_str

def escape_md(text: str) -> str:
    """Escape Markdown special characters so dynamic content (usernames, file
    names, etc.) doesn't break Markdown parsing. E.g. '@Onlyfansadlt_bot' has
    an underscore that Markdown treats as italic-start -> 'can't find end of
    the entity' crash."""
    if not text:
        return text
    return _MD_SPECIAL.sub(r'\\\1', str(text))

def md_code_span(value) -> str:
    """Render an arbitrary dynamic value as a SAFE legacy-Markdown code span.

    Root-cause fix for the production `Can't parse entities: can't find end
    of the entity` family: payload names / codes / policy values interpolated
    raw into ParseMode.MARKDOWN panels break parsing whenever they contain
    `_`, `*`, `[`, `` ` `` with unbalanced parity. Inside a code span Telegram
    ignores every special character EXCEPT the backtick itself, so replacing
    backticks makes the span unbreakable while keeping the monospace look for
    normal values (payload codes keep their underscores readable)."""
    s = "" if value is None else str(value)
    return "`" + s.replace("`", "'") + "`"

MEDIA_TYPE_LABELS: Dict[str, str] = {
    "video": "Video",
    "document": "Document",
    "audio": "Audio",
    "voice": "Voice",
    "animation": "Animation",
    "photo": "Photo",
    "video_note": "Video Note",
    "sticker": "Sticker",
}

_MD_SPECIAL = re.compile(r'([_*\[`~|])')

