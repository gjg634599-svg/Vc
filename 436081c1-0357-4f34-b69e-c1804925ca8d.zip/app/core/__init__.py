"""Core service layer (ARCHITECTURE PHASE).

Packages: access, payload, delivery, force_join, referral, watch_ads,
indexing, verification + the shared constants/format modules. The legacy
module-attribute imports (``from app.core import indexing_engine`` /
``verification`` / ``fj_link_health``) keep working via the aliases below.
"""
from app.core.indexing import engine as indexing_engine  # noqa: F401
from app.core import verification  # noqa: F401
from app.core import fj_link_health  # noqa: F401
