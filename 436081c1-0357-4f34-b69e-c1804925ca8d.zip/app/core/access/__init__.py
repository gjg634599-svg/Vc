"""Access Engine core (single authorization layer)."""
