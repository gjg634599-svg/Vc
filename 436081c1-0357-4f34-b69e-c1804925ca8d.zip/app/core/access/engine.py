"""Access Engine core: the AccessResult contract and the NETWORK
POINTS alternative (the third OR branch of the single access
decision system). The policy resolver shell remains pinned in
bot.py by the regression suites (docs/BOT_COMPATIBILITY.md) and
calls INTO this module's gate/points helpers."""
from __future__ import annotations

from dataclasses import dataclass, field

import logging
from types import SimpleNamespace

from app.core.constants import (
    NET_DEFAULT_POINT_COST, NET_SETTING_POINTS_ACCESS,
    NET_SETTING_POINT_COST, ACCESS_POLICY_FORCE_JOIN, ACCESS_POLICY_OPEN,
    ACCESS_POLICY_FORCE_JOIN_REFERRAL, ACCESS_POLICIES_IMPLEMENTED,
    ACCESS_POLICIES_ALL, ACCESS_POLICY_DEFAULT,
)
from typing import Optional

logger = logging.getLogger("payload-bot")

@dataclass
class AccessResult:
    """Outcome of an Access Engine resolution.

    `authorized` is the single boolean every delivery path must check. The
    remaining fields carry the context needed to render the correct
    "Access Requirement Screen" when authorization is denied.
    """
    authorized: bool = False
    policy: str = ACCESS_POLICY_FORCE_JOIN
    payload_id: Optional[int] = None
    payload_code: Optional[str] = None
    campaign: Optional[aiosqlite.Row] = None
    unlock_record: Optional[aiosqlite.Row] = None
    required_referrals: int = 0
    completed_referrals: int = 0
    # reason values: "open" | "unlocked" | "force_join_required" |
    # "referral_required" | "payload_missing" | "policy_unknown"
    # WATCH_AD additions (existing reasons stay fully compatible):
    #   "watch_ad_required" — Watch Ads enabled and no valid rewarded unlock
    #   "watch_ad_unlocked" — informative: authorized with a valid ad unlock
    reason: str = "policy_unknown"
    not_joined: List[Any] = field(default_factory=list)
    # WATCH_AD (v25): payload-level requirement state (always False when the
    # payload has Watch Ads disabled — zero behavior change for old payloads).
    watch_ads_enabled: bool = False
    watch_ads_satisfied: bool = False
    watch_ad_unlock_expires: Optional[str] = None
    # NETWORK POINTS (v29): the third OR alternative (spec §8/§51 —
    # Force Join AND (Referral OR Watch Ads OR Points OR Admin Bypass)).
    # points_eligible   — point access is enabled AND the payload gate
    #                     applies (stamped on every locked result so the
    #                     requirement screen can offer the [⭐ Unlock with
    #                     Points] button).
    # points_balance    — the user's current ledger balance.
    # point_cost        — configured cost for THIS unlock.
    # points_satisfied  — informative: a valid point unlock exists.
    points_eligible: bool = False
    points_balance: int = 0
    point_cost: int = 0
    points_satisfied: bool = False


def make_access_points_service(db):
    """Bind the verbatim implementations to explicit
    dependencies (call-time late binding - no globals)."""
    async def _point_access_active() -> bool:
        """NETWORK POINTS (v29, spec §8): global switch — point access is
        CONFIGURABLE (points_access_enabled, default ON)."""
        try:
            return await db.get_setting_bool(NET_SETTING_POINTS_ACCESS, True)
        except Exception:  # noqa: BLE001 — DB unavailable → fail-open on the
            # ALTERNATIVE path only (the primary referral/watch-ad gates still
            # stand); never blocks delivery with a hard crash.
            return True

    async def _point_cost() -> int:
        try:
            return max(1, await db.get_setting_int(NET_SETTING_POINT_COST,
                                                   NET_DEFAULT_POINT_COST))
        except Exception:  # noqa: BLE001
            return NET_DEFAULT_POINT_COST

    async def _stamp_point_context(res: "AccessResult", user_id: int,
                                   payload_id: Optional[int]) -> "AccessResult":
        """Stamp the point context (eligibility/balance/cost) onto a LOCKED
        result so the requirement screen can offer the Points alternative.
        Never flips authorization — purely informational (spec §9 order)."""
        if res is None:
            return res
        try:
            if payload_id is not None and await _point_access_active():
                res.points_eligible = True
                res.point_cost = await _point_cost()
                res.points_balance = await db.points_balance(int(user_id))
        except Exception:  # noqa: BLE001
            pass
        return res

    async def _point_unlock_allows(res: "AccessResult", user_id: int,
                                   payload_row) -> bool:
        """NETWORK POINTS (v29, spec §8/§51): a valid point unlock authorizes a
        gated payload BY ITSELF — the third OR alternative (never AND). Returns
        True and stamps the result when the user holds a point unlock."""
        if res is None or payload_row is None:
            return False
        pid = payload_row["id"] if "id" in payload_row.keys() else None
        if pid is None:
            return False
        if not await _point_access_active():
            return False
        try:
            if await db.point_unlock_valid(int(pid), int(user_id)):
                res.authorized = True
                res.points_satisfied = True
                res.reason = "points_unlocked"
                logger.info(
                    "ACCESS_ENGINE user_id=%s payload_id=%s decision=ALLOW "
                    "reason=points_unlocked (valid point unlock)", user_id, pid)
                return True
        except Exception as exc:  # noqa: BLE001
            logger.warning("point unlock check failed (denying only this "
                           "alternative): %s", exc)
        return False

    return SimpleNamespace(
        _point_access_active=_point_access_active,
        _point_cost=_point_cost,
        _stamp_point_context=_stamp_point_context,
        _point_unlock_allows=_point_unlock_allows,
    )
