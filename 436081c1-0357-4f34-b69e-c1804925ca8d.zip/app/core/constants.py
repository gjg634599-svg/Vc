"""Shared platform constants (ARCHITECTURE PHASE).

Canonical home for the constant blocks that the extracted storage
repositories and core services depend on. The presentation runtime
re-imports every name so the module surface (and the regression suites
that read ``B.<CONSTANT>``) is unchanged. Values are verbatim from the
Phase 8 / Network baseline — NO behavior change.

ARCHITECTURE PROPER BREAKDOWN (RULE F): the four environment-seeded
defaults are parsed ONCE by app/bootstrap/config.py::EnvDefaults — this
module never touches os.environ.
"""
from __future__ import annotations

import re
from typing import List, Tuple

from app.bootstrap.config import EnvDefaults

_ENV_DEFAULTS = EnvDefaults.from_env()


ENABLE_ANALYTICS: bool = _ENV_DEFAULTS.enable_analytics

# ============================================================
# ACCESS ENGINE V1 — POLICY CONSTANTS
# ============================================================
# Every payload carries one access_policy. The Access Engine is the SINGLE
# authorization layer for all delivery. No delivery function may bypass it.
ACCESS_POLICY_OPEN = "OPEN"
ACCESS_POLICY_FORCE_JOIN = "FORCE_JOIN"
ACCESS_POLICY_FORCE_JOIN_REFERRAL = "FORCE_JOIN_REFERRAL"
# The following policies are supported by the architecture for future expansion
# but are NOT yet enforced (treated as FORCE_JOIN until implemented):
ACCESS_POLICY_PASSWORD = "PASSWORD"
ACCESS_POLICY_COUPON = "COUPON"
ACCESS_POLICY_PAYMENT = "PAYMENT"
ACCESS_POLICY_VIP = "VIP"
ACCESS_POLICY_CUSTOM = "CUSTOM"

# Policies fully implemented in this build:
ACCESS_POLICIES_IMPLEMENTED = frozenset({
    ACCESS_POLICY_OPEN, ACCESS_POLICY_FORCE_JOIN, ACCESS_POLICY_FORCE_JOIN_REFERRAL,
})
ACCESS_POLICIES_ALL = frozenset({
    ACCESS_POLICY_OPEN, ACCESS_POLICY_FORCE_JOIN, ACCESS_POLICY_FORCE_JOIN_REFERRAL,
    ACCESS_POLICY_PASSWORD, ACCESS_POLICY_COUPON, ACCESS_POLICY_PAYMENT,
    ACCESS_POLICY_VIP, ACCESS_POLICY_CUSTOM,
})
# Backward-compat default for migrated payloads. Pre-Access-Engine payloads
# always required Force Join (when ENABLE_FORCE_JOIN was true), so FORCE_JOIN
# preserves their exact behaviour. Referral Gate was OFF by default, so it is
# NOT enabled during migration unless a campaign already existed.
ACCESS_POLICY_DEFAULT = ACCESS_POLICY_FORCE_JOIN

# Preview modes for FORCE_JOIN_REFERRAL payloads. IMPORTANT: the protected
# payload file is NEVER used as preview. Only admin-supplied preview media
# (thumbnail / image / video / text) is shown.
PREVIEW_MODE_DISABLED = "disabled"        # info-only locked screen
PREVIEW_MODE_THUMBNAIL = "thumbnail"      # admin-supplied preview image/video
PREVIEW_MODE_DESCRIPTION = "description"  # admin-supplied preview text
PREVIEW_MODE_CUSTOM = "custom"            # admin-supplied custom media
# BOTV7.1 V3: intelligent preview selection modes
PREVIEW_MODE_AUTO = "auto"                # auto-detect first compatible media
PREVIEW_MODE_SELECT = "select"            # admin selects from collection media
PREVIEW_MODES_ALL = frozenset({
    PREVIEW_MODE_DISABLED, PREVIEW_MODE_THUMBNAIL,
    PREVIEW_MODE_DESCRIPTION, PREVIEW_MODE_CUSTOM,
    PREVIEW_MODE_AUTO, PREVIEW_MODE_SELECT,
})
PREVIEW_MODE_DEFAULT = PREVIEW_MODE_AUTO

# Required-referral presets offered in the admin UI.
REFERRAL_REQUIRED_PRESETS: List[int] = [0, 1, 3, 5, 10]
REFERRAL_REQUIRED_DEFAULT: int = 5

REFERRAL_TOKEN_LENGTH: int = 16  # 8 bytes hex = 16 chars

# Session lifecycle statuses.
WATCH_AD_STATUS_PENDING: str = "pending"     # session created, ad not yet verified
WATCH_AD_STATUS_REWARDED: str = "rewarded"   # server-verified reward, unlock active
WATCH_AD_STATUS_EXPIRED: str = "expired"     # session TTL or unlock window elapsed
WATCH_AD_STATUS_REJECTED: str = "rejected"    # fraud / cross-user / payload gone
# Access Engine reason additions (existing reasons stay fully compatible).
WATCH_AD_REASON_REQUIRED: str = "watch_ad_required"
WATCH_AD_REASON_UNLOCKED: str = "watch_ad_unlocked"
# Default ad provider (the only one wired; config-driven, no hard-coded IDs).
WATCH_AD_PROVIDER_DEFAULT: str = "monetag"

# ============================================================
# WATCH_AD V2 (v26) — Ads Control modes
# ============================================================
# The Ads Control setting configures WHAT HAPPENS INSIDE ONE Watch Ads
# session (never how many times the Telegram [🎬 Watch Ad] button is
# pressed — one click always starts/resumes exactly ONE session):
#   "short"  — Short Ads: one verified rewarded ad, preferring the shortest
#              creative the provider serves. The provider (Monetag) controls
#              the actual creative/duration — no local timer ever grants a
#              reward; only the S2S postback does.
#   "random" — Random Ads: the required number of verified rewarded ads is
#              randomized SERVER-SIDE at session creation within
#              WATCH_AD_RANDOM_MIN..WATCH_AD_RANDOM_MAX and stored on the
#              session (the frontend can never choose or influence it).
#   "three"  — Three Ads: exactly three sequential verified rewarded ads
#              inside ONE session (Ad 1 → reward → Ad 2 → reward → Ad 3 →
#              reward → unlock). One Telegram button click, three provider
#              ad opportunities, each individually S2S-verified.
# Persisted in bot_settings under "watch_ads_ad_control" (DB authoritative;
# never overwritten by environment variables on restart).
WATCH_AD_AD_CONTROL_KEY: str = "watch_ads_ad_control"
WATCH_AD_AD_CONTROL_SHORT: str = "short"
WATCH_AD_AD_CONTROL_TWO: str = "two"          # v27: exactly 2 ads (fixed)
WATCH_AD_AD_CONTROL_RANDOM: str = "random"
WATCH_AD_AD_CONTROL_THREE: str = "three"
WATCH_AD_AD_CONTROL_MODES: Tuple[str, str, str, str] = (
    WATCH_AD_AD_CONTROL_SHORT, WATCH_AD_AD_CONTROL_TWO,
    WATCH_AD_AD_CONTROL_RANDOM, WATCH_AD_AD_CONTROL_THREE)
WATCH_AD_AD_CONTROL_DEFAULT: str = WATCH_AD_AD_CONTROL_SHORT
# Safe randomized range for Random Ads mode (1–3 verified rewarded ads).
WATCH_AD_RANDOM_MIN: int = 1
WATCH_AD_RANDOM_MAX: int = 3
# Hard safety cap for required_ads (any mode).
WATCH_AD_MAX_REQUIRED_ADS: int = 3

# ============================================================
# WATCH_AD V4 (v27) — GLOBAL Watch Ads admin controls
# ============================================================
# Global settings act as DEFAULTS; payloads may override the ad mode.
#   watch_ads_global_enabled — "1"/"0" master switch. When "0", the Watch
#     Ads requirement is inactive platform-wide (every payload behaves as if
#     watch_ads_enabled=0: base policy only; WA-only payloads fall back to
#     the fail-safe branch). Per-payload toggles are preserved untouched.
#   watch_ads_session_ttl    — seconds a pending ad session stays valid
#     (default = the WATCH_AD_SESSION_TTL env value; DB authoritative).
#   payloads.watch_ads_ad_mode_override — NULL ("global") or one of the
#     ad-control modes; a per-payload override of the default ad mode.
WATCH_ADS_GLOBAL_ENABLED_KEY: str = "watch_ads_global_enabled"
WATCH_ADS_SESSION_TTL_KEY: str = "watch_ads_session_ttl"
WATCH_ADS_SESSION_TTL_MIN: int = 60          # 1 minute floor
WATCH_ADS_SESSION_TTL_MAX: int = 86400       # 24h ceiling
WATCH_AD_OVERRIDE_GLOBAL: str = "global"     # stored as NULL; display value

# How long an un-rewarded (pending) ad session stays valid before the user
# must request a new one.
WATCH_AD_SESSION_TTL: int = _ENV_DEFAULTS.watch_ad_session_ttl

# ---- ARCHITECTURE PHASE service-layer constants (moved verbatim) ----


# Auto delete (seconds). 0 = never. Overridable per-payload and via settings.
AUTO_DELETE_DEFAULT: int = _ENV_DEFAULTS.auto_delete_default

# ============================================================
# NETWORK PLATFORM (v29) — constants (Phase 8 → Network)
# All values are CONFIGURABLE via bot_settings (spec §7/§8) — nothing is
# hard-coded at the use sites; these are only the DEFAULTS.
# ============================================================
NET_SETTING_ENABLED = "network_enabled"

NET_SETTING_MAX_BOTS = "max_registered_bots_per_user"

NET_SETTING_POINTS_PER_BOT = "points_per_bot_registration"

NET_SETTING_MAX_REWARD = "max_registration_reward_per_user"

NET_SETTING_POINTS_ACCESS = "points_access_enabled"

NET_SETTING_POINT_COST = "payload_point_cost"

NET_SETTING_HEALTH_INTERVAL = "network_health_check_interval"

NET_SETTING_BCAST_RATE = "network_broadcast_rate_per_bot"

NET_SETTING_BCAST_CONFIRM = "network_broadcast_confirm_threshold"

# ---------------------------------------------------------------------------
# TRUSTED FILE DELIVERY (v34 — spec §53/§57): relay TTL, retries, sweeping.
# ---------------------------------------------------------------------------
DELIVERY_SETTING_RELAY_TTL = "delivery_relay_ttl_seconds"
DELIVERY_SETTING_MAX_ATTEMPTS = "delivery_max_attempts"
DELIVERY_SETTING_RETRY_BASE = "delivery_retry_base_seconds"
DELIVERY_SETTING_SWEEP_INTERVAL = "delivery_sweep_interval_seconds"
# B17 — the deep-link handoff window: how long a HANDOFF_PENDING job (the
# user was sent the one-tap t.me/<fdb>?start=dl<token> button) stays
# claimable before it honestly settles EXPIRED (never a lying DELIVERED).
DELIVERY_SETTING_HANDOFF_TTL = "delivery_handoff_ttl_seconds"

DELIVERY_DEFAULT_RELAY_TTL = 900          # abandoned relays cleaned after 15 min
DELIVERY_DEFAULT_MAX_ATTEMPTS = 5
DELIVERY_DEFAULT_RETRY_BASE = 30          # exponential backoff base seconds
DELIVERY_DEFAULT_SWEEP_INTERVAL = 60
DELIVERY_DEFAULT_HANDOFF_TTL = 3600       # handoff button valid for 1 hour

NET_DEFAULT_MAX_BOTS = 5

NET_DEFAULT_POINTS_PER_BOT = 5

NET_DEFAULT_POINT_COST = 1

# Network callback prefixes (verified non-colliding with the ~120 existing
# prefixes enumerated in the Phase N0 audit):
#   net:<view>            — admin: Network Control Center views
#   nreg:<step>           — user/admin: Add-Bot registration wizard
#   nbot:<id>:<action>    — user/admin: registered-bot management
#   npts:<view>           — user: My Points / history
#   ptunlock:<pid>        — user: atomic point unlock for a payload
#   gpl:<id>:<action>     — admin: Global Payload Link management
#   nbc:<view>            — admin: Network Broadcast Center
NET_CB_PREFIX = "net:"

NET_REG_CB = "nreg:"

NET_BOT_CB = "nbot:"

NET_PTS_CB = "npts:"

NET_PT_UNLOCK_CB = "ptunlock:"

NET_BCAST_CB = "nbc:"

# FILE DELIVERY v34 (spec §41-§43/§72-§73): user-facing Delivery Group
# setup wizard + the platform-managed Create Network Bot wizard + the
# Control Bot panel. Verified non-colliding with the existing prefix zoo.
NET_DG_CB = "dg:"

NET_CREATE_CB = "ncreate:"

CONTROL_CB = "ctl:"

# MANAGED BOTS v37 (Task 8): Telegram managed-bot creation.
#   nmg:<action>  — user-facing: managed create flow Cancel/Back (the
#                   reply-keyboard request flow lives on ncreate:start)
#   nleg:<action> — ADMIN-ONLY: the relabeled LEGACY manual token import
#                   (BotFather token, migration only) — deliberately NOT
#                   user-facing so it can never hijack the managed flow.
# Verified non-colliding with the existing prefix zoo (N0 audit class).
NET_MANAGED_CB = "nmg:"

NET_LEGACY_CB = "nleg:"

# Message-ID direct links: prefix used in deep links like ?start=m8619
MSG_LINK_PREFIX: str = "m"

# Range links: prefix used in deep links like ?start=r8619_8625
# DEPRECATED (Issue 2 Critical Fix): kept for backward-compat. New collections
# use COLLECTION_LINK_PREFIX. Old r<link> links are auto-migrated on open.
RANGE_LINK_PREFIX: str = "r"

# Collection links: prefix used in deep links like ?start=c7f3a9b2
# Issue 2 Critical Fix: explicit collection storage replaces unreliable ranges.
COLLECTION_LINK_PREFIX: str = "c"

# Issue #94: Referral links — ?start=ref_<token>. The token is an opaque 16-char
# hex string that maps to (campaign_id, inviter_user_id) in referral_tokens.
# Using an opaque token avoids parsing ambiguity (payload names can contain
# underscores, so ref_payload_token would be ambiguous).
REFERRAL_LINK_PREFIX: str = "ref_"

# Length of the random collection code (hex). 8 hex chars = 4 bytes = ~4 billion
# combinations, low collision risk for any practical collection count.
COLLECTION_CODE_LENGTH: int = 8

# Telegram Mini App initData freshness (auth_date age, seconds).
WATCH_AD_INITDATA_MAX_AGE: int = _ENV_DEFAULTS.watch_ad_initdata_max_age

# Monetag SDK code size guard (admin paste is treated as untrusted config).
WATCH_AD_SDK_MAX_CHARS: int = 20000

PAYLOAD_PATTERN = re.compile(r"^[a-z0-9][a-z0-9_]{0,63}$")

# BOTV13: display_name validation. Allows human-readable names with spaces,
# mixed case, hyphens, and Unicode word characters. Rejects only: empty,
# too long (>128), or control characters. Strips Markdown specials so the
# name can never break parse_mode rendering.
DISPLAY_NAME_MAX_LENGTH = 128

# ============================================================
# ISSUE 7: REQUEST-TO-JOIN POLICY SWITCH (in-memory cache)
# ============================================================
# Two policies for Request-to-Join channels:
#   "request"  -> ChatJoinRequest grants access immediately (admin approval NOT required)
#   "approval" -> user must be an actual member (admin must approve)
JOIN_REQUEST_POLICY_REQUEST = "request"

JOIN_REQUEST_POLICY_APPROVAL = "approval"

JOIN_REQUEST_TTL: int = 3600  # 1 hour — pending entries expire after this

# BOTV13 Phase 3: Progressive Force Join modes.
FJ_MODE_PROGRESSIVE_RANDOM = "progressive_random"

FJ_MODE_FIXED_ORDER = "fixed_order"

FJ_MODE_SHOW_ALL = "show_all"

FJ_MODE_DEFAULT = FJ_MODE_SHOW_ALL  # backward compat: existing campaigns show all

FJ_BATCH_SIZE_DEFAULT = 2  # V25 FINAL (bot-35.log §22): the authoritative
# product configuration is SIX channels / batch size TWO (2 → 2 → 2 — the
# V25 acceptance scenario). Admins may still override via the FJ settings
# panel (fj_batch_size); fresh deployments + every acceptance test get 2.

# Issue 6: Browse Files silent auto-delete window (seconds). No notice,
# no countdown — the browse message simply disappears after this delay.
BROWSE_AUTO_DELETE_DELAY: int = 10


# ---- delivery service constants (moved verbatim) ----

DEFAULT_RETRIEVE_TEXT = (
    "\u23F0 Files sent by the bot will be deleted after {timer}.\n\n"
    "\u2705 Save or forward files before deletion."
)

DEFAULT_RETRIEVE_BUTTON = "\U0001F4E5 Retrieve Media"
