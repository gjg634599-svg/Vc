#!/usr/bin/env bash
# MediaGrab Bot — supervisor installer (v98.08 FIX-XX).
# Installs deploy/mediagrab.service as a systemd unit on the production
# host and enables it (Restart=always, RestartSec=10).
#
# Usage (as root, from the extraction dir):
#   bash deploy/install_supervisor.sh
#
# Idempotent: re-running reloads + restarts the unit safely.

set -euo pipefail

SERVICE_SRC="$(cd "$(dirname "$0")" && pwd)/mediagrab.service"
SERVICE_DST="/etc/systemd/system/mediagrab.service"
RUN_DIR="/root/gr"

if [[ "$(id -u)" -ne 0 ]]; then
    echo "ERROR: run as root (systemd unit install)." >&2
    exit 1
fi
if [[ ! -f "$SERVICE_SRC" ]]; then
    echo "ERROR: mediagrab.service not found next to this script ($SERVICE_SRC)" >&2
    exit 1
fi
if [[ ! -d "$RUN_DIR" ]]; then
    echo "ERROR: expected the bot at $RUN_DIR (WorkingDirectory in the unit)." >&2
    exit 1
fi
if ! command -v systemctl >/dev/null 2>&1; then
    echo "ERROR: systemctl not available (systemd required for this unit)." >&2
    exit 1
fi

echo "[1/4] Installing unit: $SERVICE_DST"
install -m 0644 "$SERVICE_SRC" "$SERVICE_DST"

echo "[2/4] daemon-reload"
systemctl daemon-reload

echo "[3/4] enable + (re)start"
systemctl enable mediagrab >/dev/null
systemctl restart mediagrab || true

echo "[4/4] status"
sleep 2
systemctl --no-pager --lines 5 status mediagrab || true

echo
echo "Supervisor installed. Useful commands:"
echo "  systemctl status mediagrab                      # health"
echo "  journalctl -u mediagrab -n 200 --no-pager       # recent output"
echo "  journalctl -u mediagrab | grep 'status=86'      # canary exits (wedge)"
echo "  kill -USR1 \$(systemctl show -p MainPID --value mediagrab)  # thread dump"
echo "  ls /root/gr/mediagrab_bot/vc_canary_dump_*.txt  # retained canary dumps"
