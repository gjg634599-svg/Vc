#!/usr/bin/env python3
"""vc_static_audit.py — v98.09 §39 STATIC ARCHITECTURE AUDIT.

An AST-based checker that identifies event-loop hazards in the
mediagrab_bot sources:

  1. ``while`` loops — every one is classified:
       SYNC-NO-PROGRESS  (CRITICAL — the v98.08 freeze class: condition
                          vars not advanced in the body)
       SYNC-CONDITIONAL-ADVANCE (HIGH — advance gated by a condition;
                          the v98.08 FIX-CCC defect class)
       SYNC-ADVANCE      (SAFE — unconditional progress)
       ASYNC-AWAIT       (SAFE — yields to the event loop)
       DAEMON-THREAD     (JUSTIFIED — watchdog threads by design)
  2. ``time.sleep`` inside async functions          (CRITICAL)
  3. sync ``subprocess`` calls in async functions   (HIGH)
  4. ``create_task`` without a name= / owner        (MEDIUM)
  5. lock ``.acquire(`` without timeout= in async   (HIGH)
  6. broad ``except Exception: pass``               (INFO — counted)
  7. the v98.08 FIX-CCC defect signature itself     (CRITICAL detector)

Every finding is classified SAFE / FIXED / EXPLICITLY JUSTIFIED —
no unclassified CRITICAL/HIGH findings are allowed to ship (§39).

Usage:
    python3 tools/vc_static_audit.py [--root DIR] [--json OUT]
    python3 tools/vc_static_audit.py --file voicechat_v9808.py
        (single-file mode: used to prove the checker WOULD have caught
        the v98.08 defect — run against the historical source)

Exit code: 0 = no unclassified CRITICAL/HIGH; 1 = findings need review.
"""

from __future__ import annotations

import argparse
import ast
import json
import os
import sys
from typing import Any, Dict, List, Optional

DEFAULT_MODULES = [
    "voicechat.py", "bootstrap.py", "mtproto.py", "handlers.py",
    "vc_hooks.py", "vc_architecture.py", "vc_op_scheduler.py",
    "vc_state_coordinator.py", "talkative_hooks.py", "diag_hooks.py",
    "join_all_worker.py", "distributed_join.py", "config.py",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# §39 JUSTIFICATIONS — findings reviewed by the v98.09 release engineer
# and EXPLICITLY JUSTIFIED (each with the reason). A finding here is a
# documented decision, not an oversight. Format: (module, line).
# ---------------------------------------------------------------------------
JUSTIFICATIONS: Dict[str, str] = {
    # bootstrap.py:4112 — InstanceGuard.acquire uses a plain asyncio.Lock
    # whose critical section is microsecond-scale synchronous flag
    # setting (no network I/O, no nested locks); the hold discipline
    # bounds the wait. v98.08 shipped this unchanged; the canary covers
    # the pathological case.
    # v98.12 (documented correction): line 4085 → 4112 — the §26 editable
    # status-message wiring (Bot API _cmd_vcjoin status_fn, +27 lines above
    # the anchor) shifted the finding; it is byte-identical (same acquire,
    # same justification).
    # v98.12-FINAL2 (documented correction): 4112 → 4138 — the FIX-ID
    # __init__.py hash block + FIX-SR startup-reconcile scheduling (+26
    # lines above the anchor) shifted the finding; byte-identical (same
    # acquire, same justification).
    # v99.02 (documented correction): 4138 -> 4165 — the FIX-4c cluster
    # reconnect fail_count block (+27 lines above the anchor) shifted the
    # finding; byte-identical (same acquire, same justification).
    # v99.03 (documented correction): 4165 -> 4186 — the RC-8/RC-9 deploy
    # self-heal helper functions (+21 lines above the anchor) shifted the
    # finding; byte-identical (same acquire, same justification).
    # v99.05 (documented correction): 4186 -> 4195 — the RC-17 recovery
    # scheduling call in _post_init (+9 lines above the anchor) shifted
    # the finding; byte-identical (same acquire, same justification).
    # v99.07 (documented correction): 4195 -> 4387 — the FIX-12/13/14/15/
    # 16/17 worker-watchdog + task-dump + lag-monitor + liveness-lock
    # insertions above the anchor (+192 lines) shifted the finding; it is
    # byte-identical (same acquire, same justification).
    # v99.08 (documented correction): 4387 -> 4392 — the item-3
    # cluster_reconnect_loop heartbeat registration (+5 lines above the
    # anchor) shifted the finding; byte-identical (same acquire, same
    # justification).
    # v99.09 (documented correction): 4392 -> 4453 — the FIX-D
    # _vc_loop_liveness_task module-global declaration + watchdog
    # restarter guard + FIX-E task-dump Join-All suppression (+61 lines
    # above the anchor) shifted the finding; byte-identical (same
    # acquire, same justification).
    "bootstrap.py:4453":
        "EXPLICITLY JUSTIFIED (§17): microsecond sync critical section "
        "(flag set + diag log); no I/O under the lock; hold discipline "
        "bounds the wait; canary covers pathology",
    # mtproto.py:4957 — RPC semaphore acquired without timeout but ALWAYS
    # released in a finally (the adjacent v97 CRITICAL FIX comment
    # documents the discipline); the wait is bounded by in-flight RPC
    # timeouts (each RPC has its own timeout), so a stuck acquire means
    # a stuck RPC, which the RPC timeout itself bounds.
    # v99.03 (documented correction): 4957 -> 5188 — the RC-10/RC-11 session
    # health registry + account_session_health block (+231 lines above the
    # anchor) shifted the finding; byte-identical (same acquire, same
    # justification).
    # v99.05 (documented correction): 5188 -> 5273 — the RC-15 health-loop
    # fix + the RC-12-adjacent emit change + the RC-16 login registration
    # (+85 lines above the anchor) shifted the finding; byte-identical
    # (same acquire, same justification).
    # v99.05: 5273 -> 5345 (documented correction; the RC-F5
    # _primary_value/_primary_entry schema helpers + the honest
    # dual-role account_session_health counting added +72 lines above
    # the anchor; byte-identical acquire, same justification).
    # v99.06 (documented correction): 5345 -> 5438 — the FIX-1
    # get_primary_account_id() helper + the set_primary_id pre-swap
    # rotation purge + the _vc_client_scope chameleon binding (+93
    # lines above the anchor) shifted the finding; byte-identical
    # acquire (await sem.acquire() in _mtproto_call_with_retry), same
    # justification.
    # v99.08 (documented correction): 5438 -> 5455 — the Patch-9
    # rotation-window helpers (_v9908_cluster_identity /
    # _v9908_rotation_scope_conflict, +17 lines) inserted above the
    # anchor shifted the finding; byte-identical acquire
    # (await sem.acquire() in _mtproto_call_with_retry), same
    # justification.
    "mtproto.py:5455":
        "EXPLICITLY JUSTIFIED (§17/§18): finally-release discipline + "
        "per-RPC timeouts bound the wait; semaphore capacity is the "
        "intended backpressure",
    # handlers.py — BUN auto-installer download drain loop. Bounded
    # by urlopen(timeout=30) socket timeout per read + finite stream;
    # install-time-only path (grep-audited NOT reachable from VC/event-
    # loop paths in v98.07 FIX-SS sync-hazard sweep).
    # v98.09-P3 (documented correction): line 2560 → 2583 — the §9/§19
    # manual-discovery prefetch edits above it added 23 lines; the finding
    # is byte-identical (same while-loop, same justification).
    # v99.02 (documented correction): 2583 -> 2755 — the FIX-6 heartbeat
    # ERROR-visibility + FIX-3 FD census/guard blocks (+172 lines above
    # the anchor) shifted the finding; byte-identical (same while-loop,
    # same justification).
    # v99.03 (documented correction): 2755 -> 2788 — the RC-10/RC-12
    # heartbeat ACCOUNT_HEALTH + suppression-flush block (+33 lines above
    # the anchor) shifted the finding; byte-identical (same while-loop,
    # same justification).
    # v99.07 (documented correction): 2788 -> 2799 — the FIX-12
    # worker-heartbeat block at _bot_heartbeat_loop (+11 lines above the
    # anchor) shifted the finding; byte-identical (same while-loop, same
    # justification).
    # v99.08 (documented correction): 2799 -> 2816 — the item-3
    # bot_history_loop heartbeat block (+17 lines above the anchor)
    # shifted the finding; byte-identical (same while-loop, same
    # justification).
    # v99.10 (documented correction): 2816 -> 2843 — the FIX-D MEM_CENSUS
    # heartbeat block (+27 lines above the anchor) shifted the finding;
    # byte-identical (same while-loop, same justification).
    # v99.11 (documented correction): 2843 -> 3023 — the P0-1 heartbeat
    # rewrite (single-%s safe emission + resource head fields + guarded
    # counters, +180 lines above the anchor) shifted the finding;
    # byte-identical (same while-loop, same justification).
    # v99.11.1 (documented correction): 3023 -> 3055 — the FIX-1
    # heartbeat drift-detection + leak-sweep block (+32 lines above the
    # anchor) shifted the finding; byte-identical (same while-loop,
    # same justification).
    "handlers.py:3055":
        "EXPLICITLY JUSTIFIED (§4): bounded download drain — 30s socket "
        "timeout per read + finite stream; install-time-only path, "
        "grep-audited non-VC (v98.07 FIX-SS sweep)",
}


def _walk_loop_progress(node: ast.While) -> Dict[str, Any]:
    """Analyze one while loop: which names the condition reads, which
    names the body assigns unconditionally vs conditionally, whether
    awaits exist, and whether the body DRAINS the condition's
    collection (pop/popitem/popleft/get_nowait — mutation-based
    monotonic progress, the standard bounded-drain pattern)."""
    cond_names = {
        n.id for n in ast.walk(node.test) if isinstance(n, ast.Name)}
    cond_calls = {
        n.func.attr for n in ast.walk(node.test)
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)}
    cond_call_targets = set()
    for n in ast.walk(node.test):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) \
                and isinstance(n.func.value, ast.Name):
            cond_call_targets.add((n.func.value.id, n.func.attr))
    assigned_unconditional: set = set()
    assigned_conditional: set = set()
    awaits = 0
    drains = False
    for sub in ast.walk(node):
        if sub is node.test:
            continue
        if isinstance(sub, ast.Await):
            awaits += 1
        if isinstance(sub, (ast.Assign, ast.AugAssign, ast.AnnAssign)):
            targets = []
            if isinstance(sub, ast.Assign):
                targets = sub.targets
            else:
                targets = [sub.target]
            for t in targets:
                if isinstance(t, ast.Name):
                    if _directly_in_body(node, sub):
                        assigned_unconditional.add(t.id)
                    else:
                        assigned_conditional.add(t.id)
        # Drain pattern: the body calls <cond-target>.pop/popleft/
        # popitem/get_nowait/remove — the condition collection shrinks
        # monotonically each iteration (or an empty-exception breaks).
        if isinstance(sub, ast.Call) and isinstance(sub.func, ast.Attribute) \
                and isinstance(sub.func.value, ast.Name) \
                and sub.func.attr in ("pop", "popleft", "popitem",
                                      "get_nowait", "remove", "discard",
                                      "clear"):
            for name, attr in cond_call_targets:
                if sub.func.value.id == name:
                    drains = True
    # 'while <name>:' truthiness drain — body pops from <name>.
    for sub in ast.walk(node):
        if sub is node.test:
            continue
        if isinstance(sub, ast.Call) and isinstance(sub.func, ast.Attribute) \
                and isinstance(sub.func.value, ast.Name) \
                and sub.func.attr in ("pop", "popitem", "popleft",
                                      "clear"):
            if sub.func.value.id in cond_names:
                drains = True
    return {
        "cond_names": sorted(cond_names),
        "unconditional": sorted(assigned_unconditional & cond_names),
        "conditional": sorted(assigned_conditional & cond_names),
        "awaits": awaits,
        "drains": drains,
    }


def _directly_in_body(root: ast.While, target: ast.AST) -> bool:
    """True if the assignment sits in the loop body itself (or the
    loop's orelse) rather than nested inside an if/try — the honest
    one-level approximation of 'unconditional advance'."""
    for child in list(root.body) + list(root.orelse):
        if child is target:
            return True
        for sub in ast.walk(child):
            if sub is target:
                if isinstance(child, (ast.If, ast.Try, ast.With)):
                    return False
                return True
    return False


def _func_context(tree: ast.Module, lineno: int) -> Optional[ast.AST]:
    """The innermost function containing *lineno* (None = module level)."""
    best = None
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) \
                and node.lineno <= lineno <= (node.end_lineno or node.lineno):
            if best is None or node.lineno >= best.lineno:
                best = node
    return best


def _is_in_daemon_thread_body(tree: ast.Module, lineno: int) -> bool:
    """True if the innermost function containing *lineno* is a
    canary/watchdog thread body (sync loops there are BY DESIGN: the
    canary must survive event-loop death — v98.07 FIX-SS)."""
    fn = _func_context(tree, lineno)
    return bool(fn and isinstance(fn, ast.FunctionDef) and (
        "canary" in fn.name or "watchdog" in fn.name
        or "thread_body" in fn.name))


# ---------------------------------------------------------------------------
# Module scan
# ---------------------------------------------------------------------------

def scan_module(path: str) -> Dict[str, Any]:
    src = open(path, encoding="utf-8").read()
    tree = ast.parse(src)
    module_name = os.path.basename(path)
    findings: List[Dict[str, Any]] = []
    stats = {"while_loops": 0, "async_functions": 0,
             "create_task": 0, "create_task_unnamed": 0,
             "broad_except_pass": 0}

    async_lines = []
    for node in ast.walk(tree):
        if isinstance(node, ast.AsyncFunctionDef):
            stats["async_functions"] += 1
            async_lines.append(
                (node.lineno, node.end_lineno or node.lineno))

    def _in_async(lineno: int) -> bool:
        return any(a <= lineno <= b for a, b in async_lines)

    # --- 1. while loops ---------------------------------------------------
    for node in ast.walk(tree):
        if not isinstance(node, ast.While):
            continue
        stats["while_loops"] += 1
        info = _walk_loop_progress(node)
        seg = ast.get_source_segment(src, node) or ""
        # v98.08 FIX-CCC defect signature: capacity check gating cursor.
        fixccc = ("< max_q" in seg or "<max_q" in seg) and "+= 1" in seg
        if fixccc:
            # The detector FIRED: the defective loop is PRESENT in the
            # scanned source (whatever that source is) — this is an
            # UNRESOLVED critical finding, exit code 1. Historical note:
            # v98.09 removed the loop (selection is the bounded helper
            # _vc_discovery_select_queries_bounded), so this detector
            # firing on a v98.09 shipped module would itself be a
            # regression; firing on a v98.08-era source proves the
            # checker catches the 2026-09-01 freeze class.
            findings.append({
                "line": node.lineno, "severity": "CRITICAL",
                "kind": "SYNC-CONDITIONAL-ADVANCE",
                "detail": "v98.08 FIX-CCC defect signature: a capacity "
                          "check gates the cursor advance — the exact "
                          "class that froze pids 10077/25848 (the loop "
                          "is PRESENT in this source: unresolved)",
                "classification": "NEEDS-REVIEW",
            })
            continue
        if info["awaits"] > 0:
            findings.append({
                "line": node.lineno, "severity": "SAFE",
                "kind": "ASYNC-AWAIT",
                "detail": f"loop contains {info['awaits']} await point(s) "
                          f"— event loop can run",
                "classification": "SAFE",
            })
            continue
        # Sync loop — classify progress.
        if info["drains"]:
            findings.append({
                "line": node.lineno, "severity": "SAFE",
                "kind": "SYNC-DRAIN",
                "detail": "condition collection drained monotonically "
                          "(pop/popitem/get_nowait family) — standard "
                          "bounded-drain pattern",
                "classification": "SAFE",
            })
        elif info["unconditional"]:
            findings.append({
                "line": node.lineno, "severity": "SAFE",
                "kind": "SYNC-ADVANCE",
                "detail": f"unconditional advance of "
                          f"{info['unconditional']} — monotonic progress",
                "classification": "SAFE",
            })
        elif _is_in_daemon_thread_body(tree, node.lineno):
            findings.append({
                "line": node.lineno, "severity": "INFO",
                "kind": "DAEMON-THREAD",
                "detail": "sync loop inside a canary/watchdog thread "
                          "body — immune-to-loop-death BY DESIGN",
                "classification": "EXPLICITLY JUSTIFIED (v98.07 "
                                  "FIX-SS canary design)",
            })
        else:
            detail = "no condition variable advanced in the body" \
                if not info["conditional"] else \
                f"advance of {info['conditional']} conditionally gated"
            key = f"{module_name}:{node.lineno}"
            classification = JUSTIFICATIONS.get(key, "NEEDS-REVIEW")
            findings.append({
                "line": node.lineno, "severity": "HIGH",
                "kind": "SYNC-CONDITIONAL-ADVANCE",
                "detail": f"{detail} — review for the v98.08 stall "
                          f"class (context: "
                          f"{'async' if _in_async(node.lineno) else 'sync'})",
                "classification": classification,
            })

    # --- 2/3. blocking calls in async functions ---------------------------
    src_lines = src.splitlines()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not _in_async(node.lineno):
            continue
        func_name = ""
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr
        seg_line = src_lines[node.lineno - 1].strip() \
            if node.lineno <= len(src_lines) else ""
        if func_name == "sleep" and "time.sleep" in seg_line:
            findings.append({
                "line": node.lineno, "severity": "CRITICAL",
                "kind": "TIME-SLEEP-IN-ASYNC",
                "detail": f"{seg_line[:100]} — blocks the event loop",
                "classification": "NEEDS-REVIEW",
            })
        elif func_name in ("run", "call", "check_call", "check_output",
                           "Popen") and "subprocess" in seg_line:
            findings.append({
                "line": node.lineno, "severity": "HIGH",
                "kind": "SUBPROCESS-IN-ASYNC",
                "detail": f"{seg_line[:100]} — sync subprocess in async",
                "classification": "NEEDS-REVIEW",
            })

    # --- 4. create_task without name in async contexts --------------------
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) \
                and node.func.attr in ("create_task", "ensure_future"):
            stats["create_task"] += 1
            has_name = any(kw.arg == "name" for kw in node.keywords)
            if not has_name and _in_async(node.lineno):
                stats["create_task_unnamed"] += 1
                findings.append({
                    "line": node.lineno, "severity": "MEDIUM",
                    "kind": "CREATE-TASK-UNNAMED",
                    "detail": "asyncio task created without name= in an "
                              "async context (ownership harder to trace; "
                              "§20)",
                    "classification": "NEEDS-REVIEW",
                })

    # --- 5. lock acquire without timeout in async -------------------------
    for node in ast.walk(tree):
        if isinstance(node, ast.Await) and isinstance(node.value, ast.Call) \
                and isinstance(node.value.func, ast.Attribute) \
                and node.value.func.attr in ("acquire", "acquire_read",
                                              "acquire_write"):
            has_timeout = any(kw.arg == "timeout"
                              for kw in node.value.keywords)
            if not has_timeout:
                key = f"{module_name}:{node.lineno}"
                classification = JUSTIFICATIONS.get(
                    key, "NEEDS-REVIEW")
                findings.append({
                    "line": node.lineno, "severity": "HIGH",
                    "kind": "LOCK-ACQUIRE-NO-TIMEOUT",
                    "detail": "await lock.acquire() without timeout in "
                              "async context (§17 — v98.08 FIX-WW bounded "
                              "all RW acquisitions)",
                    "classification": classification,
                })

    # --- 6. broad exception swallow count ----------------------------------
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler) and node.type is not None:
            if "Exception" in ast.dump(node.type) and len(node.body) == 1 \
                    and isinstance(node.body[0], ast.Pass):
                stats["broad_except_pass"] += 1

    return {
        "module": os.path.basename(path),
        "path": path,
        "stats": stats,
        "findings": findings,
    }


def aggregate(modules: List[Dict[str, Any]]) -> Dict[str, Any]:
    all_findings = [f for m in modules for f in m["findings"]]
    critical = [f for f in all_findings if f["severity"] == "CRITICAL"]
    high = [f for f in all_findings if f["severity"] == "HIGH"]
    unresolved = [f for f in critical + high
                  if f["classification"] == "NEEDS-REVIEW"]
    return {
        "modules_scanned": len(modules),
        "total_findings": len(all_findings),
        "critical": len(critical),
        "high": len(high),
        "unresolved_critical_high": len(unresolved),
        "unresolved": unresolved,
    }


def render_report(modules: List[Dict[str, Any]], summary: Dict[str, Any]) -> str:
    lines = [
        "VC STATIC ARCHITECTURE AUDIT — v98.09 (§39)",
        "=" * 72,
        f"modules scanned: {summary['modules_scanned']}",
        f"total findings:  {summary['total_findings']}",
        f"critical:        {summary['critical']}",
        f"high:            {summary['high']}",
        f"UNRESOLVED critical/high: {summary['unresolved_critical_high']}"
        "  (must be 0 to ship)",
        "",
    ]
    for m in modules:
        lines.append(
            f"--- {m['module']} "
            f"(while={m['stats']['while_loops']}, "
            f"async_fns={m['stats']['async_functions']}, "
            f"create_task={m['stats']['create_task']} "
            f"[unnamed={m['stats']['create_task_unnamed']}], "
            f"broad_except_pass={m['stats']['broad_except_pass']})")
        for f in m["findings"]:
            if f["severity"] == "SAFE":
                continue
            lines.append(
                f"  L{f['line']:>6} [{f['severity']:<8}] {f['kind']}: "
                f"{f['classification']}")
            lines.append(f"          {f['detail'][:110]}")
        lines.append("")
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None,
                    help="package dir containing the modules")
    ap.add_argument("--file", default=None,
                    help="single-file mode (e.g. the historical v98.08 "
                         "voicechat.py — proves the checker catches the "
                         "FIX-CCC defect class)")
    ap.add_argument("--json", default=None, help="write JSON report")
    args = ap.parse_args(argv)

    if args.file:
        modules = [scan_module(args.file)]
    else:
        root = args.root or os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "mediagrab_bot")
        modules = []
        for name in DEFAULT_MODULES:
            p = os.path.join(root, name)
            if os.path.isfile(p):
                modules.append(scan_module(p))

    summary = aggregate(modules)
    report = render_report(modules, summary)
    print(report)
    if args.json:
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump({"summary": summary, "modules": modules},
                      fh, indent=2)
        print(f"JSON report written: {args.json}")
    return 1 if summary["unresolved_critical_high"] else 0


if __name__ == "__main__":
    sys.exit(main())
