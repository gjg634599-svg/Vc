#!/usr/bin/env python3
"""vc_inventory.py — v98.09 §0 PRESERVATION CONTRACT inventory generator.

Extracts EVERY VC/discovery control from mediagrab_bot/config.py (field
name, env var, default) plus the observability marker contract, and
emits a machine-readable JSON inventory + a human-readable table.

The inventory is the §0 preservation contract: v98.09 must continue
accepting/behaving-for every entry. The test layer
(tests/test_v98_09_architecture.py::TestPreservationInventory) asserts
the shipped inventory matches the live sources (drift = failure).
"""

from __future__ import annotations

import ast
import json
import os
import re
import sys
from typing import Any, Dict, List

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


def extract_config_inventory(config_path: str) -> List[Dict[str, Any]]:
    src = open(config_path, encoding="utf-8").read()
    tree = ast.parse(src)
    out: List[Dict[str, Any]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        for stmt in node.body:
            ann = None
            env = None
            default = None
            if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name):
                ann = stmt.target.id
                if isinstance(stmt.value, ast.Call):
                    fn = stmt.value.func
                    fname = fn.attr if isinstance(fn, ast.Attribute) else (
                        fn.id if isinstance(fn, ast.Name) else "")
                    if fname.startswith("_env"):
                        if stmt.value.args:
                            first = stmt.value.args[0]
                            if isinstance(first, ast.Constant):
                                env = str(first.value)
                        if len(stmt.value.args) >= 2:
                            d = stmt.value.args[1]
                            if isinstance(d, ast.Constant):
                                default = d.value
            if ann is None:
                continue
            # VC/discovery/canary/rotation/relevant subsystem filters.
            keep = (
                ann.startswith("vc_") or ann.startswith("vc_arch_")
                or "voice" in ann or "talkative" in ann
                or ann.startswith("userbot") or ann.startswith("cluster")
                or ann in ("log_path", "project_root", "data_dir",
                           "bot_token", "admin_ids")
            )
            if keep:
                out.append({
                    "option": ann,
                    "env": env or "",
                    "default": default,
                    "line": stmt.lineno,
                    "v98_09_new": ann.startswith("vc_arch_"),
                })
    return out


def extract_markers(sources: List[str]) -> Dict[str, List[str]]:
    """Extract every stable log marker (ALL_CAPS with _ and a literal
    format string) from the given source files."""
    markers: Dict[str, List[str]] = {}
    pattern = re.compile(r'"([A-Z][A-Z0-9_]{6,})[ =]')
    for path in sources:
        name = os.path.basename(path)
        try:
            src = open(path, encoding="utf-8").read()
        except OSError:
            continue
        found = sorted(set(pattern.findall(src)))
        markers[name] = found
    return markers


def main() -> int:
    config_path = os.path.join(ROOT, "mediagrab_bot", "config.py")
    inv = extract_config_inventory(config_path)
    marker_sources = [
        os.path.join(ROOT, "mediagrab_bot", f)
        for f in ("voicechat.py", "bootstrap.py", "mtproto.py",
                  "vc_architecture.py", "handlers.py")
    ]
    markers = extract_markers(marker_sources)
    # Contract filter: vc_architecture markers unconditionally + the
    # preserved stable markers from the runtime modules. handlers.py is
    # included: BOT_HEARTBEAT (the v98.05 FIX-FF 60s liveness marker) is
    # emitted there, not in bootstrap (bootstrap documents it; handlers
    # logs it). Excluding handlers would understate the preserved
    # observability contract.
    contract_markers = sorted(
        set(markers.get("vc_architecture.py", []))
        | {m for f in ("voicechat.py", "bootstrap.py", "mtproto.py",
                       "handlers.py")
           for m in markers.get(f, [])
           if m.startswith(("VC_", "BOT_", "CLIENT_", "AUTO_", "TASK_",
                            "STARTUP_"))})
    doc = {
        "version": "v98.09",
        "generated_from": "mediagrab_bot/config.py + module sources",
        "preservation_contract": {
            "vc_options": len(inv),
            "new_v98_09_options": sum(1 for i in inv if i["v98_09_new"]),
            "options": inv,
        },
        "observability_contract": {
            "stable_markers": contract_markers,
            "marker_count": len(contract_markers),
        },
    }
    out_path = os.path.join(ROOT, "docs", "VC_CONTROL_INVENTORY_v98.09.json")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=2)
    print(f"inventory: {len(inv)} VC options "
          f"({doc['preservation_contract']['new_v98_09_options']} new v98.09 "
          f"budgets, {len(inv) - doc['preservation_contract']['new_v98_09_options']}"
          f" preserved from v98.08)")
    print(f"markers:   {len(contract_markers)} stable markers")
    print(f"written:  {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
