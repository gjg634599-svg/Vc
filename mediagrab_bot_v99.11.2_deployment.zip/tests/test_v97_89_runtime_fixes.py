"""
v97.89 — CONSTRUCTION RACE FIX: PRE-WRAP client.add_event_handler BEFORE PyTgCalls construction.

ROOT CAUSE (SOURCE-PROVEN + RUNTIME-PROVEN from note 57):
  PyTgCalls.__init__ registers a Raw() handler on the Telethon client at
  CONSTRUCTION TIME (PyTgCalls(client) at voicechat.py:2688). The v97.80
  filter was applied AFTER construction (line 2700) — but between construction
  and the filter call, the UNFILTERED Raw() handler received EVERY MTProto
  update. This caused:
  - 899 dispatch_update tasks (note 57)
  - 59 PyTgCalls handle_mtproto_updates tasks
  - 933 total tasks
  - 13.15s event-loop starvation
  - MTProto keepalive timeout → MTProto disconnect → VC physically left

  Additionally, when vc_reset_backend() created a NEW PyTgCalls(client) on the
  SAME client, the v97.87 filter (idempotency guard removed) would re-scan, but
  the CONSTRUCTION RACE still existed: between PyTgCalls(client) construction
  and _wrap_pytgcalls_update_filter(), the unfiltered handler was live.

FIX: PRE-WRAP client.add_event_handler BEFORE PyTgCalls construction. The
pre-wrap monkey-patches add_event_handler to intercept Raw() registrations
and replace the callback with a filtered version AT REGISTRATION TIME. This
eliminates the race window entirely — no unfiltered handler can ever exist.

The pre-wrap is applied:
  1. BEFORE PyTgCalls(client) construction (line 2701)
  2. Safety net: _wrap_pytgcalls_update_filter() after construction (line 2706)
  3. Safety net: _wrap_pytgcalls_update_filter() after start() (line 2713)

All three are safe to call multiple times (idempotent via _PREWRAPPED_CLIENTS
set and _filtered_update_handler name check).
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


class TestPreWrapFix(unittest.TestCase):
    """v97.89: pre-wrap eliminates the construction race."""

    def test_prewrite_function_exists(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("def _prewrap_client_event_handlers(", src)

    def test_prewrite_called_before_construction(self):
        """The pre-wrap must be called BEFORE PyTgCalls(client)."""
        with open(_VOICECHAT) as f:
            src = f.read()
        prewrap_idx = src.find("_prewrap_client_event_handlers(self._mtproto)")
        self.assertGreater(prewrap_idx, 0, "prewrap call not found")
        construct_idx = src.find("self._pytgcalls = _PyTgCalls_cls(self._mtproto)", prewrap_idx)
        self.assertGreater(construct_idx, 0, "PyTgCalls construction not found after prewrap")
        self.assertLess(prewrap_idx, construct_idx,
                        "pre-wrap MUST be called before PyTgCalls construction")

    def test_prewrite_intercepts_raw_handlers(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _filtered_add_event_handler")
        body = src[idx:idx + 1200]  # v97.89: need larger window
        self.assertIn("isinstance(event, _tl_events.Raw)", body)
        self.assertIn("UpdateGroupCall", body)
        self.assertIn("UpdateChannel", body)

    def test_post_construction_filter_still_called(self):
        """Safety net: _wrap_pytgcalls_update_filter still called after construction."""
        with open(_VOICECHAT) as f:
            src = f.read()
        construct_idx = src.find("self._pytgcalls = _PyTgCalls_cls(self._mtproto)")
        # Find the next _wrap_pytgcalls_update_filter call after construction
        filter_idx = src.find("_wrap_pytgcalls_update_filter(self._mtproto)", construct_idx)
        self.assertGreater(filter_idx, 0, "post-construction filter must exist")

    def test_filter_after_start_still_called(self):
        """Safety net: filter also called after start()."""
        with open(_VOICECHAT) as f:
            src = f.read()
        start_idx = src.find("await self._pytgcalls.start()")
        filter_idx = src.find("_wrap_pytgcalls_update_filter(self._mtproto)", start_idx)
        self.assertGreater(filter_idx, 0, "post-start filter must exist")

    def test_prewrite_idempotent(self):
        """Pre-wrap skips already-wrapped clients."""
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _prewrap_client_event_handlers")
        body = src[idx:idx + 2500]  # docstring is very long
        self.assertIn("if client_id in _PREWRAPPED_CLIENTS", body)


class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_92(self):
        with open(_INIT) as f:
            src = f.read()
        self.assertIn('__bot_version__ = "v99.11.2"', src)


class TestPreservedFixes(unittest.TestCase):
    """Verify all prior fixes preserved."""

    def test_filter_no_idempotency_guard(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _wrap_pytgcalls_update_filter")
        body = src[idx:idx + 800]
        self.assertNotIn("if client_id in _PYTGCALLS_WRAPPED_CLIENTS", body)

    def test_already_filtered_check(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn('_cb_name == "_filtered_update_handler"', src)

    def test_backend_preservation(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_BACKEND_PRESERVED", src)

    def test_stale_joined_record(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_STALE_JOINED_RECORD", src)

    def test_is_open_property(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("VC_TRACKING_SNAPSHOT")
        block = src[idx:idx + 1200]
        self.assertIn("_vc_join_all_breaker.is_open ", block)

    def test_floodwait_defer(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_TARGET_FLOODWAIT_DEFERRED", src)

    def test_leave_block(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_LEAVE_BLOCKED_DURING_JOIN_ALL", src)

    def test_diagnostic_boot(self):
        utils = os.path.join(_BASE, "mediagrab_bot", "utils_real.py")
        with open(utils) as f:
            src = f.read()
        self.assertIn("DIAGNOSTIC_BOOT", src)

    def test_deployment_identity(self):
        bootstrap = os.path.join(_BASE, "mediagrab_bot", "bootstrap.py")
        with open(bootstrap) as f:
            src = f.read()
        self.assertIn("DEPLOYMENT_IDENTITY", src)

    def test_forced_cancel(self):
        mtproto = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
        with open(mtproto) as f:
            src = f.read()
        self.assertIn("_mediagrab_bg_tasks", src)


class TestConstructionRaceBehavioral(unittest.TestCase):
    """Test that the pre-wrap eliminates the construction race."""

    def test_prewrite_called_before_construction(self):
        """The pre-wrap is called BEFORE PyTgCalls(client) construction."""
        with open(_VOICECHAT) as f:
            src = f.read()
        # Find the FIRST occurrence of _prewrap (in the backend.start() path)
        prewrap_idx = src.find("_prewrap_client_event_handlers(self._mtproto)")
        self.assertGreater(prewrap_idx, 0, "prewrap call not found")
        # Find the FIRST occurrence of PyTgCalls construction AFTER the prewrap
        construct_idx = src.find("_PyTgCalls_cls(self._mtproto)", prewrap_idx)
        self.assertGreater(construct_idx, 0, "PyTgCalls construction not found after prewrap")
        self.assertLess(prewrap_idx, construct_idx, "prewrap must be before construction")

    def test_no_unfiltered_handler_can_exist(self):
        """After pre-wrap, any Raw() registration is automatically filtered."""
        # The pre-wrap replaces client.add_event_handler with a version that
        # intercepts Raw() registrations and wraps the callback.
        # So even if PyTgCalls.__init__ registers a Raw() handler, it's
        # filtered AT REGISTRATION TIME.
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _filtered_add_event_handler")
        self.assertGreater(idx, 0)
        body = src[idx:idx + 2000]
        self.assertIn("_is_raw", body)
        self.assertIn("_filtered_cb", body)
        self.assertIn("original_add(_filtered_cb, event)", body)


if __name__ == "__main__":
    unittest.main()
