"""v98.10 — Entity-resolution hardening regression suite.

Layers:
  * Driver layer — runs tests/_v9810_entity_driver.py in a subprocess
    (REAL mtproto.py + fake Telethon world; the SAME pattern as the
    v98.09-P2 leave driver / v98.09-P3 fastpath driver).  10 behavioral
    cases: entity-type correctness (§26), the exact production failure
    pattern + convergence (§38/§5), convergence across restart (§12),
    negative-cache TTLs (§27), scoped hash ownership (§28),
    single-flight fan-out + per-entity keys (§41/§43), representation
    errors never rotate (§8), per-entity rotation routing (§25),
    RPC accounting + redaction (§21/§22/§44), discovery-cache reuse +
    TTL refresh (§29).
  * Auto-discovery pause (§30) — behavioral: the event-driven wait
    wakes EXACTLY once when Join-All finishes (no 5s busy-poll), the
    lifecycle event never disagrees with the running flag, and the
    legacy 3-line poll is gone from the loop source.
  * Source contracts — the v98.10 markers exist in mtproto.py; the
    step-6 channel probe is typed (never a raw positive int); config
    options exist with safe clamps.
"""
from __future__ import annotations

import ast
import asyncio
import os
import re
import subprocess
import sys
import time
import types
import unittest

_TESTS = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_TESTS)
_MTPROTO = os.path.join(_ROOT, "mediagrab_bot", "mtproto.py")
_VOICECHAT = os.path.join(_ROOT, "mediagrab_bot", "voicechat.py")
_CONFIG = os.path.join(_ROOT, "mediagrab_bot", "config.py")


def _read(path: str) -> str:
    with open(path, encoding="utf-8") as fh:
        return fh.read()


# =============================================================================
# Layer 1 — behavioral driver (subprocess, REAL module)
# =============================================================================

class TestV9810EntityDriver(unittest.TestCase):
    """Runs the REAL-mtproto driver; exit code = failed cases."""

    def test_driver_all_cases_pass(self):
        proc = subprocess.run(
            [sys.executable, os.path.join(_TESTS, "_v9810_entity_driver.py")],
            capture_output=True, text=True, timeout=180,
            cwd=_ROOT)
        tail = "\n".join(
            (proc.stdout + proc.stderr).strip().splitlines()[-12:])
        self.assertEqual(
            proc.returncode, 0,
            f"driver failed (exit {proc.returncode}):\n{tail}")
        self.assertIn("10/10 cases pass", proc.stdout)

    def test_driver_case_ids_present(self):
        proc = subprocess.run(
            [sys.executable, os.path.join(_TESTS, "_v9810_entity_driver.py")],
            capture_output=True, text=True, timeout=180, cwd=_ROOT)
        for cid in ("C1_", "C2_", "C3_", "C4_", "C5_", "C6_", "C7_",
                    "C8_", "C9_", "C10_"):
            self.assertIn(f"CASE {cid}", proc.stdout, cid)


# =============================================================================
# Layer 2 — auto-discovery pause (§30, behavioral)
# =============================================================================

def _exec_evt_helpers(ns: dict) -> None:
    """Exec the REAL v98.10 event helpers + the flag from voicechat.py."""
    src = _read(_VOICECHAT)

    def _seg(name: str) -> str:
        tree = ast.parse(src)
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) \
                    and node.name == name:
                return ast.get_source_segment(src, node)
        raise AssertionError(f"{name} not found")

    segs = "\n\n".join(_seg(n) for n in (
        "_vc_join_all_done_evt", "_vc_join_all_evt_set_running"))
    # the helpers reference the module globals — provide them
    ns["_VC_JOIN_ALL_DONE_EVT"] = None
    ns["asyncio"] = asyncio
    exec(compile(segs, "<v9810_evt>", "exec"), ns)


class TestAutoDiscoveryPause(unittest.TestCase):
    """§16/§30: event-driven pause — wake EXACTLY once, no busy-poll."""

    def test_event_lifecycle_follows_flag(self):
        ns: dict = {}
        _exec_evt_helpers(ns)
        evt = ns["_vc_join_all_done_evt"]()
        self.assertTrue(evt.is_set(), "resting state = NOT running (set)")
        ns["_vc_join_all_evt_set_running"](True)
        self.assertFalse(evt.is_set(), "running → cleared")
        ns["_vc_join_all_evt_set_running"](True)   # idempotent
        self.assertFalse(evt.is_set())
        ns["_vc_join_all_evt_set_running"](False)
        self.assertTrue(evt.is_set(), "finished → set (waiters wake)")

    def test_pause_wait_wakes_exactly_once_and_promptly(self):
        """The §16 wait pattern: a waiter blocked on the done-event wakes
        PROMPTLY (< 0.2s) when Join-All finishes — the legacy 5s poll
        would still be INSIDE its sleep.  Modeled on the production
        branch (event wait + stop wait, FIRST_COMPLETED)."""
        ns: dict = {}
        _exec_evt_helpers(ns)
        evt = ns["_vc_join_all_done_evt"]()
        evt.clear()  # Join-All running
        stop = asyncio.Event()
        wakes: list[float] = []

        async def _waiter():
            tasks = [
                asyncio.ensure_future(evt.wait()),
                asyncio.ensure_future(stop.wait()),
            ]
            try:
                await asyncio.wait(tasks, timeout=60.0,
                                   return_when=asyncio.FIRST_COMPLETED)
            finally:
                for t in tasks:
                    if not t.done():
                        t.cancel()
                await asyncio.gather(*tasks, return_exceptions=True)
            wakes.append(time.monotonic())

        async def _main():
            w = asyncio.ensure_future(_waiter())
            await asyncio.sleep(0.05)      # waiter parks on the event
            self.assertFalse(w.done())     # still waiting while running
            t0 = time.monotonic()
            evt.set()                      # Join-All worker finishes
            await w
            return time.monotonic() - t0

        dt = asyncio.run(_main())
        self.assertEqual(len(wakes), 1, "woke exactly once")
        self.assertLess(dt, 0.2, f"event wait must wake promptly: {dt:.3f}s")

    def test_legacy_poll_is_gone_and_event_wait_present(self):
        src = _read(_VOICECHAT)
        i = src.find('if _vc_join_all_running:')
        while i != -1:
            win = src[i:i + 2600]
            if "waiting_join_all" in win:
                # the auto-discovery pause branch
                self.assertIn("_vc_join_all_done_evt()", win,
                              "pause branch must use the lifecycle event")
                self.assertIn("asyncio.wait(", win,
                              "pause branch must wait on events (not poll)")
                self.assertIn("timeout=60.0", win,
                              "bounded safety re-check present")
                # the legacy 3-line poll pattern must NOT appear: the
                # debug line followed DIRECTLY by sleep(5)+continue
                legacy = re.search(
                    r'logger\.debug\("AUTO_DISCOVERY pausing[^\n]*"\)\s*'
                    r'await asyncio\.sleep\(5\)\s*\n\s*continue',
                    win)
                self.assertIsNone(
                    legacy, "legacy 5s busy-poll must be replaced (§16)")
                return
            i = src.find('if _vc_join_all_running:', i + 10)
        self.fail("auto-discovery pause branch not found")

    def test_event_published_at_every_flag_assignment(self):
        """The event can never disagree with _vc_join_all_running: every
        assignment site is adjacent to a publish call."""
        src = _read(_VOICECHAT)
        lines = src.split("\n")
        misses: list[int] = []
        for idx, ln in enumerate(lines):
            if ln.strip().startswith("_vc_join_all_running = "):
                window = "\n".join(lines[idx:idx + 4])
                if "_vc_join_all_evt_set_running" not in window:
                    misses.append(idx + 1)
        self.assertEqual(
            misses, [],
            f"flag assignments without event publish at lines {misses}")


# =============================================================================
# Layer 3 — source contracts (mtproto/config)
# =============================================================================

class TestV9810SourceContracts(unittest.TestCase):

    def test_step6_channel_probe_is_typed(self):
        """§5/§6: GetFullChannelRequest never receives a raw positive
        int (the PeerUser representation error)."""
        src = _read(_MTPROTO)
        tree = ast.parse(src)
        for node in ast.walk(tree):
            if (isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Name)
                    and node.func.id == "GetFullChannelRequest"):
                for a in node.args:
                    self.assertFalse(
                        isinstance(a, ast.Name) and a.id == "raw_id",
                        "raw int var passed to GetFullChannelRequest")
                    self.assertFalse(
                        isinstance(a, ast.BinOp) or isinstance(a, ast.Constant),
                        "raw int expression passed to GetFullChannelRequest")

    def test_resolver_has_v9810_machinery(self):
        src = _read(_MTPROTO)
        for marker in (
                "def _vc_entity_identity(",
                "def _vc_resolution_outcome(",
                "def _v9810_scope_route(",
                "def _v9810_hash_invalid_record(",
                "def _v9810_access_remember(",
                "def _v9810_seed_access_state_from_persistence(",
                "ENTITY_RESOLVE_RPC_COUNT",
                "ENTITY_RESOLVE_SINGLEFLIGHT_JOIN",
                "ENTITY_RESOLVE_HASH_INVALID",
                "ENTITY_RESOLVE_ACCOUNT_SWITCH",
                "ENTITY_RESOLVE_REPRESENTATION_ERROR",
                "ENTITY_RESOLVE_NEGATIVE_CACHE_HIT",
                "ENTITY_RESOLVE_TYPE_KNOWN",
        ):
            self.assertIn(marker, src, marker)

    def test_resolve_across_accounts_persists_marked_key_and_scope(self):
        """§12: the rotation success feeds the scoped access state AND
        writes the marked flat-cache key (the lookup key)."""
        src = _read(_MTPROTO)
        i = src.find("async def resolve_across_accounts(")
        self.assertGreater(i, -1)
        # v98.11 (documented window correction): 6000 -> 16000 - the
        # v98.11 typed fast-recovery probe block sits between the head
        # and the ladder-success section; asserted markers unchanged.
        win = src[i:i + 16000]
        self.assertIn("_v9810_access_remember(", win)
        self.assertIn('_vc_entity_cache[_marked_rot]', win)
        self.assertIn('"scope": _vc_client_scope(client)', win)

    def test_config_v9810_options_and_clamps(self):
        src = _read(_CONFIG)
        for opt in ("vc_entity_scope_state_ttl",
                    "vc_entity_hash_invalid_ttl",
                    "vc_entity_scope_state_max_entries"):
            self.assertIn(f"{opt}: int = _env_int(", src, opt)
        for clamp in ('_clamp_int("vc_entity_scope_state_ttl"',
                      '_clamp_int("vc_entity_hash_invalid_ttl"',
                      '_clamp_int("vc_entity_scope_state_max_entries"'):
            self.assertIn(clamp, src, clamp)

    def test_negative_cache_still_tll_bounded_in_voicechat(self):
        """v98.08 FIX-ZZ semantics preserved (backoff only, never an
        exclusion) — the v98.10 layer must not weaken them."""
        vsrc = _read(_VOICECHAT)
        self.assertIn("NEVER an exclusion", vsrc)
        self.assertIn("_VC_NEG_BACKOFF_STEPS", vsrc)
        self.assertIn("_vc_entity_negative_wipe", vsrc)

    def test_floodwait_rotation_preserved(self):
        """§3/§40: FloodWait during rotation still marks the account
        cooling down (ERR-E-002 semantics unchanged)."""
        src = _read(_MTPROTO)
        i = src.find("async def resolve_across_accounts(")
        # v98.11 (documented window correction): 6000 -> 16000 (same
        # reason as the marked-key test above).
        win = src[i:i + 16000]
        self.assertIn("except FloodWaitError as fw:", win)
        self.assertIn("STATUS_FLOODWAIT", win)
        self.assertIn("floodwait_until", win)


if __name__ == "__main__":
    unittest.main()
