"""
v97.85 — STALE JOINED RECORD FIX.

Root cause: "Already joined: 24 > Active VCs: 6" — the discovery loop counted
VCs as "already_joined" based solely on registry state (rec.state == "joined"),
even when the backend was NOT physically connected. Stale registry entries from
previous runs (where the VC had since been disconnected) were incorrectly counted.

Fix: when registry says "joined" but backend (calls container) says NOT connected,
the record is STALE. Repair the registry to "unknown" + make the VC eligible for
re-join. Only count as "already_joined" when the backend CONFIRMS the connection.
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


class TestStaleJoinedRecordFix(unittest.TestCase):
    """v97.85: registry=joined + backend=disconnected → STALE, not already_joined."""

    def test_stale_joined_record_log_exists(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_STALE_JOINED_RECORD", src)

    def test_stale_record_repaired_to_unknown(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn('vc_registry_update(gid, state="unknown"', src)
        self.assertIn('request_accepted=False', src)

    def test_stale_record_makes_eligible_not_already_joined(self):
        """The stale record falls through to active_targets.append(), not already_joined."""
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("VC_STALE_JOINED_RECORD")
        self.assertGreater(idx, 0)
        # After the stale repair, must NOT have already_joined_count += 1
        block = src[idx:idx + 800]
        self.assertNotIn("already_joined_count += 1", block)
        # Must have active_targets.append (eligible for join).
        # v97.99 note: the window was increased from 3500 to 6000 to accommodate
        # the v97.99 FIX-D cleanup code (wired _vc_cleanup_stale_backend_call
        # into the stale_joined_record block, ~25 lines added between the
        # stale detection log and active_targets.append). The test's INTENT
        # is unchanged — verify the stale record falls through to
        # active_targets.append (eligible for join), not already_joined.
        # v99.11: 6000 -> 9000 — the reason-coded cleanup call (P0)
        # lengthened the stale_joined_record block; contract unchanged.
        self.assertIn("active_targets.append", src[idx:idx + 9000])

    def test_backend_connected_still_counts_as_already_joined(self):
        """When backend IS connected, still count as already_joined (preserved)."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("reason=backend_connected", src)

    def test_already_joined_cannot_exceed_active_vcs(self):
        """already_joined_count must be a subset of active_targets (mathematical invariant)."""
        # Simulate: 6 active VCs, 24 registry entries saying "joined"
        active_vcs = 6
        registry_joined = 24
        # v97.85: only count as already_joined if backend confirms connection
        backend_confirmed_joined = 2  # only 2 are actually connected
        already_joined_count = backend_confirmed_joined
        # The remaining 22 are stale → repaired → eligible
        eligible = active_vcs - already_joined_count  # 6 - 2 = 4
        self.assertLessEqual(already_joined_count, active_vcs)
        self.assertEqual(eligible, 4)

    def test_state_transition_logged_for_stale(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("from=JOINED to=ELIGIBLE reason=stale_joined_record", src)


class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_92(self):
        with open(_INIT) as f:
            src = f.read()
        self.assertIn('__bot_version__ = "v99.11.2"', src)


class TestPreservedFixes(unittest.TestCase):
    """Verify all prior fixes preserved."""

    def test_backend_connected_check(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_backend_connected", src)
        self.assertIn("vc_resolve_calls_container", src)

    def test_is_open_property(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("VC_TRACKING_SNAPSHOT")
        block = src[idx:idx + 1200]
        self.assertIn("_vc_join_all_breaker.is_open ", block)

    def test_pytgcalls_filter(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("list_event_handlers", src)

    def test_floodwait_defer(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_TARGET_FLOODWAIT_DEFERRED", src)

    def test_leave_block_during_join_all(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_LEAVE_BLOCKED_DURING_JOIN_ALL", src)

    def test_diagnostic_logging_init(self):
        utils = os.path.join(_BASE, "mediagrab_bot", "utils_real.py")
        with open(utils) as f:
            src = f.read()
        self.assertIn("DIAGNOSTIC_LOGGING_INITIALIZED", src)

    def test_progress_already_joined_sync(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn(
            '_vc_join_all_state["progress"]["already_joined"] = already_joined_count',
            src,
        )

    def test_stale_checkpoint_fix(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_is_explicit_resume", src)

    def test_forced_cancel_client_specific(self):
        mtproto = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
        with open(mtproto) as f:
            src = f.read()
        idx = src.find("async def _forcibly_cancel_telethon_tasks(")
        body = src[idx:idx + 3000]
        self.assertIn("_mediagrab_bg_tasks", body)


# ---------------------------------------------------------------------------
# BEHAVIORAL TESTS
# ---------------------------------------------------------------------------

class TestStaleRegistryBehavioral(unittest.TestCase):
    """Test the stale registry repair behavior."""

    def test_stale_joined_not_counted_as_already_joined(self):
        """registry=joined + backend=disconnected → NOT already_joined."""
        registry_state = "joined"
        backend_connected = False
        # v97.85: only count as already_joined if backend confirms
        is_already_joined = backend_connected
        self.assertFalse(is_already_joined)

    def test_stale_joined_repaired_to_unknown(self):
        registry_state = "joined"
        backend_connected = False
        if registry_state == "joined" and not backend_connected:
            new_state = "unknown"
        else:
            new_state = registry_state
        self.assertEqual(new_state, "unknown")

    def test_stale_joined_makes_eligible(self):
        """After repair, the VC is added to active_targets (eligible)."""
        registry_state = "joined"
        backend_connected = False
        is_stale = (registry_state == "joined" and not backend_connected)
        if is_stale:
            eligible = True  # added to active_targets
        else:
            eligible = False
        self.assertTrue(eligible)

    def test_backend_confirmed_joined_stays_already_joined(self):
        registry_state = "joined"
        backend_connected = True
        is_already_joined = backend_connected
        self.assertTrue(is_already_joined)

    def test_already_joined_never_exceeds_active(self):
        """Invariant: already_joined_count <= active_vcs_count."""
        active_vcs = 6
        backend_connected_joined = 2
        already_joined = backend_connected_joined
        self.assertLessEqual(already_joined, active_vcs)

    def test_24_stale_records_repaired(self):
        """Simulate 24 stale joined records → 0 already_joined, 6 eligible (if active)."""
        total_registry_joined = 24
        active_vcs = 6
        backend_connected = 0  # none actually connected
        already_joined = 0  # v97.85: only backend-confirmed counts
        eligible = active_vcs  # all 6 active VCs are eligible
        # The 18 non-active stale records are simply not encountered (no active call)
        self.assertEqual(already_joined, 0)
        self.assertEqual(eligible, 6)


class TestIdempotentCycles(unittest.TestCase):

    def test_join_all_leave_all_join_all(self):
        """Join All → Leave All → Join All is idempotent."""
        state = {"already_joined": 0, "eligible": 10, "joined": 0}
        # Run 1: join all 10
        state["joined"] = 10
        state["already_joined"] = 0
        # Leave All: reset
        state = {"already_joined": 0, "eligible": 10, "joined": 0}
        # Run 2: join all 10 again
        self.assertEqual(state["eligible"], 10)
        self.assertEqual(state["already_joined"], 0)


if __name__ == "__main__":
    unittest.main()
