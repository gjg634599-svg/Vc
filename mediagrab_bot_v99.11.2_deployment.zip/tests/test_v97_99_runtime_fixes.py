"""Regression tests for v97.99 forensic upgrade — 24/7 VC reliability.

These tests verify the RUNTIME-PROVEN + SOURCE-PROVEN defect fixed in v97.99:

  BUG-VC-BACKEND-CONNECTED-ID-FORM (CRITICAL, RUNTIME-PROVEN + SOURCE-PROVEN):
    The v97.98 fix addressed stale calls-container objects, but the v97.98
    production runtime (bot-diagnostic (13).log) revealed a DEEPER root
    cause that v97.98 did NOT address: the Join All worker's
    ``_backend_connected`` check (voicechat.py:8788) tested only the RAW
    positive chat ID form (``gid`` and ``abs(gid)``, the latter redundant
    for positive gid), MISSING the MARKED form (``-1000000000000 - gid``)
    that PyTgCalls 2.3.3 stores in its calls container.

    For EVERY channel/supergroup (the vast majority of VC targets), this
    produced a FALSE NEGATIVE — ``backend_connected=False`` even when the
    container genuinely held the object. This triggered a cascade of wrong
    actions:
      1. false ``VC_STALE_JOINED_RECORD`` (registry says joined, backend
         says NOT connected — but backend was WRONG due to ID-form mismatch)
      2. registry corrupted to ``state="unknown"`` + coordinator→UNKNOWN
      3. next ``join()``'s container pre-check (voicechat.py:2995) correctly
         found the object via the MARKED form → ``VC_JOIN_SKIP_ALREADY_CONNECTED``
         → bot's state said "not in VC" while the container object persisted.
      4. the bot appeared to "automatically leave" (state corruption) and
         then "incorrectly believe it is already connected, skip the actual
         join" — EXACTLY the user's v97.98 production complaint.

    Runtime evidence (bot-diagnostic (13).log, v97.98, chat 2054748259):
      03:08:46 VC_JOIN_SUCCESS call_id=-8825076571855615238
              (marked -1002054748259 stored in container)
      03:14:45 VC_PARTICIPATION_UNKNOWN reason=truncated_or_incomplete
              → VC_RECONCILE_DEFERRED_UNKNOWN (UNKNOWN invariant OK)
      03:17:25 VC_STALE_JOINED_RECORD backend_connected=false
              (worker checked raw 2054748259 — MISS; container has marked)
      03:19:29 VC_JOIN_SKIP_ALREADY_CONNECTED — found in calls container
              (join checked marked -1002054748259 — HIT)
      [bot's state: unknown; coordinator: UNKNOWN; container: still has object]
      4 chats hit this: 2054748259, 2144563093, 3902917470, 4373897587.

    Root cause (SOURCE-PROVEN): ID-form mismatch between the
    ``_backend_connected`` check (raw only) and the container (marked).
    The join() pre-check and the cleanup helper BOTH correctly check
    marked+raw — the worker check was the ONLY site that missed the marked
    form. This is a classic "same data, different key form" bug.

  v97.99 FIX (minimal, targeted, deterministic — two layers + observability):
    FIX-C (PRIMARY, RUNTIME-PROVEN root cause): extend the
      ``_backend_connected`` check at voicechat.py:8788 to test ALL THREE
      ID forms (raw, abs, marked) — mirrors the join() pre-check at
      voicechat.py:2995 (chat_id + raw_id) and _vc_cleanup_stale_backend_call
      at voicechat.py:5577 (_marked + _raw). With this fix, the worker
      correctly detects already_joined for channels and does NOT fire false
      stale detection. The state corruption that caused the "automatic
      leave" + "skip the actual join" is eliminated.
    FIX-D (DEFENSE-IN-DEPTH): wire ``_vc_cleanup_stale_backend_call`` into
      the ``stale_joined_record`` block (after registry→unknown + coordinator
      →UNKNOWN), mirroring the v97.98 FIX-A pattern for the reconcile LEFT
      block. After FIX-C, this block fires ONLY for TRUE stales (container
      genuinely lacks the object); the cleanup ensures any residual object
      under a different ID form is removed. Best-effort; the join() safety-net
      (FIX-B) catches residuals.
    OBSERVABILITY: enhance the ``VC_STALE_JOINED_RECORD`` log to include
      ``checked_ids={raw, abs, marked}`` + ``container_size`` +
      ``container_sample`` so future forensic analysis can verify the ID
      forms tested and the container contents at detection time.

  INVARIANT (v97.99): the ``backend_connected`` check MUST use the SAME
    ID-form coverage as the join() pre-check and the cleanup helper, else
    false negatives produce state corruption (the v97.98 production failure).
    LOCAL OBJECT EXISTS is NEVER treated as equivalent to TELEGRAM
    PARTICIPATION CONFIRMED (carried forward from v97.98).

These tests use source-text assertions (Telethon/PyTgCalls cannot be loaded
in the validation env) matching the established v97.60-v97.98 test pattern.
"""
from __future__ import annotations

import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
_VOICECHAT_PATH = ROOT / "mediagrab_bot" / "voicechat.py"
_PIPELINE_PATH = ROOT / "mediagrab_bot" / "vc_pipeline.py"
_INIT_PATH = ROOT / "mediagrab_bot" / "__init__.py"
_BOOTSTRAP_PATH = ROOT / "mediagrab_bot" / "bootstrap.py"


def _read_source(path: Path) -> str:
    if not path.exists():
        raise unittest.SkipTest(f"{path.name} not found")
    return path.read_text(encoding="utf-8")


# ===========================================================================
# SECTION A — FIX-C: _backend_connected check tests ALL THREE ID forms
# ===========================================================================
class TestVC99FixCBackendConnectedIdForm(unittest.TestCase):
    """v97.99 FIX-C: the _backend_connected check at the Join All worker
    must test raw, abs, AND marked ID forms (not just raw + abs)."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_VOICECHAT_PATH)

    def test_backend_connected_check_includes_marked_form(self):
        """The _backend_connected check must include the marked ID form
        (-1000000000000 - gid), not just gid and abs(gid)."""
        # The fix adds _marked_gid = -1000000000000 - gid and tests it.
        self.assertIn("_marked_gid = -1000000000000 - gid", self.src,
                      "FIX-C: _marked_gid computation must be present")

    def test_backend_connected_check_tests_three_forms(self):
        """The _backend_connected expression must test gid, abs(gid),
        AND _marked_gid against _resolved_ids."""
        # Find the _backend_connected assignment block.
        idx = self.src.find("_backend_connected = (")
        self.assertGreater(idx, -1 + 1, "_backend_connected multi-line assignment must exist")
        # The next ~120 chars must contain all three forms.
        snippet = self.src[idx:idx + 200]
        self.assertIn("gid in _resolved_ids", snippet,
                      "FIX-C: raw form (gid) must be tested")
        self.assertIn("abs(gid) in _resolved_ids", snippet,
                      "FIX-C: abs form must be tested")
        self.assertIn("_marked_gid in _resolved_ids", snippet,
                      "FIX-C: marked form (_marked_gid) must be tested")

    def test_backend_connected_check_has_v97_99_marker(self):
        """The fix comment must reference v97.99 FIX-C for traceability."""
        self.assertIn("v97.99 FIX-C", self.src,
                      "FIX-C: source must reference v97.99 FIX-C marker")
        self.assertIn("BUG-VC-BACKEND-CONNECTED-ID-FORM", self.src,
                      "FIX-C: source must reference the bug ID")

    def test_backend_connected_check_runtime_evidence_documented(self):
        """The fix comment must document the runtime evidence (chat 2054748259)
        so future maintainers understand the production failure."""
        self.assertIn("2054748259", self.src,
                      "FIX-C: runtime evidence chat 2054748259 must be documented")
        self.assertIn("bot-diagnostic (13).log", self.src,
                      "FIX-C: runtime evidence source log must be documented")

    def test_backend_connected_check_invariant_documented(self):
        """The fix comment must state the v97.99 invariant (same ID-form
        coverage as join() pre-check and cleanup helper)."""
        self.assertIn("SAME ID-form coverage", self.src,
                      "FIX-C: invariant must be documented")

    def test_old_raw_only_check_removed(self):
        """The old buggy single-line check (gid + abs(gid) only) must NOT
        remain as the sole check. The new multi-form check must replace it."""
        # The old check was a single line:
        #   _backend_connected = gid in _resolved_ids or abs(gid) in _resolved_ids
        # The new check is multi-line with _marked_gid. Ensure the old
        # single-line form is NOT present (it's been replaced).
        old_pattern = "_backend_connected = gid in _resolved_ids or abs(gid) in _resolved_ids"
        self.assertNotIn(old_pattern, self.src,
                         "FIX-C: old raw-only single-line check must be replaced")


# ===========================================================================
# SECTION B — FIX-D: stale_joined_record block wires cleanup helper
# ===========================================================================
class TestVC99FixDStaleJoinedRecordCleanup(unittest.TestCase):
    """v97.99 FIX-D: the stale_joined_record block must call
    _vc_cleanup_stale_backend_call (defense-in-depth, mirrors v97.98 FIX-A)."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_VOICECHAT_PATH)

    def test_stale_joined_record_block_calls_cleanup(self):
        """The stale_joined_record block (after registry→unknown +
        coordinator→UNKNOWN) must call _vc_cleanup_stale_backend_call."""
        # Find the stale_joined_record block.
        idx = self.src.find("VC_STALE_JOINED_RECORD run_id=")
        self.assertGreater(idx, 0, "stale_joined_record log must exist")
        # Search forward for the cleanup call within the block (before
        # active_targets.append which ends the block).
        block_end = self.src.find("active_targets.append({", idx)
        self.assertGreater(block_end, idx, "active_targets.append must follow stale block")
        block = self.src[idx:block_end]
        self.assertIn("_vc_cleanup_stale_backend_call", block,
                      "FIX-D: stale_joined_record block must call _vc_cleanup_stale_backend_call")
        self.assertIn('reason="stale_joined_record:backend_disconnected"', block,
                      "FIX-D: cleanup must use stale_joined_record reason")

    def test_stale_joined_record_cleanup_has_v97_99_marker(self):
        """The FIX-D comment must reference v97.99 FIX-D for traceability."""
        idx = self.src.find("v97.99 FIX-D")
        self.assertGreater(idx, 0, "FIX-D: source must reference v97.99 FIX-D marker")

    def test_stale_joined_record_cleanup_is_best_effort(self):
        """The cleanup call must be wrapped in try/except (best-effort,
        mirrors v97.98 FIX-A pattern)."""
        # Search for the cleanup call within the stale_joined_record block
        # (between the STALE_JOINED_RECORD log and active_targets.append).
        idx = self.src.find("v97.99 FIX-D")
        self.assertGreater(idx, 0, "FIX-D block must exist")
        # The actual try block follows the comment block. Search a wider window.
        block = self.src[idx:idx + 2500]
        self.assertIn("try:", block, "FIX-D: cleanup must be in try block")
        self.assertIn("except Exception", block,
                      "FIX-D: cleanup must catch exceptions (best-effort)")
        self.assertIn(
            'await _vc_cleanup_stale_backend_call(\n                                gid, reason="stale_joined_record:backend_disconnected",',
            block,
            "FIX-D: cleanup call with stale_joined_record reason must be present",
        )

    def test_stale_joined_record_cleanup_logs_errors(self):
        """The cleanup error handler must log (debug level) for observability."""
        idx = self.src.find("v97.99 FIX-D")
        self.assertGreater(idx, 0, "FIX-D block must exist")
        # Search a wider window to reach the actual code (past the comments).
        block = self.src[idx:idx + 2500]
        self.assertIn("VC_BACKEND_STALE_CALL_CLEANUP_ERROR", block,
                      "FIX-D: cleanup errors must be logged with marker")
        self.assertIn("source=stale_joined_record", block,
                      "FIX-D: cleanup error log must include source=stale_joined_record")


# ===========================================================================
# SECTION C — Observability: STALE_JOINED_RECORD log enhanced
# ===========================================================================
class TestVC99ObservabilityStaleJoinedRecordLog(unittest.TestCase):
    """v97.99 observability: the VC_STALE_JOINED_RECORD log must include
    checked_ids + container_size + container_sample for forensic analysis."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_VOICECHAT_PATH)

    def test_stale_joined_record_log_includes_checked_ids(self):
        """The STALE_JOINED_RECORD log must include checked_ids={raw, abs, marked}
        so future forensic analysis can verify the ID forms tested."""
        self.assertIn("checked_ids={raw=", self.src,
                      "Observability: STALE_JOINED_RECORD must log checked_ids raw")
        self.assertIn("marked=", self.src,
                      "Observability: STALE_JOINED_RECORD must log checked_ids marked")

    def test_stale_joined_record_log_includes_container_size(self):
        """The STALE_JOINED_RECORD log must include container_size."""
        self.assertIn("container_size=", self.src,
                      "Observability: STALE_JOINED_RECORD must log container_size")

    def test_stale_joined_record_log_includes_container_sample(self):
        """The STALE_JOINED_RECORD log must include container_sample (first 10 IDs)
        for forensic verification."""
        self.assertIn("container_sample=", self.src,
                      "Observability: STALE_JOINED_RECORD must log container_sample")

    def test_stale_joined_record_log_references_v97_99_fix_c(self):
        """The STALE_JOINED_RECORD log must reference v97.99 FIX-C so operators
        can correlate the detection with the fix."""
        self.assertIn("v97.99 FIX-C", self.src,
                      "Observability: STALE_JOINED_RECORD must reference v97.99 FIX-C")


# ===========================================================================
# SECTION D — Version bumps
# ===========================================================================
class TestVC99VersionBumps(unittest.TestCase):
    """v97.99: version declarations must be bumped consistently."""

    def test_init_version_is_v97_99(self):
        src = _read_source(_INIT_PATH)
        self.assertIn('__bot_version__ = "v99.11.2"', src,
                      "__init__.py must declare v97.99")

    def test_bootstrap_deployment_identity_is_v97_99(self):
        src = _read_source(_BOOTSTRAP_PATH)
        self.assertIn("DEPLOYMENT_IDENTITY version={_v9812_pkg_version}", src,  # v99: derivation site (v98.12 correction)
                      "bootstrap.py DEPLOYMENT_IDENTITY must be v97.99")

    def test_no_stale_v97_98_version_remaining(self):
        """No stale v97.98 version declarations should remain in the
        two version files (__init__.py and bootstrap.py)."""
        init_src = _read_source(_INIT_PATH)
        boot_src = _read_source(_BOOTSTRAP_PATH)
        # __init__.py must not still say v97.98 as the bot version.
        self.assertNotIn('__bot_version__ = "v97.98"', init_src,
                         "__init__.py must not retain stale v97.98")
        # bootstrap.py DEPLOYMENT_IDENTITY must not still say v97.98.
        self.assertNotIn("DEPLOYMENT_IDENTITY version=v98.13", boot_src,
                         "bootstrap.py must not retain stale v97.98 DEPLOYMENT_IDENTITY")


# ===========================================================================
# SECTION E — v97.98 FIX-A + FIX-B regression (must be preserved)
# ===========================================================================
class TestVC98FixesPreserved(unittest.TestCase):
    """v97.99 must preserve the v97.98 FIX-A (cleanup helper) and FIX-B
    (join pre-check registry=="left" safety net) verbatim."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_VOICECHAT_PATH)

    def test_v97_98_cleanup_helper_still_exists(self):
        """v97.98 FIX-A: _vc_cleanup_stale_backend_call helper must still exist."""
        self.assertIn("async def _vc_cleanup_stale_backend_call(", self.src,
                      "v97.98 FIX-A: cleanup helper must be preserved")

    def test_v97_98_cleanup_helper_handles_marked_and_raw(self):
        """v97.98 FIX-A: the cleanup helper must normalize both marked and raw forms."""
        idx = self.src.find("async def _vc_cleanup_stale_backend_call(")
        self.assertGreater(idx, 0, "cleanup helper must exist")
        # The helper body includes a long docstring (~2500 chars) before the
        # actual normalization code. Search a wide enough window.
        body = self.src[idx:idx + 9500]  # v99: 4500 -> 9500 (FIX-J/FIX-HH blocks grew; contract unchanged)
        self.assertIn("_marked = ", body,
                      "v97.98 FIX-A: cleanup helper must compute _marked")
        self.assertIn("_raw = ", body,
                      "v97.98 FIX-A: cleanup helper must compute _raw")
        self.assertIn("_marked not in resolved_ids and _raw not in resolved_ids", body,
                      "v97.98 FIX-A: cleanup helper must check both forms")

    def test_v97_98_fix_b_join_pre_check_registry_left_still_exists(self):
        """v97.98 FIX-B (preserved + STRENGTHENED by v99 §7): the join
        container pre-check consults the TELEGRAM-side recheck (the
        authoritative 'is the account really in the call' state that the
        registry-left heuristic only proxied) and cleans when the recheck
        does not confirm presence."""
        pipe = _read_source(_PIPELINE_PATH)
        self.assertIn("VC_PIPELINE_STALE_CONTAINER", pipe,
                      "v99 §7: container stale detected log must exist")
        idx = pipe.find("VC_PIPELINE_STALE_CONTAINER")
        self.assertIn("_cleanup_local_call(", pipe[idx:idx + 1000],
                      "v99 §7: the stale path must clean the local call")

    def test_v97_98_fix_a_wired_into_reconcile_left_block(self):
        """v97.98 FIX-A: the cleanup helper must still be wired into the
        vc_reconcile_participations cls=="LEFT" block."""
        self.assertIn('reason="participation_reconcile_absent"', self.src,
                      "v97.98 FIX-A: reconcile LEFT block cleanup must be preserved")

    def test_v97_98_skip_allowed_invariant_preserved(self):
        """v97.98 FIX-B (preserved by v99 §7): LOCAL OBJECT EXISTS is
        NEVER proof of participation — the skip is conditional on the
        quick Telegram-side recheck verdict (present)."""
        pipe = _read_source(_PIPELINE_PATH)
        self.assertIn('if quick == "present":', pipe,
                      "v99 §7: the skip must be gated by the recheck verdict")
        self.assertIn("VC_PIPELINE_STALE_CONTAINER", pipe,
                      "v99: the non-present fall-through marker must be preserved")


# ===========================================================================
# SECTION F — v97.95 / v97.96 / v97.97 prior fixes preserved
# ===========================================================================
class TestPriorFixesPreserved(unittest.TestCase):
    """v97.99 must preserve all previously proven fixes verbatim
    (Rule 13: Preserve all previously proven fixes unless evidence proves
    they are wrong)."""

    @classmethod
    def setUpClass(cls):
        cls.vc_src = _read_source(_VOICECHAT_PATH)

    def test_v97_95_record_evidence_absent_wiring_preserved(self):
        """v97.95: record_evidence_absent must still be wired into the
        reconcile LEFT block (coordinator JOINED→LEFT on proven absence)."""
        self.assertIn("record_evidence_absent", self.vc_src,
                      "v97.95: record_evidence_absent must be preserved")
        self.assertIn("BUG-VC-REJOIN-SKIP", self.vc_src,
                      "v97.95: bug ID reference must be preserved")

    def test_v97_95_mark_unknown_wiring_preserved(self):
        """v97.95: mark_unknown must still be wired into the
        stale_joined_record + reconcile_timeout blocks."""
        self.assertIn("mark_unknown", self.vc_src,
                      "v97.95: mark_unknown must be preserved")

    def test_v97_85_stale_joined_record_detection_preserved(self):
        """v97.85: the STALE_JOINED_RECORD detection must still fire when
        registry=joined + backend_connected=false."""
        self.assertIn("VC_STALE_JOINED_RECORD", self.vc_src,
                      "v97.85: STALE_JOINED_RECORD marker must be preserved")
        self.assertIn("registry_state=joined backend_connected=false", self.vc_src,
                      "v97.85: detection condition must be preserved")

    def test_v97_84_backend_connected_check_preserved(self):
        """v97.84: the backend_connected check (now fixed by v97.99 FIX-C)
        must still gate the already_joined path."""
        self.assertIn("if _backend_connected:", self.vc_src,
                      "v97.84: backend_connected gate must be preserved")
        self.assertIn("reason=backend_connected", self.vc_src,
                      "v97.84: backend_connected reason must be preserved")

    def test_v97_95_unknown_never_destructive_invariant(self):
        """v97.95/v97.98 invariant: UNKNOWN must never cause a destructive
        action (UNKNOWN → DEFERRED, not LEFT/cleanup)."""
        self.assertIn("VC_RECONCILE_DEFERRED_UNKNOWN", self.vc_src,
                      "v97.95: DEFERRED_UNKNOWN marker must be preserved")
        self.assertIn("preserving joined state (backend evidence)", self.vc_src,
                      "v97.95: UNKNOWN preserve-joined logic must be preserved")


# ===========================================================================
# SECTION G — Structural integrity (py_compile + file existence)
# ===========================================================================
class TestVC99StructuralIntegrity(unittest.TestCase):
    """v97.99: changed files must py_compile and the source tree must be intact."""

    def test_voicechat_py_compiles(self):
        import py_compile
        tmp = py_compile.compile(
            str(_VOICECHAT_PATH), doraise=True
        )
        self.assertIsNotNone(tmp, "voicechat.py must py_compile")

    def test_init_py_compiles(self):
        import py_compile
        tmp = py_compile.compile(str(_INIT_PATH), doraise=True)
        self.assertIsNotNone(tmp, "__init__.py must py_compile")

    def test_bootstrap_py_compiles(self):
        import py_compile
        tmp = py_compile.compile(str(_BOOTSTRAP_PATH), doraise=True)
        self.assertIsNotNone(tmp, "bootstrap.py must py_compile")

    def test_voicechat_py_hash_changed_from_v97_98(self):
        """voicechat.py must have a DIFFERENT hash from v97.98 (f77f9b53...)
        — proving the fix was actually applied."""
        import hashlib
        h = hashlib.sha256(_VOICECHAT_PATH.read_bytes()).hexdigest()
        self.assertFalse(h.startswith("f77f9b53432ba81e"),
                         "voicechat.py hash must change from v97.98 (f77f9b53...)")


# ===========================================================================
# SECTION H — Runtime evidence correlation (the fix matches the failure)
# ===========================================================================
class TestVC99RuntimeEvidenceCorrelation(unittest.TestCase):
    """v97.99: the fix must target the EXACT runtime-proven failure mode.
    This correlates the fix with the bot-diagnostic (13).log evidence."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_VOICECHAT_PATH)

    def test_fix_documents_chat_2054748259_evidence(self):
        """The FIX-C comment must document chat 2054748259 as the runtime
        evidence (the false stale detection case)."""
        # The fix comment references 2054748259 and the 4 affected chats.
        self.assertIn("2054748259", self.src)
        self.assertIn("2144563093", self.src)
        self.assertIn("3902917470", self.src)
        self.assertIn("4373897587", self.src)

    def test_fix_documents_join_pre_check_consistency(self):
        """The fix must document that the join() pre-check (voicechat.py:2995)
        and cleanup helper (voicechat.py:5577) both correctly check marked+raw,
        and that the worker check was the ONLY buggy site."""
        self.assertIn("voicechat.py:2995", self.src)
        self.assertIn("voicechat.py:5577", self.src)

    def test_fix_documents_false_negative_cascade(self):
        """The fix must document the cascade: false negative → false stale →
        registry corruption → skip → bot appears to leave."""
        self.assertIn("FALSE NEGATIVE", self.src)
        self.assertIn("state corruption", self.src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
