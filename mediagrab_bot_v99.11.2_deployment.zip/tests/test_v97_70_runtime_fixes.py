"""
v97.70 regression tests — Telethon dispatch task explosion fix.

Root cause: the v97.69 runtime log showed 856 total_tasks at a 13.95s
EVENT_LOOP_LAG_CRITICAL. ~800 were Telethon _dispatch_update tasks created
for EVERY incoming message — even though 99% were irrelevant (not self-destruct
media, not VC commands). Telethon creates a new asyncio task per update per
handler. The task creation overhead for 800 tasks caused 13.95s of event-loop
starvation.

Fix: added func filters to the events.NewMessage() registrations:
  1. _self_destruct_filter: only self-destruct media passes (for mtproto_capture)
  2. _vc_command_filter: only messages starting with "/" pass (for vc_command)

The func filter runs BEFORE Telethon creates a dispatch task — eliminating
~99% of task creation for irrelevant messages.
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")


class TestDispatchTaskExplosion(unittest.TestCase):
    """P0: Telethon must NOT create dispatch tasks for irrelevant messages."""

    def test_mtproto_capture_uses_func_filter(self):
        """The self-destruct capture handler must use a func filter."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_self_destruct_filter", src,
                      "must define _self_destruct_filter function")
        self.assertIn("func=_self_destruct_filter", src,
                      "event registration must use func filter")
        # The filter must check for media + self-destruct.
        self.assertIn("getattr(message, \"media\", None)", src,
                      "filter must check for media")
        self.assertIn("_mtproto_is_self_destruct", src,
                      "filter must check _mtproto_is_self_destruct")

    def test_vc_command_uses_func_filter(self):
        """The VC command handler must use a func filter."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_vc_command_filter", src,
                      "must define _vc_command_filter function")
        self.assertIn("func=_vc_command_filter", src,
                      "event registration must use func filter")
        # The filter must check for "/" prefix.
        self.assertIn("startswith(\"/\")", src,
                      "filter must check for / prefix")

    def test_no_unfiltered_newmessage_registration(self):
        """No event registration should be without a func filter."""
        with open(_MTPROTO) as f:
            mtproto_src = f.read()
        with open(_VOICECHAT) as f:
            voicechat_src = f.read()
        # Check mtproto.py — the _on_new_message must use func filter.
        self.assertIn("func=_self_destruct_filter", mtproto_src,
                      "mtproto capture must use func filter")
        # Check voicechat.py — the _on_vc_command must use func filter.
        self.assertIn("func=_vc_command_filter", voicechat_src,
                      "vc command must use func filter")


class TestPreservedBehavior(unittest.TestCase):
    """Verify all previous fixes are still present."""

    def test_reconcile_disconnect_gate(self):
        """v97.69 reconcile disconnect gate must hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_RECONCILE_DEFERRED_NETWORK", src)

    def test_disconnect_classification(self):
        """v97.68 authoritative disconnect classification must hold."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_is_disconnect_exc", src)
        self.assertIn("classified as disconnect", src)

    def test_discovery_per_page_gate(self):
        """v97.68 discovery per-page gate must hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("DISCOVERY_DEFERRED_NETWORK", src)

    def test_callback_handler_sync_properties(self):
        """v97.62 callback handler fix must hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("event.sender_id", src)

    def test_no_await_on_sync_release(self):
        """v97.61 TypeError fix must hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertNotIn("await _vc_release_target_inflight", src)

    def test_floodwait_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_GLOBAL_FLOODWAIT_SET", src)

    def test_interdc_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("is_interdc_error", src)

    def test_dashboard_single_flight(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_DASHBOARD_REFRESH_CANCELLED", src)

    def test_no_asyncio_shield_in_stop(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        import re
        m = re.search(r'async def vc_join_all_active_stop.*?(?=\nasync def |\ndef )', src, re.DOTALL)
        self.assertIsNotNone(m)
        code_only = re.sub(r'#.*', '', m.group(0))
        self.assertNotIn("asyncio.shield", code_only)

    def test_event_loop_lag_instrumentation(self):
        with open(os.path.join(_BASE, "mediagrab_bot/bootstrap.py")) as f:
            src = f.read()
        self.assertIn("_capture_blocking_task_stack", src)

    def test_dashboard_single_to_thread(self):
        with open(os.path.join(_BASE, "mediagrab_bot/handlers.py")) as f:
            src = f.read()
        self.assertIn("_snapshot_and_triggers", src)

    def test_get_entity_wrapper(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_wrap_get_entity_disconnect_safe", src)

    def test_join_all_get_entity_timeout(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_JOIN_ALL_ENTITY_TIMEOUT", src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
