"""Regression tests for v97.95 forensic audit — VC leave/rejoin stale-state skip.

These tests verify the RUNTIME-PROVEN + SOURCE-PROVEN bug fixed in v97.95:

  BUG-VC-REJOIN-SKIP (RUNTIME-PROVEN + SOURCE-PROVEN, HIGH severity):
    After BOTH userbot accounts passively leave a Voice Chat (PyTgCalls stream
    ends / bot kicked / network drop — NO explicit /leave command), the
    participation reconcile loop + the v97.85 stale-joined-record repair
    correctly update the participation registry to state="left" / "unknown",
    BUT they do NOT call the VCChatCoordinator's record_evidence_absent() /
    mark_unknown() / reset_to_idle(). The coordinator's per-chat state
    therefore stays at JOINED indefinitely. The next Join All attempt calls
    coord.begin_operation(chat_id, "join") which sees state ∈ {JOINED, ACTIVE,
    VERIFYING} and returns (False, None, "already_joined") — the join is
    permanently skipped.

    Runtime evidence (bot-diagnostic (7).log, v97.94):
      chat_id=1922822605 on boot #2:
        10:47:45 VC_JOIN_SUCCESS + VC_COORDINATOR_OP_COMPLETE new_state=joined
        10:55:19 VC_PARTICIPATION_CONFIRMED_ABSENT + VC_REGISTRY_UPDATE_CONFIRMED
                classification=LEFT  (registry updated; coordinator NOT updated)
        10:59:06 VC_JOIN_ALL_COORD_SKIP reason=already_joined  (coordinator still JOINED)
      chat_id=1922822605 on boot #3:
        12:07:30 joined (coordinator → JOINED)
        12:14:54 VC_STALE_JOINED_RECORD registry_state=joined backend_connected=false
                — repairing registry to unknown (v97.85)  (registry updated;
                coordinator NOT updated)
        12:18:50 VC_JOIN_ALL_COORD_SKIP reason=already_joined  (coordinator still JOINED)

    Root cause (SOURCE-PROVEN):
      vc_state_coordinator.py:219-221 — the skip predicate:
        if operation_type == "join" and cur_state in _JOINED_STATES:
            return False, None, f"already_{cur_state.value}"
      voicechat.py:6070  reconcile-TIMEOUT path:        vc_registry_update(state="unknown")  — no coord.mark_unknown
      voicechat.py:6135  reconcile-POSITIVE-ABSENCE:   vc_registry_update(state="left")     — no coord.record_evidence_absent
      voicechat.py:8596  v97.85 stale-joined-record:    vc_registry_update(state="unknown")  — no coord.mark_unknown
      + record_evidence_absent / reset_to_idle / mark_joined(coord) / mark_deferred(coord)
        had ZERO call sites in v97.94 (dead code).

    Fix (v97.95): wire the 3 detection sites to the coordinator's idempotent
    state-update methods. record_evidence_absent transitions
    {JOINED, ACTIVE, VERIFYING, RECOVERING, UNKNOWN, DEFERRED} → LEFT (no-op
    on IDLE/LEFT/FAILED/CANCELLED — safe). mark_unknown never downgrades
    LEFT→UNKNOWN (safe). Both are idempotent.

These tests are behavioral — they verify the runtime property the fix
establishes (a rejoin after passive leave MUST NOT be skipped), not just the
source-text pattern.
"""
from __future__ import annotations

import asyncio
import importlib.util
import os
import sys
import unittest
from pathlib import Path

# ──────────────────────────────────────────────────────────────────────────
# Load the coordinator module DIRECTLY from file — avoids the package
# __init__ chain which pulls in python-telegram-bot / telethon (not needed
# for this pure-stdlib module and not installed in the validation env).
# ──────────────────────────────────────────────────────────────────────────
_COORD_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "mediagrab_bot", "vc_state_coordinator.py",
)
_spec = importlib.util.spec_from_file_location("vc_state_coordinator_v9795", _COORD_PATH)
_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_mod)

VCChatCoordinator = _mod.VCChatCoordinator
VCChatState = _mod.VCChatState
VCOperation = _mod.VCOperation
get_vc_coordinator = _mod.get_vc_coordinator
reset_vc_coordinator = _mod.reset_vc_coordinator

ROOT = Path(__file__).resolve().parent.parent
_VOICECHAT_PATH = ROOT / "mediagrab_bot" / "voicechat.py"


# ===========================================================================
# SECTION A — Coordinator behavioral tests (pure-Python, no network)
#
# These prove the coordinator's record_evidence_absent + mark_unknown methods
# actually clear the JOINED state, AND that after clearing, a new join is NOT
# skipped with already_joined. This is the core property the fix relies on.
# ===========================================================================
class TestCoordinatorRejoinClearsJoined(unittest.IsolatedAsyncioTestCase):
    """v97.95: the coordinator MUST allow a rejoin after passive leave.

    The bug: a chat left passively (no explicit /leave) had its participation
    registry updated to state=left but the coordinator stayed JOINED → next
    join returned already_joined. The fix wires detection sites to
    record_evidence_absent / mark_unknown. These tests prove those methods
    actually clear JOINED so the next begin_operation(join) proceeds.
    """

    async def asyncSetUp(self):
        reset_vc_coordinator()
        self.c = get_vc_coordinator()

    async def _simulate_join_success(self, chat_id: int):
        """Drive the coordinator through a successful join (IDLE→JOINING→JOINED)."""
        ok, op, reason = await self.c.begin_operation(chat_id, "join", source="test_join")
        self.assertTrue(ok, f"join begin failed: {reason}")
        accepted = await self.c.complete_operation(
            chat_id, op, True, VCChatState.JOINED, "test_join_success",
        )
        self.assertTrue(accepted)
        self.assertEqual(self.c.get_state(chat_id), VCChatState.JOINED)

    # ── record_evidence_absent clears JOINED → LEFT → rejoin proceeds ──

    async def test_record_evidence_absent_clears_joined_allowing_rejoin(self):
        """THE CORE REGRESSION: after JOINED→LEFT via record_evidence_absent,
        begin_operation(join) must NOT return already_joined."""
        chat_id = 1922822605
        await self._simulate_join_success(chat_id)
        self.assertEqual(self.c.get_state(chat_id), VCChatState.JOINED)

        # Passive leave detected by participation reconcile (positive absence).
        applied = await self.c.record_evidence_absent(
            chat_id, evidence="participation_reconcile:telegram_absent",
        )
        self.assertTrue(applied, "record_evidence_absent must transition JOINED→LEFT")
        self.assertEqual(self.c.get_state(chat_id), VCChatState.LEFT)

        # Rejoin attempt — MUST proceed (not skip).
        ok, op, reason = await self.c.begin_operation(
            chat_id, "join", source="test_rejoin_after_passive_leave",
        )
        self.assertTrue(ok, f"rejoin after passive leave was SKIPPED: {reason} — "
                            f"this is the v97.95 bug if it fails")
        self.assertNotIn("already_", reason)
        await self.c.complete_operation(chat_id, op, True, VCChatState.JOINED, "rejoin")

    async def test_record_evidence_absent_clears_active_and_verifying(self):
        """record_evidence_absent must clear ACTIVE and VERIFYING too
        (both are in _JOINED_STATES and cause already_joined skips)."""
        # Use distinct chat_ids per iteration — begin_operation creates an
        # in-flight op that must be completed (else the next begin on the same
        # chat coalesces). Distinct ids isolate each state transition.
        for i, state in enumerate((VCChatState.ACTIVE, VCChatState.VERIFYING)):
            chat_id = 77000 + i
            self.c._chat_states[chat_id] = state
            applied = await self.c.record_evidence_absent(chat_id, evidence="test")
            self.assertTrue(applied, f"must clear {state.value}")
            self.assertEqual(self.c.get_state(chat_id), VCChatState.LEFT)
            ok, op, reason = await self.c.begin_operation(
                chat_id, "join", source=f"test_{state.value}",
            )
            self.assertTrue(ok, f"rejoin after {state.value} skip: {reason}")
            # Complete the op so it doesn't leak into other tests.
            if op is not None:
                await self.c.complete_operation(
                    chat_id, op, True, VCChatState.LEFT, "test_complete",
                )

    async def test_record_evidence_absent_is_idempotent_on_left(self):
        """Calling record_evidence_absent on an already-LEFT chat is a no-op
        (must NOT crash or change state). This proves the fix is safe to call
        from multiple detection paths."""
        self.c._chat_states[8888] = VCChatState.LEFT
        applied = await self.c.record_evidence_absent(8888, evidence="test")
        self.assertFalse(applied, "no-op on LEFT")
        self.assertEqual(self.c.get_state(8888), VCChatState.LEFT)

    async def test_record_evidence_absent_noop_on_idle_failed_cancelled(self):
        """record_evidence_absent must be a no-op on terminal states
        (IDLE/FAILED/CANCELLED) — preserves operation outcomes."""
        for state in (VCChatState.IDLE, VCChatState.FAILED, VCChatState.CANCELLED):
            self.c._chat_states[9000] = state
            applied = await self.c.record_evidence_absent(9000, evidence="test")
            self.assertFalse(applied, f"must not modify {state.value}")
            self.assertEqual(self.c.get_state(9000), state)

    # ── mark_unknown clears JOINED → UNKNOWN → rejoin proceeds ──

    async def test_mark_unknown_clears_joined_allowing_rejoin(self):
        """The v97.85 stale-joined-record repair path must mark_unknown
        (backend disconnected → can't confirm left, but JOINED is wrong)."""
        chat_id = 33333
        await self._simulate_join_success(chat_id)

        await self.c.mark_unknown(chat_id, reason="stale_joined_record:backend_disconnected")
        self.assertEqual(self.c.get_state(chat_id), VCChatState.UNKNOWN)

        # Rejoin must proceed (UNKNOWN ∉ _JOINED_STATES).
        ok, op, reason = await self.c.begin_operation(chat_id, "join", source="test")
        self.assertTrue(ok, f"rejoin after mark_unknown was SKIPPED: {reason}")
        await self.c.complete_operation(chat_id, op, True, VCChatState.JOINED, "rejoin")

    async def test_mark_unknown_never_downgrades_left(self):
        """Per §19: mark_unknown must NEVER downgrade LEFT→UNKNOWN
        (LEFT is positive evidence; uncertain checks preserve it)."""
        self.c._chat_states[11111] = VCChatState.LEFT
        await self.c.mark_unknown(11111, reason="test")
        self.assertEqual(self.c.get_state(11111), VCChatState.LEFT,
                         "LEFT must be preserved (never downgraded to UNKNOWN)")

    # ── the BOTH-ACCOUNTS-LEAVE scenario ──

    async def test_both_accounts_leave_then_rejoin_must_not_skip(self):
        """THE USER-REPORTED BUG: two userbot accounts both leave a VC;
        a later JOIN for the same VC must NOT be permanently skipped.

        The coordinator state is per-chat (not per-account), so when both
        accounts leave passively, a single record_evidence_absent clears the
        chat's JOINED state and the rejoin proceeds.
        """
        chat_id = 1922822605
        await self._simulate_join_success(chat_id)

        # Both accounts leave passively. The participation reconcile detects
        # positive absence (telegram=absent, locally_tracked=False) and calls
        # record_evidence_absent — ONCE is enough (coordinator is per-chat).
        applied = await self.c.record_evidence_absent(
            chat_id, evidence="both_accounts_left:telegram_absent",
        )
        self.assertTrue(applied)
        self.assertEqual(self.c.get_state(chat_id), VCChatState.LEFT)

        # New JOIN request for the same VC — MUST be attempted, not skipped.
        ok, op, reason = await self.c.begin_operation(
            chat_id, "join", source="rejoin_after_both_left",
        )
        self.assertTrue(ok, f"rejoin after both accounts left was SKIPPED: {reason}")
        self.assertEqual(reason, "ok")

    async def test_immediate_rejoin_race_after_leave(self):
        """The race: leave account A, leave account B, IMMEDIATELY request
        join (before reconcile has run). The rejoin must still be PERMITTED
        once the old participation is gone — the coordinator must not
        permanently block it.

        Here we simulate: join → explicit leave (clears coordinator via
        complete_operation) → immediate rejoin. The explicit-leave path
        already worked; this test guards it stays working alongside the new
        passive-leave fix.
        """
        chat_id = 44444
        await self._simulate_join_success(chat_id)
        ok, op, _ = await self.c.begin_operation(chat_id, "leave", source="explicit_leave")
        self.assertTrue(ok)
        await self.c.complete_operation(chat_id, op, True, VCChatState.LEFT, "manual_leave")

        # Immediate rejoin.
        ok, op, reason = await self.c.begin_operation(chat_id, "join", source="immediate_rejoin")
        self.assertTrue(ok, f"immediate rejoin after explicit leave failed: {reason}")

    async def test_rejoin_after_stale_joined_record_repair(self):
        """The v97.85 stale-joined-record repair path: registry says joined
        but backend disconnected. The fix calls mark_unknown so the VC becomes
        eligible for rejoin (UNKNOWN is not in _JOINED_STATES)."""
        chat_id = 55555
        await self._simulate_join_success(chat_id)
        # v97.85 repair fires (backend_connected=false, registry=joined).
        await self.c.mark_unknown(chat_id, reason="stale_joined_record:backend_disconnected")
        # Rejoin attempt.
        ok, op, reason = await self.c.begin_operation(chat_id, "join", source="rejoin_after_stale_repair")
        self.assertTrue(ok, f"rejoin after stale-joined-record repair was SKIPPED: {reason}")


# ===========================================================================
# SECTION B — Source-wiring tests
#
# These prove the 3 detection sites in voicechat.py actually CALL the
# coordinator's record_evidence_absent / mark_unknown (the v97.95 wiring).
# Without these, the coordinator stays JOINED and the bug persists.
# ===========================================================================
class TestVoicechatCoordinatorWiring(unittest.TestCase):
    """v97.95: the participation reconcile + v97.85 stale-record repair
    MUST call the coordinator's idempotent state-update methods.

    SOURCE-PROVEN dead code in v97.94: record_evidence_absent, reset_to_idle,
    mark_joined(coord), mark_deferred(coord) had ZERO call sites in
    voicechat.py. The v97.95 fix wires the 3 detection sites.
    """

    @classmethod
    def setUpClass(cls):
        if not _VOICECHAT_PATH.exists():
            raise unittest.SkipTest("voicechat.py not found")
        cls.src = _VOICECHAT_PATH.read_text(encoding="utf-8")

    def _find_call_near(self, needle: str, *, near: str, window: int = 800) -> str:
        """Return the source window around `near` for inspection."""
        idx = self.src.find(near)
        self.assertGreater(idx, -1, f"anchor not found: {near}")
        return self.src[idx:idx + window]

    # ── Site 1: participation reconcile POSITIVE-ABSENCE (state="left") ──

    def test_reconcile_positive_absence_calls_record_evidence_absent(self):
        """voicechat.py LEFT branch — when cls == LEFT (telegram=absent,
        locally_tracked=False), the coordinator MUST be told via
        record_evidence_absent. v97.94 called only vc_registry_update.

        Uses index-based assertion (robust against comment volume)."""
        anchor = 'vc_registry_update(rec.chat_id, state="left")'
        anchor_idx = self.src.find(anchor)
        self.assertGreater(anchor_idx, -1, "LEFT-branch registry_update not found")
        call_idx = self.src.find("record_evidence_absent", anchor_idx)
        self.assertGreater(call_idx, -1,
                          "record_evidence_absent must appear AFTER the LEFT-"
                          "branch registry_update (v97.95 fix)")
        self.assertLess(call_idx - anchor_idx, 3000,
                        "record_evidence_absent must be within 3000 chars of "
                        "the LEFT-branch registry_update (same code block)")

    def test_reconcile_positive_absence_still_updates_registry(self):
        """The fix is ADDITIVE — it must not remove the existing
        vc_registry_update(state='left') call."""
        self.assertIn('vc_registry_update(rec.chat_id, state="left")', self.src,
                      "registry update to left must be preserved")

    # ── Site 2: v97.85 stale-joined-record repair (state="unknown") ──

    def test_stale_joined_record_repair_calls_mark_unknown(self):
        """voicechat.py v97.85 stale-joined-record repair must call
        coord.mark_unknown so the coordinator leaves JOINED.

        Uses index-based assertion (robust against comment volume)."""
        anchor = 'vc_registry_update(gid, state="unknown",'
        anchor_idx = self.src.find(anchor)
        self.assertGreater(anchor_idx, -1, "stale-record registry_update not found")
        call_idx = self.src.find("mark_unknown", anchor_idx)
        self.assertGreater(call_idx, -1,
                          "mark_unknown must appear AFTER the stale-record "
                          "registry_update (v97.95 fix)")
        self.assertLess(call_idx - anchor_idx, 3000,
                        "mark_unknown must be within 3000 chars of the "
                        "stale-record registry_update (same code block)")

    def test_stale_joined_record_repair_still_updates_registry(self):
        """The fix is ADDITIVE — registry update to unknown must remain."""
        self.assertIn('vc_registry_update(gid, state="unknown"', self.src,
                      "registry update to unknown must be preserved")

    # ── Site 3: participation reconcile TIMEOUT (state="unknown") ──

    def test_reconcile_timeout_calls_mark_unknown(self):
        """voicechat.py reconcile-TIMEOUT path must call coord.mark_unknown
        so the chat becomes eligible for rejoin.

        Uses index-based assertion (robust against comment volume — the
        timeout block has extensive v97.65/v97.75 comments)."""
        anchor = 'vc_registry_update(rec.chat_id, state="unknown")'
        # Find the FIRST occurrence (the timeout path). There may be multiple
        # state="unknown" updates; the timeout one is followed by the
        # VC_RECONCILE_TIMEOUT marker.
        timeout_marker_idx = self.src.find('"VC_RECONCILE_TIMEOUT chat_id=')
        self.assertGreater(timeout_marker_idx, -1,
                           "VC_RECONCILE_TIMEOUT log emission not found")
        # The registry_update for the timeout path is just before the marker,
        # but the v97.95 fix added ~1800 chars of comments between them.
        # Use a 3000-char window to cover the full code block.
        search_start = max(0, timeout_marker_idx - 3000)
        anchor_idx = self.src.find(anchor, search_start, timeout_marker_idx)
        self.assertGreater(anchor_idx, -1,
                           "timeout-path registry_update(state=unknown) not "
                           "found before VC_RECONCILE_TIMEOUT marker")
        call_idx = self.src.find("mark_unknown", anchor_idx, timeout_marker_idx + 200)
        self.assertGreater(call_idx, -1,
                          "mark_unknown must appear between the timeout-path "
                          "registry_update and the VC_RECONCILE_TIMEOUT marker "
                          "(v97.95 fix)")

    # ── Dead-code revival: the methods must now have call sites ──

    def test_record_evidence_absent_has_call_site(self):
        """v97.94: record_evidence_absent had ZERO call sites (dead code).
        v97.95 must wire at least one call site."""
        # Count occurrences excluding the definition in vc_state_coordinator
        # (this is voicechat.py only).
        count = self.src.count("record_evidence_absent")
        self.assertGreaterEqual(count, 1,
                                "record_evidence_absent must have a call site "
                                "in voicechat.py (was dead code in v97.94)")

    def test_mark_unknown_has_call_site(self):
        """v97.94 had exactly ONE mark_unknown call site (manual leave).
        v97.95 adds at least 2 more (stale-record repair + reconcile timeout)."""
        count = self.src.count("mark_unknown")
        # v97.94 had 1 (line 17890). v97.95 adds ≥2 → ≥3 total.
        self.assertGreaterEqual(count, 3,
                                "mark_unknown must have ≥3 call sites in "
                                "voicechat.py (v97.94 had 1; v97.95 adds ≥2)")


# ===========================================================================
# SECTION C — Structured logging tests (Phase 8)
#
# The leave/skip path had ZERO structured markers in v97.94. v97.95 adds
# VC_LEAVE_CLEANUP_* and VC_JOIN_SKIP(reason=...) and VC_STALE_STATE_DETECTED
# so the failure is diagnosable in production logs.
# ===========================================================================
class TestLeaveSkipLoggingMarkers(unittest.TestCase):
    """v97.95: the runtime log must make this failure diagnosable.

    The v97.94 audit found the leave path had NO structured markers —
    VC_LEAVE / VC_STOP / VC_SKIP / VC_LEAVE_CLEANUP did not exist. The skip
    path emitted only a generic VC_JOIN_ALL_COORD_SKIP without the
    coordinator/backend/registry state needed to diagnose it.
    """

    @classmethod
    def setUpClass(cls):
        if not _VOICECHAT_PATH.exists():
            raise unittest.SkipTest("voicechat.py not found")
        cls.src = _VOICECHAT_PATH.read_text(encoding="utf-8")

    def test_vc_leave_cleanup_markers_present(self):
        """The leave cleanup path must emit structured markers."""
        for marker in (
            "VC_LEAVE_CLEANUP_START",
            "VC_LEAVE_CLEANUP_COMPLETE",
        ):
            self.assertIn(marker, self.src,
                          f"{marker} marker must be present (v97.95 logging fix)")

    def test_vc_join_skip_marker_has_reason_field(self):
        """The skip log MUST identify the EXACT reason for the skip
        (coordinator state / backend_connected / registry_state / breaker)."""
        # The existing VC_JOIN_ALL_COORD_SKIP must carry a reason= field.
        self.assertIn("VC_JOIN_ALL_COORD_SKIP", self.src)
        # The new VC_STALE_STATE_DETECTED marker must fire when the fix
        # repairs a stale JOINED state.
        self.assertIn("VC_STALE_STATE_DETECTED", self.src,
                      "VC_STALE_STATE_DETECTED marker must be present "
                      "(v97.95 logging fix — fires when stale JOINED is repaired)")

    def test_skip_log_includes_coordinator_state(self):
        """The skip log must include the coordinator state + backend state
        so the operator can diagnose WHICH stale source caused the skip."""
        # Find the VC_JOIN_ALL_COORD_SKIP log line and verify it includes
        # enough context (reason is required; the new logging adds more).
        idx = self.src.find("VC_JOIN_ALL_COORD_SKIP")
        self.assertGreater(idx, -1)
        window = self.src[idx:idx + 600]
        # Must log the reason (already did in v97.94).
        self.assertIn("reason=", window)


# ===========================================================================
# SECTION D — Version bump
# ===========================================================================
class TestVersionBump(unittest.TestCase):
    """v97.95 must bump the version string consistently."""

    @classmethod
    def setUpClass(cls):
        cls._init_path = ROOT / "mediagrab_bot" / "__init__.py"
        cls._bootstrap_path = ROOT / "mediagrab_bot" / "bootstrap.py"
        if not cls._init_path.exists():
            raise unittest.SkipTest("__init__.py not found")

    def test_init_version_is_v97_95(self):
        # v99: the version string tracks the CURRENT artifact (v99.03 —
        # the VC pipeline rewrite release).
        src = self._init_path.read_text(encoding="utf-8")
        self.assertIn("v99.11", src,
                      "__init__.py must declare the current version")

    def test_bootstrap_version_is_v97_95(self):
        if not self._bootstrap_path.exists():
            self.skipTest("bootstrap.py not found")
        src = self._bootstrap_path.read_text(encoding="utf-8")
        # v99 test maintenance (v98.12 correction): the identity derives
        # from the package version — assert the derivation site.
        self.assertIn("version={_v9812_pkg_version}", src,
                      "bootstrap.py must derive the identity version")


if __name__ == "__main__":
    unittest.main()
