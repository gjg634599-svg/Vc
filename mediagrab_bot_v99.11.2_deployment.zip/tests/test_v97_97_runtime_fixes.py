"""Regression tests for v97.97 forensic upgrade — codebase lifecycle hardening.

These tests verify the SOURCE-PROVEN defects fixed in v97.97:

  BUG-5 (MEDIUM, SOURCE-PROVEN, latent leak in sync entry points):
    ``remove_account`` (mtproto.py:600) and ``set_disabled`` (mtproto.py:649)
    used fire-and-forget ``supervised_create_task(client.disconnect())`` (the
    v97.44 fix for bare ``loop.create_task``). That pattern was a LATENT LEAK:
    it called ``client.disconnect()`` but did NOT call
    ``_forcibly_cancel_telethon_tasks`` (so the 6 Telethon background tasks
    could survive a drain timeout) and did NOT call
    ``_release_client_session`` (so the session-ownership registry retained
    a stale owner, blocking the next ``connect_account`` with
    SESSION_OWNERSHIP_CONFLICT).

    v97.97 FIX: a unified async helper ``_cleanup_client_async`` applies the
    SAME v97.96 BUG-1 pattern used by ``connect_account`` (4 paths) and
    ``disconnect_account`` (BUG-3): ``_forcibly_cancel_telethon_tasks`` ->
    ``client.disconnect()`` -> await ``disconnected`` drain (10s) ->
    ``_release_client_session``. The sync entry points schedule the helper
    via ``supervised_create_task`` (preserving their sync API).

  BUG-6 (LOW, SOURCE-PROVEN + RUNTIME-PROVEN, observability false-positive):
    ``_log_orphaned_telethon_tasks`` (mtproto.py) flagged the global
    ``_mtproto_client``'s legitimately-alive 6 bg tasks as "orphans" when a
    CLUSTER client was being disconnected (e.g., at shutdown, when PRIMARY
    is intentionally left running via ACCOUNT_DISCONNECT_SKIP_GLOBAL).
    Runtime evidence (bot-diagnostic (9).log 17:37:08):
      MTPROTO_ORPHAN_TELETHON_TASKS_DETECTED count=6 ... but 0 reconnects
      occurred; the 6 tasks were PRIMARY's global _mtproto_client tasks.
    This was a false positive that misled operators.

    v97.97 FIX: the orphan detector now excludes tasks belonging to the
    KNOWN-LIVE global ``_mtproto_client`` (via snapshot-id match AND
    cr_frame.f_locals["self"] is _mtproto_client check). The log message is
    updated to clarify the exclusion. Observability-only — no behavior change.

These tests use source-text assertions (Telethon cannot be loaded in the
validation env) matching the established v97.60-v97.96 test pattern.
"""
from __future__ import annotations

import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
_MTPROTO_PATH = ROOT / "mediagrab_bot" / "mtproto.py"
_VOICECHAT_PATH = ROOT / "mediagrab_bot" / "voicechat.py"
_INIT_PATH = ROOT / "mediagrab_bot" / "__init__.py"
_BOOTSTRAP_PATH = ROOT / "mediagrab_bot" / "bootstrap.py"


def _read_source(path: Path) -> str:
    if not path.exists():
        raise unittest.SkipTest(f"{path.name} not found")
    return path.read_text(encoding="utf-8")


# ===========================================================================
# SECTION A — BUG-5: remove_account uses _cleanup_client_async (no bare disconnect)
# ===========================================================================
class TestBUG5RemoveAccountCleanup(unittest.TestCase):
    """v97.97 BUG-5: remove_account must schedule _cleanup_client_async."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_MTPROTO_PATH)

    def test_remove_account_calls_cleanup_helper(self):
        """remove_account must call _cleanup_client_async with label='remove_account'."""
        idx = self.src.find("def remove_account(self, account_id: str) -> bool:")
        self.assertGreater(idx, -1, "remove_account must exist")
        # Window after the def — must contain _cleanup_client_async.
        window = self.src[idx:idx + 1200]
        self.assertIn("_cleanup_client_async", window,
                      "BUG-5: remove_account must call _cleanup_client_async")
        self.assertIn('label="remove_account"', window,
                      "BUG-5: remove_account must pass label='remove_account'")

    def test_remove_account_no_fire_and_forget_bare_disconnect(self):
        """remove_account must NOT use fire-and-forget client.disconnect()."""
        idx = self.src.find("def remove_account(self, account_id: str) -> bool:")
        self.assertGreater(idx, -1, "remove_account must exist")
        # The next def boundary.
        next_def = self.src.find("\n    def ", idx + 10)
        self.assertGreater(next_def, -1, "must find next def")
        window = self.src[idx:next_def]
        # The OLD pattern was: supervised_create_task(client.disconnect(), ...)
        # The NEW pattern schedules _cleanup_client_async instead.
        self.assertNotIn("supervised_create_task(\n                    client.disconnect()",
                          window,
                          "BUG-5: remove_account must not fire-and-forget client.disconnect()")

    def test_remove_account_pops_client_before_cleanup(self):
        """remove_account must pop the client from _clients BEFORE scheduling cleanup."""
        idx = self.src.find("def remove_account(self, account_id: str) -> bool:")
        self.assertGreater(idx, -1, "remove_account must exist")
        window = self.src[idx:idx + 1200]
        pop_idx = window.find("self._clients.pop(account_id, None)")
        # Find the actual CALL (self._cleanup_client_async(...), not the docstring mention.
        cleanup_idx = window.find("self._cleanup_client_async(")
        self.assertGreater(pop_idx, -1, "must pop client from _clients")
        self.assertGreater(cleanup_idx, -1, "must call self._cleanup_client_async")
        self.assertLess(pop_idx, cleanup_idx,
                        "BUG-5: client must be popped from _clients BEFORE cleanup "
                        "(so the helper holds the only reference)")


# ===========================================================================
# SECTION B — BUG-5: set_disabled uses _cleanup_client_async (no bare disconnect)
# ===========================================================================
class TestBUG5SetDisabledCleanup(unittest.TestCase):
    """v97.97 BUG-5: set_disabled must schedule _cleanup_client_async."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_MTPROTO_PATH)

    def test_set_disabled_calls_cleanup_helper(self):
        """set_disabled must call _cleanup_client_async with label='set_disabled'."""
        idx = self.src.find("def set_disabled(self, account_id: str, disabled: bool) -> bool:")
        self.assertGreater(idx, -1, "set_disabled must exist")
        window = self.src[idx:idx + 1200]
        self.assertIn("_cleanup_client_async", window,
                      "BUG-5: set_disabled must call _cleanup_client_async")
        self.assertIn('label="set_disabled"', window,
                      "BUG-5: set_disabled must pass label='set_disabled'")

    def test_set_disabled_no_fire_and_forget_bare_disconnect(self):
        """set_disabled must NOT use fire-and-forget client.disconnect()."""
        idx = self.src.find("def set_disabled(self, account_id: str, disabled: bool) -> bool:")
        self.assertGreater(idx, -1, "set_disabled must exist")
        next_def = self.src.find("\n    def ", idx + 10)
        self.assertGreater(next_def, -1, "must find next def")
        window = self.src[idx:next_def]
        self.assertNotIn("supervised_create_task(\n                    client.disconnect()",
                          window,
                          "BUG-5: set_disabled must not fire-and-forget client.disconnect()")


# ===========================================================================
# SECTION C — BUG-5: _cleanup_client_async helper structure
# ===========================================================================
class TestBUG5CleanupHelperStructure(unittest.TestCase):
    """v97.97 BUG-5: _cleanup_client_async must apply the v97.96 BUG-1 pattern."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_MTPROTO_PATH)

    def test_cleanup_helper_exists(self):
        """_cleanup_client_async method must exist on UserbotCluster."""
        idx = self.src.find("async def _cleanup_client_async(self, account_id: str, client: Any,")
        self.assertGreater(idx, -1,
                           "BUG-5: _cleanup_client_async method must exist")

    def test_cleanup_helper_calls_forcibly_cancel(self):
        """_cleanup_client_async must call _forcibly_cancel_telethon_tasks BEFORE disconnect."""
        idx = self.src.find("async def _cleanup_client_async(self, account_id: str, client: Any,")
        self.assertGreater(idx, -1, "_cleanup_client_async must exist")
        # Window for the helper body (up to the next async def / class boundary).
        next_def = self.src.find("\n    async def ", idx + 20)
        if next_def == -1:
            next_def = self.src.find("\n    def ", idx + 20)
        self.assertGreater(next_def, -1, "must find helper boundary")
        window = self.src[idx:next_def]
        cancel_idx = window.find("_forcibly_cancel_telethon_tasks")
        disconnect_idx = window.find("await client.disconnect()")
        release_idx = window.find("self._release_client_session(account_id, client)")
        self.assertGreater(cancel_idx, -1, "must call _forcibly_cancel_telethon_tasks")
        self.assertGreater(disconnect_idx, -1, "must call client.disconnect()")
        self.assertGreater(release_idx, -1, "must call _release_client_session")
        # Order: forcibly_cancel BEFORE disconnect BEFORE release.
        self.assertLess(cancel_idx, disconnect_idx,
                        "BUG-5: _forcibly_cancel must come BEFORE disconnect")
        self.assertLess(disconnect_idx, release_idx,
                        "BUG-5: disconnect must come BEFORE _release_client_session")

    def test_cleanup_helper_skips_global_mtproto_client(self):
        """_cleanup_client_async must NOT disconnect the global _mtproto_client."""
        idx = self.src.find("async def _cleanup_client_async(self, account_id: str, client: Any,")
        self.assertGreater(idx, -1, "_cleanup_client_async must exist")
        next_def = self.src.find("\n    async def ", idx + 20)
        if next_def == -1:
            next_def = self.src.find("\n    def ", idx + 20)
        window = self.src[idx:next_def]
        self.assertIn("if client is _mtproto_client:", window,
                      "BUG-5: helper must guard against disconnecting the global _mtproto_client")
        self.assertIn("ACCOUNT_DISCONNECT_SKIP_GLOBAL", window,
                      "BUG-5: helper must log ACCOUNT_DISCONNECT_SKIP_GLOBAL for global client")

    def test_cleanup_helper_awaits_disconnected_drain(self):
        """_cleanup_client_async must await the 'disconnected' drain future (like disconnect_account)."""
        idx = self.src.find("async def _cleanup_client_async(self, account_id: str, client: Any,")
        self.assertGreater(idx, -1, "_cleanup_client_async must exist")
        next_def = self.src.find("\n    async def ", idx + 20)
        if next_def == -1:
            next_def = self.src.find("\n    def ", idx + 20)
        window = self.src[idx:next_def]
        self.assertIn('getattr(client, "disconnected", None)', window,
                      "BUG-5: helper must get the 'disconnected' drain future")
        self.assertIn("asyncio.wait_for(disc, timeout=10)", window,
                      "BUG-5: helper must await the drain with 10s timeout (like disconnect_account)")


# ===========================================================================
# SECTION D — BUG-6: orphan detector excludes known-live global _mtproto_client
# ===========================================================================
class TestBUG6OrphanDetectorExcludesGlobalClient(unittest.TestCase):
    """v97.97 BUG-6: orphan detector must exclude known-live global client tasks."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_MTPROTO_PATH)

    def test_orphan_detector_excludes_global_snapshot_ids(self):
        """_log_orphaned_telethon_tasks must build _known_global_ids
        from the global _mtproto_client's snapshot and skip matching tasks."""
        idx = self.src.find("async def _log_orphaned_telethon_tasks(client: Any, snapshot: list,")
        self.assertGreater(idx, -1, "_log_orphaned_telethon_tasks must exist")
        next_def = self.src.find("\nasync def ", idx + 20)
        if next_def == -1:
            next_def = self.src.find("\ndef ", idx + 20)
        window = self.src[idx:next_def] if next_def > -1 else self.src[idx:idx + 3000]
        self.assertIn("_known_global_ids", window,
                      "BUG-6: must compute _known_global_ids")
        self.assertIn("_mtproto_client", window,
                      "BUG-6: must reference _mtproto_client")
        self.assertIn("id(t) in _known_global_ids", window,
                      "BUG-6: must skip tasks whose id is in the global snapshot")

    def test_orphan_detector_checks_global_is_live(self):
        """The detector must verify the global client is connected before excluding."""
        idx = self.src.find("async def _log_orphaned_telethon_tasks(client: Any, snapshot: list,")
        self.assertGreater(idx, -1, "_log_orphaned_telethon_tasks must exist")
        next_def = self.src.find("\nasync def ", idx + 20)
        if next_def == -1:
            next_def = self.src.find("\ndef ", idx + 20)
        window = self.src[idx:next_def] if next_def > -1 else self.src[idx:idx + 3000]
        self.assertIn("_global_is_live", window,
                      "BUG-6: must compute _global_is_live flag")
        self.assertIn("_mtproto_client.is_connected()", window,
                      "BUG-6: must check _mtproto_client.is_connected() before excluding")
        self.assertIn("client is not _mtproto_client", window,
                      "BUG-6: must NOT exclude when the client being cancelled IS the global client")

    def test_orphan_detector_excludes_global_owner_via_frame(self):
        """The detector must also exclude tasks whose cr_frame.f_locals['self']
        is _mtproto_client (defensive — handles edge cases where the snapshot
        was lost)."""
        idx = self.src.find("async def _log_orphaned_telethon_tasks(client: Any, snapshot: list,")
        self.assertGreater(idx, -1, "_log_orphaned_telethon_tasks must exist")
        next_def = self.src.find("\nasync def ", idx + 20)
        if next_def == -1:
            next_def = self.src.find("\ndef ", idx + 20)
        window = self.src[idx:next_def] if next_def > -1 else self.src[idx:idx + 3000]
        self.assertIn('f_locals.get("self")', window,
                      "BUG-6: must inspect cr_frame.f_locals['self'] for owner")
        self.assertIn("_owner_client is _mtproto_client", window,
                      "BUG-6: must check if owner is _mtproto_client via frame inspection")
        self.assertIn('"global_mtproto_client"', window,
                      "BUG-6: must label global-client tasks as 'global_mtproto_client'")

    def test_orphan_detector_message_updated(self):
        """The log message must mention the v97.97 exclusion (no longer
        claims all alive tasks are 'leaks from PRIOR reconnects')."""
        idx = self.src.find("MTPROTO_ORPHAN_TELETHON_TASKS_DETECTED label=%s count=%d")
        self.assertGreater(idx, -1, "orphan-detector log marker must exist")
        # Window covering the full log message (multi-line f-string).
        window = self.src[idx:idx + 600]
        self.assertIn("known-live global", window,
                      "BUG-6: message must mention 'known-live global' exclusion")
        self.assertIn("v97.97", window,
                      "BUG-6: message must reference the v97.97 fix")


# ===========================================================================
# SECTION E — v97.95/v97.96 regression (preserve prior fixes)
# ===========================================================================
class TestPriorFixesPreserved(unittest.TestCase):
    """v97.97 must NOT weaken the v97.95 VC fix or the v97.96 SQLite fix."""

    @classmethod
    def setUpClass(cls):
        cls.mtproto = _read_source(_MTPROTO_PATH)
        cls.voicechat = _read_source(_VOICECHAT_PATH)

    def test_v97_95_record_evidence_absent_sites_preserved(self):
        """The 3 v97.95 fix sites in voicechat.py must still call
        record_evidence_absent / mark_unknown on the coordinator."""
        # Site 1: participation reconcile positive-absence.
        self.assertIn("record_evidence_absent", self.voicechat,
                      "v97.95 fix site 1 (record_evidence_absent) must be preserved")
        # Site 2/3: stale-joined-record + reconcile-timeout -> mark_unknown.
        self.assertIn("mark_unknown", self.voicechat,
                      "v97.95 fix sites 2/3 (mark_unknown) must be preserved")

    def test_v97_96_forcibly_cancel_in_connect_account_preserved(self):
        """connect_account must still call _forcibly_cancel_telethon_tasks
        in the 4 paths (BUG-1 from v97.96)."""
        # The cluster_reconnect_stale label is THE core v97.96 BUG-1 fix.
        self.assertIn("cluster_reconnect_stale", self.mtproto,
                      "v97.96 BUG-1 fix (cluster_reconnect_stale) must be preserved")
        self.assertIn("cluster_reconnect_getme_fail", self.mtproto,
                      "v97.96 BUG-1 fix (cluster_reconnect_getme_fail) must be preserved")
        self.assertIn("cluster_reconnect_except", self.mtproto,
                      "v97.96 BUG-1 fix (cluster_reconnect_except) must be preserved")

    def test_v97_96_disconnect_account_forcibly_cancel_preserved(self):
        """disconnect_account must still call _forcibly_cancel_telethon_tasks
        (BUG-3 from v97.96)."""
        idx = self.mtproto.find("async def disconnect_account(self, account_id: str) -> str:")
        self.assertGreater(idx, -1, "disconnect_account must exist")
        next_def = self.mtproto.find("\n    async def ", idx + 20)
        if next_def == -1:
            next_def = self.mtproto.find("\n    def ", idx + 20)
        window = self.mtproto[idx:next_def]
        self.assertIn("_forcibly_cancel_telethon_tasks", window,
                      "v97.96 BUG-3 fix (disconnect_account forcibly_cancel) must be preserved")

    def test_v97_96_fail_count_increment_preserved(self):
        """_classify_connect_exception must still increment fail_count (BUG-2 from v97.96)."""
        self.assertIn("ACCOUNT_SQLITE_LOCKED_BACKOFF", self.mtproto,
                      "v97.96 BUG-2 logging marker must be preserved")
        # The fail_count increment must still be present.
        self.assertIn('acc["fail_count"]', self.mtproto,
                      "v97.96 BUG-2 fail_count increment must be preserved")


# ===========================================================================
# SECTION F — Version bump
# ===========================================================================
class TestVersionBump(unittest.TestCase):
    """v97.97 must bump the version string consistently."""

    @classmethod
    def setUpClass(cls):
        cls._init_src = _read_source(_INIT_PATH)
        cls._bootstrap_src = _read_source(_BOOTSTRAP_PATH)

    def test_init_version_is_v97_97(self):
        # v99: the version string tracks the CURRENT artifact (v99.03).
        self.assertIn("v99.11", self._init_src,
                      "__init__.py must declare the current version")

    def test_bootstrap_version_is_v97_97(self):
        self.assertIn("version={_v9812_pkg_version}", self._bootstrap_src,  # v99: derivation site
                      "bootstrap.py DEPLOYMENT_IDENTITY must declare v97.97")

    def test_no_v97_96_version_strings_remain(self):
        """The VERSION STRINGS (not descriptive comments) must not still
        reference v97.96 (the previous version) in __init__.py / bootstrap.py."""
        self.assertNotIn('__bot_version__ = "v97.97"', self._init_src,
                          "__init__.py must not still declare v97.96")
        self.assertNotIn("version=v97.97", self._bootstrap_src,
                          "bootstrap.py must not still declare v97.96")


if __name__ == "__main__":
    unittest.main()
