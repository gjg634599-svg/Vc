"""Regression tests for v98.01 forensic upgrade — 24/7 VC production readiness.

These tests verify the SOURCE-PROVEN defects fixed in v98.01, addressing the
five remaining VC/lifecycle risks identified in the post-v98.00 production
audit:

  FIX-G (ISSUE 1 — PyTgCalls passive-disconnect / liveness, SOURCE-PROVEN):
    PyTgCallsBackend.start() created ``PyTgCalls(client)`` + ``.start()`` but
    NEVER registered any lifecycle callbacks (``on_stream_end``,
    ``on_connection_state``, etc.). The only ``on_stream_end`` reference in
    the v98.00 source (voicechat.py:20801) was in the talkative audio-capture
    path and MISUSED it as an audio-frame callback. For regular Join-All VC
    joins, NO callback fired when PyTgCalls' transport died passively
    (server-side kick / network drop / VC ended without exception). The
    container object persisted (bookkeeping), ``verify_joined`` returned True
    (FIX-H), and the bot had no notification → stale container blocked rejoin.

    FIX-G: register lifecycle callbacks after ``.start()`` (capability-probed,
    try/except — no-op if the installed PyTgCalls exposes none of them); track
    ``transport_dead`` chats in ``_vc_transport_dead_chats`` (TTL-evicted);
    consult in ``verify_joined`` / ``vc_verify_target`` so a passive-disconnect
    is detected AS RELIABLY AS THE PyTgCalls API PERMITS, while preserving
    UNKNOWN-safety (transport_dead is UNKNOWN evidence, NEVER destructive).

  FIX-H (ISSUE 2 — verify_joined trusts container presence, SOURCE-PROVEN):
    ``verify_joined`` (voicechat.py:4011-4020) returned True IMMEDIATELY when
    ``backend_has_target is True`` (calls container has the chat), SKIPPING the
    Telegram cross-check. A stale container object (transport dead but not
    GC'd) → verify_joined said True → bot thought joined → never triggered
    rejoin → stale object blocked rejoin indefinitely.

    FIX-H: when ``backend_has_target is True`` AND valid call_id+access_hash
    AND not corroborated in the last 60s AND not transport_dead → call a
    LIGHTWEIGHT Telegram corroboration (GetGroupCallRequest limit=1, single
    RPC). Map: call exists → True (corroborated); GroupcallInvalidError → None
    (stale container, UNKNOWN — let reconcile handle via Case C); FloodWait/
    timeout/exception → True (preserve, don't destroy). Container presence is
    now NECESSARY but NOT SUFFICIENT for definitive JOINED.

  FIX-I (ISSUE 3 — VC_PARTICIPATION_UNKNOWN / truncated participant scans,
  SOURCE-PROVEN):
    ``vc_check_telegram_participation`` did bounded pagination (up to 10 pages
    × 200 participants = 2000 max). For VCs >2000 participants OR when the bot
    was muted/invisible/restricted, the scan was INCOMPLETE → returned
    "unknown" forever, never converging. A chat stuck "unknown" forever never
    got recovered or cleaned.

    FIX-I: when the broad scan is incomplete, do a TARGETED single-user query
    — ``GetGroupParticipantsRequest(call=call_input, ids=[my_id])``. This
    queries ONLY our own user_id. Telegram's response is AUTHORITATIVE for our
    specific user — NO truncation possible (single-id query). If our
    participant object is returned → "present"; if empty (and no exception) →
    "absent" (authoritative negative). Breaks the "stuck UNKNOWN forever"
    loop for large VCs.

  FIX-J (ISSUE 4 — both-account simultaneous leave/rejoin/failover,
  SOURCE-PROVEN):
    ``_vc_cleanup_stale_backend_call`` (voicechat.py:5557) called
    ``vc_get_backend()`` (the GLOBAL backend) WITHOUT consulting
    ``_vc_active_join_backends_by_chat``. If chat X was joined by a PER-ACCOUNT
    backend (Account B), this called Account A's ``_leave_target(chat_id)`` —
    a no-op (A's container doesn't have X) OR, if both accounts had a call
    object for X, it destroyed A's call but B's stale object remained.
    Cross-account cleanup corruption (Issue 4d).

    FIX-J: resolve the OWNER backend first (per-chat ownership dict, BOTH ID
    forms); fall back to global ONLY if no owner recorded. Also resolve the
    OWNER's calls container (not the global one). Additionally, switch the
    Join-All reconnect path (voicechat.py:7496) from
    ``_telethon_drain_and_reconnect_raw`` (UNLOCKED) to
    ``_telethon_drain_and_reconnect`` (LOCKED) so concurrent RPCs on the same
    cluster client drain before the reconnect disconnects (BUG-A5-1).

  FIX-K (ISSUE 5 — cold-path TelegramClient creation / MTProto robustness,
  SOURCE-PROVEN via A5 subagent):
    The ``_cluster_reconnect_loop`` (bootstrap.py:922) retried ONLY
    ``STATUS_CONNECTION_FAILED`` accounts. Accounts in ``STATUS_FLOODWAIT``
    (whose wait had expired but whose status was never transitioned back) and
    ``STATUS_DISCONNECTED`` (set during shutdown or initial connect failure)
    were NEVER retried — they sat silently dead forever.

    FIX-K: extend the loop to retry all three retryable states
    (STATUS_CONNECTION_FAILED + STATUS_FLOODWAIT-after-expiry +
    STATUS_DISCONNECTED). The FloodWait retry checks ``floodwait_until <= now``
    before retrying. SAFE: if the retry FloodWaits again, connect_account sets
    a new floodwait_until; if it succeeds, status → HEALTHY.

  INVARIANT (v98.01): all the v97.30-v98.00 invariants are PRESERVED:
    * UNKNOWN is non-destructive (transport_dead is UNKNOWN, never LEFT).
    * API failure is not absence (corroboration failure → preserve).
    * Container presence is not physical participation (now corroborated).
    * Container absence is not automatically LEFT (reconcile via Case C).
    * Cleanup is idempotent (_leave_target catches exceptions).
    * Join is idempotent (container pre-check + registry state).
    * Recovery is deterministic (FloodWait retried after expiry).
    * FloodWait never crashes Join-All (FIX-F preserved from v98.00).
    * One account must not destroy another's state (FIX-J account-aware).

  All v97.30-v98.00 fixes are PRESERVED VERBATIM. voicechat.py + bootstrap.py
  are the ONLY source files modified (plus version bumps in __init__.py);
  changes are ADDITIVE (new helpers + new branches + locked-variant switch +
  reconnect-loop status extension + version bumps); no existing behavior
  weakened.

  HONESTY NOTE: PyTgCalls 2.3.3 is NOT installed in the build sandbox. The
  FIX-G callback registration is capability-probed (tries on_stream_end /
  on_call_end / on_killed / on_connection_state / on_connect / on_disconnect
  via both decorator and direct-register patterns) and silently no-ops if
  none are available. Runtime validation of the actual callback firing
  requires a real production soak (NOT performed in this sandbox — no Telegram
  credentials). All FIX-G/H/I/J/K claims are SOURCE-PROVEN + TEST-PROVEN
  (source-text + structural + invariant tests); none are RUNTIME-PROVEN for
  the new v98.01 paths (the v98.00 RUNTIME-PROVEN fixes are preserved).
"""

from __future__ import annotations

import asyncio
import hashlib
import os
import time
import unittest

_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG_ROOT = os.path.dirname(_HERE)
_VOICECHAT = os.path.join(_PKG_ROOT, "mediagrab_bot", "voicechat.py")
_INIT = os.path.join(_PKG_ROOT, "mediagrab_bot", "__init__.py")
_BOOTSTRAP = os.path.join(_PKG_ROOT, "mediagrab_bot", "bootstrap.py")
_MTPROTO = os.path.join(_PKG_ROOT, "mediagrab_bot", "mtproto.py")


def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def _read_voicechat() -> str:
    return _read(_VOICECHAT)


def _read_init() -> str:
    return _read(_INIT)


def _read_bootstrap() -> str:
    return _read(_BOOTSTRAP)


def _sha256(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


# ---------------------------------------------------------------------------
# Section A — FIX-G: PyTgCalls lifecycle callbacks + transport_dead tracking
# ---------------------------------------------------------------------------


class TestVC801FixGLifecycleCallbacks(unittest.TestCase):
    """FIX-G: PyTgCalls lifecycle callback registration + transport_dead."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_fix_g_marker_present(self):
        self.assertIn("v98.01 FIX-G", self.src)
        self.assertIn("ISSUE 1 — PyTgCalls passive-disconnect", self.src)

    def test_transport_dead_state_dict_defined(self):
        self.assertIn("_vc_transport_dead_chats: dict[int, float] = {}", self.src)
        self.assertIn("_VC_TRANSPORT_DEAD_TTL_SECONDS = 300", self.src)

    def test_mark_clear_is_helpers_defined(self):
        self.assertIn("def _vc_mark_transport_dead(chat_id: int) -> None:", self.src)
        self.assertIn("def _vc_clear_transport_dead(chat_id: int) -> None:", self.src)
        self.assertIn("def _vc_is_transport_dead(chat_id: int) -> bool:", self.src)

    def test_register_lifecycle_callbacks_function_defined(self):
        self.assertIn(
            "def _vc_register_lifecycle_callbacks(backend: Any) -> None:", self.src
        )
        # v98.03 FIX-W NOTE: the original v98.01 FIX-G probed for the WRONG
        # callback names (on_stream_end / on_call_end / on_killed /
        # on_connection_state / on_connect / on_disconnect) on the WRONG
        # object (the GroupCallFactory). PyTgCalls 2.x exposes ONLY
        # on_network_status_changed and on_participant_list_updated on the
        # PER-CALL GroupCall instance, not on the factory. v98.03 FIX-W
        # rewrote this function to probe the REAL callback names. This test
        # now asserts on the corrected intent (passive-disconnect callback
        # registered via the real PyTgCalls 2.x API).
        self.assertIn('"on_network_status_changed"', self.src,
                      "FIX-W (supersedes FIX-G): must capability-probe the real "
                      "PyTgCalls 2.x on_network_status_changed callback")
        # The OLD wrong callback names must NOT appear in the function body
        # (they may appear in the docstring as historical explanation).
        fn_start = self.src.find("def _vc_register_lifecycle_callbacks(backend")
        self.assertGreater(fn_start, 0, "function not found")
        # Function body extends to the next top-level def.
        next_def = self.src.find("\ndef ", fn_start + 1)
        fn_body = self.src[fn_start:next_def if next_def > 0 else fn_start + 10000]
        for _old_cb in ("on_stream_end", "on_call_end", "on_killed",
                        "on_connection_state", "on_connect", "on_disconnect"):
            # Assert the OLD names are NOT iterated over as the probe list.
            old_iter = f'for _attr in ("{_old_cb}"'
            self.assertNotIn(old_iter, fn_body,
                             f"FIX-W must NOT iterate over the OLD wrong callback name {_old_cb}")

    def test_register_lifecycle_called_in_backend_start(self):
        # The backend.start() must call _vc_register_lifecycle_callbacks(self)
        # AFTER await self._pytgcalls.start().
        self.assertIn("await self._pytgcalls.start()", self.src)
        self.assertIn("_vc_register_lifecycle_callbacks(self)", self.src)

    def test_register_lifecycle_is_capability_probed(self):
        # Must be wrapped in try/except — no assumption the callbacks exist.
        # The registration loop must guard each callback with try/except.
        self.assertIn("VC_PYTGCALLS_CALLBACK_REGISTER_FAILED", self.src)
        self.assertIn("VC_PYTGCALLS_NO_LIFECYCLE_CALLBACKS", self.src)

    def test_transport_dead_never_destructive_docstring(self):
        # The docstring + comments must explicitly state transport_dead is
        # UNKNOWN evidence, NEVER directly causing a LEFT.
        self.assertIn("UNKNOWN evidence", self.src)
        self.assertIn("MUST NEVER directly", self.src)
        self.assertIn("cause a real VC leave", self.src)

    def test_transport_dead_consulted_in_verify_joined(self):
        # verify_joined must consult _vc_is_transport_dead before returning
        # True from container presence alone.
        self.assertIn("if _vc_is_transport_dead(chat_id):", self.src)
        self.assertIn("VC_JOIN_EVIDENCE_SUSPECT", self.src)

    def test_transport_dead_cleared_on_case_c(self):
        # vc_verify_target Case C (genuine absence) must clear the mark.
        self.assertIn("if _vc_was_transport_dead:", self.src)
        self.assertIn("_vc_clear_transport_dead(chat_id)", self.src)
        self.assertIn("VC_TRANSPORT_DEAD_CLEARED", self.src)

    def test_transport_dead_cleared_on_join_success(self):
        # A fresh successful join must clear the mark (transport is alive).
        # Find the VC_JOIN_SUCCESS context.
        idx = self.src.find("VC_JOIN_SUCCESS chat_id=%s call_id=%s strategy=%s")
        self.assertGreater(idx, 0, "VC_JOIN_SUCCESS log must exist")
        # Look in the chars BEFORE the log for the clear call.
        # v98.07 test maintenance: 1500 → 2800 — the v98.07 FIX-RR per-account
        # accounting block sits between _vc_clear_transport_dead and the
        # VC_JOIN_SUCCESS log line; the CONTRACT (clear before the success
        # log) is unchanged.
        # v98.13 test maintenance: 2800 → 6000 — the v98.13 §GATE
        # (Telegram-side participant verification + unverified branch)
        # sits between the clear block and the success log; the CONTRACT
        # (clear before the success log) is unchanged.
        # v99 test maintenance: the join() body is now the compact
        # pipeline-delegation site; both id forms (marked + raw) are
        # cleared before the log — the CONTRACT is unchanged.
        preceding = self.src[max(0, idx - 6000):idx]
        self.assertIn("_vc_clear_transport_dead(marked)", preceding,
                      "FIX-G must clear transport_dead before VC_JOIN_SUCCESS log")
        self.assertIn("_vc_clear_transport_dead(raw)", preceding,
                      "FIX-G must clear transport_dead (raw form) before the success log")


class TestVC801FixGTransportDeadSemantics(unittest.TestCase):
    """Functional tests for the transport_dead TTL + mark/clear/is helpers."""

    def setUp(self):
        # Import the module to access the real functions. We import
        # voicechat lazily and access the module-level helpers directly.
        # These are pure-Python functions (no Telegram required).
        import sys
        _pkg_root = _PKG_ROOT
        if _pkg_root not in sys.path:
            sys.path.insert(0, _pkg_root)
        # We need the module-level functions. Use a minimal import that
        # doesn't trigger the full bot bootstrap (voicechat is large but
        # imports are lazy where possible). If import fails (missing deps),
        # fall back to source-text assertions (already covered above).
        try:
            import importlib
            from mediagrab_bot import voicechat as _vc
            self._vc = _vc
            self._can_import = True
        except Exception:
            self._vc = None
            self._can_import = False

    def test_mark_then_is_transport_dead_returns_true(self):
        if not self._can_import:
            self.skipTest("voicechat import unavailable (missing deps) — source-text test covers this")
        _vc = self._vc
        # Reset state.
        _vc._vc_transport_dead_chats.clear()
        _vc._vc_mark_transport_dead(123456)
        self.assertTrue(_vc._vc_is_transport_dead(123456))

    def test_clear_makes_is_transport_dead_false(self):
        if not self._can_import:
            self.skipTest("voicechat import unavailable — source-text test covers this")
        _vc = self._vc
        _vc._vc_transport_dead_chats.clear()
        _vc._vc_mark_transport_dead(789012)
        self.assertTrue(_vc._vc_is_transport_dead(789012))
        _vc._vc_clear_transport_dead(789012)
        self.assertFalse(_vc._vc_is_transport_dead(789012))

    def test_stale_mark_evicted(self):
        if not self._can_import:
            self.skipTest("voicechat import unavailable — source-text test covers this")
        _vc = self._vc
        _vc._vc_transport_dead_chats.clear()
        # Manually insert a STALE mark (older than TTL).
        _vc._vc_transport_dead_chats[999999] = time.monotonic() - 99999
        self.assertFalse(_vc._vc_is_transport_dead(999999))
        # The stale mark must have been evicted.
        self.assertNotIn(999999, _vc._vc_transport_dead_chats)

    def test_mark_non_integer_no_crash(self):
        if not self._can_import:
            self.skipTest("voicechat import unavailable — source-text test covers this")
        _vc = self._vc
        # Must not crash on bad input.
        _vc._vc_mark_transport_dead("not_an_int")  # type: ignore[arg-type]
        _vc._vc_clear_transport_dead("not_an_int")  # type: ignore[arg-type]
        self.assertFalse(_vc._vc_is_transport_dead("not_an_int"))  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Section B — FIX-H: verify_joined Telegram corroboration
# ---------------------------------------------------------------------------


class TestVC801FixHVerifyJoinedCorroboration(unittest.TestCase):
    """FIX-H: verify_joined no longer trusts container presence alone."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_fix_h_marker_present(self):
        self.assertIn("v98.01 FIX-H", self.src)
        self.assertIn("ISSUE 2 — verify_joined trusts container presence", self.src)

    def test_corroboration_cache_defined(self):
        self.assertIn("_vc_corroboration_cache: dict[int, float] = {}", self.src)
        self.assertIn("_VC_CORROBORATION_THROTTLE_SECONDS = 60", self.src)

    def test_telegram_call_still_valid_function_defined(self):
        self.assertIn(
            "async def _vc_telegram_call_still_valid(", self.src
        )
        # Must use GetGroupCallRequest with limit=1 (lightweight, single RPC).
        self.assertIn("GetGroupCallRequest(call=call_input, limit=1)", self.src)

    def test_corroboration_returns_three_states(self):
        # The function must return True (call exists) / False (call gone) /
        # None (UNKNOWN — FloodWait/RPC/timeout).
        # Find the function body and assert each return path.
        idx = self.src.find("async def _vc_telegram_call_still_valid(")
        self.assertGreater(idx, 0)
        # v98.12 TEST-MECHANISM CORRECTION (documented): window 4000 -> 5800 —
        # the v98.12 §6 owner-account client-resolution block sits above the
        # return paths; the INVARIANT (tri-state returns) is unchanged.
        body = self.src[idx:idx + 5800]
        self.assertIn("return True", body)  # call exists
        self.assertIn("return False", body)  # GroupcallInvalidError
        self.assertIn("return None", body)   # FloodWait / RPC / timeout

    def test_corroboration_groupcallinvalid_is_not_destructive(self):
        # The GroupcallInvalidError path must return None (UNKNOWN), NOT False,
        # in verify_joined's caller — the corroboration function returns False
        # (call gone), but verify_joined maps it to None (UNKNOWN — let
        # reconcile handle via Case C). This is NON-DESTRUCTIVE.
        # v98.12 TEST-MECHANISM CORRECTION (documented): the branch now
        # runs the §4/§5 evidence gate (_vc_call_gone_evidence_check) BEFORE
        # deciding — the window widened 2000→3600 and the needles track the
        # v98.12 structure: refreshed→preserve, strong_negative→None (UNKNOWN,
        # reconcile confirms Case C), weak→preserve. The invariant (this
        # branch is NON-DESTRUCTIVE without strong evidence) is STRENGTHENED.
        # v99.05 RC-F3 derivation: the refreshed branch gained the
        # call-alive-is-not-participant-proof comment + return None (v98.13
        # §VERIF rule applied to the refreshed verdict) — window 3600→5200
        # (the WEAK/INCONCLUSIVE "MUST NOT destroy" needle moved further).
        idx = self.src.find("if _corr is False:")
        self.assertGreater(idx, 0, "verify_joined must handle _corr is False")
        # The branch has a large comment block; use a generous window.
        following = self.src[idx:idx + 5200]
        self.assertIn("_vc_call_gone_evidence_check(", following)
        self.assertIn("return None", following)  # strong negative only
        self.assertIn("reconcile confirms Case C", following)
        self.assertIn("MUST NOT destroy", following)

    def test_verify_joined_no_longer_short_circuits_on_container_alone(self):
        # The v98.00 early-return True at the container-presence branch must
        # be GONE. The new code must consult transport_dead + corroboration
        # BEFORE returning True.
        # The old pattern was: "return True" immediately after
        # "backend_has_target is True:". The new pattern has the FIX-H comment.
        self.assertIn("if backend_has_target is True:", self.src)
        # The new branch must NOT immediately return True — it must consult
        # transport_dead + corroboration first.
        idx = self.src.find("if backend_has_target is True:")
        following = self.src[idx:idx + 300]
        self.assertNotIn("return True  # BACKEND_CONFIRMED", following,
                         "v98.00 short-circuit must be removed")
        self.assertIn("v98.01 FIX-H", following)

    def test_corroboration_floodwait_is_preserve_not_destroy(self):
        # FloodWait during corroboration must return True (preserve) OR None
        # (UNKNOWN), NEVER False (destroy).
        idx = self.src.find("async def _vc_telegram_call_still_valid(")
        body = self.src[idx:idx + 4000]
        # Find the FloodWait handler in the corroboration function.
        fw_idx = body.find("except FloodWaitError")
        self.assertGreater(fw_idx, 0, "must handle FloodWaitError")
        fw_block = body[fw_idx:fw_idx + 400]
        self.assertIn("return None", fw_block,
                      "FloodWait must return None (UNKNOWN, non-destructive)")


# ---------------------------------------------------------------------------
# Section C — FIX-I: targeted GetGroupParticipantsRequest for truncated VCs
# ---------------------------------------------------------------------------


class TestVC801FixITargetedParticipantQuery(unittest.TestCase):
    """FIX-I: targeted single-user query when broad scan is truncated."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_fix_i_marker_present(self):
        self.assertIn("v98.01 FIX-I", self.src)
        self.assertIn("ISSUE 3 — VC_PARTICIPATION_UNKNOWN / truncated", self.src)

    def test_targeted_query_uses_ids_my_id(self):
        # v99.05 RC-F4b contract: the targeted query resolves our OWN
        # InputPeer explicitly (client.get_input_entity("me") — always
        # resolvable on an authorized client) and passes it in ids, with
        # the raw-int fallback preserved. Single-user, no pagination, no
        # truncation possible.
        self.assertIn(
            "GetGroupParticipantsRequest(\n                call=call_input, ids=_targeted_ids,",
            self.src,
        )
        self.assertIn('client.get_input_entity("me")', self.src)
        self.assertIn("_targeted_ids: list = [int(my_id)]", self.src)

    def test_targeted_present_path_returns_present(self):
        self.assertIn("VC_PARTICIPATION_PRESENT", self.src)
        self.assertIn("via TARGETED_QUERY", self.src)
        self.assertIn("RC-F1 peer-matching", self.src)
        self.assertIn("return \"present\"", self.src)

    def test_targeted_absent_path_returns_absent(self):
        self.assertIn("VC_PARTICIPATION_ABSENT_VIA_TARGETED", self.src)
        self.assertIn("authoritative absence", self.src)
        self.assertIn("return \"absent\"", self.src)

    def test_targeted_query_only_runs_when_broad_scan_incomplete(self):
        # The guard must be `if not search_complete and my_id is not None:`.
        self.assertIn("if not search_complete and my_id is not None:", self.src)

    def test_targeted_floodwait_is_non_destructive(self):
        # FloodWait in the targeted query must return unknown (fall through),
        # NEVER absent.
        idx = self.src.find("VC_PARTICIPATION_TARGETED_FLOODWAIT")
        self.assertGreater(idx, 0, "must log targeted FloodWait")
        # The targeted FloodWait handler must NOT return absent.
        # Find the except FloodWaitError block in the FIX-I section.
        fix_i_idx = self.src.find("v98.01 FIX-I (ISSUE 3")
        self.assertGreater(fix_i_idx, 0)
        # v99 test maintenance: 6000 -> 12000 — the v99 §3 identity
        # resolution block sits between the FIX-I marker and the handler;
        # the CONTRACT (FloodWait never returns absent) is unchanged.
        # v99.02 test maintenance: 12000 -> 16000 — the v99.02 FIX-2
        # no-match absent-streak block (RC-2 convergence) also sits between
        # the marker and the handler; the CONTRACT is still unchanged.
        fix_i_body = self.src[fix_i_idx:fix_i_idx + 16000]
        fw_idx = fix_i_body.find("except FloodWaitError as _t_exc:")
        self.assertGreater(fw_idx, 0, "FIX-I must handle FloodWaitError")
        # The 200 chars after the FloodWait handler must not contain
        # "return \"absent\"" (FloodWait is never absence).
        fw_block = fix_i_body[fw_idx:fw_idx + 200]
        self.assertNotIn("return \"absent\"", fw_block,
                          "FloodWait must NEVER return absent (non-destructive)")

    def test_targeted_groupcallinvalid_returns_absent(self):
        # v99.05 RC-F4 SEMANTICS CHANGE (intentional — mission §13
        # STALE_CALL): GroupcallInvalid on the targeted query means the
        # queried (id, access_hash) pair is NOT a live call — a STALE
        # CALL IDENTITY, NOT absence proof.  The historical mapping to
        # absent conflated STALE_CALL with ABSENT (the 2026-09-12
        # production run showed how absence claims from stale identities
        # destroy real joins).  New contract: UNKNOWN + the stale_call
        # evidence flag; the pipeline re-detects the current pair and
        # re-verifies.
        self.assertIn("VC_PARTICIPATION_STALE_CALL_VIA_TARGETED", self.src)
        self.assertIn("STALE CALL IDENTITY, returning unknown", self.src)


# ---------------------------------------------------------------------------
# Section D — FIX-J: account-aware cleanup + locked drain variant
# ---------------------------------------------------------------------------


class TestVC801FixJAccountAwareCleanup(unittest.TestCase):
    """FIX-J: _vc_cleanup_stale_backend_call respects account ownership."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_fix_j_marker_present(self):
        self.assertIn("v98.01 FIX-J", self.src)
        self.assertIn("ISSUE 4 — both-account cleanup corruption", self.src)

    def test_cleanup_resolves_owner_backend_first(self):
        # The cleanup must consult _vc_active_join_backends_by_chat BEFORE
        # falling back to vc_get_backend().
        idx = self.src.find("async def _vc_cleanup_stale_backend_call(")
        self.assertGreater(idx, 0)
        # The function has a large docstring; use a generous window.
        # v99.11: 6000 -> 9000 — the leave-policy chokepoint docstring
        # grew the helper; CONTRACT unchanged (owner-first resolution).
        body = self.src[idx:idx + 9000]
        self.assertIn("_vc_active_join_backends_by_chat.get(chat_id)", body)
        self.assertIn("_owner_backend", body)
        # The actual fallback (in the else branch, indented 12 spaces) must
        # be present. We search for the INDENTED form to avoid matching the
        # comment block (which describes the v98.00 bug and also mentions
        # vc_get_backend() but unindented / in backticks).
        self.assertIn("            backend = vc_get_backend()", body,
                      "vc_get_backend() fallback (else branch) must be present")
        self.assertIn("VC_BACKEND_STALE_CALL_CLEANUP_OWNER", body,
                      "owner-resolution log marker must be present")

    def test_cleanup_checks_both_id_forms_for_owner(self):
        # Must check both raw and marked forms when looking up the owner.
        idx = self.src.find("v98.01 FIX-J (ISSUE 4")
        self.assertGreater(idx, 0)
        body = self.src[idx:idx + 3000]
        self.assertIn("_marked_lookup", body)
        self.assertIn("_raw_lookup", body)

    def test_cleanup_uses_owner_account_container(self):
        # The container resolution must pass _owner_account_id.
        self.assertIn(
            "vc_resolve_calls_container(\n                account_id=_owner_account_id,\n            )",
            self.src,
        )

    def test_cleanup_logs_owner_account(self):
        self.assertIn("VC_BACKEND_STALE_CALL_CLEANUP_OWNER", self.src)
        self.assertIn("VC_BACKEND_STALE_CALL_CLEANUP_NO_OWNER", self.src)


class TestVC801FixJLockedDrainVariant(unittest.TestCase):
    """FIX-J / BUG-A5-1: Join-All reconnect uses the LOCKED drain variant."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_no_longer_imports_raw_drain_variant(self):
        # The v98.00 code imported _telethon_drain_and_reconnect_raw.
        # v98.01 must import the LOCKED _telethon_drain_and_reconnect.
        # Check the Join-All reconnect context.
        idx = self.src.find("v98.01 FIX-J / BUG-A5-1")
        self.assertGreater(idx, 0, "FIX-J BUG-A5-1 marker must be present")
        # The import block must use the locked variant.
        self.assertIn(
            "_telethon_drain_and_reconnect as _drain_reconnect_locked",
            self.src,
        )
        # The call site must use _drain_reconnect_locked, NOT the raw variant.
        call_idx = self.src.find("_drain_reconnect_locked(")
        self.assertGreater(call_idx, 0, "must call the locked variant")

    def test_raw_variant_no_longer_imported_in_join_all_reconnect(self):
        # The old import line `from .mtproto import get_cluster_router,
        # _telethon_drain_and_reconnect_raw` must be GONE (replaced by the
        # locked import).
        old_import = "from .mtproto import get_cluster_router, _telethon_drain_and_reconnect_raw"
        # The exact old string must not appear.
        self.assertNotIn(old_import, self.src,
                         "v98.00 raw-variant import must be removed")


# ---------------------------------------------------------------------------
# Section E — FIX-K: reconnect loop status coverage
# ---------------------------------------------------------------------------


class TestVC801FixKReconnectLoopStatusCoverage(unittest.TestCase):
    """FIX-K: _cluster_reconnect_loop retries FLOODWAIT-after-expiry + DISCONNECTED."""

    def setUp(self):
        self.src = _read_bootstrap()

    def test_fix_k_marker_present(self):
        self.assertIn("v98.01 FIX-K", self.src)
        self.assertIn("BUG-A5-5", self.src)

    def test_no_longer_short_circuits_on_connection_failed_only(self):
        # The v98.00 line `if st != STATUS_CONNECTION_FAILED: continue` must
        # be GONE. The new code must handle multiple statuses.
        self.assertNotIn(
            "if st != STATUS_CONNECTION_FAILED:\n                    continue",
            self.src,
            "v98.00 single-status short-circuit must be removed",
        )

    def test_handles_floodwait_after_expiry(self):
        self.assertIn("STATUS_FLOODWAIT", self.src)
        self.assertIn("_fw_expired", self.src)
        self.assertIn("floodwait_until <= now", self.src)
        self.assertIn("ACCOUNT_RECONNECT_FLOODWAIT_EXPIRED", self.src)

    def test_handles_disconnected(self):
        self.assertIn("STATUS_DISCONNECTED", self.src)
        self.assertIn("ACCOUNT_RECONNECT_DISCONNECTED", self.src)

    def test_status_constants_imported(self):
        # bootstrap.py must import STATUS_FLOODWAIT + STATUS_DISCONNECTED
        # from .mtproto.
        # The import block at the top must include these.
        import_block = self.src[self.src.find("from .mtproto import ("):
                                self.src.find("from .mtproto import (") + 600]
        self.assertIn("STATUS_FLOODWAIT", import_block)
        self.assertIn("STATUS_DISCONNECTED", import_block)

    def test_healthy_accounts_not_retried(self):
        # The new code must still skip STATUS_HEALTHY / STATUS_CONNECTED.
        self.assertIn("STATUS_HEALTHY", self.src)
        self.assertIn("continue  # not enough time has passed", self.src)


# ---------------------------------------------------------------------------
# Section F — Version bumps v98.00 -> v98.01
# ---------------------------------------------------------------------------


class TestVC801VersionBumps(unittest.TestCase):
    """v98.01 version declarations are consistent across files."""

    def test_init_bot_version_bumped(self):
        src = _read_init()
        self.assertIn('__bot_version__ = "v99.11.2"', src)
        self.assertNotIn('__bot_version__ = "v98.13"', src)

    def test_bootstrap_deployment_identity_bumped(self):
        src = _read_bootstrap()
        self.assertIn("DEPLOYMENT_IDENTITY version={_v9812_pkg_version}", src)  # v99: derivation site (v98.12 correction)
        self.assertNotIn("DEPLOYMENT_IDENTITY version=v98.13", src)


# ---------------------------------------------------------------------------
# Section G — v98.00 regression preserved
# ---------------------------------------------------------------------------


class TestVC801V9800RegressionPreserved(unittest.TestCase):
    """All v98.00 fixes (FIX-E + FIX-F) must be preserved in v98.01."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_fix_e_case_a_preserved(self):
        self.assertIn("v98.00 FIX-E Case A", self.src)
        self.assertIn("reason=no_client", self.src)

    def test_fix_e_case_b_preserved(self):
        self.assertIn("v98.00 FIX-E Case B", self.src)
        self.assertIn("reason=redetect_failed", self.src)
        self.assertIn("redetect failure is UNKNOWN, NOT absent", self.src)

    def test_fix_e_case_c_preserved(self):
        self.assertIn("v98.00 FIX-E Case C", self.src)
        self.assertIn("vc_detect_active_call returned None — genuine absence", self.src)

    def test_fix_f_gid_preserved(self):
        # The v98.00 FIX-F (gid assigned before FloodWait log) must still be
        # present. The UnboundLocalError fix must not be regressed.
        # FIX-F is in _vc_join_all_active_worker.
        self.assertIn("v97.81", self.src)  # historical marker
        # The gid assignment must come before the FloodWait log.
        # (We don't assert exact line numbers — just that the pattern exists.)


# ---------------------------------------------------------------------------
# Section H — Structural integrity (py_compile + key markers)
# ---------------------------------------------------------------------------


class TestVC801StructuralIntegrity(unittest.TestCase):
    """v98.01 source compiles + key structural markers present."""

    def test_py_compile_voicechat(self):
        import py_compile
        py_compile.compile(_VOICECHAT, doraise=True)

    def test_py_compile_bootstrap(self):
        import py_compile
        py_compile.compile(_BOOTSTRAP, doraise=True)

    def test_py_compile_mtproto(self):
        import py_compile
        py_compile.compile(_MTPROTO, doraise=True)

    def test_py_compile_init(self):
        import py_compile
        py_compile.compile(_INIT, doraise=True)

    def test_no_pyc_files_in_source_tree(self):
        # The canonical source tree must have NO .pyc / __pycache__.
        # NOTE: other tests in this suite (py_compile) may generate .pyc
        # files as a side effect. Clean them BEFORE checking so this test
        # is order-independent.
        import shutil
        for root, dirs, files in os.walk(_PKG_ROOT):
            if "mediagrab_bot_v98.00_backup" in root:
                continue
            for f in files:
                if f.endswith(".pyc"):
                    try:
                        os.remove(os.path.join(root, f))
                    except OSError:
                        pass
            if "__pycache__" in dirs:
                try:
                    shutil.rmtree(os.path.join(root, "__pycache__"), ignore_errors=True)
                except OSError:
                    pass
        # Now verify the tree is clean.
        _found_pyc = []
        _found_pycache = []
        for root, dirs, files in os.walk(_PKG_ROOT):
            if "mediagrab_bot_v98.00_backup" in root:
                continue
            for f in files:
                if f.endswith(".pyc"):
                    _found_pyc.append(os.path.join(root, f))
            if "__pycache__" in dirs:
                _found_pycache.append(root)
        self.assertEqual(_found_pyc, [], f".pyc found in source tree: {_found_pyc[:5]}")
        self.assertEqual(_found_pycache, [], f"__pycache__ found: {_found_pycache[:5]}")

    def test_key_markers_present(self):
        src = _read_voicechat()
        # All five FIX markers must be present.
        for marker in ("FIX-G", "FIX-H", "FIX-I", "FIX-J"):
            self.assertIn(f"v98.01 {marker}", src,
                          f"{marker} marker must be present in voicechat.py")
        # FIX-K is in bootstrap.py.
        bs = _read_bootstrap()
        self.assertIn("v98.01 FIX-K", bs)


# ---------------------------------------------------------------------------
# Section I — Invariant preservation (UNKNOWN safety, idempotency)
# ---------------------------------------------------------------------------


class TestVC801InvariantPreservation(unittest.TestCase):
    """All v97.30-v98.00 invariants are preserved in v98.01."""

    def setUp(self):
        self.src = _read_voicechat()

    def test_unknown_never_destructive_invariant(self):
        # The transport_dead mark must be explicitly documented as UNKNOWN
        # evidence, NEVER directly causing a LEFT.
        self.assertIn("UNKNOWN evidence", self.src)
        # Must state that transport_dead must not trigger a destructive leave.
        self.assertTrue(
            ("MUST NOT trigger a destructive leave" in self.src
             or "MUST NEVER directly cause a real VC leave" in self.src
             or "MUST NEVER directly" in self.src),
            "FIX-G must document that transport_dead is never destructive"
        )

    def test_api_failure_not_absence_invariant(self):
        # Corroboration failure (FloodWait/RPC/timeout) must return None
        # (UNKNOWN), NOT False (absent).
        idx = self.src.find("async def _vc_telegram_call_still_valid(")
        body = self.src[idx:idx + 4000]
        # The FloodWait handler must return None.
        fw_idx = body.find("except FloodWaitError")
        self.assertGreater(fw_idx, 0)
        fw_block = body[fw_idx:fw_idx + 300]
        self.assertIn("return None", fw_block)

    def test_container_presence_not_definitive_joined_invariant(self):
        # verify_joined must NOT return True from container alone (without
        # corroboration or transport_dead check).
        # The v98.00 early-return True must be replaced by the FIX-H logic.
        self.assertIn("VC_JOIN_EVIDENCE_SUSPECT", self.src)
        self.assertIn("NOT returning True from container alone", self.src)

    def test_cleanup_idempotent_invariant(self):
        # _leave_target must catch exceptions (idempotent).
        self.assertIn("async def _leave_target(self, chat_id: int) -> str:", self.src)
        # The cleanup helper must return True if already absent (idempotent).
        self.assertIn("Already absent from container", self.src)

    def test_floodwait_never_crashes_join_all_invariant(self):
        # The v98.00 FIX-F (gid before FloodWait log) must be preserved.
        self.assertIn("UnboundLocalError", self.src)

    def test_cross_account_no_corruption_invariant(self):
        # FIX-J: cleanup must resolve owner backend first.
        self.assertIn("VC_BACKEND_STALE_CALL_CLEANUP_OWNER", self.src)
        self.assertIn("account-aware, prevents cross-account corruption", self.src)

    def test_left_requires_case_c_genuine_absence_invariant(self):
        # Only Case C (vc_detect_active_call returned None) may mark absent.
        # Cases A + B must remain UNKNOWN.
        self.assertIn("v98.00 FIX-E Case C", self.src)
        self.assertIn("v98.00 FIX-E Case A", self.src)
        self.assertIn("v98.00 FIX-E Case B", self.src)


# ---------------------------------------------------------------------------
# Section J — Runtime evidence correlation (v97.99 production log)
# ---------------------------------------------------------------------------


class TestVC801RuntimeEvidenceCorrelation(unittest.TestCase):
    """v98.01 fixes correlate with the v97.99 production runtime evidence."""

    def test_issue1_correlates_with_container_shrinkage(self):
        # The v97.99 log showed container 16 -> 6 (10 chats lost to passive
        # disconnect with no callback). FIX-G registers the callbacks that
        # would have detected these. v98.03 FIX-W rewrote the function to
        # use the real PyTgCalls 2.x API (on_network_status_changed) and
        # honest wording about the play-strategy limitation. Assert on the
        # corrected intent.
        src = _read_voicechat()
        # The function must still register SOME passive-disconnect callback.
        self.assertIn("on_network_status_changed", src)
        # Must mention passive-disconnect / transport_dead.
        self.assertIn("passive-disconnect", src)
        # Must mention the periodic reconcile path as the fallback.
        self.assertIn("periodic reconcile", src)

    def test_issue2_correlates_with_stale_container_blocks_rejoin(self):
        # The v97.97 log (chat 1922822605) showed a stale container object
        # blocking rejoin. FIX-H's corroboration would have caught it.
        src = _read_voicechat()
        self.assertIn("stale container object", src)
        self.assertIn("permanently blocks rejoin", src)

    def test_issue3_correlates_with_truncated_unknown_forever(self):
        # The v97.99 log showed 6 survivors stuck UNKNOWN (truncated participant
        # scan). FIX-I's targeted query would have resolved them.
        src = _read_voicechat()
        self.assertIn("stuck \"unknown\" forever", src)
        self.assertIn("truncated_or_incomplete", src)

    def test_issue4_correlates_with_cross_account_cleanup(self):
        # The v97.97 log showed both-account rotation. FIX-J's account-aware
        # cleanup prevents the cross-account corruption that would have
        # occurred if Account B joined and Account A's cleanup fired.
        src = _read_voicechat()
        # The FIX-J comment uses "both-account cleanup corruption" (matching
        # Issue 4's title) AND the owner-resolution log marker.
        self.assertIn("both-account cleanup corruption", src)
        self.assertIn("VC_BACKEND_STALE_CALL_CLEANUP_OWNER", src)
        self.assertIn("prevents cross-account corruption", src)


# ---------------------------------------------------------------------------
# Section K — Honest scope / non-fabrication markers
# ---------------------------------------------------------------------------


class TestVC801HonestScopeMarkers(unittest.TestCase):
    """v98.01 explicitly documents what is NOT runtime-proven (no fabrication)."""

    def setUp(self):
        self.src = _read_voicechat()
        self.bs = _read_bootstrap()

    def test_fix_g_documents_sandbox_limitation(self):
        # v98.03 FIX-W rewrote the FIX-G docstring to use the real PyTgCalls
        # 2.x API and honest wording about the play-strategy limitation.
        # The sandbox-limitation note was replaced with a more specific
        # limitation note about the play strategy not exposing per-call
        # GroupCall instances. Assert on the corrected intent: FIX-W must
        # honestly document a real limitation (no fabrication of liveness).
        self.assertIn("HONEST", self.src)
        # Must mention the periodic reconcile path as the fallback (preserved
        # from v98.01 FIX-G's intent — passive-disconnect detection falls
        # back to vc_detect_active_call Case C).
        self.assertIn("periodic reconcile", self.src)
        # Must reference the play-strategy limitation (the actual reason
        # the warning still fires for the production deployment).
        self.assertIn("play", self.src)

    def test_fix_g_documents_no_false_positive_left(self):
        # If no callback API is available, the bot must fall back to the
        # reconcile path (no false-positive LEFT from an unavailable callback).
        # v98.03 FIX-W preserves this invariant.
        # Must mention that unavailable callbacks don't cause false-positive LEFT.
        self.assertTrue(
            ("no false-positive LEFT" in self.src or "no false-positive" in self.src),
            "FIX-W (supersedes FIX-G): must document that unavailable callbacks "
            "don't cause false-positive LEFT"
        )

    def test_fix_k_documents_status_gap(self):
        # FIX-K must document the v97.30 gap (FLOODWAIT-after-expiry +
        # DISCONNECTED never retried).
        self.assertIn("silently dead forever", self.bs)
        self.assertIn("STATUS_FLOODWAIT", self.bs)


if __name__ == "__main__":
    unittest.main(verbosity=2)
