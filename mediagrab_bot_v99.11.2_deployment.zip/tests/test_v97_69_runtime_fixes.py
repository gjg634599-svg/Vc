"""
v97.69 regression tests — reconcile disconnect gate.

Root cause: the reconcile loop (vc_reconcile_participations) did sequential
per-target verify_target calls with 20s timeout each. When MTProto disconnected,
12 targets × 20s = 240s of sequential blocking, causing 5 EVENT_LOOP_LAG_CRITICAL
(up to 25.17s) + 12 VC_RECONCILE_TIMEOUT.

Fix: check MTProto connectivity BEFORE the reconcile loop + before EACH verify.
If disconnected, skip the entire cycle (return deferred) — no per-target RPCs.
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")


class TestReconcileDisconnectGate(unittest.TestCase):
    """P0: reconcile must skip ALL verifications when MTProto is disconnected."""

    def test_reconcile_deferred_when_disconnected(self):
        """vc_reconcile_participations must return deferred when MTProto is disconnected."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_RECONCILE_DEFERRED_NETWORK", src,
                      "reconcile must log VC_RECONCILE_DEFERRED_NETWORK when disconnected")
        self.assertIn("mtproto_disconnected", src,
                      "reconcile must classify as mtproto_disconnected")

    def test_reconcile_checks_before_each_verify(self):
        """The reconcile loop must re-check connectivity before EACH verify."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_still_connected", src,
                      "reconcile must check _still_connected before each verify")
        self.assertIn("disconnected mid-cycle", src,
                      "reconcile must log when disconnected mid-cycle")

    def test_reconcile_no_rpc_when_disconnected(self):
        """When disconnected, reconcile must NOT issue any per-target RPCs."""
        with open(_VOICECHAT) as f:
            src = f.read()
        # Find the function.
        import re
        m = re.search(r'async def vc_reconcile_participations.*?(?=\nasync def |\ndef )', src, re.DOTALL)
        self.assertIsNotNone(m, "vc_reconcile_participations not found")
        func_body = m.group(0)
        # The deferred return must be BEFORE the for loop.
        deferred_pos = func_body.find("VC_RECONCILE_DEFERRED_NETWORK")
        for_loop_pos = func_body.find("for rec in participations")
        self.assertGreater(deferred_pos, 0, "must have deferred check")
        self.assertGreater(for_loop_pos, 0, "must have for loop")
        self.assertLess(deferred_pos, for_loop_pos,
                        "deferred check must be BEFORE the for loop")


class TestPreservedBehavior(unittest.TestCase):
    """Verify all previous fixes are still present."""

    def test_disconnect_classification(self):
        """v97.68 authoritative disconnect classification must hold."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_is_disconnect_exc", src)
        self.assertIn("classified as disconnect", src)

    def test_discovery_per_page_gate(self):
        """v97.68 discovery per-page gate must hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("DISCOVERY_DEFERRED_NETWORK", src)
        self.assertIn("client disconnected mid-cycle", src)

    def test_callback_handler_sync_properties(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("event.sender_id", src)

    def test_no_await_on_sync_release(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertNotIn("await _vc_release_target_inflight", src)

    def test_floodwait_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_GLOBAL_FLOODWAIT_SET", src)

    def test_interdc_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("is_interdc_error", src)

    def test_dashboard_single_flight(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_DASHBOARD_REFRESH_CANCELLED", src)

    def test_no_asyncio_shield_in_stop(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        import re
        m = re.search(r'async def vc_join_all_active_stop.*?(?=\nasync def |\ndef )', src, re.DOTALL)
        self.assertIsNotNone(m)
        code_only = re.sub(r'#.*', '', m.group(0))
        self.assertNotIn("asyncio.shield", code_only)

    def test_event_loop_lag_instrumentation(self):
        with open(os.path.join(_BASE, "mediagrab_bot/bootstrap.py")) as f:
            src = f.read()
        self.assertIn("_capture_blocking_task_stack", src)

    def test_dashboard_single_to_thread(self):
        with open(os.path.join(_BASE, "mediagrab_bot/handlers.py")) as f:
            src = f.read()
        self.assertIn("_snapshot_and_triggers", src)

    def test_get_entity_wrapper(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_wrap_get_entity_disconnect_safe", src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
