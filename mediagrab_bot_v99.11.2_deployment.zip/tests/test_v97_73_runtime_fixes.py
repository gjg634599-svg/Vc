"""
v97.73 regression tests — shield removal + timeout harmonization.

Root causes fixed:
  1. asyncio.shield() in 3 locations prevented CancelledError from propagating,
     keeping orphaned/stuck tasks alive. The v97.67 fix removed shield from
     vc_join_all_active_stop, but 3 more shield() calls remained:
       - voicechat.py:7424 (orphan await)
       - mtproto.py:4807 (update loop drain)
       - mtproto_generation.py:351 (generation retirement)
  2. _VC_CALLBACK_HANDLER_TIMEOUT was 30s — if a handler does block, it starves
     the event loop for 30s before the timeout fires. Reduced to 10s.
  3. Reconcile per-target timeout was 20s — sequential verification of 12+
     targets = 240s potential blocking. Reduced to 10s.
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_GEN = os.path.join(_BASE, "mediagrab_bot", "mtproto_generation.py")


class TestNoAsyncioShield(unittest.TestCase):
    """P0: no asyncio.shield() should remain in production code (only comments)."""

    def test_no_shield_in_mtproto(self):
        with open(_MTPROTO) as f:
            src = f.read()
        # Remove comments before checking.
        import re
        code_only = re.sub(r'#.*', '', src)
        self.assertNotIn("asyncio.shield", code_only,
                         "no asyncio.shield in mtproto.py code (only in comments)")

    def test_no_shield_in_voicechat(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        import re
        code_only = re.sub(r'#.*', '', src)
        self.assertNotIn("asyncio.shield", code_only,
                         "no asyncio.shield in voicechat.py code (only in comments)")

    def test_no_shield_in_generation(self):
        with open(_GEN) as f:
            src = f.read()
        import re
        code_only = re.sub(r'#.*', '', src)
        self.assertNotIn("asyncio.shield", code_only,
                         "no asyncio.shield in mtproto_generation.py code")


class TestTimeoutHarmonization(unittest.TestCase):
    """P0: all timeouts should be ≤10s to prevent event-loop starvation."""

    def test_callback_handler_timeout_is_10s(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_VC_CALLBACK_HANDLER_TIMEOUT = 10", src,
                      "callback handler timeout must be 10s (was 30s)")

    def test_reconcile_verify_timeout_is_10s(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("timeout=10,", src,
                      "reconcile per-target verify timeout must be 10s (was 20s)")

    def test_rpc_timeout_is_10s(self):
        """v97.72 RPC timeout reduction must hold."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("timeout=10.0", src,
                      "RPC timeout must be 10s (v97.72)")


class TestPreservedBehavior(unittest.TestCase):
    """Verify all previous fixes are still present."""

    def test_dispatch_filter(self):
        with open(_MTPROTO) as f: src = f.read()
        self.assertIn("func=_self_destruct_filter", src)

    def test_vc_command_filter(self):
        with open(_VOICECHAT) as f: src = f.read()
        self.assertIn("func=_vc_command_filter", src)

    def test_disconnect_classification(self):
        with open(_MTPROTO) as f: src = f.read()
        self.assertIn("_is_disconnect_exc", src)

    def test_reconcile_disconnect_gate(self):
        with open(_VOICECHAT) as f: src = f.read()
        self.assertIn("VC_RECONCILE_DEFERRED_NETWORK", src)

    def test_callback_handler_sync_properties(self):
        with open(_VOICECHAT) as f: src = f.read()
        self.assertIn("event.sender_id", src)

    def test_no_await_on_sync_release(self):
        with open(_VOICECHAT) as f: src = f.read()
        self.assertNotIn("await _vc_release_target_inflight", src)

    def test_floodwait_preserved(self):
        with open(_VOICECHAT) as f: src = f.read()
        self.assertIn("VC_GLOBAL_FLOODWAIT_SET", src)

    def test_dashboard_single_to_thread(self):
        with open(os.path.join(_BASE, "mediagrab_bot/handlers.py")) as f: src = f.read()
        self.assertIn("_snapshot_and_triggers", src)

    def test_get_entity_wrapper(self):
        with open(_MTPROTO) as f: src = f.read()
        self.assertIn("_wrap_get_entity_disconnect_safe", src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
