"""v99.11.2 FIX — THE JOIN-ALL ALREADY-JOINED CLUSTER CONVERGENCE SUITE.

PRODUCTION EVIDENCE (bot-diagnostic (3).log, 2026-09-25 12:03:37,
20 occurrences / 3 CLOSED→OPEN breaker cycles):

    VC_JOIN_ALL_TARGET_ACCOUNT_SELECTED chat_id=1875192287
        account=acc_918335829278 rank=cursor:6 of 2 eligible
    VC_JOIN_SKIPPED_ALREADY_OWNED chat_id=1875192287
        owner=acc_919006065076 requester=acc_918335829278
    VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONFLICT ... owner=acc_919006065076
        dispatch_account=acc_918335829278 — different/unknown owner
        (v99.11.1 FIX-3 classification: conflict retained)
    VC_JOIN_ALL_TARGET_FAILURE chat_id=1875192287 reason=transport_error
        exc=VCTransportError: Chat 1875192287 is already joined by
        account acc_919006065076; one-group-one-account invariant (v99.06).
    JOIN_ALL_BREAKER failure recorded: VCTransportError x1/3 … x3 → OPEN
    VC_COORDINATOR_OP_FAILED op=join recoverable=True
    BOT_HEARTBEAT: joins=... acc_918335829278:J=19/F=19
        acc_919006065076:J=18/F=1  ← BOTH are the bot's OWN accounts

ROOT CAUSE (the actual bypass): the v99.11.1 classifier
``_v9911_classify_already_joined_exc`` DID run on the production
exception and DID parse the owner — its convergence condition was
``owner == the per-target DISPATCH account`` only.  In the multi-account
cluster the Join-All requester is the BOT (the account pool the
cursor-rotation selector dispatches on behalf of), so the dominant
production condition — chat owned by bot account A (acc_919006065076,
J=18 in the same heartbeat) while the cursor dispatched bot account B
(acc_918335829278) — classified as "different/unknown owner" → conflict
semantics → generic transport-failure accounting → breaker + coordinator
failure + re-dispatch next run (12:03:37 → 12:23:58 → 12:36:09).
The v99.11.1 race suite never exercised this condition: its
RACE-DIFF-ACCOUNT fixture used "acc_919006065076" as a FOREIGN owner —
in production that id is one of the bot's own accounts.

THE v99.11.2 FIX: at the SAME semantic boundary (the worker's
except-VCTransportError handler, BEFORE the generic transport-failure
accounting), the owner's scope is resolved against the bot's OWN
account pool (the authoritative cluster registry — the same pool the
selector draws from, the same account normalization as the v99.06
gate):

  * owner == dispatch account                      → idempotent success
    (v99.11.1, preserved);
  * owner = another OWN cluster account (verified) → IDEMPOTENT SUCCESS
    (v99.11.2 — the production case): result=already_joined, registry
    synced to joined UNDER THE OWNER (ownership never reassigned, the
    dispatching account never joins — the v99.06 gate preserved, zero
    RPCs), breaker count UNCHANGED, no per-account failure, no retry,
    no duplicate transport, coordinator completes JOINED;
  * owner foreign to the registry / unparseable /
    cluster membership unverifiable                 → conflict semantics
    RETAINED (exactly v99.06-v99.11.1).

§A — source contracts (worker wiring, machine-searchable).
§B — helper + classifier unit semantics (subprocess driver).
§C — behavioral regression (subprocess): tests/_v9912_convergence_driver.py
      runs the REAL worker end-to-end through the EXACT production
      event path (Cases A-G of the v99.11.2 remediation task).
"""
from __future__ import annotations

import os
import subprocess
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

_ROOT = str(Path(__file__).resolve().parents[1])
_VC = os.path.join(_ROOT, "mediagrab_bot", "voicechat.py")
_VC_RES = os.path.join(_ROOT, "mediagrab_bot", "vc_resources.py")
_DRIVER = os.path.join(_ROOT, "tests", "_v9912_convergence_driver.py")


def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


class TestConvergenceSourceContracts(unittest.TestCase):
    """§A — the worker wiring (machine-searchable)."""

    def setUp(self):
        self.src = _read(_VC)

    def test_a1_cluster_membership_helper_exists(self):
        self.assertIn("def _v9912_owner_is_own_cluster_account(", self.src)

    def test_a2_cluster_check_uses_the_cluster_registry(self):
        """Membership evidence = get_userbot_cluster().list_accounts()
        (the authoritative pool), NEVER a substring guess."""
        seg = self.src.split(
            "def _v9912_owner_is_own_cluster_account(", 2)
        self.assertGreaterEqual(len(seg), 2)
        body = seg[1][:3000]
        self.assertIn("get_userbot_cluster()", body)
        self.assertIn("list_accounts", body)

    def test_a3_worker_calls_helper_before_conflict_branch(self):
        """The owner-scope resolution sits in the SAME if/elif chain as
        the v99.11.1 classification — AFTER the same-account branch,
        BEFORE the different/unknown-owner conflict branch (the semantic
        boundary precedes failure accounting)."""
        self.assertIn(
            "elif _v9911_aj_is and _v9912_owner_is_own_cluster_account(",
            self.src)
        idx_same = self.src.find("if _v9911_aj_is and _v9911_aj_same:")
        idx_cluster = self.src.find(
            "elif _v9911_aj_is and _v9912_owner_is_own_cluster_account(")
        idx_conflict = self.src.find("elif _v9911_aj_is:")
        idx_failure_gate = self.src.find("if _v9911_aj_converged:")
        for idx in (idx_same, idx_cluster, idx_conflict,
                    idx_failure_gate):
            self.assertGreater(idx, 0)
        self.assertLess(idx_same, idx_cluster)
        self.assertLess(idx_cluster, idx_conflict)
        self.assertLess(idx_conflict, idx_failure_gate)

    def test_a4_cluster_branch_converges_before_accounting(self):
        """The cluster-owned branch sets result=already_joined and the
        convergence flag — which gates OFF the failure chain
        (``if _v9911_aj_converged: pass`` before the entity/transport
        failure classification)."""
        idx_cluster = self.src.find(
            "elif _v9911_aj_is and _v9912_owner_is_own_cluster_account(")
        seg = self.src[idx_cluster:idx_cluster + 4200]
        self.assertIn('result_state = "already_joined"', seg)
        self.assertIn("_v9911_aj_converged = True", seg)
        # No failure accounting inside the convergence branch.
        self.assertNotIn("record_failure", seg)
        self.assertNotIn("_vc_join_account_record_failure", seg)

    def test_a5_unified_convergence_marker(self):
        """VC_JOIN_ALL_ALREADY_JOINED_CONVERGED carries the structured
        fields (chat_id, requester_account, owner_account, owner_scope,
        source, breaker_recorded=false)."""
        self.assertGreaterEqual(self.src.count(
            "VC_JOIN_ALL_ALREADY_JOINED_CONVERGED"), 2)
        seg = self.src.split(
            "VC_JOIN_ALL_ALREADY_JOINED_CONVERGED ", 2)
        self.assertGreaterEqual(len(seg), 2)
        body = seg[1][:1200]
        for field in ("chat_id=%s", "requester_account=%s",
                      "owner_account=%s", "owner_scope=",
                      "breaker_recorded=false"):
            self.assertIn(field, body)

    def test_a6_cluster_branch_registry_sync_preserves_owner(self):
        """The cluster-owned convergence syncs the registry to joined
        UNDER THE OWNER (account_id from the parsed owner — ownership is
        NEVER reassigned to the dispatching account)."""
        idx_cluster = self.src.find(
            "elif _v9911_aj_is and _v9912_owner_is_own_cluster_account(")
        seg = self.src[idx_cluster:idx_cluster + 5000]
        self.assertIn("vc_registry_update(", seg)
        self.assertIn('state="joined"', seg)
        self.assertIn("request_accepted=True", seg)
        self.assertIn("account_id=_v9911_aj_owner or None", seg)
        self.assertNotIn("account_id=_v9911_aj_dispatch_eff", seg)

    def test_a7_same_account_branch_emits_unified_marker(self):
        """The same-account convergence (v99.11.1, preserved) ALSO emits
        the v99.11.2 unified marker with owner_scope=same_account."""
        idx_same = self.src.find("if _v9911_aj_is and _v9911_aj_same:")
        idx_cluster = self.src.find(
            "elif _v9911_aj_is and _v9912_owner_is_own_cluster_account(")
        seg = self.src[idx_same:idx_cluster]
        self.assertIn("VC_JOIN_ALL_ALREADY_JOINED_CONVERGED", seg)
        self.assertIn("owner_scope=same_account", seg)
        self.assertIn("breaker_recorded=false", seg)

    def test_a8_conflict_marker_records_breaker(self):
        """The different/unknown-owner conflict marker is DISTINCT and
        explicitly records breaker_recorded=true (the conflict
        semantics)."""
        seg = self.src.split(
            "VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONFLICT ", 2)
        self.assertGreaterEqual(len(seg), 2)
        body = seg[1][:1600]
        self.assertIn("breaker_recorded=true", body)
        self.assertIn("NOT converted to", body)
        self.assertIn("same-account success", body)

    def test_a9_v9911_marker_and_classifier_preserved(self):
        """The v99.11.1 FIX-3 machinery is untouched (no regression on
        the already-validated fix)."""
        self.assertIn("def _v9911_classify_already_joined_exc(", self.src)
        self.assertIn("VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONVERGED", self.src)
        self.assertIn("_v9911_aj_is, _v9911_aj_owner, "
                      "_v9911_aj_dispatch_eff, \\", self.src)
        self.assertIn("= _v9911_classify_already_joined_exc(", self.src)

    def test_a10_no_revert_of_working_fixes(self):
        """v99.11.1 FD-lifecycle + snapshot-recovery fixes stay in place
        (VC_FD_OP_DELTA / VC_FD_DRIFT_SUSPECTED live in vc_resources.py;
        the total-function snapshot recovery markers in voicechat.py)."""
        res = _read(_VC_RES)
        self.assertIn("VC_FD_OP_DELTA", res)
        self.assertIn("VC_FD_DRIFT_SUSPECTED", res)
        self.assertIn("VC_SNAPSHOT_STALE_UNEXPECTED_STATE", self.src)


class TestConvergenceDriver(unittest.TestCase):
    """§B+§C — the REAL worker through the EXACT production event path
    (subprocess: tests/_v9912_convergence_driver.py).

    Case A  — CONV-SAME-ACCOUNT: the same-account race converges
              idempotently (v99.11.1 behavior preserved).
    Case A' — CONV-CLUSTER-OWNED: THE EXACT PRODUCTION EVENT (owner =
              the bot's OTHER account, dispatch = cursor-selected
              account): idempotent success, breaker UNCHANGED, registry
              joined UNDER THE OWNER, coordinator JOINED, no duplicate
              transport.
    Case B  — the exception passes through the exact coordinator path
              production uses (begin_operation → the worker's
              except-VCTransportError → complete_operation JOINED —
              asserted via the REAL coordinator's chat state).
    Case C  — CONV-DIFF-ACCOUNT: foreign owner → conflict retained +
              breaker failure recorded.
    Case D  — CONV-UNKNOWN-OWNER: unparseable owner → conservative
              conflict retained.
    Case E  — CONV-STORM: 5 consecutive cluster-owned already-joined
              events (the exact production x3+ storm) → breaker stays
              CLOSED, zero failures.
    Case F  — CONV-GENUINE-TRANSPORT: a genuine unrelated
              VCTransportError still increments the breaker.
    Case G  — CONV-WRAPPED: a VCTransportError subclass carrying the
              production message still converges (the semantic survives
              type normalization).
    """

    @classmethod
    def setUpClass(cls):
        cls.proc = subprocess.run(
            [sys.executable, _DRIVER],
            capture_output=True, text=True, timeout=240,
            cwd=_ROOT,
        )
        cls.out = cls.proc.stdout + cls.proc.stderr

    def test_c1_driver_exit_code_zero(self):
        self.assertEqual(
            self.proc.returncode, 0,
            f"driver failures:\n{self.out[-4000:]}")

    def test_c2_exact_production_event_converges(self):
        self.assertIn("CASE CONV-CLUSTER-OWNED: PASS", self.out)

    def test_c3_unified_convergence_marker_emitted(self):
        self.assertIn("VC_JOIN_ALL_ALREADY_JOINED_CONVERGED", self.out)

    def test_c4_cluster_owned_marker_scope(self):
        self.assertIn("owner_scope=own_cluster_account", self.out)
        self.assertIn("breaker_recorded=false", self.out)

    def test_c5_same_account_case_preserved(self):
        self.assertIn("CASE CONV-SAME-ACCOUNT: PASS", self.out)

    def test_c6_same_account_unified_marker_scope(self):
        self.assertIn("owner_scope=same_account", self.out)

    def test_c7_different_owner_conflict_retained(self):
        self.assertIn("CASE CONV-DIFF-ACCOUNT: PASS", self.out)

    def test_c8_unknown_owner_conflict_retained(self):
        self.assertIn("CASE CONV-UNKNOWN-OWNER: PASS", self.out)

    def test_c9_storm_stays_closed(self):
        """The exact production storm (FIVE consecutive cluster-owned
        already-joined races — the 12:03:37→12:04:30 sequence that
        drove CLOSED→OPEN at threshold=3) now stays CLOSED."""
        self.assertIn("CASE CONV-STORM: PASS", self.out)

    def test_c10_genuine_transport_failure_still_counted(self):
        self.assertIn("CASE CONV-GENUINE-TRANSPORT: PASS", self.out)

    def test_c11_wrapped_exception_converges(self):
        self.assertIn("CASE CONV-WRAPPED: PASS", self.out)

    def test_c12_helper_membership_semantics(self):
        """§B — the cluster-membership helper's unit semantics run in
        the same driver process (membership positive/negative, empty,
        dunder-key, never-raise under a broken registry)."""
        self.assertIn("CASE UNIT-HELPER-MEMBERSHIP: PASS", self.out)
        self.assertIn("CASE UNIT-HELPER-NEVER-RAISES: PASS", self.out)

    def test_c13_driver_summary(self):
        self.assertIn("SUMMARY: 9/9 cases passed", self.out)


if __name__ == "__main__":
    unittest.main()
