"""
v97.80 RUNTIME-DRIVEN FORENSIC FIX tests.

Root causes fixed in v97.80 (driven by REAL production runtime log — note 50):

  RC1 (RUNTIME-PROVEN): v97.79's _wrap_pytgcalls_update_filter called
      `client.add_update_handler` which DOES NOT EXIST on Telethon v1.x.
      AttributeError → backend failed → "No supported join method available" →
      all VC joins failed. v97.80 FIX: use the CORRECT public API
      (add_event_handler / remove_event_handler / list_event_handlers) +
      apply the filter AFTER pytgcalls.start() (post-registration replacement).

  RC2 (RUNTIME-PROVEN): dispatch-update explosion persists — 452
      _dispatch_update tasks + 15.15s CRITICAL. The v97.79 filter was supposed
      to fix this but was broken (RC1). v97.80's correct filter eliminates the
      explosion by only passing group-call-related TL types.

  RC3 (SOURCE-PROVEN): "automatic leave after several minutes" is NOT a
      configured timeout — there is no auto_leave_after_* config. The observed
      auto-leave is a SIDE EFFECT of event-loop starvation → MTProto disconnect →
      PyTgCalls WebRTC peer connection times out server-side → Telegram prunes
      the participant → user "leaves". v97.80 fixes the root cause (RC1+RC2)
      which eliminates the starvation that caused the indirect auto-leave.

Tests:
  RC1: PyTgCalls filter uses correct API (add_event_handler, not add_update_handler)
  RC2: filter replaces Raw() handler post-registration
  RC3: no configured auto-leave timeout (source-verified)
  Plus: idempotent Join All / Leave All cycles (from v97.78/v97.79 preserved)
"""
import asyncio
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


# ---------------------------------------------------------------------------
# Source-verification tests
# ---------------------------------------------------------------------------

class TestRC1NoAddUpdateHandler(unittest.TestCase):
    """RC1: the broken add_update_handler API must be gone from active code."""

    def test_no_add_update_handler_in_active_code(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        # Find the _wrap_pytgcalls_update_filter function body
        idx = src.find("def _wrap_pytgcalls_update_filter(")
        self.assertGreater(idx, 0)
        next_def = src.find("\ndef ", idx + 50)
        body = src[idx:next_def if next_def > 0 else idx + 3000]
        # Active code must NOT call client.add_update_handler as a method call
        # (i.e. "client.add_update_handler(" or ".add_update_handler = ")
        # Comments/docstrings with backticks are OK.
        import re
        # Match actual calls/assignments: "client.add_update_handler(" or ".add_update_handler ="
        calls = re.findall(r'\.add_update_handler\s*[\(=]', body)
        # Filter out matches inside comments/docstrings
        active_calls = []
        for line in body.split("\n"):
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith('"""') or stripped.startswith("'"):
                continue
            if re.search(r'\.add_update_handler\s*[\(=]', line):
                # Check it's not inside a string literal
                if '`client.add_update_handler' not in line and "'client.add_update_handler" not in line:
                    active_calls.append(line)
        self.assertEqual(len(active_calls), 0,
                         "active code must not call add_update_handler: %s" % active_calls)

    def test_uses_correct_event_handler_api(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _wrap_pytgcalls_update_filter(")
        body = src[idx:idx + 4000]  # v97.87: function is longer
        # v97.80: must use the CORRECT Telethon public API
        self.assertIn("list_event_handlers", body)
        self.assertIn("remove_event_handler", body)
        self.assertIn("add_event_handler", body)

    def test_filter_called_after_start(self):
        """v97.80: the filter is applied AFTER pytgcalls.start() (post-registration)."""
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("await self._pytgcalls.start()")
        self.assertGreater(idx, 0, "pytgcalls.start() call not found")
        # The filter call must come AFTER start()
        filter_idx = src.find("_wrap_pytgcalls_update_filter(self._mtproto)", idx)
        self.assertGreater(filter_idx, 0, "filter call not found after start()")

    def test_hasattr_check_for_correct_api(self):
        """v97.80: the filter checks hasattr for the correct API before proceeding."""
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _wrap_pytgcalls_update_filter(")
        body = src[idx:idx + 4000]  # v97.87: function is longer
        self.assertIn('hasattr(client, "list_event_handlers")', body)
        self.assertIn('hasattr(client, "remove_event_handler")', body)
        self.assertIn('hasattr(client, "add_event_handler")', body)


class TestRC2FilterReplacesRawHandler(unittest.TestCase):
    """RC2: the filter replaces PyTgCalls' Raw() handler with a filtered version."""

    def test_filter_checks_raw_type(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _wrap_pytgcalls_update_filter(")
        body = src[idx:idx + 4000]  # v97.87: function is longer
        self.assertIn("events.Raw", body)
        self.assertIn("isinstance(_event, _raw_type)", body)

    def test_filter_only_passes_vc_updates(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _wrap_pytgcalls_update_filter(")
        body = src[idx:idx + 4000]  # v97.87: function is longer
        self.assertIn("UpdateGroupCall", body)
        self.assertIn("UpdateGroupCallParticipants", body)
        self.assertIn("UpdateChannel", body)


class TestRC3NoAutoLeaveTimeout(unittest.TestCase):
    """RC3: there is NO configured auto-leave timeout — the "automatic leave"
    is a side effect of event-loop starvation, not a policy."""

    def test_no_auto_leave_after_config(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        # There must be no auto_leave_after_* config
        self.assertNotIn("auto_leave_after", src)
        self.assertNotIn("AUTO_LEAVE_AFTER", src)

    def test_watcher_does_not_leave(self):
        """The VC watcher loop must NOT call backend.leave()."""
        with open(_VOICECHAT) as f:
            src = f.read()
        # Find the watcher loop
        idx = src.find("_vc_watcher_loop")
        if idx < 0:
            self.skipTest("no _vc_watcher_loop found")
        # Check the watcher loop body (generous window)
        body = src[idx:idx + 5000]
        # The watcher should not call backend.leave or gc.leave
        # (it may reference leave in comments, but not in active calls)
        # Look for active leave calls
        for line in body.split("\n"):
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            # Active leave calls would be "await backend.leave(" or "await gc.leave("
            # but NOT in comments
            if "await backend.leave(" in stripped or "await gc.leave(" in stripped:
                self.fail("watcher loop calls leave: %s" % stripped)


class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_92(self):
        with open(_INIT) as f:
            src = f.read()
        self.assertIn('__bot_version__ = "v99.11.2"', src)


class TestVCInstrumentation(unittest.TestCase):
    """v97.80: VC_TARGET_EXCLUDED + VC_AUTOMATIC_LEAVE instrumentation."""

    def test_target_excluded_logging(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_TARGET_EXCLUDED", src)
        # v97.81: floodwait_active is now DEFERRED, not EXCLUDED
        self.assertIn("reason=mtproto_not_started", src)
        self.assertIn("reason=dead_lettered", src)
        # v97.81: floodwait now uses DEFER not EXCLUDE
        self.assertIn("VC_TARGET_FLOODWAIT_DEFERRED", src)

    def test_automatic_leave_logging(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_AUTOMATIC_LEAVE", src)
        self.assertIn("caller=", src)


# ---------------------------------------------------------------------------
# BEHAVIORAL TESTS — PyTgCalls filter + idempotent cycles
# ---------------------------------------------------------------------------

class _FakeTelethonClient:
    """Simulates a Telethon client with the CORRECT public API
    (add_event_handler, remove_event_handler, list_event_handlers)."""
    def __init__(self):
        self._event_handlers = []  # list of (callback, event)

    def add_event_handler(self, callback, event=None):
        self._event_handlers.append((callback, event))

    def remove_event_handler(self, callback, event=None):
        self._event_handlers = [
            (cb, ev) for cb, ev in self._event_handlers
            if not (cb is callback and ev is event)
        ]

    def list_event_handlers(self):
        return list(self._event_handlers)


class _FakeRawEvent:
    """Simulates telethon.events.Raw()."""
    pass


class TestPyTgCallsFilterPostRegistration(unittest.TestCase):
    """v97.80: the filter replaces the Raw() handler AFTER registration."""

    def test_filter_replaces_raw_handler(self):
        client = _FakeTelethonClient()
        # Simulate PyTgCalls registering a Raw() handler (as it does at construction)
        async def pytgcalls_raw_handler(update):
            return update

        raw_event = _FakeRawEvent()
        client.add_event_handler(pytgcalls_raw_handler, raw_event)
        self.assertEqual(len(client.list_event_handlers()), 1)

        # Now apply the v97.80 filter (simulated)
        replaced = 0
        for cb, ev in client.list_event_handlers():
            if isinstance(ev, _FakeRawEvent):
                filtered_cb = cb  # In real code, this wraps with a filter
                client.remove_event_handler(cb, ev)
                client.add_event_handler(filtered_cb, ev)
                replaced += 1
        self.assertEqual(replaced, 1, "filter must replace exactly 1 Raw() handler")
        self.assertEqual(len(client.list_event_handlers()), 1)

    def test_filter_idempotent(self):
        """The filter must be idempotent — applying twice doesn't double-replace."""
        # Simulate the idempotency guard using a regular set (not WeakSet —
        # id() returns an int which can't be weak-referenced)
        wrapped = set()
        client = _FakeTelethonClient()
        client_id = id(client)
        # First application: proceeds
        self.assertNotIn(client_id, wrapped)
        wrapped.add(client_id)
        # Second application: skips (idempotent)
        self.assertIn(client_id, wrapped)


class TestJoinAllLeaveAllIdempotent(unittest.TestCase):
    """The Join All / Leave All cycle must be idempotent (v97.78/v97.79 preserved)."""

    class _FakeVCState:
        def __init__(self):
            self.entity_fail_counts = {}
            self.target_cooldowns = {}
            self.no_active_call_cooldowns = {}
            self.reconcile_cooldowns = {}
            self.global_floodwait_until = 0.0
            self.breaker_open = False
            self.worker_alive = False
            self.FAIL_THRESHOLD = 3

        def is_dead_lettered(self, chat_id):
            return self.entity_fail_counts.get(chat_id, 0) >= self.FAIL_THRESHOLD

        def record_failure(self, chat_id):
            c = self.entity_fail_counts.get(chat_id, 0) + 1
            self.entity_fail_counts[chat_id] = c
            return c

        def reset_target_state(self, include_global_floodwait=False):
            cleared = len(self.entity_fail_counts)
            self.entity_fail_counts.clear()
            self.target_cooldowns.clear()
            self.no_active_call_cooldowns.clear()
            self.reconcile_cooldowns.clear()
            if include_global_floodwait:
                self.global_floodwait_until = 0.0
            self.breaker_open = False
            self.worker_alive = False
            return cleared

    def test_join_all_leave_all_5_cycles(self):
        """Join All → auto-leave → Join All → Leave All → Join All (5 cycles).
        No VC may become permanently excluded."""
        state = self._FakeVCState()
        vcs = list(range(1001, 1011))  # 10 VCs
        for cycle in range(5):
            # Join All: discover all
            eligible = [v for v in vcs if not state.is_dead_lettered(v)]
            self.assertEqual(len(eligible), 10, f"cycle {cycle}: all 10 must be eligible")
            # Simulate failures during the cycle
            for v in vcs:
                state.record_failure(v)
            # Leave All (v97.79: stops worker + clears breaker + floodwait)
            state.reset_target_state(include_global_floodwait=True)
        self.assertEqual(len(state.entity_fail_counts), 0)

    def test_floodwait_does_not_permanently_exclude(self):
        state = self._FakeVCState()
        # FloodWait is NOT a dead-letter failure
        self.assertFalse(state.is_dead_lettered(4001))
        # After Leave All clears floodwait, VC is eligible
        state.reset_target_state(include_global_floodwait=True)
        self.assertEqual(state.global_floodwait_until, 0.0)

    def test_dead_letter_cleared_on_leave_all(self):
        state = self._FakeVCState()
        for v in range(2000, 2010):
            for _ in range(3):
                state.record_failure(v)
        self.assertEqual(len([v for v in range(2000, 2010) if state.is_dead_lettered(v)]), 10)
        cleared = state.reset_target_state(include_global_floodwait=True)
        self.assertEqual(cleared, 10)
        self.assertEqual(len(state.entity_fail_counts), 0)

    def test_one_dead_letter_does_not_suppress_others(self):
        state = self._FakeVCState()
        for _ in range(3):
            state.record_failure(6001)
        vcs = [6001, 6002, 6003, 6004, 6005]
        eligible = [v for v in vcs if not state.is_dead_lettered(v)]
        self.assertEqual(len(eligible), 4)
        self.assertNotIn(6001, eligible)


class TestNoOrphanWorkers(unittest.TestCase):
    """No orphan Join-All workers (v97.79 Leave All stops worker, preserved)."""

    def test_leave_all_stops_worker(self):
        """v97.79: Leave All calls vc_join_all_active_stop() first."""
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("async def vc__leave_all(")
        block = src[idx:idx + 5000]
        self.assertIn("vc_join_all_active_stop()", block)


class TestForcedCancelClientSpecific(unittest.TestCase):
    """v97.79 client-specific forced-cancel preserved (not global)."""

    def test_forced_cancel_uses_snapshot(self):
        with open(_VOICECHAT) as f:
            voicechat_src = f.read()
        # The mtproto.py forced-cancel uses client-specific snapshot
        mtproto_path = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
        with open(mtproto_path) as f:
            src = f.read()
        idx = src.find("async def _forcibly_cancel_telethon_tasks(")
        self.assertGreater(idx, 0)
        body = src[idx:idx + 4000]  # v97.87: function is longer
        self.assertIn("_mediagrab_bg_tasks", body)
        self.assertIn("v97.79_client_specific_retirement", body)


if __name__ == "__main__":
    unittest.main()
