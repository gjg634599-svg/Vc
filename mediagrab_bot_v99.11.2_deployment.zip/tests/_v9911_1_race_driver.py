"""v99.11.1 FIX-3 — Join-All already-joined RACE driver.

Runs the REAL production ``_vc_join_all_active_worker`` (full module body)
via the proven v98.10 fastpath harness (fake Telethon RPC surface, fake
PyTgCalls 2.3.3 semantics, REAL join_all_worker circuit breaker +
state machines), reproducing the EXACT production race:

    1. Join-All snapshot says the target is UNJOINED
       (no container object, no ownership entry, registry=unknown).
    2. Between the snapshot and the dispatch, the backend state CHANGES:
       a concurrent path registers the chat as joined (container object
       + ownership map) — the state converges to joined.
    3. The native join boundary raises the EXACT production
       VCTransportError:
       ``Chat <id> is already joined by account <account>;
       one-group-one-account invariant (v99.06).``
    4. The REAL worker processes that exception.

Cases:
    RACE-SAME-ACCOUNT  — the converged owner IS the dispatching account
                         (the required idempotent convergence: result=
                         already_joined, breaker count UNCHANGED, breaker
                         CLOSED, registry converges to joined, no
                         duplicate native transport).
    RACE-DIFF-ACCOUNT  — the owner is a DIFFERENT account: the existing
                         conflict semantics are RETAINED (failed result +
                         breaker failure recorded — the invariant is NOT
                         weakened into a false same-account success).
    RACE-STORM-GREEN   — the production storm signature (3 consecutive
                         already-joined races, the exact x3 that opened
                         the breaker in the 2026-09-22/23 logs) now stays
                         CLOSED and completes.

Exit code = number of failed cases; each case prints
``CASE <id>: PASS|FAIL — detail``.
"""
from __future__ import annotations

import asyncio
import sys
import types
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import _v9810_fastpath_driver as FP  # noqa: E402

MARKED = FP.MARKED_BASE
RAW = FP.RAW
RAW_B = FP.RAW_B
RAW_C = 1393246704

# The account the production error names when ownership is FOREIGN to
# every backend in this world (the different-owner case).
FOREIGN_OWNER = "acc_919006065076"


def _prod_error(vc, marked_chat: int, owner: str):
    """The EXACT production exception text (v99.06 gate signature)."""
    return vc.VCTransportError(
        f"Chat {marked_chat} is already joined by account {owner}; "
        f"one-group-one-account invariant (v99.06).")


def _patch_race_join(vc, w, owner_for: "callable", seen: list):
    """Replace every backend's ``join`` with the race boundary.

    When the worker dispatches the join for the race chat, the patched
    boundary FIRST flips the backend state to joined (the concurrent
    convergence: container object + ownership map — exactly what
    ``_vc_group_owner`` resolves ``source=active_backend`` from), THEN
    raises the exact production already-joined VCTransportError.  The
    native join_group_call is NEVER invoked (the production gate fires
    before any native allocation — zero RPCs, no duplicate transport).
    """
    def _patch(backend):
        async def _race_join(chat_id, call_id=0, access_hash=0,
                             muted=True, **kw):
            marked = MARKED - chat_id if chat_id > 0 else int(chat_id)
            # (2) the state change between snapshot and dispatch:
            backend._pytgcalls.calls[marked] = types.SimpleNamespace(
                chat_id=marked)
            vc._vc_active_join_backends_by_chat[marked] = backend
            owner = owner_for(backend)
            seen.append((marked, owner))
            # (3) the exact production exception at the join boundary.
            raise _prod_error(vc, marked, owner)
        backend.join = _race_join

    for b in (w.global_b, w.a_b, w.b_b):
        _patch(b)


def _seed_registry_unknown(vc, raw: int):
    """The race target's pre-state: registry=unknown, NO container
    object (the snapshot classifies it ELIGIBLE for join)."""
    rec = vc.VCParticipationState(
        chat_id=raw, state="unknown", request_accepted=False,
        intentional=True, locally_tracked=False, account_id="")
    vc._vc_participations[raw] = rec


async def case_race_same_account(vc):
    w = await FP.reset_world(vc)
    FP.seed_group(RAW, title="RACE-SAME", call_id=-555, call_ah=7777)
    _seed_registry_unknown(vc, RAW)
    vc._vc_join_all_state["run_id"] = "race_same"

    seen: list = []

    def owner_for(backend):
        # The TRUE converged owner: the dispatching backend's EFFECTIVE
        # account (the same account the v99.06 gate would resolve for
        # the requester) — the genuine same-account condition.
        return vc._vc_effective_account_id(
            str(getattr(backend, "_account_id", "") or "global"))

    _patch_race_join(vc, w, owner_for, seen)
    terminal = await FP.run_worker(vc)

    breaker = vc._vc_join_all_breaker
    failures = dict(breaker._failures)
    breaker_state = breaker.state.value
    result = vc._vc_join_all_state["results"].get(RAW, {})
    progress = vc._vc_join_all_state["progress"]
    rec = await vc.vc_registry_get(RAW)

    # The dispatch happened exactly once for the race chat.
    race_seen = [s for s in seen if s[0] in (MARKED - RAW, RAW)]
    containers = [
        k for k in w.global_b._pytgcalls.calls
        if k in (MARKED - RAW, RAW)
    ]
    containers += [
        k for k in w.a_b._pytgcalls.calls if k in (MARKED - RAW, RAW)
    ]
    containers += [
        k for k in w.b_b._pytgcalls.calls if k in (MARKED - RAW, RAW)
    ]
    ok = (
        terminal in ("completed",)
        and len(race_seen) == 1
        and result.get("state") == "already_joined"
        and failures == {}
        and breaker_state == "closed"
        and progress.get("already_joined", 0) == 1
        and progress.get("failed", 0) == 0
        and rec is not None and rec.state == "joined"
        and rec.request_accepted is True
        and len(containers) == 1  # NO duplicate native transport
        and not w.global_b._pytgcalls.api_log  # native join never ran
        and not w.a_b._pytgcalls.api_log
        and not w.b_b._pytgcalls.api_log
    )
    detail = (f"terminal={terminal} result={result.get('state')} "
              f"failures={failures} breaker={breaker_state} "
              f"progress_aj={progress.get('already_joined')} "
              f"prog_failed={progress.get('failed')} "
              f"registry={None if rec is None else rec.state}/"
              f"{None if rec is None else rec.account_id} "
              f"containers={containers} seen={race_seen}")
    return ok, detail


async def case_race_diff_account(vc):
    w = await FP.reset_world(vc)
    FP.seed_group(RAW, title="RACE-DIFF", call_id=-555, call_ah=7777)
    _seed_registry_unknown(vc, RAW)
    vc._vc_join_all_state["run_id"] = "race_diff"

    seen: list = []
    _patch_race_join(vc, w, lambda backend: FOREIGN_OWNER, seen)
    terminal = await FP.run_worker(vc)

    breaker = vc._vc_join_all_breaker
    failures = dict(breaker._failures)
    result = vc._vc_join_all_state["results"].get(RAW, {})
    progress = vc._vc_join_all_state["progress"]

    ok = (
        terminal in ("completed",)
        and result.get("state") == "failed"
        # The breaker records under the exception class NAME (the
        # harness stub's VCTransportError subclass).
        and any(v >= 1 for v in failures.values())
        and progress.get("failed", 0) >= 1
        and progress.get("already_joined", 0) == 0
    )
    detail = (f"terminal={terminal} result={result.get('state')} "
              f"failures={failures} progress={progress} ")
    return ok, detail


async def case_race_storm_green(vc):
    """The production storm: THREE consecutive already-joined races (the
    exact x3 that drove the breaker CLOSED→OPEN on 2026-09-22
    03:21:15→03:21:20).  With same-account convergence they are
    idempotent successes — the breaker never records a failure, stays
    CLOSED, and the run completes."""
    w = await FP.reset_world(vc)
    FP.seed_group(RAW, title="STORM-1", call_id=-555, call_ah=7777)
    FP.seed_group(RAW_B, title="STORM-2", call_id=-556, call_ah=7778)
    FP.seed_group(RAW_C, title="STORM-3", call_id=-557, call_ah=7779)
    for raw in (RAW, RAW_B, RAW_C):
        _seed_registry_unknown(vc, raw)
    vc._vc_join_all_state["run_id"] = "race_storm"

    seen: list = []

    def owner_for(backend):
        return vc._vc_effective_account_id(
            str(getattr(backend, "_account_id", "") or "global"))

    _patch_race_join(vc, w, owner_for, seen)
    terminal = await FP.run_worker(vc)

    breaker = vc._vc_join_all_breaker
    failures = dict(breaker._failures)
    breaker_state = breaker.state.value
    progress = vc._vc_join_all_state["progress"]
    results = vc._vc_join_all_state["results"]

    ok = (
        terminal in ("completed",)
        and failures == {}
        and breaker_state == "closed"
        and progress.get("already_joined", 0) == 3
        and progress.get("failed", 0) == 0
        and all(results.get(r, {}).get("state") == "already_joined"
                for r in (RAW, RAW_B, RAW_C))
    )
    detail = (f"terminal={terminal} failures={failures} "
              f"breaker={breaker_state} progress_aj="
              f"{progress.get('already_joined')} "
              f"prog_failed={progress.get('failed')}")
    return ok, detail


CASES = [
    ("RACE-SAME-ACCOUNT", case_race_same_account),
    ("RACE-DIFF-ACCOUNT", case_race_diff_account),
    ("RACE-STORM-GREEN", case_race_storm_green),
]


def main() -> int:
    async def _run():
        vc = FP.import_voicechat()
        failed = 0
        for case_id, fn in CASES:
            try:
                ok, detail = await fn(vc)
            except Exception as exc:  # noqa: BLE001
                ok, detail = False, f"EXC {type(exc).__name__}: {exc}"
            status = "PASS" if ok else "FAIL"
            print(f"CASE {case_id}: {status} — {detail}")
            if not ok:
                failed += 1
        return failed

    failed = asyncio.run(_run())
    print(f"SUMMARY: {len(CASES) - failed}/{len(CASES)} cases passed")
    return failed


if __name__ == "__main__":
    sys.exit(main())
