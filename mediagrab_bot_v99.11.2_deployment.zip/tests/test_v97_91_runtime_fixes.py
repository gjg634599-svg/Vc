"""
v97.91 — THREE RUNTIME-PROVEN ROOT CAUSE FIXES.

Root causes proven from bot-diagnostic (3).log:

  RC1 (RUNTIME-PROVEN): pytgcalls logger NOT suppressed → 5795 DEBUG lines
      Each _handle_mtproto_updates call logs the FULL update at DEBUG level.
      This produces massive synchronous file writes → event-loop pressure.
      FIX: suppress pytgcalls logger to WARNING.

  RC2 (RUNTIME-PROVEN): PyTgCalls.stop() does not exist in PyTgCalls 2.x
      Runtime error: 'PyTgCalls' object has no attribute 'stop'
      FIX: check if stop() exists before calling; skip gracefully if not.

  RC3 (RUNTIME-PROVEN): setup_logging() never called (v97.90 fix, verified)
      v97.90 added setup_logging() call in main(). The diagnostic log
      (bot-diagnostic (3).log) was generated AFTER v97.90 was deployed —
      but still has 0 DIAGNOSTIC_BOOT events. This means v97.90 was NOT
      deployed for this runtime. v97.91 preserves the v97.90 fix.

  The 1368 dispatch_update tasks + 85.76s lag are caused by:
  1. Unfiltered PyTgCalls Raw() handler (v97.89 pre-wrap not deployed)
  2. pytgcalls DEBUG logging to diagnostic file (5795 lines)
  3. Both contribute to event-loop starvation → MTProto disconnect → VC left

  v97.91 merges ALL fixes from v97.80-v97.90 + adds:
  - pytgcalls logger suppression
  - PyTgCalls.stop() API fix
  - setup_logging() call (v97.90)
  - pre-wrap (v97.89)
  - All prior fixes preserved
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_UTILS = os.path.join(_BASE, "mediagrab_bot", "utils_real.py")
_BOOTSTRAP = os.path.join(_BASE, "mediagrab_bot", "bootstrap.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


class TestPyTgCallsLoggerSuppressed(unittest.TestCase):
    """RC1: pytgcalls logger must be suppressed to WARNING."""

    def test_pytgcalls_logger_suppressed(self):
        with open(_UTILS) as f:
            src = f.read()
        self.assertIn('logging.getLogger("pytgcalls").setLevel(logging.WARNING)', src)


class TestPyTgCallsStopFix(unittest.TestCase):
    """RC2: PyTgCalls.stop() must be guarded."""

    def test_stop_guarded(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("getattr(self._pytgcalls, \"stop\", None)", src)
        self.assertIn("PyTgCalls 2.x has no .stop() method", src)

    def test_no_bare_stop_call(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("async def stop(self) -> None:")
        body = src[idx:idx + 2000]
        self.assertNotIn("await self._pytgcalls.stop()", body)


class TestSetupLoggingCalled(unittest.TestCase):
    """RC3: setup_logging() must be called in main()."""

    def test_setup_logging_called_in_main(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        idx = src.find("def main() -> None:")
        body = src[idx:idx + 1000]
        self.assertIn("setup_logging()", body)

    def test_setup_logging_before_deployment_identity(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        setup_idx = src.find("setup_logging()", src.find("def main"))
        deploy_idx = src.find("DEPLOYMENT_IDENTITY", setup_idx)
        self.assertGreater(setup_idx, 0)
        self.assertGreater(deploy_idx, 0)
        self.assertLess(setup_idx, deploy_idx)


class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_92(self):
        with open(_INIT) as f:
            src = f.read()
        self.assertIn('__bot_version__ = "v99.11.2"', src)

    def test_deployment_identity_version(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn("version={_v9812_pkg_version}", src)  # v99: derivation site


class TestPreservedFixes(unittest.TestCase):
    """Verify all prior fixes preserved."""

    def test_prewrite_before_construction(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_prewrap_client_event_handlers", src)

    def test_backend_preservation(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_BACKEND_PRESERVED", src)

    def test_stale_joined_record(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_STALE_JOINED_RECORD", src)

    def test_is_open_property(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("VC_TRACKING_SNAPSHOT")
        block = src[idx:idx + 1200]
        self.assertIn("_vc_join_all_breaker.is_open ", block)

    def test_floodwait_defer(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_TARGET_FLOODWAIT_DEFERRED", src)

    def test_leave_block(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_LEAVE_BLOCKED_DURING_JOIN_ALL", src)

    def test_diagnostic_boot(self):
        with open(_UTILS) as f:
            src = f.read()
        self.assertIn("DIAGNOSTIC_BOOT", src)

    def test_deployment_identity(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn("DEPLOYMENT_IDENTITY", src)

    def test_forced_cancel(self):
        mtproto = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
        with open(mtproto) as f:
            src = f.read()
        self.assertIn("_mediagrab_bg_tasks", src)


if __name__ == "__main__":
    unittest.main()
