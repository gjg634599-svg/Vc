"""
v97.72 regression tests — RPC timeout reduction + reconnect drain analysis.

Root cause: the 30s RPC timeout in mtproto_call_with_retry kept readers holding
the RW read lock for up to 30s. When the watchdog triggered a reconnect, the
RW write lock had to wait for ALL readers to release — up to 30s. This starved
the event loop, causing 10-17s EVENT_LOOP_LAG_CRITICAL with only 25-28 total tasks.

Fix: reduced the RPC timeout from 30s to 10s. This means each reader releases
the read lock within 10s, so the writer doesn't wait longer than 10s.
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")


class TestRpcTimeoutReduction(unittest.TestCase):
    """P0: RPC timeout must be 10s (was 30s) to prevent RW lock starvation."""

    def test_rpc_timeout_is_10s(self):
        """mtproto_call_with_retry RPC timeout must be 10s (was 30s)."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("timeout=10.0", src,
                      "RPC timeout must be 10s (v97.72 reduced from 30s)")
        # Verify the old 30s timeout is gone from the RPC call path.
        import re
        m = re.search(r'async def mtproto_call_with_retry.*?(?=\nasync def |\ndef )', src, re.DOTALL)
        self.assertIsNotNone(m, "function not found")
        func_body = m.group(0)
        self.assertNotIn("timeout=30.0", func_body,
                         "no 30s RPC timeout should remain in mtproto_call_with_retry")
        self.assertIn("timeout=10.0", func_body,
                      "RPC timeout must be 10s in mtproto_call_with_retry")

    def test_disconnect_timeout_is_10s(self):
        """Disconnect timeout in drain function must be 10s (was 30s)."""
        with open(_MTPROTO) as f:
            src = f.read()
        import re
        m = re.search(r'async def _telethon_drain_and_reconnect_raw.*?(?=\nasync def |\ndef )', src, re.DOTALL)
        self.assertIsNotNone(m)
        func_body = m.group(0)
        self.assertNotIn("timeout=30", func_body,
                         "no 30s timeouts in drain path")
        self.assertIn("timeout=10", func_body,
                      "drain path must use 10s timeouts")


class TestReconcileGateBeforeCapabilityEvidence(unittest.TestCase):
    """P0: reconcile must check connectivity BEFORE vc_collect_capability_evidence()."""

    def test_gate_before_capability_evidence(self):
        """The disconnect gate must be BEFORE vc_collect_capability_evidence() call."""
        with open(_VOICECHAT) as f:
            src = f.read()
        import re
        m = re.search(r'async def vc_reconcile_participations\(.*?"""', src, re.DOTALL)
        self.assertIsNotNone(m)
        after_doc = src[m.end():]
        next_func = re.search(r'\nasync def |\ndef ', after_doc)
        if next_func:
            after_doc = after_doc[:next_func.start()]
        gate_pos = after_doc.find("VC_RECONCILE_DEFERRED_NETWORK")
        evidence_pos = after_doc.find("await vc_collect_capability_evidence()")
        self.assertGreater(gate_pos, 0, "must have disconnect gate")
        self.assertGreater(evidence_pos, 0, "must call vc_collect_capability_evidence")
        self.assertLess(gate_pos, evidence_pos,
                        "disconnect gate must be BEFORE vc_collect_capability_evidence() call")


class TestPreservedBehavior(unittest.TestCase):
    """Verify all previous fixes are still present."""

    def test_dispatch_filter(self):
        with open(_MTPROTO) as f: src = f.read()
        self.assertIn("func=_self_destruct_filter", src)

    def test_vc_command_filter(self):
        with open(_VOICECHAT) as f: src = f.read()
        self.assertIn("func=_vc_command_filter", src)

    def test_disconnect_classification(self):
        with open(_MTPROTO) as f: src = f.read()
        self.assertIn("_is_disconnect_exc", src)

    def test_callback_handler_sync_properties(self):
        with open(_VOICECHAT) as f: src = f.read()
        self.assertIn("event.sender_id", src)

    def test_no_await_on_sync_release(self):
        with open(_VOICECHAT) as f: src = f.read()
        self.assertNotIn("await _vc_release_target_inflight", src)

    def test_floodwait_preserved(self):
        with open(_VOICECHAT) as f: src = f.read()
        self.assertIn("VC_GLOBAL_FLOODWAIT_SET", src)

    def test_no_asyncio_shield_in_stop(self):
        with open(_VOICECHAT) as f: src = f.read()
        import re
        m = re.search(r'async def vc_join_all_active_stop.*?(?=\nasync def |\ndef )', src, re.DOTALL)
        self.assertIsNotNone(m)
        code_only = re.sub(r'#.*', '', m.group(0))
        self.assertNotIn("asyncio.shield", code_only)

    def test_dashboard_single_to_thread(self):
        with open(os.path.join(_BASE, "mediagrab_bot/handlers.py")) as f: src = f.read()
        self.assertIn("_snapshot_and_triggers", src)

    def test_get_entity_wrapper(self):
        with open(_MTPROTO) as f: src = f.read()
        self.assertIn("_wrap_get_entity_disconnect_safe", src)

    def test_reconcile_disconnect_gate(self):
        with open(_VOICECHAT) as f: src = f.read()
        self.assertIn("VC_RECONCILE_DEFERRED_NETWORK", src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
