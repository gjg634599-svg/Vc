"""
v97.86 — BACKEND PRESERVATION + PHYSICAL DISCONNECT INSTRUMENTATION.

Root cause (SOURCE-PROVEN from note 56 runtime + source audit):
  vc_reset_backend() set _vc_backend = None WITHOUT stopping the old backend.
  When vc_get_backend() was called next, it created a NEW PyTgCallsBackend →
  backend.start() → NEW PyTgCalls instance bound to the SAME MTProto client.
  The NEW instance's start() conflicted with or destroyed the OLD instance's
  connections, physically disconnecting ALL VCs that were joined via the old
  backend. This was the ROOT CAUSE of the "VC auto-leave" the user observed.

  Runtime evidence (note 56): 25 VC_STALE_JOINED_RECORD events — all with
  registry_state=joined + backend_connected=false. The calls container was
  EMPTY because the PyTgCalls instance was replaced/orphaned.

Fix: vc_reset_backend() now PRESERVES the existing backend if it's still
started with an active PyTgCalls instance. Only resets if the backend is
genuinely dead. Also instruments backend.stop() with VC_BACKEND_STOP_REQUEST.
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


class TestBackendPreservation(unittest.TestCase):
    """v97.86: vc_reset_backend preserves active backends."""

    def test_preserve_connections_parameter(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("preserve_connections: bool = True", src)

    def test_backend_preserved_log(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_BACKEND_PRESERVED", src)

    def test_backend_reset_safe_log(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_BACKEND_RESET — backend is not started", src)

    def test_checks_started_and_pytgcalls(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def vc_reset_backend")
        body = src[idx:idx + 2000]  # increased window
        self.assertIn("_still_started", body)
        self.assertIn("_has_pytgcalls", body)


class TestBackendStopInstrumentation(unittest.TestCase):
    """v97.86: backend.stop() logs VC_BACKEND_STOP_REQUEST."""

    def test_backend_stop_request_logged(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_BACKEND_STOP_REQUEST", src)
        self.assertIn("caller=", src)
        self.assertIn("backend_id=", src)
        self.assertIn("THIS CAN DISCONNECT ALL VCs", src)


class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_92(self):
        with open(_INIT) as f:
            src = f.read()
        self.assertIn('__bot_version__ = "v99.11.2"', src)


class TestPreservedFixes(unittest.TestCase):
    """Verify all prior fixes preserved."""

    def test_stale_joined_record(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_STALE_JOINED_RECORD", src)

    def test_backend_connected_check(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_backend_connected", src)
        self.assertIn("vc_resolve_calls_container", src)

    def test_is_open_property(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("VC_TRACKING_SNAPSHOT")
        block = src[idx:idx + 1200]
        self.assertIn("_vc_join_all_breaker.is_open ", block)

    def test_pytgcalls_filter(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("list_event_handlers", src)

    def test_floodwait_defer(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_TARGET_FLOODWAIT_DEFERRED", src)

    def test_leave_block(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_LEAVE_BLOCKED_DURING_JOIN_ALL", src)

    def test_diagnostic_logging(self):
        utils = os.path.join(_BASE, "mediagrab_bot", "utils_real.py")
        with open(utils) as f:
            src = f.read()
        self.assertIn("DIAGNOSTIC_LOGGING_INITIALIZED", src)

    def test_forced_cancel(self):
        mtproto = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
        with open(mtproto) as f:
            src = f.read()
        self.assertIn("_mediagrab_bg_tasks", src)


class TestBackendPreservationBehavioral(unittest.TestCase):
    """Test that backend preservation prevents VC disconnection."""

    def test_preserve_when_started(self):
        """When backend is started + has pytgcalls, preserve it."""
        _vc_backend_started = True
        _vc_backend_pytgcalls = True  # not None
        preserve = _vc_backend_started and _vc_backend_pytgcalls
        self.assertTrue(preserve, "backend must be preserved when active")

    def test_reset_when_not_started(self):
        """When backend is NOT started, safe to reset."""
        _vc_backend_started = False
        _vc_backend_pytgcalls = None
        preserve = _vc_backend_started and (_vc_backend_pytgcalls is not None)
        self.assertFalse(preserve, "backend must be reset when not active")

    def test_reset_when_no_pytgcalls(self):
        """When backend has no pytgcalls, safe to reset."""
        _vc_backend_started = True
        _vc_backend_pytgcalls = None
        preserve = _vc_backend_started and (_vc_backend_pytgcalls is not None)
        self.assertFalse(preserve, "backend must be reset when no pytgcalls")


if __name__ == "__main__":
    unittest.main()
