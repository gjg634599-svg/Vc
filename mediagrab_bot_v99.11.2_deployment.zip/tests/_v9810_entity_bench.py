"""v98.10 §38 — LOG-DRIVEN REGRESSION BENCHMARK (controlled/mock).

Reproduces the EXACT bot-diagnostic (3).log failure world in a
controlled fake-Telethon environment and measures the entity-resolution
behavior BEFORE (P3 tree) and AFTER (v98.10 tree):

  World (scaled from the production log's 46-entity window):
    * N entities, each a channel that ONLY account acc_B has in its
      session (the primary/global client is NOT a member) with a hash
      valid ONLY for acc_B (Telegram access hashes are account-scoped).
    * The vc_groups DB row for each entity carries acc_B's hash (the
      production state: the hash was persisted with no account
      attribution).
    * The Join-All classification loop calls
      resolve_vc_entity(primary, marked, chat_id=marked,
      access_hash=db_hash) — the EXACT production call — then, on
      success, "detects" via a GetFullChannelRequest on the client the
      resolution source routes to (mirroring the worker's v98.07
      source-based detection routing).

  Cycles measured:
    cycle 1  — first run after restart (fresh caches)
    cycle 2  — steady state, same process
    cycle 3  — after a "restart": persistence flushed + module reloaded

  Metrics per cycle (mirroring the production log's counters):
    invalid_channel_object   — "Invalid channel object (caused by
                                GetChannelsRequest)" occurrences
    input_entity_miss        — "Could not find the input entity" count
    peeruser_miss            — of which the misleading PeerUser form
    rotations                — resolve_across_accounts invocations
    rpcs                     — total RPC ledger entries
    lat_ms                   — total wall time

Usage: python3 tests/_v9810_entity_bench.py <tree-root> [--entities N]
Prints one JSON line per cycle.  Live Telegram access is NOT available
in the sandbox — this is a CONTROLLED/MOCK verification (§38): the
error texts, RPC shapes and per-account hash semantics mirror Telethon
1.44 (verified against its source).
"""
from __future__ import annotations

import asyncio
import json
import sys
import time
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _v9810_entity_driver as drv  # noqa: E402  (shared fake world)

MARKED_BASE = -1000000000000
N_DEFAULT = 20


def build_world(n: int):
    """N channels only acc_B can see, with acc_B-owned hashes."""
    drv.WORLD.channels.clear()
    drv.WORLD.sessions.clear()
    for i in range(n):
        raw = 1000000 + i
        drv.WORLD.add_channel(
            raw, title=f"bench-{i}",
            accounts={"acc_B": 900000 + i}, session=["acc_B"])


def derive_detect_client(res: dict, primary, acc_b):
    """Mirror the worker's v98.07 source-based detection routing."""
    src = str(res.get("source") or "")
    if "account_rotation:" in src:
        aid = src.split("account_rotation:")[1].split(":")[0].split(",")[0]
        if aid == "acc_B":
            return acc_b
    return primary


async def run_cycle(mt, primary, acc_b, n: int, cycle: str) -> dict:
    drv.LEDGER.reset()
    _ROT[0] = 0
    t0 = time.monotonic()
    resolved = 0
    for i in range(n):
        raw = 1000000 + i
        marked = MARKED_BASE - raw
        db_hash = 900000 + i  # acc_B's hash — foreign to the primary
        res = await mt.resolve_vc_entity(
            primary, marked, chat_id=marked, access_hash=db_hash)
        if res.get("ok"):
            resolved += 1
            # "detection" on the routed client (the worker's next step)
            detect_client = derive_detect_client(res, primary, acc_b)
            ch = res["entity"]
            try:
                await mt.mtproto_call_with_retry(
                    detect_client, drv.GetFullChannelRequest(channel=ch))
            except Exception:
                # the v98.07 ChannelInvalid → evict + rereresolve loop is
                # the production steady-state failure; count it as the
                # detection failure it is
                drv.LEDGER.invalid_channel_object += 1
    dt_ms = (time.monotonic() - t0) * 1000.0
    return {
        "cycle": cycle,
        "entities": n,
        "resolved": resolved,
        "invalid_channel_object": drv.LEDGER.invalid_channel_object,
        "input_entity_miss": drv.LEDGER.input_entity_miss,
        "peeruser_miss": drv.LEDGER.peeruser_miss,
        "rotations": _ROT[0],
        "rpcs": drv.LEDGER.total(),
        "lat_ms": round(dt_ms, 2),
    }


def _instrument_rotations(mt) -> None:
    """Count resolve_across_accounts invocations on BOTH trees (the P3
    tree has no _v9810_resolution_stats)."""
    orig = mt.resolve_across_accounts
    _ROT[0] = 0

    async def _counting(chat_ref, *a, **kw):
        _ROT[0] += 1
        return await orig(chat_ref, *a, **kw)

    mt.resolve_across_accounts = _counting


_ROT = [0]


async def run_benchmark(root: str, n: int) -> list[dict]:
    import tempfile
    tmp = tempfile.mkdtemp(prefix=f"bench_{Path(root).name}_")
    Path(tmp, "data").mkdir(parents=True, exist_ok=True)
    drv.install_stubs_for_root(tmp, root)
    mt = drv.load_real_mtproto_from_root(root)
    mt.mtproto_call_with_retry = drv._dispatch_mtproto_call
    _instrument_rotations(mt)
    primary, acc_b, _ = drv._mk_accounts(mt)
    build_world(n)

    out = []
    out.append(await run_cycle(mt, primary, acc_b, n, "1-first-run"))
    out.append(await run_cycle(mt, primary, acc_b, n, "2-steady-state"))

    # "restart": flush + reload
    try:
        await mt._flush_access_hash_persistence()
    except Exception:
        pass
    pfile = Path(getattr(mt, "_VC_ACCESS_HASH_FILE", Path(tmp) / "no.json"))
    root2 = str(pfile.parent.parent)
    drv.install_stubs_for_root(root2, root)
    mt2 = drv.load_real_mtproto_from_root(root)
    mt2.mtproto_call_with_retry = drv._dispatch_mtproto_call
    _instrument_rotations(mt2)
    primary2, acc_b2, _ = drv._mk_accounts(mt2)
    out.append(await run_cycle(mt2, primary2, acc_b2, n, "3-after-restart"))
    return out




# ---------------------------------------------------------------------------
# §24 scenario matrix: each situation measured SEPARATELY (1 entity per
# scenario, fresh module state between scenarios; metrics = the §38
# counters for exactly that situation's first resolution + a second
# resolution in the same process).
# ---------------------------------------------------------------------------
def _scenario_worlds():
    """raw_id → world-builder.  Each scenario sets up ONE entity."""
    def fresh_cache():
        drv.WORLD.add_channel(3100001, title="fresh",
                              accounts={"global": 4242}, session=["global"])
        return 3100001, 4242
    def stale_cache():
        # global-scope knowledge that expired (verified_at beyond TTL)
        drv.WORLD.add_channel(3100002, title="stale",
                              accounts={"global": 4243}, session=["global"])
        return 3100002, 4243
    def bad_access_hash():
        # the DB hash is acc_B's (foreign to the primary consumer)
        drv.WORLD.add_channel(3100003, title="bad-hash",
                              accounts={"acc_B": 4244}, session=["acc_B"])
        return 3100003, 4244
    def wrong_entity_type():
        # a basic group (legacy -<id>) probed with the correct machinery
        drv.WORLD.chats[3100004] = drv.Chat(id=3100004, title="basic")
        return -3100004, 0
    def private_channel():
        # no session, no hash — the channel is invisible to everyone
        drv.WORLD.add_channel(3100005, title="private", accounts={},
                              session=[])
        return 3100005, 0
    def unresolvable():
        # unknown id — nothing in the world
        return 3100999, 0
    def secondary_owned():
        # active VC on an acc_B-only channel (the production 46 case)
        drv.WORLD.add_channel(3100006, title="sec-owned",
                              accounts={"acc_B": 4246}, session=["acc_B"])
        return 3100006, 4246
    def already_joined():
        # global-owned channel the primary already resolved (flat cache)
        drv.WORLD.add_channel(3100007, title="joined",
                              accounts={"global": 4247}, session=["global"])
        return 3100007, 4247
    return [
        ("fresh-cache", fresh_cache),
        ("stale-cache", stale_cache),
        ("bad-access-hash", bad_access_hash),
        ("wrong-entity-type", wrong_entity_type),
        ("private-channel", private_channel),
        ("unresolvable", unresolvable),
        ("secondary-account-owned", secondary_owned),
        ("already-joined", already_joined),
    ]


async def run_scenarios(root: str) -> list[dict]:
    import tempfile
    out = []
    for name, builder in _scenario_worlds():
        tmp = tempfile.mkdtemp(prefix=f"sc_{name}_")
        Path(tmp, "data").mkdir(parents=True, exist_ok=True)
        drv.WORLD.channels.clear()
        drv.WORLD.sessions.clear()
        drv.WORLD.chats.clear()
        drv.WORLD.users.clear()
        drv.install_stubs_for_root(tmp, root)
        mt = drv.load_real_mtproto_from_root(root)
        mt.mtproto_call_with_retry = drv._dispatch_mtproto_call
        primary, acc_b, _ = drv._mk_accounts(mt)
        raw_or_ref, db_hash = builder()
        if raw_or_ref > 0:
            marked = MARKED_BASE - raw_or_ref
        else:
            marked = raw_or_ref
        # first resolution
        r1 = await run_one(mt, primary, marked, db_hash)
        # second resolution (same process — convergence)
        r2 = await run_one(mt, primary, marked, db_hash)
        out.append({
            "scenario": name, "ref": marked,
            "resolve1": r1["ok"], "source1": r1.get("source", ""),
            "rpcs1": r1.get("rpcs", drv.LEDGER.total()),
            "invalid1": r1.get("invalid", 0),
            "resolve2": r2["ok"], "rpcs2": r2.get("rpcs", 0),
            "invalid2": r2.get("invalid", 0),
        })
    return out


async def run_one(mt, primary, marked, db_hash):
    drv.LEDGER.reset()
    _ROT[0] = 0
    try:
        res = await mt.resolve_vc_entity(
            primary, marked, chat_id=marked, access_hash=db_hash)
        res["invalid"] = drv.LEDGER.invalid_channel_object
        res["rotations"] = _ROT[0]
        return res
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "source": type(exc).__name__,
                "invalid": drv.LEDGER.invalid_channel_object,
                "rotations": _ROT[0], "rpcs": drv.LEDGER.total()}


def main() -> int:
    root = sys.argv[1] if len(sys.argv) > 1 else str(
        Path(__file__).resolve().parents[1])
    n = N_DEFAULT
    if "--entities" in sys.argv:
        n = int(sys.argv[sys.argv.index("--entities") + 1])
    if "--scenarios" in sys.argv:
        for r in asyncio.run(run_scenarios(root)):
            print(json.dumps(r))
        return 0
    results = asyncio.run(run_benchmark(root, n))
    for r in results:
        print(json.dumps(r))
    return 0


if __name__ == "__main__":
    sys.exit(main())
