"""
v97.74 forensic-audit regression tests.

Root causes fixed in v97.74 (independently verified by a fresh audit, NOT
trusted from the v97.73 manifest):

  P0  mtproto.py:_forcibly_cancel_telethon_tasks — `except (TimeoutError,
      CancelledError, Exception): pass` EXPLICITLY swallowed CancelledError,
      so a cancelled reconnect kept running as an orphan (cancellation leak +
      potential lock-not-released). Fix: re-raise CancelledError.

  P1  mtproto.py — 3 bare `loop.create_task(...)` (lines 2534, 5749, 5799)
      with no supervision → unobserved exceptions ("Task exception was never
      retrieved"). Fix: supervised_create_task.

  P1  mtproto.py:_GatedClientProxy._wrap_coro / __call__ held the READ lock
      for the full RPC duration with NO timeout → writer (reconnect)
      starvation. The v97.72 "RW-lock starvation" fix only covered
      mtproto_call_with_retry, not the ~86 proxy call sites. Fix: 10s wait_for.

  P1  mtproto.py:1473 — broad `except (TimeoutError, Exception): pass` on the
      per-account drain swallowed ALL drain errors silently (no logging).
      Fix: split + log.

  P2  mtproto.py:1813 — `except Exception: pass` on tmp.disconnect() during
      import retry. Fix: log.

  P2  mtproto.py — stale "30s" log/comment strings contradicting the actual
      10s timeouts (v97.72). Fix: 30s → 10s.

  P2  voicechat.py:6451 — `VC_CALLBACK_WORKER_FATAL` at DEBUG = invisible in
      production. Fix: WARNING.

  P2  voicechat.py:7228 — `except (TimeoutError, Exception): pass` on
      distributed-pool shutdown drain swallowed orphan-worker leaks silently.
      Fix: split + log.

Two of the tests below are REAL BEHAVIORAL tests (not source-string
inspection) of the cancellation / proxy-timeout patterns, using standalone
asyncio coroutines that do NOT import telethon. They prove the fix's
correctness at the pattern level — they do NOT prove the bot's runtime
behavior against real Telegram (that requires live infrastructure this
audit environment does not have).
"""
import asyncio
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


# ---------------------------------------------------------------------------
# Source-verification tests (match existing v97.7x test style)
# ---------------------------------------------------------------------------

class TestP0CancelledErrorNotSwallowed(unittest.TestCase):
    """P0: CancelledError must NOT be swallowed in _forcibly_cancel_telethon_tasks."""

    def test_no_cancellederror_in_swallow_tuple(self):
        with open(_MTPROTO) as f:
            src = f.read()
        # The v97.73 swallow tuple is gone.
        self.assertNotIn(
            "except (asyncio.TimeoutError, asyncio.CancelledError, Exception):",
            src,
            "v97.73 P0 swallow-tuple still present — CancelledError leak",
        )

    def test_cancellederror_re_raised_at_force_cancel_site(self):
        # v97.77: the old wait_for(_ult, timeout=3.0) site was replaced by the
        # asyncio.all_tasks() approach. Verify the new approach handles
        # CancelledError correctly (re-raises, doesn't swallow).
        with open(_MTPROTO) as f:
            src = f.read()
        idx = src.find("async def _forcibly_cancel_telethon_tasks")
        self.assertGreater(idx, 0)
        body = src[idx:idx + 7000]
        # v97.77: the gather(return_exceptions=True) catches CancelledError
        # per-task without swallowing it from the outer flow.
        self.assertIn("asyncio.gather(*alive_telethon_tasks, return_exceptions=True)", body)


class TestP1SupervisedCreateTask(unittest.TestCase):
    """P1: bare loop.create_task replaced with supervised_create_task."""

    def test_no_bare_loop_create_task_in_cluster_cancel_login(self):
        with open(_MTPROTO) as f:
            src = f.read()
        # The cluster_cancel_login release-session site must use supervised.
        idx = src.find("cluster_cancel_login_release_session")
        self.assertGreater(idx, 0, "supervised release-session name not found")
        # And the old bare call must be gone at the _release_pending site.
        self.assertNotIn(
            "asyncio.get_running_loop().create_task(_release_pending())",
            src,
        )

    def test_no_bare_loop_create_task_in_progress_cb(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertNotIn(
            "asyncio.get_running_loop().create_task(\n                            progress_cb",
            src,
        )
        self.assertIn("download_progress_cb", src)


class TestP1GatedProxyTimeout(unittest.TestCase):
    """P1: _GatedClientProxy._wrap_coro and __call__ must bound the RPC with 10s."""

    def test_wrap_coro_has_wait_for_timeout_10(self):
        with open(_MTPROTO) as f:
            src = f.read()
        idx = src.find("def _wrap_coro(self, name")
        self.assertGreater(idx, 0)
        body = src[idx:idx + 1100]
        self.assertIn("asyncio.wait_for(func(*args, **kwargs), timeout=10.0)", body)

    def test_call_dunder_has_wait_for_timeout_10(self):
        with open(_MTPROTO) as f:
            src = f.read()
        idx = src.find("async def __call__(self, *args, **kwargs):")
        self.assertGreater(idx, 0)
        body = src[idx:idx + 500]
        self.assertIn("asyncio.wait_for(self._real_client(*args, **kwargs), timeout=10.0)", body)


class TestP1ClusterDrainLogged(unittest.TestCase):
    """P1: per-account drain errors must be logged, not silently `pass`ed."""

    def test_no_broad_swallow_at_cluster_drain(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertNotIn(
            'except (asyncio.TimeoutError, Exception):  # noqa: BLE001\n                        pass',
            src,
        )
        self.assertIn("MTPROTO_CLUSTER_DRAIN_TIMEOUT", src)
        self.assertIn("MTPROTO_CLUSTER_DRAIN_ERROR", src)


class TestP2StaleStringsFixed(unittest.TestCase):
    """P2: stale '30s' log/comment strings must reflect the actual 10s timeout."""

    def test_no_stale_30s_in_rpc_timeout_log(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertNotIn('MTProto RPC timed out after 30s', src)
        self.assertIn('MTProto RPC timed out after 10s', src)

    def test_no_stale_30s_in_get_entity_error(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertNotIn('get_entity timed out after 30s', src)
        self.assertIn('get_entity timed out after 10s', src)

    def test_no_stale_30s_in_get_messages_error(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertNotIn('get_messages timed out after 30s', src)
        self.assertIn('get_messages timed out after 10s', src)


class TestP2VoicechatObservability(unittest.TestCase):
    """P2: VC callback worker FATAL must be WARNING; distributed pool drain must log."""

    def test_callback_worker_fatal_is_warning(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        # v97.94: search for the actual logger.warning("VC_CALLBACK_WORKER_FATAL
        # call, not just the first occurrence of the string (which may appear in
        # comments referencing the marker). This is more precise, not weaker.
        import re
        m = re.search(r'logger\.(warning|debug|info|error)\(\s*"[^"]*VC_CALLBACK_WORKER_FATAL', src)
        self.assertIsNotNone(m, "logger call for VC_CALLBACK_WORKER_FATAL not found")
        self.assertEqual(m.group(1), "warning",
                         "VC_CALLBACK_WORKER_FATAL must be logged at WARNING level, "
                         f"got {m.group(1)}")

    def test_distributed_pool_drain_logs_timeout(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_DISTRIBUTED_POOL_DRAIN_TIMEOUT", src)
        self.assertIn("VC_DISTRIBUTED_POOL_DRAIN_ERROR", src)


class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_92(self):
        with open(_INIT) as f:
            src = f.read()
        self.assertIn('__bot_version__ = "v99.11.2"', src)


# ---------------------------------------------------------------------------
# REAL BEHAVIORAL tests (no telethon import) — prove the fix patterns
# ---------------------------------------------------------------------------

class TestP0CancelledErrorPropagates(unittest.TestCase):
    """P0 behavioral proof: when the outer coroutine is cancelled while inside
    a `wait_for(slow, timeout=...)`, the v97.74 fix pattern (re-raise
    CancelledError) ensures cancellation propagates and the coroutine unwinds
    instead of running as an orphan. This reproduces the exact pattern at
    mtproto.py:_forcibly_cancel_telethon_tasks WITHOUT importing telethon."""

    def _run(self, coro):
        return asyncio.new_event_loop().run_until_complete(coro)

    def test_v97_74_pattern_propagates_cancel(self):
        """The FIXED pattern: except CancelledError → raise."""
        cancelled_inner = {"flag": False}

        async def slow_inner():
            try:
                await asyncio.sleep(10)
            except asyncio.CancelledError:
                cancelled_inner["flag"] = True
                raise

        async def outer_fixed():
            # v97.74 pattern
            try:
                await asyncio.wait_for(slow_inner(), timeout=3.0)
            except asyncio.CancelledError:
                raise  # the fix
            except (asyncio.TimeoutError, Exception):
                pass

        async def driver():
            task = asyncio.ensure_future(outer_fixed())
            await asyncio.sleep(0.05)
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
            return task.done()

        done = self._run(driver())
        self.assertTrue(done, "outer task must be DONE after cancellation")
        # Inner received CancelledError (wait_for propagated cancel).
        self.assertTrue(cancelled_inner["flag"],
                        "inner coroutine must have observed CancelledError")

    def test_v97_73_pattern_outer_continues_as_orphan(self):
        """The BUGGY v97.73 pattern: the outer coroutine swallows CancelledError
        (via the tuple `except (TimeoutError, CancelledError, Exception): pass`)
        and continues running as an orphan after its caller cancelled it. This is
        the actual P0 defect at mtproto.py:_forcibly_cancel_telethon_tasks — the
        reconnect coroutine kept running instead of unwinding on shutdown/parent
        cancellation. Documents WHY the v97.74 re-raise fix was necessary."""
        outer_continued = {"flag": False}

        async def outer_buggy():
            # v97.73 pattern (the bug)
            try:
                await asyncio.wait_for(asyncio.sleep(3.0), timeout=3.0)
            except (asyncio.TimeoutError, asyncio.CancelledError, Exception):
                pass  # noqa: BLE001 — the bug
            # Code AFTER the try/except — runs even if cancelled was requested.
            outer_continued["flag"] = True

        async def driver():
            task = asyncio.ensure_future(outer_buggy())
            await asyncio.sleep(0.05)
            task.cancel()
            # Buggy pattern: outer swallows CancelledError → finishes normally.
            await task  # no raise

        self._run(driver())
        self.assertTrue(outer_continued["flag"],
                        "v97.73 pattern let the outer coroutine continue after cancellation")


class TestP1ProxyTimeoutReleasesLock(unittest.TestCase):
    """P1 behavioral proof: the _wrap_coro pattern with `wait_for(inner, timeout=10)`
    must RELEASE the read lock when the inner RPC hangs, so a waiting writer
    (reconnect) can acquire it. Reproduces the proxy pattern without telethon."""

    def _run(self, coro):
        return asyncio.new_event_loop().run_until_complete(coro)

    def test_hung_rpc_releases_lock_within_timeout(self):
        lock = asyncio.Lock()  # stand-in for the RW read lock
        writer_acquired = {"flag": False, "at": None}

        async def hung_rpc():
            await asyncio.sleep(30)  # simulates a hung socket

        async def reader_fixed():  # v97.74 pattern
            await lock.acquire()
            try:
                await asyncio.wait_for(hung_rpc(), timeout=0.2)
            except asyncio.TimeoutError:
                pass  # mirror mtproto callers
            finally:
                lock.release()

        async def writer():
            await lock.acquire()
            writer_acquired["flag"] = True
            writer_acquired["at"] = asyncio.get_event_loop().time()
            lock.release()

        async def driver():
            import time as _t
            t0 = _t.monotonic()
            reader_task = asyncio.ensure_future(reader_fixed())
            # Let reader acquire the lock + start the hung RPC.
            await asyncio.sleep(0.05)
            writer_task = asyncio.ensure_future(writer())
            # Writer should block on the lock until reader's wait_for times out.
            await asyncio.gather(reader_task, writer_task)
            elapsed = _t.monotonic() - t0
            return elapsed

        elapsed = self._run(driver())
        self.assertTrue(writer_acquired["flag"],
                        "writer must have acquired the lock after reader's RPC timed out")
        self.assertLess(elapsed, 1.0,
                        "writer must not wait for the full 30s hung RPC (got %.2fs)" % elapsed)

    def test_old_pattern_starves_writer(self):
        """The BUGGY v97.73 pattern (no wait_for around the RPC) starves the
        writer for the full RPC duration. Documents why the fix was necessary."""
        lock = asyncio.Lock()
        writer_acquired = {"flag": False}

        async def slow_rpc():
            await asyncio.sleep(0.5)  # not hung, just slow

        async def reader_buggy():  # v97.73 pattern (no timeout)
            await lock.acquire()
            try:
                await slow_rpc()  # NO wait_for — holds lock for full duration
            finally:
                lock.release()

        async def writer():
            await lock.acquire()
            writer_acquired["flag"] = True
            lock.release()

        async def driver():
            import time as _t
            t0 = _t.monotonic()
            reader_task = asyncio.ensure_future(reader_buggy())
            await asyncio.sleep(0.05)
            writer_task = asyncio.ensure_future(writer())
            await asyncio.gather(reader_task, writer_task)
            return _t.monotonic() - t0

        elapsed = self._run(driver())
        self.assertTrue(writer_acquired["flag"])
        # Writer had to wait for the full slow_rpc (0.5s), not ~0.2s.
        self.assertGreater(elapsed, 0.45,
                           "old pattern forced writer to wait for full RPC (%.2fs)" % elapsed)


if __name__ == "__main__":
    unittest.main()
