#!/usr/bin/env python3
"""v98.13 §VERIF — VC JOIN-VERIFICATION regression suite.

Covers the production-proven root causes from bot-diagnostic.log
(2026-09-09 04:41–05:11, the v98.12 FINAL-2 build):

  RC-1  32/32 VC_JOIN_CONFIRMED fired on status=calls (LOCAL PyTgCalls
        container) — no Telegram-side participant check at join time.
  RC-2  31/32 VC_JOIN_EVIDENCE events were
        source=backend_calls_container strength=container_only_no_call_id
        mapped to evidence=positive → "joined".
  RC-3  19× VC_PARTICIPATION_TARGETED_EMPTY_RESULT ("targeted query
        returned None") fell back to UNKNOWN forever (the FIX-L streak
        only counted empty lists — None results never converged).
  RC-4  9× InterdcCallErrorError/InterdcCallRichErrorError (DC 4,
        JoinGroupCallRequest) failed targets after Telethon's 4 quick
        internal retries — no app-level exponential backoff.

Fix contract (user requirements 1–13):
  * join() runs the Telegram-side participant verification gate
    (_vc_join_telegram_gate) BEFORE any "joined successfully" reporting.
  * VCJoinUnverifiedError (VCTransportError subclass) is the honest
    UNKNOWN outcome; the Join-All worker maps it to confirmation_unknown
    (never joined_confirmed, never failed+breaker).
  * verify_joined NEVER returns True from container-only evidence —
    only participant data (or the ≤60s join-time gate cache) qualifies.
  * InterdcCall/transport/timeout errors are retried with exponential
    backoff on the SAME PyTgCalls client (VC_JOIN_TRANSIENT_DC_RETRY).
  * Per-(account, chat) in-flight coalescing prevents duplicate
    simultaneous JoinGroupCallRequests (VC_JOIN_COALESCED).
  * pytgcalls is PINNED to ==2.3.3 (requirements + pyproject).

Mix: source-pattern tests (marker discipline) + behavioural tests
(extract-and-exec, the v98 driver methodology).
"""
from __future__ import annotations

import asyncio
import os
import re
import sys
import types
import unittest
from pathlib import Path

_SRC = Path(__file__).resolve().parent.parent / "mediagrab_bot"
_VC = (_SRC / "voicechat.py").read_text(encoding="utf-8")
_PIPE = (_SRC / "vc_pipeline.py").read_text(encoding="utf-8")
_REQ = (Path(__file__).resolve().parent.parent / "requirements.txt").read_text(encoding="utf-8")
_PROJ = (Path(__file__).resolve().parent.parent / "pyproject.toml").read_text(encoding="utf-8")


def _grab_fn(src: str, name: str) -> str:
    m = re.search(rf"^(?:async )?def {name}\(.*?(?=^(?:async )?def |^class |\Z)",
                  src, re.M | re.S)
    if m is None:
        raise AssertionError(f"function {name} not found in voicechat.py")
    return m.group(0)


def _exec_fn(src: str, name: str, ns: dict):
    code = compile(_grab_fn(src, name), "<voicechat-extract>", "exec")
    exec(code, ns)  # noqa: S102 — test harness
    return ns[name]


# ---------------------------------------------------------------------------
# Section A — join-time Telegram verification gate (source pattern)
# ---------------------------------------------------------------------------

class TestJoinTelegramGateSource(unittest.TestCase):
    def setUp(self):
        self.vc = _VC
        self.pipe = _PIPE

    def test_gate_function_exists(self):
        # v99: the gate lives in the canonical pipeline as the bounded
        # Telegram-side participant verification loop.
        self.assertIn("async def _verify_participation(", self.pipe)

    def test_gate_called_in_join_before_success_reporting(self):
        # v99: join() delegates to the canonical pipeline BEFORE any
        # success reporting, and the pipeline runs the Telegram-side
        # participant verification BEFORE JOINED_CONFIRMED is reachable.
        join_idx = self.vc.find("async def join(self, chat_ref")
        pipe_idx = self.vc.find("from .vc_pipeline import run_vc_join")
        success_idx = self.vc.find("VC_JOIN_SUCCESS chat_id=%s call_id=%s strategy=%s ")
        self.assertGreater(join_idx, 0)
        self.assertGreater(pipe_idx, join_idx)
        self.assertGreater(success_idx, pipe_idx,
                           "VC_JOIN_SUCCESS must come AFTER the pipeline delegation")
        # the pipeline verifies participants before confirming
        verify_idx = self.pipe.find('TELEGRAM_VERIFYING, "participant_gate"')
        confirmed_idx = self.pipe.find('"participant_confirmed"')
        self.assertGreater(verify_idx, 0)
        self.assertGreater(confirmed_idx, verify_idx,
                           "JOINED_CONFIRMED must come AFTER participant verification")

    def test_success_line_carries_telegram_verified(self):
        self.assertIn("telegram_verified=true verify_result=present", self.vc)

    def test_unverified_never_emits_join_success(self):
        # The pipeline's post-verification section handles "present"
        # FIRST and falls through to the typed UNVERIFIED raise for the
        # unknown verdict — success is unreachable without "present".
        present_idx = self.pipe.find('if verdict == "present":')
        unv_idx = self.pipe.find('raise VCJoinUnverifiedError(')
        self.assertGreater(present_idx, 0)
        self.assertGreater(unv_idx, present_idx,
                           "the unverified raise guards the fallthrough "
                           "after the present branch")
        # the machine can only reach JOINED_CONFIRMED from
        # TELEGRAM_VERIFYING (validated transitions — no container
        # shortcut)
        self.assertIn(
            "VCJoinState.TELEGRAM_VERIFYING: {\n        "
            "VCJoinState.JOINED_CONFIRMED", self.pipe)
        # in join(): the success log follows the delegation
        pipe_call = self.vc.find("outcome = await run_vc_join(")
        success_log = self.vc.find("VC_JOIN_SUCCESS chat_id=%s call_id=%s strategy=%s ")
        self.assertGreater(pipe_call, 0)
        self.assertGreater(success_log, pipe_call)

    def test_unverified_marker_logged(self):
        self.assertIn("VC_JOIN_UNVERIFIED chat_id=%s call_id=%s account=%s", self.pipe)

    def test_call_ended_marker_logged(self):
        self.assertIn("VC_JOIN_CALL_ENDED_DURING_JOIN", self.pipe)

    def test_gate_uses_participant_verification(self):
        # v99: the pipeline's verification loop calls
        # vc_check_telegram_participation (participant list), not just a
        # call-existence check.
        gate_src = _grab_fn(self.pipe, "_verify_participation")
        self.assertIn("vc_check_telegram_participation(", gate_src)

    def test_gate_bounded_attempts_and_backoff(self):
        # v99: the loop's bounds come from the same env knobs (the cfg
        # fields are seeded from VC_JOIN_TG_VERIFY_*).
        self.assertIn("VC_JOIN_TG_VERIFY_ATTEMPTS", self.pipe)
        self.assertIn("VC_JOIN_TG_VERIFY_BACKOFF_BASE", self.pipe)
        self.assertIn("VC_JOIN_TG_VERIFY_BUDGET", self.pipe)
        gate_src = _grab_fn(self.pipe, "_verify_participation")
        self.assertIn("2 ** (attempt - 1)", gate_src)  # exponential backoff

    def test_gate_identity_refresh_on_stale_identity(self):
        # v99.05 RC-F4 (FINAL REBUILD): the stale-identity hygiene is
        # INLINED in _verify_participation — an "absent"/stale verdict
        # triggers a PURE current-identity re-detect (_current_call_identity,
        # no registry writes — the pipeline is the single writer) and a
        # CHANGED pair is adopted + re-verified (mission §13 STALE_CALL).
        # The historical _call_gone_evidence/"refreshed"/registry adoption
        # is REMOVED (it registered state=joined on absent verdicts — the
        # 2026-09-12 phantom bookkeeping).
        gate_src = _grab_fn(self.pipe, "_verify_participation")
        self.assertIn("_current_call_identity(", gate_src)
        self.assertIn('"call_ended"', gate_src)
        self.assertIn("VC_CALL_IDENTITY_CHANGED", gate_src)
        self.assertNotIn("_call_gone_evidence(", gate_src)

    def test_gate_infeasible_fails_fast(self):
        # v99: the identity resolution layer fails fast with an honest
        # client=NONE when no verification client exists (the run then
        # takes the honest unknown path — never a fake verification).
        resolve_idx = self.pipe.find("async def resolve(backend: Any")
        self.assertGreater(resolve_idx, 0, "VCAccountIdentity.resolve must exist")
        resolve_src = self.pipe[resolve_idx:resolve_idx + 4000]
        self.assertIn("client is None", resolve_src)
        gate_src = _grab_fn(self.pipe, "_verify_participation")
        self.assertIn('except Exception', gate_src)  # query failures → unknown


# ---------------------------------------------------------------------------
# Section B — typed error + worker mapping (source pattern)
# ---------------------------------------------------------------------------

class TestVCJoinUnverifiedErrorSource(unittest.TestCase):
    def setUp(self):
        self.vc = _VC

    def test_error_class_is_vctransport_subclass(self):
        self.assertIn("class VCJoinUnverifiedError(VCTransportError):", self.vc)

    def test_worker_maps_typed_error_to_confirmation_unknown(self):
        # The Join-All worker must intercept VCJoinUnverifiedError BEFORE
        # the generic VCTransportError handler.
        typed_idx = self.vc.find("except VCJoinUnverifiedError as exc:")
        generic_idx = self.vc.find("except VCTransportError as exc:")
        self.assertGreater(typed_idx, 0)
        self.assertGreater(generic_idx, typed_idx)
        following = self.vc[typed_idx:typed_idx + 1600]
        self.assertIn('result_state = "confirmation_unknown"', following)
        self.assertIn("VC_JOIN_ALL_TARGET_UNVERIFIED", following)

    def test_worker_unverified_not_breaker_failure(self):
        typed_idx = self.vc.find("except VCJoinUnverifiedError as exc:")
        following = self.vc[typed_idx:typed_idx + 1600]
        self.assertNotIn("record_failure", following,
                         "unverified joins must NOT count as breaker failures")

    def test_distributed_path_maps_typed_error(self):
        dist_idx = self.vc.find(
            "except VCJoinUnverifiedError:\n        # v98.13 §GATE")
        self.assertGreater(dist_idx, 0)
        following = self.vc[dist_idx:dist_idx + 1800]
        self.assertIn('return "confirmation_unknown", aid', following)

    def test_distributed_generic_handler_after_typed(self):
        # _vc_distributed_join_attempt must catch the typed error BEFORE
        # the generic Exception handler (which would mark it retriable).
        dist_idx = self.vc.find("except VCJoinUnverifiedError:\n")
        gen_idx = self.vc.find("return f\"failed:{type(exc).__name__}\"")
        self.assertGreater(dist_idx, 0)
        self.assertGreater(gen_idx, dist_idx)


# ---------------------------------------------------------------------------
# Section C — verify_joined strictness (source pattern)
# ---------------------------------------------------------------------------

class TestVerifyJoinedStrictnessSource(unittest.TestCase):
    def setUp(self):
        self.vc = _VC

    def test_container_only_no_call_id_not_positive(self):
        idx = self.vc.find("strength=container_only_no_call_id")
        self.assertGreater(idx, 0)
        following = self.vc[idx:idx + 1200]
        self.assertNotIn('return True', following,
                         "container_only_no_call_id must NOT return True")

    def test_container_only_corroboration_inconclusive_not_positive(self):
        idx = self.vc.find("strength=container_only — corroboration")
        self.assertGreater(idx, 0)
        following = self.vc[idx:idx + 600]
        self.assertNotIn("return True", following)

    def test_call_exists_is_not_participant_proof(self):
        idx = self.vc.find('evidence=call_alive strength=weak — call EXISTS')
        self.assertGreater(idx, 0,
                           "call-exists corroboration must be marked weak, "
                           "not positive")

    def test_telegram_unknown_with_backend_not_positive(self):
        idx = self.vc.find("reason=telegram_unknown_but_backend_confirmed")
        self.assertGreater(idx, 0)
        following = self.vc[idx:idx + 700]
        self.assertNotIn("return True", following,
                         "telegram_unknown + container must be UNKNOWN, "
                         "not True")

    def test_telegram_exception_with_backend_not_positive(self):
        idx = self.vc.find("reason=telegram_exception_but_backend_confirmed")
        self.assertGreater(idx, 0)
        following = self.vc[idx:idx + 700]
        self.assertNotIn("return True", following)

    def test_gate_cache_reuse_path(self):
        idx = self.vc.find("source=join_time_gate")
        self.assertGreater(idx, 0)

    def test_docstring_documents_container_never_true(self):
        self.assertIn("The local calls-container ALONE never returns True",
                      self.vc)

    def test_rotated_backend_identity_propagated(self):
        # RC-2 contributor: the post-verified bookkeeping sets _current_*
        # on the rotated OWNER backend (via the per-chat ownership map),
        # not only on self.
        self.assertIn("_owner._current_call_id = outcome.call_id", self.vc)
        self.assertIn("_owner._current_access_hash = int(outcome.access_hash or 0)",
                      self.vc)

    def test_verify_joined_returns_none_for_weak_negative(self):
        # The weak-negative GroupcallInvalid branch preserves as UNKNOWN.
        idx = self.vc.find("VC_JOIN_EVIDENCE_WEAK_NEGATIVE_PRESERVED")
        following = self.vc[idx:idx + 1400]
        self.assertIn('return None', following)


# ---------------------------------------------------------------------------
# Section D — InterdcCall/DC retry + dedupe (source pattern)
# ---------------------------------------------------------------------------

class TestTransientDCRetrySource(unittest.TestCase):
    def setUp(self):
        self.vc = _VC
        self.pipe = _PIPE

    def test_classifier_exists(self):
        self.assertIn("def _vc_classify_join_transport_error(", self.vc)

    def test_retry_loop_in_join(self):
        # v99: the §DC retry loop lives in the canonical pipeline.
        self.assertIn("VC_PIPELINE_TRANSPORT_RETRY", self.pipe)
        self.assertIn("VC_JOIN_DC_MAX_RETRIES", self.pipe)
        self.assertIn("VC_JOIN_DC_BACKOFF_BASE", self.pipe)

    def test_retry_reuses_same_client_no_reconnect(self):
        idx = self.pipe.find("VC_PIPELINE_TRANSPORT_RETRY")
        following = self.pipe[idx:idx + 700]
        self.assertIn("SAME PyTgCalls client", following)

    def test_floodwait_never_retried_in_loop(self):
        clf = _grab_fn(self.vc, "_vc_classify_join_transport_error")
        self.assertIn('"floodwait"', clf)
        # The pipeline's dispatch loop only retries cls == transient_dc;
        # the floodwait branch parks the account and raises FIRST.
        pipe_loop = _grab_fn(self.pipe, "run_vc_join")
        fw_idx = pipe_loop.find('if cls == "floodwait":')
        dc_idx = pipe_loop.find('if cls == "transient_dc" and tr < cfg.transport_retries:')
        self.assertGreater(fw_idx, 0)
        self.assertGreater(dc_idx, 0)
        self.assertLess(fw_idx, dc_idx,
                        "the FloodWait branch must precede the transient retry")
        # FloodWait classification short-circuits BEFORE transient checks
        # in the classifier itself:
        fw_idx = clf.find('return "floodwait"')
        dc_idx = clf.find('return "transient_dc"')
        self.assertLess(fw_idx, dc_idx)

    def test_dedupe_locks_exist(self):
        # v99: the v98.13 voicechat-level coalescing-lock layer was
        # REMOVED (dead code — the join body it guarded was replaced by
        # the pipeline delegation); the per-(account, chat) single-flight
        # registry is the canonical mechanism and lives in the pipeline.
        self.assertIn("_VC_PIPELINE_INFLIGHT", self.pipe)
        self.assertIn("VC_PIPELINE_COALESCED", self.pipe)
        self.assertIn("async def _pipeline_inflight_get_or_run(", self.pipe)
        # nothing may bypass it: the voicechat layer no longer defines a
        # competing lock layer.
        self.assertNotIn("async def _acquire_join_inflight(", self.vc)

    def test_coalesced_duplicate_marker(self):
        self.assertIn("VC_PIPELINE_COALESCED account=%s chat_id=%s", self.pipe)

    def test_attempt_final_summary_line(self):
        # v99.05 RC-F6: the summary line carries the attempt correlation
        # id + the success-evidence fields (verification_method /
        # participant_identity) — mission §16/§3.
        self.assertIn("VC_ATTEMPT_FINAL attempt_id=%s chat_id=%s account=%s ",
                      self.pipe)
        self.assertIn("tg_user_id=%s ", self.pipe)
        self.assertIn("join_result=%s ", self.pipe)
        self.assertIn("telegram_participant=%s verification_result=%s "
                      "final_state=%s ", self.pipe)
        self.assertIn("retry_reason=%s exc_class=%s verification_method=%s ",
                      self.pipe)
        self.assertIn("participant_identity=%s", self.pipe)

    def test_all_terminal_states_logged(self):
        # v99: every OUTCOME terminal state is assigned to
        # out.final_state and emitted through VC_ATTEMPT_FINAL; the
        # mid-loop failure states (ENTITY_FAILED / TRANSPORT_FAILED /
        # TELEGRAM_ABSENT) exist as validated machine transitions that
        # re-enter the bounded recovery loop.
        for state in ("JOINED_CONFIRMED", "VERIFICATION_UNKNOWN",
                      "CALL_ENDED", "FLOOD_WAIT", "UNRECOVERABLE"):
            self.assertIn(f"out.final_state = VCJoinState.{state}",
                          self.pipe, f"missing terminal state {state}")
        for mid in ("ENTITY_FAILED", "TRANSPORT_FAILED", "TELEGRAM_ABSENT"):
            self.assertIn(f"VCJoinState.{mid}: {{", self.pipe,
                          f"missing machine state {mid}")


# ---------------------------------------------------------------------------
# Section E — targeted-None convergence (source pattern)
# ---------------------------------------------------------------------------

class TestTargetedNoneConvergenceSource(unittest.TestCase):
    def setUp(self):
        self.vc = _VC

    def test_none_result_now_records_streak(self):
        # The FIX-L streak condition covers BOTH empty lists AND None
        # results (the 19× production convergence hole).
        self.assertIn("if not _targeted_participants:", self.vc)
        self.assertNotIn(
            "if _targeted_result is not None and not _targeted_participants:",
            self.vc)

    def test_streak_threshold_semantics_preserved(self):
        # FIX-L invariants intact: single/double → unknown, 3+ → absent.
        idx = self.vc.find("_streak_count >= _VC_TARGETED_ABSENT_THRESHOLD")
        self.assertGreater(idx, 0)
        after = self.vc[idx:idx + 3000]
        self.assertIn('return "absent"', after)

    def test_single_empty_returns_unknown_preserved(self):
        idx = self.vc.find("VC_PARTICIPATION_TARGETED_EMPTY_STREAK")
        after = self.vc[idx:idx + 1500]
        self.assertIn('return "unknown"', after)


# ---------------------------------------------------------------------------
# Section F — dependency pinning (requirement 10)
# ---------------------------------------------------------------------------

class TestDependencyPinning(unittest.TestCase):
    def test_requirements_pins_pytgcalls_exact(self):
        self.assertIn("pytgcalls==2.3.3", _REQ)
        self.assertNotIn("pytgcalls>=2.3.0", _REQ)

    def test_requirements_bounds_telethon(self):
        self.assertIn("telethon>=1.34.0,<2.0", _REQ)

    def test_pyproject_pins_pytgcalls_exact(self):
        self.assertIn('pytgcalls==2.3.3', _PROJ)

    def test_pin_rationale_documented(self):
        self.assertIn("runtime-proven pairing", _REQ)


# ---------------------------------------------------------------------------
# Section G — behavioural: classifier (extract-and-exec)
# ---------------------------------------------------------------------------

class TestClassifierBehaviour(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ns = {"__name__": "v9813_cls_ns", "Any": object, "asyncio": asyncio}
        exec(compile("class VCTransportError(Exception):\n    pass\n", "<t>", "exec"), cls.ns)
        cls.clf = staticmethod(_exec_fn(_VC, "_vc_classify_join_transport_error", cls.ns))

    def test_interdc_errors_transient(self):
        for msg in (
            "InterdcCallErrorError: An error occurred while communicating "
            "with DC 4 (caused by JoinGroupCallRequest)",
            "InterdcCallRichErrorError: A rich error occurred while "
            "communicating with DC 4",
        ):
            self.assertEqual(self.clf(msg), "transient_dc", msg)

    def test_telethon_giveup_transient(self):
        self.assertEqual(
            self.clf("PyTgCalls join failed: Request was unsuccessful 4 time(s)"),
            "transient_dc")

    def test_floodwait_not_transient(self):
        for msg in (
            "PyTgCalls join failed: A wait of 182 seconds is required "
            "(caused by JoinGroupCallRequest)",
            "FloodWaitError", "Too many requests",
        ):
            self.assertEqual(self.clf(msg), "floodwait", msg)

    def test_deterministic_errors(self):
        for msg in (
            "Cannot join: invalid call_id=None",
            "Invalid channel object. Make sure to pass the right types",
            "",
        ):
            self.assertEqual(self.clf(msg), "deterministic", msg)

    def test_transport_disconnect_transient(self):
        for msg in (
            "ConnectionError: Cannot send requests while disconnected",
            "MTProto client not connected — join deferred",
            "ConnectionResetError: connection reset by peer",
            "asyncio.TimeoutError",
        ):
            self.assertEqual(self.clf(msg), "transient_dc", msg)

    def test_inflight_key_stable_identifiers(self):
        # v99: the single-flight key derivation lives INLINE in
        # run_vc_join — (STABLE account id, MARKED chat id): the account
        # defaults to "global" and the chat is normalized to the marked
        # -100 form. The behavioural coalescing proof is
        # test_v99_00_vc_pipeline.py::test_s18/s19.
        pipe = _PIPE
        kf = _grab_fn(pipe, "run_vc_join")
        self.assertIn("marked_key = int(chat_ref)", kf)
        self.assertIn("marked_key = _marked_of(chat_ref)", kf)
        self.assertIn("(account, marked_key)", kf)
        self.assertIn('or "global"', pipe)  # stable default account id


# ---------------------------------------------------------------------------
# Section H — behavioural: the join-time gate (stubbed participants)
# ---------------------------------------------------------------------------

class TestJoinGateBehaviour(unittest.TestCase):
    """Runs the REAL pipeline verification loop (_verify_participation)
    with stubbed RPC layers — the v98.13 gate's behavioural contract,
    preserved by the canonical v99 pipeline (§6)."""

    @classmethod
    def setUpClass(cls):
        ns: dict = {"__name__": "v99_gate_ns", "Any": object, "asyncio": asyncio,
                    "Optional": object, "dict": dict,
                    "int": int, "str": str, "float": float, "tuple": tuple,
                    "logger": types.SimpleNamespace(
                        info=lambda *a, **k: None,
                        warning=lambda *a, **k: None,
                        debug=lambda *a, **k: None)}
        import time as _time
        ns["time"] = _time
        # stubs for the late-bound voicechat imports (the extraction
        # strips the `from .voicechat import ...` lines; the names
        # resolve to THESE namespace globals)
        cls.results = {"participation": "present",
                       "current": None}
        cls.queries = []
        async def _stub_participation(chat_id, call_id=None, access_hash=None,
                                      *, account_id="", client=None):
            cls.queries.append(("check", int(call_id or 0)))
            return cls.results["participation"]
        # v99.05 RC-F4: the absent-path hygiene now calls the PURE
        # _current_call_identity probe (no registry writes, no
        # "refreshed"/"preserved" verdicts — the pipeline is the single
        # writer).  Stub it directly: None = no active call, (0,0) =
        # probe inconclusive, (cid, ah) = the current pair.
        async def _stub_current_identity(identity, marked_chat):
            cls.queries.append(("current", int(marked_chat or 0)))
            return cls.results["current"]
        ns["vc_check_telegram_participation"] = _stub_participation
        ns["_current_call_identity"] = _stub_current_identity
        ns["_fp_access_hash"] = lambda x: "fp:test"
        cls.identity = types.SimpleNamespace(
            account_id="acc_TEST", client=object(),
            user_id=8624009332, scope="acc_TEST")
        # extract the REAL pipeline verification loop; strip the
        # package-relative imports so the stubs above are used instead
        # (v99.05: _current_call_identity is stubbed in the namespace —
        # only _verify_participation itself is executed).
        code = _grab_fn(_PIPE, "_verify_participation")
        code = "\n".join(
            ln for ln in code.split("\n")
            if "from .voicechat import" not in ln)
        assert "from .voicechat import" not in code, "unstripped import remains"
        exec(compile(code, "<pipeline-verify-extract>", "exec"), ns)
        cls.ns = ns

    def _verify(self, **kw):
        kw.setdefault("attempts", 3)
        kw.setdefault("backoff", 0.01)
        kw.setdefault("budget", 10.0)
        self.__class__.queries.clear()
        return asyncio.run(self.ns["_verify_participation"](
            self.identity, -1001234567890, 111, 222, **kw))

    def test_present_confirms(self):
        self.__class__.results["participation"] = "present"
        out = self._verify(attempts=2)
        self.assertEqual(out, "present")
        check_queries = [q for q in self.queries if q[0] == "check"]
        self.assertEqual(len(check_queries), 1)

    def test_unknown_after_bounded_retries(self):
        self.__class__.results["participation"] = "unknown"
        out = self._verify(attempts=3)
        self.assertEqual(out, "unknown")
        check_queries = [q for q in self.queries if q[0] == "check"]
        self.assertEqual(len(check_queries), 3)  # bounded — exactly N

    def test_absent_with_live_call_refreshes_identity(self):
        # v99.05 RC-F4: absent + the CURRENT identity pair CHANGED (999/888
        # vs the stale 111/222): the hygiene ADOPTS the current pair — the
        # SECOND check queries the CURRENT call_id (999), never the stale
        # one (111).  mission §13 STALE_CALL: rediscover + retry with the
        # new identity.
        self.__class__.results["participation"] = "absent"
        self.__class__.results["current"] = (999, 888)
        try:
            out = self._verify(attempts=2)
            # never success, never call_ended (the call is alive)
            self.assertEqual(out, "absent")
            check_queries = [q for q in self.queries if q[0] == "check"]
            self.assertEqual(len(check_queries), 2)
            self.assertEqual(check_queries[1][1], 999,
                             "the refreshed identity must be adopted")
        finally:
            self.__class__.results["current"] = None

    def test_absent_with_no_active_call_is_call_ended(self):
        self.__class__.results["participation"] = "absent"
        self.__class__.results["current"] = None
        try:
            out = self._verify(attempts=2)
            self.assertEqual(out, "call_ended")
        finally:
            self.__class__.results["current"] = None

    def test_absent_with_inconclusive_probe_is_unknown(self):
        # v99.05 RC-F4 / mission §15: an absent verdict whose identity
        # probe FAILED ((0,0) — inconclusive) is NOT trusted and NOT
        # destructive: the verdict degrades to unknown (never destroy a
        # potentially-valid join on weak evidence).
        self.__class__.results["participation"] = "absent"
        self.__class__.results["current"] = (0, 0)
        try:
            out = self._verify(attempts=2)
            self.assertEqual(out, "unknown")
        finally:
            self.__class__.results["current"] = None

    def test_query_failure_is_honest_unknown(self):
        # the verification client unavailable / query errors: the loop
        # retries BOUNDED and ends in the honest UNKNOWN (never present,
        # never absent — inspection failure is not departure).
        async def _raising(chat_id, call_id=None, access_hash=None,
                           *, account_id="", client=None):
            raise RuntimeError("verification_client_unavailable")
        self.ns["vc_check_telegram_participation"] = _raising
        try:
            out = self._verify(attempts=2)
            self.assertEqual(out, "unknown")
        finally:
            # restore the recording stub
            cls = self.__class__
            async def _restore(chat_id, call_id=None, access_hash=None,
                               *, account_id="", client=None):
                cls.queries.append(("check", int(call_id or 0)))
                return cls.results["participation"]
            self.ns["vc_check_telegram_participation"] = _restore


# ---------------------------------------------------------------------------
# Section I — behavioural: join() unverified path (stubbed backend)
# ---------------------------------------------------------------------------

class TestJoinUnverifiedRaiseBehaviour(unittest.TestCase):
    """Executes the REAL PyTgCallsBackend.join method body end-to-end with
    a fake pytgcalls + infeasible gate (no client) — join must raise
    VCJoinUnverifiedError (NOT return True) when the container confirms
    but Telegram-side verification cannot confirm."""

    @classmethod
    def setUpClass(cls):
        # Build a minimal namespace with the real class + needed attrs.
        src = _VC
        cls_join = re.search(
            r"^class PyTgCallsBackend\(VCBackend\):.*?(?=^class |\Z)",
            src, re.M | re.S)
        assert cls_join, "PyTgCallsBackend not found"
        # Strip the relative imports the class body performs at RUNTIME
        # (from .mtproto import ...) — they cannot resolve outside the
        # package; the names they bind are provided in the namespace.
        cls_src = cls_join.group(0)
        cls_src = re.sub(r"^(\s*)from \.mtproto import mtproto_get_client_legacy\s*$",
                         r"\1mtproto_get_client_legacy = _NS_MGCL", cls_src, flags=re.M)
        cls_src = re.sub(r"^(\s*)from \.mtproto import _vc_entity_cache\s*$",
                         r"\1_vc_entity_cache = _NS_ENTITY_CACHE", cls_src, flags=re.M)
        # v99: join() delegates to the canonical pipeline — stub the
        # relative import the same way.  The REAL pipeline behaviour is
        # covered end-to-end by tests/test_v99_00_vc_pipeline.py (loaded
        # against a full mock harness); this class verifies the
        # DELEGATION CONTRACT: the typed unverified error propagates,
        # transport failures propagate, and the pipeline receives the
        # exact target/call identity + account for per-(account, chat)
        # single-flight dedup.
        cls_src = re.sub(r"^(\s*)from \.vc_pipeline import run_vc_join\s*$",
                         r"\1run_vc_join = _NS_RUN_VC_JOIN", cls_src, flags=re.M)
        ns: dict = {
            "__name__": "v9813_join_ns", "Any": object, "Optional": object,
            "asyncio": asyncio, "logger": types.SimpleNamespace(
                info=lambda *a, **k: None, warning=lambda *a, **k: None,
                debug=lambda *a, **k: None, error=lambda *a, **k: None),
            "_NS_ENTITY_CACHE": {}, "_NS_MGCL": None,
        }
        # v99 pipeline stub (delegation-contract testing — see the class
        # docstring; the real pipeline is behaviourally covered by
        # test_v99_00_vc_pipeline.py against a full mock harness).
        ns["_NS_PIPE_CALLS"] = []
        ns["_NS_PIPE_VERDICT"] = ["unverified"]

        class _PipeOutcome:
            def __init__(self):
                self.final_state = "JOINED_CONFIRMED"
                self.verdict = "joined"
                self.chat_id = 1234567890
                self.marked_chat_id = -1001234567890
                self.account = "global"
                self.tg_user_id = 8624009332
                self.attempts = 1
                self.call_id = -111
                self.access_hash = 222

        async def _ns_run_vc_join(backend, chat_ref, *, call_id=0,
                                  access_hash=0, muted=True, account_id=""):
            ns["_NS_PIPE_CALLS"].append(
                (chat_ref, call_id, access_hash, account_id))
            verdict = ns["_NS_PIPE_VERDICT"][0]
            if verdict == "unverified":
                raise ns["VCJoinUnverifiedError"](
                    "Join transport accepted for -1001234567890 "
                    "(call_id=-111, account=global) but Telegram-side "
                    "participant verification did NOT confirm "
                    "participation — the join is NOT reported as "
                    "successful (v99 pipeline).")
            if verdict == "transport":
                raise ns["VCTransportError"](
                    "PyTgCalls join failed: no container entry created")
            return _PipeOutcome()
        ns["_NS_RUN_VC_JOIN"] = _ns_run_vc_join
        import time as _time
        ns["time"] = _time
        exec(compile("class VCTransportError(Exception):\n    pass\n\n"
                     "class VCJoinUnverifiedError(VCTransportError):\n    pass\n",
                     "<t>", "exec"), ns)
        ns["_env_int"] = lambda n, d: d
        ns["_env_float"] = lambda n, d: d
        async def _stub_resolve_vc_entity(client, chat_ref, chat_id=0, access_hash=0):
            _ent = cls._FakeChannel()
            _ent.id = 1234567890
            return {"ok": True, "entity": _ent, "source": "cache"}
        ns["resolve_vc_entity"] = _stub_resolve_vc_entity


        # real helper functions needed by the method — v99: the join()
        # body delegates to the (stubbed) pipeline; the only voicechat
        # helper it still references is the transport classifier (the
        # v98.13 gate/dedup/attempt-final helpers were REMOVED from
        # voicechat.py as dead code — their contracts live in the
        # pipeline module and are covered by its own suite).
        for fn in ("_vc_classify_join_transport_error",):
            exec(compile(_grab_fn(src, fn), "<t>", "exec"), ns)
        # registries/maps the method touches
        ns["_vc_join_inflight_locks"] = {}
        ns["_vc_active_join_backends_by_chat"] = {}
        ns["_vc_corroboration_cache"] = {}
        ns["_vc_last_verify_evidence"] = {}
        def _noop(*a, **k):
            return None
        async def _async_noop(*a, **k):
            return None
        ns["_vc_record_verify_evidence"] = _noop
        ns["_vc_clear_transport_dead"] = _noop
        ns["_vc_targeted_absent_streak_reset"] = _noop
        ns["_vc_entity_negative_clear_for_chat"] = _noop
        ns["_vc_owning_account_of_backend"] = lambda be: "acc_OWNER"
        ns["_vc_join_account_record_join"] = _noop
        ns["_vc_both_id_forms"] = lambda cid: (cid, cid)
        ns["_vc_session_join_success_ids"] = set()
        ns["_vc_cleanup_stale_backend_call"] = _async_noop
        ns["vc_registry_get"] = _async_noop
        ns["get_userbot_cluster"] = lambda: (_ for _ in ()).throw(
            RuntimeError("no cluster"))
        ns["mtproto_get_client"] = lambda: None  # gate INFEASIBLE
        # telethon types for the entity check — FORCE-register so the
        # earlier test classes' registrations cannot shadow ours.
        telethon = types.ModuleType("telethon")
        tl = types.ModuleType("telethon.tl")
        types_mod = types.ModuleType("telethon.tl.types")
        class Channel:
            pass
        class Chat:
            pass
        types_mod.Channel = Channel
        types_mod.Chat = Chat
        tl.types = types_mod
        telethon.tl = tl
        sys.modules["telethon"] = telethon
        sys.modules["telethon.tl"] = tl
        sys.modules["telethon.tl.types"] = types_mod
        # _FakeChannel must be an INSTANCE of the Channel the real join()
        # imports, so the marked-id conversion (−100 prefix) runs.
        cls._FakeChannel = Channel
        cls.ns = ns
        # Exec the (relative-import-stripped) class body AFTER the helpers
        # exist so the method bodies resolve them from the shared namespace.
        exec(compile("class VCBackend:\n    pass\n\n" + cls_src, "<t>", "exec"), ns)

    @staticmethod
    def _fake_entity():
        from types import SimpleNamespace
        # A Channel-like entity with an .id
        return SimpleNamespace(id=1234567890)

    def _make_backend(self):
        ns = self.ns
        cls = ns["PyTgCallsBackend"]
        be = cls.__new__(cls)
        be._started = True
        be._pytgcalls = self._fake_pytgcalls()
        be._mtproto = None
        be._compatible = True
        be._join_strategy = "play"
        be._leave_strategy = "leave_call"
        be._status_strategy = "calls"
        be._account_id = ""
        be._current_chat_id = None
        be._current_call_id = None
        be._current_access_hash = 0
        be._pending_chat_id = None
        be._pending_call_id = None
        be._join_path_operational = True
        be._consecutive_status_failures = 0
        be._last_error = ""
        be._last_status_error = ""
        be._last_join_error = ""
        be._active_join_backend = None
        be._group_calls = {}
        return be

    @staticmethod
    def _fake_pytgcalls():
        class _FP:
            def __init__(self):
                self.calls: dict[int, object] = {}
                self.log: list = []
            async def play(self, chat_id, stream):
                self.log.append(("play", chat_id))
                self.calls[chat_id] = object()
            async def leave_call(self, chat_id):
                self.log.append(("leave", chat_id))
                self.calls.pop(chat_id, None)
        return _FP()

    def test_unverified_join_raises_typed_error(self):
        # v99 delegation contract: the pipeline's honest UNVERIFIED
        # outcome propagates through join() — join() NEVER swallows it
        # into a success return.  (The real pipeline's
        # transport-accepted-then-inconclusive path is behaviourally
        # proven in test_v99_00_vc_pipeline.py::test_s30_*.)
        self.ns["_NS_PIPE_VERDICT"][0] = "unverified"
        self.ns["_NS_PIPE_CALLS"].clear()
        be = self._make_backend()
        with self.assertRaises(self.ns["VCJoinUnverifiedError"]) as cm:
            asyncio.run(be.join(1234567890, call_id=-111, access_hash=222,
                                muted=True))
        self.assertIn("NOT reported as successful", str(cm.exception))
        # the pipeline received the EXACT join identity
        (chat_ref, call_id, access_hash, account_id), = self.ns["_NS_PIPE_CALLS"]
        self.assertEqual(chat_ref, 1234567890)
        self.assertEqual(call_id, -111)
        self.assertEqual(access_hash, 222)
        self.assertEqual(account_id, "")

    def test_container_confirm_still_required_before_gate(self):
        # v99 delegation contract: a transport-phase failure (no
        # container entry / dispatch error) propagates as the classic
        # VCTransportError — NOT the unverified error (the honest
        # distinction between failed-transport and unverified survives
        # the pipeline move).
        self.ns["_NS_PIPE_VERDICT"][0] = "transport"
        be = self._make_backend()
        be._pytgcalls.calls.clear()
        with self.assertRaises(self.ns["VCTransportError"]) as cm:
            asyncio.run(be.join(1234567890, call_id=-111, access_hash=222,
                                muted=True))
        self.assertNotIsInstance(cm.exception, self.ns["VCJoinUnverifiedError"])

    def test_dedup_coalesces_second_join(self):
        # v99: per-(account, chat) single-flight lives IN the pipeline
        # (behaviourally proven against the REAL pipeline by
        # test_v99_00_vc_pipeline.py::test_s18_duplicate_join_coalesced
        # and ::test_s19_concurrent_worker_race_same_outcome — one
        # dispatch, identical outcomes for every coalesced caller).  Here
        # we verify the DELEGATION carries the stable account identity
        # the single-flight key requires: every call forwards
        # account_id, so the pipeline keys on (account, marked chat).
        self.ns["_NS_PIPE_VERDICT"][0] = "unverified"
        self.ns["_NS_PIPE_CALLS"].clear()
        be = self._make_backend()
        for _ in range(2):
            with self.assertRaises(self.ns["VCJoinUnverifiedError"]):
                asyncio.run(be.join(1234567890, call_id=-111,
                                    access_hash=222, muted=True))
        self.assertEqual(len(self.ns["_NS_PIPE_CALLS"]), 2)
        for chat_ref, call_id, access_hash, account_id in self.ns["_NS_PIPE_CALLS"]:
            self.assertEqual(account_id, "")
            self.assertEqual(chat_ref, 1234567890)


# ---------------------------------------------------------------------------
# Section J — behavioural: verify_joined container-only → None
# ---------------------------------------------------------------------------

class TestVerifyJoinedBehaviour(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        src = _VC
        ns: dict = {"__name__": "v9813_verify_ns", "Any": object,
                    "Optional": object, "asyncio": asyncio,
                    "logger": types.SimpleNamespace(
                        info=lambda *a, **k: None,
                        warning=lambda *a, **k: None,
                        debug=lambda *a, **k: None)}
        import time as _time
        ns["time"] = _time
        exec(compile("class VCTransportError(Exception):\n    pass\n\n"
                     "class VCJoinUnverifiedError(VCTransportError):\n    pass\n",
                     "<t>", "exec"), ns)
        # the method + its dependencies
        m = re.search(r"^class PyTgCallsBackend\(VCBackend\):.*?(?=^class |\Z)",
                      src, re.M | re.S)
        exec(compile("class VCBackend:\n    pass\n\n" + m.group(0), "<t>", "exec"), ns)
        cls.cls = ns["PyTgCallsBackend"]
        cls.ns = ns
        # shared stubs
        cls.reg = {}
        cls.telegram = {"result": "unknown"}
        async def _registry_get(chat_id):
            return cls.reg.get(chat_id)
        async def _participation(chat_id, call_id=None, access_hash=None,
                                 *, account_id=""):
            return cls.telegram["result"]
        async def _still_valid(chat_id, call_id, access_hash, *, timeout=8,
                               account_id=""):
            return None
        async def _gone(chat_id, old_cid, old_ah, *, account_id="", timeout=12.0):
            return "inconclusive"
        ns["vc_registry_get"] = _registry_get
        ns["vc_check_telegram_participation"] = _participation
        ns["_vc_telegram_call_still_valid"] = _still_valid
        ns["_vc_call_gone_evidence_check"] = _gone
        ns["_vc_record_verify_evidence"] = lambda *a, **k: None
        ns["_vc_clear_transport_dead"] = lambda *a, **k: None
        ns["_vc_targeted_absent_streak_reset"] = lambda *a, **k: None
        ns["_vc_corroboration_cache"] = {}
        ns["_vc_last_verify_evidence"] = {}
        ns["_VC_CORROBORATION_THROTTLE_SECONDS"] = 60
        ns["_vc_active_join_backends_by_chat"] = {}
        ns["_vc_is_transport_dead"] = lambda cid: False
        ns["mtproto_get_client"] = lambda: None
        from types import SimpleNamespace
        ns["_vc_entity_cache"] = {}

    def _backend(self, container_has=True):
        be = self.cls.__new__(self.cls)
        be._started = True
        be._account_id = ""
        be._active_join_backend = None
        be._current_chat_id = None
        be._current_call_id = None
        be._current_access_hash = 0
        be._status_strategy = "calls"
        be._join_strategy = "play"
        be._leave_strategy = "leave_call"
        be._last_status_error = ""
        be._pending_chat_id = None
        be._pending_call_id = None
        be._join_path_operational = True
        be._consecutive_status_failures = 0
        be._pytgcalls_mtproto = None

        class _FP:
            def __init__(self, has):
                self.calls = {-1001: object()} if has else {}
        be._pytgcalls = _FP(container_has)
        return be

    def test_container_present_no_identity_returns_none(self):
        be = self._backend(container_has=True)
        self.__class__.reg.clear()
        out = asyncio.run(be.verify_joined(-1001))
        self.assertIsNone(out, "container-only must be UNKNOWN, not True")

    def test_participant_present_returns_true(self):
        be = self._backend(container_has=True)
        self.__class__.reg[-1001] = types.SimpleNamespace(
            call_id=-555, access_hash=777, state="joined", account_id=None)
        self.__class__.telegram["result"] = "present"
        try:
            out = asyncio.run(be.verify_joined(-1001))
            self.assertIs(out, True)
        finally:
            self.__class__.telegram["result"] = "unknown"

    def test_gate_cache_shortcut(self):
        # Fresh join-time-gate strong evidence → True without RPCs.
        import time as _t
        be = self._backend(container_has=True)
        self.__class__.reg.clear()
        self.__class__.telegram["result"] = "unknown"
        self.ns["_vc_last_verify_evidence"][-1001] = {
            "outcome": "joined", "strength": "strong",
            "reason": "join_time_gate:participant_confirmed",
            "account_id": "global", "call_id": -555, "ts": _t.monotonic()}
        try:
            out = asyncio.run(be.verify_joined(-1001))
            self.assertIs(out, True)
        finally:
            self.ns["_vc_last_verify_evidence"].clear()

    def test_stale_gate_cache_not_used(self):
        import time as _t
        be = self._backend(container_has=True)
        self.__class__.reg.clear()
        self.ns["_vc_last_verify_evidence"][-1001] = {
            "outcome": "joined", "strength": "strong", "reason": "x",
            "account_id": "global", "call_id": -555,
            "ts": _t.monotonic() - 600}  # 10 min old — stale
        try:
            out = asyncio.run(be.verify_joined(-1001))
            self.assertIsNone(out)
        finally:
            self.ns["_vc_last_verify_evidence"].clear()


if __name__ == "__main__":
    unittest.main(verbosity=2)
