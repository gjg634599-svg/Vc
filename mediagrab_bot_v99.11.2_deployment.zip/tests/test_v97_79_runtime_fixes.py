"""
v97.79 RUNTIME-DRIVEN FORENSIC FIX tests.

Root causes fixed in v97.79 (driven by REAL production runtime logs bot_forced.log
+ bot_forced (2).log):

  RC1 (SOURCE-PROVEN): v97.78's _forcibly_cancel_telethon_tasks was GLOBAL —
      asyncio.all_tasks() + __qualname__ matching cancelled ALL clients' tasks,
      including other accounts' healthy tasks. v97.79 FIX: client-specific task
      snapshot using CORRECT Telethon attribute names (_updates_handle,
      _keepalive_handle, _send_loop_handle, _recv_loop_handle, _send_task,
      _recv_task). forced-cancel now cancels ONLY the snapshot.

  RC2 (RUNTIME-PROVEN): dispatch-update explosion — PyTgCalls registers a raw
      update handler on the Telethon client that receives EVERY MTProto update.
      bf2 line 1964: 1296 _dispatch_update + 88 pytgcalls = 1418 tasks → 29.88s
      EVENT_LOOP_LAG_CRITICAL. v97.79 FIX: wrap add_update_handler so PyTgCalls
      only receives group-call-related TL types (UpdateGroupCall*).

  RC3 (RUNTIME-PROVEN + SOURCE-PROVEN): VC state corruption — Leave All didn't
      cancel the join-all worker, so the next Join All hit "already_running" and
      bypassed vc_reset_target_state(). Global FloodWait + breaker + dead-letter
      persisted. v97.79 FIX: Leave All now stops the worker + clears breaker +
      clears global FloodWait + resets state.

Tests:
  Telethon A-P: client-specific cancellation + multi-client isolation + single-flight
  VC I-R: dead-letter clearing + idempotent Join All / Leave All cycles
"""
import asyncio
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_MTPROTO_GEN = os.path.join(_BASE, "mediagrab_bot", "mtproto_generation.py")
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


# ---------------------------------------------------------------------------
# Source-verification tests
# ---------------------------------------------------------------------------

class TestRC1ClientSpecificCancellation(unittest.TestCase):
    """RC1: forced-cancel must use client-specific snapshot, not global asyncio.all_tasks()."""

    def test_snapshot_function_exists(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("def _snapshot_telethon_bg_tasks(", src)
        self.assertIn("_mediagrab_bg_tasks", src)

    def test_correct_telethon_attr_names(self):
        with open(_MTPROTO) as f:
            src = f.read()
        # v97.79: must use the CORRECT Telethon attribute names
        self.assertIn("_updates_handle", src)
        self.assertIn("_keepalive_handle", src)
        self.assertIn("_send_loop_handle", src)
        self.assertIn("_recv_loop_handle", src)
        self.assertIn("_send_task", src)
        self.assertIn("_recv_task", src)

    def test_snapshot_called_after_connect(self):
        with open(_MTPROTO) as f:
            src = f.read()
        # Primary client
        self.assertIn('_snapshot_telethon_bg_tasks(_mtproto_client, label="primary")', src)
        # Cluster client
        self.assertIn('_snapshot_telethon_bg_tasks(client, label=f"cluster:{account_id}")', src)

    def test_forced_cancel_uses_snapshot_first(self):
        with open(_MTPROTO) as f:
            src = f.read()
        idx = src.find("async def _forcibly_cancel_telethon_tasks(")
        self.assertGreater(idx, 0)
        body = src[idx:idx + 4000]  # v97.87: function is longer
        # Must try snapshot FIRST
        self.assertIn('snapshot = getattr(client, "_mediagrab_bg_tasks", None)', body)
        self.assertIn("cancel(msg=\"v97.79_client_specific_retirement\")", body)

    def test_global_fallback_exists_with_warning(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("async def _forcibly_cancel_telethon_tasks_global(", src)
        self.assertIn("MTPROTO_FORCED_CANCEL_NO_SNAPSHOT", src)


class TestRC2PyTgCallsFilter(unittest.TestCase):
    """RC2: PyTgCalls update handler must be pre-filtered."""

    def test_wrap_function_exists(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("def _wrap_pytgcalls_update_filter(", src)
        self.assertIn("_PYTGCALLS_WRAPPED_CLIENTS", src)

    def test_filter_only_group_call_updates(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("def _wrap_pytgcalls_update_filter(")
        body = src[idx:idx + 4000]  # v97.87: function is longer
        self.assertIn("UpdateGroupCall", body)
        self.assertIn("UpdateGroupCallParticipants", body)
        self.assertIn("UpdateChannel", body)

    def test_filter_called_after_pytgcalls_start(self):
        """v97.80: the filter is applied AFTER pytgcalls.start() (post-registration).
        The v97.79 approach (before start) used the nonexistent add_update_handler API."""
        with open(_VOICECHAT) as f:
            src = f.read()
        start_idx = src.find("await self._pytgcalls.start()")
        self.assertGreater(start_idx, 0, "pytgcalls.start() call not found")
        # The filter call must come AFTER start()
        filter_idx = src.find("_wrap_pytgcalls_update_filter(self._mtproto)", start_idx)
        self.assertGreater(filter_idx, 0, "filter call not found after pytgcalls.start()")


class TestRC3LeaveAllResetsWorker(unittest.TestCase):
    """RC3: Leave All must cancel the join-all worker + clear breaker + clear floodwait."""

    def test_leave_all_stops_worker(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("async def vc__leave_all(")
        block = src[idx:idx + 6000]  # v97.83: handler is longer
        self.assertIn("vc_join_all_active_stop()", block)
        self.assertIn("VC_LEAVE_ALL_STOP_WORKER", block)

    def test_leave_all_clears_breaker(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("async def vc__leave_all(")
        block = src[idx:idx + 6000]  # v97.83: handler is longer
        self.assertIn("_vc_join_all_breaker.reset()", block)
        self.assertIn("_vc_join_all_state_machine.reset()", block)
        self.assertIn("_vc_join_all_cancel_token.reset()", block)

    def test_leave_all_clears_global_floodwait(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("async def vc__leave_all(")
        block = src[idx:idx + 6000]  # v97.83: handler is longer
        self.assertIn("vc_reset_target_state(include_global_floodwait=True)", block)


class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_92(self):
        with open(_INIT) as f:
            src = f.read()
        self.assertIn('__bot_version__ = "v99.11.2"', src)


# ---------------------------------------------------------------------------
# BEHAVIORAL TESTS — Telethon A-P (client-specific cancellation)
# ---------------------------------------------------------------------------

class _FakeTelethonClient:
    """Simulates a Telethon client with the CORRECT attribute names."""
    def __init__(self, name):
        self.name = name
        self._updates_handle = None
        self._keepalive_handle = None
        self._sender = _FakeSender()
        self._mediagrab_bg_tasks = []
        self._mediagrab_poisoned = False

    def set_bg_tasks(self, tasks):
        """Set the 6 background tasks + snapshot them."""
        self._updates_handle = tasks[0]
        self._keepalive_handle = tasks[1]
        self._sender._send_loop_handle = tasks[2]
        self._sender._recv_loop_handle = tasks[3]
        self._sender._connection._send_task = tasks[4]
        self._sender._connection._recv_task = tasks[5]
        # Snapshot
        self._mediagrab_bg_tasks = [
            (tasks[0], "update_loop"),
            (tasks[1], "keepalive_loop"),
            (tasks[2], "mtprotosender_send_loop"),
            (tasks[3], "mtprotosender_recv_loop"),
            (tasks[4], "connection_send_loop"),
            (tasks[5], "connection_recv_loop"),
        ]


class _FakeSender:
    def __init__(self):
        self._send_loop_handle = None
        self._recv_loop_handle = None
        self._connection = _FakeConnection()


class _FakeConnection:
    def __init__(self):
        self._send_task = None
        self._recv_task = None


def _make_bg_tasks(prefix="task", stuck=False):
    """Create 6 asyncio tasks simulating Telethon background loops."""
    tasks = []
    for i in range(6):
        def _make_coro(idx):
            async def _coro():
                try:
                    if stuck:
                        await asyncio.sleep(100)
                    else:
                        await asyncio.sleep(0.01)
                except asyncio.CancelledError:
                    raise
            _coro.__qualname__ = f"{prefix}._bg_loop_{idx}"
            return _coro()
        tasks.append(asyncio.ensure_future(_make_coro(i)))
    return tasks


class TestARetiringGenACancelsOnlyA(unittest.TestCase):
    """Test A — Retiring generation A cancels A's tasks only, not B's."""

    def test_cancel_only_client_a_tasks(self):
        async def driver():
            client_a = _FakeTelethonClient("A")
            client_b = _FakeTelethonClient("B")
            tasks_a = _make_bg_tasks("ClientA", stuck=True)
            tasks_b = _make_bg_tasks("ClientB", stuck=True)
            await asyncio.sleep(0.001)
            client_a.set_bg_tasks(tasks_a)
            client_b.set_bg_tasks(tasks_b)
            # Cancel ONLY client A's snapshot
            for task, _human in client_a._mediagrab_bg_tasks:
                if not task.done():
                    task.cancel(msg="v97.79_test")
            await asyncio.gather(*[t for t, _ in client_a._mediagrab_bg_tasks],
                                 return_exceptions=True)
            # Client A: all dead
            self.assertTrue(all(t.done() for t, _ in client_a._mediagrab_bg_tasks))
            # Client B: all alive
            self.assertTrue(all(not t.done() for t, _ in client_b._mediagrab_bg_tasks))
            # Cleanup B
            for t, _ in client_b._mediagrab_bg_tasks:
                t.cancel()
            await asyncio.gather(*[t for t, _ in client_b._mediagrab_bg_tasks],
                                 return_exceptions=True)

        asyncio.new_event_loop().run_until_complete(driver())


class TestBTwoClientsIsolated(unittest.TestCase):
    """Test B — Two simultaneous Telethon clients remain isolated."""

    def test_isolation(self):
        async def driver():
            a = _FakeTelethonClient("A")
            b = _FakeTelethonClient("B")
            ta = _make_bg_tasks("A", stuck=True)
            tb = _make_bg_tasks("B", stuck=True)
            await asyncio.sleep(0.001)
            a.set_bg_tasks(ta)
            b.set_bg_tasks(tb)
            self.assertEqual(len(a._mediagrab_bg_tasks), 6)
            self.assertEqual(len(b._mediagrab_bg_tasks), 6)
            # Different task objects
            a_ids = {id(t) for t, _ in a._mediagrab_bg_tasks}
            b_ids = {id(t) for t, _ in b._mediagrab_bg_tasks}
            self.assertEqual(len(a_ids & b_ids), 0, "no shared tasks")
            for t, _ in a._mediagrab_bg_tasks + b._mediagrab_bg_tasks:
                t.cancel()
            await asyncio.gather(*[t for t, _ in a._mediagrab_bg_tasks + b._mediagrab_bg_tasks],
                                 return_exceptions=True)

        asyncio.new_event_loop().run_until_complete(driver())


class TestCOrphanedTasksDetectedBySnapshot(unittest.TestCase):
    """Test C — Orphaned tasks from generation A are detected via snapshot."""

    def test_snapshot_detects_alive_tasks(self):
        async def driver():
            client = _FakeTelethonClient("A")
            tasks = _make_bg_tasks("A", stuck=True)
            await asyncio.sleep(0.001)
            client.set_bg_tasks(tasks)
            alive = [(t, h) for t, h in client._mediagrab_bg_tasks if not t.done()]
            self.assertEqual(len(alive), 6)
            for t, _ in alive:
                t.cancel()
            await asyncio.gather(*[t for t, _ in alive], return_exceptions=True)
        asyncio.new_event_loop().run_until_complete(driver())


class TestDSurvivingTaskBlocksReconnect(unittest.TestCase):
    """Test D — A surviving task blocks reconnect (poisoned gate)."""

    def test_survivor_blocks(self):
        class MockStuckTask:
            def __init__(self):
                self._done = False
            def done(self):
                return self._done
            def cancel(self, msg=None):
                pass
        stuck = MockStuckTask()
        survivors = [stuck] if not stuck.done() else []
        poisoned = len(survivors) > 0
        self.assertTrue(poisoned)
        self.assertFalse(not poisoned)  # connect must be blocked


class TestEPoisonOnlyGenA(unittest.TestCase):
    """Test E — A poisoned update loop poisons only generation A."""

    def test_poison_isolation(self):
        client_a = _FakeTelethonClient("A")
        client_b = _FakeTelethonClient("B")
        client_a._mediagrab_poisoned = True
        self.assertTrue(client_a._mediagrab_poisoned)
        self.assertFalse(client_b._mediagrab_poisoned)


class TestFReconnectSingleFlight(unittest.TestCase):
    """Test F — Reconnect remains strict single-flight (v97.76 preserved)."""

    def test_single_flight(self):
        shared = {"task": None}
        exec_count = {"n": 0}

        async def underlying():
            exec_count["n"] += 1
            await asyncio.sleep(0.1)
            return True

        def trigger():
            existing = shared["task"]
            if existing is not None and not existing.done():
                return
            shared["task"] = asyncio.ensure_future(underlying())

        async def caller():
            trigger()
            await asyncio.sleep(0.05)

        async def driver():
            await asyncio.gather(*[caller() for _ in range(100)])
            if shared["task"]:
                await shared["task"]

        asyncio.new_event_loop().run_until_complete(driver())
        self.assertEqual(exec_count["n"], 1)


class TestG100TriggersOneTask(unittest.TestCase):
    """Test G — 100 concurrent reconnect triggers produce at most one task."""

    def test_100_triggers(self):
        shared = {"task": None}
        max_c = {"n": 0}

        async def underlying():
            await asyncio.sleep(0.2)

        def trigger():
            existing = shared["task"]
            if existing is not None and not existing.done():
                return
            shared["task"] = asyncio.ensure_future(underlying())
            max_c["n"] = max(max_c["n"], 1)

        async def driver():
            for _ in range(100):
                trigger()
                await asyncio.sleep(0)
            if shared["task"]:
                await shared["task"]

        asyncio.new_event_loop().run_until_complete(driver())
        self.assertLessEqual(max_c["n"], 1)


class TestHFailedReconnectNoStorm(unittest.TestCase):
    """Test H — A failed reconnect does not create a replacement task storm."""

    def test_no_storm(self):
        shared = {"task": None}
        created = {"n": 0}

        async def underlying():
            await asyncio.sleep(0.05)
            raise ConnectionError("failed")

        def trigger():
            existing = shared["task"]
            if existing is not None and not existing.done():
                return
            shared["task"] = asyncio.ensure_future(underlying())
            created["n"] += 1

            def _done(t):
                if shared["task"] is t:
                    shared["task"] = None
            shared["task"].add_done_callback(_done)

        async def caller():
            trigger()
            await asyncio.sleep(0.02)

        async def driver():
            await asyncio.gather(*[caller() for _ in range(50)])
            if shared["task"]:
                try:
                    await shared["task"]
                except Exception:
                    pass

        asyncio.new_event_loop().run_until_complete(driver())
        self.assertLessEqual(created["n"], 1)


class TestKPrimaryClusterIsolated(unittest.TestCase):
    """Test K — Primary and cluster clients remain isolated."""

    def test_different_snapshots(self):
        async def driver():
            a = _FakeTelethonClient("primary")
            b = _FakeTelethonClient("cluster")
            ta = _make_bg_tasks("primary")
            tb = _make_bg_tasks("cluster")
            await asyncio.sleep(0.001)
            a.set_bg_tasks(ta)
            b.set_bg_tasks(tb)
            self.assertIsNot(a._mediagrab_bg_tasks, b._mediagrab_bg_tasks)
            for t, _ in a._mediagrab_bg_tasks + b._mediagrab_bg_tasks:
                t.cancel()
            await asyncio.gather(*[t for t, _ in a._mediagrab_bg_tasks + b._mediagrab_bg_tasks],
                                 return_exceptions=True)
        asyncio.new_event_loop().run_until_complete(driver())


class TestLForcedCancelClientSpecific(unittest.TestCase):
    """Test L — Forced cancellation is client/generation specific (not global)."""

    def test_cancel_uses_snapshot_not_all_tasks(self):
        with open(_MTPROTO) as f:
            src = f.read()
        idx = src.find("async def _forcibly_cancel_telethon_tasks(")
        body = src[idx:idx + 4000]  # v97.87: function is longer
        # Must NOT use asyncio.all_tasks as the PRIMARY mechanism
        # (it's only in the fallback function)
        self.assertNotIn("asyncio.all_tasks(loop)", body.split("async def _forcibly_cancel_telethon_tasks_global")[0])


class TestMNoGlobalNameBasedCancellation(unittest.TestCase):
    """Test M — No global name-based Telethon cancellation remains as primary path."""

    def test_global_fallback_is_secondary(self):
        with open(_MTPROTO) as f:
            src = f.read()
        # The primary function must use snapshot, not asyncio.all_tasks
        idx = src.find("async def _forcibly_cancel_telethon_tasks(")
        end = src.find("async def _forcibly_cancel_telethon_tasks_global", idx)
        primary_body = src[idx:end]
        self.assertIn("_mediagrab_bg_tasks", primary_body)
        self.assertNotIn("asyncio.all_tasks(loop)", primary_body)


# ---------------------------------------------------------------------------
# BEHAVIORAL TESTS — VC I-R (dead-letter + idempotent cycles)
# ---------------------------------------------------------------------------

class _FakeVCState:
    def __init__(self):
        self.entity_fail_counts = {}
        self.target_cooldowns = {}
        self.no_active_call_cooldowns = {}
        self.reconcile_cooldowns = {}
        self.global_floodwait_until = 0.0
        self.breaker_open = False
        self.worker_alive = False
        self.FAIL_THRESHOLD = 3

    def is_dead_lettered(self, chat_id):
        return self.entity_fail_counts.get(chat_id, 0) >= self.FAIL_THRESHOLD

    def record_failure(self, chat_id):
        c = self.entity_fail_counts.get(chat_id, 0) + 1
        self.entity_fail_counts[chat_id] = c
        return c

    def reset_target_state(self, include_global_floodwait=False):
        cleared = len(self.entity_fail_counts)
        self.entity_fail_counts.clear()
        self.target_cooldowns.clear()
        self.no_active_call_cooldowns.clear()
        self.reconcile_cooldowns.clear()
        if include_global_floodwait:
            self.global_floodwait_until = 0.0
        self.breaker_open = False
        self.worker_alive = False
        return cleared


class TestIDiscoverAllVCs(unittest.TestCase):
    """Test I — Join All Active discovers all active VCs on first invocation."""

    def test_first_invocation(self):
        state = _FakeVCState()
        vcs = list(range(1001, 1009))
        eligible = [v for v in vcs if not state.is_dead_lettered(v)]
        self.assertEqual(len(eligible), 8)


class TestJRediscoverAfterAutoLeave(unittest.TestCase):
    """Test J — After automatic leave, Join All Active rediscovers all (v97.79 reset)."""

    def test_rediscover(self):
        state = _FakeVCState()
        vcs = list(range(1001, 1009))
        for v in vcs:
            for _ in range(3):
                state.record_failure(v)
        self.assertEqual(len([v for v in vcs if not state.is_dead_lettered(v)]), 0)
        state.reset_target_state()
        self.assertEqual(len([v for v in vcs if not state.is_dead_lettered(v)]), 8)


class TestKNoStaleStateAfterAutoLeave(unittest.TestCase):
    """Test K — No stale state after auto-leave + Join All (v97.79 clears worker)."""

    def test_worker_cleared(self):
        state = _FakeVCState()
        state.worker_alive = True
        state.breaker_open = True
        # v97.79: Leave All stops worker + clears breaker
        state.reset_target_state(include_global_floodwait=True)
        self.assertFalse(state.worker_alive)
        self.assertFalse(state.breaker_open)


class TestLLeaveAllResetsState(unittest.TestCase):
    """Test L — Leave All fully resets lifecycle state."""

    def test_leave_all_resets(self):
        state = _FakeVCState()
        for i in range(10):
            state.record_failure(2000 + i)
            state.target_cooldowns[2000 + i] = 1.0
        state.global_floodwait_until = 999.0
        state.breaker_open = True
        state.worker_alive = True
        # v97.79: Leave All resets EVERYTHING including floodwait + breaker + worker
        cleared = state.reset_target_state(include_global_floodwait=True)
        self.assertEqual(cleared, 10)
        self.assertEqual(state.global_floodwait_until, 0.0)
        self.assertFalse(state.breaker_open)
        self.assertFalse(state.worker_alive)


class TestMRepeatedCycles(unittest.TestCase):
    """Test M — Repeated Join All / Leave All / Join All remains idempotent."""

    def test_5_cycles(self):
        state = _FakeVCState()
        vcs = list(range(3000, 3010))
        for cycle in range(5):
            eligible = [v for v in vcs if not state.is_dead_lettered(v)]
            self.assertEqual(len(eligible), 10, f"cycle {cycle}")
            for v in vcs:
                state.record_failure(v)
            # v97.79: Leave All clears worker + breaker + floodwait + dead-letter
            state.reset_target_state(include_global_floodwait=True)
        self.assertEqual(len(state.entity_fail_counts), 0)


class TestNFloodWaitDoesNotPermanentlyRemove(unittest.TestCase):
    """Test N — FloodWait does not permanently remove a VC."""

    def test_floodwait_not_dead_letter(self):
        state = _FakeVCState()
        # FloodWait is NOT an entity failure (per source)
        self.assertFalse(state.is_dead_lettered(4001))


class TestOCooldownExpires(unittest.TestCase):
    """Test O — Breaker/cooldown state expires via reset."""

    def test_cooldown_cleared(self):
        state = _FakeVCState()
        state.target_cooldowns[5001] = 1.0
        state.breaker_open = True
        state.reset_target_state()
        self.assertEqual(len(state.target_cooldowns), 0)
        self.assertFalse(state.breaker_open)


class TestPOneDeadLetterNoSuppression(unittest.TestCase):
    """Test P — One dead-lettered VC does not suppress others."""

    def test_isolated(self):
        state = _FakeVCState()
        for _ in range(3):
            state.record_failure(6001)
        vcs = [6001, 6002, 6003, 6004, 6005]
        eligible = [v for v in vcs if not state.is_dead_lettered(v)]
        self.assertEqual(len(eligible), 4)
        self.assertNotIn(6001, eligible)


class TestQStaleWorkerCannotBlock(unittest.TestCase):
    """Test Q — A stale/cancelling Join All worker cannot block a new valid Join All.
    v97.79: Leave All stops the worker first, so the next Join All doesn't hit already_running."""

    def test_worker_stopped_before_join(self):
        state = _FakeVCState()
        state.worker_alive = True
        # v97.79: Leave All stops worker
        state.reset_target_state(include_global_floodwait=True)
        self.assertFalse(state.worker_alive)
        # Next Join All can proceed (no already_running)


class TestRMultipleAccountsIsolated(unittest.TestCase):
    """Test R — Multiple accounts remain isolated."""

    def test_per_chat_state(self):
        state = _FakeVCState()
        state.record_failure(8001)
        self.assertFalse(state.is_dead_lettered(8001))  # only 1 failure
        state.reset_target_state()
        self.assertFalse(state.is_dead_lettered(8001))


if __name__ == "__main__":
    unittest.main()
