"""v99.11.1 FIX-1 — THE FD/SOCKET LIFECYCLE SUITE.

PRODUCTION EVIDENCE (2026-09-22/23 diagnostic logs):
  * open_fds climbed 262→881/1024 with joined_transports FLAT (36→39):
    sockets 244→859 — ≈ +5-7 retained sockets/minute with NO
    corresponding transport growth, invisible to every log-visible
    operation, TASK_POPULATION flat at 37 (the sockets carry no asyncio
    tasks — in-process native WebRTC sockets, not Telethon TCP
    connections), memory FLAT (~173MB) — the resource that grew was
    ONLY FDs/sockets.
  * The measured steady-state cost: 6 sockets idle (joined=0, 85 flat
    minutes after the 23:13 restart) vs 252-282 sockets at 36-39 joined
    → ≈ 6.8-7.1 PYTHON-process sockets per ACTIVE native transport.
  * The v99.11 admission model projected only 5 FDs per join and
    counted ``joined`` from the ownership map (populated only AFTER a
    successful dispatch) — invisible transports were invisible to
    admission.
  * The transport leak sweep ran ONLY at join-dispatch time — during
    the drift phase (no joins in flight) it NEVER ran.

THE v99.11.1 FIX UNDER TEST:
  * measured per-join FD cost (8 = measured 7 + 1 margin) in the
    admission FD dimension (env-tunable VC_JOIN_FD_COST);
  * the admission joined-counter = max(ownership map, lifecycle-tracker
    ACTIVE count) — no invisible transports;
  * per-operation FD instrumentation (fd_class_census / fd_op_phase →
    VC_FD_OP_DELTA) at the 8 required lifecycle boundaries;
  * heartbeat FD-drift detection (fd_drift_evaluate →
    VC_FD_DRIFT_SUSPECTED) + the leak sweep on EVERY beat;
  * the acquisition↔release pairing harness: repeated join→leave,
    failed-join→cleanup, already-joined→idempotent, pause/resume and
    recovery cycles must return the FD census to baseline — NO
    monotonic growth.

PRESERVED v99.11 GUARANTEES asserted here: admission denies only NEW
joins (never touches ACTIVE transports); the FD guard stays the
last-resort backstop; the drift detector takes NO destructive action.
"""

from __future__ import annotations

import asyncio
import os
import socket
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mediagrab_bot import vc_resources as vr  # noqa: E402

_ROOT = str(Path(__file__).resolve().parents[1])
_VC = os.path.join(_ROOT, "mediagrab_bot", "voicechat.py")
_HD = os.path.join(_ROOT, "mediagrab_bot", "handlers.py")
_VP = os.path.join(_ROOT, "mediagrab_bot", "vc_pipeline.py")
_VR = os.path.join(_ROOT, "mediagrab_bot", "vc_resources.py")


def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def _fd_total() -> int:
    return vr.fd_class_census()["total"]


class FakeNativeTransport:
    """A faithful instrumented native-transport lifecycle.

    Models the measured production arithmetic: one transport = SEVEN
    process sockets (the in-process WebRTC stack: RTP/RTCP + ICE
    candidates).  ``acquire`` opens them; ``release`` closes every one;
    ``acquire_then_raise`` models a FAILED join (the partial allocation
    the pipeline's §11 FAILED_JOIN_CLEANUP must release).
    """

    SOCKETS_PER_TRANSPORT = 7  # the MEASURED production cost

    def __init__(self, chat_id: int):
        self.chat_id = chat_id
        self._socks: list[socket.socket] = []

    def acquire(self) -> None:
        for _ in range(self.SOCKETS_PER_TRANSPORT):
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.bind(("127.0.0.1", 0))
            self._socks.append(s)

    def release(self) -> None:
        for s in self._socks:
            try:
                s.close()
            except OSError:
                pass
        self._socks.clear()

    def acquire_then_raise(self) -> None:
        self.acquire()
        raise RuntimeError("native join raised mid-allocation")

    @property
    def live(self) -> int:
        return len(self._socks)


class TestFdClassCensus(unittest.TestCase):
    """fd_class_census — the pure /proc classification primitive."""

    def test_a1_available_and_consistent(self):
        cens = vr.fd_class_census()
        self.assertGreaterEqual(cens["total"], 0)
        if cens["total"] >= 0:
            classes = (cens["sockets"] + cens["pipes"] + cens["files"]
                       + cens["anon"] + cens["other"])
            self.assertEqual(classes, cens["total"],
                             "class counts must sum to the total")

    def test_a2_sees_real_sockets(self):
        before = vr.fd_class_census()
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind(("127.0.0.1", 0))
        try:
            during = vr.fd_class_census()
            self.assertEqual(during["total"], before["total"] + 1)
            self.assertEqual(during["sockets"], before["sockets"] + 1)
        finally:
            s.close()
        after = vr.fd_class_census()
        self.assertEqual(after["total"], before["total"])
        self.assertEqual(after["sockets"], before["sockets"])

    def test_a3_never_raises(self):
        # Repeated calls are safe (the /proc read path is guarded).
        for _ in range(5):
            self.assertGreaterEqual(_fd_total(), 0)


class TestFdOpPhase(unittest.TestCase):
    """fd_op_phase — the per-operation VC_FD_OP_DELTA instrumentation."""

    def setUp(self):
        vr.reset_fd_instrumentation()

    def tearDown(self):
        vr.reset_fd_instrumentation()

    def test_b1_before_after_cleanup_deltas(self):
        base = vr.fd_op_phase("op_test", 1, "before")
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind(("127.0.0.1", 0))
        try:
            after = vr.fd_op_phase("op_test", 1, "after")
            self.assertEqual(after["total"], base["total"] + 1)
            self.assertEqual(after["sockets"], base["sockets"] + 1)
        finally:
            s.close()
        cleanup = vr.fd_op_phase("op_test", 1, "cleanup")
        self.assertEqual(cleanup["total"], base["total"])
        self.assertEqual(cleanup["sockets"], base["sockets"])

    def test_b2_baseline_dropped_after_completion(self):
        vr.fd_op_phase("op_test", 7, "before")
        vr.fd_op_phase("op_test", 7, "cleanup")
        # The instrumentation itself must not retain baselines (the
        # instrument must not be a leak source).
        self.assertEqual(len(vr._fd_op_baselines), 0)

    def test_b3_phases_cover_the_required_operations(self):
        """The 8 required operation boundaries exist in the shipped
        source: join dispatch (success+failed), already-joined, leave,
        Join-All pause/resume, stale recovery, crash/restart recovery,
        failed-join cleanup."""
        vc_src = _read(_VC)
        vp_src = _read(_VP)
        self.assertIn('"native_join_dispatch"', vc_src)
        self.assertIn('"failed"', vc_src)  # dispatch failure phase
        self.assertIn('"native_leave"', vc_src)
        self.assertIn('"join_all_breaker_pause"', vc_src)
        self.assertIn('"stale_container_recovery"', vc_src)
        self.assertIn('"crash_restart_recovery"', vc_src)
        self.assertIn('"failed_join_cleanup"', vp_src)


class TestFdDriftDetector(unittest.TestCase):
    """fd_drift_evaluate — the production leak signature detector."""

    def setUp(self):
        vr.reset_fd_instrumentation()
        # Controllable clock (vc_resources uses time.monotonic()).
        class _Clock:
            t = 1000.0
            def monotonic(self):
                return _Clock.t
        self._clock = _Clock
        self._saved_time = vr.time
        vr.time = _Clock()

    def tearDown(self):
        vr.time = self._saved_time
        vr.reset_fd_instrumentation()

    def _beat(self, fd: int, joined: int, advance: float = 60.0) -> bool:
        self._clock.t += advance
        return vr.fd_drift_evaluate(fd, joined, sockets=max(0, fd - 18))

    def test_c1_production_curve_detected(self):
        """The measured 2026-09-22 curve: joined FLAT at 39 while fd
        climbs ~6/beat — suspected on every growth beat."""
        self._beat(300, 39, advance=0.0)  # baseline
        r1 = self._beat(306, 39)
        self._beat(312, 39)
        r3 = self._beat(318, 39)
        self.assertTrue(r1)
        self.assertTrue(r3)
        # 3 consecutive growth beats → the streak qualifies for the
        # VC_FD_DRIFT_SUSPECTED WARNING.
        self.assertGreaterEqual(vr._fd_drift_state["suspect_streak"], 3)

    def test_c2_flat_fd_not_suspected(self):
        self._beat(300, 39, advance=0.0)
        r = self._beat(300, 39)
        self.assertFalse(r)
        r = self._beat(300, 39)
        self.assertFalse(r)
        self.assertEqual(vr._fd_drift_state["suspect_streak"], 0)

    def test_c2b_jitter_never_qualifies(self):
        """Oscillating ±2 jitter (the healthy steady state) never
        sustains a 3-beat growth streak — no drift WARNING fires."""
        self._beat(300, 39, advance=0.0)
        for fd in (302, 300, 301, 299, 301, 300):
            self._beat(fd, 39)
        self.assertLess(vr._fd_drift_state["suspect_streak"], 3)

    def test_c3_growth_with_transport_growth_not_suspected(self):
        """+7 FDs WITH +1 joined transport is the MEASURED healthy
        per-transport cost, not a leak."""
        self._beat(300, 39, advance=0.0)
        r = self._beat(307, 40)
        self.assertFalse(r)

    def test_c4_falling_fd_not_suspected(self):
        self._beat(300, 39, advance=0.0)
        r = self._beat(290, 39)
        self.assertFalse(r)

    def test_c5_heartbeat_wiring(self):
        """The heartbeat census block calls the drift detector + the
        leak sweep on EVERY logged beat (v99.11 swept only at join
        time)."""
        hd = _read(_HD)
        self.assertIn("fd_drift_evaluate", hd)
        self.assertIn("sweep_for_leaks", hd)
        # And the drift detector is OBSERVABILITY ONLY — the heartbeat
        # keeps the v99.02 guard as the only restart path.
        self.assertIn("_fd_guard_evaluate", hd)


class TestAdmissionModel(unittest.TestCase):
    """The evidence-based admission corrections."""

    def test_d1_measured_join_fd_cost(self):
        self.assertEqual(vr.DEFAULT_JOIN_FD_COST, 8)

    def test_d2_fd_dimension_uses_the_measured_cost(self):
        snap = vr.ResourceSnapshot(
            rss_mb=None, threads=None,
            fd_count=800, fd_limit=1024, joined_transports=37,
            active_joins=1, queued_joins=0)
        dec = vr.evaluate_admission(snap)
        # 800 + 8×(1+1) = 816 < 0.80×1024 = 819 → allowed (narrowly).
        self.assertTrue(dec.allowed, str(dec.reason))
        snap2 = vr.ResourceSnapshot(
            rss_mb=None, threads=None,
            fd_count=805, fd_limit=1024, joined_transports=37,
            active_joins=1, queued_joins=0)
        dec2 = vr.evaluate_admission(snap2)
        # 805 + 16 = 821 ≥ 819 → denied BEFORE the 0.85 emergency region.
        self.assertFalse(dec2.allowed)
        self.assertIn("fd_total=805", dec2.reason)
        self.assertIn("×(1+1)", dec2.reason)

    def test_d3_env_override(self):
        snap = vr.ResourceSnapshot(
            rss_mb=None, threads=None,
            fd_count=805, fd_limit=1024, joined_transports=37,
            active_joins=1, queued_joins=0)
        os.environ["VC_JOIN_FD_COST"] = "2"
        try:
            dec = vr.evaluate_admission(snap)
            # 805 + 2×2 = 809 < 819 → allowed with the override.
            self.assertTrue(dec.allowed, str(dec.reason))
        finally:
            os.environ.pop("VC_JOIN_FD_COST", None)

    def test_d4_admission_preserves_the_v9911_guarantees(self):
        """VC_MAX_JOINED=40 admission BEFORE allocation; denial defers
        the NEW join only (the reason line preserves the exact marker
        shape); admission never mutates ACTIVE transports (pure
        decision function — no side effects)."""
        snap = vr.ResourceSnapshot(
            rss_mb=None, threads=None,
            fd_count=100, fd_limit=1024, joined_transports=40,
            active_joins=0, queued_joins=0)
        dec = vr.evaluate_admission(snap)
        self.assertFalse(dec.allowed)
        self.assertIn("VC_MAX_JOINED", dec.reason)
        self.assertIn("joined_transports=40", dec.reason)

    def test_d5_joined_counter_uses_the_tracker_maximum(self):
        """The admission blind-spot fix: joined = max(ownership map,
        lifecycle-tracker ACTIVE) — a container transport with NO
        ownership entry is still visible to admission."""
        vc_src = _read(_VC)
        self.assertIn("count_active()", vc_src)
        # Behavioral: the tracker itself counts ACTIVE transports.
        tl = vr.TransportLifecycleTracker()
        for cid in (1, 2, 3):
            tl.mark_allocating(cid, "acc_X")
            tl.mark_active(cid)
        tl.mark_allocating(4, "acc_X")  # in-flight, NOT active yet
        self.assertEqual(tl.count_active(), 3)
        tl.mark_failed(2, reason="dispatch_error")
        self.assertEqual(tl.count_active(), 2)
        tl.mark_released(3)
        self.assertEqual(tl.count_active(), 1)


class TestAcquisitionReleasePairing(unittest.TestCase):
    """THE deterministic regression harness: every acquisition has a
    matching release across repeated lifecycle cycles — FD usage must
    NOT monotonically increase (join→leave→join→leave, failed
    join→cleanup, already-joined idempotent, pause/resume, recovery)."""

    def setUp(self):
        vr.reset_fd_instrumentation()

    def tearDown(self):
        vr.reset_fd_instrumentation()

    def test_e1_join_leave_cycles_return_to_baseline(self):
        base = _fd_total()
        for cycle in range(5):
            t = FakeNativeTransport(1000 + cycle)
            t.acquire()
            self.assertEqual(_fd_total(),
                             base + FakeNativeTransport.SOCKETS_PER_TRANSPORT)
            t.release()
            self.assertEqual(_fd_total(), base,
                             f"cycle {cycle}: FDs not returned to baseline")

    def test_e2_failed_join_cleanup_releases_partial_allocation(self):
        """The exception path must release EXACTLY like the normal path
        (the pipeline's §11 FAILED_JOIN_CLEANUP contract)."""
        base = _fd_total()
        for cycle in range(5):
            t = FakeNativeTransport(2000 + cycle)
            with self.assertRaises(RuntimeError):
                t.acquire_then_raise()
            # The §11 cleanup equivalent: release on the failure path.
            t.release()
            self.assertEqual(_fd_total(), base)

    def test_e3_failed_join_without_cleanup_is_detectable(self):
        """A partial allocation WITHOUT cleanup is the leak the drift
        detector + leak sweep must surface (the harness proves the
        instrumentation catches the failure mode it exists for)."""
        base = _fd_total()
        t = FakeNativeTransport(3000)
        try:
            with self.assertRaises(RuntimeError):
                t.acquire_then_raise()
            # NO cleanup — the retained sockets are visible.
            self.assertGreater(_fd_total(), base)
        finally:
            t.release()

    def test_e4_already_joined_is_idempotent_no_allocation(self):
        """The FIX-3 convergence path: an already-joined target creates
        NO duplicate native transport (FD census unchanged)."""
        base = _fd_total()
        existing = FakeNativeTransport(4000)
        existing.acquire()
        try:
            with_join = _fd_total()
            # Idempotent re-dispatch: reuses the EXISTING transport
            # object — no new acquisition (the convergence contract).
            self.assertEqual(_fd_total(), with_join)
        finally:
            existing.release()
        self.assertEqual(_fd_total(), base)

    def test_e5_pause_resume_retains_nothing(self):
        """Join-All pause/resume (breaker wait): the pause boundary
        takes no allocation and the resume returns the census to the
        pause baseline (VC_FD_OP_DELTA join_all_breaker_pause)."""
        base = vr.fd_op_phase("join_all_breaker_pause", 500, "before")
        # Simulated wait: open + close a transient socket (e.g. RPC) —
        # must be released before resume.
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.bind(("127.0.0.1", 0))
        s.close()
        after = vr.fd_op_phase("join_all_breaker_pause", 500, "cleanup")
        self.assertEqual(after["total"], base["total"])

    def test_e6_stale_recovery_releases_the_dead_transport(self):
        """Stale-container recovery: the dead transport's sockets are
        released at the recovery boundary (before→cleanup pairing)."""
        base = _fd_total()
        t = FakeNativeTransport(6000)
        t.acquire()  # the dead/stale transport
        vr.fd_op_phase("stale_container_recovery", 6000, "before")
        t.release()  # the recovery's leave/remove
        cleanup = vr.fd_op_phase("stale_container_recovery", 6000, "cleanup")
        self.assertEqual(cleanup["total"], base)

    def test_e7_interleaved_multi_transport_cycles(self):
        """Many transports, interleaved joins/leaves/exceptions — the
        full production-shaped churn — never drift the baseline."""
        base = _fd_total()
        live: list[FakeNativeTransport] = []
        try:
            for cycle in range(8):
                t = FakeNativeTransport(7000 + cycle)
                t.acquire()
                live.append(t)
                if cycle % 2 == 0:
                    # leave half of them (the successful-leave path)
                    live.pop(0).release()
                if cycle % 3 == 0:
                    # a failed join + cleanup on a fresh target
                    f = FakeNativeTransport(8000 + cycle)
                    with self.assertRaises(RuntimeError):
                        f.acquire_then_raise()
                    f.release()
            # All remaining live transports leave.
            while live:
                live.pop().release()
            self.assertEqual(_fd_total(), base,
                             "interleaved cycles drifted the FD baseline")
        finally:
            while live:
                live.pop().release()


class TestTransportLifecycleTracker(unittest.TestCase):
    """The tracker (the admission's honest ACTIVE counter)."""

    def test_f1_states_and_counts(self):
        tl = vr.TransportLifecycleTracker()
        tl.mark_allocating(1, "acc_A")
        self.assertEqual(tl.get_state(1), "ALLOCATING")
        tl.mark_active(1)
        self.assertEqual(tl.get_state(1), "ACTIVE")
        tl.mark_stopping(1)
        self.assertEqual(tl.get_state(1), "STOPPING")
        tl.mark_released(1)
        self.assertEqual(tl.get_state(1), "RELEASED")
        self.assertEqual(tl.count_active(), 0)

    def test_f2_sweep_detects_stuck_transports(self):
        import time
        tl = vr.TransportLifecycleTracker(leak_after_seconds=0.01)
        tl.mark_allocating(42, "acc_A")  # stuck ALLOCATING forever
        time.sleep(0.02)
        suspects = tl.sweep_for_leaks()
        self.assertEqual(len(suspects), 1)
        self.assertEqual(suspects[0][0], 42)

    def test_f3_synthetic_record_for_untracked_chat(self):
        """A transport never seen allocating (resumed process) gets a
        synthetic record — downstream observation still works."""
        tl = vr.TransportLifecycleTracker()
        tl.mark_active(99)
        self.assertEqual(tl.get_state(99), "ACTIVE")
        self.assertEqual(tl.count_active(), 1)


class TestSourceContracts(unittest.TestCase):
    """Machine-searchable wiring contracts."""

    def test_g1_dispatch_instrumentation(self):
        vc_src = _read(_VC)
        self.assertIn('fd_op_phase as _v9911_fdop', vc_src)
        self.assertIn('"native_join_dispatch", chat_id, "before"', vc_src)
        self.assertIn('"native_join_dispatch", chat_id,\n                                    "failed"', vc_src)
        self.assertIn('"native_join_dispatch", chat_id, "after"', vc_src)

    def test_g2_leave_instrumentation(self):
        vc_src = _read(_VC)
        self.assertIn('fd_op_phase as _v9911_fdop_leave', vc_src)
        self.assertIn('"native_leave", chat_id, "before"', vc_src)
        self.assertIn('"native_leave", chat_id, "after"', vc_src)

    def test_g3_counters_unification(self):
        vc_src = _read(_VC)
        self.assertIn("transport_lifecycle as _v9911_tl_c", vc_src)
        self.assertIn("if _v9911_tracked_active > joined:", vc_src)

    def test_g4_v9911_guarantees_preserved(self):
        """The v99.11 marker set is intact: admission-before-allocation,
        pressure deferral, no-destructive-leave-on-pressure, the FD
        guard backstop, heartbeat census."""
        vc_src = _read(_VC)
        hd_src = _read(_HD)
        self.assertIn("VC_MAX_JOINED", _read(_VR))
        self.assertIn("VCResourcePressureError", vc_src)
        self.assertIn("ACTIVE transports are NEVER touched", vc_src)
        self.assertIn("VC_FD_GUARD_RESTART", hd_src)
        self.assertIn("BOT_HEARTBEAT", hd_src)
        self.assertIn("FD_CENSUS", hd_src)

    def test_g5_drift_detector_has_no_destructive_action(self):
        """The drift detector's own source contains no leave/restart
        invocation — observability only."""
        vr_src = _read(_VR)
        seg = vr_src.split("def fd_drift_evaluate", 2)[1].split(
            "def reset_fd_instrumentation")[0]
        self.assertNotIn("vc_leave", seg)
        self.assertNotIn("SIGTERM", seg)
        self.assertNotIn("record_failure", seg)


if __name__ == "__main__":
    unittest.main()
