"""
v97.67 regression tests — mid-RPC disconnect race + Join-All shutdown orphan.

Root causes fixed:
  1. mtproto_call_with_retry checked connectivity ONCE before the loop, but the
     client can disconnect DURING the RPC. The ConnectionError handler retried
     WITHOUT re-checking — producing 48 retry errors in the v97.66 log.
  2. vc_join_all_active_stop used asyncio.shield() which prevented CancelledError
     from propagating into the worker. The 45-iteration reconnect wait loop
     also didn't check _token.is_cancelled.
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")


class TestMidRpcDisconnectRace(unittest.TestCase):
    """P0: the retry loop must be disconnect-aware at EVERY attempt."""

    def test_per_attempt_connectivity_check(self):
        """The connectivity check must be INSIDE the retry loop, not just before it."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_is_gate_client_connected()", src,
                      "must have a per-attempt connectivity check function")
        self.assertIn("before attempt", src,
                      "must log 'before attempt' when checking connectivity per attempt")

    def test_connection_error_handler_rechecks_client(self):
        """The ConnectionError handler must immediately classify disconnect."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("ConnectionError on attempt", src,
                      "ConnectionError handler must log which attempt failed")
        self.assertIn("classified as disconnect", src,
                      "must classify disconnect exceptions and terminate retry loop")

    def test_no_sleep_when_disconnected(self):
        """When the client is disconnected after a ConnectionError, must NOT sleep."""
        with open(_MTPROTO) as f:
            src = f.read()
        # The handler must raise BEFORE setting _sleep_before_retry.
        # Check that the raise is before the _sleep_before_retry assignment
        # in the disconnected branch.
        import re
        m = re.search(r'except ConnectionError as exc:.*?(?=\n        except )', src, re.DOTALL)
        self.assertIsNotNone(m, "ConnectionError handler not found")
        handler = m.group(0)
        # The disconnected branch must raise before any sleep.
        raise_pos = handler.find("raise ConnectionError")
        sleep_pos = handler.find("_sleep_before_retry")
        self.assertGreater(raise_pos, 0, "must raise in disconnected branch")
        # The sleep must be AFTER the raise (in the "client still connected" branch).
        self.assertGreater(sleep_pos, raise_pos,
                           "sleep must be after the raise (only for connected clients)")

    def test_floodwait_preserved(self):
        """FloodWait handling must be preserved."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("FloodWaitError", src)
        self.assertIn("vc_set_global_floodwait", src)

    def test_transient_connection_error_still_retries(self):
        """When the client is STILL connected after a ConnectionError, must retry."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("will retry (client still connected)", src,
                      "must retry when client is still connected after ConnectionError")


class TestJoinAllShutdownOrphan(unittest.TestCase):
    """P1: Join-All shutdown must not leave the worker alive."""

    def test_no_asyncio_shield_in_stop(self):
        """vc_join_all_active_stop must NOT use asyncio.shield in actual code."""
        with open(_VOICECHAT) as f:
            src = f.read()
        # Find the stop function.
        import re
        m = re.search(r'async def vc_join_all_active_stop.*?(?=\nasync def |\ndef )', src, re.DOTALL)
        self.assertIsNotNone(m, "vc_join_all_active_stop not found")
        func_body = m.group(0)
        # Remove comments (lines starting with #) before checking.
        code_only = re.sub(r'#.*', '', func_body)
        self.assertNotIn("asyncio.shield", code_only,
                         "must NOT use asyncio.shield in actual code (it prevents CancelledError propagation)")

    def test_reconnect_wait_checks_token_cancelled(self):
        """The reconnect wait loop must check _token.is_cancelled."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_token.is_cancelled", src,
                      "reconnect wait must check _token.is_cancelled")

    def test_reconnect_wait_has_cancelled_error_handler(self):
        """The reconnect wait loop must handle CancelledError."""
        with open(_VOICECHAT) as f:
            src = f.read()
        # The reconnect wait loop must have a CancelledError handler.
        self.assertIn("except asyncio.CancelledError:", src)

    def test_shutdown_does_not_force_clear(self):
        """The shutdown must NOT force-clear state while the worker is alive."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("marking ORPHANED (NOT force-clearing state", src)
        self.assertNotIn("force-clearing state\")", src,
                         "must NOT log force-clearing state")


class TestPreservedBehavior(unittest.TestCase):
    """Verify all previous fixes are still present."""

    def test_event_loop_lag_instrumentation(self):
        with open(os.path.join(_BASE, "mediagrab_bot/bootstrap.py")) as f:
            src = f.read()
        self.assertIn("_capture_blocking_task_stack", src)
        self.assertIn("EVENT_LOOP_LAG_APP_TASKS", src)

    def test_dashboard_single_to_thread(self):
        with open(os.path.join(_BASE, "mediagrab_bot/handlers.py")) as f:
            src = f.read()
        self.assertIn("_snapshot_and_triggers", src)

    def test_callback_handler_sync_properties(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("event.sender_id", src)

    def test_no_await_on_sync_release(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertNotIn("await _vc_release_target_inflight", src)

    def test_entity_dead_letter_network_exclusion(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_is_network_err", src)

    def test_get_entity_wrapper(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_wrap_get_entity_disconnect_safe", src)

    def test_join_all_get_entity_timeout(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_JOIN_ALL_ENTITY_TIMEOUT", src)

    def test_reconcile_timeout_cause(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("classified UNKNOWN cause=", src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
