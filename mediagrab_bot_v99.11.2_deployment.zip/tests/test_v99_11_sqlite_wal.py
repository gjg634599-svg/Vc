"""v99.11 — THE SQLITE / WAL CHECKPOINT SUITE (P1).

Production evidence: "WAL checkpoint error: database table is locked"
repeated through the 2026-09-21 reconcile-active logs.  Root cause
(empirically verified below): ``PRAGMA wal_checkpoint(TRUNCATE)`` ran on
the SHARED aiosqlite connection while other coroutines held open read
cursors / implicit write transactions on it — SQLITE_LOCKED is a
SELF-lock; the busy handler CANNOT resolve it (busy_timeout is useless)
and the error was swallowed at DEBUG.

FIX UNDER TEST: the checkpoint now runs on a DEDICATED short-lived
sqlite3 connection (utils_real.run_wal_checkpoint, via
asyncio.to_thread), where cross-connection contention degrades to a
(busy, log, ckpt) result row — never an exception — with bounded
retry/backoff and INFO/WARNING observability.  Plus the talkative
retention-sweep fixes (nonexistent column + dangling write txn) and the
db_layer write-serialization lock.
"""

from __future__ import annotations

import asyncio
import os
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def _tmp_db():
    d = tempfile.mkdtemp(prefix="v9911_sqlite_")
    p = os.path.join(d, "test.db")
    conn = sqlite3.connect(p)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT)")
    conn.execute("INSERT INTO t (v) VALUES ('a')")
    conn.commit()
    conn.close()
    return p


class TestTheSelfLockMechanism(unittest.TestCase):
    """T1: reproduce the EXACT v99.10 failure mechanism — proving WHY the
    fix is a dedicated connection (not a timeout/mode tweak)."""

    def test_t1_same_connection_checkpoint_self_locks(self):
        p = _tmp_db()
        conn = sqlite3.connect(p, timeout=5.0)
        try:
            # open an UNCOMMITTED write txn + a mid-scan read cursor on
            # the SAME connection (the production shape: reconcile reads
            # + implicit txns on the shared aiosqlite connection)
            conn.execute("INSERT INTO t (v) VALUES ('uncommitted')")
            cur = conn.execute("SELECT * FROM t")
            cur.fetchone()  # cursor mid-scan
            with self.assertRaises(sqlite3.OperationalError) as cm:
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
            self.assertIn("locked", str(cm.exception).lower())
            cur.close()
        finally:
            conn.close()
            os.unlink(p)

    def test_t1b_second_connection_never_raises(self):
        """The SAME contention from a SECOND connection degrades to a
        (busy, log, ckpt) row — the fix's foundation."""
        p = _tmp_db()
        c1 = sqlite3.connect(p)
        c1.execute("INSERT INTO t (v) VALUES ('x')")
        # leave the write txn OPEN on c1
        c2 = sqlite3.connect(p, timeout=2.0)
        try:
            row = c2.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
            self.assertIsNotNone(row)
            self.assertEqual(len(row), 3)  # (busy, log, ckpt)
        finally:
            c1.rollback()
            c1.close()
            c2.close()
            os.unlink(p)


class TestRunWalCheckpoint(unittest.TestCase):
    """The v99.11 dedicated-connection checkpoint."""

    def _patch_db_path(self, tmp_path):
        import mediagrab_bot.db_layer as dbl
        orig = dbl._effective_config

        class _Cfg:
            db_path = Path(tmp_path)

        dbl._effective_config = lambda: _Cfg()
        return orig, dbl

    def test_t2_quiescent_checkpoint_succeeds(self):
        import mediagrab_bot.utils_real as ur
        p = _tmp_db()
        orig, dbl = self._patch_db_path(p)
        try:
            busy, log, ckpt = asyncio.run(ur.run_wal_checkpoint())
            self.assertEqual(busy, 0)
            self.assertGreaterEqual(ckpt, 0)
        finally:
            dbl._effective_config = orig
            for f in (p, p + "-wal", p + "-shm"):
                if os.path.exists(f):
                    os.unlink(f)

    def test_t3_busy_path_no_raise_bounded_retries(self):
        """A concurrent writer holding the WAL → busy result, no
        exception, retries bounded (fast via the test-sleep patch)."""
        import mediagrab_bot.utils_real as ur
        p = _tmp_db()
        orig, dbl = self._patch_db_path(p)
        ur._WAL_CHECKPOINT_RETRY_SLEEP = 0.0  # fast retries for the test
        ur._WAL_CHECKPOINT_CONN_TIMEOUT = 0.3  # fast busy-timeout for the test
        c1 = sqlite3.connect(p)
        c1.execute("INSERT INTO t (v) VALUES ('hold-wal')")
        try:
            # TRUNCATE needs the WAL exclusively; c1's open write txn
            # blocks the truncate portion → busy=1 (never raises)
            busy, log, ckpt = asyncio.run(ur.run_wal_checkpoint())
            self.assertEqual(busy, 1,
                             "expected busy while a writer holds the WAL")
        finally:
            ur._WAL_CHECKPOINT_RETRY_SLEEP = 30.0
            ur._WAL_CHECKPOINT_CONN_TIMEOUT = 10.0
            dbl._effective_config = orig
            c1.rollback()
            c1.close()
            for f in (p, p + "-wal", p + "-shm"):
                if os.path.exists(f):
                    os.unlink(f)

    def test_t4_open_cursor_on_shared_conn_no_self_lock(self):
        """The exact production contention shape (open cursor + open
        write txn on the SHARED connection) no longer raises — the
        checkpoint's dedicated connection is immune."""
        import mediagrab_bot.utils_real as ur
        p = _tmp_db()
        orig, dbl = self._patch_db_path(p)
        shared = sqlite3.connect(p)
        try:
            shared.execute("INSERT INTO t (v) VALUES ('implicit-txn')")
            cur = shared.execute("SELECT * FROM t")
            cur.fetchone()
            busy, log, ckpt = asyncio.run(ur.run_wal_checkpoint())
            # no raise — that is the whole point
            self.assertIn(busy, (0, 1))
            cur.close()
            shared.rollback()
        finally:
            dbl._effective_config = orig
            shared.close()
            for f in (p, p + "-wal", p + "-shm"):
                if os.path.exists(f):
                    os.unlink(f)


class TestTalkativeRetention(unittest.TestCase):
    """The retention-sweep fixes: correct column + no dangling txn."""

    def test_t5_inspected_chats_uses_real_column(self):
        src = (Path(__file__).resolve().parents[1] / "mediagrab_bot"
               / "talkative.py").read_text(encoding="utf-8")
        # the v99.10 statement used the NONEXISTENT checked_at column
        self.assertNotIn("inspected_chats WHERE checked_at", src)
        self.assertIn(
            "DELETE FROM inspected_chats WHERE created_at", src)
        # always commit/rollback after the batch (no dangling txn)
        self.assertIn("await _db.rollback()", src)

    def test_t5b_retention_sweep_no_dangling_txn(self):
        """Zero deletions still leaves NO open write transaction."""
        import aiosqlite
        from mediagrab_bot.db_layer import SCHEMA_SQL, _run_migrations

        async def run():
            d = tempfile.mkdtemp(prefix="v9911_ret_")
            p = os.path.join(d, "r.db")
            db = await aiosqlite.connect(p)
            await db.executescript(SCHEMA_SQL)
            await _run_migrations(db)
            await db.commit()
            try:
                # zero rows match → the sweep's DELETEs delete nothing;
                # the v99.11 fix still closes the transaction.
                cur = await db.execute(
                    "DELETE FROM inspected_chats WHERE created_at < "
                    "datetime('now','-30 days')")
                self.assertEqual(cur.rowcount or 0, 0)
                await db.commit()  # the v99.11 always-commit contract
                self.assertFalse(db.in_transaction,
                                  "no dangling write txn after the sweep")
            finally:
                await db.close()
        asyncio.run(run())


class TestWriteSerializationLock(unittest.TestCase):
    """db_write_lock: multi-statement write scopes serialize."""

    def test_t6_write_lock_serializes(self):
        from mediagrab_bot.db_layer import _get_write_lock
        lock = _get_write_lock()
        order = []

        async def worker(n):
            async with lock:
                order.append(f"enter{n}")
                await asyncio.sleep(0.02)
                order.append(f"exit{n}")

        async def run():
            await asyncio.gather(worker(1), worker(2))
        asyncio.run(run())
        self.assertEqual(order, ["enter1", "exit1", "enter2", "exit2"])

    def test_t7_checkpoint_saves_serialized(self):
        """CheckpointManager.save_checkpoint holds the manager lock —
        two concurrent saves cannot interleave their UPDATE/commit
        pairs (source + behaviour)."""
        from mediagrab_bot.join_all_worker import CheckpointManager
        cm = CheckpointManager()
        lock = cm._save_lock()
        self.assertIsNotNone(lock)
        src = (Path(__file__).resolve().parents[1] / "mediagrab_bot"
               / "join_all_worker.py").read_text(encoding="utf-8")
        self.assertIn("async with self._save_lock():", src)


class TestDbLayerPragmas(unittest.TestCase):
    def test_t8_wal_and_timeout_config(self):
        src = (Path(__file__).resolve().parents[1] / "mediagrab_bot"
               / "db_layer.py").read_text(encoding="utf-8")
        self.assertIn("PRAGMA journal_mode=WAL", src)
        self.assertIn("PRAGMA busy_timeout=5000", src)
        self.assertIn("PRAGMA synchronous=NORMAL", src)
        # v99.11: explicit auto-checkpoint
        self.assertIn("PRAGMA wal_autocheckpoint=1000", src)
        # v99.11: the new durability columns exist in schema + migration
        self.assertIn("resume_attempts", src)
        self.assertIn("resource_json", src)
        self.assertIn("last_successful_target", src)

    def test_t9_utils_real_no_shared_conn_checkpoint(self):
        """The old self-locking pattern is GONE."""
        src = (Path(__file__).resolve().parents[1] / "mediagrab_bot"
               / "utils_real.py").read_text(encoding="utf-8")
        self.assertNotIn('db.execute("PRAGMA wal_checkpoint', src)
        self.assertIn("def run_wal_checkpoint", src)
        self.assertIn("_wal_checkpoint_blocking", src)
        self.assertIn("WAL_CHECKPOINT_OK", src)
        self.assertIn("WAL_CHECKPOINT_BUSY", src)


if __name__ == "__main__":
    unittest.main()
