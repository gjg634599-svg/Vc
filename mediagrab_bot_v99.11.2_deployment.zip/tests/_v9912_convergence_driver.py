"""v99.11.2 FIX — Join-All already-joined CONVERGENCE driver.

Runs the REAL production ``_vc_join_all_active_worker`` (full module body)
via the proven v98.10 fastpath harness (fake Telethon RPC surface, fake
PyTgCalls 2.3.3 semantics, REAL join_all_worker circuit breaker + REAL
vc_state_coordinator + REAL state machines), reproducing THE EXACT
PRODUCTION EVENT from bot-diagnostic (3).log (2026-09-25 12:03:37):

    VC_JOIN_ALL_TARGET_ACCOUNT_SELECTED chat_id=1875192287
        account=acc_918335829278 rank=cursor:6 of 2 eligible   ← dispatch
    VC_JOIN_SKIPPED_ALREADY_OWNED owner=acc_919006065076
        requester=acc_918335829278                              ← the gate
    VCTransportError: Chat 1875192287 is already joined by
        account acc_919006065076; one-group-one-account invariant (v99.06).
    VC_JOIN_ALL_TARGET_FAILURE reason=transport_error          ← the bug
    JOIN_ALL_BREAKER failure recorded: VCTransportError x1/3    ← the harm
    VC_COORDINATOR_OP_FAILED op=join recoverable=True

The owner (acc_919006065076, J=18/F=1 in the SAME heartbeat census) is
one of THIS bot's own cluster accounts — the Join-All requester is the
BOT, not the individual cursor-selected dispatch account.  v99.11.1's
classifier compared owner == dispatch account only, so this production
condition was classified "different/unknown owner" → conflict semantics
→ transport failure → breaker → coordinator failure → re-dispatch next
run (the same chats re-failed at 12:03:37, 12:23:58, 12:36:09).

The v99.11.2 seam under test (the exact production worker boundary):

    Join-All target → dispatch (own cluster account, cursor rotation)
        → run_vc_join v99.06 gate raises the production VCTransportError
        → the REAL worker's except-VCTransportError handler
        → _v9911_classify_already_joined_exc (owner evidence)
        → v99.11.2 owner-scope resolution (cluster registry membership)
        → convergence BEFORE failure accounting
        → breaker accounting (must NOT record) + coordinator completion

Cases:
    CONV-CLUSTER-OWNED   — the EXACT production event: owner is the OTHER
                           own cluster account (≠ dispatch).  Expected:
                           idempotent success (result=already_joined,
                           breaker failures UNCHANGED + CLOSED, registry
                           joined UNDER THE OWNER, coordinator JOINED, no
                           duplicate transport, native join never ran).
    CONV-SAME-ACCOUNT    — owner == the dispatching account (the v99.11.1
                           case, preserved) + the v99.11.2 unified marker.
    CONV-DIFF-ACCOUNT    — owner is FOREIGN to the bot's cluster registry
                           (Case C): conflict semantics RETAINED (failed
                           result + breaker failure + RECOVERING state).
    CONV-UNKNOWN-OWNER   — the exception signature with NO parseable owner
                           (Case D): conservative conflict RETAINED.
    CONV-STORM           — the production storm (FIVE consecutive
                           cluster-owned already-joined races — the exact
                           sequence that drove CLOSED→OPEN at threshold=3
                           on 2026-09-25 12:03:37→12:04:30) stays CLOSED.
    CONV-GENUINE-TRANSPORT — an unrelated genuine VCTransportError (Case F)
                           still increments the breaker (over-broad-fix
                           guard).
    CONV-WRAPPED         — a VCTransportError SUBCLASS carrying the exact
                           production message (Case G): the semantic
                           survives type normalization → convergence.

Exit code = number of failed cases; each case prints
``CASE <id>: PASS|FAIL — detail``.
"""
from __future__ import annotations

import asyncio
import os
import sys
import types

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import _v9810_fastpath_driver as FP  # noqa: E402

MARKED = FP.MARKED_BASE
# The five PRODUCTION chat ids from the 2026-09-25 12:03:37→12:04:30
# breaker-opening sequence (bot-diagnostic (3).log lines 2762-3256).
RAW_P1 = 1875192287
RAW_P2 = 3975105162
RAW_P3 = 2144563093
RAW_P4 = 3758624369
RAW_P5 = 2333937461
RAW = FP.RAW

# An owner FOREIGN to the harness cluster registry ({acc_A, acc_B}) —
# the different-account conflict case (Case C).  (The v99.11.1 driver
# used "acc_919006065076" here; in PRODUCTION that id is one of the
# bot's OWN accounts — which is exactly why the v99.11.1 test world
# never exercised the production condition.)
FOREIGN_OWNER = "acc_777777777777"


def _prod_error(vc, marked_chat: int, owner: str):
    """The EXACT production exception text (v99.06 gate signature)."""
    return vc.VCTransportError(
        f"Chat {marked_chat} is already joined by account {owner}; "
        f"one-group-one-account invariant (v99.06).")


def _prod_error_unparsed_owner(vc, marked_chat: int):
    """Case D: the signature is present but the owner token is absent —
    the classifier parses owner="" (unknown) → conservative conflict."""
    return vc.VCTransportError(
        f"Chat {marked_chat} is already joined by account ; "
        f"one-group-one-account invariant (v99.06).")


def _genuine_error(vc, marked_chat: int):
    """Case F: a genuine unrelated transport failure (NO already-joined
    signature) — must still increment the breaker."""
    return vc.VCTransportError(
        f"PyTgCalls join failed: connection reset by peer "
        f"(caused by JoinGroupCallRequest chat={marked_chat})")


def _patch_race_join(vc, w, owner_for, seen: list, error_fn=None,
                     container: str = "other"):
    """Replace every backend's ``join`` with the production race boundary.

    When the worker dispatches the join for the race chat, the patched
    boundary FIRST flips the backend state to joined (the concurrent
    convergence: container object + ownership map — exactly what
    ``_vc_group_owner`` resolves ``source=active_backend`` from), THEN
    raises the exact production already-joined VCTransportError.  The
    native join_group_call is NEVER invoked (the production gate fires
    before any native allocation — zero RPCs, no duplicate transport).

    ``container``: "other" — the convergence lands on the OWNER-side
    backend (the production cluster-owned case: dispatch acc_A, owner
    acc_B's backend holds the chat); "self" — the dispatched backend
    itself converges (the v99.11.1 same-account race).
    """
    _err = error_fn or (lambda marked: None)

    def _patch(backend):
        async def _race_join(chat_id, call_id=0, access_hash=0,
                             muted=True, **kw):
            marked = MARKED - chat_id if chat_id > 0 else int(chat_id)
            owner = owner_for(backend)
            if container == "other" and owner in ("acc_A", "acc_B"):
                # (2a) the OTHER own cluster account's backend now holds
                # the chat — the production convergence (registry/
                # active_backend, owner=acc_919006065076 while the
                # cursor dispatched acc_918335829278).
                owner_be = w.b_b if owner != "acc_B" else w.a_b
            else:
                # (2b) the dispatched backend itself (the v99.11.1 race
                # shape; also the foreign/unknown-owner evidence shape).
                owner_be = backend
            owner_be._pytgcalls.calls[marked] = types.SimpleNamespace(
                chat_id=marked)
            vc._vc_active_join_backends_by_chat[marked] = owner_be
            seen.append((marked, owner))
            custom = _err(marked)
            if custom is not None:
                raise custom
            # (3) the exact production exception at the join boundary.
            raise _prod_error(vc, marked, owner)

        backend.join = _race_join

    for b in (w.global_b, w.a_b, w.b_b):
        _patch(b)


def _patch_race_join_wrapped(vc, w, owner_for, seen: list):
    """Case G: the exception is a VCTransportError SUBCLASS (the wrapped
    type) carrying the exact production message — the semantic must
    survive type normalization."""
    class _ProdWrappedJoinError(vc.VCTransportError):
        pass

    def _patch(backend):
        async def _race_join(chat_id, call_id=0, access_hash=0,
                             muted=True, **kw):
            marked = MARKED - chat_id if chat_id > 0 else int(chat_id)
            owner = owner_for(backend)
            owner_be = w.b_b if owner != "acc_B" else w.a_b
            owner_be._pytgcalls.calls[marked] = types.SimpleNamespace(
                chat_id=marked)
            vc._vc_active_join_backends_by_chat[marked] = owner_be
            seen.append((marked, owner))
            raise _ProdWrappedJoinError(
                f"Chat {marked} is already joined by account {owner}; "
                f"one-group-one-account invariant (v99.06).")

        backend.join = _race_join

    for b in (w.global_b, w.a_b, w.b_b):
        _patch(b)


def _seed_registry_unknown(vc, raw: int):
    """The race target's pre-state: registry=unknown, NO container
    object (the snapshot classifies it ELIGIBLE for join)."""
    rec = vc.VCParticipationState(
        chat_id=raw, state="unknown", request_accepted=False,
        intentional=True, locally_tracked=False, account_id="")
    vc._vc_participations[raw] = rec


def _other_cluster_owner(vc, backend):
    """The owner the production error names: the OTHER own cluster
    account (≠ the dispatching backend's account) — the exact
    production condition (owner=acc_919006065076 while the cursor
    dispatched acc_918335829278)."""
    aid = vc._vc_effective_account_id(
        str(getattr(backend, "_account_id", "") or "global"))
    return "acc_B" if aid != "acc_B" else "acc_A"


async def case_cluster_owned(vc):
    """THE EXACT PRODUCTION EVENT (12:03:37) — owner = other own cluster
    account, dispatch = cursor-selected account, gate raise, worker
    boundary, breaker accounting, coordinator completion."""
    w = await FP.reset_world(vc)
    FP.seed_group(RAW, title="CONV-CLUSTER", call_id=-555, call_ah=7777)
    _seed_registry_unknown(vc, RAW)
    vc._vc_join_all_state["run_id"] = "conv_cluster"

    breaker_before = dict(vc._vc_join_all_breaker._failures)

    seen: list = []
    _patch_race_join(vc, w, lambda b: _other_cluster_owner(vc, b), seen)
    terminal = await FP.run_worker(vc)

    breaker = vc._vc_join_all_breaker
    failures = dict(breaker._failures)
    breaker_state = breaker.state.value
    result = vc._vc_join_all_state["results"].get(RAW, {})
    progress = vc._vc_join_all_state["progress"]
    rec = await vc.vc_registry_get(RAW)
    coord_state = vc.get_vc_coordinator().get_state(RAW)
    race_seen = [s for s in seen if s[0] in (MARKED - RAW, RAW)]
    containers = [
        k for b in (w.global_b, w.a_b, w.b_b)
        for k in b._pytgcalls.calls if k in (MARKED - RAW, RAW)
    ]
    native_ran = any(
        b._pytgcalls.api_log for b in (w.global_b, w.a_b, w.b_b))
    ok = (
        terminal in ("completed",)
        and len(race_seen) == 1
        and race_seen[0][1] in ("acc_A", "acc_B")
        and result.get("state") == "already_joined"
        and failures == breaker_before == {}
        and breaker_state == "closed"
        and progress.get("already_joined", 0) == 1
        and progress.get("failed", 0) == 0
        and rec is not None and rec.state == "joined"
        and rec.request_accepted is True
        and rec.account_id == race_seen[0][1]  # the OWNER keeps ownership
        and coord_state.value == "joined"
        and len(containers) == 1  # NO duplicate native transport
        and not native_ran  # native join never ran (zero RPCs)
    )
    detail = (f"terminal={terminal} result={result.get('state')} "
              f"failures={failures} breaker={breaker_state} "
              f"coord={coord_state.value} "
              f"progress_aj={progress.get('already_joined')} "
              f"prog_failed={progress.get('failed')} "
              f"registry={None if rec is None else rec.state}/"
              f"{None if rec is None else rec.account_id} "
              f"owner_seen={race_seen} containers={containers}")
    return ok, detail


async def case_same_account(vc):
    """Case A — the v99.11.1 same-account race (preserved) + the
    v99.11.2 unified convergence marker."""
    w = await FP.reset_world(vc)
    FP.seed_group(RAW, title="CONV-SAME", call_id=-555, call_ah=7777)
    _seed_registry_unknown(vc, RAW)
    vc._vc_join_all_state["run_id"] = "conv_same"

    breaker_before = dict(vc._vc_join_all_breaker._failures)
    seen: list = []

    def owner_for(backend):
        return vc._vc_effective_account_id(
            str(getattr(backend, "_account_id", "") or "global"))

    _patch_race_join(vc, w, owner_for, seen, container="self")
    terminal = await FP.run_worker(vc)

    breaker = vc._vc_join_all_breaker
    failures = dict(breaker._failures)
    breaker_state = breaker.state.value
    result = vc._vc_join_all_state["results"].get(RAW, {})
    progress = vc._vc_join_all_state["progress"]
    rec = await vc.vc_registry_get(RAW)
    coord_state = vc.get_vc_coordinator().get_state(RAW)
    ok = (
        terminal in ("completed",)
        and result.get("state") == "already_joined"
        and failures == breaker_before == {}
        and breaker_state == "closed"
        and progress.get("already_joined", 0) == 1
        and progress.get("failed", 0) == 0
        and rec is not None and rec.state == "joined"
        and coord_state.value == "joined"
    )
    detail = (f"terminal={terminal} result={result.get('state')} "
              f"failures={failures} breaker={breaker_state} "
              f"coord={coord_state.value}")
    return ok, detail


async def case_diff_account(vc):
    """Case C — the owner is FOREIGN to the cluster registry: conflict
    semantics RETAINED (failure + breaker + RECOVERING coordinator)."""
    w = await FP.reset_world(vc)
    FP.seed_group(RAW, title="CONV-DIFF", call_id=-555, call_ah=7777)
    _seed_registry_unknown(vc, RAW)
    vc._vc_join_all_state["run_id"] = "conv_diff"

    breaker_before = dict(vc._vc_join_all_breaker._failures)
    seen: list = []
    _patch_race_join(vc, w, lambda backend: FOREIGN_OWNER, seen)
    terminal = await FP.run_worker(vc)

    breaker = vc._vc_join_all_breaker
    failures = dict(breaker._failures)
    breaker_state = breaker.state.value
    result = vc._vc_join_all_state["results"].get(RAW, {})
    progress = vc._vc_join_all_state["progress"]
    coord_state = vc.get_vc_coordinator().get_state(RAW)
    ok = (
        terminal in ("completed",)
        and result.get("state") == "failed"
        # The breaker DID record the failure (conflict semantics).
        and any(v >= 1 for v in failures.values())
        and sum(failures.values()) == sum(breaker_before.values()) + 1
        and progress.get("failed", 0) >= 1
        and progress.get("already_joined", 0) == 0
        and coord_state.value in ("recovering", "failed")
    )
    detail = (f"terminal={terminal} result={result.get('state')} "
              f"failures={failures} breaker={breaker_state} "
              f"coord={coord_state.value} "
              f"progress_aj={progress.get('already_joined')} "
              f"prog_failed={progress.get('failed')}")
    return ok, detail


async def case_unknown_owner(vc):
    """Case D — the signature with NO parseable owner: conservative
    conflict RETAINED (never guessed into a convergence)."""
    w = await FP.reset_world(vc)
    FP.seed_group(RAW, title="CONV-UNKNOWN", call_id=-555, call_ah=7777)
    _seed_registry_unknown(vc, RAW)
    vc._vc_join_all_state["run_id"] = "conv_unknown"

    breaker_before = dict(vc._vc_join_all_breaker._failures)
    seen: list = []
    _patch_race_join(
        vc, w, lambda backend: "",
        seen, error_fn=lambda marked: _prod_error_unparsed_owner(vc, marked))
    terminal = await FP.run_worker(vc)

    breaker = vc._vc_join_all_breaker
    failures = dict(breaker._failures)
    result = vc._vc_join_all_state["results"].get(RAW, {})
    progress = vc._vc_join_all_state["progress"]
    ok = (
        terminal in ("completed",)
        and result.get("state") == "failed"
        and any(v >= 1 for v in failures.values())
        and sum(failures.values()) == sum(breaker_before.values()) + 1
        and progress.get("failed", 0) >= 1
        and progress.get("already_joined", 0) == 0
    )
    detail = (f"terminal={terminal} result={result.get('state')} "
              f"failures={failures} progress={progress}")
    return ok, detail


async def case_storm(vc):
    """Case E — the production storm: FIVE consecutive cluster-owned
    already-joined races (the exact 12:03:37→12:04:30 sequence that
    drove the breaker CLOSED→OPEN at threshold=3) stays CLOSED and
    completes — every event an idempotent success."""
    w = await FP.reset_world(vc)
    raws = (RAW_P1, RAW_P2, RAW_P3, RAW_P4, RAW_P5)
    titles = ("STORM-P1", "STORM-P2", "STORM-P3", "STORM-P4", "STORM-P5")
    for raw, title in zip(raws, titles):
        FP.seed_group(raw, title=title, call_id=-558, call_ah=7780)
        _seed_registry_unknown(vc, raw)
    vc._vc_join_all_state["run_id"] = "conv_storm"

    breaker_before = dict(vc._vc_join_all_breaker._failures)
    seen: list = []
    _patch_race_join(vc, w, lambda b: _other_cluster_owner(vc, b), seen)
    terminal = await FP.run_worker(vc)

    breaker = vc._vc_join_all_breaker
    failures = dict(breaker._failures)
    breaker_state = breaker.state.value
    progress = vc._vc_join_all_state["progress"]
    results = vc._vc_join_all_state["results"]
    coord = vc.get_vc_coordinator()
    coord_states = {r: coord.get_state(r).value for r in raws}
    ok = (
        terminal in ("completed",)
        and failures == breaker_before == {}
        and breaker_state == "closed"
        and progress.get("already_joined", 0) == len(raws)
        and progress.get("failed", 0) == 0
        and all(results.get(r, {}).get("state") == "already_joined"
                for r in raws)
        and all(s == "joined" for s in coord_states.values())
        and len(seen) == len(raws)
    )
    detail = (f"terminal={terminal} failures={failures} "
              f"breaker={breaker_state} seen={len(seen)} "
              f"progress_aj={progress.get('already_joined')} "
              f"prog_failed={progress.get('failed')} "
              f"coord={coord_states}")
    return ok, detail


async def case_genuine_transport(vc):
    """Case F — a genuine unrelated VCTransportError still increments
    the breaker (the over-broad-fix guard: NOT every VCTransportError
    becomes a success)."""
    w = await FP.reset_world(vc)
    FP.seed_group(RAW, title="CONV-GENUINE", call_id=-555, call_ah=7777)
    _seed_registry_unknown(vc, RAW)
    vc._vc_join_all_state["run_id"] = "conv_genuine"

    breaker_before = dict(vc._vc_join_all_breaker._failures)
    seen: list = []
    _patch_race_join(
        vc, w, lambda backend: "",
        seen, error_fn=lambda marked: _genuine_error(vc, marked),
        container="self")
    terminal = await FP.run_worker(vc)

    breaker = vc._vc_join_all_breaker
    failures = dict(breaker._failures)
    breaker_state = breaker.state.value
    result = vc._vc_join_all_state["results"].get(RAW, {})
    progress = vc._vc_join_all_state["progress"]
    ok = (
        terminal in ("completed",)
        and result.get("state") == "failed"
        and sum(failures.values()) == sum(breaker_before.values()) + 1
        and breaker_state == "closed"  # x1/3 — counted but not open
        and progress.get("failed", 0) >= 1
        and progress.get("already_joined", 0) == 0
    )
    detail = (f"terminal={terminal} result={result.get('state')} "
              f"failures={failures} breaker={breaker_state} "
              f"prog_failed={progress.get('failed')}")
    return ok, detail


async def case_wrapped(vc):
    """Case G — a VCTransportError SUBCLASS carrying the production
    message (the wrapped-type seam): the semantic survives type
    normalization → idempotent convergence, breaker unchanged."""
    w = await FP.reset_world(vc)
    FP.seed_group(RAW, title="CONV-WRAPPED", call_id=-555, call_ah=7777)
    _seed_registry_unknown(vc, RAW)
    vc._vc_join_all_state["run_id"] = "conv_wrapped"

    breaker_before = dict(vc._vc_join_all_breaker._failures)
    seen: list = []
    _patch_race_join_wrapped(vc, w, lambda b: _other_cluster_owner(vc, b),
                             seen)
    terminal = await FP.run_worker(vc)

    breaker = vc._vc_join_all_breaker
    failures = dict(breaker._failures)
    breaker_state = breaker.state.value
    result = vc._vc_join_all_state["results"].get(RAW, {})
    progress = vc._vc_join_all_state["progress"]
    rec = await vc.vc_registry_get(RAW)
    coord_state = vc.get_vc_coordinator().get_state(RAW)
    ok = (
        terminal in ("completed",)
        and result.get("state") == "already_joined"
        and failures == breaker_before == {}
        and breaker_state == "closed"
        and progress.get("already_joined", 0) == 1
        and progress.get("failed", 0) == 0
        and rec is not None and rec.state == "joined"
        and coord_state.value == "joined"
    )
    detail = (f"terminal={terminal} result={result.get('state')} "
              f"failures={failures} breaker={breaker_state} "
              f"coord={coord_state.value}")
    return ok, detail


async def case_unit_helper_membership(vc):
    """§B — the cluster-membership helper's unit semantics (through the
    imported REAL module; the harness cluster registry = {acc_A, acc_B})."""
    await FP.reset_world(vc)  # populates GLOBAL_CLUSTER.clients
    checks = [
        # Positive: own cluster accounts.
        ("acc_A", True),
        ("acc_B", True),
        # Negative: foreign account (the Case C owner).
        (FOREIGN_OWNER, False),
        # Negative: the v99.11.1 test-world foreign id (an OWN account
        # in production — the exact divergence this suite repairs).
        ("acc_919006065076", False),
        # Negative: empty / None / dunder registry keys.
        ("", False),
        (None, False),
        ("__meta", False),
    ]
    results = [
        (owner, vc._v9912_owner_is_own_cluster_account(owner))
        for owner, _ in checks
    ]
    ok = all(
        got == want
        for (owner, want), (_, got) in zip(checks, results)
    ) and callable(vc._v9912_owner_is_own_cluster_account)
    detail = f"results={results}"
    return ok, detail


async def case_unit_helper_never_raises(vc):
    """§B — the helper NEVER raises: a broken/unavailable cluster
    registry degrades to False (conflict semantics — ownership is
    never guessed)."""
    await FP.reset_world(vc)
    cluster = FP.GLOBAL_CLUSTER
    orig = cluster.list_accounts
    try:
        def _boom():
            raise RuntimeError("cluster registry unavailable")
        cluster.list_accounts = _boom
        v1 = vc._v9912_owner_is_own_cluster_account("acc_A")
        cluster.list_accounts = lambda: None
        v2 = vc._v9912_owner_is_own_cluster_account("acc_A")
        cluster.list_accounts = lambda: [{"no_account_id": 1}, "junk", 5]
        v3 = vc._v9912_owner_is_own_cluster_account("acc_A")
        ok = (v1 is False and v2 is False and v3 is False)
        detail = f"raising={v1} none={v2} junk={v3}"
        return ok, detail
    finally:
        cluster.list_accounts = orig


CASES = [
    ("CONV-CLUSTER-OWNED", case_cluster_owned),
    ("CONV-SAME-ACCOUNT", case_same_account),
    ("CONV-DIFF-ACCOUNT", case_diff_account),
    ("CONV-UNKNOWN-OWNER", case_unknown_owner),
    ("CONV-STORM", case_storm),
    ("CONV-GENUINE-TRANSPORT", case_genuine_transport),
    ("CONV-WRAPPED", case_wrapped),
    ("UNIT-HELPER-MEMBERSHIP", case_unit_helper_membership),
    ("UNIT-HELPER-NEVER-RAISES", case_unit_helper_never_raises),
]


def main() -> int:
    async def _run():
        vc = FP.import_voicechat()
        failed = 0
        for case_id, fn in CASES:
            try:
                ok, detail = await fn(vc)
            except Exception as exc:  # noqa: BLE001
                ok, detail = False, f"EXC {type(exc).__name__}: {exc}"
            status = "PASS" if ok else "FAIL"
            print(f"CASE {case_id}: {status} — {detail}")
            if not ok:
                failed += 1
        return failed

    failed = asyncio.run(_run())
    print(f"SUMMARY: {len(CASES) - failed}/{len(CASES)} cases passed")
    return failed


if __name__ == "__main__":
    sys.exit(main())
