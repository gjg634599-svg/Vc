"""v98.12 — PRODUCTION HARDENING forensic regression driver.

Loads the REAL ``mediagrab_bot/mtproto_generation.py`` (stdlib-only deps —
direct file import) and EXTRACTS-EXECS the REAL voicechat.py functions
(``_vc_record_verify_evidence``, ``_vc_call_gone_evidence_check``,
``_vc_telegram_call_still_valid``, ``_vc_reconnect_account``) with a
stubbed dependency namespace — the same loader philosophy as the
v98.09/v98.10/v98.11 drivers (no fake module bodies: the ACTUAL shipped
source is under test).

PROMPT 5 (v98.12) §30 matrix coverage at the driver level:

  V3  proxy client identity / stable account ids        (C1)
  V16 Account A VC ownership — verify via A             (C2, C3)
  V17 Account B VC ownership — verify via B             (C2, C3)
  V18 wrong-account verification must not destroy B     (C3, C4)
  V19 verification timeout → preserve                   (C4)
  V20 call-gone race (stale identity) → refresh/preserve (C5, C6, C7)
  V21 stale-container race — strong-evidence gate       (C8 source)
  V24 concurrent join → single-flight reconnect          (C9)
  V26 reconnect during verification                      (C4, C10)
  V28 account reconnect isolation                        (C11)
  V29 reconnect exhaustion recovery (long backoff)       (C10, C12)
  V32 deployment identity (version + stamp contract)     (C13 source)
  V10/V11 no-evidence no-rotation (v98.11 preserved)     (C14 source)

Every case prints ``CASE <id>: PASS|FAIL — detail``; exit code = number of
failed cases.
"""
from __future__ import annotations

import asyncio
import importlib.util
import ast
import logging
import sys
import time
import types
from pathlib import Path
from typing import Any, Optional

_SRC = Path(__file__).resolve().parent.parent / "mediagrab_bot"
_VC = (_SRC / "voicechat.py").read_text(encoding="utf-8")
# v99.09 test maintenance: the verify_joined signature pin
# (chat_id, *, _v9909_delegated=False) — keyword-only guard
# param, POSITIONAL chat_id unchanged; contracts unchanged.

_GEN = _SRC / "mtproto_generation.py"

logging.basicConfig(level=logging.DEBUG, stream=sys.stdout,
                    format="%(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("v9812drv")

CASES: list[tuple[str, Any]] = []


def case(fn):
    CASES.append((fn.__name__, fn))
    return fn


# ---------------------------------------------------------------------------
# 1. Load mtproto_generation as a REAL module (stdlib-only imports).
# ---------------------------------------------------------------------------
def _load_generation_module():
    spec = importlib.util.spec_from_file_location("v9812_mtgen", str(_GEN))
    mod = importlib.util.module_from_spec(spec)
    sys.modules["v9812_mtgen"] = mod
    spec.loader.exec_module(mod)
    return mod


GEN = _load_generation_module()

# ---------------------------------------------------------------------------
# 2. Fake telethon modules (not installed in the test environment — the
#    production import guards make this a supported shape).
# ---------------------------------------------------------------------------
class GroupcallInvalidError(Exception):
    pass


class FloodWaitError(Exception):
    def __init__(self, seconds: int = 30):
        super().__init__(f"Too many requests (retry after {s}")
        self.seconds = seconds


class RPCError(Exception):
    pass


def _install_fake_telethon() -> None:
    telethon = types.ModuleType("telethon")
    errors = types.ModuleType("telethon.errors")
    errors.FloodWaitError = FloodWaitError  # type: ignore[attr-defined]
    errors.RPCError = RPCError  # type: ignore[attr-defined]
    tl = types.ModuleType("telethon.tl")
    phone = types.ModuleType("telethon.tl.functions.phone")

    class GetGroupCallRequest:
        def __init__(self, call=None, limit=1):
            self.call = call
            self.limit = limit

    phone.GetGroupCallRequest = GetGroupCallRequest  # type: ignore[attr-defined]
    tl_functions = types.ModuleType("telethon.tl.functions")
    tl_types = types.ModuleType("telethon.tl.types")

    class InputGroupCall:
        def __init__(self, id=0, access_hash=0):
            self.id = id
            self.access_hash = access_hash

    tl_types.InputGroupCall = InputGroupCall  # type: ignore[attr-defined]
    telethon.errors = errors  # type: ignore[attr-defined]
    telethon.tl = tl  # type: ignore[attr-defined]
    tl.functions = tl_functions  # type: ignore[attr-defined]
    tl_functions.phone = phone  # type: ignore[attr-defined]
    tl.types = tl_types  # type: ignore[attr-defined]
    for name, mod in [
        ("telethon", telethon), ("telethon.errors", errors),
        ("telethon.tl", tl), ("telethon.tl.functions", tl_functions),
        ("telethon.tl.functions.phone", phone), ("telethon.tl.types", tl_types),
    ]:
        sys.modules.setdefault(name, mod)


_install_fake_telethon()

# ---------------------------------------------------------------------------
# 3. Extract-and-exec the REAL voicechat functions into a stub namespace.
# ---------------------------------------------------------------------------
def _extract_fn(name: str) -> ast.AsyncFunctionDef:
    tree = ast.parse(_VC)
    for node in tree.body:
        if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)) and node.name == name:
            return node
    raise AssertionError(f"function {name} not found in voicechat.py")


def _exec_fn(name: str, ns: dict[str, Any]):
    node = _extract_fn(name)
    mod = ast.Module(body=[node], type_ignores=[])
    code = compile(mod, "<voicechat-extract>", "exec")
    exec(code, ns)
    return ns[name]


# --- the shared fake world -------------------------------------------------
MARKED_BASE = -1000000000000


class FakeCalls:
    """Fake telethon 'calls container' bookkeeping (chat → call info)."""

    def __init__(self):
        self.live: dict[int, dict[str, Any]] = {}       # raw_id -> {call_id, access_hash}
        self.get_calls: list[int] = []                   # (chat_id) GetGroupCall invocations
        self.full_calls: list[int] = []                  # (raw_id) GetFullChannel detections


class FakeAccount:
    def __init__(self, aid: str, world: "World"):
        self.account_id = aid
        self.world = world
        self.connected = True
        self.groupcall_invalid_for: set[int] = set()     # call_ids that raise GroupcallInvalid

    def is_connected(self):
        return self.connected


class World:
    """Two-account production shape: global + acc_A + acc_B clients in a
    _clients registry; RPC ledger for every GetGroupCall / GetFullChannel."""

    def __init__(self):
        self.accounts = {
            "global": FakeAccount("global", self),
            "acc_A": FakeAccount("acc_A", self),
            "acc_B": FakeAccount("acc_B", self),
        }
        # raw chat id -> current call identity
        self.calls: dict[int, dict[str, int]] = {}
        # GetGroupCall(call_id, access_hash, account) → ledger + result
        self.ledger: list[tuple[str, int, int]] = []
        self.detect_ledger: list[tuple[str, int]] = []
        self.registry_calls: list[dict[str, Any]] = []
        # per-account behavior overrides
        self.groupcall_invalid: dict[tuple[str, int], bool] = {}
        self.detect_error: dict[tuple[str, int], Optional[Exception]] = {}
        self.resolve_error: dict[tuple[str, int], Optional[Exception]] = {}

    def cluster(self):
        w = self

        class Cluster:
            def get_client(self, account_id):
                return w.accounts.get(account_id)

            def get_account(self, account_id):
                return {"account_id": account_id, "user_id": hash(account_id) % 100000}

        return Cluster()

    # --- RPC fakes ---------------------------------------------------------
    async def get_group_call(self, account: str, call_id: int, access_hash: int):
        self.ledger.append((account, call_id, access_hash))
        if self.groupcall_invalid.get((account, call_id)):
            raise GroupcallInvalidError()
        # A call is "live" if any chat's CURRENT identity matches
        for raw, ident in self.calls.items():
            if ident["call_id"] == call_id and ident["access_hash"] == access_hash:
                return types.SimpleNamespace(participants_count=5)
        raise GroupcallInvalidError()

    async def detect_active_call(self, account: str, raw_id: int):
        self.detect_ledger.append((account, raw_id))
        err = self.detect_error.get((account, raw_id))
        if err is not None:
            raise err
        ident = self.calls.get(raw_id)
        if ident is None:
            return None
        return {"call_id": ident["call_id"], "access_hash": ident["access_hash"], "members": 5}


W = World()


async def _corroboration_rpc(client, req):
    """The mtproto_call_with_retry stand-in: GetGroupCall against the fake
    world. A DISCONNECTED account raises a generic ConnectionError — the
    shipped corroboration's broad handler maps that to None (UNKNOWN,
    preserved) — the §5 weak-evidence path."""
    acc = getattr(client, "account_id", "global")
    acc_obj = W.accounts.get(acc)
    if acc_obj is not None and not acc_obj.is_connected():
        raise ConnectionError("simulated disconnect during corroboration")
    return await W.get_group_call(acc, req.call.id, req.call.access_hash)


async def _fake_resolve_vc_entity(client, chat_ref, chat_id=0, access_hash=0):
    acc = getattr(client, "account_id", "global")
    raw = chat_id if chat_id > 0 else (-chat_id % 1000000000000 if chat_id < MARKED_BASE else 0)
    err = W.resolve_error.get((acc, raw))
    if err is not None:
        return {"ok": False, "error": str(err)}
    entity = types.SimpleNamespace(id=raw, access_hash=111)
    return {"ok": True, "entity": entity, "source": "cache"}


async def _fake_registry_register(chat_id, *, title=None, call_id=None,
                                  access_hash=None, request_accepted=False,
                                  state="joining", intentional=False,
                                  created_by_tour=False, account_id=None):
    W.registry_calls.append({
        "chat_id": chat_id, "call_id": call_id, "access_hash": access_hash,
        "state": state, "account_id": account_id,
    })
    return types.SimpleNamespace(chat_id=chat_id, call_id=call_id,
                                 access_hash=access_hash, state=state,
                                 account_id=account_id)


def _build_namespace() -> dict[str, Any]:
    ns: dict[str, Any] = {
        "__name__": "v9812_voicechat_extract",
        "asyncio": asyncio, "time": time, "logger": logging.getLogger("v9812.vc"),
        "Optional": Optional, "Any": Any,
        # injected production dependencies (stubs):
        "get_userbot_cluster": lambda: W.cluster(),
        "mtproto_get_client": lambda: W.accounts["global"],
        "mtproto_call_with_retry": lambda client, req: _corroboration_rpc(
            client, req),
        "resolve_vc_entity": _fake_resolve_vc_entity,
        "vc_detect_active_call": lambda client, entity: W.detect_active_call(
            getattr(client, "account_id", "global"), entity.id),
        "vc_registry_register": _fake_registry_register,
        "_vc_entity_cache": {},
        "_vc_active_join_backends_by_chat": {},
        # module-level state the functions reference:
        "_vc_last_verify_evidence": {},
        "_vc_corroboration_cache": {},
        "_VC_CORROBORATION_THROTTLE_SECONDS": 60,
        "_vc_account_reconnect_inflight": set(),
    }
    # real functions
    ns["_vc_record_verify_evidence"] = _exec_fn("_vc_record_verify_evidence", ns)
    ns["_vc_telegram_call_still_valid"] = _exec_fn("_vc_telegram_call_still_valid", ns)
    ns["_vc_call_gone_evidence_check"] = _exec_fn("_vc_call_gone_evidence_check", ns)
    ns["_vc_reconnect_account"] = _exec_fn("_vc_reconnect_account", ns)
    return ns


NS = _build_namespace()


def _owner_backend_for(aid: str):
    """A fake backend object with a stable _account_id (§8: NEVER id(client))."""
    be = types.SimpleNamespace()
    be._account_id = aid
    return be


# ---------------------------------------------------------------------------
# C1 — V3: stable account identity on the owner path
# ---------------------------------------------------------------------------
@case
async def C1_stable_owner_account_ids():
    """The owner-account resolution must yield ONLY stable identifiers
    (global / acc_<id>) — never python object ids (§8)."""
    be_b = _owner_backend_for("acc_B")
    NS["_vc_active_join_backends_by_chat"][12345] = be_b
    try:
        # verify_joined's resolution (source-contract mirror): the dict maps
        # chat → backend with a STABLE _account_id string.
        aid = getattr(NS["_vc_active_join_backends_by_chat"][12345], "_account_id", "")
        ok = aid == "acc_B" and isinstance(aid, str) and "0x" not in aid
    finally:
        NS["_vc_active_join_backends_by_chat"].clear()
    # and the cluster path resolves the account client by the same stable id
    cl = W.cluster().get_client("acc_B")
    ok = ok and getattr(cl, "account_id", "") == "acc_B"
    print(f"CASE C1: {'PASS' if ok else 'FAIL'} — owner ids stable (acc_B, no object-id leakage)")
    return ok


# ---------------------------------------------------------------------------
# C2 — V16/V17: corroboration uses the OWNER account's client
# ---------------------------------------------------------------------------
@case
async def C2_corroboration_uses_owner_client():
    """GetGroupCall must be sent via the OWNER account (§6) — the ledger
    records (account, call_id, access_hash)."""
    W.calls[777] = {"call_id": -1001, "access_hash": 222}
    for aid in ("acc_A", "acc_B"):
        res = await NS["_vc_telegram_call_still_valid"](
            777, -1001, 222, account_id=aid)
        sent_by = W.ledger[-1][0]
        ok = res is True and sent_by == aid
        if not ok:
            print(f"CASE C2: FAIL — corroborate via owner {aid}: got {res}, ledger={W.ledger[-1]}")
            return False
    W.calls.clear(); W.ledger.clear()
    print("CASE C2: PASS — corroboration sent via owner account A AND B (ledger-verified)")
    return True


# ---------------------------------------------------------------------------
# C3 — V20: the (6).log false-CALL-GONE race: stale identity → refresh
# ---------------------------------------------------------------------------
@case
async def C3_stale_identity_groupcall_invalid_refreshes():
    """THE production root cause: chat's call was REPLACED after the snapshot
    detection; corroborating the OLD identity raises GroupcallInvalid; the
    evidence check re-detects an ACTIVE call → 'refreshed' → identity
    updated (registry) → the join is preserved."""
    W.calls[888] = {"call_id": -2002, "access_hash": 333}       # the CURRENT call
    NS["_vc_entity_cache"][888] = {"entity": types.SimpleNamespace(id=888, access_hash=111)}
    be = _owner_backend_for("acc_B")
    NS["_vc_active_join_backends_by_chat"][888] = be
    try:
        ev = await NS["_vc_call_gone_evidence_check"](
            888, -999, 444, account_id="acc_B")     # -999 = the OBSOLETE identity
        reg = W.registry_calls[-1] if W.registry_calls else None
        det = W.detect_ledger[-1] if W.detect_ledger else None
        ok = (ev == "refreshed"
              and det == ("acc_B", 888)              # re-detect via the OWNER account
              and reg is not None and reg["call_id"] == -2002 and reg["state"] == "joined"
              and be._current_call_id == -2002)      # backend identity refreshed
    finally:
        NS["_vc_active_join_backends_by_chat"].clear()
        W.calls.clear(); W.detect_ledger.clear(); W.registry_calls.clear()
    print(f"CASE C3: {'PASS' if ok else 'FAIL'} — GroupcallInvalid on stale identity → refreshed (identity updated, join preserved)")
    return ok


# ---------------------------------------------------------------------------
# C4 — V18/V19: inconclusive evidence NEVER destroys (weak path)
# ---------------------------------------------------------------------------
@case
async def C4_inconclusive_recheck_preserves():
    """When the re-detect itself FAILS (timeout / RPC error), the evidence is
    WEAK — 'inconclusive' → the caller must preserve the join (§5)."""
    W.calls[999] = {"call_id": -3, "access_hash": 9}
    W.detect_error[("acc_A", 999)] = TimeoutError("simulated detect timeout")
    try:
        ev = await NS["_vc_call_gone_evidence_check"](999, -3, 9, account_id="acc_A")
        ok = ev == "inconclusive"
    finally:
        W.detect_error.clear(); W.calls.clear(); W.detect_ledger.clear()
    print(f"CASE C4: PASS — re-detect timeout → inconclusive (weak; join preserved)" if ok
          else "CASE C4: FAIL")
    return ok


# ---------------------------------------------------------------------------
# C5 — genuine call disappearance → strong negative
# ---------------------------------------------------------------------------
@case
async def C5_genuine_gone_is_strong_negative():
    """Authoritative re-detect finds NO active call → strong_negative →
    destructive recovery IS justified (the v98.05 silent-death case)."""
    W.calls.pop(555, None)                     # no active call anywhere
    NS["_vc_entity_cache"][555] = {"entity": types.SimpleNamespace(id=555, access_hash=1)}
    try:
        ev = await NS["_vc_call_gone_evidence_check"](555, -5, 6)
        ok = ev == "strong_negative"
    finally:
        W.detect_ledger.clear()
    print(f"CASE C5: {'PASS' if ok else 'FAIL'} — no active call (authoritative) → strong_negative")
    return ok


# ---------------------------------------------------------------------------
# C6 — evidence registry records account + strength (§35 observability)
# ---------------------------------------------------------------------------
@case
async def C6_evidence_registry_observability():
    NS["_vc_record_verify_evidence"](4242, outcome="unknown", strength="weak",
                                     reason="test", account_id="acc_B", call_id=-7)
    rec = NS["_vc_last_verify_evidence"].get(4242)
    ok = (rec is not None and rec["strength"] == "weak"
          and rec["account_id"] == "acc_B" and rec["call_id"] == -7
          and rec["ts"] > 0)
    # bounded: one entry per chat (overwrite semantics)
    NS["_vc_record_verify_evidence"](4242, outcome="joined", strength="strong",
                                     reason="test2", account_id="acc_B")
    ok = ok and len([k for k in NS["_vc_last_verify_evidence"] if k == 4242]) == 1
    print(f"CASE C6: {'PASS' if ok else 'FAIL'} — evidence registry: strength/account/call_id + bounded per chat")
    return ok


# ---------------------------------------------------------------------------
# C7 — the worker gate: strong_negative + fresh → recovery; weak → preserve
# (source contract: the exact gate the worker runs)
# ---------------------------------------------------------------------------
@case
async def C7_worker_gate_source_contract():
    src = _VC
    needle_gate = '_v9812_ev_strength == "strong_negative"'
    needle_fresh = "0.0 <= _v9812_ev_age <= 30.0"
    needle_preserve = 'result_state = "joined_unverified"'
    needle_reg = 'elif result_state == "joined_unverified":'
    needle_reg_state = "_reg_state = \"joined\""
    ok = all(n in src for n in (needle_gate, needle_fresh, needle_preserve,
                                needle_reg, needle_reg_state))
    # the destructive path remains reachable ONLY inside the else:
    idx = src.find(needle_preserve)
    else_idx = src.find("else:", idx)
    rec_idx = src.find("_vc_stale_container_recovery(", else_idx)
    ok = ok and 0 < idx < else_idx < rec_idx < idx + 2000
    print(f"CASE C7: {'PASS' if ok else 'FAIL'} — worker gate: weak→joined_unverified(preserve); strong+fresh→recovery")
    return ok


# ---------------------------------------------------------------------------
# C8 — V21: verify_joined wiring — account-aware + evidence-gated (source)
# ---------------------------------------------------------------------------
@case
async def C8_verify_joined_wiring_source():
    src = _VC
    idx = src.find("async def verify_joined(self, chat_id: int, *,", 4000)
    # v98.13 test maintenance: 22000 → 30000 — the v98.13 §VERIF changes
    # (join-time-gate evidence reuse + strictness markers + evidence
    # recording) grew the method; the CONTRACTS are unchanged.
    seg = src[idx:idx + 30000]     # the full method (~550 source lines)
    ok = (
        "_v9812_owner_account" in seg
        and "_vc_active_join_backends_by_chat.get" in seg
        and "account_id=_v9812_owner_account" in seg            # corroboration
        and seg.count("account_id=_v9812_owner_account") >= 2   # + participation
        and "_vc_call_gone_evidence_check(" in seg
        and "_vc_record_verify_evidence(" in seg
        and "VC_JOIN_EVIDENCE_WEAK_NEGATIVE_PRESERVED" in seg
    )
    # the identity-refresh marker lives in the helper (module scope):
    ok = ok and "VC_JOIN_IDENTITY_REFRESHED" in src
    print(f"CASE C8: {'PASS' if ok else 'FAIL'} — verify_joined: owner-account corroboration + participation + evidence gate")
    return ok


# ---------------------------------------------------------------------------
# C9 — V24: per-account reconnect single-flight (the (6).log retry storm)
# ---------------------------------------------------------------------------
@case
async def C9_account_reconnect_single_flight():
    """Two concurrent _vc_reconnect_account(acc_A) → ONE drain+connect; the
    second returns the connected-state without starting a second sequence."""
    inflight = NS["_vc_account_reconnect_inflight"]
    inflight.add("acc_A")            # simulate an in-flight reconnect
    try:
        t0 = time.monotonic()
        res = await NS["_vc_reconnect_account"]("acc_A")
        dt = time.monotonic() - t0
        # the skip path must return fast (no 10s drain + 15s connect)
        ok = res is False and dt < 2.0
    finally:
        inflight.discard("acc_A")
    # and the gate key is per-account (acc_B unaffected):
    inflight.add("acc_A")
    try:
        # acc_B reconnect proceeds into its own path (it will hit the stubbed
        # cluster import error — caught by the function's except → False,
        # but NOT by the single-flight skip).
        inflight_before = set(inflight)
        await NS["_vc_reconnect_account"]("acc_B")
        ok = ok and inflight_before == {"acc_A"}
    finally:
        inflight.clear()
    print(f"CASE C9: {'PASS' if ok else 'FAIL'} — per-account single-flight: concurrent same-account reconnects coalesce; other accounts isolated")
    return ok


# ---------------------------------------------------------------------------
# C10 — V29: reconnect TimeoutError → NETWORK_UNREACHABLE long backoff
# ---------------------------------------------------------------------------
@case
async def C10_timeout_classified_network_unreachable():
    coord = GEN.ReconnectCoordinator()
    key = "primary:/tmp/x.session"
    # simulate a failed attempt that raised TimeoutError
    gen_stub = types.SimpleNamespace(
        generation_id="g1", backend_generation=1,
        mark_failed=lambda: None, owner_token="")
    try:
        raise asyncio.TimeoutError()
    except asyncio.TimeoutError as exc:
        # replay the coordinator's except-branch logic (the ACTUAL shipped
        # code path: classify from the exception):
        coord._fail_count[key] = 1
        _v9812_is_timeout = (
            isinstance(exc, asyncio.TimeoutError)
            or type(exc).__name__ in ("TimeoutError", "ConnectTimeoutError"))
        coord._last_failure_class[key] = (
            GEN.NetworkFailureClass.NETWORK_UNREACHABLE if _v9812_is_timeout
            else GEN.NetworkFailureClass.UNKNOWN)
    # Step-3 backoff computation (the shipped _compute_backoff with the
    # recorded class):
    backoff = coord._compute_backoff(key, GEN.NetworkFailureClass.NETWORK_UNREACHABLE)
    ok = backoff >= 3.0        # 5s base ± 25% jitter → [3.75, 6.25]
    # vs the SHORT ladder (the (6).log behavior): 1s ± jitter → ~[0.75, 1.25]
    short = coord._compute_backoff(key, GEN.NetworkFailureClass.DISCONNECTED)
    ok = ok and backoff > short * 2
    # and the ladder GROWS: failure classes at count 1,2,3 → 5,10,20 (capped 60)
    coord._fail_count[key] = 3
    grown = coord._compute_backoff(key, GEN.NetworkFailureClass.NETWORK_UNREACHABLE)
    ok = ok and grown >= 15.0
    # success clears the recorded class:
    coord._last_failure_class.pop(key, None)
    ok = ok and key not in coord._last_failure_class
    print(f"CASE C10: {'PASS' if ok else 'FAIL'} — TimeoutError → NETWORK_UNREACHABLE long ladder ({backoff:.1f}s vs short {short:.1f}s; grows to {grown:.1f}s)")
    return ok


# ---------------------------------------------------------------------------
# C11 — V28: coordinator single-flight for concurrent reconnect requests
# ---------------------------------------------------------------------------
@case
async def C11_generation_single_flight():
    coord = GEN.reset_reconnect_coordinator() or GEN.ReconnectCoordinator()
    coord = GEN.ReconnectCoordinator()
    started = []

    async def reconnect_fn(gen):
        started.append(gen.generation_id)
        await asyncio.sleep(0.05)
        return True

    async def call_it():
        return await coord.request_reconnect(
            session_path="/tmp/s.session", account_id="primary",
            reconnect_fn=reconnect_fn)

    r1, r2, r3 = await asyncio.gather(call_it(), call_it(), call_it())
    ok = r1 is True and r2 is True and r3 is True and len(started) == 1
    print(f"CASE C11: {'PASS' if ok else 'FAIL'} — 3 concurrent request_reconnect → 1 reconnect_fn (single-flight)")
    return ok


# ---------------------------------------------------------------------------
# C12 — exhaustion recovery: failure counter + cached success reset
# ---------------------------------------------------------------------------
@case
async def C12_failure_count_and_success_reset():
    coord = GEN.ReconnectCoordinator()
    key = "primary:/tmp/y.session"
    async def failing_fn(gen):
        raise asyncio.TimeoutError()
    # three failing attempts
    for i in range(3):
        try:
            await coord.request_reconnect(
                session_path="/tmp/y.session", account_id="primary",
                reconnect_fn=failing_fn)
        except Exception:
            pass
    ok = coord._fail_count.get(key, 0) == 3
    ok = ok and coord._last_failure_class.get(key) is GEN.NetworkFailureClass.NETWORK_UNREACHABLE
    # a success resets
    async def ok_fn(gen):
        return True
    await coord.request_reconnect(
        session_path="/tmp/y.session", account_id="primary", reconnect_fn=ok_fn)
    ok = ok and coord._fail_count.get(key, 0) == 0
    ok = ok and key not in coord._last_failure_class
    print(f"CASE C12: {'PASS' if ok else 'FAIL'} — 3 TimeoutError failures counted+classified; success resets both")
    return ok


# ---------------------------------------------------------------------------
# C13 — V32: deployment identity (version + stamp + unit contract)
# ---------------------------------------------------------------------------
@case
async def C13_deployment_identity_contract():
    init_src = (_SRC / "__init__.py").read_text(encoding="utf-8")
    boot_src = (_SRC / "bootstrap.py").read_text(encoding="utf-8")
    # v99.11.1 release bump: tracks CURRENT (the targeted production
    # remediation patch — see PATCH_MANIFEST_v99.11.1.txt). v99.11: the
    # stability-persistence
    # release — resource admission guard, leave policy, crash-loop guard).
    ok = '__bot_version__ = "v99.11.2"' in init_src
    ok = ok and 'DEPLOYMENT_IDENTITY version={_v9812_pkg_version}' in boot_src
    ok = ok and "BUILD_IDENTITY_MISMATCH" in boot_src and "BUILD_IDENTITY_VERIFIED" in boot_src
    ok = ok and "build_stamp.json" in boot_src
    ok = ok and "supervisor=" in boot_src and "started_at=" in boot_src
    # the stamper tool exists and stamps the same module set
    stamp_src = (Path(__file__).resolve().parent.parent / "tools" / "stamp_build.py").read_text(encoding="utf-8")
    ok = ok and "mtproto_generation.py" in stamp_src and "build_stamp.json" in stamp_src
    # the systemd unit keeps the 24/7 contract
    unit = (Path(__file__).resolve().parent.parent / "deploy" / "mediagrab.service").read_text(encoding="utf-8")
    ok = ok and "Restart=always" in unit and "RestartSec=10" in unit and "StartLimitIntervalSec=0" in unit
    print(f"CASE C13: {'PASS' if ok else 'FAIL'} — version v99.03 + build stamp + supervisor identity + systemd 24/7 contract")
    return ok


# ---------------------------------------------------------------------------
# C14 — watchdog adaptive cadence + evidence model state machine (source)
# ---------------------------------------------------------------------------
@case
async def C14_watchdog_and_state_machine_source():
    mt_src = (_SRC / "mtproto.py").read_text(encoding="utf-8")
    ok = ("_v9812_wd_interval = 30.0 if _v9812_wd_consec_disc >= 6 else 10.0" in mt_src
          and "MTPROTO_WATCHDOG_RECOVERED" in mt_src)
    gen_src = _GEN.read_text(encoding="utf-8")
    ok = ok and "_last_failure_class" in gen_src and "NETWORK_UNREACHABLE" in gen_src
    # §7 state machine vocabulary present in the worker:
    ok = ok and "joined_unverified" in _VC and "VC_JOIN_ALL_TARGET_VERIFY_DEFERRED" in _VC
    print(f"CASE C14: {'PASS' if ok else 'FAIL'} — watchdog adaptive cadence + §7 VERIFY_DEFERRED state + failure-class recording")
    return ok


# ---------------------------------------------------------------------------
# C15 — V10/V11: v98.11 resolver fixes PRESERVED (regression guard)
# ---------------------------------------------------------------------------
@case
async def C15_v9811_resolver_fixes_preserved():
    mt_src = (_SRC / "mtproto.py").read_text(encoding="utf-8")
    preserved = [
        "ENTITY_RESOLVE_LOCAL_MISS",       # S4/S5 LOCAL_MISS marker
        "_VC_RES_LOCAL_MISS",              # the class constant
        "rotation_probe",                  # S6 typed fast recovery
        "_vc_client_scope",                # S9 stable scopes
        "ENTITY_RESOLVE_HASH_REFRESH",     # S6 hash refresh marker
        "dialogs_index",                   # S24 dialogs index
        "ENTITY_RESOLVE_TYPE_KNOWN",       # S6 typed probe marker
    ]
    missing = [m for m in preserved if m not in mt_src]
    ok = not missing
    print(f"CASE C15: {'PASS' if ok else 'FAIL'} — v98.11 resolver markers intact (missing: {missing})")
    return ok


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
async def main() -> int:
    failed = 0
    for name, fn in CASES:
        try:
            ok = await fn()
            if not ok:
                failed += 1
        except Exception as exc:  # noqa: BLE001
            print(f"CASE {name}: FAIL — exception {type(exc).__name__}: {exc}")
            failed += 1
    print(f"v98.12 driver: {len(CASES) - failed}/{len(CASES)} cases pass")
    return failed


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
