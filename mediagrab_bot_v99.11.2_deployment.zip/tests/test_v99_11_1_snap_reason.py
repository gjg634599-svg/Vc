"""v99.11.1 FIX-2 — THE ``_v9805_snap_reason`` UnboundLocalError SUITE.

PRODUCTION EVIDENCE (the exact failure this suite locks out):

    2026-09-22/23 diagnostic logs, 51× (7 + 26 + 18 across the three
    files), all at ``_vc_join_all_active_worker:13695``:

        VC_SNAPSHOT_STALE_RECOVERY_ERROR chat_id=<id>
        exc=UnboundLocalError: cannot access local variable
        '_v9805_snap_reason' where it is not associated with a value
        (v98.05 FIX-DD)

    Reproduced chats include 2207237797, 2087656656, 1922822605,
    1070871253, 1741660162, 1993596337, 2592942176 — every occurrence
    directly follows a VC_ENTITY_DISCOVERED line: the Join-All snapshot
    loop iterating DISCOVERY targets whose registry record is ABSENT
    (``rec is None`` → ``_registry_state_for_skip = "not_registered"``).

ROOT CAUSE: v98.05 FIX-DD assigned ``_v9805_snap_reason`` only inside
``if _registry_state_for_skip in ("left", "unknown", recovery_pending)``
while the v99.11 P0 evidence split made the recovery call the ``else``
branch of ``state in ("unknown", recovery_pending)`` — reachable for
ANY other state.  ``"not_registered"`` / ``"failed"`` reached the
recovery call with the local never assigned → UnboundLocalError → the
broad ``except Exception`` logged it as a recovery error → registry set
to recovery_pending → the same chat re-entered the broken path every
cycle (the interlocked loop that also fed FIX-1's FD growth and FIX-3's
breaker storm).

THE v99.11.1 FIX (total-function state machine):
  * the reason is DERIVED from the validated state by a total
    conditional expression with an explicit ``else ""`` arm — assigned
    UNCONDITIONALLY, before any branch that can consume it;
  * the recovery call is reachable ONLY via
    ``elif _registry_state_for_skip == "left":``;
  * unknown / recovery_pending → PRESERVE (the v99.11 P0 weak-evidence
    deny, unchanged);
  * any other state (not_registered, failed, future states) → the NEW
    explicit preserve branch: VC_SNAPSHOT_STALE_UNEXPECTED_STATE, no
    destructive recovery, target stays eligible for re-join.

MANDATORY INVARIANTS (per the remediation mission):
  1. no UnboundLocalError is reachable for ANY registry state;
  2. UNKNOWN remains preserve/no-leave;
  3. RECOVERY_PENDING remains preserve/no-leave;
  4. validated LEFT can perform the intended stale recovery;
  5. invalid/unexpected registry state never triggers destructive
     recovery.
"""

from __future__ import annotations

import ast
import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

_SRC_DIR = Path(__file__).resolve().parents[1] / "mediagrab_bot"
_VC_PATH = _SRC_DIR / "voicechat.py"
_VC_SRC = _VC_PATH.read_text(encoding="utf-8")
_VC_TREE = ast.parse(_VC_SRC)

_VC_STATE_RECOVERY_PENDING = "recovery_pending"


def _find_function(tree: ast.Module, name: str) -> ast.AsyncFunctionDef | None:
    for node in ast.walk(tree):
        if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)) \
                and node.name == name:
            return node
    return None


def _worker_node() -> ast.AsyncFunctionDef:
    fn = _find_function(_VC_TREE, "_vc_join_all_active_worker")
    assert fn is not None, "_vc_join_all_active_worker not found"
    return fn


class TestSnapReasonNoUnboundLocal(unittest.TestCase):
    """The name ``_v9805_snap_reason`` can never be read unbound."""

    def test_b1_assignment_is_unconditional_and_precedes_use(self):
        """AST dominance: the single Assign of ``_v9805_snap_reason`` is
        guarded ONLY by conditionals that ALSO guard every Load of the
        name (no path reaches a Load without having passed the Assign —
        the v98.05 shape: Assign nested inside an ``if`` while the Load
        sat in a sibling ``else``)."""
        fn = _worker_node()
        parent_map: dict[int, ast.AST] = {}
        for parent in ast.walk(fn):
            for child in ast.iter_child_nodes(parent):
                parent_map[id(child)] = parent

        def _guards(node: ast.AST) -> list[ast.AST]:
            """The If/Try/With chain enclosing ``node`` (innermost first)."""
            out = []
            cur: ast.AST = node
            while id(cur) in parent_map:
                p = parent_map[id(cur)]
                if isinstance(p, (ast.If, ast.Try, ast.With, ast.AsyncWith,
                                  ast.ExceptHandler)):
                    out.append(p)
                if isinstance(p, (ast.AsyncFunctionDef, ast.FunctionDef)):
                    break
                cur = p
            return out

        assigns: list[ast.Assign] = []
        loads: list[ast.Name] = []
        for node in ast.walk(fn):
            if isinstance(node, ast.Assign) and any(
                    isinstance(t, ast.Name) and t.id == "_v9805_snap_reason"
                    for t in node.targets):
                assigns.append(node)
            elif isinstance(node, ast.Name) and \
                    node.id == "_v9805_snap_reason" and \
                    isinstance(node.ctx, ast.Load):
                loads.append(node)
        self.assertEqual(
            len(assigns), 1,
            "exactly ONE assignment of _v9805_snap_reason expected")
        self.assertGreaterEqual(len(loads), 1,
                                "the recovery call must still consume the reason")
        assign_guards = [id(g) for g in _guards(assigns[0])]
        for load in loads:
            self.assertLess(
                assigns[0].lineno, load.lineno,
                "assignment must precede every use (line order)")
            # Every conditional guarding the ASSIGN must also guard the
            # LOAD — the load can never execute on a path where the
            # assignment was skipped.
            load_guard_ids = {id(g) for g in _guards(load)}
            for gid in assign_guards:
                self.assertIn(
                    gid, load_guard_ids,
                    "a conditional guards the assignment but NOT this "
                    "use — the use can execute without the assignment "
                    "(the UnboundLocalError shape)")

    def test_b2_total_function_covers_every_state(self):
        """The derived-reason expression has an explicit ``else ""`` arm:
        every registry state yields a DEFINED value (left/unknown/
        recovery_pending → their reason; ANYTHING ELSE → "")."""
        fn = _worker_node()
        found = False
        for node in ast.walk(fn):
            if isinstance(node, ast.Assign) and any(
                    isinstance(t, ast.Name) and t.id == "_v9805_snap_reason"
                    for t in node.targets):
                value = node.value
                self.assertIsInstance(
                    value, ast.IfExp,
                    "the reason must be a total conditional expression")
                # Walk the orelse chain: the outermost else must be the
                # empty-string arm (total function).
                arm = value
                depth = 0
                while isinstance(arm, ast.IfExp):
                    depth += 1
                    arm = arm.orelse
                self.assertGreaterEqual(depth, 3,
                                        "left/unknown/recovery_pending arms")
                self.assertIsInstance(arm, ast.Constant)
                self.assertEqual(arm.value, "",
                                 "the final else arm must be the empty "
                                 "string (total function)")
                found = True
        self.assertTrue(found)

    def test_b3_recovery_call_gated_on_left_only(self):
        """The ``_vc_stale_container_recovery`` call inside the snapshot
        branch is reachable ONLY through
        ``elif _registry_state_for_skip == "left":``."""
        fn = _worker_node()
        # Find the left-gated elif arm directly: the If whose test is
        # ``_registry_state_for_skip == "left"`` and whose body holds the
        # snapshot stale-container recovery call.  Then verify its
        # parent gate is the unknown/recovery_pending preserve gate.
        left_arm: ast.If | None = None
        for node in ast.walk(fn):
            if isinstance(node, ast.If):
                test_src = ast.unparse(node.test).replace(" ", "")
                if (test_src in (
                        '_registry_state_for_skip=="left"',
                        "_registry_state_for_skip=='left'")
                        and any(isinstance(n, ast.Call)
                                and isinstance(n.func, ast.Name)
                                and n.func.id == "_vc_stale_container_recovery"
                                for n in ast.walk(node))):
                    left_arm = node
                    break
        self.assertIsNotNone(
            left_arm,
            "the left-gated recovery arm not found — the recovery call "
            "must live inside elif _registry_state_for_skip == 'left':")
        # Its parent (the gate whose orelse chain contains the arm) must
        # be the unknown/recovery_pending preserve gate.
        parent_map: dict[int, ast.AST] = {}
        for parent in ast.walk(fn):
            for child in ast.iter_child_nodes(parent):
                parent_map[id(child)] = parent
        cur = left_arm
        gate: ast.If | None = None
        while id(cur) in parent_map:
            p = parent_map[id(cur)]
            if isinstance(p, ast.If):
                gate = p
                break
            cur = p
        self.assertIsNotNone(gate, "the recovery arm must be an elif of a gate")
        gate_src = ast.unparse(gate.test)
        self.assertIn("unknown", gate_src)
        self.assertTrue(
            "_VC_STATE_RECOVERY_PENDING" in gate_src
            or "recovery_pending" in gate_src)
        self.assertIn(
            "_registry_state_for_skip", gate_src)


class TestSnapReasonStateSemantics(unittest.TestCase):
    """Every state's branch semantics (the 5 mandatory assertions)."""

    def _reason_for_state(self, state: str) -> str:
        """Extract the ACTUAL total-function expression from the source
        and evaluate it for ``state`` — the test executes the shipped
        code, not a copy."""
        fn = _worker_node()
        for node in ast.walk(fn):
            if isinstance(node, ast.Assign) and any(
                    isinstance(t, ast.Name) and t.id == "_v9805_snap_reason"
                    for t in node.targets):
                expr_src = ast.unparse(node.value)
                break
        else:
            self.fail("assignment not found")
        expr_src = expr_src.replace(
            "_registry_state_for_skip", repr(state)).replace(
            "_VC_STATE_RECOVERY_PENDING", repr(_VC_STATE_RECOVERY_PENDING))
        return eval(compile(ast.parse(expr_src, "<expr>", "eval"),  # noqa: S307
                            "<expr>", "eval"))

    def test_c1_left_gets_the_left_reason(self):
        self.assertEqual(
            self._reason_for_state("left"),
            "snapshot_stale_container:left_registry")

    def test_c2_unknown_preserved_with_explicit_reason(self):
        """UNKNOWN → preserve (no leave); the reason is still derived
        (defined) — never unbound."""
        self.assertEqual(
            self._reason_for_state("unknown"),
            "snapshot_stale_container:unknown_registry")
        # The preserve branch (v99.11 P0) must remain in the source.
        self.assertIn('VC_LEAVE_DENIED_UNAUTHORIZED', _VC_SRC)
        self.assertIn('reason=SNAPSHOT_STALE_CONTAINER', _VC_SRC)
        self.assertIn('weak_evidence_', _VC_SRC)

    def test_c3_recovery_pending_preserved_with_explicit_reason(self):
        self.assertEqual(
            self._reason_for_state(_VC_STATE_RECOVERY_PENDING),
            "snapshot_stale_container:recovery_pending_registry")

    def test_c4_not_registered_defined_and_preserve_branch(self):
        """THE ACTUAL PRODUCTION STATE COMBINATION: ``rec is None`` →
        ``"not_registered"`` — the state that produced all 51
        UnboundLocalErrors.  Now: reason defined (empty), the explicit
        unexpected-state preserve branch exists, sets
        ``_backend_connected = False``, and never enters recovery."""
        self.assertEqual(self._reason_for_state("not_registered"), "")
        self.assertEqual(self._reason_for_state("failed"), "")
        # The preserve branch must set _backend_connected = False (the
        # target stays eligible for re-join, NOT already_joined) — check
        # the LOG-CALL occurrence of the marker (the last one; the first
        # occurrence sits in the explanatory comment).
        idx_marker = _VC_SRC.rfind("VC_SNAPSHOT_STALE_UNEXPECTED_STATE")
        self.assertGreater(idx_marker, 0)
        after_marker = _VC_SRC[idx_marker:idx_marker + 1400]
        self.assertIn("_backend_connected = False", after_marker)

    def test_c5_no_suppression_only_broad_catch_shape(self):
        """The fix must not be a bare ``except UnboundLocalError`` — the
        marker line for the recovery-error log keeps its diagnostic
        semantics (real recovery exceptions still land there)."""
        self.assertNotIn("except UnboundLocalError", _VC_SRC)
        self.assertIn("VC_SNAPSHOT_STALE_RECOVERY_ERROR", _VC_SRC)

    def test_c6_unexpected_state_not_destructive(self):
        """Invalid/unexpected states must not reach a destructive
        recovery: the unexpected-state preserve branch contains no
        leave/recovery invocation, and the ONLY recovery call in the
        snapshot state machine lives inside the left-gated elif arm."""
        idx_unexpected = _VC_SRC.find("VC_SNAPSHOT_STALE_UNEXPECTED_STATE")
        idx_left_elif = _VC_SRC.find('elif _registry_state_for_skip == "left":')
        self.assertGreater(idx_unexpected, 0)
        self.assertGreater(idx_left_elif, 0)
        # The unexpected-state branch body (up to the left-gated elif)
        # must contain NO recovery call and NO leave.
        branch_body = _VC_SRC[idx_unexpected:idx_left_elif]
        self.assertNotIn("_vc_stale_container_recovery(", branch_body)
        self.assertNotIn("vc_leave", branch_body)
        self.assertIn("_backend_connected = False", branch_body)


class TestSnapReasonSourceContracts(unittest.TestCase):
    """Machine-searchable markers for the next production log."""

    def test_d1_convergence_marker_present(self):
        self.assertIn("VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONVERGED", _VC_SRC)
        self.assertIn("VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONFLICT", _VC_SRC)

    def test_d2_fix_annotation_present(self):
        self.assertIn("v99.11.1 FIX-2", _VC_SRC)

    def test_d3_worker_file_compiles(self):
        compile(_VC_SRC, str(_VC_PATH), "exec")


if __name__ == "__main__":
    unittest.main()
