"""v99.11 — THE ENTITY-RESOLUTION / get_contacts SUITE (P1).

Production evidence (bot-diagnostic.log.3, 2026-09-21 11:33:37):
  ``ENTITY_CONTACT_SEARCH_FAILED … exc=AttributeError: 'TelegramClient'
  object has no attribute 'get_contacts'`` — Telethon REMOVED
  ``get_contacts`` in the 1.x line (this project pins
  ``telethon>=1.34.0,<2.0``; production 1.44.0).  The v99.10 code called
  the removed API at three sites; contact-based resolution silently
  never worked.

FIX UNDER TEST: ``mtproto._telethon_fetch_contacts`` — the supported
ladder:
  1. ``client.iter_contacts()`` (the 1.x async iterator, capped 5000)
  2. raw-API fallback ``functions.contacts.GetContactsRequest`` (for
  driver/stub clients implementing only the callable interface)
  NEVER touches ``get_contacts``.
"""

from __future__ import annotations

import asyncio
import sys
import types
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mediagrab_bot import mtproto  # noqa: E402

PKG = Path(__file__).resolve().parents[1] / "mediagrab_bot"


class _Contact(SimpleNamespace):
    pass


class _IterContactsClient:
    """A Telethon-1.x-shaped client: iter_contacts, NO get_contacts."""

    def __init__(self, contacts):
        self._contacts = contacts
        self.iter_calls = 0

    async def iter_contacts(self):
        self.iter_calls += 1
        for c in self._contacts:
            yield c


class TestFetchContactsLadder(unittest.TestCase):
    def test_t1_no_get_contacts_attribute_iter_ladder_works(self):
        client = _IterContactsClient(
            [_Contact(id=1, access_hash=11), _Contact(id=2, access_hash=22)])
        # THE P1 regression assertion: the unavailable method is absent
        self.assertFalse(hasattr(client, "get_contacts"))
        out = asyncio.run(mtproto._telethon_fetch_contacts(client))
        self.assertEqual([c.id for c in out], [1, 2])
        self.assertEqual(client.iter_calls, 1)

    def test_t2_tripwire_never_touched(self):
        """A get_contacts attribute that FAILS the test if accessed —
        the helper must never touch the removed API."""
        class _Tripwire(_IterContactsClient):
            # The property explodes on ACCESS (Python's hasattr only
            # swallows AttributeError — an AssertionError propagates),
            # so even a hasattr probe would fail the test; the ladder
            # must not touch the removed API at all.
            @property
            def get_contacts(self):
                raise AssertionError(
                    "the removed get_contacts API was accessed")

        client = _Tripwire([_Contact(id=7, access_hash=77)])
        out = asyncio.run(mtproto._telethon_fetch_contacts(client))
        self.assertEqual(len(out), 1)

    def test_t3_raw_api_fallback(self):
        """iter_contacts missing → the callable raw-API ladder."""
        requests = []

        class _RawClient:
            async def __call__(self, request):
                requests.append(request)
                return SimpleNamespace(
                    users=[_Contact(id=9, access_hash=99)])

        # telethon is NOT installed in the test env — inject a stub
        # module carrying functions.contacts.GetContactsRequest.
        stub = types.ModuleType("telethon")
        fn = types.ModuleType("telethon.functions")
        contacts_mod = types.ModuleType("telethon.functions.contacts")

        class GetContactsRequest:
            def __init__(self, hash=0):
                self.hash = hash

        contacts_mod.GetContactsRequest = GetContactsRequest
        fn.contacts = contacts_mod
        stub.functions = fn
        saved = {k: v for k, v in sys.modules.items()
                 if k.startswith("telethon")}
        sys.modules["telethon"] = stub
        sys.modules["telethon.functions"] = fn
        sys.modules["telethon.functions.contacts"] = contacts_mod
        try:
            client = _RawClient()
            self.assertFalse(hasattr(client, "iter_contacts"))
            out = asyncio.run(mtproto._telethon_fetch_contacts(client))
            self.assertEqual(len(out), 1)
            self.assertEqual(out[0].id, 9)
            self.assertEqual(len(requests), 1)
            self.assertEqual(requests[0].hash, 0)
        finally:
            for k in list(sys.modules):
                if k.startswith("telethon"):
                    sys.modules.pop(k, None)
            sys.modules.update(saved)

    def test_t4_both_paths_fail_raises(self):
        class _Broken:
            async def iter_contacts(self):
                raise RuntimeError("iter boom")

            async def __call__(self, request):
                raise RuntimeError("raw boom")

        with self.assertRaises(RuntimeError):
            asyncio.run(mtproto._telethon_fetch_contacts(_Broken()))

    def test_t4b_neither_api_available_raises_runtimeerror(self):
        class _Empty:
            pass

        with self.assertRaises(RuntimeError) as cm:
            asyncio.run(mtproto._telethon_fetch_contacts(_Empty()))
        self.assertIn("no supported contacts API", str(cm.exception))

    def test_t5_bounded_materialization(self):
        """A pathological contact list is capped at 5000 items."""

        class _Big(_IterContactsClient):
            async def iter_contacts(self):
                for i in range(10000):
                    yield _Contact(id=i, access_hash=0)

        out = asyncio.run(mtproto._telethon_fetch_contacts(_Big([])))
        self.assertEqual(len(out), 5000)


class TestSourceContracts(unittest.TestCase):
    def test_s1_no_raw_get_contacts_calls_anywhere(self):
        """The complete package contains NO invocation of the removed
        API (scan every shipped module)."""
        for py in sorted(PKG.glob("*.py")):
            src = py.read_text(encoding="utf-8")
            for forbidden in ("client.get_contacts(",
                              "await client.get_contacts",
                              "_rpc(client.get_contacts",
                              ".get_contacts()"):
                self.assertNotIn(
                    forbidden, src,
                    f"{py.name} still invokes the removed API: "
                    f"{forbidden!r}")

    def test_s2_three_call_sites_use_the_ladder(self):
        mt = (PKG / "mtproto.py").read_text(encoding="utf-8")
        vc = (PKG / "voicechat.py").read_text(encoding="utf-8")
        self.assertEqual(
            mt.count("await _telethon_fetch_contacts(client)"), 2,
            "both mtproto sites (resolve_vc_entity step 5 + "
            "resolve_user_id_full step 5) use the ladder")
        self.assertEqual(
            vc.count("_telethon_fetch_contacts(client)"), 1,
            "the voicechat fallback site uses the ladder (lazy import)")
        self.assertIn("from .mtproto import _telethon_fetch_contacts", vc)

    def test_s3_ladder_documented_and_bounded(self):
        mt = (PKG / "mtproto.py").read_text(encoding="utf-8")
        self.assertIn("async def _telethon_fetch_contacts", mt)
        self.assertIn("iter_contacts", mt)
        self.assertIn("GetContactsRequest", mt)
        self.assertIn("5000", mt)

    def test_s4_entity_resolution_paths_intact(self):
        """The surrounding resolution ladder is preserved (dialog scan,
        common-groups, hash persistence)."""
        mt = (PKG / "mtproto.py").read_text(encoding="utf-8")
        self.assertIn("ENTITY_CONTACT_HIT", mt)
        self.assertIn("ENTITY_CONTACT_SEARCH_FAILED", mt)
        self.assertIn("iter_dialogs", mt)


if __name__ == "__main__":
    unittest.main()
