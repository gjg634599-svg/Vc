"""
v97.66 regression tests — causal investigation of event-loop lag + instrumentation.

Root cause found:
  The 10.11s EVENT_LOOP_LAG_CRITICAL occurred because the dashboard snapshot
  loop did TWO sequential asyncio.to_thread() calls:
    await asyncio.to_thread(_dashboard_write_snapshots)
    await asyncio.to_thread(_process_admin_triggers)
  When the bounded executor (max_workers=8) was saturated, the second
  to_thread blocked waiting for a free worker — which blocked the event loop.
  The task dump at the critical lag event proved this:
    Task-8 at handlers.py:2221 in _dashboard_snapshot_loop() [await asyncio.to_thread(_process_admin_triggers)]

Fix:
  1. Combined both to_thread calls into ONE (eliminates sequential executor wait)
  2. Added _capture_blocking_task_stack() to the lag monitor — captures the
     currently executing application-owned tasks + their stack frames at 2s/5s/10s
  3. Added Join-All per-target stage instrumentation (VC_JOIN_ALL_STAGE logs)
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_HANDLERS = os.path.join(_BASE, "mediagrab_bot", "handlers.py")
_BOOTSTRAP = os.path.join(_BASE, "mediagrab_bot", "bootstrap.py")


class TestDashboardSnapshotCombinedToThread(unittest.TestCase):
    """The 10.11s lag root cause: sequential to_thread calls."""

    def test_no_sequential_to_thread_in_snapshot_loop(self):
        """The dashboard snapshot loop must NOT do two sequential to_thread calls."""
        with open(_HANDLERS) as f:
            src = f.read()
        # Find the snapshot loop function.
        import re
        m = re.search(r'async def _dashboard_snapshot_loop.*?(?=\nasync def |\ndef |\nclass )', src, re.DOTALL)
        self.assertIsNotNone(m, "function not found")
        func_body = m.group(0)
        # The OLD code had two sequential to_thread calls. The NEW code
        # combines them into one via _snapshot_and_triggers.
        self.assertIn("_snapshot_and_triggers", func_body,
                      "snapshot loop must use _snapshot_and_triggers to combine calls")
        self.assertNotIn("await asyncio.to_thread(_dashboard_write_snapshots)", func_body,
                         "snapshot loop must NOT call to_thread(_dashboard_write_snapshots) separately")
        self.assertNotIn("await asyncio.to_thread(_process_admin_triggers)", func_body,
                         "snapshot loop must NOT call to_thread(_process_admin_triggers) separately")


class TestEventLoopLagCausalInstrumentation(unittest.TestCase):
    """The lag monitor must capture task stacks at 2s/5s/10s."""

    def test_capture_blocking_task_stack_exists(self):
        """_capture_blocking_task_stack must exist in bootstrap.py."""
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn("def _capture_blocking_task_stack", src,
                      "_capture_blocking_task_stack must exist")
        self.assertIn("EVENT_LOOP_LAG_APP_TASKS", src,
                      "must log EVENT_LOOP_LAG_APP_TASKS with task stacks")

    def test_capture_called_at_2s_5s_10s(self):
        """The capture must be called at all three lag thresholds."""
        with open(_BOOTSTRAP) as f:
            src = f.read()
        # At 10s (critical)
        self.assertIn("_capture_blocking_task_stack(lag)", src)
        # Count occurrences — should be at least 3 (2s, 5s, 10s)
        count = src.count("_capture_blocking_task_stack(lag)")
        self.assertGreaterEqual(count, 3,
                                "capture must be called at 2s, 5s, and 10s thresholds")


class TestJoinAllStageInstrumentation(unittest.TestCase):
    """Join-All must log per-target stage durations."""

    def test_stage_instrumentation_exists(self):
        """VC_JOIN_ALL_STAGE logs must exist."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_JOIN_ALL_STAGE", src,
                      "Join-All must log VC_JOIN_ALL_STAGE with op_id, gid, stage, duration")
        self.assertIn("_stage_log", src,
                      "stage logging helper must exist")


class TestEntityDeadLetterNetworkExclusionPreserved(unittest.TestCase):
    """Verify the v97.64 network-error exclusion is still present."""

    def test_network_error_exclusion_present(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_is_network_err", src)
        self.assertIn("cannot send requests", src)
        self.assertIn("connection reset", src)


class TestReconcileTimeoutCausePreserved(unittest.TestCase):
    """Verify the v97.65 reconcile timeout cause classification is present."""

    def test_reconcile_timeout_has_cause(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("classified UNKNOWN cause=", src)
        self.assertIn("mtproto_disconnected", src)


class TestPreservedBehavior(unittest.TestCase):
    """Verify all previous fixes are still present."""

    def test_floodwait_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_GLOBAL_FLOODWAIT_SET", src)

    def test_interdc_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("is_interdc_error", src)

    def test_no_await_on_sync_release(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertNotIn("await _vc_release_target_inflight", src)

    def test_dashboard_single_flight(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_DASHBOARD_REFRESH_CANCELLED", src)

    def test_join_all_get_entity_timeout(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_JOIN_ALL_ENTITY_TIMEOUT", src)

    def test_callback_handler_sync_properties(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("event.sender_id", src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
