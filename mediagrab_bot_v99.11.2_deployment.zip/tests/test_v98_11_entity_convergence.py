"""v98.11 — Entity-resolution convergence regression suite (PROMPT 4).

Layer 1: the behavioral driver (17 cases, REAL mtproto + production
         topology fake world — gated proxies + real-cluster registry).
Layer 2: source contracts for the v98.11 machinery.
Layer 3: persistence/config contracts.

The v98.10 suite (test_v98_10_entity_resolution.py) stays in place and
MUST keep passing — v98.11 is an additive hardening layer.
"""
from __future__ import annotations

import ast
import subprocess
import sys
import unittest
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
_SRC = _ROOT / "mediagrab_bot"
_DRIVER = _ROOT / "tests" / "_v9811_entity_driver.py"

_MTPROTO = _SRC / "mtproto.py"
_CONFIG = _SRC / "config.py"


def _read(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="replace")


# =============================================================================
# Layer 1 — behavioral driver
# =============================================================================
class TestV9811Driver(unittest.TestCase):

    def test_driver_all_cases_pass(self):
        """The 17 v98.11 behavioral cases (production topology) pass."""
        proc = subprocess.run(
            [sys.executable, str(_DRIVER)],
            capture_output=True, text=True, timeout=300,
            cwd=str(_ROOT))
        self.assertEqual(proc.returncode, 0, proc.stdout[-3000:] + proc.stderr[-2000:])
        self.assertIn("17/17 cases pass", proc.stdout)

    def test_driver_case_ids_present(self):
        """The driver covers the v98.11 §30 matrix case ids."""
        src = _read(Path(_DRIVER))
        for marker in ("V1_valid_scoped_hash_local_cache_miss",
                       "V2_stale_scoped_hash_refresh",
                       "V7_private_channel_fallback",
                       "V10_floodwait_account_cooling",
                       "V12_convergence_durable_knowledge",
                       "V13_single_flight_waiter_cancel",
                       "V15_dialogs_index_one_scan_per_ttl",
                       "V16_scope_stability_across_proxies",
                       "V17_local_miss_only_no_rotation"):
            self.assertIn(marker, src, marker)


# =============================================================================
# Layer 2 — source contracts (the v98.11 machinery)
# =============================================================================
class TestV9811SourceContracts(unittest.TestCase):

    def test_local_miss_class_exists_and_is_distinct(self):
        """S4: LOCAL_MISS is a first-class outcome, distinct from
        NOT_ACCESSIBLE, and the classifier routes Telethon's local
        session-cache-miss text to it."""
        src = _read(_MTPROTO)
        self.assertIn('_VC_RES_LOCAL_MISS = "LOCAL_MISS"', src)
        self.assertIn('return _VC_RES_LOCAL_MISS', src)
        # The NOT_ACCESSIBLE class still exists (server-confirmed denial).
        self.assertIn('_VC_RES_NOT_ACCESSIBLE = "NOT_ACCESSIBLE"', src)

    def test_rotation_gate_requires_account_scoped_evidence(self):
        """S5: local-miss (without hash-rejection evidence) and temporary
        failures do NOT rotate; the composite Step-2 class elevates
        server-verified denials."""
        src = _read(_MTPROTO)
        i = src.find("async def resolve_vc_entity(")
        win = src[i:i + 40000]
        self.assertIn("_v9811_scope_hash_rejected(", win)
        self.assertIn("_VC_RES_LOCAL_MISS, _VC_RES_TEMPORARY_RPC_FAILURE", win)
        # Composite Step-2 precedence.
        self.assertIn("_v9811_step2_cls", win)

    def test_scope_identification_covers_proxies_and_real_registry(self):
        """S9: _vc_client_scope consults the proxy's stable _client_id
        AND the real cluster's _clients registry."""
        src = _read(_MTPROTO)
        i = src.find("def _vc_client_scope(")
        # v99.08: window 5200 -> 6600 (documented correction; the
        # Patch-9 rotation-window guard + its audit docstring grew the
        # function head; the asserted markers are unchanged and the
        # cluster-registry scan still lives INSIDE _vc_client_scope).
        win = src[i:i + 6600]
        self.assertIn('getattr(client, "_client_id", None)', win)
        self.assertIn('startswith("cluster:")', win)
        self.assertIn('getattr(_cluster, "_clients", None)', win)

    def test_dialogs_index_bounded(self):
        """S24: the dialogs index is TTL-bounded and size-bounded."""
        src = _read(_MTPROTO)
        for marker in ("_v9811_dialogs_index_ttl()",
                       "_V9811_DIALOGS_INDEX_MAX_SCOPES",
                       "def _v9811_dialogs_index_invalidate(",
                       "def _v9811_dialogs_lookup("):
            self.assertIn(marker, src, marker)

    def test_rotation_typed_probe_before_ladder(self):
        """S6: resolve_across_accounts probes typed input peers BEFORE
        the ladder, with scope-safe hash candidates and the probe
        timeout."""
        src = _read(_MTPROTO)
        i = src.find("async def resolve_across_accounts(")
        win = src[i:i + 20000]
        self.assertIn("access_hash: int = 0", win)
        self.assertIn("_v9810_typed_input_peer(_ident_rot0, _probe_hash)", win)
        self.assertIn("_v9810_probe_timeout()", win)
        self.assertIn("_v9810_hash_invalid_check(", win)
        # The ladder still runs (fallback), and FloodWait still cools.
        self.assertIn("await resolve_entity_full(", win)
        self.assertIn("except FloodWaitError as fw:", win)
        self.assertIn("STATUS_FLOODWAIT", win)

    def test_persistence_seeds_only_stable_scopes(self):
        """S9: client:<id> scopes are NOT seeded after restart (they are
        per-process object ids — dead weight)."""
        src = _read(_MTPROTO)
        i = src.find("def _v9810_seed_access_state_from_persistence(")
        win = src[i:i + 3200]
        self.assertIn('_scope == "global" or _scope.startswith("acc_")', win)

    def test_step4_matcher_accepts_all_id_forms(self):
        """S6/S24: the dialogs matcher consults every legitimate id form
        (the v98.10 matcher could never match a marked-form ref)."""
        src = _read(_MTPROTO)
        self.assertIn("def _v9811_want_ids(", src)
        i = src.find("async def resolve_entity_full(")
        win = src[i:i + 14000]
        self.assertIn("_v9811_want_ids(chat_id, marked_chat_id, identity)",
                      win)
        self.assertIn("await _v9811_dialogs_lookup(", win)

    def test_forensic_markers_present(self):
        """S26: the v98.11 outcome markers exist (structured, hash-free)."""
        src = _read(_MTPROTO)
        for marker in ("ENTITY_RESOLVE_LOCAL_MISS",
                       "ENTITY_RESOLVE_CACHE_MISS",
                       "ENTITY_RESOLVE_HASH_REFRESH",
                       "ENTITY_RESOLVE_TYPE_KNOWN",
                       "VC_ENTITY_RESOLVE_ROTATED"):
            self.assertIn(marker, src, marker)

    def test_no_credential_logging_in_new_paths(self):
        """S26: the v98.11 log lines never emit raw hashes (no hash
        field, or redacted-only in the v98.10 lines)."""
        tree = ast.parse(_read(_MTPROTO))
        _v9811_markers = ("ENTITY_RESOLVE_LOCAL_MISS",
                          "ENTITY_RESOLVE_CACHE_MISS",
                          "ENTITY_RESOLVE_HASH_REFRESH",
                          "rotation_probe")
        checked = 0
        for node in ast.walk(tree):
            if (isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Attribute)
                    and node.func.attr in ("info", "warning", "error", "debug")):
                for a in node.args:
                    if isinstance(a, ast.Constant) and isinstance(a.value, str):
                        if any(m in a.value for m in _v9811_markers):
                            checked += 1
                            self.assertNotIn(
                                "hash=%s", a.value,
                                "raw hash field in: " + a.value[:70])
                            self.assertNotIn(
                                "access_hash=%s", a.value,
                                "raw access_hash field in: " + a.value[:70])
        self.assertGreater(checked, 3, "expected the v98.11 markers to exist")

    def test_floodwait_cooling_from_wrapped_ladder(self):
        """S19: a ladder failure wrapped as [class=FLOOD_WAIT] still
        cools the account (the v98.10 raw-except never fired)."""
        src = _read(_MTPROTO)
        i = src.find("async def resolve_across_accounts(")
        win = src[i:i + 20000]
        self.assertIn("wrapped FloodWait cooled", win)


# =============================================================================
# Layer 3 — config + compatibility contracts
# =============================================================================
class TestV9811ConfigContracts(unittest.TestCase):

    def test_v9811_options_and_clamps(self):
        src = _read(_CONFIG)
        for opt in ("vc_entity_dialogs_index_ttl",
                    "vc_entity_probe_timeout"):
            self.assertIn(f"{opt}: int = _env_int(", src, opt)
        for clamp in ('_clamp_int("vc_entity_dialogs_index_ttl"',
                      '_clamp_int("vc_entity_probe_timeout"'):
            self.assertIn(clamp, src, clamp)

    def test_v9810_options_untouched(self):
        """The v98.10 options survive verbatim (additive hardening)."""
        src = _read(_CONFIG)
        for opt in ("vc_entity_scope_state_ttl",
                    "vc_entity_hash_invalid_ttl",
                    "vc_entity_scope_state_max_entries"):
            self.assertIn(f"{opt}: int = _env_int(", src, opt)

    def test_no_db_schema_change_required(self):
        """S28: v98.11 adds NO DB migration — the scoped knowledge still
        lives in the existing vc_access_hashes.json (additive fields).
        The persistence writer/reader keep their v98.10 shapes."""
        src = _read(_MTPROTO)
        self.assertIn("_VC_ACCESS_HASH_FILE", src)
        self.assertIn("def _flush_access_hash_persistence(", src)
        self.assertIn('_persist_entry_v9810["scope"] = str(_scope_v9810)', src)


if __name__ == "__main__":
    unittest.main()
