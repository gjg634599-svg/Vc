"""v98.09-P3 — Join-All fast-path / knowledge-cache regression driver.

Runs the REAL production ``_vc_join_all_active_worker`` + discovery engine
with the REAL voicechat module imported via a stub loader (telegram/
telethon/pytgcalls are unavailable in the sandbox). Fakes:

  * FakePyTgCalls — PyTgCalls 2.3.3 semantics (marked-id ``calls`` dict,
    join_group_call stores the marked id, leave_call pops it).
  * Fake telethon TL classes — Channel/Chat/User/InputPeerChannel and
    GetFullChannelRequest/GetFullChatRequest/SearchGlobalRequest whose
    CONSTRUCTION is recorded in the RPC ledger.
  * Fake ``mtproto_call_with_retry`` — dispatches by request type from a
    scenario-configurable response table; every RPC is COUNTED (the §24
    before/after measurement primitive).
  * Fake ``db_layer`` — dict-backed vc_groups store implementing the
    REAL knowledge-cache function contracts (fresh/stale TTL windows,
    store-active/mark-inactive) plus a permissive SQL sink for the paths
    that persist via raw SQL.
  * REAL join_all_worker / vc_state_coordinator / vc_op_scheduler /
    distributed_join / vc_architecture / vc_hooks (all stdlib-only) —
    the worker runs against the genuine state machine, circuit breaker,
    cancellation token, and checkpoint manager.

Cases implement the v98.09-P3 §28 test matrix (Tests 1-17 + §29 rotation
scenario).  Exit code = number of failed cases; each case prints
``CASE <id>: PASS|FAIL — detail``.
"""
from __future__ import annotations

import asyncio
import importlib.util
import logging
import os
import sys
import time
import types
from typing import Any

# v99.02 FIX-1 adaptation (contract-preserving): the pipeline now BLOCKS
# null-stream dispatches by default (runtime-proven: 168 production
# dispatches → 0 Telegram-side verifications). This driver exercises the
# join-all / knowledge-cache semantics through the null-stream transport
# (its FakePyTgCalls has no audio capability) — it opts in via the
# documented operator knob, exactly like a production operator studying
# null-stream behaviour would. The gate itself is covered by
# tests/test_v99_02_production_stability.py (blocking WITHOUT the env,
# allowance WITH it).
os.environ.setdefault("VC_ALLOW_NULL_STREAM_JOIN", "1")

_HERE_DIR = __file__
_ROOT = _HERE_DIR.rsplit("/tests/", 1)[0]
_SRC = f"{_ROOT}/mediagrab_bot"

MARKED_BASE = -1000000000000


# ---------------------------------------------------------------------------
# Fake telethon TL surface
# ---------------------------------------------------------------------------

class _TLChannel:
    def __init__(self, id=0, title="", username=None, access_hash=None,
                 broadcast=False):
        self.id = id
        self.title = title
        self.username = username
        self.access_hash = access_hash
        self.broadcast = broadcast
        self.megagroup = not broadcast  # supergroups carry VC-capable identity


class _TLChat:
    def __init__(self, id=0, title="", participants_count=0, access_hash=None):
        self.id = id
        self.title = title
        self.participants_count = participants_count
        self.access_hash = access_hash


class _TLUser:
    def __init__(self, id=0, first_name=""):
        self.id = id
        self.first_name = first_name


class _TLGroupCall:
    def __init__(self, id, access_hash):
        self.id = id
        self.access_hash = access_hash


class _TLFullChat:
    def __init__(self, call=None, participants_count=0, about=""):
        self.call = call
        self.participants_count = participants_count
        self.about = about


class _TLFullResponse:
    def __init__(self, full_chat, chats=None):
        self.full_chat = full_chat
        self.chats = chats or []


class _TLSearchResponse:
    def __init__(self, chats=(), users=(), messages=(), next_rate=0):
        self.chats = list(chats)
        self.users = list(users)
        self.messages = list(messages)
        self.next_rate = next_rate


class _TLInputPeerChannel:
    def __init__(self, channel_id=0, access_hash=0):
        self.channel_id = channel_id
        self.access_hash = access_hash


class _TLInputPeerEmpty:
    pass


class _TLInputPeerChat:
    def __init__(self, chat_id=0):
        self.chat_id = chat_id


class _TLLPeerUser:
    def __init__(self, user_id=0):
        self.user_id = user_id


class _TLInputMessagesFilterEmpty:
    pass


class _GetFullChannelRequest:
    def __init__(self, channel=None):
        self.channel = channel
        self.kind = "GetFullChannelRequest"


class _GetFullChatRequest:
    def __init__(self, chat_id=0):
        self.chat_id = chat_id
        self.kind = "GetFullChatRequest"


class _SearchGlobalRequest:
    def __init__(self, q="", **kwargs):
        self.q = q
        self.offset_rate = kwargs.get("offset_rate", 0)
        self.offset_id = kwargs.get("offset_id", 0)
        self.limit = kwargs.get("limit", 50)
        self.kind = "SearchGlobalRequest"


class _ResolveUsernameRequest:
    def __init__(self, username=""):
        self.username = username
        self.kind = "ResolveUsernameRequest"


class FloodWaitError(Exception):
    def __init__(self, seconds=10):
        self.seconds = seconds
        super().__init__(f"Too many requests: retry after {seconds}s")


class ChannelPrivateError(Exception):
    pass


class ChatAdminRequiredError(Exception):
    pass


class ChatIdInvalidError(Exception):
    pass


class RPCError(Exception):
    pass


class _PermissiveErrors(types.ModuleType):
    """telethon.errors stub — any missing exception name resolves to a
    dynamically-created Exception subclass (cached)."""
    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        exc = type(name, (Exception,), {})
        setattr(self, name, exc)
        return exc


class _PermissiveTypes(types.ModuleType):
    """telethon.tl.types stub — any missing type name resolves to a
    dynamically-created plain class (cached)."""
    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        cls = type(name, (object,), {})
        setattr(self, name, cls)
        return cls


# ---------------------------------------------------------------------------
# RPC ledger + fake mtproto surface
# ---------------------------------------------------------------------------

class RPCLedger:
    def __init__(self):
        self.calls: list[tuple[str, Any]] = []

    def count(self, kind: str) -> int:
        return sum(1 for k, _ in self.calls if k == kind)

    def total(self) -> int:
        return len(self.calls)

    def reset(self) -> None:
        self.calls.clear()


LEDGER = RPCLedger()


class Scenario:
    """Scenario-configurable RPC response table + client behavior."""
    def __init__(self):
        # gid → {"call": GroupCall|None, "members": int} for GetFullChannel/Chat
        self.full_channel: dict[int, dict] = {}
        # queue of SearchGlobal responses (pages); each is _TLSearchResponse
        self.search_pages: list[_TLSearchResponse] = []
        # entity resolution table: InputPeerChannel(channel_id) → entity
        self.entities: dict[int, Any] = {}
        # dialogs for iter_dialogs: list of (FakeDialog)
        self.dialogs: list[Any] = []
        # gid → FloodWait seconds (raise instead of responding)
        self.floodwait_on: dict[int, int] = {}
        # username → entity
        self.resolve_username: dict[str, Any] = {}
        # iter_dialogs override: callable or None
        self.dialogs_error = None


SCENARIO = Scenario()


async def fake_mtproto_call_with_retry(client, request, retries=3, **kw):
    kind = getattr(request, "kind", type(request).__name__)
    LEDGER.calls.append((kind, request))
    if kind == "GetFullChannelRequest":
        gid = getattr(getattr(request, "channel", None), "id", None)
        if gid is None:
            gid = getattr(request, "channel", 0)
        fw = SCENARIO.floodwait_on.get(gid if isinstance(gid, int) else 0)
        if fw:
            raise FloodWaitError(fw)
        info = SCENARIO.full_channel.get(gid if isinstance(gid, int) else -1)
        if info is None:
            raise ChannelPrivateError("channel private")
        return _TLFullResponse(_TLFullChat(
            call=info.get("call"), participants_count=info.get("members", 0)))
    if kind == "GetFullChatRequest":
        gid = getattr(request, "chat_id", 0)
        info = SCENARIO.full_channel.get(gid)
        if info is None:
            raise ChannelPrivateError("chat private")
        return _TLFullResponse(_TLFullChat(
            call=info.get("call"), participants_count=info.get("members", 0)))
    if kind == "SearchGlobalRequest":
        if SCENARIO.search_pages:
            return SCENARIO.search_pages.pop(0)
        return _TLSearchResponse()
    if kind == "ResolveUsernameRequest":
        ent = SCENARIO.resolve_username.get(getattr(request, "username", ""))
        if ent is None:
            raise ChannelPrivateError("no such username")
        return types.SimpleNamespace(user=ent, chats=[ent])
    return _TLSearchResponse()


async def fake_resolve_vc_entity(client, chat_ref, chat_id=0, access_hash=0):
    """Fake entity resolution — cache-first, then InputPeerChannel table."""
    gid = chat_id if isinstance(chat_id, int) and chat_id > 0 else abs(
        int(chat_id or 0)) % 1000000000000 if chat_id else 0
    ent = SCENARIO.entities.get(gid)
    if ent is None and isinstance(chat_ref, _TLChannel):
        ent = chat_ref
    if ent is not None:
        return {"ok": True, "entity": ent, "source": "cache",
                "scope": "_global", "error": ""}
    return {"ok": False, "entity": None, "source": "", "error": "not found"}


class FakeClient:
    def __init__(self, account_id="_global"):
        self.account_id = account_id
        self.get_entity_calls = 0
        self.iter_dialogs_calls = 0

    def is_connected(self) -> bool:
        return True

    async def get_entity(self, ref):
        self.get_entity_calls += 1
        LEDGER.calls.append(("get_entity", ref))
        if isinstance(ref, _TLInputPeerChannel):
            ent = SCENARIO.entities.get(ref.channel_id)
            if ent is not None:
                return ent
            raise ChannelPrivateError("no entity")
        if isinstance(ref, int):
            ent = SCENARIO.entities.get(ref)
            if ent is not None:
                return ent
            raise ChannelPrivateError("no entity for bare id")
        if isinstance(ref, _TLLPeerUser):
            raise ChannelPrivateError("PeerUser cache miss")
        return None

    def iter_dialogs(self, limit=0):
        self.iter_dialogs_calls += 1
        LEDGER.calls.append(("iter_dialogs", limit))

        async def _gen():
            if SCENARIO.dialogs_error is not None:
                raise SCENARIO.dialogs_error
            for d in SCENARIO.dialogs:
                yield d

        return _gen()


class FakeDialog:
    def __init__(self, entity):
        self.entity = entity
        self.name = getattr(entity, "title", "")


class FakeCluster:
    def __init__(self):
        self.clients: dict[str, FakeClient] = {}

    def get_client(self, account_id):
        return self.clients.get(account_id)

    def get_healthy_accounts(self):
        return [{"account_id": aid} for aid in self.clients]

    def list_accounts(self):
        return [{"account_id": aid} for aid in self.clients]


GLOBAL_CLUSTER = FakeCluster()


def _scope_of_client(client) -> str:
    return getattr(client, "account_id", "_global")


# ---------------------------------------------------------------------------
# Fake db_layer — dict-backed knowledge cache (REAL function contracts)
# ---------------------------------------------------------------------------

_GROUPS: dict[int, dict] = {}


class _FakeCursor:
    async def fetchone(self):
        return None

    async def fetchall(self):
        return []

    @property
    def rowcount(self):
        return 0


class _FakeDB:
    async def execute(self, sql, params=()):
        return _FakeCursor()

    async def commit(self):
        return None

    async def rollback(self):
        return None

    async def executemany(self, sql, seq=()):
        return _FakeCursor()

    async def executescript(self, sql):
        return None

    def __aiter__(self):
        return self

    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False


async def _get_db():
    return _FakeDB()


async def _vc_upsert_group(*, group_id, access_hash=None, title=None,
                           username=None, public_link=None, source=None,
                           access_status="unknown", active_vc=None,
                           last_error=None, commit=True, call_id=None,
                           call_access_hash=None, last_active_vc_at=None):
    row = _GROUPS.get(group_id)
    is_new = row is None
    if is_new:
        row = {"group_id": group_id, "access_hash": None, "title": None,
               "username": None, "public_link": None, "source": None,
               "access_status": "unknown", "active_vc": 0,
               "last_error": None, "call_id": None,
               "call_access_hash": None, "last_active_vc_at": None}
        _GROUPS[group_id] = row
    if access_hash is not None:
        row["access_hash"] = access_hash
    if title is not None:
        row["title"] = title
    if username is not None:
        row["username"] = username
    if public_link is not None:
        row["public_link"] = public_link
    if source is not None:
        row["source"] = source
    row["access_status"] = access_status
    if active_vc is not None:
        row["active_vc"] = 1 if active_vc else 0
    if last_error is not None:
        row["last_error"] = last_error
    if call_id is not None:
        row["call_id"] = call_id
    if call_access_hash is not None:
        row["call_access_hash"] = call_access_hash
    if last_active_vc_at is not None:
        row["last_active_vc_at"] = last_active_vc_at
    return is_new


async def _vc_group_count():
    return len(_GROUPS)


async def _vc_groups_keyset_stream(batch_size=500, *, only_accessible=False):
    for gid in sorted(_GROUPS):
        row = dict(_GROUPS[gid])
        if only_accessible and row.get("access_status") not in (
                "accessible", "stale"):
            continue
        yield row


async def _vc_groups_fresh_active(active_ttl_seconds, *, limit=200):
    cutoff = time.time() - max(0.0, float(active_ttl_seconds))
    out = []
    for gid in sorted(_GROUPS, key=lambda g: -(
            _GROUPS[g].get("last_active_vc_at") or 0)):
        row = _GROUPS[gid]
        lav = row.get("last_active_vc_at")
        if row.get("active_vc") and lav is not None and lav >= cutoff \
                and row.get("access_status") in ("accessible", "stale", "unknown"):
            out.append(dict(row))
            if len(out) >= limit:
                break
    return out


async def _vc_groups_stale_active(active_ttl_seconds, *, limit=40):
    cutoff = time.time() - max(0.0, float(active_ttl_seconds))
    out = []
    for gid in sorted(_GROUPS, key=lambda g: -(
            _GROUPS[g].get("last_active_vc_at") or 0)):
        row = _GROUPS[gid]
        lav = row.get("last_active_vc_at")
        if row.get("active_vc") and lav is not None and lav < cutoff \
                and row.get("access_status") in ("accessible", "stale", "unknown"):
            out.append(dict(row))
            if len(out) >= limit:
                break
    return out


async def _vc_knowledge_store_active(group_id, *, call_id=None,
                                     call_access_hash=None, commit=True):
    row = _GROUPS.get(group_id)
    if row is None:
        return False
    row["active_vc"] = 1
    row["call_id"] = call_id
    row["call_access_hash"] = call_access_hash
    row["last_active_vc_at"] = time.time()
    return True


async def _vc_knowledge_mark_inactive(group_id, *, commit=True):
    row = _GROUPS.get(group_id)
    if row is None:
        return False
    row["active_vc"] = 0
    row["call_id"] = None
    row["call_access_hash"] = None
    return True


async def _vc_get_settings():
    return {"vc_join_mode": "primary"}


class _FakeDBLayer(types.ModuleType):
    pass


def _make_db_layer_module():
    m = _FakeDBLayer("mediagrab_bot.db_layer")
    m.get_db = _get_db
    m._db = None
    m.repo = None
    m.vc_groups_active = _vc_groups_fresh_active  # compat: unused in cases
    m.vc_groups_all = _vc_groups_keyset_stream
    m.vc_groups_keyset = _vc_groups_keyset_stream
    m.vc_groups_keyset_stream = _vc_groups_keyset_stream
    m.vc_upsert_group = _vc_upsert_group
    m.vc_group_count = _vc_group_count
    m.vc_groups_fresh_active = _vc_groups_fresh_active
    m.vc_groups_stale_active = _vc_groups_stale_active
    m.vc_knowledge_store_active = _vc_knowledge_store_active
    m.vc_knowledge_mark_inactive = _vc_knowledge_mark_inactive
    m.vc_get_settings = _vc_get_settings
    m.vc_update_settings = _noop_async
    m.vc_add_visit = _noop_async
    m.vc_update_visit = _noop_async
    m.vc_recent_visits = _empty_list
    m.vc_get_tour_state = _empty_dict
    m.vc_save_tour_state = _noop_async
    m.vc_visit_count = _zero
    m.vc_visited_group_ids_since = _empty_set
    m.talkative_add_memory = _noop_async
    m.talkative_effective_provider = _empty_dict
    m.talkative_effective_settings = _empty_dict
    sys.modules["mediagrab_bot.db_layer"] = m
    return m


async def _noop_async(*a, **k):
    return None


async def _empty_dict(*a, **k):
    return {}


async def _empty_list(*a, **k):
    return []


async def _empty_set(*a, **k):
    return set()


async def _zero(*a, **k):
    return 0


# ---------------------------------------------------------------------------
# Fake PyTgCalls + backend world
# ---------------------------------------------------------------------------

class FakePyTgCalls:
    """PyTgCalls 2.x semantics: marked-id container + join_group_call."""

    def __init__(self):
        self.calls: dict[int, Any] = {}
        self.api_log: list[tuple[str, Any]] = []

    async def join_group_call(self, chat_id, stream, muted=True):
        self.api_log.append(("join_group_call", chat_id, muted))
        self.calls[chat_id] = types.SimpleNamespace(chat_id=chat_id)

    async def call(self, chat_id, stream):
        self.api_log.append(("call", chat_id, None))
        self.calls[chat_id] = types.SimpleNamespace(chat_id=chat_id)

    async def join_call(self, chat_id, muted=True):
        self.api_log.append(("join_call", chat_id, muted))
        self.calls[chat_id] = types.SimpleNamespace(chat_id=chat_id)

    async def play(self, chat_id, stream):
        self.api_log.append(("play", chat_id, None))
        self.calls[chat_id] = types.SimpleNamespace(chat_id=chat_id)

    async def leave_call(self, chat_id):
        self.api_log.append(("leave_call", chat_id))
        self.calls.pop(chat_id, None)

    async def leave_group_call(self, chat_id):
        self.api_log.append(("leave_group_call", chat_id))
        self.calls.pop(chat_id, None)

    async def stop_call(self, chat_id):
        self.api_log.append(("stop_call", chat_id))
        self.calls.pop(chat_id, None)

    async def leave_current_call(self):
        self.api_log.append(("leave_current_call", None))
        if self.calls:
            self.calls.pop(next(iter(self.calls)))


# ---------------------------------------------------------------------------
# Stub loader — imports the REAL voicechat module
# ---------------------------------------------------------------------------

def _mod(name, attrs):
    m = types.ModuleType(name)
    m.__dict__.update(attrs)
    sys.modules[name] = m
    return m


def _attrs(*names):
    def _stub(*a, **k):
        return None
    out = {}
    for n in names:
        out[n] = _stub
    return out


class _FakeConfig:
    project_root = "/tmp/v9810_root"
    data_dir = "/tmp/v9810_root/data"
    db_path = "/tmp/v9810_fake.db"
    vc_multi_stagger_seconds = 0.05
    vc_multi_join_timeout = 10
    vc_multi_join_concurrency = 3
    vc_join_all_fast_path = True
    vc_knowledge_active_ttl = 300
    vc_knowledge_stale_refresh_limit = 40
    vc_discovery_adaptive_pagination = True
    vc_discovery_adaptive_expansion = True
    vc_discovery_expand = True
    vc_discovery_floodwait_max_retries = 1
    vc_discovery_search_delay = 0.05
    vc_discovery_pagination_pages = 3
    vc_discovery_results_per_query = 50
    vc_discovery_max_queries_per_cycle = 20
    vc_discovery_cycle_wall_cap = 90
    vc_discovery_dead_cooldown = 604800
    vc_discovery_query_cooldown = 7200
    vc_discovery_stale_revalidate_interval = 86400
    vc_discovery_auto_join = False
    vc_discovery_metadata_concurrency = 4
    vc_auto_join_after_discovery = False
    vc_watcher_interval = 60
    vc_reconcile_interval = 300
    vc_rotation_settle_seconds = 45
    vc_max_joined = 100


def import_voicechat():
    """Stub-import the REAL voicechat.py (full module body execution)."""
    logging.getLogger("mediagrap").addHandler(logging.NullHandler())
    # Fake telethon package.
    tl_types = _PermissiveTypes("telethon.tl.types")
    tl_types.Channel = _TLChannel
    tl_types.Chat = _TLChat
    tl_types.User = _TLUser
    tl_types.InputPeerChannel = _TLInputPeerChannel
    tl_types.InputPeerChat = _TLInputPeerChat
    tl_types.InputPeerEmpty = _TLInputPeerEmpty
    tl_types.InputMessagesFilterEmpty = _TLInputMessagesFilterEmpty
    tl_types.PeerUser = _TLLPeerUser
    tl_funcs_channels = _mod("telethon.tl.functions.channels", {
        "GetFullChannelRequest": _GetFullChannelRequest,
    })
    tl_funcs_messages = _mod("telethon.tl.functions.messages", {
        "GetFullChatRequest": _GetFullChatRequest,
        "SearchGlobalRequest": _SearchGlobalRequest,
    })
    tl_funcs_contacts = _mod("telethon.tl.functions.contacts", {
        "ResolveUsernameRequest": _ResolveUsernameRequest,
    })
    tl_functions = _PermissiveErrors("telethon.tl.functions")
    tl_functions.channels = tl_funcs_channels
    tl_functions.messages = tl_funcs_messages
    tl_functions.contacts = tl_funcs_contacts
    tl = _mod("telethon", {"TelegramClient": object})
    tl.tl = types.SimpleNamespace(types=tl_types, functions=tl_functions)
    tl_errors = _PermissiveErrors("telethon.errors")
    tl_errors.FloodWaitError = FloodWaitError
    tl_errors.ChannelPrivateError = ChannelPrivateError
    tl_errors.ChatAdminRequiredError = ChatAdminRequiredError
    tl_errors.ChatIdInvalidError = ChatIdInvalidError
    tl_errors.RPCError = RPCError
    tl.errors = tl_errors
    sys.modules["telethon"] = tl
    sys.modules["telethon.tl"] = _mod("telethon.tl", {})
    sys.modules["telethon.tl.types"] = tl_types
    sys.modules["telethon.tl.functions"] = tl_functions
    sys.modules["telethon.tl.functions.channels"] = tl_funcs_channels
    sys.modules["telethon.tl.functions.messages"] = tl_funcs_messages
    sys.modules["telethon.tl.functions.contacts"] = tl_funcs_contacts
    sys.modules["telethon.errors"] = tl_errors

    _mod("httpx", _attrs("AsyncClient", "Client"))
    _mod("telegram", _attrs("Update", "InlineKeyboardButton",
                            "InlineKeyboardMarkup"))
    _mod("telegram.ext", _attrs("ContextTypes", "filters"))
    _mod("telegram.error", _attrs(
        "BadRequest", "Forbidden", "NetworkError", "TimedOut", "RetryAfter"))
    _mod("pytgcalls", {"PyTgCalls": object})

    pkg = types.ModuleType("mediagrab_bot")
    pkg.__path__ = [_SRC]
    sys.modules["mediagrab_bot"] = pkg

    cfg = _mod("mediagrab_bot.config", {
        "config": _FakeConfig(),
        "_env_int": lambda name, default=0, **k: default,
        "_env_float": lambda name, default=0.0, **k: default,
        "_env_bool": lambda name, default=False, **k: default,
        "_env": lambda name, default="", **k: default,
    })
    _mod("mediagrab_bot.text_utils", _attrs("md_escape", "html_escape"))
    _mod("mediagrab_bot.media_processor", _attrs(
        "download_slot", "with_retries", "retrying", "send_file_back",
        "notify", "safe_unlink"))
    _mod("mediagrab_bot.ai_modes", _attrs(
        "ACCEPTS", "MODE_LABELS", "MODE_ORDER", "PROMPTS", "build_prompt",
        "NORMALISERS", "normalise", "accepts", "media_kind_for",
        "render_result"))
    _mod("mediagrab_bot.frame_extractor", _attrs(
        "extract_frames", "FrameExtractionError", "_FFMPEG", "_FFPROBE"))

    class _VCTransportError(Exception):
        pass

    _cluster = GLOBAL_CLUSTER
    _global_client = FakeClient("_global")

    async def _mtproto_call(client, request, retries=3, **kw):
        return await fake_mtproto_call_with_retry(client, request, retries)

    async def _get_healthy(client=None):
        return True

    def _started():
        return True

    def _get_client():
        return _global_client

    def _get_client_legacy():
        return _global_client

    def _get_cluster():
        return _cluster

    def _get_client_for_role(*a, **k):
        return _global_client

    _router = types.SimpleNamespace(
        _cluster=_cluster,
        route=lambda *a, **k: _global_client,
        get_client_for_role=lambda *a, **k: _global_client,
        get_client_for_role_with_id=lambda *a, **k: ("acc_A", _global_client),
    )

    def _get_router():
        return _router

    def _mtproto_trigger_reconnect():
        return None

    def _get_current_vc_account_id():
        return "acc_A"

    mtproto_attrs = {
        "VCTransportError": _VCTransportError,
        "_redact_ah": lambda ah: "redacted" if ah else "-",
        "_mtproto_client": _global_client,
        "_vc_entity_cache": {},
        "_vc_entity_cache_by_client": {},
        "_user_entity_cache": {},
        "_USER_ENTITY_CACHE_FILE": "/tmp/u.json",
        "_VC_ACCESS_HASH_FILE": "/tmp/ah.json",
        "resolve_entity_full": fake_resolve_vc_entity,
        "resolve_vc_entity": fake_resolve_vc_entity,
        "_vc_client_scope": _scope_of_client,
        "mtproto_call_with_retry": _mtproto_call,
        "mtproto_is_available": _started,
        "mtproto_is_started": _started,
        "mtproto_get_client": _get_client,
        "mtproto_get_client_legacy": _get_client_legacy,
        "ROLE_PRIMARY": "primary",
        "mtproto_get_client_for_role": _get_client_for_role,
        "get_userbot_cluster": _get_cluster,
        "get_cluster_router": _get_router,
        "get_routed_client": lambda *a, **k: _global_client,
        "get_vc_pool": lambda: None,
        "VoiceChatAccountPool": object,
        "UserbotCluster": object,
        "UserbotClusterRouter": object,
        "profile_resolve_entity": fake_resolve_vc_entity,
        "profile_count_posts": lambda *a, **k: 0,
        "profile_download_photo": lambda *a, **k: None,
        "resolve_forwarded_sender": fake_resolve_vc_entity,
        "resolve_forwarded_sender_full": fake_resolve_vc_entity,
        "resolve_user_id_full": fake_resolve_vc_entity,
        "resolve_across_accounts": fake_resolve_vc_entity,
        "_get_current_vc_account_id": _get_current_vc_account_id,
        "ROLE_VOICE_CHAT": "voice_chat",
        "STATUS_CONNECTED": "connected",
        "STATUS_CONNECTION_FAILED": "connection_failed",
        "STATUS_FLOODWAIT": "floodwait",
        "STATUS_HEALTHY": "healthy",
        "STATUS_UNAUTHORIZED": "unauthorized",
        "_flush_access_hash_persistence": lambda *a, **k: None,
        "_flush_user_entity_persistence": lambda *a, **k: None,
        "_mtproto_trigger_reconnect": _mtproto_trigger_reconnect,
    }
    _mod("mediagrab_bot.mtproto", mtproto_attrs)
    _mod("mediagrab_bot.talkative_hooks", _attrs(
        "_adaptive_check_stale", "_adaptive_claim_response",
        "_adaptive_release_response", "_adaptive_detect_language",
        "_adaptive_response_length_guidance", "_adaptive_route_model",
        "_talkative_mode_allows_vc", "_adaptive_get_context",
        "_adaptive_engagement_score", "_talkative_build_system_prompt",
        "talkative_generate", "talkative_get_mode"))
    _mod("mediagrab_bot.diag_hooks", _attrs("v85_diag"))
    _make_db_layer_module()

    _tasks: set = set()

    def supervised_create_task(coro, name="task"):
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            coro.close()
            return None
        t = loop.create_task(coro, name=name)
        _tasks.add(t)
        t.add_done_callback(_tasks.discard)
        return t

    _mod("mediagrab_bot.utils_real", {
        "extension_category": lambda *a, **k: "file",
        "get_bot": lambda *a, **k: None,
        "human_size": lambda *a, **k: "",
        "is_available": lambda *a, **k: True,
        "periodic_cleanup": lambda *a, **k: None,
        "register_bot": lambda *a, **k: None,
        "remove_path": lambda *a, **k: None,
        "safe_edit_message_text": _noop_async,
        "safe_filename": lambda *a, **k: "f",
        "safe_reply_text": _noop_async,
        "safe_send_document": _noop_async,
        "safe_send_message": _noop_async,
        "supervised_create_task": supervised_create_task,
        "telegram_media_type": lambda *a, **k: "document",
        "unique_path": lambda *a, **k: "/tmp/u",
        "_active_tasks": _tasks,
        "_redact_secrets": lambda *a, **k: "",
        "_ui_check": lambda *a, **k: True,
        "_ui_claim": lambda *a, **k: True,
        "_ui_invalidate": lambda *a, **k: None,
        "_ui_release": lambda *a, **k: None,
        "_ui_owners": {},
        "_userbot_id": lambda: 1,
    })
    _mod("mediagrab_bot.states", {
        "IDLE": "idle", "set_state": lambda *a, **k: None,
        "get_state": lambda *a, **k: "idle", "reset": lambda *a, **k: None,
        "set_tool": lambda *a, **k: None, "get_tool": lambda *a, **k: None,
        "set_last_download": lambda *a, **k: None,
        "get_last_download": lambda *a, **k: None,
        "AWAIT_VC_CHECK_TARGET": "await_check",
        "AWAIT_VC_COOLDOWN": "await_cooldown",
        "AWAIT_VC_JOIN_TARGET": "await_join",
        "AWAIT_VC_STAY": "await_stay",
    })
    _mod("mediagrab_bot.ui_keyboards", _attrs(
        "back_only", "cancel_back", "vc_menu", "vc_manual_menu",
        "vc_settings_menu", "vc_dashboard_menu", "vc_dashboard_back_menu",
        "vc_dashboard_text", "vc_dashboard_errors_menu",
        "vc_dashboard_logs_menu", "vc_stay_presets_menu",
        "vc_cooldown_presets_menu"))
    _mod("mediagrab_bot.ai_analyzer", _attrs(
        "_read_bytes", "_run_in_thread", "_get_client"))

    # REAL stdlib-only modules.
    for name, fname in (
            ("mediagrab_bot.join_all_worker", "join_all_worker.py"),
            ("mediagrab_bot.vc_state_coordinator", "vc_state_coordinator.py"),
            ("mediagrab_bot.vc_op_scheduler", "vc_op_scheduler.py"),
            ("mediagrab_bot.distributed_join", "distributed_join.py"),
            ("mediagrab_bot.vc_hooks", "vc_hooks.py"),
            ("mediagrab_bot.vc_architecture", "vc_architecture.py")):
        spec = importlib.util.spec_from_file_location(name, f"{_SRC}/{fname}")
        m = importlib.util.module_from_spec(spec)
        sys.modules[name] = m
        spec.loader.exec_module(m)
    spec = importlib.util.spec_from_file_location(
        "mediagrab_bot.voicechat", f"{_SRC}/voicechat.py")
    vc = importlib.util.module_from_spec(spec)
    sys.modules["mediagrab_bot.voicechat"] = vc
    spec.loader.exec_module(vc)
    return vc


# ---------------------------------------------------------------------------
# World management
# ---------------------------------------------------------------------------

RAW = 1922822605
RAW_B = 2054748259


class World:
    """Fake multi-account world: global + account A + account B backends."""

    def __init__(self, vc):
        self.vc = vc
        self.global_b = vc.PyTgCallsBackend()
        self.global_b._started = True
        self.global_b._leave_strategy = "leave_call"
        self.global_b._join_strategy = "join_group_call"
        self.global_b._status_strategy = "calls"
        self.global_b._compatible = True
        self.global_b._pytgcalls = FakePyTgCalls()
        self.global_b._mtproto = FakeClient("_global")
        vc._vc_backend = self.global_b
        self.a_b = self._account_backend("acc_A")
        self.b_b = self._account_backend("acc_B")
        vc._vc_participations.clear()
        vc._vc_active_join_backends_by_chat.clear()
        vc._vc_target_cooldowns.clear()
        vc._vc_entity_fail_counts.clear()
        vc._vc_join_all_leave_block_active = False

    def _account_backend(self, aid):
        b = self.vc.vc_get_backend(account_id=aid)
        b._started = True
        b._leave_strategy = "leave_call"
        b._join_strategy = "join_group_call"
        b._status_strategy = "calls"
        b._compatible = True
        b._pytgcalls = FakePyTgCalls()
        b._mtproto = FakeClient(aid)
        GLOBAL_CLUSTER.clients[aid] = b._mtproto
        return b

    def join_on(self, backend, raw=RAW):
        marked = MARKED_BASE - raw if raw > 0 else raw
        backend._pytgcalls.calls[marked] = types.SimpleNamespace(
            chat_id=marked)
        self.vc._vc_active_join_backends_by_chat[marked] = backend
        rec = self.vc.VCParticipationState(
            chat_id=raw, state="joined", request_accepted=True,
            intentional=True, locally_tracked=True,
            account_id=backend._account_id)
        self.vc._vc_participations[raw] = rec
        return rec


def reset_world_sync(vc):
    """Sync portion of the world reset."""
    _GROUPS.clear()
    SCENARIO.full_channel.clear()
    SCENARIO.search_pages.clear()
    SCENARIO.entities.clear()
    SCENARIO.dialogs.clear()
    SCENARIO.floodwait_on.clear()
    SCENARIO.resolve_username.clear()
    SCENARIO.dialogs_error = None
    LEDGER.reset()
    w = World(vc)
    GLOBAL_CLUSTER.clients.clear()
    GLOBAL_CLUSTER.clients["acc_A"] = w.a_b._mtproto
    GLOBAL_CLUSTER.clients["acc_B"] = w.b_b._mtproto
    vc._vc_join_all_state.clear()
    vc._vc_join_all_state.update({
        "run_id": "run_case", "running": True, "resumed": False,
        "started_at": "now", "current_index": 0, "progress": {
            "processed": 0, "total": 0, "joined_confirmed": 0,
            "already_joined": 0, "transport_accepted": 0,
            "confirmation_unknown": 0, "confirmed_not_joined": 0,
            "skipped_call_ended": 0, "skipped_in_flight": 0,
            "failed": 0, "deferred": 0,
        }, "results": {}, "targets": [], "discovery": {},
        "floodwait_count": 0,
    })
    vc._vc_join_all_excl_reasons.clear()
    vc.vc_reset_target_state()
    try:
        vc.get_vc_coordinator()._chat_states.clear()
    except Exception:
        pass
    return w


async def reset_world(vc):
    """Reset all module-level mutable state between cases (async: resets
    the REAL worker state machine, breaker, and cancellation token so each
    case starts from IDLE — exactly like vc_join_all_active_start does)."""
    w = reset_world_sync(vc)
    try:
        await vc._vc_join_all_state_machine.reset()
        await vc._vc_join_all_breaker.reset()
        vc._vc_join_all_cancel_token.reset()
    except Exception:
        pass
    vc._vc_join_all_stop_requested = False
    return w


def seed_group(gid, *, title="G", call_id=None, call_ah=None,
               active_at=None, access_hash=111, access_status="accessible",
               username=None):
    _GROUPS[gid] = {
        "group_id": gid, "access_hash": access_hash, "title": title,
        "username": username, "public_link": None, "source": "test",
        "access_status": access_status,
        "active_vc": 1 if call_id else 0,
        "call_id": call_id, "call_access_hash": call_ah,
        "last_active_vc_at": active_at if active_at is not None else (
            time.time() if call_id else None),
        "last_error": None,
    }
    if call_id:
        SCENARIO.full_channel[gid] = {
            "call": _TLGroupCall(call_id, call_ah), "members": 42}
        SCENARIO.entities[gid] = _TLChannel(
            id=gid, title=title, username=username, access_hash=access_hash)
    else:
        SCENARIO.full_channel[gid] = {"call": None, "members": 42}
        SCENARIO.entities[gid] = _TLChannel(
            id=gid, title=title, username=username, access_hash=access_hash)


async def run_worker(vc):
    """Run the REAL worker to terminal state."""
    try:
        await asyncio.wait_for(vc._vc_join_all_active_worker(), timeout=60)
    except asyncio.TimeoutError:
        return "worker_timeout"
    return vc._vc_join_all_state.get("terminal_status", "unknown")


# ---------------------------------------------------------------------------
# Cases (§28 Tests 1-17 + §29 rotation)
# ---------------------------------------------------------------------------

async def case_kb_fastpath(vc):
    """Tests 1+2+15+16 — fresh active cache: no discovery scan on the
    critical path, no classification RPC, target handed directly with
    cached identity; the dialog refresh is decoupled (background task)."""
    w = await reset_world(vc)
    seed_group(RAW, title="KB", call_id=-555, call_ah=7777)
    # §4: patch vc_discover_groups so the ONLY way it can run is via the
    # decoupled background refresh (the critical path must NOT await it).
    _dg_calls = []
    _orig_dg = vc.vc_discover_groups

    async def _fake_dg(*a, **k):
        _dg_calls.append(time.monotonic())
        return {"discovered": 0, "newly_discovered": 0, "updated": 0,
                "skipped": 0, "inaccessible": 0, "errors": 0,
                "complete": True, "cancelled": False,
                "floodwait_interrupted": False}

    vc.vc_discover_groups = _fake_dg
    try:
        vc._vc_join_all_state["run_id"] = "kb_fastpath"
        terminal = await run_worker(vc)
    finally:
        vc.vc_discover_groups = _orig_dg
    metrics = vc.v9810_join_metrics_snapshot()
    ok = (
        terminal in ("completed",)
        and LEDGER.count("iter_dialogs") == 0  # Test 1: no full discovery
        and LEDGER.count("GetFullChannelRequest") == 0  # Test 15+16: no RPC classify
        and metrics.get("targets_from_cache", 0) == 1
        and metrics.get("fast_path_used") == 1
        and metrics.get("rechecks_skipped_fresh", 0) == 1  # Test 16
        and w.global_b._pytgcalls.api_log  # a join attempt happened
        and w.global_b._pytgcalls.api_log[0][0] == "join_group_call"
        and w.global_b._pytgcalls.api_log[0][1] == MARKED_BASE - RAW
        and len(_dg_calls) <= 1  # decoupled bg refresh (never blocking)
    )
    detail = (f"terminal={terminal} iter_dialogs={LEDGER.count('iter_dialogs')} "
              f"fullch={LEDGER.count('GetFullChannelRequest')} metrics={metrics} "
              f"api={w.global_b._pytgcalls.api_log} bg_dg={len(_dg_calls)}")
    return ok, detail


async def case_kb_already_joined(vc):
    """Test 3 — already-joined VC (global backend) skipped, preserved."""
    w = await reset_world(vc)
    seed_group(RAW, title="KB-AJ", call_id=-555, call_ah=7777)
    w.join_on(w.global_b, RAW)
    vc._vc_join_all_state["run_id"] = "kb_aj"
    terminal = await run_worker(vc)
    metrics = vc.v9810_join_metrics_snapshot()
    ok = (
        terminal in ("completed",)
        and metrics.get("already_joined_skipped", 0) == 1
        and not w.global_b._pytgcalls.api_log  # no join attempt
        and MARKED_BASE - RAW in w.global_b._pytgcalls.calls  # preserved
    )
    return ok, f"terminal={terminal} metrics={metrics} api={w.global_b._pytgcalls.api_log}"


async def case_kb_owner_account(vc):
    """Test 4 — already-joined owned by SECONDARY account detected
    cross-backend (§13), preserved, no duplicate join."""
    w = await reset_world(vc)
    seed_group(RAW, title="KB-SEC", call_id=-555, call_ah=7777)
    w.join_on(w.b_b, RAW)  # account B owns it (global container empty)
    vc._vc_join_all_state["run_id"] = "kb_sec"
    terminal = await run_worker(vc)
    metrics = vc.v9810_join_metrics_snapshot()
    ok = (
        terminal in ("completed",)
        and metrics.get("already_joined_skipped", 0) == 1
        and metrics.get("already_owned_by_account", 0) == 1
        and not w.global_b._pytgcalls.api_log  # global did NOT duplicate-join
        and MARKED_BASE - RAW in w.b_b._pytgcalls.calls  # B preserved
    )
    return ok, (f"terminal={terminal} metrics={metrics} "
                f"b_api={w.b_b._pytgcalls.api_log}")


async def case_rotation_invariant(vc):
    """Test 5 + §29 — rotation never leaves the old account's VC; registry
    keeps the owner; explicit leave then uses the OWNER backend."""
    w = await reset_world(vc)
    w.join_on(w.a_b, RAW)  # Account 1 (acc_A) joins VC-A
    # Rotation: settle window + reset with preservation (v97.86/v98.08).
    vc._vc_rotation_settle_begin("acc_A", "acc_B")
    decision = vc.vc_reset_backend(preserve_connections=True)
    _rot_rec = await vc.vc_registry_get(RAW)
    owner_be = vc._v9809_leave_owner_backend(RAW, _rot_rec)
    rec = _rot_rec
    no_leave = (
        not w.a_b._pytgcalls.api_log  # NO leave happened
        and MARKED_BASE - RAW in w.a_b._pytgcalls.calls  # still connected
    )
    owner_ok = (
        owner_be is w.a_b  # owner resolution → Account 1's backend
        and rec is not None and rec.state == "joined"
        and rec.account_id == "acc_A"
    )
    # Explicit leave must go through Account 1's ACTUAL backend.
    outcome = await vc.vc_leave_target(RAW)
    left_ok = (
        outcome == "success"
        and ("leave_call", RAW) in w.a_b._pytgcalls.api_log
        and MARKED_BASE - RAW not in w.a_b._pytgcalls.calls
        and not w.b_b._pytgcalls.api_log  # B untouched
    )
    ok = decision == "preserved" and no_leave and owner_ok and left_ok
    return ok, (f"decision={decision} no_leave={no_leave} owner_ok={owner_ok} "
                f"leave_outcome={outcome} left_ok={left_ok}")


async def case_stop_preserves(vc):
    """Test 8 — Stop during a run preserves already-joined VCs; only future
    join attempts stop; pending discovery (bg refresh) cancelled."""
    w = await reset_world(vc)
    # Two fresh targets; first joins, then cancel before the second.
    seed_group(RAW, title="T1", call_id=-555, call_ah=7777)
    seed_group(RAW_B, title="T2", call_id=-556, call_ah=7778)
    vc._vc_join_all_state["run_id"] = "stop_case"

    # Simulate an already-joined VC that must survive the stop.
    w.join_on(w.b_b, 1393246704)
    seed_group(1393246704, title="OWNED", call_id=-557, call_ah=7779)

    worker_task = asyncio.get_running_loop().create_task(
        vc._vc_join_all_active_worker(), name="stop_case_worker")
    await asyncio.sleep(0.8)  # first join + stagger window
    vc._vc_join_all_cancel_token.cancel(reason="admin_stop")
    vc._vc_join_all_stop_requested = True
    try:
        await asyncio.wait_for(asyncio.shield(worker_task), timeout=30)
    except asyncio.TimeoutError:
        worker_task.cancel()
        await asyncio.gather(worker_task, return_exceptions=True)
    terminal = vc._vc_join_all_state.get("terminal_status", "?")
    preserved = (
        MARKED_BASE - 1393246704 in w.b_b._pytgcalls.calls
        and not w.b_b._pytgcalls.api_log
        and await vc.vc_registry_get(1393246704) is not None
    )
    bg_cancelled = not vc._vc_join_all_bg_refresh_running()
    vc._vc_join_all_stop_requested = False
    ok = terminal in ("stopped", "cancelled", "completed") and preserved \
        and bg_cancelled
    return ok, (f"terminal={terminal} preserved={preserved} "
                f"bg_cancelled={bg_cancelled}")


async def case_stale_refresh(vc):
    """Test 14 — stale active cache entry triggers Tier-2 refresh
    (detection RPC runs; the entry re-enters the fresh window)."""
    w = await reset_world(vc)
    seed_group(RAW, title="STALE", call_id=-555, call_ah=7777,
               active_at=time.time() - 3600)  # older than TTL (300s)
    vc._vc_join_all_state["run_id"] = "stale_case"
    terminal = await run_worker(vc)
    refreshed = _GROUPS[RAW]["last_active_vc_at"] > time.time() - 60
    ok = (
        terminal in ("completed",)
        and LEDGER.count("GetFullChannelRequest") >= 1  # Tier-2 refresh ran
        and refreshed  # freshness re-anchored
        and w.global_b._pytgcalls.api_log  # joined after refresh
    )
    return ok, (f"terminal={terminal} fullch={LEDGER.count('GetFullChannelRequest')} "
                f"refreshed={refreshed} api={len(w.global_b._pytgcalls.api_log)}")


async def case_duplicate_results(vc):
    """Test 9 — duplicate SearchGlobal pages yield ONE candidate per
    unique chat; the §11 offset_rate token flows to page 2."""
    w = await reset_world(vc)
    ch = _TLChannel(id=RAW, title="DUP", access_hash=111)
    # Page 1: FULL page with 50 unique chats; page 2: full page of
    # duplicates ONLY (the §11 zero-new-unique early-stop case).
    page1 = _TLSearchResponse(
        chats=[ch] + [_TLChannel(id=i, title=f"u{i}", access_hash=1)
                      for i in range(3000, 3048)] + [_TLChannel(id=3048, title="u3048")],
        next_rate=12345)
    page2 = _TLSearchResponse(chats=[ch] * 50, next_rate=6789)
    SCENARIO.search_pages = [page1, page2]
    entities: dict[int, dict] = {}
    raw_ents: dict[int, Any] = {}
    report = {"queries_attempted": [], "pages_searched": 0, "stages": {},
              "per_variant": []}
    await vc.DiscoveryManager._search_keyword(
        FakeClient(), "dup query", entities, raw_ents, report,
        source="exact")
    reqs = [r for k, r in LEDGER.calls if k == "SearchGlobalRequest"]
    ok = (len(entities) == 50 and report["pages_searched"] == 2
          and LEDGER.count("SearchGlobalRequest") == 2
          and len(reqs) == 2 and reqs[1].offset_rate == 12345
          and entities[RAW]["title"] == "DUP")
    return ok, (f"entities={len(entities)} pages={report['pages_searched']} "
                f"rates={[r.offset_rate for r in reqs]}")


async def case_adaptive_pagination(vc):
    """Test 11 — a duplicate-only page stops pagination early (2 RPCs, not
    3); a high-unique page continues within the hard cap."""
    w = await reset_world(vc)
    ch = _TLChannel(id=RAW, title="P1", access_hash=111)
    ch2 = _TLChannel(id=RAW_B, title="P2", access_hash=112)
    # Page 1 unique-rich (full page), page 2 duplicate-only → early stop.
    SCENARIO.search_pages = [
        _TLSearchResponse(chats=[ch] + [_TLChannel(id=i, title="x") for i in
                                        range(1000, 1049)], next_rate=1),
        _TLSearchResponse(chats=[ch], next_rate=2),  # only duplicates
        _TLSearchResponse(chats=[ch], next_rate=3),
    ]
    LEDGER.reset()
    entities: dict[int, dict] = {}
    report = {"queries_attempted": [], "pages_searched": 0, "stages": {},
              "per_variant": []}
    await vc.DiscoveryManager._search_keyword(
        FakeClient(), "ap query", entities, {}, report, source="exact")
    ok = (LEDGER.count("SearchGlobalRequest") == 2
          and report["pages_searched"] == 2)
    return ok, f"rpcs={LEDGER.count('SearchGlobalRequest')} pages={report['pages_searched']}"


async def case_metadata_reuse(vc):
    """Test 10 — Stage-10 metadata flows to classify: no duplicate
    GetFullChannel (tier3 reuse), correct active result."""
    w = await reset_world(vc)
    seed_group(RAW, title="META", call_id=-555, call_ah=7777)
    ent = SCENARIO.entities[RAW]
    LEDGER.reset()
    cls = await vc._vc_discovery_classify(
        FakeClient(), ent,
        prefetched={"vc_active": True, "vc_call_id": -555,
                    "vc_access_hash": 7777, "members_count": 42})
    ok = (
        cls["active_vc"] is True
        and cls["vc_info"] == {"call_id": -555, "access_hash": 7777,
                               "members": 42}
        and LEDGER.count("GetFullChannelRequest") == 0  # REUSED, not re-fetched
    )
    # Inactive prefetch → accessible, not active, still zero RPC.
    cls2 = await vc._vc_discovery_classify(
        FakeClient(), ent, prefetched={"vc_active": False})
    ok = ok and cls2["active_vc"] is False and cls2["vc_info"] is None \
        and LEDGER.count("GetFullChannelRequest") == 0
    # No prefetch → REAL probe fires (legacy behavior preserved).
    cls3 = await vc._vc_discovery_classify(FakeClient(), ent)
    ok = ok and cls3["active_vc"] is True \
        and LEDGER.count("GetFullChannelRequest") == 1
    return ok, f"cls={cls.get('active_vc')} fullch={LEDGER.count('GetFullChannelRequest')}"


async def case_floodwait_no_dup(vc):
    """Test 12 — FloodWait on the classification probe does NOT duplicate
    work: the candidate is excluded once, the query state is NOT re-probed,
    the run terminates cleanly."""
    w = await reset_world(vc)
    # Fresh-cache candidate but with a FloodWait response table + registry
    # joined state → forces the standard path (ambiguous) where the
    # detection RPC hits FloodWait.
    seed_group(RAW, title="FW", call_id=-555, call_ah=7777)
    SCENARIO.floodwait_on[RAW] = 5
    rec = vc.VCParticipationState(chat_id=RAW, state="joined",
                                  request_accepted=True)
    vc._vc_participations[RAW] = rec
    vc._vc_join_all_state["run_id"] = "fw_case"
    LEDGER.reset()
    terminal = await run_worker(vc)
    fw_probes = LEDGER.count("GetFullChannelRequest")
    ok = terminal in ("completed", "failed") and fw_probes <= 2
    return ok, f"terminal={terminal} fw_probes={fw_probes}"


async def case_search_no_dup_pipelines(vc):
    """§6 — search_full pipeline with results does NOT run the legacy
    SearchGlobal loop (single canonical search execution)."""
    w = await reset_world(vc)
    ch = _TLChannel(id=RAW, title="PIPE", access_hash=111)
    SCENARIO.entities[RAW] = ch
    SCENARIO.resolve_username["pipe"] = ch
    SCENARIO.search_pages = [
        _TLSearchResponse(chats=[ch], next_rate=0),
    ]
    LEDGER.reset()
    res = await vc._vc_discovery_public_search(
        FakeClient(), "pipe query", limit=10, max_pages=3)
    ok = (
        len(res) == 1
        # §6: the legacy loop uses per_page=min(max(10, limit),100)=10 while
        # the pipeline stages use per_page=50 — zero limit-10 requests proves
        # the legacy loop NEVER executed (single canonical search pipeline).
        and not any(r.limit == 10 for k, r in LEDGER.calls
                    if k == "SearchGlobalRequest")
    )
    return ok, f"res={len(res)} rpcs={LEDGER.count('SearchGlobalRequest')} legacy_style={sum(1 for k, r in LEDGER.calls if k == 'SearchGlobalRequest' and r.limit == 10)}"


async def case_adaptive_expansion(vc):
    """§10 — sufficient exact yield skips the expansion + fuzzy fan-out;
    zero-yield query keeps full variant coverage."""
    w = await reset_world(vc)
    # Sufficient yield: 45 unique chats (sub-full page → single RPC) with
    # max_results=45 → expansion skipped.
    chats = [_TLChannel(id=i, title=f"e{i}", access_hash=1)
             for i in range(2000, 2045)]
    for c in chats:
        SCENARIO.entities[c.id] = c
        SCENARIO.full_channel[c.id] = {"call": None, "members": 1}
    SCENARIO.search_pages = [
        _TLSearchResponse(chats=chats, next_rate=0),
    ]
    LEDGER.reset()
    rep = await vc.DiscoveryManager.search_full(
        "sufficient", max_results=45, expand=True, include_broadcasts=False)
    ok = (
        rep["stages"].get("expansion_skipped_reason") == "sufficient_exact_yield"
        and rep["stages"].get("fuzzy_skipped_reason") == "sufficient_exact_yield"
        and LEDGER.count("SearchGlobalRequest") == 1
    )
    # Zero-yield: no results anywhere → expansion + fuzzy still run.
    SCENARIO.search_pages = []
    LEDGER.reset()
    rep2 = await vc.DiscoveryManager.search_full(
        "nothing", max_results=45, expand=True, include_broadcasts=False)
    ok2 = (
        rep2["stages"].get("expansion_skipped_reason") is None
        and rep2["stages"].get("fuzzy_skipped_reason") is None
        and LEDGER.count("SearchGlobalRequest") >= 3  # exact + variant fan-out ran
    )
    return ok and ok2, (f"skip={rep['stages'].get('expansion_skipped_reason')} "
                        f"rpcs={LEDGER.count('SearchGlobalRequest')} "
                        f"zero_case_full={ok2}")


async def case_cancels_pending(vc):
    """Test 13 — cancellation stops pending discovery work (the bg refresh
    task is cancelled; no orphaned iter_dialogs)."""
    w = await reset_world(vc)
    seed_group(RAW, title="C", call_id=-555, call_ah=7777)
    SCENARIO.dialogs = [FakeDialog(_TLChannel(id=i, title=f"d{i}"))
                        for i in range(3000, 3300)]
    vc._vc_join_all_state["run_id"] = "cancel_case"
    worker_task = asyncio.get_running_loop().create_task(
        vc._vc_join_all_active_worker(), name="cancel_worker")
    await asyncio.sleep(0.3)
    worker_task.cancel()
    try:
        await asyncio.wait_for(asyncio.shield(worker_task), timeout=10)
    except (asyncio.CancelledError, asyncio.TimeoutError):
        await asyncio.gather(worker_task, return_exceptions=True)
    # The worker's finally must have cancelled the bg refresh task.
    await asyncio.sleep(0.2)
    ok = not vc._vc_join_all_bg_refresh_running()
    return ok, f"bg_running={vc._vc_join_all_bg_refresh_running()}"


async def case_no_cache_full_discovery(vc):
    """Control — empty knowledge cache keeps the EXACT legacy path
    (dialog discovery on the critical path, then classification)."""
    w = await reset_world(vc)
    gid = 3001
    seed_group(gid, title="LEGACY", call_id=None)  # no active knowledge
    _GROUPS.clear()  # empty cache → fast path OFF
    SCENARIO.entities[gid] = _TLChannel(id=gid, title="LEGACY", access_hash=1)
    SCENARIO.full_channel[gid] = {
        "call": _TLGroupCall(-999, 888), "members": 5}
    SCENARIO.dialogs = [FakeDialog(SCENARIO.entities[gid])]
    vc._vc_join_all_state["run_id"] = "legacy_case"
    terminal = await run_worker(vc)
    metrics = vc.v9810_join_metrics_snapshot()
    ok = (
        terminal in ("completed",)
        and LEDGER.count("iter_dialogs") == 1  # dialog scan DID run
        and metrics.get("fast_path_used", 0) == 0
        and w.global_b._pytgcalls.api_log  # joined via standard path
    )
    return ok, (f"terminal={terminal} dialogs={LEDGER.count('iter_dialogs')} "
                f"metrics={metrics.get('fast_path_used')} "
                f"api={len(w.global_b._pytgcalls.api_log)}")


async def case_leave_owner_backend_fallback(vc):
    """Test 7 — leave uses the ACTUAL owner backend (P2 regression guard,
    re-proven in the P3 world with the fast-path section present)."""
    w = await reset_world(vc)
    w.join_on(w.a_b, RAW)
    outcome = await vc.vc_leave_target(RAW)
    ok = (outcome == "success"
          and ("leave_call", RAW) in w.a_b._pytgcalls.api_log
          and MARKED_BASE - RAW not in w.a_b._pytgcalls.calls
          and not w.global_b._pytgcalls.api_log)
    return ok, f"outcome={outcome} a_api={w.a_b._pytgcalls.api_log}"


async def case_manual_leave_joinall_call(vc):
    """Test 6 — manual Leave works for a Join-All-created (per-account)
    call: fallback path stops the worker + leaves tracked VCs."""
    w = await reset_world(vc)
    w.join_on(w.a_b, RAW)
    w.join_on(w.b_b, RAW_B)
    vc._vc_join_all_running = True  # simulate an active run
    _fut = asyncio.get_running_loop().create_future()
    asyncio.get_running_loop().call_later(
        0.3, lambda: _fut.done() or _fut.set_result(None))
    vc._vc_join_all_worker = _fut
    res = await vc.vc_manual_leave()
    vc._vc_join_all_running = False
    ok = str(res).startswith("left_tracked") \
        and MARKED_BASE - RAW not in w.a_b._pytgcalls.calls \
        and MARKED_BASE - RAW_B not in w.b_b._pytgcalls.calls
    return ok, f"res={res}"


CASES = [
    ("KB-FASTPATH", case_kb_fastpath),
    ("KB-ALREADY-JOINED", case_kb_already_joined),
    ("KB-OWNER-ACCOUNT", case_kb_owner_account),
    ("ROTATION-INVARIANT", case_rotation_invariant),
    ("STOP-PRESERVES", case_stop_preserves),
    ("STALE-REFRESH", case_stale_refresh),
    ("DUP-RESULTS", case_duplicate_results),
    ("ADAPTIVE-PAGINATION", case_adaptive_pagination),
    ("METADATA-REUSE", case_metadata_reuse),
    ("FLOODWAIT-NO-DUP", case_floodwait_no_dup),
    ("SEARCH-NO-DUP-PIPELINES", case_search_no_dup_pipelines),
    ("ADAPTIVE-EXPANSION", case_adaptive_expansion),
    ("CANCELS-PENDING", case_cancels_pending),
    ("NO-CACHE-LEGACY", case_no_cache_full_discovery),
    ("LEAVE-OWNER-BACKEND", case_leave_owner_backend_fallback),
    ("MANUAL-LEAVE-JOINALL", case_manual_leave_joinall_call),
]


def main() -> int:
    async def _run():
        vc = import_voicechat()
        failed = 0
        for case_id, fn in CASES:
            try:
                ok, detail = await fn(vc)
            except Exception as exc:  # noqa: BLE001
                ok, detail = False, f"EXC {type(exc).__name__}: {exc}"
            status = "PASS" if ok else "FAIL"
            print(f"CASE {case_id}: {status} — {detail}")
            if not ok:
                failed += 1
        return failed

    failed = asyncio.run(_run())
    print(f"SUMMARY: {len(CASES) - failed}/{len(CASES)} cases passed")
    return failed


if __name__ == "__main__":
    sys.exit(main())
