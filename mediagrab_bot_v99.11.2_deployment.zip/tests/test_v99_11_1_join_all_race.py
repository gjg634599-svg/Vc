"""v99.11.1 FIX-3 — THE JOIN-ALL ALREADY-JOINED RACE SUITE.

PRODUCTION EVIDENCE (2026-09-22/23 diagnostic logs, 64 error instances
/ 98 breaker events):

    VC_GROUP_OWNER_RESOLVED chat_id=<id> owner=<account> source=active_backend
    VC_JOIN_SKIPPED_ALREADY_OWNED chat_id=<id> owner=<account> requester=<other>
    VC_JOIN_ALL_TARGET_FAILURE chat_id=<id> reason=transport_error
      exc=VCTransportError: Chat <id> is already joined by account
      <account>; one-group-one-account invariant (v99.06).
    JOIN_ALL_BREAKER failure recorded: VCTransportError x1/3  … x3
    JOIN_ALL_BREAKER CLOSED → OPEN  →  HALF_OPEN → OPEN (probe failed)
    … eventually permanently open.

ROOT CAUSE: the snapshot/dispatch race.  The Join-All snapshot marks a
target eligible (unjoined); a concurrent path (reconcile re-verify,
deferred drain, the previous run's still-converging state) registers
ownership between the snapshot and the dispatch; the v99.06 gate raises
the already-joined VCTransportError at the join boundary (BEFORE any
native allocation — zero RPCs); the worker's generic transport-failure
classification counted it as a breaker failure → 3 conflicts opened the
breaker → the half-open probes re-hit the SAME conflicts → the storm.

THE v99.11.1 FIX: same-account already-joined converges idempotently
(result=already_joined, registry→joined, breaker count UNCHANGED, no
retry, no duplicate transport); different/unknown owner RETAINS the
conflict semantics (the one-group-one-account invariant is never
weakened into a false same-account success).

§A — source contracts (worker wiring).
§B — behavioral regression (subprocess): tests/_v9911_1_race_driver.py
      runs the REAL worker end-to-end through the exact 4-step race.
"""

from __future__ import annotations

import os
import subprocess
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

_ROOT = str(Path(__file__).resolve().parents[1])
_VC = os.path.join(_ROOT, "mediagrab_bot", "voicechat.py")
_DRIVER = os.path.join(_ROOT, "tests", "_v9911_1_race_driver.py")


def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


class TestRaceSourceContracts(unittest.TestCase):
    """§A — the worker wiring (machine-searchable)."""

    def setUp(self):
        self.src = _read(_VC)

    def test_a1_classification_helper_exists(self):
        self.assertIn("def _v9911_classify_already_joined_exc(", self.src)
        self.assertIn("_V9911_AJ_OWNER_RE", self.src)

    def test_a2_handler_uses_the_helper(self):
        self.assertIn(
            "_v9911_aj_is, _v9911_aj_owner, _v9911_aj_dispatch_eff, \\",
            self.src)
        self.assertIn(
            "= _v9911_classify_already_joined_exc(", self.src)

    def test_a3_converged_branch_skips_failure_accounting(self):
        """The converged branch must set result=already_joined and the
        failure-classification chain must be gated BEHIND it
        (``if _v9911_aj_converged: pass`` / ``elif _is_entity_error:`` /
        ``else:`` — the converged outcome never reaches the failure
        accounting)."""
        self.assertIn('result_state = "already_joined"', self.src)
        self.assertIn("if _v9911_aj_converged:", self.src)
        # The converged gate sits BEFORE the entity-error BRANCH in the
        # same if/elif chain.
        idx_conv = self.src.find("if _v9911_aj_converged:")
        self.assertGreater(idx_conv, 0)
        idx_entity_branch = self.src.find("elif _is_entity_error:",
                                          idx_conv)
        self.assertGreater(idx_entity_branch, idx_conv)
        # The converged branch body is a pure pass (no accounting calls).
        seg = self.src[idx_conv:idx_entity_branch]
        self.assertNotIn("record_failure", seg)
        self.assertNotIn("_vc_join_account_record_failure", seg)

    def test_a4_convergence_markers(self):
        self.assertIn("VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONVERGED", self.src)
        self.assertIn("VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONFLICT", self.src)

    def test_a5_registry_convergence_call(self):
        """The converged branch syncs the registry to joined (mirroring
        the snapshot's ALREADY_JOINED sync)."""
        seg = self.src.split("VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONVERGED", 2)
        self.assertGreaterEqual(len(seg), 2)
        after = seg[1][:2500]
        self.assertIn("vc_registry_update(", after)
        self.assertIn('state="joined"', after)
        self.assertIn("request_accepted=True", after)

    def test_a6_conflict_branch_retains_semantics(self):
        """Different/unknown owner keeps the conflict/error semantics —
        the marker explicitly says NOT converted to same-account
        success, and the flow continues into the existing failure
        classification below."""
        seg = self.src.split(
            "VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONFLICT", 2)
        self.assertGreaterEqual(len(seg), 2)
        after = seg[1][:1600]
        self.assertIn("NOT converted to", after)
        self.assertIn("same-account success", after)

    def test_a7_coordinator_completes_already_joined_as_joined(self):
        """``already_joined`` completes the coordinator op with
        success=True → the coordinator state converges to JOINED."""
        self.assertIn(
            'success=(result_state in ("joined_confirmed",\n'
            "                                                      "
            '"joined_unverified",\n'
            '                                                      "already_joined")),',
            self.src)

    def test_a8_progress_bucket_wired(self):
        """result_state=already_joined is counted by the existing
        progress bookkeeping (the v97.84 bucket)."""
        self.assertIn('elif result_state == "already_joined":', self.src)
        self.assertIn('prog["already_joined"] += 1', self.src)


class TestRaceBreakerSemantics(unittest.TestCase):
    """The REAL circuit breaker's counting semantics (join_all_worker)."""

    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, _ROOT)
        from mediagrab_bot.join_all_worker import CircuitBreaker
        cls.CircuitBreaker = CircuitBreaker

    def test_b1_three_conflicts_open_the_breaker(self):
        """The production storm baseline: 3 transport failures (the
        pre-fix behavior) OPEN the breaker — this is the semantics the
        diff-account case RETAINS."""
        import asyncio

        async def _run():
            b = self.CircuitBreaker(failure_threshold=3,
                                    cooldown_seconds=60.0)
            opened = False
            for _ in range(3):
                opened = await b.record_failure(
                    "VCTransportError",
                    reason="VCTransportError: Chat 1 is already joined "
                           "by account acc_X; one-group-one-account "
                           "invariant (v99.06).",
                    is_systemic=False)
            return b, opened

        b, opened = asyncio.run(_run())
        self.assertTrue(opened)
        self.assertEqual(b.state.value, "open")
        self.assertEqual(b._failures.get("VCTransportError", 0), 3)

    def test_b2_zero_failures_keeps_it_closed(self):
        """The post-fix same-account storm: zero recorded failures →
        CLOSED (what RACE-STORM-GREEN asserts end-to-end)."""
        import asyncio

        async def _run():
            b = self.CircuitBreaker(failure_threshold=3,
                                    cooldown_seconds=60.0)
            return b

        b = asyncio.run(_run())
        self.assertEqual(b.state.value, "closed")
        self.assertEqual(b._failures, {})


class TestRaceBehavioralDriver(unittest.TestCase):
    """§B — the REAL worker through the exact 4-step race (subprocess).

    1. Join-All snapshot says the target is unjoined;
    2. the backend/fixture changes state to joined by the SAME account;
    3. the native join raises the exact already-joined
       VCTransportError;
    4. Join-All processes that exception.

    Expected (RACE-SAME-ACCOUNT): result=already_joined / idempotent
    success; breaker failure count UNCHANGED; breaker remains CLOSED;
    registry converges to joined; NO duplicate transport is created.
    Also: already joined by a DIFFERENT owner must NOT be silently
    converted into same-account success (RACE-DIFF-ACCOUNT).
    """

    @classmethod
    def setUpClass(cls):
        cls.proc = subprocess.run(
            [sys.executable, _DRIVER],
            capture_output=True, text=True, timeout=180,
            cwd=_ROOT,
        )
        cls.out = cls.proc.stdout + cls.proc.stderr

    def test_c1_driver_exit_code_zero(self):
        self.assertEqual(
            self.proc.returncode, 0,
            f"driver failures:\n{self.out[-4000:]}")

    def test_c2_same_account_race_converges(self):
        self.assertIn("CASE RACE-SAME-ACCOUNT: PASS", self.out)

    def test_c3_same_account_convergence_marker_emitted(self):
        self.assertIn("VC_JOIN_ALL_TARGET_ALREADY_JOINED_CONVERGED", self.out)

    def test_c4_different_owner_conflict_retained(self):
        self.assertIn("CASE RACE-DIFF-ACCOUNT: PASS", self.out)

    def test_c5_storm_stays_closed(self):
        """The exact production x3 storm (3 consecutive already-joined
        conflicts) now stays CLOSED and completes green."""
        self.assertIn("CASE RACE-STORM-GREEN: PASS", self.out)

    def test_c6_driver_summary(self):
        self.assertIn("SUMMARY: 3/3 cases passed", self.out)


if __name__ == "__main__":
    unittest.main()
