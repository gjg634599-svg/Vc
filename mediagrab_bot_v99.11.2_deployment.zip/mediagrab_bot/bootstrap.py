"""Bootstrap module — application startup, shutdown, and main entry point.

Extracted from _bot_core.py. Contains:
  - Error handler (_on_error)
  - Task dump diagnostics (_dump_running_tasks, _task_dump_loop)
  - Event-loop lag monitor (_event_loop_lag_monitor)
  - Scheduled loop (_scheduled_loop)
  - Watchdog (_watchdog_loop, _watchdog_start, _WATCHDOG_TASKS)
  - Cluster reconnect loop
  - Startup validation (_cluster_startup_validate_bg)
  - PTB post_init / post_stop hooks
  - build_application() — wires all PTB handlers
  - V85 infrastructure classes (InstanceGuard, ButtonRegistry, etc.)
  - V96 TaskSupervisor, RuntimeControllerV96
  - main() — entry point

Dependencies: imports subsystem functions from _bot_core for VC, Talkative,
MTProto, Discovery, etc. These will be replaced with direct module imports
as those subsystems are extracted in future phases.
"""
# v99.07 FIX-44 (comment hygiene): the historical vXX FIX-ZZ narratives in
# this file are largely TEST-PINNED — the static-analysis suite asserts on
# them as contracts (e.g. assertIn("v98.08 FIX-BBB", ...)), so blind
# removal breaks the suite. The safely removable narrative lines were
# removed (see git); the remaining corpus is contractual documentation.


from __future__ import annotations

import asyncio
import inspect
import json
import os
import re
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Any, Awaitable, Callable, Optional

# v98.07 FIX-SS: faulthandler at module level (the heartbeat canary thread
# dumps all thread stacks on a stale liveness stamp).
import faulthandler  # noqa: E402

from telegram import Update, InlineKeyboardMarkup
from telegram.ext import (Application, ApplicationBuilder, CallbackQueryHandler,
                          CommandHandler, InlineQueryHandler, MessageHandler,
                          ContextTypes, filters)
from telegram.error import BadRequest, Forbidden, NetworkError, TimedOut

from .db_layer import init_db, close_db
from .utils_real import (
    register_bot, safe_reply_text, safe_edit_message_text, safe_send_message,
    periodic_cleanup,
)
from .ui_keyboards import vc_menu

# MTProto layer — extracted to mediagrab_bot/mtproto.py (real implementation).
from .mtproto import (
    get_userbot_cluster,
    mtproto_get_client,
    mtproto_take_screenshot,
    resolve_entity_full,
    ROLE_PRIMARY, STATUS_CONNECTION_FAILED,
    # v98.01 FIX-K / BUG-A5-5: added STATUS_FLOODWAIT + STATUS_DISCONNECTED
    # so _cluster_reconnect_loop can retry FloodWait-after-expiry and
    # DISCONNECTED accounts (was silently stuck before).
    STATUS_FLOODWAIT, STATUS_DISCONNECTED,
)

# VC layer — extracted to mediagrab_bot/voicechat.py
from .voicechat import (
    vc_get_backend, vc_get_status, vc_build_active_queue, vc_discover_groups,
    vc_dashboard_menu, vc_dashboard_text,
    vc_discovery_start, vc_discovery_stop, vc_discovery_get_state,
    vc_discovery_get_metrics, vc_discovery_get_recent_runs,
    vc_discovery_list_queries, vc_discovery_add_query,
    vc_discovery_remove_query, vc_discovery_enable_query,
    vc_discovery_clear_queries, vc_discovery_reset_metrics,
    vc_discovery_search_query_now, vc_discovery_run_cycle,
    get_vc_coverage_manager, vc_reset_backend,
    vc_start_tour, vc_stop_tour, vc_pause_tour, vc_resume_tour, vc_tour,
    vc_watcher_start, vc_watcher_stop, vc_leave_target, vc_manual_leave,
    vc_skip_current, vc_registry_get, vc_join_all_active_start,
    vc_join_all_active_stop, vc_leave_all_tracked,
    vc_join_all_startup_recovery, vc_join_all_resume,
    auto_discovery_start, auto_discovery_stop, auto_discovery_state,
    _vc_reconcile_start, _vc_reconcile_stop, _vc_reconcile_task,
    _vc_watcher_state, _vc_watcher_task, _vc_join_all_running,
    _vc_known_call_ids, _vc_target_cooldowns, _vc_entity_cache,
    _vc_entity_cache_by_client, _vc_is_admin,
    _vc_dashboard_auto_refresh_start, _vc_dashboard_auto_refresh_stop_all,
    _vc_join_all_auto_refresh_stop_all, _vc_dedup_check, _vc_dm_with_fallback,
    _vc_execute_manual_join, _vc_mtproto_ok, _vc_scan_counts, _vc_status_text,
    _vc_discovery_builtin_defaults, _vc_discovery_current_mode,
    _deferred_queue_start, _deferred_queue_stop_worker, _deferred_queue_task,
)

# Talkative layer — extracted to mediagrab_bot/talkative.py
from .talkative import (
    talkative_apply_effective_runtime, talkative_effective_enabled,
    talkative_effective_provider,
    _talkative_cleanup_task, _talkative_fetch_bot_identity,
    _talkative_handle_message_wrapper, _talkative_start_cleanup_task,
    _talkative_stop_cleanup_task, _provider_get_state, _provider_init_states,
    _provider_record_failure, _media_seed_default_library,
)

# Multimodal layer — extracted to mediagrab_bot/multimodal.py
from .multimodal import register_multimodal_handler, _app_voice_enroll_register, _voice_enroll_selfcheck_async
from .frame_extractor import witai_service

# Handler layer — extracted to mediagrab_bot/handlers.py
from .handlers import (
    start_command, route_callback, route_message, help_command, _menu_edit,
    repo, kb, msg, states,
    admin_handler, inline_handler,
    mtproto_handler, scheduled_handler,
    _dashboard_snapshot_start, _dashboard_live_start, _dashboard_live_stop,
    _bot_heartbeat_start, _bot_history_start,
    mtproto_manager, _active_tasks,
)
from .voicechat import vc_handler, _auto_discovery_task
from .talkative import talkative_handler
# v99.07 FIX-33: supervised_create_task is imported from its DEFINING
# module (utils_real) — the package __init__ re-exports it via bootstrap,
# which previously relied on the transitive handlers import (import-order
# dependent: if the handlers import list ever dropped it, the re-export
# would AttributeError at package import time).
from .utils_real import (
    setup_logging, _install_asyncio_handler, _ErrorDedupFilter,
    supervised_create_task,
)

# Config + diagnostics
from .config import config
from .diag_hooks import v85_diag
import logging
logger = logging.getLogger("mediagrab")

# V85 diagnostics (defined in bootstrap itself, below)
# v85_diag_snapshot, _V85_PID_FILE, _V85_DIAG_ENABLED are defined in this module.


async def _on_error(update: object, context) -> None:
    """PTB global error handler.

    Any exception raised inside a handler that isn't caught locally ends up
    here. We log it with full context so it's debuggable, but the bot keeps
    running — a single bad update never terminates the process.
    """
    error = getattr(context, "error", None)
    if error is None:
        logger.error("PTB error handler invoked with no error object.")
        return
    # Extract the update id for traceability.
    update_id = getattr(update, "update_id", "?")
    # V63 Fix: NetworkError (DNS failure, connection refused, bad gateway)
    # is a transient infrastructure issue — log it at WARNING (not ERROR)
    # to reduce log noise during outages. PTB's polling loop auto-retries.
    if isinstance(error, NetworkError):
        logger.warning(
            "Network error in update %s: %s: %s (PTB will auto-retry)",
            update_id, type(error).__name__, error,
        )
        return  # Don't try to notify the user — send_message will also fail.
    # V87.2: wrap logger.error in try/except so a _ErrorDedupFilter crash
    # (or any other logging infrastructure failure) cannot prevent _on_error
    # from notifying the user.
    try:
        logger.error(
            "Unhandled exception in update %s: %s: %s",
            update_id, type(error).__name__, error,
            exc_info=context.error,
        )
    except Exception:
        # Last resort: write to stderr directly.
        import sys as _sys
        _sys.stderr.write(f"LOGGING CRASH in _on_error: {type(error).__name__}: {error}\n")
    # Best-effort: notify the user that something went wrong (only for
    # updates that carry a chat). We use plain text to avoid any chance of
    # a secondary parse error.
    try:
        if isinstance(error, (BadRequest, Forbidden)):
            # These are usually user-facing (chat not found, blocked, etc.)
            # — don't try to reply, just log.
            return
        chat = getattr(getattr(update, "effective_chat", None), "id", None)
        if chat and not isinstance(error, (BadRequest, Forbidden, NetworkError, TimedOut)):
            await context.bot.send_message(
                chat_id=chat,
                text=(
                    "⚠️ An unexpected error occurred while processing your "
                    "request. Please try again, or use /start to return to "
                    "the main menu."
                ),
            )
    except Exception:  # noqa: BLE001
        pass


# V93 FIX: Task-dump diagnostic for stuck-task detection.
# Logs all running asyncio tasks with their names + stack frames so the
# admin can see exactly which coroutine is stuck when the bot freezes.
_task_dump_last_at: float = 0.0


def _dump_running_tasks(reason: str = "manual") -> None:
    """Log all running asyncio tasks with names, running time, and await point.

    V94 ENHANCED: includes task running time (seconds since creation) and
    the current await point (file:line:function) for each task.

    Call this when the bot appears frozen to see which coroutine is stuck.
    Safe to call from any context (sync or async).

    v98.08 FIX-BBB (F7', RUNTIME-PROVEN: 1,183 TASK_DUMP lines ≈ 7.6% of
    the v98.07 soak log — 16 lag-triggered dumps × ~70 lines each, most
    re-listing the SAME 16 persistent loops). RATE LIMIT: lag-triggered
    dumps (reason startswith event_loop_lag) are limited to 1 full dump
    per 60s; suppressed requests emit ONE counter line
    (TASK_DUMP_SUPPRESSED). Manual/admin dumps bypass the limit. The
    canary's faulthandler dump is a SEPARATE mechanism and is never
    affected.
    """
    global _task_dump_last_at, _v808_task_dump_last_full, _v808_task_dump_suppressed
    import time as _t
    now = _t.monotonic()
    _task_dump_last_at = now
    # v98.08 FIX-BBB: rate-limit lag-triggered full dumps (1/60s).
    _v808_rate_limited = reason.startswith("event_loop_lag") and (
        now - _v808_task_dump_last_full) < 60.0
    if _v808_rate_limited:
        _v808_task_dump_suppressed += 1
        try:
            loop = asyncio.get_event_loop()
            _v808_total = len(asyncio.all_tasks(loop))
        except Exception:  # noqa: BLE001
            _v808_total = -1
        logger.warning(
            "TASK_DUMP_SUPPRESSED n=%d window=60s reason=%s total_tasks=%d "
            "— rate-limited (max 1 full dump/60s; v98.08 FIX-BBB; canary "
            "dumps unaffected)",
            _v808_task_dump_suppressed, reason, _v808_total)
        return
    _v808_task_dump_last_full = now
    # v99.07 FIX-15: reset the suppression counter when a full dump is
    # actually emitted — TASK_DUMP_SUPPRESSED n= now reports per-window
    # counts instead of a monotonic process-lifetime total that could
    # never decrease.
    _v808_task_dump_suppressed = 0
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        logger.warning("TASK_DUMP reason=%s error=no_running_loop", reason)
        return
    tasks = asyncio.all_tasks(loop)
    logger.warning(
        "TASK_DUMP reason=%s total_tasks=%d — listing all running coroutines:",
        reason, len(tasks),
    )
    # V94: sort by running time descending (longest-running first) so the
    # most likely stuck tasks appear at the top.
    # v99.07 FIX-14: REAL running-time ordering — asyncio tasks expose no
    # creation time, so a first-seen registry maintained by THIS dump
    # approximates age across dumps (ids present now inherit their earlier
    # first-seen timestamp; new ids start at 'now'). The old key (0, name)
    # was pure lexicographic — the docstring's promise was never delivered.
    # globals().setdefault keeps the v98.08 exec-extraction contract working
    # when this function body runs with a minimal namespace.
    _v9907_first_seen = globals().setdefault("_task_first_seen", {})  # type: ignore[index]
    _v9907_now = _t.monotonic()
    _v9907_seen_now = {
        id(t): _v9907_first_seen.get(id(t), _v9907_now) for t in tasks
    }
    _v9907_first_seen.clear()
    _v9907_first_seen.update(_v9907_seen_now)

    def _task_sort_key(t: asyncio.Task) -> tuple:
        # v99.07 FIX-14: (age descending, name) — longest-running first.
        return (-(_v9907_now - _v9907_seen_now[id(t)]), t.get_name() or "")

    for i, task in enumerate(sorted(tasks, key=_task_sort_key)):
        name = task.get_name() or "<unnamed>"
        done = task.done()
        cancelled = task.cancelled()
        # Get the coroutine's current frame for stack info.
        coro = task.get_coro()
        frame = None
        if coro is not None and hasattr(coro, "cr_frame") and coro.cr_frame is not None:
            frame = coro.cr_frame
        frame_info = ""
        if frame is not None:
            code = frame.f_code
            # V94: show function name + line + a snippet of the source if possible.
            try:
                source_line = ""
                import linecache
                src = linecache.getline(code.co_filename, frame.f_lineno).strip()
                if src:
                    source_line = f" [{src[:80]}]"
                frame_info = f" at {code.co_filename}:{frame.f_lineno} in {code.co_name}(){source_line}"
            except Exception:  # noqa: BLE001
                frame_info = f" at {code.co_filename}:{frame.f_lineno} in {code.co_name}()"
        status = "done" if done else ("cancelled" if cancelled else "running")
        # V94: include cancellation state.
        cancel_msg = ""
        if cancelled:
            cancel_msg = " (cancelled)"
        elif task.cancelling() > 0:
            cancel_msg = f" (cancelling={task.cancelling()})"
        logger.warning(
            "TASK_DUMP [%d] name=%s status=%s%s%s",
            i, name, status, cancel_msg, frame_info,
        )
    # V96: also dump the TaskSupervisor registry (service-level view).
    try:
        _ts_snapshot = TaskSupervisor.snapshot()
        if _ts_snapshot:
            logger.warning(
                "TASK_DUMP_SERVICES registered=%d — service registry:",
                len(_ts_snapshot),
            )
            for svc in _ts_snapshot:
                logger.warning(
                    "TASK_DUMP_SERVICE name=%s state=%s uptime=%.1fs "
                    "restart_policy=%s feature_flag=%s feature_enabled=%s "
                    "restart_count=%d last_error=%s",
                    svc["name"], svc["state"], svc["uptime_s"],
                    svc["restart_policy"], svc["feature_flag"],
                    svc["feature_enabled"], svc["restart_count"],
                    (svc["last_error"] or "")[:80],
                )
    except Exception:  # noqa: BLE001
        pass

    # v97.75/v97.76 RUNTIME INSTRUMENTATION: categorize tasks by type.
    # v97.76 FIX: the v97.75 categorization checked `frame_info` (filename:lineno)
    # for function names like "_dispatch_update" — but function names live in
    # `co_name`, NOT in the filename. This caused 67 _dispatch_update tasks to
    # be miscategorized as "other" (runtime log note 46 showed
    # `other=99, mtproto_other=2` when the real breakdown was 67 _dispatch_update
    # + 11 mtproto_safe_reconnect). v97.76 fixes this by checking co_name too.
    try:
        _cat_counts: dict[str, int] = {}
        for task in tasks:
            name = task.get_name() or ""
            coro = task.get_coro()
            frame_info = ""
            func_name = ""
            if coro is not None and hasattr(coro, "cr_frame") and coro.cr_frame is not None:
                f = coro.cr_frame
                frame_info = f"{f.f_code.co_filename}:{f.f_lineno}"
                func_name = f.f_code.co_name or ""
            # v97.76: categorize by NAME first (task name is most reliable for
            # supervised tasks), then by func_name, then by frame_info.
            combined = f"{name} {func_name} {frame_info}"
            if "mtproto_safe_reconnect" in name or "mtproto_safe_reconnect" in func_name:
                _cat_counts["mtproto_safe_reconnect"] = _cat_counts.get("mtproto_safe_reconnect", 0) + 1
            elif "handle_mtproto_updates" in combined:
                _cat_counts["pytgcalls_handle_mtproto_updates"] = _cat_counts.get("pytgcalls_handle_mtproto_updates", 0) + 1
            elif "pytgcalls" in frame_info:
                _cat_counts["pytgcalls_other"] = _cat_counts.get("pytgcalls_other", 0) + 1
            elif "_dispatch_update" in func_name or "_dispatch_update" in combined:
                _cat_counts["telethon_dispatch_update"] = _cat_counts.get("telethon_dispatch_update", 0) + 1
            elif "telethon" in frame_info and ("_send_loop" in func_name or "_recv_loop" in func_name or "_update_loop" in func_name or "_keepalive_loop" in func_name):
                _cat_counts["telethon_background"] = _cat_counts.get("telethon_background", 0) + 1
            elif "voicechat.py" in frame_info and "_vc_callback_worker" in func_name:
                _cat_counts["vc_callback_workers"] = _cat_counts.get("vc_callback_workers", 0) + 1
            elif "voicechat.py" in frame_info and ("join_all" in func_name or "join_all" in name):
                _cat_counts["vc_join_all"] = _cat_counts.get("vc_join_all", 0) + 1
            elif "voicechat.py" in frame_info and "reconcile" in func_name:
                _cat_counts["vc_reconcile"] = _cat_counts.get("vc_reconcile", 0) + 1
            elif "mtproto.py" in frame_info and ("_telethon_drain" in func_name or "_forcibly_cancel" in func_name):
                _cat_counts["mtproto_reconnect"] = _cat_counts.get("mtproto_reconnect", 0) + 1
            elif "mtproto.py" in frame_info:
                _cat_counts["mtproto_other"] = _cat_counts.get("mtproto_other", 0) + 1
            else:
                _cat_counts["other"] = _cat_counts.get("other", 0) + 1
        _cat_str = ", ".join(f"{k}={v}" for k, v in sorted(_cat_counts.items(), key=lambda x: -x[1]))
        logger.warning("TASK_DUMP_CATEGORIES total=%d — %s", len(tasks), _cat_str)
        # v97.76 P0: RECONNECT_TASK_STORM alert — fires when more than 1
        # mtproto_safe_reconnect task exists. This is the PRIMARY root cause
        # proven by note 46 (11-14 simultaneous tasks). v97.76's strict
        # single-flight fix should keep this at 0 or 1.
        _reconnect_tasks = _cat_counts.get("mtproto_safe_reconnect", 0)
        if _reconnect_tasks > 1:
            logger.error(
                "RECONNECT_TASK_STORM mtproto_safe_reconnect_tasks=%d "
                "(expected ≤1; v97.76 strict single-flight FAILED). "
                "Each excess task is a trigger that created its own task instead "
                "of sharing the single-flight task. If this fires after v97.76, "
                "a call site was missed or the shared-task guard is broken.",
                _reconnect_tasks,
            )
        # v97.75/v97.78: generation-coexistence alert.
        # v97.78 FIX: the v97.75 threshold (>6) was a FALSE POSITIVE for
        # multi-account bots. The bot legitimately runs 1 primary client +
        # N cluster account clients, each with 6 background tasks. So the
        # expected count is 6 * (1 + N_active_cluster_accounts).
        # The runtime log (note 48) showed telethon_background=12 with ZERO
        # disconnect/reconnect events — proving 12 = 2 legitimate clients
        # (primary + 1 cluster account), NOT generation coexistence.
        _tlg_bg = _cat_counts.get("telethon_background", 0)
        _expected_clients = 1  # primary
        try:
            from .mtproto import get_cluster_router
            _router = get_cluster_router()
            for _aid, _acc in list(_router._cluster._accounts.items()):
                if _acc.get("status") in ("healthy", "connected"):
                    _expected_clients += 1
        except Exception:  # noqa: BLE001
            pass
        _expected_bg = 6 * _expected_clients
        if _tlg_bg > _expected_bg:
            _excess = _tlg_bg - _expected_bg
            logger.error(
                "TELETHON_GENERATION_COEXISTENCE telethon_background_tasks=%d "
                "(expected ≤%d for %d client(s); %d excess = %.1f extra generations) — "
                "If this fires, the forced-cancel fix is not working OR a client "
                "was created without retiring the old one.",
                _tlg_bg, _expected_bg, _expected_clients, _excess, _excess / 6.0,
            )
        elif _tlg_bg > 6 and _tlg_bg <= _expected_bg:
            # Log at INFO so operators see the multi-client state without alarm
            logger.info(
                "TELETHON_BACKGROUND_OK telethon_background_tasks=%d "
                "(expected for %d client(s); no coexistence)",
                _tlg_bg, _expected_clients,
            )
        _pytg = _cat_counts.get("pytgcalls_handle_mtproto_updates", 0)
        if _pytg > 20:
            logger.error(
                "PYTGCALLS_UPDATE_EXPLOSION_DETECTED handle_mtproto_updates_tasks=%d "
                "(expected ≤20 during normal VC; >20 = update storm).",
                _pytg,
            )
        _disp = _cat_counts.get("telethon_dispatch_update", 0)
        if _disp > 30:
            logger.warning(
                "TELETHON_DISPATCH_UPDATE_BACKLOG dispatch_update_tasks=%d "
                "(normal ≤10; >30 = event-loop starvation causing update pile-up). "
                "This is usually a SYMPTOM of reconnect-storm or generation-coexistence, "
                "not a root cause itself.",
                _disp,
            )
    except Exception as exc:  # noqa: BLE001
        logger.debug("TASK_DUMP_CATEGORIES error: %s", exc)


# v99.07 FIX-7 (RUNTIME-CRITICAL): the periodic task-dump threshold was
# hard-wired at >20 while the 2026-09-19 production run's STEADY STATE is
# 31–33 tasks (PTB fetcher + 10 named service loops + transient handlers —
# all healthy, population FLAT for 27 minutes). The result:
# TASK_DUMP reason=periodic_high_task_count fired every 5 minutes forever
# (06:25:43 → 06:45:43, 5 dumps ≈ 160 log lines of zero-value noise).
# The threshold is now a named module constant calibrated ABOVE the
# documented steady state (40) and configurable via the
# TASK_DUMP_PERIODIC_THRESHOLD env var; the loop logs the old→new value
# once at startup (constraint: threshold changes must log both values).
_TASK_DUMP_PERIODIC_THRESHOLD_DEFAULT = 40


def _task_dump_periodic_threshold() -> int:
    """v99.07 FIX-7: resolve the periodic dump threshold (env-overridable)."""
    try:
        _raw = os.environ.get("TASK_DUMP_PERIODIC_THRESHOLD", "")
        if _raw.strip():
            _val = int(_raw.strip())
            if _val > 0:
                return _val
    except (TypeError, ValueError):
        pass
    return _TASK_DUMP_PERIODIC_THRESHOLD_DEFAULT


async def _task_dump_loop() -> None:
    """V93: periodic task-dump every 5 minutes for proactive stuck-task detection.

    v99.07 FIX-7: only logs when the task population exceeds
    _TASK_DUMP_PERIODIC_THRESHOLD (default 40 — calibrated above the
    runtime-proven 31–33 steady state; the old hard-wired >20 fired on
    every tick forever). The v98.09 boundedness model's
    task_population_bound=5000 remains the hard safety bound.
    """
    _v9907_old_threshold = 20
    _v9907_new_threshold = _task_dump_periodic_threshold()
    # v99.07 FIX-12 (P0): heartbeat with the worker watchdog (300s cadence
    # → expected_duration 310 → per-worker stuck bound 465s, so the loop's
    # designed cadence is never falsely STUCK-cancelled).
    bot_worker_register("task_dump_loop", expected_duration=310.0)
    logger.info(
        "Task-dump diagnostic loop started (interval=300s, "
        "threshold_old=%d, threshold_new=%d — v99.07 FIX-7 recalibrated "
        "above the 31–33 steady-state population; env override: "
        "TASK_DUMP_PERIODIC_THRESHOLD).",
        _v9907_old_threshold, _v9907_new_threshold,
    )
    while True:
        try:
            await asyncio.sleep(300)
            bot_worker_heartbeat("task_dump_loop")  # v99.07 FIX-12
            loop = asyncio.get_running_loop()
            tasks = asyncio.all_tasks(loop)
            if len(tasks) > _task_dump_periodic_threshold():
                # v99.09 FIX-E (2026-09-19 17:43:28, tasks=47): Join-All
                # legitimately adds ~10-15 bounded tasks on top of the
                # 31-33 steady state (worker + per-target wait_for wrappers
                # + distributed-join helpers — every one healthy and
                # self-draining). The periodic dump firing mid-Join-All is
                # pure noise (one 47-line dump in the run — rate-limit
                # itself worked). Suppress the PERIODIC dump while
                # Join-All runs, with an OBSERVABLE marker (the watchdog
                # already applies the same Join-All-is-running exception
                # for auto_discovery restarts). On-demand dumps are NOT
                # affected: SIGUSR1/faulthandler and the worker-watchdog
                # stuck-task paths bypass this gate entirely.
                _v9909_join_all_running = False
                try:
                    import mediagrab_bot.voicechat as _v9909_vc_mod
                    _v9909_join_all_running = bool(
                        getattr(_v9909_vc_mod, "_vc_join_all_running", False))
                except Exception:  # noqa: BLE001
                    _v9909_join_all_running = False
                if _v9909_join_all_running:
                    logger.debug(
                        "TASK_DUMP_SUPPRESSED_BUSY reason=join_all_running "
                        "tasks=%d threshold=%d (v99.09 FIX-E — known-busy "
                        "population during Join-All; on-demand SIGUSR1 "
                        "dumps unaffected)",
                        len(tasks), _task_dump_periodic_threshold(),
                    )
                else:
                    _dump_running_tasks(reason="periodic_high_task_count")
        except asyncio.CancelledError:
            logger.info("Task-dump diagnostic loop cancelled.")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.debug("Task-dump loop error: %s", exc)


_task_dump_task: asyncio.Task | None = None

# Module-level globals for startup/shutdown state (referenced via `global` in
# _post_init / _post_stop). Must be defined at module scope so the `global`
# declarations resolve.
_post_init_done: bool = False
_app_bg_tasks: list = []
_dashboard_snapshot_task: asyncio.Task | None = None
_bot_heartbeat_task: asyncio.Task | None = None
_bot_history_task: asyncio.Task | None = None


def _task_dump_start() -> None:
    """Start the task-dump diagnostic loop (idempotent)."""
    global _task_dump_task
    if _task_dump_task is not None and not _task_dump_task.done():
        return
    try:
        _task_dump_task = asyncio.create_task(_task_dump_loop())
    except RuntimeError:
        pass


# ---------------------------------------------------------------------------
# v98.05 FIX-FF / FIX-KK — Worker watchdog + heartbeat instrumentation.
# ---------------------------------------------------------------------------
# v98.05 FIX-FF: explicit structured markers for the bot's worker lifecycle.
#   BOT_HEARTBEAT          — periodic 5s liveness marker (complements the
#                            existing heartbeat file writer)
#   BOT_WORKER_START       — emitted when a critical worker starts a cycle
#   BOT_WORKER_COMPLETE    — emitted when a worker cycle completes
#   BOT_WORKER_TIMEOUT     — emitted when a worker cycle exceeds its
#                            expected maximum duration
#   BOT_WORKER_RECOVERED   — emitted when a stuck/timed-out worker is
#                            automatically recovered (restarted)
#   BOT_TASK_STUCK         — emitted when a worker has not produced a
#                            heartbeat within its expected interval
#   BOT_TASK_CANCELLED     — emitted when a stuck worker's task is
#                            cancelled (precedes BOT_WORKER_RECOVERED)
#   BOT_EVENT_LOOP_LAG     — alias for EVENT_LOOP_LAG_* (already emitted
#                            by _event_loop_lag_monitor)
#
# v98.05 FIX-KK: worker recovery watchdog. Tracks per-worker last-
#   heartbeat timestamps. If a worker has not produced a heartbeat
#   within `_BOT_WORKER_STUCK_TIMEOUT` seconds, the watchdog:
#     1. Emits BOT_TASK_STUCK
#     2. Cancels the stuck task (BOT_TASK_CANCELLED)
#     3. Restarts the worker (BOT_WORKER_RECOVERED)
#   This prevents the bot from silently degrading when a worker dies.
#
# Workers register themselves via `bot_worker_heartbeat(name)` at the
# start of each cycle, and `bot_worker_complete(name)` at the end.
# ---------------------------------------------------------------------------

# Per-worker tracking dict: name → {last_heartbeat, cycle_start,
# expected_duration, task_ref}
_bot_worker_state: dict[str, dict[str, Any]] = {}
_BOT_WORKER_STUCK_TIMEOUT = 300.0  # 5min — worker cycle should never exceed this
_BOT_WORKER_HEARTBEAT_INTERVAL = 60.0  # watchdog checks every 60s
_bot_worker_watchdog_task: asyncio.Task | None = None


def bot_worker_register(
    name: str,
    *,
    expected_duration: float = 60.0,
    task: "asyncio.Task | None" = None,
) -> None:
    """Register a critical worker for watchdog tracking.

    Called when a worker task starts. The worker should call
    `bot_worker_heartbeat(name)` at the start of each cycle and
    `bot_worker_complete(name)` at the end.
    """
    _bot_worker_state[name] = {
        "last_heartbeat": time.monotonic(),
        "cycle_start": time.monotonic(),
        "expected_duration": expected_duration,
        "task": task,
        "stuck_reported": False,
    }
    logger.info(
        "BOT_WORKER_START name=%s expected_duration=%.0fs (v98.05 FIX-FF: "
        "worker watchdog tracking enabled)",
        name, expected_duration,
    )


def bot_worker_heartbeat(name: str) -> None:
    """Mark a heartbeat for a worker (called at cycle start).

    Resets the stuck_reported flag if the worker was previously stuck
    and has now recovered.
    """
    if name not in _bot_worker_state:
        # Auto-register with default expected_duration.
        bot_worker_register(name)
    state = _bot_worker_state[name]
    state["last_heartbeat"] = time.monotonic()
    state["cycle_start"] = time.monotonic()
    if state.get("stuck_reported"):
        state["stuck_reported"] = False
        logger.info(
            "BOT_WORKER_RECOVERED name=%s — worker resumed heartbeats "
            "(v98.05 FIX-FF/FIX-KK)",
            name,
        )


def bot_worker_complete(name: str, *, duration: float | None = None) -> None:
    """Mark a worker cycle as complete.

    If `duration` is provided and exceeds expected_duration, emits
    BOT_WORKER_TIMEOUT (non-fatal — the cycle completed, but slower
    than expected).

    v99.07 FIX-13: the entry is PRUNED when its task is done (or no task
    was registered) — the registry tracks LIVE workers only and can no
    longer grow unbounded through register-without-complete cycles. A
    later heartbeat auto-re-registers silently.
    """
    state = _bot_worker_state.get(name)
    if state is None:
        return
    _dur = duration if duration is not None else (
        time.monotonic() - state.get("cycle_start", time.monotonic())
    )
    state["last_heartbeat"] = time.monotonic()
    logger.info(
        "BOT_WORKER_COMPLETE name=%s duration=%.2fs (v98.05 FIX-FF)",
        name, _dur,
    )
    if _dur > state.get("expected_duration", 60.0) * 1.5:
        logger.warning(
            "BOT_WORKER_TIMEOUT name=%s duration=%.2fs "
            "expected<=%.0fs — cycle completed but exceeded expected "
            "duration (v98.05 FIX-FF: non-fatal, surfaced for profiling)",
            name, _dur, state.get("expected_duration", 60.0),
        )
    # v99.07 FIX-13: prune completed one-shot cycles (live service loops
    # never call complete() and are never pruned here — their heartbeats
    # keep them current; the watchdog sweep below also drops dead tasks).
    _task = state.get("task")
    if _task is None or _task.done():
        _bot_worker_state.pop(name, None)


async def _bot_worker_watchdog_loop() -> None:
    """v98.05 FIX-KK: watchdog that detects stuck workers and recovers them.

    Every _BOT_WORKER_HEARTBEAT_INTERVAL seconds, checks all registered
    workers. If a worker has not produced a heartbeat within
    _BOT_WORKER_STUCK_TIMEOUT seconds, emits BOT_TASK_STUCK, cancels the
    task (BOT_TASK_CANCELLED), and emits BOT_WORKER_RECOVERED when the
    task is re-created (the worker's start function must be idempotent
    and is called here to restart).

    v99.07 FIX-12 (P0): the registry was ALWAYS EMPTY — bot_worker_register
    / heartbeat / complete were defined and the watchdog started, but no
    worker in the tree ever called them. All long-running service loops now
    heartbeat (see the per-loop instrumentation), so this watchdog is live.
    The stuck bound is per-worker: max(_BOT_WORKER_STUCK_TIMEOUT,
    expected_duration * 1.5) — a slow-cadence worker (e.g. the 300s
    reconcile loop) must not be falsely STUCK-cancelled at its own designed
    cadence; the 300s floor applies unchanged to every fast worker.
    """
    logger.info(
        "BOT_WORKER_WATCHDOG_STARTED interval=%.0fs stuck_timeout=%.0fs "
        "(v98.05 FIX-KK; v99.07 FIX-12: service loops now heartbeat — "
        "per-worker bound = max(stuck_timeout, expected*1.5))",
        _BOT_WORKER_HEARTBEAT_INTERVAL, _BOT_WORKER_STUCK_TIMEOUT,
    )
    while True:
        try:
            await asyncio.sleep(_BOT_WORKER_HEARTBEAT_INTERVAL)
            _now = time.monotonic()
            # v99.07 FIX-13: prune dead entries — tasks that finished (or
            # entries with no task reference whose heartbeat went stale
            # beyond 4x their effective stuck bound) can no longer recover;
            # keeping them forever made _bot_worker_state grow unbounded.
            for _dead_name in list(_bot_worker_state.keys()):
                _st = _bot_worker_state.get(_dead_name)
                if _st is None:
                    continue
                _dtask = _st.get("task")
                _eff_bound = max(
                    _BOT_WORKER_STUCK_TIMEOUT,
                    float(_st.get("expected_duration", 60.0)) * 1.5,
                )
                _stale = _now - _st.get("last_heartbeat", _now) > 4.0 * _eff_bound
                if (_dtask is not None and _dtask.done()) or (_dtask is None and _stale):
                    _bot_worker_state.pop(_dead_name, None)
                    logger.debug(
                        "BOT_WORKER_PRUNED name=%s (task done or heartbeat "
                        "stale; v99.07 FIX-13)", _dead_name,
                    )
            for _name, _state in list(_bot_worker_state.items()):
                _last = _state.get("last_heartbeat", _now)
                _elapsed = _now - _last
                # v99.07 FIX-12: per-worker effective stuck bound.
                _eff_stuck = max(
                    _BOT_WORKER_STUCK_TIMEOUT,
                    float(_state.get("expected_duration", 60.0)) * 1.5,
                )
                if _elapsed > _eff_stuck and not _state.get("stuck_reported"):
                    _state["stuck_reported"] = True
                    logger.error(
                        "BOT_TASK_STUCK name=%s elapsed=%.1fs "
                        "threshold=%.0fs — worker has not produced a "
                        "heartbeat; will attempt recovery (v98.05 FIX-KK; "
                        "v99.07 FIX-12 per-worker bound)",
                        _name, _elapsed, _eff_stuck,
                    )
                    # Cancel the stuck task if we have a reference.
                    _task = _state.get("task")
                    if _task is not None and not _task.done():
                        try:
                            _task.cancel()
                            logger.warning(
                                "BOT_TASK_CANCELLED name=%s — stuck task "
                                "cancelled; will be restarted (v98.05 FIX-KK)",
                                _name,
                            )
                        except Exception as exc:  # noqa: BLE001
                            logger.warning(
                                "BOT_TASK_CANCEL_FAILED name=%s exc=%s "
                                "(v98.05 FIX-KK)",
                                _name, exc,
                            )
                    # The worker's start function (registered separately)
                    # will be called to restart. For now, we just clear the
                    # state so the next register call is treated as fresh.
                    # The actual restart is delegated to the worker's own
                    # supervisor (e.g., _watchdog_loop already retries
                    # handler registrations). This watchdog SURFACES the
                    # stuck condition; recovery is best-effort.
        except asyncio.CancelledError:
            logger.info("BOT_WORKER_WATCHDOG_CANCELLED (v98.05 FIX-KK)")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.debug("BOT_WORKER_WATCHDOG_ERROR exc=%s (v98.05 FIX-KK)", exc)


def _bot_worker_watchdog_start() -> None:
    """Start the worker watchdog (idempotent)."""
    global _bot_worker_watchdog_task
    if _bot_worker_watchdog_task is not None and not _bot_worker_watchdog_task.done():
        return
    try:
        _bot_worker_watchdog_task = asyncio.create_task(_bot_worker_watchdog_loop())
    except RuntimeError:
        pass


# v98.05 FIX-FF: explicit BOT_HEARTBEAT marker emitted by the existing
# _bot_heartbeat_loop in handlers.py. This constant is read by that loop
# to emit a periodic liveness log line (in addition to writing the
# heartbeat file). The marker is logged every _BOT_HEARTBEAT_INTERVAL
# seconds, providing a clear "bot is alive" signal in the diagnostic log.
_BOT_HEARTBEAT_LOG_INTERVAL = 60.0  # log every 60s (file is every 5s)


# v98.05 FIX-KK (worker recovery watchdog): the _bot_worker_watchdog_loop
# (defined above) detects workers that have not produced a heartbeat within
# _BOT_WORKER_STUCK_TIMEOUT seconds. When a stuck worker is detected, the
# watchdog:
#   1. Emits BOT_TASK_STUCK (ERROR level — surfaces the stuck condition)
#   2. Cancels the stuck task (BOT_TASK_CANCELLED)
#   3. The worker's own supervisor (e.g., _watchdog_loop already retries
#      handler registrations) restarts the worker, which emits
#      BOT_WORKER_RECOVERED when it resumes heartbeats.
# This prevents the bot from silently degrading when a worker dies. The
# watchdog is COMPLEMENTARY to the pre-existing _event_loop_lag_monitor
# (which detects event-loop starvation) and the pre-existing _mtproto_
# watchdog_loop / _mtproto_health_loop (which detect MTProto disconnects).
# All critical workers should call bot_worker_register(name, task=...) at
# startup and bot_worker_heartbeat(name) at the start of each cycle.


# V94 FIX: Event-loop lag monitor.
# Measures the delay between expected and actual sleep completion.
# If the event loop is starved (blocked by synchronous code or a very long
# coroutine), the actual sleep duration exceeds the requested duration.
# This immediately surfaces event-loop starvation in the log.
_event_loop_lag_task: asyncio.Task | None = None
_event_loop_lag_warned_1s = False
_event_loop_lag_warned_5s = False
_event_loop_lag_warned_10s = False
# v98.08 FIX-WW/FIX-BBB: dispatch-backlog marker rate limiting + TASK_DUMP
# full-dump rate limiting (state; see _capture_blocking_task_stack and
# _dump_running_tasks).
_v808_dispatch_backlog_last_logged: float = 0.0
_v808_task_dump_last_full: float = 0.0
_v808_task_dump_suppressed: int = 0


async def _event_loop_lag_monitor() -> None:
    """V94: monitor event-loop lag every 2 seconds.

    Logs warnings at 1s, 5s, and 10s lag thresholds. Each threshold fires
    only once per lag episode (reset when lag returns to normal).
    """
    global _event_loop_lag_warned_1s, _event_loop_lag_warned_5s, _event_loop_lag_warned_10s
    logger.info("Event-loop lag monitor started (interval=2s).")
    # v99.07 FIX-12 (P0): heartbeat with the worker watchdog.
    bot_worker_register("event_loop_lag_monitor", expected_duration=10.0)
    while True:
        try:
            start = time.monotonic()
            await asyncio.sleep(2.0)
            bot_worker_heartbeat("event_loop_lag_monitor")  # v99.07 FIX-12
            elapsed = time.monotonic() - start
            lag = elapsed - 2.0  # expected 2.0s

            if lag < 0.5:
                # Normal — reset all warning flags.
                _event_loop_lag_warned_1s = False
                _event_loop_lag_warned_5s = False
                _event_loop_lag_warned_10s = False
                # v97.50: set backpressure state to normal
                try:
                    from .voicechat import vc_set_backpressure_state
                    vc_set_backpressure_state("normal", lag)
                except Exception:  # noqa: BLE001
                    pass
            elif lag >= 10.0 and not _event_loop_lag_warned_10s:
                logger.error(
                    "EVENT_LOOP_LAG_CRITICAL lag=%.2fs — event loop is "
                    "severely starved (blocked or overloaded). Bot will "
                    "appear frozen to users.",
                    lag,
                )
                _event_loop_lag_warned_10s = True
                _event_loop_lag_warned_5s = True
                _event_loop_lag_warned_1s = True
                # Dump tasks so we can see what's stuck.
                _dump_running_tasks(reason="event_loop_lag_critical")
                # v97.66: capture the currently executing task + its stack
                # to identify the EXACT blocking operation.
                _capture_blocking_task_stack(lag)
                # v97.50: set backpressure state to emergency
                try:
                    from .voicechat import vc_set_backpressure_state
                    vc_set_backpressure_state("emergency", lag)
                except Exception:  # noqa: BLE001
                    pass
            elif lag >= 5.0 and not _event_loop_lag_warned_5s:
                logger.warning(
                    "EVENT_LOOP_LAG_HIGH lag=%.2fs — event loop is "
                    "significantly delayed. Commands may be slow.",
                    lag,
                )
                _event_loop_lag_warned_5s = True
                _event_loop_lag_warned_1s = True
                # v97.66: capture stack at 5s too.
                _capture_blocking_task_stack(lag)
                # v97.50: set backpressure state to strong
                try:
                    from .voicechat import vc_set_backpressure_state
                    vc_set_backpressure_state("strong_backpressure", lag)
                except Exception:  # noqa: BLE001
                    pass
            elif lag >= 1.0 and not _event_loop_lag_warned_1s:
                # v97.66: log at 1s + capture stack.
                # v99.07 FIX-16: the old code had TWO branches (>= 2.0 and
                # >= 1.0) emitting the IDENTICAL EVENT_LOOP_LAG_MODERATE
                # message — only the 2.0 branch captured a stack, making
                # the 1.0 branch a dead duplicate. Merged: ONE moderate
                # branch that ALWAYS captures the blocking stack.
                logger.warning(
                    "EVENT_LOOP_LAG_MODERATE lag=%.2fs — event loop "
                    "slightly delayed.",
                    lag,
                )
                _event_loop_lag_warned_1s = True
                _capture_blocking_task_stack(lag)
                # v97.50: set backpressure state to reduce
                try:
                    from .voicechat import vc_set_backpressure_state
                    vc_set_backpressure_state("reduce", lag)
                except Exception:  # noqa: BLE001
                    pass
        except asyncio.CancelledError:
            logger.info("Event-loop lag monitor cancelled.")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.debug("Event-loop lag monitor error: %s", exc)


def _capture_blocking_task_stack(lag: float) -> None:
    """v97.66: capture the currently executing task + its stack frame to
    identify the EXACT blocking operation causing event-loop lag.

    This is the causal instrumentation the master prompt requires: instead of
    just logging "lag=10.11s", this captures which task was executing + its
    Python stack, so the blocking call path can be identified.

    v98.08 FIX-WW: ALSO counts the Telethon _dispatch_update backlog (the
    F2' systemic bottleneck: 528/540 tasks at the 16:57:19 CRITICAL lag
    were anonymous Task-N dispatch coroutines at telegram/updates.py:605).
    VC_UPDATE_DISPATCH_BACKLOG (rate-limited 60s) makes the pileup
    trackable WITHOUT a full TASK_DUMP.
    """
    try:
        import traceback
        loop = asyncio.get_running_loop()
        # Dump ALL application-owned tasks with their current await point.
        all_tasks = asyncio.all_tasks(loop)
        _app_tasks = []
        _v808_dispatch_backlog = 0
        for t in all_tasks:
            if t.done():
                continue
            name = t.get_name() if hasattr(t, "get_name") else str(t)
            # v98.08 FIX-WW: count the dispatch backlog (anonymous Task-N
            # coroutines awaiting inside Telethon's _dispatch_update).
            try:
                _v808_coro = t.get_coro()
                _v808_frame = getattr(_v808_coro, "cr_frame", None)
                if _v808_frame is not None \
                        and _v808_frame.f_code.co_name == "_dispatch_update":
                    _v808_dispatch_backlog += 1
            except Exception:  # noqa: BLE001
                pass
            # Only log application-owned tasks (skip Telethon/PTB internals).
            if any(kw in name.lower() for kw in (
                "vc_callback", "vc_join_all", "vc_watcher", "vc_reconcile",
                "vc_dashboard", "vc_op_scheduler", "vc_talkative",
                "dashboard_snapshot", "bot_heartbeat", "bot_history",
                "_mtproto_", "_scheduled", "periodic_cleanup",
            )):
                coro = t.get_coro()
                frame = coro.cr_frame if hasattr(coro, "cr_frame") else None
                if frame is not None:
                    fname = frame.f_code.co_filename
                    lineno = frame.f_lineno
                    func = frame.f_code.co_name
                    _app_tasks.append(f"  {name} at {fname}:{lineno} in {func}()")
        # v98.08 FIX-WW: dispatch backlog marker (rate-limited: 1/60s —
        # the lag monitor calls this on every episode; a burst would
        # otherwise re-log the same backlog dozens of times).
        global _v808_dispatch_backlog_last_logged
        _v808_now = time.monotonic()
        if _v808_dispatch_backlog >= 200 and \
                _v808_now - _v808_dispatch_backlog_last_logged >= 60.0:
            _v808_dispatch_backlog_last_logged = _v808_now
            logger.warning(
                "VC_UPDATE_DISPATCH_BACKLOG n=%d total_tasks=%d — Telethon "
                "per-update dispatch coroutines piled up (the F2' systemic "
                "bottleneck: 528/540 at the v98.07 CRITICAL lag; starvation "
                "feedback loop) (v98.08 FIX-WW)",
                _v808_dispatch_backlog, len(all_tasks))
        if _app_tasks:
            logger.warning(
                "EVENT_LOOP_LAG_APP_TASKS lag=%.2fs count=%d:\n%s",
                lag, len(_app_tasks), "\n".join(_app_tasks[:20]),
            )
    except Exception as exc:  # noqa: BLE001
        logger.debug("EVENT_LOOP_LAG_CAUSE_CAPTURE_FAILED: %s", exc)


def _event_loop_lag_start() -> None:
    """Start the event-loop lag monitor (idempotent)."""
    global _event_loop_lag_task
    if _event_loop_lag_task is not None and not _event_loop_lag_task.done():
        return
    try:
        _event_loop_lag_task = asyncio.create_task(_event_loop_lag_monitor())
    except RuntimeError:
        pass


async def _scheduled_loop(app: Application) -> None:
    """Periodically run due scheduled tasks."""
    logger.info("Scheduled-task loop started (interval=60s).")
    while True:
        try:
            await asyncio.sleep(60)
            n = await scheduled_handler.run_due_tasks(app)
            if n:
                logger.info("Processed %d scheduled tasks.", n)
        except asyncio.CancelledError:
            logger.info("Scheduled-task loop cancelled.")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.exception("scheduled loop error: %s", exc)


# V63 Fix #4: Background task watchdog.
# Monitors critical background tasks every 60s. If a task has died (not
# cancelled, but done with an exception), logs an error + attempts restart.
_watchdog_task: Optional[asyncio.Task] = None
_watchdog_last_check = 0.0

# Registry of critical tasks to watch: (task_ref_getter, restart_fn, name)
# Each getter returns the task object (or None); restart_fn restarts it.
def _watchdog_get_talkative_cleanup():
    # Use module attribute access — talkative reassigns _talkative_cleanup_task.
    import mediagrab_bot.talkative as _tk
    return getattr(_tk, "_talkative_cleanup_task", None)

def _watchdog_get_vc_reconcile():
    # Use module attribute access — voicechat reassigns _vc_reconcile_task
    # via `global`, so a from-import snapshots a stale None.
    import mediagrab_bot.voicechat as _vc
    return _vc._vc_reconcile_task

def _watchdog_get_dashboard_snapshot():
    # Task is created in handlers.py — use module attribute access.
    import mediagrab_bot.handlers as _hd
    return getattr(_hd, "_dashboard_snapshot_task", None)

def _watchdog_get_bot_heartbeat():
    import mediagrab_bot.handlers as _hd
    return getattr(_hd, "_bot_heartbeat_task", None)

def _watchdog_get_bot_history():
    import mediagrab_bot.handlers as _hd
    return getattr(_hd, "_bot_history_task", None)


# ---------------------------------------------------------------------------
# v98.07 FIX-SS (F1 — HARD FREEZE): thread-based heartbeat canary.
#
# RUNTIME EVIDENCE (bot-diagnostic.log.1 pid=7670): the last BOT_HEARTBEAT
# printed 07:44:07 (60s cadence, healthy through the whole run), the last
# log line 07:47:18 — then 95 minutes of TOTAL silence while the process
# ran. NO EVENT_LOOP_LAG warning preceded the silence (the lag monitor
# itself is a loop task — it died with the loop). The freeze site sat
# inside vc_verify_target's redetect→participation prologue; the strongest
# temporal correlation: MTPROTO_WATCHDOG_DISCONNECT_DETECTED at 07:47:05
# (disconnects ran ~1/min from 06:52; 46 in the visible log). Every await
# on that path is bounded (10s/15s wait_for), so a SYNC block (or a
# thread-level wedge) is the remaining mechanism class.
#
# An asyncio heartbeat CANNOT detect an event-loop blockage (it dies with
# the loop). This canary is a plain daemon threading.Thread — immune to
# loop blockage. It watches a time.monotonic() stamp refreshed by a 5s
# async liveness loop. If the stamp goes stale > 180s:
#   1. faulthandler.dump_traceback() → side file (ALL thread stacks —
#      names the exact blocking frame, including logging-lock holds),
#   2. VC_HEARTBEAT_CANARY_TRIGGERED logged + printed to stderr,
#   3. (config-gated, default ON) os._exit(86) — the supervisor restarts
#      a wedged process instead of hanging for 95 minutes. Exit code 86
#      is unique to this path for log forensics.
# ---------------------------------------------------------------------------
_VC_LOOP_LIVENESS_STAMP: float = time.monotonic()
_VC_LOOP_LIVENESS_ARMED: bool = False
# v99.07 FIX-17: the loop thread WRITES the stamp and the canary thread
# READS it — previously unsynchronized (correct only under CPython's GIL
# by accident). A tiny lock makes the cross-thread contract explicit;
# nothing but the float read/write happens under it (no I/O, no logging).
_VC_LOOP_LIVENESS_LOCK = threading.Lock()
_VC_CANARY_THREAD: threading.Thread | None = None
_VC_CANARY_TRIGGERED: bool = False
_VC_CANARY_CHECK_INTERVAL: float = 10.0
_VC_CANARY_STALE_THRESHOLD: float = 180.0


def _vc_canary_dump_path() -> str:
    try:
        _root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
        os.makedirs(_root, exist_ok=True)
        return os.path.join(_root, f"vc_canary_dump_{os.getpid()}.txt")
    except Exception:  # noqa: BLE001
        return os.path.join(tempfile.gettempdir(), f"vc_canary_dump_{os.getpid()}.txt")


def _vc_heartbeat_canary_thread_body() -> None:
    """v98.07 FIX-SS: the canary watchdog thread (daemon, never raises out)."""
    global _VC_CANARY_TRIGGERED
    while True:
        time.sleep(_VC_CANARY_CHECK_INTERVAL)
        try:
            if _VC_CANARY_TRIGGERED or not _VC_LOOP_LIVENESS_ARMED:
                continue
            # v99.07 FIX-17: synchronized read (the loop thread writes
            # under the same lock — no bare cross-thread float access).
            # globals().get + self-heal keeps the exec-extraction test
            # contract working when the body runs with a minimal
            # namespace (the lock is created on demand).
            _v9907_llock = globals().get("_VC_LOOP_LIVENESS_LOCK")
            if _v9907_llock is None:
                import threading as _v9907_lthreading
                _v9907_llock = _v9907_lthreading.Lock()
                globals()["_VC_LOOP_LIVENESS_LOCK"] = _v9907_llock
            with _v9907_llock:
                _age = time.monotonic() - _VC_LOOP_LIVENESS_STAMP
            if _age <= _VC_CANARY_STALE_THRESHOLD:
                continue
            _VC_CANARY_TRIGGERED = True
            _dump_path = _vc_canary_dump_path()
            _msg = (
                "VC_HEARTBEAT_CANARY_TRIGGERED age=%.0fs threshold=%.0fs "
                "pid=%d — event loop appears hard-blocked; dumping ALL thread "
                "stacks to %s (v98.07 FIX-SS)"
                % (_age, _VC_CANARY_STALE_THRESHOLD, os.getpid(), _dump_path)
            )
            # 1) Dump to stderr (always visible) + the side file.
            try:
                print(f"[CANARY] {_msg}", file=sys.stderr, flush=True)
            except Exception:  # noqa: BLE001
                pass
            try:
                with open(_dump_path, "w", encoding="utf-8") as _fh:
                    _fh.write(f"{_msg}\n")
                    # v98.09 ARCH (§25 CANARY CLASSIFICATION + CONTEXT):
                    # a STRUCTURED context block is written BEFORE the
                    # faulthandler stacks (bot version, discovery phase,
                    # query cursor, gate/queue depths, scope registry) so
                    # the dump is self-describing without log cross-
                    # reference. Then the event is CLASSIFIED — v98.08
                    # printed one hard-blocked message for every freeze
                    # class; v98.09 distinguishes EVENT_LOOP_BLOCKED /
                    # EVENT_LOOP_STARVED / DISCOVERY_OVER_BUDGET /
                    # RPC_STUCK / LOCK_WAIT / TASK_BACKLOG / CPU_PRESSURE
                    # from the live module-state evidence (thread-safe
                    # reads of plain dict state; the loop is wedged, so
                    # asyncio introspection from this thread is not safe —
                    # the stacks below carry that part).
                    _v98a_class = "EVENT_LOOP_BLOCKED"
                    _v98a_rationale = "classification-unavailable"
                    try:
                        from .vc_architecture import (
                            canary_context_snapshot,
                            classify_canary_event,
                            render_canary_context,
                        )
                        _v98a_snap = canary_context_snapshot(
                            bot_version=getattr(config, "bot_version", "v98.12"))
                        _v98a_disc = _v98a_snap.get("discovery") or {}
                        _v98a_cls, _v98a_why = classify_canary_event(
                            _age, _VC_CANARY_STALE_THRESHOLD,
                            {
                                # A fired canary means the loop thread has
                                # not run the 5s stamper for > threshold:
                                # the loop is BLOCKED (starvation-with-
                                # heartbeat would still stamp; the dump
                                # stacks confirm the frame).
                                "loop_blocked_in_user_code": True,
                                "discovery_active": bool(
                                    _v98a_disc.get("active")),
                                "discovery_over_budget": bool(
                                    _v98a_disc.get("over_budget")),
                            },
                        )
                        _v98a_class = _v98a_cls
                        _v98a_rationale = _v98a_why
                        _fh.write(render_canary_context(_v98a_snap) + "\n")
                    except Exception as _v98a_exc:  # noqa: BLE001
                        _fh.write(
                            f"VC_ARCH CONTEXT ERROR: {_v98a_exc}\n")
                    _fh.write(
                        f"CANARY_CLASS={_v98a_class} "
                        f"RATIONALE={_v98a_rationale}\n")
                    faulthandler.dump_traceback(file=_fh)
                print(f"[CANARY] full dump written: {_dump_path}",
                      file=sys.stderr, flush=True)
                # v98.09 ARCH (§25): the classification travels with the
                # dump + the log (VC_HEARTBEAT_CANARY_CLASSIFIED) so the
                # soak greps can distinguish freeze CLASSES, not just
                # count freezes.
                try:
                    logger.warning(
                        "VC_HEARTBEAT_CANARY_CLASSIFIED class=%s "
                        "rationale=%s (v98.09 §25 — classification from "
                        "live module state; stacks in %s)",
                        _v98a_class, _v98a_rationale, _dump_path)
                except Exception:  # noqa: BLE001
                    pass
                # v98.08 FIX-XX: dump RETENTION — copy the dump into the
                # diagnostic log directory with a wall-clock timestamp so
                # it survives data/ cleanup + is included in the next
                # upload bundle (the v98.07 soak wrote
                # vc_canary_dump_29332.txt but it was never retrieved —
                # the F1' blocking frame stayed unknown). Also log
                # VC_HEARTBEAT_CANARY_DUMP_WRITTEN BEFORE the exit(86)
                # decision so the marker + path are in the diagnostic log.
                _v808_retained = ""
                try:
                    import shutil as _shutil_mod
                    from datetime import datetime as _dt_mod
                    _v808_log_dir = os.path.dirname(
                        getattr(config, "log_path", "") or "") \
                        or os.path.dirname(os.path.abspath(__file__))
                    _v808_stamp = _dt_mod.now().strftime("%Y%m%d_%H%M%S")
                    _v808_retained = os.path.join(
                        _v808_log_dir,
                        f"vc_canary_dump_{os.getpid()}_{_v808_stamp}.txt")
                    _shutil_mod.copyfile(_dump_path, _v808_retained)
                except Exception as _ret_exc:  # noqa: BLE001
                    _v808_retained = f"(retention copy failed: {_ret_exc})"
                try:
                    logger.warning(
                        "VC_HEARTBEAT_CANARY_DUMP_WRITTEN path=%s retained_copy=%s "
                        "(v98.08 FIX-XX — dump retained in the diagnostic dir; "
                        "BEFORE exit(86) by design)",
                        _dump_path, _v808_retained)
                except Exception:  # noqa: BLE001
                    pass
            except Exception as _exc:  # noqa: BLE001
                # Side file failed — still dump to stderr so the evidence
                # survives in the console/log stream.
                try:
                    print(f"[CANARY] side-file dump failed: {_exc}",
                          file=sys.stderr, flush=True)
                    faulthandler.dump_traceback()
                except Exception:  # noqa: BLE001
                    pass
            # 2) Log line (best-effort — the logging handler itself may be
            #    the wedged resource; the stderr prints above are primary).
            try:
                logger.warning("%s", _msg)
            except Exception:  # noqa: BLE001
                pass
            # v98.08 FIX-XX: optional webhook notification (config-gated,
            # bounded 10s — sync urllib from THIS daemon thread is safe:
            # the event loop is already wedged). Default URL empty = no-op.
            try:
                _v808_hook = str(getattr(config, "vc_canary_notify_webhook", "") or "")
                if _v808_hook:
                    import urllib.request as _ur808
                    _v808_req = _ur808.Request(
                        _v808_hook, data=json.dumps({
                            "event": "vc_heartbeat_canary_triggered",
                            "pid": os.getpid(), "age_s": round(_age),
                            "dump": _dump_path,
                        }).encode("utf-8"),
                        headers={"Content-Type": "application/json"})
                    with _ur808.urlopen(_v808_req, timeout=10) as _v808_resp:
                        _v808_resp.read(64)
                    print("[CANARY] webhook notification sent",
                          file=sys.stderr, flush=True)
            except Exception:  # noqa: BLE001
                pass  # bounded, best-effort — never block the exit path
            # 3) Exit(86) so the supervisor restarts a wedged process
            #    (config-gated, default ON).
            try:
                _canary_exit_enabled = bool(getattr(config, "vc_heartbeat_canary", True))
            except Exception:  # noqa: BLE001
                _canary_exit_enabled = True
            if _canary_exit_enabled:
                try:
                    print(
                        "[CANARY] os._exit(86) — restarting the wedged process "
                        "(supervisor should restart; exit code 86 = canary)",
                        file=sys.stderr, flush=True,
                    )
                except Exception:  # noqa: BLE001
                    pass
                # v99.07 FIX-22: leave a marker on disk BEFORE the exit so
                # the next boot can distinguish a canary-triggered restart
                # (86) from a clean shutdown — the exit code lives in the
                # supervisor journal, which is not always available. The
                # marker is consumed (logged + removed) at the next boot.
                try:
                    _v9907_marker = os.path.join(
                        os.path.dirname(os.path.abspath(__file__)), "data",
                        "vc_canary_exit_86.marker")
                    os.makedirs(os.path.dirname(_v9907_marker), exist_ok=True)
                    with open(_v9907_marker, "w", encoding="utf-8") as _mf:
                        _mf.write(
                            f"pid={os.getpid()} age={_age:.0f}s "
                            f"class={_v98a_class} "
                            f"wall={time.time():.0f}\n")
                except Exception:  # noqa: BLE001
                    pass
                os._exit(86)
            else:
                try:
                    print("[CANARY] exit disabled by config "
                          "(vc_heartbeat_canary=false) — process left running",
                          file=sys.stderr, flush=True)
                except Exception:  # noqa: BLE001
                    pass
        except Exception:  # noqa: BLE001
            # Never let the canary thread die.
            try:
                time.sleep(5)
            except Exception:  # noqa: BLE001
                pass


def _vc_start_heartbeat_canary() -> None:
    """v98.07 FIX-SS: start the canary thread once (idempotent, daemon)."""
    global _VC_CANARY_THREAD
    if _VC_CANARY_THREAD is not None and _VC_CANARY_THREAD.is_alive():
        return
    _t = threading.Thread(
        target=_vc_heartbeat_canary_thread_body,
        name="vc_heartbeat_canary", daemon=True,
    )
    _t.start()
    _VC_CANARY_THREAD = _t
    logger.info(
        "VC_HEARTBEAT_CANARY_STARTED threshold=%.0fs check_interval=%.0fs "
        "exit_on_trigger=%s (v98.07 FIX-SS — thread-based, immune to "
        "event-loop blockage)",
        _VC_CANARY_STALE_THRESHOLD, _VC_CANARY_CHECK_INTERVAL,
        bool(getattr(config, "vc_heartbeat_canary", True)),
    )


async def _vc_loop_liveness_loop() -> None:
    """v98.07 FIX-SS: refresh the liveness stamp every 5s (event-loop side).

    This task is the ONLY stamp writer: it measures loop responsiveness
    directly. If the loop blocks (sync code / logging lock / GIL wedge),
    the stamp goes stale and the canary thread fires. The watchdog
    (below) restarts this task if it dies while the loop is healthy —
    preventing false positives from a dead-but-healthy-loop task.

    v98.09 ARCH (§11/§13/§27): every 12th stamp (~60s) this loop ALSO
    runs the architecture maintenance sweep — negative-cache cardinality
    bound (deterministic fail-safe eviction) + scope-token lifecycle
    fold (id() reuse detection) + the rate-limited budgets heartbeat
    line. All guarded: maintenance must NEVER delay the stamp (a
    diagnostics mechanism must not become the freeze source — §26)."""
    global _VC_LOOP_LIVENESS_STAMP, _VC_LOOP_LIVENESS_ARMED
    _VC_LOOP_LIVENESS_ARMED = True
    logger.info("VC_LOOP_LIVENESS_LOOP started (5s stamp cadence, v98.07 FIX-SS)")
    # v99.07 FIX-12 (P0): heartbeat with the worker watchdog.
    bot_worker_register("vc_loop_liveness", expected_duration=15.0)
    _v98a_tick = 0
    while True:
        try:
            await asyncio.sleep(5)
            bot_worker_heartbeat("vc_loop_liveness")  # v99.07 FIX-12
            # v99.07 FIX-17: synchronized write (the canary thread reads
            # under the same lock); self-healing acquisition mirrors the
            # canary's read side (exec-contract safe).
            _v9907_wlock = globals().get("_VC_LOOP_LIVENESS_LOCK")
            if _v9907_wlock is None:
                import threading as _v9907_wthreading
                _v9907_wlock = _v9907_wthreading.Lock()
                globals()["_VC_LOOP_LIVENESS_LOCK"] = _v9907_wlock
            with _v9907_wlock:
                _VC_LOOP_LIVENESS_STAMP = time.monotonic()
            _v98a_tick += 1
            if _v98a_tick % 12 == 0:
                try:
                    from . import voicechat as _vc9
                    from .vc_architecture import (
                        emit_budgets_heartbeat,
                        negcache_sweep,
                        scope_registry_update,
                    )
                    scope_registry_update(
                        _vc9._vc_client_scope_account_map(),
                        reason="liveness_sweep")
                    negcache_sweep(
                        _vc9._VC_ENTITY_NEGATIVE_CACHE,
                        _vc9._vc_arch_negcache_bound(),
                        reason="liveness_sweep")
                    emit_budgets_heartbeat()
                except Exception as _v98a_exc:  # noqa: BLE001
                    logger.debug(
                        "VC_ARCH liveness maintenance error: %s", _v98a_exc)
        except asyncio.CancelledError:
            logger.info("VC_LOOP_LIVENESS_LOOP cancelled.")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.warning("VC_LOOP_LIVENESS_LOOP error: %s", exc)
            await asyncio.sleep(5)


# v99.09 FIX-D (2026-09-19 production, every 60s for the whole run):
# ``VC loop liveness start failed (non-fatal): name '_vc_loop_liveness_task'
# is not defined`` + ``WATCHDOG: vc_loop_liveness was None — starting
# (attempt 1)`` forever. The v99.07 FIX-11 idempotency check READS the
# module global before any assignment — but unlike every other supervised
# task (see _task_dump_task/_dashboard_snapshot_task/_bot_heartbeat_task/
# _watchdog_task/_cluster_reconnect_task …), this one had NO module-level
# declaration, so the very first read raised NameError: the stamper NEVER
# started, and the watchdog's restarter() call raised the same NameError
# each pass (which also aborted the failure-counter increment — hence
# "attempt 1" ad infinitum). Declaring the binding makes FIX-11's
# idempotency genuinely work: first call binds None→task; live task is
# reused; a dead task is replaced; the watchdog sees a real task.
_vc_loop_liveness_task: "asyncio.Task | None" = None


def _watchdog_get_vc_loop_liveness():
    return globals().get("_vc_loop_liveness_task", None)


def _vc_loop_liveness_start() -> None:
    """v98.07 FIX-SS: (re)start the liveness stamp task (supervised).

    v99.07 FIX-11 (P0): idempotent — a watchdog restart while the previous
    stamper is still alive previously spawned a DUPLICATE 5-second stamper
    (the unconditional reassignment leaked the old task and doubled the
    stamp cadence). The live task is now reused, not replaced.
    """
    global _vc_loop_liveness_task
    # v99.07 FIX-11: reuse the LIVE task — never spawn a duplicate stamper.
    if _vc_loop_liveness_task is not None and not _vc_loop_liveness_task.done():
        return
    try:
        _vc_loop_liveness_task = supervised_create_task(
            _vc_loop_liveness_loop(), name="vc_loop_liveness")
    except RuntimeError:
        pass


def _watchdog_get_vc_session_hot_reload():
    # v98.07 FIX-UU: the hot-reload task lives in mtproto (it owns the
    # cluster + import machinery).
    from . import mtproto as _mt
    return getattr(_mt, "_vc_session_hot_reload_task", None)


def _vc_session_hot_reload_start() -> None:
    # v98.07 FIX-UU: delegate to the mtproto starter.
    try:
        from .mtproto import _vc_session_hot_reload_start as _start
        _start()
    except Exception as exc:  # noqa: BLE001
        logger.warning("session hot-reload start failed (non-fatal): %s", exc)


def _watchdog_get_auto_discovery():
    # Use module attribute access — voicechat reassigns _auto_discovery_task.
    import mediagrab_bot.voicechat as _vc
    return _vc._auto_discovery_task

def _watchdog_get_deferred_queue():
    # Use module attribute access — voicechat reassigns _deferred_queue_task.
    import mediagrab_bot.voicechat as _vc
    return getattr(_vc, "_deferred_queue_task", None)

def _watchdog_get_cluster_reconnect():
    """V70.1 §5: return the cluster-reconnect background task (or None)."""
    return _cluster_reconnect_task

# RELI-J-007: restarter for the auto_discovery task — the underlying starter
# (auto_discovery_start) is a coroutine, so the restarter schedules it on the
# running loop. Falls back to no-op if no loop is running.
# v97 FIX: use auto_discovery_effective_enabled() (DB authoritative) instead
# of config.vc_discovery_enabled (.env only). The watchdog must NOT restart
# discovery when the admin has disabled it via the dashboard.
async def _watchdog_restart_auto_discovery_async():
    """Async wrapper that checks DB state before restarting discovery."""
    try:
        from .voicechat import auto_discovery_effective_enabled, auto_discovery_start
        _eff, _src = await auto_discovery_effective_enabled()
        if not _eff:
            logger.debug(
                "WATCHDOG: skipping auto_discovery restart — effective_disabled source=%s",
                _src,
            )
            return
        await auto_discovery_start()
    except Exception as exc:  # noqa: BLE001
        logger.warning("WATCHDOG: auto_discovery async restart failed: %s", exc)


def _watchdog_restart_auto_discovery():
    # v97.5 FIX: use supervised_create_task (strong ref in _active_tasks)
    # instead of bare asyncio.create_task.  A bare create_task result has
    # only a weak reference from the event loop and can be GC'd before the
    # wrapper's first await — meaning the real auto_discovery restart never
    # happens and the watchdog must wait another full cycle (60s) to retry.
    try:
        from .utils_real import supervised_create_task
        supervised_create_task(
            _watchdog_restart_auto_discovery_async(),
            name="watchdog_restart_auto_discovery",
        )
    except RuntimeError:
        # No running event loop — nothing we can do here.
        pass

# RELI-J-008: restarter for the cluster_reconnect task. Defined as a wrapper
# here (alongside the other getters) so it can be referenced from
# _WATCHDOG_TASKS — _cluster_reconnect_start itself is defined further down
# in the module, but name lookup happens at call time (after module load).
def _watchdog_restart_cluster_reconnect():
    try:
        _cluster_reconnect_start()  # type: ignore[name-defined]
    except (NameError, RuntimeError):
        pass

_WATCHDOG_TASKS: list[tuple[str, Any, Any]] = [
    ("talkative_cleanup", _watchdog_get_talkative_cleanup, _talkative_start_cleanup_task),
    ("vc_reconcile", _watchdog_get_vc_reconcile, _vc_reconcile_start),
    ("dashboard_snapshot", _watchdog_get_dashboard_snapshot, _dashboard_snapshot_start),
    ("bot_heartbeat", _watchdog_get_bot_heartbeat, _bot_heartbeat_start),
    ("bot_history", _watchdog_get_bot_history, _bot_history_start),
    # v98.07 FIX-SS: the liveness stamp task is watchdog-supervised so a
    # dead-but-healthy-loop task is restarted (no false canary positives).
    ("vc_loop_liveness", _watchdog_get_vc_loop_liveness, _vc_loop_liveness_start),
    # v98.07 FIX-UU: session hot-reload rescan task.
    ("vc_session_hot_reload", _watchdog_get_vc_session_hot_reload, _vc_session_hot_reload_start),
    ("auto_discovery", _watchdog_get_auto_discovery, _watchdog_restart_auto_discovery),
    ("deferred_queue", _watchdog_get_deferred_queue, _deferred_queue_start),
    # RELI-J-008: watch the cluster-reconnect loop too — if it dies, the
    # auto-reconnect backoff for connection_failed accounts stops entirely.
    ("cluster_reconnect", _watchdog_get_cluster_reconnect, _watchdog_restart_cluster_reconnect),
]


async def _watchdog_loop() -> None:
    """V63 Fix #4: monitor critical background tasks + restart dead ones.

    v97 CHAOS-3 FIX: added exponential backoff + max restart count. Previously,
    a task that crashed immediately on start was restarted every 60s forever,
    wasting CPU and masking real errors. Now: backoff = min(60 * 2^failures, 600),
    give up after 10 consecutive failures.
    """
    logger.info("Background watchdog loop started (interval=60s).")
    global _watchdog_last_check
    # v99.07 FIX-12 (P0): heartbeat with the v98.05 FIX-KK worker watchdog
    # (previously NO worker ever called bot_worker_heartbeat — the registry
    # was always empty and the watchdog inert).
    bot_worker_register("watchdog_loop", expected_duration=90.0)
    # Access voicechat module globals by attribute (from-import snapshots
    # immutable values at import time; voicechat reassigns these at runtime).
    import mediagrab_bot.voicechat as _vc_mod
    # v97 CHAOS-3: track consecutive restart failures per task for backoff.
    _watchdog_failure_counts: dict[str, int] = {}
    _watchdog_last_restart: dict[str, float] = {}
    _WATCHDOG_MAX_FAILURES = 10
    while True:
        try:
            await asyncio.sleep(60)
            bot_worker_heartbeat("watchdog_loop")  # v99.07 FIX-12
            _watchdog_last_check = time.monotonic()
            for name, getter, restarter in _WATCHDOG_TASKS:
                try:
                    task = getter()
                    # v97 PA-2 FIX: check _vc_join_all_running BEFORE both
                    # branches.
                    if name == "auto_discovery" and _vc_mod._vc_join_all_running:
                        logger.debug(
                            "WATCHDOG: skipping %s restart — Join All is running",
                            name,
                        )
                        continue
                    # v97 CHAOS-3: check if we've hit max failures.
                    failures = _watchdog_failure_counts.get(name, 0)
                    if failures >= _WATCHDOG_MAX_FAILURES:
                        # Only log once every 10 minutes to avoid spam.
                        last = _watchdog_last_restart.get(name, 0)
                        if time.monotonic() - last > 600:
                            logger.error(
                                "WATCHDOG: %s has failed %d consecutive restarts — "
                                "GIVING UP (manual intervention required)",
                                name, failures,
                            )
                            _watchdog_last_restart[name] = time.monotonic()
                        continue
                    if task is None:
                        # v97.10 GLOBAL FLOODWAIT: if a systemic FloodWait is
                        # active, do NOT restart VC workers — they are likely
                        # stalled due to the FloodWait, not dead.  Restarting
                        # them would create duplicate RPC load during the
                        # rate-limit period.
                        if name in ("auto_discovery", "deferred_queue") and \
                           hasattr(_vc_mod, "vc_is_global_floodwait_active") and \
                           _vc_mod.vc_is_global_floodwait_active():
                            logger.debug(
                                "WATCHDOG: %s is None but global_floodwait "
                                "active — not restarting (FloodWait pause)",
                                name,
                            )
                            continue
                        # v97 PART H FIX: for discovery-gated tasks
                        # (auto_discovery + deferred_queue), check the
                        # DB-authoritative effective-enabled state BEFORE
                        # logging "was None — starting".  When the admin has
                        # intentionally disabled discovery (DB=0), the task is
                        # legitimately None and must NOT be restarted or logged
                        # as a warning (prevents the spammy
                        # "WATCHDOG: auto_discovery was None — starting" loop).
                        if name in ("auto_discovery", "deferred_queue"):
                            try:
                                _eff, _src = await _vc_mod.auto_discovery_effective_enabled()
                            except Exception:  # noqa: BLE001
                                _eff, _src = False, "error"
                            if not _eff:
                                logger.debug(
                                    "WATCHDOG: %s is None but effective_disabled "
                                    "source=%s — not restarting (admin disabled)",
                                    name, _src,
                                )
                                continue
                        # v97 CHAOS-3: apply backoff before restarting.
                        last = _watchdog_last_restart.get(name, 0)
                        backoff = min(60 * (2 ** failures), 600)
                        if time.monotonic() - last < backoff:
                            continue
                        logger.warning("WATCHDOG: %s was None — starting (attempt %d)",
                                       name, failures + 1)
                        _watchdog_last_restart[name] = time.monotonic()
                        # v99.09 FIX-D (continued): the restarter call was
                        # UNGUARDED — a raising restarter (the FIX-D
                        # NameError was the 2026-09-19 production case)
                        # aborted this watchdog pass AND skipped the
                        # failure-counter increment, so the log said
                        # "attempt 1" every 60s forever with no GIVING-UP
                        # escalation ever reachable. Guard + count + log:
                        # the next pass applies the normal backoff ladder.
                        try:
                            restarter()
                        except Exception as _v9909_rexc:  # noqa: BLE001
                            _watchdog_failure_counts[name] = failures + 1
                            logger.error(
                                "WATCHDOG: %s restarter raised %s: %s "
                                "(attempt %d counted; backoff applies)",
                                name, type(_v9909_rexc).__name__,
                                _v9909_rexc, failures + 1,
                            )
                        continue
                    if task.done():
                        # v97 PART H FIX: for discovery-gated tasks, if the
                        # admin has disabled discovery (DB=0) since the task
                        # was started, do NOT restart — respect the DB.
                        if name in ("auto_discovery", "deferred_queue"):
                            try:
                                _eff, _src = await _vc_mod.auto_discovery_effective_enabled()
                            except Exception:  # noqa: BLE001
                                _eff, _src = False, "error"
                            if not _eff:
                                logger.debug(
                                    "WATCHDOG: %s died but effective_disabled "
                                    "source=%s — not restarting (admin disabled)",
                                    name, _src,
                                )
                                continue
                        if task.cancelled():
                            logger.warning("WATCHDOG: %s was cancelled — restarting", name)
                        else:
                            exc = task.exception()
                            if exc is not None:
                                logger.error(
                                    "WATCHDOG: %s died with exception: %s: %s — restarting",
                                    name, type(exc).__name__, str(exc)[:150],
                                )
                            else:
                                logger.warning(
                                    "WATCHDOG: %s completed unexpectedly — restarting", name)
                        # v97 CHAOS-3: apply backoff.
                        last = _watchdog_last_restart.get(name, 0)
                        backoff = min(60 * (2 ** failures), 600)
                        if time.monotonic() - last < backoff:
                            _watchdog_failure_counts[name] = failures + 1
                            logger.warning(
                                "WATCHDOG: %s restart deferred (backoff=%.0fs, failures=%d/%d)",
                                name, backoff, failures + 1, _WATCHDOG_MAX_FAILURES,
                            )
                            continue
                        # Restart.
                        try:
                            restarter()
                            _watchdog_failure_counts[name] = 0  # reset on success
                            _watchdog_last_restart[name] = time.monotonic()
                            logger.info("WATCHDOG: %s restarted", name)
                        except Exception as restart_exc:  # noqa: BLE001
                            _watchdog_failure_counts[name] = failures + 1
                            logger.error("WATCHDOG: %s restart failed (%d/%d): %s",
                                         name, failures + 1, _WATCHDOG_MAX_FAILURES,
                                         restart_exc)
                except Exception:  # noqa: BLE001
                    pass

            # v97.53: retry handler registration if MTProto is connected
            # but talkative/VC-command handlers are not registered.
            # This honors the promise at bootstrap.py:985 ("will retry on
            # next MTProto reconnect") which was previously unfulfilled.
            try:
                from .mtproto import mtproto_is_started, mtproto_get_client_legacy
                if mtproto_is_started():
                    _client = mtproto_get_client_legacy()
                    if _client is not None and _client.is_connected():
                        import mediagrab_bot.voicechat as _vc_mod
                        import mediagrab_bot.talkative as _talk_mod
                        if not _vc_mod._vc_command_handler_registered:
                            logger.info("WATCHDOG: retrying VC command handler registration")
                            await _vc_mod.vc_register_command_handler()
                        if not _talk_mod._talkative_userbot_handler_registered:
                            # v99.07 FIX-5 (RUNTIME-CRITICAL: the 2026-09-19
                            # log shows "WATCHDOG: retrying talkative handler
                            # registration" + TALKATIVE_EFFECTIVE enabled=False
                            # source=dashboard_db on EVERY 60s watchdog tick
                            # from 06:21:43 to 06:47:43 — 26 retries for a
                            # subsystem the admin intentionally DISABLED).
                            # Gate the retry on the DB-authoritative
                            # effective-enabled state (same pattern as the
                            # auto_discovery/deferred_queue tasks above): a
                            # disabled Talkative legitimately has NO handler.
                            try:
                                from .db_layer import talkative_effective_enabled
                                _talk_eff, _talk_src = await talkative_effective_enabled()
                            except Exception:  # noqa: BLE001
                                _talk_eff, _talk_src = False, "error"
                            if not _talk_eff:
                                logger.debug(
                                    "WATCHDOG: talkative handler not registered "
                                    "but effective_disabled source=%s — not "
                                    "retrying (admin disabled; v99.07 FIX-5)",
                                    _talk_src,
                                )
                            else:
                                logger.info("WATCHDOG: retrying talkative handler registration")
                                try:
                                    from .db_layer import talkative_apply_effective_runtime
                                    await talkative_apply_effective_runtime()
                                except Exception:  # noqa: BLE001
                                    pass
            except Exception:  # noqa: BLE001
                pass

        except asyncio.CancelledError:
            logger.info("Watchdog loop cancelled.")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.warning("Watchdog loop error: %s", exc)


def _watchdog_start() -> None:
    """Start the watchdog background task (idempotent)."""
    global _watchdog_task
    if _watchdog_task is not None and not _watchdog_task.done():
        return
    try:
        _watchdog_task = asyncio.create_task(_watchdog_loop())
    except RuntimeError:
        pass


# V70.1 §5: Auto-reconnect background task for connection_failed accounts.
_cluster_reconnect_task: asyncio.Task | None = None
_CLUSTER_RECONNECT_INTERVAL = 60  # check every 60s
_CLUSTER_RECONNECT_BACKOFF = [60, 300, 900]  # 1m, 5m, 15m


async def _cluster_reconnect_loop() -> None:
    """V70.1 §5: Periodically retry connection_failed accounts.

    For each account with status STATUS_CONNECTION_FAILED, retry connect_account()
    with exponential backoff: 1m → 5m → 15m (then stay at 15m).

    Logs ACCOUNT_RECONNECT_START / ACCOUNT_RECONNECT_SUCCESS / ACCOUNT_RECONNECT_FAILED.
    """
    logger.info("CLUSTER_RECONNECT_LOOP started interval=%ds backoff=%s",
                _CLUSTER_RECONNECT_INTERVAL, _CLUSTER_RECONNECT_BACKOFF)
    # v99.08 sustainability item 3: heartbeat with the worker watchdog
    # (bootstrap-local — no import cycle).
    bot_worker_register("cluster_reconnect_loop",
                        expected_duration=float(_CLUSTER_RECONNECT_INTERVAL) * 1.5)
    while True:
        try:
            bot_worker_heartbeat("cluster_reconnect_loop")  # v99.08 item 3
            await asyncio.sleep(_CLUSTER_RECONNECT_INTERVAL)
            cluster = get_userbot_cluster()
            accounts = cluster.list_accounts()
            now = time.time()
            for acc in accounts:
                aid = acc["account_id"]
                st = acc.get("status", "")
                # v98.01 FIX-K / BUG-A5-5 (ISSUE 5 — cold-path MTProto
                # robustness, SOURCE-PROVEN via A5 subagent):
                # The v97.30 code retried ONLY ``STATUS_CONNECTION_FAILED``
                # accounts. Accounts in ``STATUS_FLOODWAIT`` (whose wait
                # had expired but whose status was never transitioned back
                # to a retryable state) and ``STATUS_DISCONNECTED`` (set
                # during shutdown or initial connect failure) were NEVER
                # retried — they sat silently dead forever.
                #
                # FIX: retry all three retryable states:
                #   * STATUS_CONNECTION_FAILED → retry (existing behavior).
                #   * STATUS_FLOODWAIT where ``floodwait_until <= now`` →
                #     the FloodWait expired; retry (if it FloodWaits again,
                #     connect_account sets a new floodwait_until; if it
                #     succeeds, status → HEALTHY).
                #   * STATUS_DISCONNECTED → retry (same backoff).
                # Accounts in STATUS_HEALTHY / STATUS_CONNECTED are NOT
                # retried here (they're checked by _check_cluster_clients_health
                # which transitions them to STATUS_CONNECTION_FAILED on
                # detected disconnect).
                _fw_until = float(acc.get("floodwait_until", 0) or 0)
                _fw_expired = (st == STATUS_FLOODWAIT and _fw_until and now >= _fw_until)
                if st == STATUS_CONNECTION_FAILED:
                    pass  # retryable (existing path)
                elif _fw_expired:
                    logger.info(
                        "ACCOUNT_RECONNECT_FLOODWAIT_EXPIRED account_id=%s "
                        "phone=%s floodwait_until=%.0f now=%.0f — retrying "
                        "(v98.01 FIX-K: was silently stuck in FLOODWAIT)",
                        aid, acc.get("phone", ""), _fw_until, now,
                    )
                elif st == STATUS_DISCONNECTED:
                    logger.info(
                        "ACCOUNT_RECONNECT_DISCONNECTED account_id=%s "
                        "phone=%s — retrying (v98.01 FIX-K: was silently "
                        "stuck in DISCONNECTED)",
                        aid, acc.get("phone", ""),
                    )
                else:
                    # STATUS_HEALTHY / STATUS_CONNECTED / STATUS_FLOODWAIT-
                    # not-yet-expired / unknown → skip.
                    continue
                if acc.get("disabled"):
                    continue
                last_attempt = float(acc.get("last_connect_attempt", 0) or 0)
                fail_count = int(acc.get("fail_count", 0) or 0)
                # Determine the backoff for this attempt.
                backoff_idx = min(fail_count, len(_CLUSTER_RECONNECT_BACKOFF) - 1)
                wait_needed = _CLUSTER_RECONNECT_BACKOFF[backoff_idx]
                elapsed = now - last_attempt
                if elapsed < wait_needed:
                    continue  # not enough time has passed
                phone = acc.get("phone", "")
                logger.info("ACCOUNT_RECONNECT_START account_id=%s phone=%s "
                            "fail_count=%d backoff=%ds status=%s",
                            aid, phone, fail_count, wait_needed, st)
                try:
                    result = await cluster.connect_account(aid)
                    if result.startswith("connected"):
                        logger.info("ACCOUNT_RECONNECT_SUCCESS account_id=%s "
                                    "phone=%s", aid, phone)
                    else:
                        logger.warning("ACCOUNT_RECONNECT_FAILED account_id=%s "
                                       "phone=%s result=%s", aid, phone, result)
                except Exception as exc:
                    logger.warning("ACCOUNT_RECONNECT_FAILED account_id=%s "
                                   "phone=%s exc=%s: %s", aid, phone,
                                   type(exc).__name__, str(exc)[:120])
                    # v99.02 FIX-4c (RC-4b, RUNTIME-PROVEN via v99.01
                    # production log 2026-09-10 01:01–03:20): 140 consecutive
                    # ACCOUNT_RECONNECT_FAILED at EXACTLY 60s intervals,
                    # every ACCOUNT_RECONNECT_START showing
                    # "fail_count=0 backoff=60s" — the documented
                    # 60→300→900s ladder NEVER engaged. Root cause: the
                    # exception escaped _connect_account_inner BEFORE the
                    # connect phase (the very first self._save() at
                    # mtproto.py:1299 raised
                    # "OSError: [Errno 24] Too many open files:
                    # 'accounts.json.tmp'"), so _classify_connect_exception
                    # (the ONLY place fail_count is incremented for connect
                    # failures) was never reached; this loop's generic
                    # except handler logged the failure WITHOUT counting
                    # it. FIX: ANY failure here increments the account's
                    # fail_count so the backoff ladder engages — exactly
                    # like the classified connect failures do.
                    try:
                        _acc2 = cluster.get_account(aid)
                        if _acc2 is not None:
                            _acc2["fail_count"] = (
                                int(_acc2.get("fail_count", 0) or 0) + 1)
                            _acc2["last_exception"] = (
                                f"{type(exc).__name__}: {str(exc)[:140]}")
                            _acc2["last_exception_type"] = type(exc).__name__
                    except Exception:  # noqa: BLE001
                        pass
        except asyncio.CancelledError:
            logger.info("CLUSTER_RECONNECT_LOOP cancelled")
            raise
        except Exception as exc:
            logger.warning("CLUSTER_RECONNECT_LOOP error (non-fatal): %s: %s",
                           type(exc).__name__, str(exc)[:120])


def _cluster_reconnect_start() -> None:
    """V70.1 §5: Start the auto-reconnect background task (idempotent)."""
    global _cluster_reconnect_task
    if _cluster_reconnect_task is not None and not _cluster_reconnect_task.done():
        return
    try:
        _cluster_reconnect_task = asyncio.create_task(_cluster_reconnect_loop())
    except RuntimeError:
        pass


async def _cluster_startup_validate_bg(cluster) -> None:
    """V89: Background task that runs the slow cluster import + validate.

    Moved out of _post_init so PTB can start polling immediately. If a Telethon
    connect/get_me/is_user_authorized hangs, only THIS task is delayed — polling
    and command handlers continue to work (they check cluster readiness at
    request time and degrade gracefully).

    v97 CRITICAL FIX: wait for mtproto_start() to complete BEFORE validating
    accounts. Previously, this task ran concurrently with mtproto_start(),
    causing connect_account() to create a duplicate TelegramClient on the
    same session file → `OperationalError: database is locked`.
    """
    import time as _t
    _t0 = _t.monotonic()
    logger.info("ACCOUNT_STARTUP_BG_ENTER — cluster validation started in background")

    # v97 CRITICAL FIX: wait for the legacy MTProto client to finish starting.
    # mtproto_start() sets _mtproto_started = True when it completes. If we
    # don't wait, connect_account() won't find the legacy client active and
    # will create a DUPLICATE TelegramClient on the same session file.
    from . import mtproto as _mtproto_mod
    _wait_start = _t.monotonic()
    while not _mtproto_mod._mtproto_started:
        if _t.monotonic() - _wait_start > 70:
            logger.warning(
                "ACCOUNT_STARTUP_BG — mtproto_start() not complete after 70s; "
                "proceeding with cluster validation (may see sqlite_locked)"
            )
            break
        await asyncio.sleep(2)
    if _mtproto_mod._mtproto_started:
        logger.info("ACCOUNT_STARTUP_BG — mtproto_start() complete, proceeding "
                    "with cluster validation (waited %.1fs)",
                    _t.monotonic() - _wait_start)
    try:
        # Part 4: scan data/sessions/*.session and import any not yet registered.
        try:
            import_report = await asyncio.wait_for(
                cluster.import_existing_sessions(), timeout=120)
        except asyncio.TimeoutError:
            import_report = {"scanned": 0, "imported": 0, "duplicate": 0, "failed": 0, "timeout": True}
            logger.warning("ACCOUNT_IMPORT_STARTUP timed out after 120s (non-fatal).")
        except Exception as exc:  # noqa: BLE001
            import_report = {"scanned": 0, "imported": 0, "duplicate": 0, "failed": 0, "error": True}
            logger.warning("ACCOUNT_IMPORT_STARTUP failed (non-fatal): %s", exc)
        logger.info(
            "ACCOUNT_IMPORT_STARTUP scanned=%d imported=%d duplicate=%d failed=%d",
            import_report["scanned"], import_report["imported"],
            import_report["duplicate"], import_report["failed"],
        )
        # Part 5: validate every registered account.
        try:
            validate_report = await asyncio.wait_for(
                cluster.startup_validate(), timeout=120)
        except asyncio.TimeoutError:
            validate_report = {"total": 0, "sessions_found": 0, "imported": 0,
                               "connected": 0, "failed": 0, "timeout": True}
            logger.warning("ACCOUNT_STARTUP_VALIDATION timed out after 120s (non-fatal).")
        except Exception as exc:  # noqa: BLE001
            validate_report = {"total": 0, "sessions_found": 0, "imported": 0,
                               "connected": 0, "failed": 0, "error": True}
            logger.warning("ACCOUNT_STARTUP_VALIDATION failed (non-fatal): %s", exc)
        logger.info(
            "ACCOUNT_STARTUP_VALIDATION total=%d sessions_found=%d imported=%d "
            "connected=%d failed=%d",
            validate_report["total"], validate_report["sessions_found"],
            validate_report["imported"], validate_report["connected"],
            validate_report["failed"],
        )
        # If we have healthy accounts but no persisted primary, promote the
        # first one so routing is deterministic from boot.
        if not cluster.get_primary_id():
            healthy = cluster.get_healthy_accounts()
            if healthy:
                healthy.sort(key=lambda a: float(a.get("created_at", 0)))
                first_aid = healthy[0]["account_id"]
                cluster.set_primary_id(first_aid)
                if cluster._accounts[first_aid].get("role") != ROLE_PRIMARY:
                    cluster._accounts[first_aid]["role"] = ROLE_PRIMARY
                    cluster._save()
                logger.info("ACCOUNT_AUTO_PRIMARY account_id=%s", first_aid)
        # v98.12-FINAL2 FIX-SR (§3 scenarios C/D — the SECOND-RUN core fix):
        # with the cluster now connected, run the one-per-process startup VC
        # reconcile: for every registry-joined record, verify SERVER-SIDE
        # participation via the OWNER account (account-aware detection +
        # targeted participant query) BEFORE any JoinGroupCall is re-issued.
        #   present  → registry joined + coordinator JOINED (server proof);
        #   absent   → registry left + coordinator LEFT (dead target
        #              pre-cleaned — the Join-All no longer wastes an
        #              attempt, and no false already_joined is reported);
        #   unknown  → preserved (weak evidence) — Join-All's stale-record
        #              repair owns the transport re-establishment.
        # Runs in its own supervised task so a slow verify never blocks
        # this validator (and never blocks polling startup).
        try:
            from .voicechat import vc_startup_reconcile_participations
            supervised_create_task(
                vc_startup_reconcile_participations(),
                name="vc_startup_reconcile_final2",
            )
            logger.info(
                "VC_STARTUP_RECONCILE_SCHEDULED — second-run VC state "
                "reconstruction running in background (v98.12-FINAL2 FIX-SR)"
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "VC_STARTUP_RECONCILE_SCHEDULE_FAILED (non-fatal): %s", exc)
    except Exception as exc:  # noqa: BLE001
        logger.warning("V89 cluster startup validation task failed (non-fatal): %s", exc)
    finally:
        logger.info("ACCOUNT_STARTUP_BG_EXIT duration_ms=%d",
                    int((_t.monotonic() - _t0) * 1000))


async def _post_init(app: Application) -> None:
    # V85 §1: delegate to RuntimeController first — installs InstanceGuard,
    # emits UPDATE_MODE diagnostic, prevents duplicate initialization.
    try:
        await RuntimeController.post_init(app)
    except Exception as exc:  # noqa: BLE001
        logger.warning("V85 RuntimeController.post_init failed (non-fatal): %s", exc)
    # RELI-J-006: idempotency guard — if we've already initialized this
    # process, skip the rest. Some PTB restart paths invoke _post_init twice.
    global _post_init_done
    if _post_init_done:
        logger.info("_post_init already completed — skipping duplicate initialization.")
        return
    _post_init_done = True
    # V47 Fix: install the asyncio exception handler now that we're inside
    # the running event loop. Uses get_running_loop() (safe in a coroutine).
    _install_asyncio_handler()
    # RUNTIME_DEBUG: start event loop lag + task dump monitors if enabled.
    try:
        from .runtime_debug import start_runtime_debug
        start_runtime_debug()
    except Exception:  # noqa: BLE001
        pass
    # ASYNC-I-003: bound init_db with a timeout so a hung DB initialization
    # cannot block startup indefinitely. Non-fatal — log and continue.
    try:
        await asyncio.wait_for(init_db(), timeout=30)
    except asyncio.TimeoutError:
        logger.error("init_db timed out after 30s — continuing startup (non-fatal).")
    except Exception as exc:  # noqa: BLE001
        logger.error("init_db failed: %s — continuing startup (non-fatal).", exc)
    # Register the Bot instance so background services (MTProto capture
    # handler) can send messages without needing the Application object.
    register_bot(app.bot)
    # Task ID 16 — fetch + cache the bot's identity for Talkative trigger
    # detection (reply / mention / name). Non-fatal if it fails.
    # v97 CRITICAL FIX: wrap in a timeout — this Bot API call can hang
    # if the network is flaky, blocking the entire _post_init and
    # preventing run_polling() from starting.
    try:
        await asyncio.wait_for(_talkative_fetch_bot_identity(app), timeout=15)
    except asyncio.TimeoutError:
        logger.warning("_talkative_fetch_bot_identity timed out after 15s (non-fatal).")
    except Exception as exc:  # noqa: BLE001
        logger.warning("_talkative_fetch_bot_identity failed (non-fatal): %s", exc)
    # V56 Fix: use module-level registry instead of app._bg_tasks (PTB Application
    # is slot-based and doesn't allow custom attributes).
    global _app_bg_tasks
    _app_bg_tasks = [
        asyncio.create_task(
            periodic_cleanup(
                config.downloads_dir, config.frames_dir,
                interval=600, max_age=3600,
            )
        ),
        asyncio.create_task(_scheduled_loop(app)),
    ]
    # Task ID 16 — start the Talkative cleanup background task (sessions +
    # memory + stale cooldowns). Idempotent: safe to call even when
    # Talkative is disabled (the loop just becomes a no-op).
    try:
        _talkative_start_cleanup_task()
        logger.info("Talkative cleanup task started.")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Talkative cleanup task start failed (non-fatal): %s", exc)
    # V62 Fix #14: initialize known provider states at startup to avoid
    # lazy concurrent mutation of _provider_health.
    try:
        _provider_init_states()
        logger.info("Provider health states initialized (groq, openrouter, gemini).")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Provider health init failed (non-fatal): %s", exc)
    # V62: start the dashboard snapshot writer so the Next.js admin dashboard
    # can surface real bot state (provider health + talkative metrics).
    try:
        _dashboard_snapshot_start()
        logger.info("Dashboard snapshot task started.")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Dashboard snapshot task start failed (non-fatal): %s", exc)
    # V63: start the bot heartbeat (5s) + history archiver (60s) so the
    # dashboard can detect whether the bot is running and plot trends.
    try:
        _bot_heartbeat_start()
        logger.info("Bot heartbeat task started.")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Bot heartbeat task start failed (non-fatal): %s", exc)
    try:
        _bot_history_start()
        logger.info("Bot history archiver task started.")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Bot history archiver task start failed (non-fatal): %s", exc)
    # V65: auto-start the dashboard-live WebSocket mini-service.
    # v97.34: offload to a thread so the bun auto-install download (if needed)
    # doesn't block the event loop during startup.
    try:
        await asyncio.to_thread(_dashboard_live_start)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Dashboard live start failed (non-fatal): %s", exc)
    # Start the MTProto backend if configured (background service).
    if config.mtproto_configured:
        try:
            # ASYNC-I-003: bound mtproto_manager.start with a timeout so a
            # hung connect cannot block startup. Non-fatal on timeout/failure.
            result = await asyncio.wait_for(mtproto_manager.start(), timeout=60)
            logger.info("MTProto backend startup: %s", result)
        except asyncio.TimeoutError:
            logger.warning("MTProto backend startup timed out after 60s (non-fatal).")
        except Exception as exc:  # noqa: BLE001
            logger.warning("MTProto backend failed to start (non-fatal): %s", exc)
        # v98.08 FIX-YY: boot-time CLIENT_SCOPE_MAP banner — every live
        # client scope token → owning account_id (F3': the v98.07 log's
        # client:102535920 tokens were only resolvable by cross-referencing
        # SESSION_OWNER_ACQUIRED lines; now one banner states the map).
        try:
            from .voicechat import _vc_emit_client_scope_map_banner as _v808_scope_banner
            _v808_scope_banner()
        except Exception as exc:  # noqa: BLE001
            logger.debug("CLIENT_SCOPE_MAP banner failed (non-fatal): %s", exc)
        # Register VC tour in-group command handler + reconcile stale state.
        # V41 Fix #9: VC Tour is intentionally .env-gated (VC_TOUR_ENABLED).
        # This is the master kill switch — there is no dashboard toggle for
        # VC Tour enabled/disabled. The env var IS the authoritative source.
        # This is documented + logged for transparency.
        try:
            # v97: wrap in a timeout — reconcile_on_startup does DB reads
            # which could block under contention.
            await asyncio.wait_for(vc_tour.reconcile_on_startup(), timeout=15)
            if config.vc_tour_enabled:
                # P1 fix #12/#15: check return value and retry if needed.
                registered = await vc_tour.register_command_handler()
                if registered:
                    logger.info(
                        "VC tour command handler registered (source=env VC_TOUR_ENABLED=true). "
                        "VC Tour is env-gated — no dashboard toggle exists.")
                else:
                    logger.warning("VC tour command handler NOT registered — will retry on next MTProto reconnect.")
            else:
                logger.info(
                    "VC tour disabled (source=env VC_TOUR_ENABLED=false). "
                    "VC Tour is env-gated — set VC_TOUR_ENABLED=true to enable. "
                    "No dashboard toggle exists for this feature.")
        except Exception as exc:  # noqa: BLE001
            logger.warning("VC tour init failed (non-fatal): %s", exc)
        # V41 Fix #6: Talkative V2 — use the unified effective-enabled resolver.
        # Precedence: master_kill_override → dashboard_db → env_default → code_default.
        # The env var TALKATIVE_ENABLED is the bootstrap default, NOT a hard
        # kill switch — the DB-persisted dashboard setting wins when non-NULL.
        try:
            # v97 CRITICAL FIX: wrap in a timeout — talkative_apply_effective_runtime
            # calls _cache_userbot_identity() which does client.get_me() (Telethon
            # RPC). If the Telethon connection is flaky, this can hang indefinitely.
            talk_active = await asyncio.wait_for(
                talkative_apply_effective_runtime(), timeout=20)
            if talk_active:
                # Also log the effective provider for Fix #7 traceability.
                try:
                    prov, psrc, model, pready, preason = await talkative_effective_provider()
                    logger.info(
                        "TALKATIVE_PROVIDER effective=%s source=%s model=%s ready=%s reason=%s",
                        prov, psrc, model, pready, preason or "ok",
                    )
                except Exception:  # noqa: BLE001
                    pass
            else:
                # Log WHY it's disabled (transparency for the admin).
                try:
                    enabled, source = await talkative_effective_enabled()
                    logger.info(
                        "Talkative runtime inactive (enabled=%s source=%s env_master=%s). "
                        "Use the dashboard ON button to enable (persists across restarts).",
                        enabled, source, config.talkative_enabled,
                    )
                except Exception:  # noqa: BLE001
                    logger.info("Talkative runtime inactive.")
        except Exception as exc:  # noqa: BLE001
            logger.warning("Talkative userbot handler init failed (non-fatal): %s", exc)
        # Task ID 18 — start the VC participation reconciliation loop.
        # Non-destructive: collects capability evidence + verifies tracked
        # targets every config.vc_reconcile_interval seconds.  Idempotent.
        try:
            _vc_reconcile_start()
            logger.info("VC reconcile loop started.")
        except Exception as exc:  # noqa: BLE001
            logger.warning("VC reconcile loop start failed (non-fatal): %s", exc)
        # v98.07 FIX-SS: heartbeat canary (thread-based, immune to event-loop
        # blockage) + the 5s liveness stamp task. The canary converts the
        # F1-class "95 minutes of silent freeze" into a ≤3-minute crash with
        # a full ALL-thread stack dump naming the blocking frame.
        try:
            _vc_start_heartbeat_canary()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Heartbeat canary start failed (non-fatal): %s", exc)
        try:
            _vc_loop_liveness_start()
            logger.info("VC loop liveness task started (v98.07 FIX-SS).")
        except Exception as exc:  # noqa: BLE001
            logger.warning("VC loop liveness start failed (non-fatal): %s", exc)
        # v98.07 FIX-UU: session hot-reload — .session files dropped into the
        # 4 roots AFTER boot are imported WITHOUT a restart (60s rescan).
        try:
            _vc_session_hot_reload_start()
            logger.info("Session hot-reload loop started (v98.07 FIX-UU).")
        except Exception as exc:  # noqa: BLE001
            logger.warning("Session hot-reload start failed (non-fatal): %s", exc)
        # v97: Join-All startup recovery — mark any interrupted run so it
        # doesn't block future runs. The admin can manually resume via
        # /joinallresume or the dashboard button.
        try:
            # v97: wrap in a timeout — does DB reads.
            await asyncio.wait_for(vc_join_all_startup_recovery(), timeout=10)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Join-All startup recovery failed (non-fatal): %s", exc)
        # #26: Old scheduled Discovery is DISABLED — Discovery V2 replaces it.
        # The old vc_discovery_start() always returns "disabled_v2".
        # V63 Fix #2: ACTUALLY start the Autonomous Discovery (auto_discovery_start)
        # — V62 only called the old disabled vc_discovery_start(), so the scheduler
        # never ran. This is the root cause of "Auto discovery: idle, cycle: 0".
        try:
            _dres = await asyncio.wait_for(vc_discovery_start(), timeout=10)
            logger.info("Old discovery: %s (replaced by Discovery V2)", _dres)
        except Exception as exc:  # noqa: BLE001
            logger.warning("VC discovery loop start failed (non-fatal): %s", exc)
        # V63 Fix #2: start the Auto Discovery scheduler.
        try:
            _auto_res = await asyncio.wait_for(auto_discovery_start(), timeout=10)
            logger.info("Auto discovery: %s", _auto_res)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Auto discovery start failed (non-fatal): %s", exc)
        # V64 Fix: start the dedicated deferred queue worker.
        try:
            _deferred_queue_start()
            logger.info("Deferred queue worker started.")
        except Exception as exc:  # noqa: BLE001
            logger.warning("Deferred queue worker start failed (non-fatal): %s", exc)
    else:
        logger.info("MTProto backend disabled (MTPROTO_ENABLED=false).")
    # V60 Fix #13: startup self-check for the voice enrollment subsystem.
    # Reports a truthful end-to-end dependency status so the admin can see
    # exactly why enrollment is or isn't Ready.
    try:
        # v97: wrap in a timeout — does DB + filesystem checks.
        sc = await asyncio.wait_for(_voice_enroll_selfcheck_async(), timeout=10)
        logger.info("VOICE_ENROLL_SELFCHECK status=%s missing=%s provider=%s "
                    "ffmpeg=%s ffprobe=%s handler=%s db=%s table=%s",
                    sc.get("status"), sc.get("missing"),
                    sc.get("provider_name") or "(none)",
                    sc.get("ffmpeg_available"), sc.get("ffprobe_available"),
                    sc.get("handler_registered"), sc.get("db_ready"),
                    sc.get("voice_profiles_table"))
    except Exception as exc:  # noqa: BLE001
        logger.warning("VOICE_ENROLL_SELFCHECK_FAILED exc=%s", exc)
    # V63 Fix #4: start the background watchdog.
    try:
        _watchdog_start()
        logger.info("Background watchdog started.")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Watchdog start failed (non-fatal): %s", exc)
    # V93 FIX: start the task-dump diagnostic loop.
    try:
        _task_dump_start()
        logger.info("Task-dump diagnostic loop started.")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Task-dump start failed (non-fatal): %s", exc)
    # V94 FIX: start the event-loop lag monitor.
    try:
        _event_loop_lag_start()
        logger.info("Event-loop lag monitor started.")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Event-loop lag monitor start failed (non-fatal): %s", exc)
    # v98.05 FIX-FF/FIX-KK: start the worker watchdog (tracks BOT_WORKER_*
    # markers and recovers stuck workers).
    try:
        _bot_worker_watchdog_start()
        logger.info("Worker watchdog started (v98.05 FIX-FF/FIX-KK).")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Worker watchdog start failed (non-fatal): %s", exc)
    # V70.1 §5: start the cluster auto-reconnect loop (1m/5m/15m backoff).
    try:
        _cluster_reconnect_start()
        logger.info("Cluster auto-reconnect loop started (backoff 1m/5m/15m).")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Cluster auto-reconnect start failed (non-fatal): %s", exc)
    # V76 PART 2: start the VC coverage reconciler (every 60s).
    try:
        await get_vc_coverage_manager().start_reconciler()
        logger.info("VC coverage reconciler started (interval=60s).")
    except Exception as exc:  # noqa: BLE001
        logger.warning("VC coverage reconciler start failed (non-fatal): %s", exc)
    # V89 FIX (ROOT CAUSE of /start no-reply):
    # Previously, cluster.import_existing_sessions() + cluster.startup_validate()
    # were awaited directly inside _post_init with 120s timeouts each. PTB's
    # run_polling() calls post_init BEFORE start_polling() (see PTB _application.py
    # __run lines 1081→1085), so a hung Telethon connect/get_me/is_user_authorized
    # blocked polling from starting for up to 240s. The bot appeared "started but
    # silent" — no /start reply because getUpdates had never begun.
    #
    # FIX: move ALL slow MTProto/cluster network I/O into a fire-and-forget
    # background task. _post_init returns immediately; PTB starts polling within
    # milliseconds; cluster validation completes in parallel. The cluster just
    # won't be "healthy" for the first few seconds of uptime — which is fine,
    # because Talkative/Discovery/VC gracefully degrade when the cluster isn't
    # ready yet (they check cluster.get_primary_id() at request time).
    # V90 FIX: _app_bg_tasks is a list, not a set. Use supervised_create_task
    # (which tracks in _active_tasks, a set) instead of manual .add()/.discard()
    # which raised AttributeError: 'list' object has no attribute 'add'.
    try:
        cluster = get_userbot_cluster()
        supervised_create_task(
            _cluster_startup_validate_bg(cluster),
            name="cluster_startup_validate_bg",
        )
        logger.info("ACCOUNT_STARTUP_BG_SCHEDULED — cluster validation running in "
                    "background; polling will start immediately.")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to schedule cluster startup validation (non-fatal): %s", exc)
    # v99.04 RC-17: if the boot build-identity verdict was MISMATCH, start
    # the background deploy-health recovery loop — it re-verifies the full
    # identity every 120s (re-running the RC-9 ZIP / RC-14 embedded heal)
    # and re-opens the VC pipeline the moment the tree matches the stamp,
    # WITHOUT a restart (mission §9: healthy → broken → repaired → healthy).
    try:
        _v9904_deploy_recovery_schedule()
    except Exception as exc:  # noqa: BLE001
        logger.debug("deploy-health recovery scheduling failed (non-fatal): %s", exc)
    # V86 (P6 Task 4): seed the curated Media Reaction Engine library with a
    # small default emoji set so the engine has something to send before an
    # admin curates real stickers/GIFs. Idempotent — skips if already seeded.
    try:
        # v97: wrap in a timeout — does DB writes.
        await asyncio.wait_for(_media_seed_default_library(), timeout=10)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Media library seed failed (non-fatal): %s", exc)
    logger.info("Bot post-init complete (DB + cleanup + scheduled loop + "
                "MTProto + VC + Talkative + reconcile + voice_enroll + watchdog + "
                "cluster import/validate + media_library_seed).")
    # V96: log startup phase timing summary.
    try:
        _summary = RuntimeControllerV96.startup_summary()
        if _summary["phases"]:
            logger.info(
                "STARTUP_PHASES summary phases=%s",
                json.dumps(_summary["phases"]),
            )
    except Exception:  # noqa: BLE001
        pass


async def _post_stop(app: Application) -> None:
    # V85.3 FIX BUG 7.2: cancel the background watchdog FIRST, before any
    # subsystem stop.  The watchdog restarts dead tasks every 60s; if it
    # wakes during shutdown it would re-start tasks we just cancelled
    # (e.g. _vc_reconcile_start), and those restarted tasks are raw
    # create_task calls NOT in _active_tasks, so they survive the
    # _active_tasks cancel sweep and are abandoned when the loop closes.
    global _watchdog_task
    global _post_init_done  # RELI-J-006: reset so a subsequent startup re-initializes.
    if _watchdog_task is not None and not _watchdog_task.done():
        _watchdog_task.cancel()
        try:
            await asyncio.wait_for(_watchdog_task, timeout=5)
        except (asyncio.TimeoutError, asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
    _watchdog_task = None
    # V85.3 FIX BUG 1.2: cancel the cluster reconnect loop too (raw task).
    global _cluster_reconnect_task
    if _cluster_reconnect_task is not None and not _cluster_reconnect_task.done():
        _cluster_reconnect_task.cancel()
        try:
            await asyncio.wait_for(_cluster_reconnect_task, timeout=5)
        except (asyncio.TimeoutError, asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
    _cluster_reconnect_task = None
    # v97.59 §15: deterministic shutdown — stop the VC operation scheduler FIRST
    # so no new VC operations start during shutdown. The scheduler cancels
    # in-flight ops with a bounded timeout + drains queued ops.
    try:
        from .voicechat import get_vc_scheduler
        _sched = get_vc_scheduler()
        if _sched._workers:  # only if started
            logger.info("SHUTDOWN: stopping VC operation scheduler")
            await _sched.stop(timeout=10)
    except Exception as exc:  # noqa: BLE001
        logger.warning("SHUTDOWN: VC scheduler stop failed (non-fatal): %s", exc)
    # V85 §1: release InstanceGuard + close any V85-registered HTTP clients.
    try:
        await v85_close_all_http_clients()
    except Exception as exc:  # noqa: BLE001
        logger.debug("V85 HTTP client cleanup failed: %s", exc)
    # V86 multimodal: close the Wit.ai httpx client (singleton).
    try:
        await witai_service.close()
    except Exception as exc:  # noqa: BLE001
        logger.debug("Wit.ai client cleanup failed: %s", exc)
    try:
        await RuntimeController.post_stop(app)
    except Exception as exc:  # noqa: BLE001
        logger.warning("V85 RuntimeController.post_stop failed (non-fatal): %s", exc)
    # V65: stop the dashboard-live WebSocket mini-service subprocess.
    try:
        _dashboard_live_stop()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Dashboard live stop failed (non-fatal): %s", exc)
    # Shutdown ordering (Task ID 18 — extended for Multi-VC participations):
    #   1. cancel background tasks (cleanup loop, scheduled loop)
    #   2. stop Talkative cleanup task + close httpx client
    #   3. stop VC reconcile loop (Task ID 18)
    #   4. stop VC tour (cancels tour task, leaves active VC cleanly)
    #   5. cleanup tracked participations (leave all tracked targets with
    #      bounded timeouts — Task ID 18)
    #   6. stop PyTgCalls backend (leaves any lingering VC, releases the
    #      PyTgCalls instance) — MUST happen BEFORE MTProto stop because
    #      the backend holds a reference to the MTProto client.
    #   7. stop MTProto (disconnects the Telethon client)
    #   8. close DB
    # Each step is wrapped in a bounded try/except so a hang in one layer
    # cannot block the rest of shutdown.
    # V56 Fix: use module-level _app_bg_tasks instead of app._bg_tasks.
    for task in _app_bg_tasks:
        if not task.done():
            task.cancel()
    if _app_bg_tasks:
        # RELI-J-002: bound the gather so a hung bg task cannot block
        # shutdown indefinitely. (Asyncio gather without a timeout could
        # deadlock on a task that ignores CancelledError.)
        try:
            await asyncio.wait_for(
                asyncio.gather(*_app_bg_tasks, return_exceptions=True),
                timeout=10,
            )
        except asyncio.TimeoutError:
            logger.warning("app_bg_tasks gather timed out after 10s — proceeding.")
        except Exception:  # noqa: BLE001
            pass
    _app_bg_tasks.clear()
    # V93 FIX: cancel the task-dump diagnostic loop too.
    global _task_dump_task
    if _task_dump_task is not None and not _task_dump_task.done():
        _task_dump_task.cancel()
        try:
            await asyncio.wait_for(_task_dump_task, timeout=3)
        except (asyncio.TimeoutError, asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
    _task_dump_task = None
    # V94 FIX: cancel the event-loop lag monitor too.
    global _event_loop_lag_task
    if _event_loop_lag_task is not None and not _event_loop_lag_task.done():
        _event_loop_lag_task.cancel()
        try:
            await asyncio.wait_for(_event_loop_lag_task, timeout=3)
        except (asyncio.TimeoutError, asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
    _event_loop_lag_task = None
    # V95 FIX: cancel the dashboard snapshot, bot heartbeat, and bot history
    # tasks. These were previously NOT explicitly cancelled (they relied on
    # the event loop closing to clean them up). Explicit cancellation ensures
    # their finally blocks run and they don't leak on graceful-but-incomplete
    # shutdown (e.g. test harness, signal handler).
    # NOTE: these tasks are created in handlers.py (_dashboard_snapshot_start /
    # _bot_heartbeat_start / _bot_history_start) which own the module globals.
    # Access handlers' module attributes directly so we cancel the REAL tasks
    # (bootstrap's own globals are stale None copies).
    import mediagrab_bot.handlers as _hd_mod
    _snap = getattr(_hd_mod, "_dashboard_snapshot_task", None)
    if _snap is not None and not _snap.done():
        _snap.cancel()
        try:
            await asyncio.wait_for(_snap, timeout=3)
        except (asyncio.TimeoutError, asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
    _hd_mod._dashboard_snapshot_task = None
    _hb = getattr(_hd_mod, "_bot_heartbeat_task", None)
    if _hb is not None and not _hb.done():
        _hb.cancel()
        try:
            await asyncio.wait_for(_hb, timeout=3)
        except (asyncio.TimeoutError, asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
    _hd_mod._bot_heartbeat_task = None
    _hist = getattr(_hd_mod, "_bot_history_task", None)
    if _hist is not None and not _hist.done():
        _hist.cancel()
        try:
            await asyncio.wait_for(_hist, timeout=3)
        except (asyncio.TimeoutError, asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
    _hd_mod._bot_history_task = None
    # 1b. Cancel supervised fire-and-forget tasks (Phase 5 — strong-ref
    #     registry).  V85.3 FIX BUG 1.10: await them after cancelling so
    #     their finally blocks run (prevents abandoned mid-cleanup state).
    #     V85.3 FIX BUG 1.8/1.9: call the graceful stop functions for the
    #     deferred queue + auto discovery FIRST so they set their stop
    #     events + update state to "stopped" (instead of being killed
    #     abruptly mid-iteration leaving state as "running").
    try:
        await _deferred_queue_stop_worker()
    except Exception:  # noqa: BLE001
        pass
    try:
        await auto_discovery_stop()
    except Exception:  # noqa: BLE001
        pass
    # v97.1 MULTI-ACCOUNT: clear the distributed assignment/load registries
    # so a subsequent startup starts clean (no stale vc_id -> account_id).
    try:
        from .distributed_join import distributed_reset
        await distributed_reset()
    except Exception:  # noqa: BLE001
        pass
    # v97.2 BUG 1 FIX: cancel + await any in-flight distributed worker tasks
    # before the generic _active_tasks sweep.  This guarantees no orphan
    # distributed workers survive shutdown (no "Task was destroyed but it is
    # pending").  The pool tasks are also in _active_tasks, but cancelling
    # them here first ensures their finally blocks (which release in-flight
    # locks + assignments) run cleanly.
    try:
        from .voicechat import _vc_distributed_cancel_pool
        await _vc_distributed_cancel_pool()
    except Exception:  # noqa: BLE001
        pass
    # v97.5 SHUTDOWN-ORDER FIX: gracefully stop the Join-All worker BEFORE
    # the blanket ``_active_tasks`` sweep below.  Previously, step 14
    # (the _active_tasks cancel) ran FIRST and abruptly cancelled the
    # Join-All worker (which is a supervised task) — so by the time the
    # graceful-stop block (formerly step 19a, inside the mtproto block)
    # ran, ``_worker.done()`` was already True and the cooperative stop
    # signal (``_vc_join_all_stop_requested = True``) was NEVER set.
    # This caused "Task was destroyed but it is pending" warnings + skipped
    # the worker's cooperative cleanup (checkpoint save, assignment release,
    # circuit-breaker snapshot).  Moving the graceful stop here ensures the
    # worker receives the stop signal, saves its final checkpoint, and
    # releases all distributed assignments before the blanket cancel.
    try:
        import mediagrab_bot.voicechat as _vc_mod
        _worker = _vc_mod._vc_join_all_worker
        if _worker is not None and not _worker.done():
            _vc_mod._vc_join_all_stop_requested = True
            # Cooperative cancellation via the CancellationToken too.
            try:
                _vc_mod._vc_join_all_cancel_token.cancel(reason="shutdown")
            except Exception:  # noqa: BLE001
                pass
            _worker.cancel()
            try:
                await asyncio.wait_for(_worker, timeout=10)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                logger.warning("Join-All worker did not stop in 10s — proceeding.")
        _vc_mod._vc_join_all_worker = None
    except Exception as exc:  # noqa: BLE001
        logger.debug("Join-All worker graceful stop error: %s", exc)
    # v97.92 SHUTDOWN-ORDER FIX (runtime-proven — Task 1-c BUG-H6 / Task 1-d BUG-S2):
    #   The previous code ran the ``_active_tasks`` blanket cancel sweep HERE
    #   (BEFORE ``vc_leave_all_tracked`` ran at step 5 below). This meant:
    #     - The MTProto reconnect task (in _active_tasks via supervised_create_task)
    #       was cancelled mid-flight, leaving the client in a partial state.
    #     - When ``vc_leave_all_tracked`` then issued leave RPCs (60s budget),
    #       they could fail with ``Cannot send requests while disconnected``
    #       because the client was half-disconnected.
    #     - On the bot-diagnostic (4).log cascade, this contributed to the
    #       "VC disappears" symptom during shutdown.
    #   FIX: SELECTIVELY cancel only the worker/loop tasks here (preserve the
    #   MTProto reconnect task + any other task that vc_leave_all_tracked
    #   depends on). The blanket sweep is moved to AFTER vc_leave_all_tracked
    #   + backend.stop() + mtproto_stop() — by then the MTProto client is
    #   being torn down explicitly and there's no more work for the
    #   reconnect task to do.
    _SHUTDOWN_PRESERVE_PREFIXES = ("mtproto_safe_reconnect",)
    for task in list(_active_tasks):
        if task.done():
            continue
        _tname = ""
        try:
            _tname = task.get_name() if hasattr(task, "get_name") else ""
        except Exception:  # noqa: BLE001
            _tname = ""
        # v97.92: skip the MTProto reconnect task — it must survive long
        # enough to serve the leave RPCs in vc_leave_all_tracked.
        if any(_tname.startswith(p) for p in _SHUTDOWN_PRESERVE_PREFIXES):
            continue
        task.cancel()
    # Await the cancelled subset (preserving the reconnect task).
    _to_await = [t for t in list(_active_tasks) if not t.done()]
    if _to_await:
        try:
            await asyncio.wait_for(
                asyncio.gather(*_to_await, return_exceptions=True),
                timeout=10)
        except (asyncio.TimeoutError, Exception):  # noqa: BLE001
            pass
    # NOTE: _active_tasks is NOT cleared here — the preserved reconnect task
    # is still in it. It will be cleared by the post-MTProto-stop sweep below.
    # 1c. Stop auto-refresh tasks (Fix 1/2).
    try:
        await _vc_dashboard_auto_refresh_stop_all()
    except Exception:  # noqa: BLE001
        pass
    try:
        await _vc_join_all_auto_refresh_stop_all()
    except Exception:  # noqa: BLE001
        pass
    # 1c. Stop VC Watcher (#18 shutdown).
    try:
        await vc_watcher_stop()
    except Exception:  # noqa: BLE001
        pass
    # 2. Stop the Talkative cleanup task + close httpx client.
    try:
        await _talkative_stop_cleanup_task()
    except Exception as exc:  # noqa: BLE001
        logger.debug("Talkative cleanup stop error: %s", exc)
    # 2b. Stop the VCCoverageManager reconciler (orphan task leak fix).
    # NOTE: start_reconciler is called unconditionally in _post_init (line 914),
    # so stop must also be unconditional to avoid orphan tasks.
    try:
        await asyncio.wait_for(
            get_vc_coverage_manager().stop_reconciler(), timeout=5,
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("VC coverage reconciler stop error: %s", exc)
    # 3-7. Stop the MTProto-dependent subsystems.
    if config.mtproto_configured:
        # v97.5: the Join-All graceful stop was moved EARLIER (before the
        # _active_tasks sweep) — see the block above.  This block is now a
        # no-op fallback that just clears the worker reference if it wasn't
        # already cleared (defensive — should already be None).
        try:
            import mediagrab_bot.voicechat as _vc_mod
            _vc_mod._vc_join_all_worker = None
        except Exception:  # noqa: BLE001
            pass
        # 3. Stop the VC reconcile loop (Task ID 18).
        try:
            await _vc_reconcile_stop()
        except Exception as exc:  # noqa: BLE001
            logger.debug("VC reconcile stop error: %s", exc)
        # 3b. Stop the VC Group Discovery loop (#33).
        try:
            await vc_discovery_stop()
        except Exception as exc:  # noqa: BLE001
            logger.debug("VC discovery stop error: %s", exc)
        # 4. Stop the VC tour first (leave active VC cleanly).
        try:
            await asyncio.wait_for(vc_tour.stop_tour(), timeout=15)
        except asyncio.TimeoutError:
            logger.warning("VC tour stop timed out after 15s — proceeding.")
        except Exception as exc:  # noqa: BLE001
            logger.debug("VC tour stop error: %s", exc)
        # 5. Cleanup tracked participations (Phase 3 — P0 force-cleanup).
        #    On SHUTDOWN we leave ALL tracked targets (including intentional)
        #    because the backend is being torn down and MTProto will
        #    disconnect — any lingering VC participation would become a ghost.
        #    force=True ensures intentional participations are NOT skipped.
        #    The admin "Leave All Tracked" BUTTON uses force=False (default)
        #    so intentional participations survive a tour stop.
        try:
            result = await asyncio.wait_for(
                vc_leave_all_tracked(force=True), timeout=60,
            )
            logger.info(
                "VC participation cleanup: total=%d success=%d failed=%d "
                "unknown=%d timeout=%d",
                result["total"], result["success"], result["failed"],
                result["unknown"], result["timeout"],
            )
        except asyncio.TimeoutError:
            logger.warning(
                "VC participation cleanup timed out after 60s — proceeding. "
                "Some tracked targets may require manual cleanup."
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug("VC participation cleanup error: %s", exc)
        # 6. Stop the PyTgCalls backend explicitly.  vc_tour.stop_tour()
        #    keeps the backend alive across tour cycles, so we must stop it
        #    here before MTProto is torn down.  Bounded timeout prevents a
        #    hung leave() from blocking shutdown.
        try:
            backend = vc_get_backend()
            if backend is not None:
                await asyncio.wait_for(backend.stop(), timeout=10)
                logger.info("VC backend stopped during shutdown.")
        except asyncio.TimeoutError:
            logger.warning("VC backend stop timed out after 10s — proceeding.")
        except Exception as exc:  # noqa: BLE001
            logger.debug("VC backend stop error: %s", exc)
        finally:
            # Drop the cached backend reference so a restart builds a fresh one.
            vc_reset_backend()
        # 7. Stop MTProto (the PyTgCalls backend no longer references it).
        # RELI-J-003: bound with a timeout so a hung disconnect cannot
        # block shutdown.
        try:
            await asyncio.wait_for(mtproto_manager.stop(), timeout=15)
        except asyncio.TimeoutError:
            logger.warning("MTProto stop timed out after 15s — proceeding.")
        except Exception as exc:  # noqa: BLE001
            logger.debug("MTProto stop error: %s", exc)
        # v97.92: NOW do the blanket sweep of _active_tasks. By this point
        # vc_leave_all_tracked + backend.stop() have completed + MTProto is
        # stopped — any remaining supervised task (including the
        # preserved MTProto reconnect task from the v97.92 fix above) can
        # be safely cancelled. The reconnect task is now a no-op (client
        # is stopped) and will exit on its next iteration.
        try:
            for task in list(_active_tasks):
                if not task.done():
                    task.cancel()
            if _active_tasks:
                await asyncio.wait_for(
                    asyncio.gather(*list(_active_tasks), return_exceptions=True),
                    timeout=5,
                )
        except (asyncio.TimeoutError, Exception):  # noqa: BLE001
            pass
        _active_tasks.clear()
    # 8. Close DB.
    # RELI-J-003: bound with a timeout so a hung DB close cannot block
    # shutdown.
    # v97.94 FIX BUG-P13-1 (SOURCE-PROVEN ordering defect):
    # TaskSupervisor.cancel_all() previously ran AFTER close_db(), so any
    # task registered with TaskSupervisor that touches the DB would hit a
    # "DB closed" error during cancellation. Correct order: cancel ALL
    # supervised tasks FIRST, then close the DB. (Currently latent —
    # TaskSupervisor has zero register() call sites — but the ordering
    # defect is real and would manifest once TaskSupervisor is wired.)
    try:
        await TaskSupervisor.cancel_all(timeout=5)
    except Exception:  # noqa: BLE001
        pass
    try:
        await asyncio.wait_for(close_db(), timeout=10)
    except asyncio.TimeoutError:
        logger.warning("close_db timed out after 10s — proceeding.")
    except Exception as exc:  # noqa: BLE001
        logger.debug("DB close error: %s", exc)
    # RELI-J-006: reset the idempotency guard so a subsequent startup
    # (e.g. in tests or a reload) re-initializes subsystems cleanly.
    _post_init_done = False
    # v97.60 §15: FINAL TASK VERIFICATION — enumerate all remaining asyncio
    # tasks + classify each as EXPECTED_LONG_LIVED / SHUTTING_DOWN / ORPHANED /
    # LEAKED / FAILED. This is the authoritative shutdown verification per
    # the master prompt: "After shutdown, there must be ZERO unexpected
    # application-owned tasks remaining."
    try:
        _final_task_audit()
    except Exception as exc:  # noqa: BLE001
        logger.warning("SHUTDOWN: final task audit failed (non-fatal): %s", exc)
    logger.info("Bot stopped cleanly.")


def _final_task_audit() -> None:
    """v97.60 §15: enumerate remaining tasks + classify each.

    Classification:
      EXPECTED_LONG_LIVED — Telethon/asyncio internals that survive shutdown
        (e.g. the asyncio selector thread). These are NOT application-owned.
      SHUTTING_DOWN — tasks we explicitly cancelled above; they may still be
        in the process of terminating (cancelling=1). Acceptable if bounded.
      ORPHANED — application-owned tasks that didn't terminate. These indicate
        a leak or a worker that ignored CancelledError.
      LEAKED — tasks created by fire-and-forget create_task without supervision.
      FAILED — tasks that raised an unhandled exception.

    This function logs the classification + warns about any ORPHANED/LEAKED
    tasks. It does NOT raise — shutdown is best-effort.
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        return  # no loop — nothing to audit
    all_tasks = asyncio.all_tasks(loop)
    if not all_tasks:
        logger.info("SHUTDOWN_FINAL_AUDIT: no remaining tasks — clean shutdown")
        return
    # Classify each task by name.
    expected_keywords = (
        "asyncio_selector", "asyncio.selector", "BaseEventLoop",
        "self-poll", "Telethon", "_recv_loop", "_send_loop",
        "_update_loop", "_keepalive_loop", "mtprotosender",
    )
    shutting_down_keywords = (
        "vc_callback_", "vc_dashboard_auto_refresh_", "vc_join_all_auto_refresh_",
        "vc_join_all_worker", "vc_reconcile", "vc_op_scheduler",
        "vc_watcher", "vc_discovery", "vc_talkative",
        "dashboard_snapshot", "bot_heartbeat", "bot_history",
        "_scheduled_loop", "periodic_cleanup", "runtime_debug",
        "event_loop_lag", "task_dump",
    )
    orphaned = []
    leaked = []
    failed = []
    expected = 0
    shutting_down = 0
    for task in all_tasks:
        name = task.get_name() if hasattr(task, "get_name") else str(task)
        # Check if the task is done (terminated).
        if task.done():
            # Check if it failed.
            if not task.cancelled():
                try:
                    exc = task.exception()
                    if exc is not None:
                        failed.append((name, f"{type(exc).__name__}: {exc}"[:80]))
                except asyncio.InvalidStateError:
                    pass
            continue
        # Task is still alive — classify.
        name_lower = name.lower()
        if any(kw.lower() in name_lower for kw in expected_keywords):
            expected += 1
        elif any(kw.lower() in name_lower for kw in shutting_down_keywords):
            shutting_down += 1
            # These should have been cancelled above — log them.
            orphaned.append((name, "shutting_down_still_alive"))
        else:
            leaked.append((name, "unknown_leaked_task"))
    total = len(all_tasks)
    alive = sum(1 for t in all_tasks if not t.done())
    logger.info(
        "SHUTDOWN_FINAL_AUDIT: total=%d alive=%d expected_long_lived=%d "
        "shutting_down=%d orphaned=%d leaked=%d failed=%d",
        total, alive, expected, shutting_down,
        len(orphaned), len(leaked), len(failed),
    )
    if orphaned:
        logger.warning(
            "SHUTDOWN_ORPHANED_TASKS count=%d — these workers did not terminate "
            "during shutdown (may be stuck in CancelledError): %s",
            len(orphaned), [t[0] for t in orphaned[:10]],
        )
    if leaked:
        logger.warning(
            "SHUTDOWN_LEAKED_TASKS count=%d — these are unknown tasks that may "
            "indicate a fire-and-forget create_task without supervision: %s",
            len(leaked), [t[0] for t in leaked[:10]],
        )
    if failed:
        logger.warning(
            "SHUTDOWN_FAILED_TASKS count=%d — these tasks raised unhandled "
            "exceptions: %s",
            len(failed), [(t[0], t[1]) for t in failed[:5]],
        )


def build_application() -> Application:
    if not config.bot_token:
        logger.error("TG_BOT_TOKEN is not set. Copy .env.example to .env and fill it in.")
        sys.exit(1)

    builder = (
        ApplicationBuilder()
        .token(config.bot_token)
        .concurrent_updates(True)
        .post_init(_post_init)
        .post_stop(_post_stop)
        # V90 FIX: use 60s read/write timeouts for Bot API control messages
        # (callbacks, /start, dashboard edits). The previous 3600s (1 hour)
        # timeout meant a rate-limited edit_message_text could block the
        # handler for up to 1 hour, consuming a concurrent_updates semaphore
        # slot and eventually starving the dispatcher.
        # The download_timeout (3600s) is still used by the download handler
        # which sets its own timeout per request.
        .read_timeout(60)
        .write_timeout(60)
        .connect_timeout(30)
        .pool_timeout(30)
    )
    if config.local_mode:
        builder = builder.base_url(config.bot_api_base_url)
        builder = builder.base_file_url(config.bot_api_file_url)
        builder = builder.local_mode(True)
        logger.info("Local Bot API server mode ENABLED: %s", config.bot_api_base_url)
    elif config.local_bot_api_enabled:
        # v97.21: Local Bot API Server integration.
        # Uses the Local Bot API for delivery (removes 20MB ceiling, allows
        # local file paths).  Telethon MTProto download pipeline is NOT
        # affected — it remains the primary method for protected media.
        builder = builder.base_url(config.local_bot_api_url + "/bot")
        builder = builder.base_file_url(config.local_bot_api_url + "/file/bot")
        builder = builder.local_mode(True)
        logger.info("LOCAL_BOT_API_ENABLED url=%s — delivery via Local Bot API",
                    config.local_bot_api_url)
    app = builder.build()

    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("help", help_command))

    # Fix 8: register slash commands for major features so they work as
    # /vc, /status, /admin, /download, /analyze, /library, /toolbox, /qr,
    # /stats, /history, /settings, /schedule, /backup, /mtproto, /talkative.
    # These all open the corresponding menu (same as the inline button).
    async def _cmd_vc(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if _vc_is_admin(update.effective_user.id):
            await vc_handler.show_menu(update, context)
        else:
            await safe_reply_text(update.message, "🚫 Not authorised.")

    async def _cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """P2 fix: enforce admin authorization at the entry point."""
        if not update.effective_user or update.effective_user.id not in config.admin_ids:
            await safe_reply_text(update.message, "🚫 Not authorised.")
            return
        await admin_handler.show_menu(update, context)

    async def _cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Show VC status via slash command (admin-only)."""
        if not _vc_is_admin(update.effective_user.id):
            await safe_reply_text(update.message, "🚫 Not authorised.")
            return
        s = await vc_get_status()
        text = _vc_status_text(s)
        await safe_send_message(
            context.bot, update.effective_chat.id, text,
            reply_markup=vc_menu(),
        )

    async def _cmd_dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Open the live VC dashboard via slash command (admin-only)."""
        if not _vc_is_admin(update.effective_user.id):
            await safe_reply_text(update.message, "🚫 Not authorised.")
            return
        text = await vc_dashboard_text()
        msg = await safe_send_message(
            context.bot, update.effective_chat.id,
            text, reply_markup=vc_dashboard_menu(),
        )
        if msg is not None:
            _vc_dashboard_auto_refresh_start(
                update.effective_chat.id, msg.message_id,
                admin_id=update.effective_user.id,
            )

    async def _cmd_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Generic menu opener for feature commands."""
        cmd = update.message.text.split()[0].lstrip("/").lower() if update.message.text else ""
        menu_map = {
            "download": (msg.DOWNLOAD_MENU_TEXT, kb.download_menu),
            "dl": (msg.DOWNLOAD_MENU_TEXT, kb.download_menu),
            "analyze": (msg.ANALYZE_MENU_TEXT, kb.analyze_menu),
            "ai": (msg.ANALYZE_MENU_TEXT, kb.analyze_menu),
            "library": (msg.LIBRARY_MENU_TEXT, kb.library_menu),
            "lib": (msg.LIBRARY_MENU_TEXT, kb.library_menu),
            "toolbox": (msg.TOOLBOX_MENU_TEXT, kb.toolbox_menu),
            "tb": (msg.TOOLBOX_MENU_TEXT, kb.toolbox_menu),
            "qr": (msg.QR_MENU_TEXT, kb.qr_menu),
            "stats": (msg.STATS_MENU_TEXT, kb.stats_menu),
            "history": (msg.HISTORY_MENU_TEXT, kb.history_menu),
            "settings": (msg.SETTINGS_MENU_TEXT, kb.settings_menu),
            "schedule": (msg.SCHEDULED_MENU_TEXT, kb.scheduled_menu),
            "backup": (msg.BACKUP_MENU_TEXT, kb.backup_menu),
            "mtproto": (None, None),  # handled separately
            "talkative": (None, None),  # handled separately
        }
        if cmd in ("mtproto",):
            await mtproto_handler.show_menu(update, context)
            return
        if cmd in ("talkative", "talk"):
            await talkative_handler.show_menu(update, context)
            return
        entry = menu_map.get(cmd)
        if entry and entry[1]:
            await states.reset(update.effective_user.id)
            await safe_send_message(
                context.bot, update.effective_chat.id,
                entry[0], reply_markup=entry[1](),
            )
            return
        await start_command(update, context)

    app.add_handler(CommandHandler("vc", _cmd_vc))
    app.add_handler(CommandHandler("status", _cmd_status))
    app.add_handler(CommandHandler("dashboard", _cmd_dashboard))
    app.add_handler(CommandHandler("admin", _cmd_admin))
    app.add_handler(CommandHandler("download", _cmd_menu))
    app.add_handler(CommandHandler("dl", _cmd_menu))
    app.add_handler(CommandHandler("analyze", _cmd_menu))
    app.add_handler(CommandHandler("ai", _cmd_menu))
    app.add_handler(CommandHandler("library", _cmd_menu))
    app.add_handler(CommandHandler("lib", _cmd_menu))
    app.add_handler(CommandHandler("toolbox", _cmd_menu))
    app.add_handler(CommandHandler("tb", _cmd_menu))
    app.add_handler(CommandHandler("qr", _cmd_menu))
    app.add_handler(CommandHandler("stats", _cmd_menu))
    app.add_handler(CommandHandler("history", _cmd_menu))
    app.add_handler(CommandHandler("settings", _cmd_menu))
    app.add_handler(CommandHandler("schedule", _cmd_menu))
    app.add_handler(CommandHandler("backup", _cmd_menu))
    app.add_handler(CommandHandler("mtproto", _cmd_menu))
    app.add_handler(CommandHandler("talkative", _cmd_menu))

    # VC control slash commands — reuse exact existing control functions.
    # All require admin authorization. Work in private chats, groups,
    # and supergroups. Support /cmd and /cmd@BotUsername forms (PTB handles
    # the @BotUsername suffix automatically via CommandHandler).
    async def _vc_auth_check(update: Update) -> bool:
        """Common admin check for VC commands. Returns True if authorised."""
        if not update.effective_user:
            await safe_reply_text(update.message, "🚫 Cannot identify user.")
            return False
        if not _vc_is_admin(update.effective_user.id):
            await safe_reply_text(update.message, "🚫 Not authorised. Admin only.")
            return False
        return True

    async def _cmd_vcstart(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        result = await vc_start_tour()
        replies = {
            "started": "▶️ VC Tour started.",
            "already_running": "ℹ️ Tour is already running.",
            "mtproto_not_started": "❌ MTProto not started.",
            "join_all_running_stop_first": "❌ Join-All is running. Stop it first.",
        }
        await safe_reply_text(update.message, replies.get(result, f"ℹ️ Tour: {result}"))

    async def _cmd_vcstop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        result = await vc_stop_tour()
        await safe_reply_text(update.message, f"⏹ VC Tour: {result}")

    async def _cmd_vcpause(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        result = await vc_pause_tour()
        await safe_reply_text(update.message, f"⏸ VC Tour: {result}")

    async def _cmd_vcresume(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        result = await vc_resume_tour()
        await safe_reply_text(update.message, f"▶️ VC Tour: {result}")

    async def _cmd_vcskip(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        result = await vc_skip_current()
        await safe_reply_text(update.message, f"⏭ VC Tour skip: {result}")

    async def _cmd_vcjoin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        logger.info("COMMAND_RECEIVED path=botapi cmd=join sender=%s chat=%s",
                    update.effective_user.id if update.effective_user else 0,
                    update.effective_chat.id if update.effective_chat else 0)
        if not await _vc_auth_check(update): return
        args = context.args
        _cid = update.effective_chat.id if update.effective_chat else 0
        _sid = update.effective_user.id if update.effective_user else 0
        _botapi_msg_id = int(getattr(update.message, "message_id", 0) or 0)
        # P1 #17: /join sent in a group without an argument automatically
        # targets the source group.  /join in a DM requires an explicit target.
        _is_group = (update.effective_chat is not None
                     and update.effective_chat.type in ("group", "supergroup"))
        if not args:
            if _is_group:
                # Use the source group as the target.
                args = [str(_cid)]
            else:
                await safe_reply_text(update.message, "Usage: /join <group_id|@username|link>")
                return
        if await _vc_dedup_check("join", _cid, _sid,
                                 args=args, message_id=_botapi_msg_id):
            logger.info("COMMAND_DUPLICATE_SUPPRESSED path=botapi cmd=join sender=%s chat=%s", _sid, _cid)
            return
        logger.info("COMMAND_EXECUTION_START path=botapi cmd=join sender=%s", _sid)
        # P1 #9: use the shared _vc_execute_manual_join executor.
        _source_chat_id = _cid
        async def _botapi_dm_fn(text: str) -> bool:
            return await _vc_dm_with_fallback(None, _sid, text,
                                              source_chat_id=_source_chat_id)
        # v98.12 §26 (USER-FACING JOIN UX): ONE editable status message in
        # the SOURCE chat (python-telegram-bot Message.edit_text) renders
        # the join lifecycle (🔎 → 🎙️ → ⚡ → ✅/⚠️) — immediate feedback, no
        # message spam; DM routing remains the fallback for DM-context
        # commands and edit failures.
        _v9812_bot_status_msg = None

        async def _botapi_status_fn(text: str, *, final: bool = False) -> bool:
            nonlocal _v9812_bot_status_msg
            try:
                _eff_chat = update.effective_chat
                if _eff_chat is None:
                    return False
                if _v9812_bot_status_msg is None:
                    _v9812_bot_status_msg = await _eff_chat.send_message(text)
                    return True
                try:
                    await _v9812_bot_status_msg.edit_text(text)
                    return True
                except Exception:  # noqa: BLE001
                    _v9812_bot_status_msg = await _eff_chat.send_message(text)
                    return True
            except Exception:  # noqa: BLE001
                return False  # executor falls back to the DM path

        _v9812_use_status = _is_group and update.effective_chat is not None
        # P1 #17: in group context, pass the source group ID as the target
        # (resolved via MTProto get_entity).  In DM context, pass the arg.
        _target_ref = _cid if _is_group else args[0]
        res = await _vc_execute_manual_join(
            target_ref=_target_ref,
            sender_id=_sid,
            source_chat_id=_source_chat_id,
            dm_send_fn=_botapi_dm_fn,
            is_group_context=_is_group,
            status_fn=(_botapi_status_fn if _v9812_use_status else None),
        )
        # P1 #11: separate execution outcome from DM delivery outcome.
        exec_ok = res.get("ok", False)
        dm_ok = res.get("dm_ok", False)
        if exec_ok and dm_ok:
            logger.info("COMMAND_EXECUTION_SUCCESS path=botapi cmd=join exec=ok dm=ok")
        elif exec_ok and not dm_ok:
            logger.warning("COMMAND_EXECUTION_SUCCESS path=botapi cmd=join exec=ok dm=FAILED")
        elif not exec_ok and dm_ok:
            logger.info("COMMAND_EXECUTION_FAILURE path=botapi cmd=join exec=failed dm=ok error=%s", res.get("error",""))
        else:
            logger.warning("COMMAND_EXECUTION_FAILURE path=botapi cmd=join exec=failed dm=FAILED error=%s", res.get("error",""))

    async def _cmd_vcleave(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        logger.info("COMMAND_RECEIVED path=botapi cmd=leave sender=%s chat=%s",
                    update.effective_user.id if update.effective_user else 0,
                    update.effective_chat.id if update.effective_chat else 0)
        if not await _vc_auth_check(update): return
        _cid = update.effective_chat.id if update.effective_chat else 0
        _sid = update.effective_user.id if update.effective_user else 0
        _botapi_msg_id = int(getattr(update.message, "message_id", 0) or 0)
        if await _vc_dedup_check("leave", _cid, _sid,
                                 message_id=_botapi_msg_id):
            logger.info("COMMAND_DUPLICATE_SUPPRESSED path=botapi cmd=leave sender=%s chat=%s", _sid, _cid)
            return
        # P1 #8/#16: target-specific leave in Multi-VC mode + DM-route the
        # operational result.  If /leave is sent in a group, leave ONLY that
        # group's VC and DM the result (don't post operational output in the
        # source group).  If sent in a DM, fall back to vc_manual_leave().
        _is_group = (update.effective_chat is not None
                     and update.effective_chat.type in ("group", "supergroup"))
        async def _leave_dm_fn(text: str) -> bool:
            return await _vc_dm_with_fallback(None, _sid, text,
                                              source_chat_id=_cid)
        if _is_group:
            rec = await vc_registry_get(_cid)
            if rec is not None and rec.state in ("joined", "unknown", "joining"):
                outcome = await vc_leave_target(_cid)
                await _leave_dm_fn(f"🚪 Left VC in this group: {outcome}")
            else:
                await _leave_dm_fn("ℹ️ Not currently in a VC in this group.")
        else:
            result = await vc_manual_leave()
            await safe_reply_text(update.message, f"🚪 Manual leave: {result}")

    async def _cmd_joinall(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        result = await vc_join_all_active_start()
        replies = {
            "started": "🚀 Join-All started.",
            "already_running": "ℹ️ Join-All is already running.",
            "tour_running_stop_first": "❌ Tour is running. Stop it first.",
            "mtproto_not_started": "❌ MTProto not started.",
        }
        await safe_reply_text(update.message, replies.get(result, f"🚀 Join-All: {result}"))

    async def _cmd_joinallstop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        result = await vc_join_all_active_stop()
        await safe_reply_text(update.message, f"🛑 Join-All: {result}")

    async def _cmd_joinallresume(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """v97: resume the latest interrupted Join-All run from its checkpoint."""
        if not await _vc_auth_check(update): return
        result = await vc_join_all_resume()
        replies = {
            "started": "▶️ Join-All resumed from checkpoint.",
            "already_running": "ℹ️ Join-All is already running.",
            "tour_running_stop_first": "❌ Tour is running. Stop it first.",
            "mtproto_not_started": "❌ MTProto not started.",
        }
        await safe_reply_text(update.message, replies.get(result, f"▶️ Join-All resume: {result}"))

    async def _cmd_watcher(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        logger.info("COMMAND_RECEIVED path=botapi cmd=watcher sender=%s chat=%s",
                    update.effective_user.id if update.effective_user else 0,
                    update.effective_chat.id if update.effective_chat else 0)
        if not await _vc_auth_check(update):
            logger.info("COMMAND_REJECTED path=botapi cmd=watcher sender=%s reason=not_authorized",
                        update.effective_user.id if update.effective_user else 0)
            return
        logger.info("COMMAND_EXECUTION_START path=botapi cmd=watcher sender=%s",
                    update.effective_user.id)
        result = await vc_watcher_start()
        replies = {
            "started": "👁 VC Watcher started.",
            "already_running": "ℹ️ Watcher is already running.",
            "tour_running_stop_first": "❌ Tour is running. Stop it first.",
            "join_all_running_stop_first": "❌ Join-All is running. Stop it first.",
            "mtproto_not_started": "❌ MTProto not started.",
        }
        await safe_reply_text(update.message, replies.get(result, f"👁 Watcher: {result}"))
        logger.info("COMMAND_EXECUTION_SUCCESS path=botapi cmd=watcher result=%s", result)

    async def _cmd_watcherstop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        logger.info("COMMAND_RECEIVED path=botapi cmd=watcherstop sender=%s",
                    update.effective_user.id if update.effective_user else 0)
        if not await _vc_auth_check(update): return
        result = await vc_watcher_stop()
        await safe_reply_text(update.message, f"⏹ Watcher: {result}")
        logger.info("COMMAND_EXECUTION_SUCCESS path=botapi cmd=watcherstop result=%s", result)

    async def _cmd_scan(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        if not _vc_mtproto_ok():
            await safe_reply_text(update.message, "❌ MTProto not started.")
            return
        await safe_reply_text(update.message, "🔄 Scanning groups…")
        disc = await vc_discover_groups()
        queue = await vc_build_active_queue()
        await safe_send_message(
            context.bot, update.effective_chat.id,
            f"🔄 Scan complete.\nDiscovery: {disc.get('discovered',0)} found "
            f"({disc.get('newly_discovered',0)} new), {disc.get('errors',0)} errors.\n"
            f"Active VCs: {len(queue)}\n"
            f"Scan counts: {_vc_scan_counts}",
        )

    async def _cmd_rebuild(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        if not _vc_mtproto_ok():
            await safe_reply_text(update.message, "❌ MTProto not started.")
            return
        await safe_reply_text(update.message, "🧱 Rebuilding queue…")
        await vc_discover_groups()
        queue = await vc_build_active_queue()
        await safe_send_message(
            context.bot, update.effective_chat.id,
            f"🧱 Queue rebuilt: {len(queue)} items.\n{_vc_scan_counts}",
        )

    async def _cmd_vcstatus(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        s = await vc_get_status()
        text = _vc_status_text(s)
        await safe_send_message(
            context.bot, update.effective_chat.id, text,
            reply_markup=vc_menu(),
        )

    async def _cmd_discover(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        if not _vc_mtproto_ok():
            await safe_reply_text(update.message, "❌ MTProto not started.")
            return
        args = context.args or []
        run_now = bool(args) and args[0].lower() == "now"
        if run_now:
            await safe_reply_text(update.message, "🔍 Running one discovery cycle now…")
            res = await vc_discovery_run_cycle()
            await safe_send_message(
                context.bot, update.effective_chat.id,
                f"🔍 *Discovery cycle complete*\n"
                f"Queries: `{res.get('queries_run',0)}` · "
                f"Found: `{res.get('results_found',0)}`\n"
                f"New: `{res.get('new_groups',0)}` · "
                f"Refreshed: `{res.get('refreshed_groups',0)}`\n"
                f"Active VCs: `{res.get('active_vcs_found',0)}`\n"
                f"Joined: `{res.get('auto_joins_confirmed',0)}` · "
                f"Deferred: `{res.get('deferred_targets',0)}`\n"
                f"FloodWaits: `{res.get('floodwait_count',0)}` · "
                f"Errors: `{res.get('errors',0)}`\n"
                f"Complete: `{res.get('complete',False)}` · "
                f"Cancelled: `{res.get('cancelled',False)}`",
            )
            return
        result = await vc_discovery_start()
        replies = {
            "started": "🔍 Discovery loop started.",
            "already_running": "ℹ️ Discovery is already running.",
            "disabled": "❌ Discovery disabled. Set VC_DISCOVERY_ENABLED=true.",
            "mtproto_not_started": "❌ MTProto not started.",
            "tour_running_stop_first": "❌ VC Tour is running. Stop it first.",
            "join_all_running_stop_first": "❌ Join-All is running. Stop it first.",
        }
        await safe_reply_text(update.message, replies.get(result, f"ℹ️ Discovery: {result}"))

    async def _cmd_discoverstop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        result = await vc_discovery_stop()
        replies = {
            "stopped": "⏹ Discovery loop stopped.",
            "not_running": "ℹ️ Discovery was not running.",
        }
        await safe_reply_text(update.message, replies.get(result, f"ℹ️ Discovery: {result}"))

    async def _cmd_discoverstatus(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        st = vc_discovery_get_state()
        m = vc_discovery_get_metrics()
        runs = await vc_discovery_get_recent_runs(limit=5)
        runs_txt = ""
        if runs:
            lines = []
            for r in runs:
                lines.append(
                    f"  • {str(r.get('started_at','—'))[:19]}: "
                    f"q={r.get('queries_run',0)} new={r.get('new_groups',0)} "
                    f"active={r.get('active_vcs_found',0)} "
                    f"joined={r.get('auto_joins_confirmed',0)}"
                )
            runs_txt = "\n*Recent runs*\n" + "\n".join(lines)
        txt = (
            f"🔍 *Discovery Status*\n"
            f"Running: {('✅' if st.get('running') else '⏹')} · "
            f"Phase: `{st.get('current_phase','idle')}`\n"
            f"Enabled: {('✅' if st.get('enabled') else '⏹')} · "
            f"Cycle: `{st.get('cycle_count',0)}`\n"
            f"Last: `{st.get('last_complete_at','—')}`\n"
            f"Next: `{st.get('next_cycle_at','—')}`\n"
            f"Current: `{(st.get('current_query') or '—')[:50]}`\n\n"
            f"*This cycle*\n"
            f"Queries: `{st.get('queries_run_this_cycle',0)}` · "
            f"Found: `{st.get('results_found_this_cycle',0)}`\n"
            f"New: `{st.get('new_groups_this_cycle',0)}` · "
            f"Refreshed: `{st.get('refreshed_groups_this_cycle',0)}`\n"
            f"Active VCs: `{st.get('active_vcs_found_this_cycle',0)}`\n"
            f"Joined: `{st.get('auto_joins_confirmed',0)}` · "
            f"Failed: `{st.get('auto_joins_failed',0)}` · "
            f"Deferred: `{st.get('deferred_targets',0)}`\n"
            f"FloodWaits: `{st.get('floodwait_count_this_cycle',0)}` · "
            f"Errors: `{st.get('errors_this_cycle',0)}`\n\n"
            f"*Cumulative*\n"
            f"Cycles: `{m.get('total_cycles',0)}` "
            f"(✅{m.get('cycles_complete',0)} "
            f"⏹{m.get('cycles_cancelled',0)} "
            f"⚠{m.get('cycles_floodwait_interrupted',0)})\n"
            f"Queries run: `{m.get('total_queries_run',0)}`\n"
            f"New groups: `{m.get('total_new_groups',0)}`\n"
            f"Active VCs: `{m.get('total_active_vcs_found',0)}`\n"
            f"Joined: `{m.get('total_auto_joins_confirmed',0)}`\n"
            f"Deferred: `{m.get('total_deferred',0)}`\n"
            f"Dead marked: `{m.get('total_dead_marked',0)}`\n"
            f"FloodWaits: `{m.get('total_floodwaits',0)}`\n"
            f"Errors: `{m.get('total_errors',0)}`\n"
            f"Last error: `{(st.get('last_error') or '—')[:100]}`"
            f"{runs_txt}"
        )
        await safe_send_message(context.bot, update.effective_chat.id, txt)

    async def _cmd_discoverreset(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        vc_discovery_reset_metrics()
        await safe_reply_text(update.message, "🔄 Discovery metrics reset.")

    async def _cmd_discoverquery(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Feature B #43: /discoverquery add|remove|list|enable|disable|clear|search <term>.

        Admin-only.  Manages persistent discovery queries without restart (#41).
        """
        if not await _vc_auth_check(update): return
        args = context.args or []
        if not args:
            await safe_reply_text(update.message,
                "Usage:\n"
                "/discoverquery add <term>\n"
                "/discoverquery remove <term>\n"
                "/discoverquery list\n"
                "/discoverquery enable <term>\n"
                "/discoverquery disable <term>\n"
                "/discoverquery clear\n"
                "/discoverquery search <term>")
            return
        sub = args[0].lower()
        if sub == "add":
            if len(args) < 2:
                await safe_reply_text(update.message, "Usage: /discoverquery add <term>")
                return
            term = " ".join(args[1:])
            res = await vc_discovery_add_query(term, source="dashboard_manual")
            if res.get("ok"):
                await safe_reply_text(update.message, f"✅ Query added: {term[:60]}")
            else:
                await safe_reply_text(update.message, f"❌ {res.get('error','unknown')}")
        elif sub == "remove":
            if len(args) < 2:
                await safe_reply_text(update.message, "Usage: /discoverquery remove <term>")
                return
            term = " ".join(args[1:])
            res = await vc_discovery_remove_query(term)
            if res.get("ok"):
                await safe_reply_text(update.message, f"✅ Query removed: {term[:60]}")
            else:
                await safe_reply_text(update.message, f"❌ {res.get('error','unknown')}")
        elif sub == "list":
            queries = await vc_discovery_list_queries()
            builtin = _vc_discovery_builtin_defaults()
            lines = [f"📋 *Discovery Queries* ({len(queries)} manual)\n"]
            for q in queries[:20]:
                en = "✅" if q.get("enabled") else "⏹"
                lines.append(f"  {en} `{str(q.get('query',''))[:40]}` prio={q.get('priority',0)}")
            lines.append(f"\nBuilt-in defaults ({len(builtin)}): {', '.join(builtin[:8])}")
            await safe_send_message(context.bot, update.effective_chat.id, "\n".join(lines))
        elif sub == "enable":
            if len(args) < 2:
                await safe_reply_text(update.message, "Usage: /discoverquery enable <term>")
                return
            term = " ".join(args[1:])
            res = await vc_discovery_enable_query(term, True)
            await safe_reply_text(update.message,
                f"✅ Enabled: {term[:60]}" if res.get("ok") else f"❌ {res.get('error','unknown')}")
        elif sub == "disable":
            if len(args) < 2:
                await safe_reply_text(update.message, "Usage: /discoverquery disable <term>")
                return
            term = " ".join(args[1:])
            res = await vc_discovery_enable_query(term, False)
            await safe_reply_text(update.message,
                f"⏹ Disabled: {term[:60]}" if res.get("ok") else f"❌ {res.get('error','unknown')}")
        elif sub == "clear":
            res = await vc_discovery_clear_queries()
            await safe_reply_text(update.message,
                f"🗑 Cleared {res.get('removed',0)} manual queries.")
        elif sub == "search":
            if len(args) < 2:
                await safe_reply_text(update.message, "Usage: /discoverquery search <term>")
                return
            term = " ".join(args[1:])
            await safe_reply_text(update.message, f"🔎 Searching for: {term[:60]}…")
            res = await vc_discovery_search_query_now(term)
            await safe_send_message(context.bot, update.effective_chat.id,
                f"🔎 *Search complete*\n"
                f"Query: `{res.get('query','')[:40]}`\n"
                f"Found: `{res.get('found',0)}` · Unique: `{res.get('unique',0)}`\n"
                f"New: `{res.get('new',0)}` · Active VCs: `{res.get('active_vcs',0)}`\n"
                f"Joined: `{res.get('joined',0)}`")
        else:
            await safe_reply_text(update.message,
                f"Unknown subcommand: {sub}. Use add|remove|list|enable|disable|clear|search.")

    async def _cmd_discovermode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Feature B #77: /discovermode fallback|mixed|custom_only."""
        if not await _vc_auth_check(update): return
        args = context.args or []
        if not args:
            await safe_reply_text(update.message,
                f"Current mode: `{_vc_discovery_current_mode()}`\n"
                f"Usage: /discovermode fallback|mixed|custom_only")
            return
        new_mode = args[0].lower().strip()
        if new_mode not in ("fallback", "mixed", "custom_only"):
            await safe_reply_text(update.message,
                f"❌ Invalid mode. Use: fallback, mixed, or custom_only.")
            return
        try:
            object.__setattr__(config, "vc_discovery_mode", new_mode)
        except Exception:  # noqa: BLE001
            pass
        logger.info("VC_DISCOVERY_MODE_CHANGED mode=%s (via command)", new_mode)
        await safe_reply_text(update.message, f"🔀 Discovery mode set to: {new_mode}")

    async def _cmd_vchelp(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _vc_auth_check(update): return
        help_text = (
            "*VC Commands*\n\n"
            "/vcstart — Start VC Tour\n"
            "/vcstop — Stop VC Tour\n"
            "/vcpause — Pause VC Tour\n"
            "/vcresume — Resume VC Tour\n"
            "/vcskip — Skip current VC\n"
            "/join <target> — Manual join a VC\n"
            "/vcleave — Leave current VC\n"
            "/joinall — Join all active VCs\n"
            "/joinallstop — Stop Join-All\n"
            "/watcher — Start VC Watcher\n"
            "/watcherstop — Stop VC Watcher\n"
            "/discover [now] — Start broad group discovery (or run one cycle)\n"
            "/discoverstop — Stop group discovery\n"
            "/discoverstatus — Show discovery state + metrics\n"
            "/discoverreset — Reset discovery metrics\n"
            "/discoverquery add|remove|list|enable|disable|clear|search <term>\n"
            "/discovermode fallback|mixed|custom_only\n"
            "/scan — Refresh groups + scan active VCs\n"
            "/rebuild — Rebuild VC queue\n"
            "/vcstatus — Show VC status\n"
            "/dashboard — Open live VC dashboard\n"
            "/vc — Open VC menu\n"
        )
        await safe_send_message(context.bot, update.effective_chat.id, help_text)

    # Register all VC commands.
    app.add_handler(CommandHandler("vcstart", _cmd_vcstart))
    app.add_handler(CommandHandler("vcstop", _cmd_vcstop))
    app.add_handler(CommandHandler("vcpause", _cmd_vcpause))
    app.add_handler(CommandHandler("vcresume", _cmd_vcresume))
    app.add_handler(CommandHandler("vcskip", _cmd_vcskip))
    app.add_handler(CommandHandler("join", _cmd_vcjoin))
    app.add_handler(CommandHandler("vcjoin", _cmd_vcjoin))
    app.add_handler(CommandHandler("vcleave", _cmd_vcleave))
    app.add_handler(CommandHandler("leave", _cmd_vcleave))
    app.add_handler(CommandHandler("joinall", _cmd_joinall))
    app.add_handler(CommandHandler("joinallstop", _cmd_joinallstop))
    app.add_handler(CommandHandler("joinallresume", _cmd_joinallresume))
    app.add_handler(CommandHandler("watcher", _cmd_watcher))
    app.add_handler(CommandHandler("watcherstop", _cmd_watcherstop))
    app.add_handler(CommandHandler("scan", _cmd_scan))
    app.add_handler(CommandHandler("rebuild", _cmd_rebuild))
    app.add_handler(CommandHandler("vcstatus", _cmd_vcstatus))
    app.add_handler(CommandHandler("discover", _cmd_discover))
    app.add_handler(CommandHandler("discoverstop", _cmd_discoverstop))
    app.add_handler(CommandHandler("discoverstatus", _cmd_discoverstatus))
    app.add_handler(CommandHandler("discoverreset", _cmd_discoverreset))
    app.add_handler(CommandHandler("discoverquery", _cmd_discoverquery))
    app.add_handler(CommandHandler("discovermode", _cmd_discovermode))
    app.add_handler(CommandHandler("vchelp", _cmd_vchelp))

    if config.inline_enabled:
        app.add_handler(InlineQueryHandler(inline_handler.handle_inline))

    app.add_handler(CallbackQueryHandler(route_callback))

    # V60 Fix #1: register the high-priority Bot API voice enrollment
    # handler in group=-1. This runs BEFORE the default-group
    # route_message handler and the group=10 Talkative wrapper. It
    # consumes voice/audio messages ONLY when a pending enrollment state
    # matches (admin_user_id, bot_chat_id); otherwise the update falls
    # through to normal processing.
    _app_voice_enroll_register(app)

    # V86 upgrade — multimodal MessageHandler (group=-1, highest priority).
    # Captures voice/photo/video/audio/document/sticker/gif/animation messages
    # and routes them through the unified multimodal pipeline. The handler
    # raises ApplicationHandlerStop ONLY after it has FULLY processed a media
    # message (transcribed, analyzed, or reacted) and sent a reply — this
    # prevents the group-0 download/analyze handlers from re-processing the
    # same media (DOUBLE-PROCESSING fix, P8 Task 2). Pure-text messages,
    # errors, voice-enrollment-active chats, and early-return paths do NOT
    # raise ApplicationHandlerStop, so they fall through to route_message
    # (download/analyze) and the group=10 Talkative wrapper.
    #
    # Registration order within group=-1: voice_enroll FIRST, then multimodal.
    # The voice_enroll handler returns early when no enrollment is pending, so
    # it never blocks multimodal for normal media; when an enrollment IS
    # pending, voice_enroll claims the sample and raises ApplicationHandlerStop
    # before multimodal ever sees it. The multimodal handler ALSO has a
    # defence-in-depth `_voice_enroll_active` check so it can be reordered
    # safely in the future.
    if getattr(config, "multimodal_enabled", True):
        register_multimodal_handler(app)

    app.add_handler(MessageHandler(
        filters.ALL & ~filters.COMMAND, route_message
    ))

    # Task ID 16 — Talkative Mode handler, registered LAST in a separate
    # group (group=10) so EVERY existing handler (route_message in the
    # default group 0) gets first crack at the update. Talkative only fires
    # when no other handler has consumed the update.
    #
    # Filter: TEXT only, no COMMANDS (the existing route_message handles
    # everything else). The handler itself re-checks the priority workflow
    # guard + trigger detection + cooldown + RPM, so even if it does fire
    # it can still bail out gracefully.
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        _talkative_handle_message_wrapper,
    ), group=10)

    # Global error handler — catches any unhandled exception so a single bad
    # update never crashes the bot.
    app.add_error_handler(_on_error)

    # V85 §6: register the /v85status command (admin-only) so the runtime
    # state can be inspected live from Telegram.
    try:
        app.add_handler(CommandHandler("v85status", v85_status_command))
        app.add_handler(CommandHandler("v85refresh", _v85_refresh_command))
        v85_diag("BUTTON_CHECK", target="build_application",
                 handlers="v85status,v85refresh")
    except Exception as exc:  # noqa: BLE001
        logger.warning("V85 /v85status registration failed (non-fatal): %s", exc)

    # v99.03 RC-8/RC-10: the deployment-health and account-health admin
    # commands — the live operator surface for "is my deployment complete"
    # (/deploy_check) and "why do I see fewer accounts than .session files"
    # (/v85accounts).  Registered exactly like /v85status (group 0).  See
    # the block comment above the command bodies for the runtime evidence
    # (the 2026-09-11 v99.02 production log: every diagnostic fact existed
    # only in the log file — the operator's report "still facing issues +
    # two accounts but showing one" was the direct result).
    try:
        app.add_handler(CommandHandler(
            "deploy_check", v99_03_deploy_check_command), group=0)
        app.add_handler(CommandHandler(
            "deploycheck", v99_03_deploy_check_command), group=0)
        app.add_handler(CommandHandler(
            "v85accounts", v99_03_accounts_command), group=0)
        v85_diag("BUTTON_CHECK", target="build_application",
                 handlers="deploy_check,v85accounts")
    except Exception as exc:  # noqa: BLE001
        logger.warning("v99.03 /deploy_check + /v85accounts registration "
                       "failed (non-fatal): %s", exc)

    # V86 P8: register the /multimodal command (admin-only) so the multimodal
    # AI configuration can be inspected live from Telegram. Registered in the
    # default group (0) so it behaves like /v85status.
    try:
        app.add_handler(CommandHandler("multimodal", multimodal_status_command),
                        group=0)
        v85_diag("BUTTON_CHECK", target="build_application",
                 handlers="multimodal")
    except Exception as exc:  # noqa: BLE001
        logger.warning("V86 /multimodal registration failed (non-fatal): %s", exc)

    # V93 FIX: register the /taskdump command (admin-only) for stuck-task diagnosis.
    async def _taskdump_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_user.id not in config.admin_ids:
            return
        _dump_running_tasks(reason="admin_command")
        await update.message.reply_text(
            "📋 Task dump logged (reason=admin_command). "
            "Check the bot log for TASK_DUMP entries."
        )
    try:
        app.add_handler(CommandHandler("taskdump", _taskdump_command), group=0)
    except Exception as exc:  # noqa: BLE001
        logger.warning("V93 /taskdump registration failed (non-fatal): %s", exc)

    # V85 §6: validate that no duplicate callback routes were registered
    # during build_application. This is a one-time post-registration audit
    # that surfaces BUTTON_DUPLICATE_FOUND diagnostics.
    try:
        ButtonRegistry.validate_markup(None)  # no-op for None markup (early return); baseline emitted explicitly below
        v85_diag("BUTTON_REGISTRY_OK",
                 unique_callbacks=len(ButtonRegistry._seen_callbacks))
    except Exception as exc:  # noqa: BLE001
        v85_diag("BUTTON_CHECK_FAILED", exc=str(exc)[:120])

    return app


# V85 §5: /v85refresh command — triggers RefreshCoordinator.refresh_all()
async def _v85_refresh_command(update: Update,
                               context: ContextTypes.DEFAULT_TYPE) -> None:
    """Admin-only /v85refresh — runs RefreshCoordinator.refresh_all()."""
    if not update.effective_user or update.effective_user.id not in config.admin_ids:
        await safe_reply_text(update.message, "🚫 Not authorised.")
        return
    msg = await safe_reply_text(update.message, "🔄 Refreshing all subsystems…")
    # ERR-J-001: safe_reply_text can return None when the reply silently
    # fails (e.g. blocked chat, deleted message). Bail out early so we do
    # not call safe_edit_message_text on a None message reference.
    if msg is None:
        return
    try:
        report = await RefreshCoordinator.refresh_all()
        lines = ["✅ *V85 Refresh Complete*", f"• duration: `{report.get('duration_s', 0)}s`"]
        for k, v in report.get("steps", {}).items():
            if isinstance(v, dict) and "error" in v:
                lines.append(f"• `{k}`: ❌ {v['error']}")
            elif isinstance(v, dict):
                lines.append(f"• `{k}`: ✅ {list(v.keys())[:5]}")
            else:
                lines.append(f"• `{k}`: {v}")
        if msg is not None:
            await safe_edit_message_text(
                context.bot, msg.chat_id, msg.message_id,
                "\n".join(lines), parse_mode="Markdown",
            )
    except Exception as exc:  # noqa: BLE001
        if msg is not None:
            await safe_edit_message_text(
                context.bot, msg.chat_id, msg.message_id,
                f"❌ Refresh failed: `{str(exc)[:120]}`",
                parse_mode="Markdown",
            )



# ===========================================================================
# V85 PRODUCTION STABILITY, DISCOVERY, VC ENGINE, RUNTIME & UI CONSOLIDATION
# --------------------------------------------------------------------------
# This module is ADDITIVE: it introduces the centralized runtime controller,
# instance guard, button registry, client pool wrapper, provider manager
# facade, unified entity resolver + message-link resolver, refresh
# coordinator, and structured diagnostics emitters required by the V85
# patch brief. Every public function degrades gracefully — if any new
# subsystem fails, the original V80 code path is preserved.
# ===========================================================================

# ===========================================================================
# V85 §1 — Diagnostics emitter
# ===========================================================================

_V85_DIAG_BUFFER: list[tuple[float, str]] = []
_V85_DIAG_BUFFER_MAX = 500


def v85_diag(event: str, **fields: Any) -> None:
    """Emit a structured V85 diagnostic line and buffer it for /v85status.

    Format: ``V85_DIAG event=<name> key=value key=value ...``
    """
    try:
        parts = [f"event={event}"]
        for k, v in fields.items():
            try:
                sv = str(v)
            except Exception:
                sv = "<unrepr>"
            if len(sv) > 200:
                sv = sv[:200] + "..."
            parts.append(f"{k}={sv}")
        line = " ".join(parts)
        _V85_DIAG_BUFFER.append((time.time(), line))
        if len(_V85_DIAG_BUFFER) > _V85_DIAG_BUFFER_MAX:
            del _V85_DIAG_BUFFER[: len(_V85_DIAG_BUFFER) - _V85_DIAG_BUFFER_MAX]
        logger.info("V85_DIAG %s", line)
    except Exception:  # noqa: BLE001
        pass


# Register v85_diag via the diag_hooks DI bridge so that voicechat.py and
# other extracted subsystems can emit diagnostics without importing bootstrap.
from mediagrab_bot.diag_hooks import register_diag_hooks as _register_diag_hooks
_register_diag_hooks(v85_diag)


def v85_diag_snapshot() -> list[dict[str, Any]]:
    """Return the recent diagnostic buffer for /v85status."""
    out: list[dict[str, Any]] = []
    for ts, line in list(_V85_DIAG_BUFFER):
        out.append({"ts": ts, "line": line})
    return out


# ===========================================================================
# V85 §2 — InstanceGuard (Requirement 3)
# ===========================================================================

class InstanceGuard:
    """Prevents duplicate polling / scheduler / worker startup.

    The runtime logs show:
      ``telegram.error.Conflict: terminated by other getUpdates request;
       make sure that only one bot instance is running``

    Root cause: PTB's ``post_init`` can fire more than once on quick
    restart cycles, and the previous background workers had not yet
    released their ``getUpdates`` long-poll. ``InstanceGuard`` provides a
    single authoritative flag + lock that every V85 subsystem checks
    before starting.
    """

    _lock = asyncio.Lock()
    _active = False
    _pid: int | None = None
    _started_at: float = 0.0

    @classmethod
    async def acquire(cls) -> str:
        async with cls._lock:
            if cls._active:
                v85_diag(
                    "INSTANCE_ALREADY_RUNNING",
                    pid=cls._pid, started_at=cls._started_at,
                )
                return "INSTANCE_ALREADY_RUNNING"
            cls._active = True
            cls._pid = os.getpid()
            cls._started_at = time.time()
            v85_diag(
                "INSTANCE_OK",
                pid=cls._pid, started_at=int(cls._started_at),
            )
            return "INSTANCE_OK"

    @classmethod
    async def release(cls) -> None:
        async with cls._lock:
            cls._active = False
            cls._pid = None
            cls._started_at = 0.0

    @classmethod
    def is_active(cls) -> bool:
        return cls._active


# ===========================================================================
# V85 §3 — ButtonRegistry (Requirement 6)
# ===========================================================================

class ButtonRegistry:
    """Detects + deduplicates inline buttons and callback routes.

    PTB's ``ApplicationBuilder`` does not validate duplicate callback_data
    strings. A typo or refactor can produce two ``InlineKeyboardButton``
    instances pointing to the same route, or two ``CallbackQueryHandler``
    entries that both fire. This registry records every callback_data
    string at construction time and emits a diagnostic when a duplicate
    is detected.
    """

    _seen_callbacks: dict[str, int] = {}
    _duplicates: list[tuple[str, int]] = []

    @classmethod
    def register(cls, callback_data: str) -> bool:
        """Record a callback_data string. Returns True if it is new."""
        if not callback_data:
            return True
        try:
            count = cls._seen_callbacks.get(callback_data, 0) + 1
            cls._seen_callbacks[callback_data] = count
            if count > 1:
                cls._duplicates.append((callback_data, count))
                # RELI-J-010: cap the duplicates list so a long-running bot
                # does not accumulate unbounded memory if a misbehaving
                # callback keeps re-firing.
                if len(cls._duplicates) > 200:
                    del cls._duplicates[:len(cls._duplicates) - 200]
                v85_diag(
                    "BUTTON_DUPLICATE_FOUND",
                    callback_data=callback_data, count=count,
                )
                return False
            return True
        except Exception:  # noqa: BLE001
            return True

    @classmethod
    def validate_markup(cls, markup: InlineKeyboardMarkup | None) -> int:
        """Walk an InlineKeyboardMarkup and register every button.

        Returns the number of duplicate buttons removed (de-dup leaves
        the first occurrence intact).
        """
        if markup is None:
            return 0
        removed = 0
        try:
            for row in markup.inline_keyboard:
                seen_in_row: set[str] = set()
                for btn in list(row):
                    cd = getattr(btn, "callback_data", None)
                    if not cd:
                        continue
                    if cd in seen_in_row:
                        removed += 1
                        v85_diag(
                            "BUTTON_DUPLICATE_REMOVED",
                            callback_data=cd, scope="inline_row",
                        )
                        # We cannot mutate the row in-place safely; we
                        # leave it but log the duplicate. The handler
                        # route is what matters.
                    else:
                        seen_in_row.add(cd)
                        cls.register(cd)
            # OBS-J-003: do NOT emit BUTTON_REGISTRY_OK on every validate_markup
            # call — it is high-frequency noise. The baseline emission in
            # build_application remains; per-call OK is silent.
        except Exception as exc:  # noqa: BLE001
            v85_diag("BUTTON_CHECK_FAILED", exc=str(exc)[:120])
        return removed

    @classmethod
    def stats(cls) -> dict[str, Any]:
        return {
            "unique_callbacks": len(cls._seen_callbacks),
            "duplicates": list(cls._duplicates[-20:]),
            "total_seen": sum(cls._seen_callbacks.values()),
        }


# Hook the registry into _menu_edit and safe_send_message paths by
# wrapping _menu_edit. We monkey-patch at module level so existing callers
# transparently benefit.
try:
    _v85_orig_menu_edit = _menu_edit  # type: ignore[name-defined]

    async def _v85_menu_edit(update: Update, text: str,
                             markup: InlineKeyboardMarkup | None = None,
                             **kwargs: Any) -> Any:
        try:
            ButtonRegistry.validate_markup(markup)
        except Exception:  # noqa: BLE001
            pass
        return await _v85_orig_menu_edit(update, text, markup, **kwargs)

    # Replace in module namespace — late binding means callers pick this up.
    globals()["_menu_edit"] = _v85_menu_edit
    v85_diag("BUTTON_CHECK_INSTALLED", target="_menu_edit")
except Exception as exc:  # noqa: BLE001
    v85_diag("BUTTON_CHECK_INSTALL_FAILED", exc=str(exc)[:120])


# ===========================================================================
# V85 §4 — ClientPool (Requirement 13)
# ===========================================================================

class ClientPool:
    """Unified MTProto client lifecycle wrapper.

    Wraps the existing ``UserbotCluster`` so callers get a single API for
    acquire / reconnect / shutdown / health validation. Does NOT replace
    ``UserbotCluster`` — it delegates to it. This is the "one active
    MTProto client per account" facade required by V85 §13.
    """

    _health: dict[str, dict[str, Any]] = {}

    @classmethod
    def acquire(cls, account_id: str | None = None) -> Any | None:
        """Return a connected Telethon client for the given account.

        If ``account_id`` is None, returns the primary account's client.
        Returns ``None`` if no healthy client is available.
        """
        try:
            cluster = get_userbot_cluster()  # type: ignore[name-defined]
            # V85.4 FIX BUG CM-2: UserbotCluster has no get_primary_client()
            # method — use get_primary_id() + get_client() instead.
            if account_id:
                client = cluster.get_client(account_id)
            else:
                pid = cluster.get_primary_id()
                client = cluster.get_client(pid) if pid else None
            # V85.4 FIX BUG CM-1: getattr(client, "is_connected", False)
            # returned the BOUND METHOD (always truthy), not the result.
            # Telethon's is_connected is a sync method — call it.
            if client is not None:
                try:
                    is_conn = client.is_connected()
                except Exception:  # noqa: BLE001
                    is_conn = False
                if is_conn:
                    cls._health[str(account_id or "primary")] = {
                        "ok": True, "ts": time.time(),
                    }
                    return client
            cls._health[str(account_id or "primary")] = {
                "ok": False, "ts": time.time(), "reason": "not_connected",
            }
            return None
        except Exception as exc:  # noqa: BLE001
            cls._health[str(account_id or "primary")] = {
                "ok": False, "ts": time.time(), "reason": str(exc)[:120],
            }
            return None

    @classmethod
    async def reconnect(cls, account_id: str | None = None) -> bool:
        """V85.4 FIX BUG CM-3: UserbotCluster has no reconnect_account /
        reconnect_primary methods.  Delegate to the real connect_account
        (which disconnects any existing client first + creates a fresh one).
        For account_id=None, reconnect the primary account.
        """
        try:
            cluster = get_userbot_cluster()  # type: ignore[name-defined]
            aid = account_id or cluster.get_primary_id()
            if not aid:
                v85_diag("CLIENTPOOL_RECONNECT_FAILED",
                         account_id=str(account_id), reason="no_primary")
                return False
            result = await cluster.connect_account(aid)
            # connect_account returns a status string; treat "connected" as success.
            ok = isinstance(result, str) and result in ("connected", "already_connected")
            if not ok:
                v85_diag("CLIENTPOOL_RECONNECT_FAILED",
                         account_id=str(aid), reason=str(result)[:120])
            return ok
        except Exception as exc:  # noqa: BLE001
            v85_diag("CLIENTPOOL_RECONNECT_FAILED",
                     account_id=str(account_id), exc=str(exc)[:120])
            return False

    @classmethod
    async def shutdown(cls) -> None:
        """V85.4 FIX BUG CM-3: UserbotCluster has no shutdown() method.
        Disconnect every client in the cluster (idempotent).  Guard against
        the legacy shared client so we don't tear down the global _mtproto_client
        when only one account reused it (BUG CM-6).
        """
        try:
            cluster = get_userbot_cluster()  # type: ignore[name-defined]
            for aid in list(getattr(cluster, "_clients", {}).keys()):
                try:
                    await cluster.disconnect_account(aid)
                except Exception:  # noqa: BLE001
                    pass
        except Exception as exc:  # noqa: BLE001
            v85_diag("CLIENTPOOL_SHUTDOWN_FAILED", exc=str(exc)[:120])

    @classmethod
    def health_snapshot(cls) -> dict[str, Any]:
        return {"clients": dict(cls._health)}


# ===========================================================================
# V85 §5 — ProviderManager facade (Requirement 14)
# ===========================================================================

class ProviderManager:
    """Facade over the existing ``_provider_*`` machinery.

    The V80 code already classifies + cools down providers (625 hits for
    ``provider``). This facade simply exposes a stable API and emits the
    V85 diagnostic tokens (PROVIDER_AUTH_FAILED, PROVIDER_QUOTA,
    PROVIDER_BILLING, PROVIDER_DISABLED, PROVIDER_RECOVERED) required by
    the brief. It does NOT replace the existing logic.
    """

    _PROVIDERS = ("groq", "openrouter", "gemini")

    @classmethod
    def record_failure(cls, provider: str, error: str) -> str:
        cls_cls = ""
        try:
            cls_cls = _provider_record_failure(provider, error)  # type: ignore[name-defined]
        except Exception as exc:  # noqa: BLE001
            v85_diag("PROVIDER_RECORD_FAILED",
                     provider=provider, exc=str(exc)[:120])
            return "unknown"
        # Emit V85 diagnostic token based on classification.
        token_map = {
            "auth_failed": "PROVIDER_AUTH_FAILED",
            "billing_exhausted": "PROVIDER_BILLING",
            "quota_exhausted": "PROVIDER_QUOTA",
            "network": "PROVIDER_DISABLED",
        }
        token = token_map.get(cls_cls, "PROVIDER_DISABLED")
        v85_diag(token, provider=provider, cls=cls_cls)
        return cls_cls

    @classmethod
    def record_recovery(cls, provider: str) -> None:
        try:
            st = _provider_get_state(provider)  # type: ignore[name-defined]
            st["state"] = "healthy"
            st["cooldown_until"] = 0.0
            st["consecutive_successes"] = int(st.get("consecutive_successes", 0)) + 1
        except Exception:  # noqa: BLE001
            pass
        v85_diag("PROVIDER_RECOVERED", provider=provider)

    @classmethod
    def is_ready(cls, provider: str) -> tuple[bool, str]:
        try:
            st = _provider_get_state(provider)  # type: ignore[name-defined]
            now = time.monotonic()
            if st.get("state") == "failing" and st.get("cooldown_until", 0) > now:
                return False, st.get("last_error", "in_cooldown")
            return True, "ok"
        except Exception as exc:  # noqa: BLE001
            return False, str(exc)[:80]

    @classmethod
    def snapshot(cls) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for p in cls._PROVIDERS:
            try:
                st = _provider_get_state(p)  # type: ignore[name-defined]
                out[p] = {
                    "state": st.get("state", "untested"),
                    "cooldown_until": st.get("cooldown_until", 0),
                    "total_failures": st.get("total_failures", 0),
                    "last_error": st.get("last_error", ""),
                }
            except Exception:  # noqa: BLE001
                out[p] = {"state": "unknown"}
        return out


# ===========================================================================
# V85 §9 + §10 — Unified EntityResolver + resolve_message_link
# ===========================================================================

# Regex patterns for the supported Telegram link formats.
# v99.07 FIX-44: 8 lines of unprotected historical narrative removed
#  • added a private-channel-without-msg-id pattern (t.me/c/<id>) checked
#  • removed the dead/buggy _TG_LINK_PUBLIC_THREAD (had a literal-backslash
_TG_LINK_PRIVATE = re.compile(r"t(?:elegram)?\.me/c/(\d+)/(\d+)", re.IGNORECASE)
_TG_LINK_PRIVATE_NO_MSG = re.compile(r"t(?:elegram)?\.me/c/(\d+)/?$", re.IGNORECASE)
_TG_LINK_INVITE = re.compile(r"t(?:elegram)?\.me/(?:joinchat/|\+)", re.IGNORECASE)
_TG_LINK_PUBLIC_MSG = re.compile(
    r"t(?:elegram)?\.me/([A-Za-z][A-Za-z0-9_]{4,})/(\d+)", re.IGNORECASE)
_TG_LINK_PROFILE = re.compile(
    r"t(?:elegram)?\.me/([A-Za-z][A-Za-z0-9_]{4,})/?$", re.IGNORECASE)


async def resolve_message_link(link: str | int, client: Any | None = None) -> Any | None:
    """V85 §10 — Resolve a Telegram message link to the CHAT entity.

    Supported inputs:
      - ``https://t.me/c/<chat_id>/<msg_id>``  (private channel/supergroup)
      - ``https://t.me/<username>/<msg_id>``    (public channel/supergroup)
      - ``https://t.me/<username>``             (profile / channel link)
      - ``@username``                            (resolved via dialogs)
      - numeric id (int or numeric str)          (resolved via cache + dialogs)
      - ``t.me/...`` without scheme              (also accepted)

    Returns the chat entity (NOT the message). For message extraction use
    ``resolve_message_link_sender`` (already exists in V77).

    Falls through to ``resolve_entity_full`` for non-link inputs.

    This function NEVER raises — it returns ``None`` on failure so
    callers can fall back to legacy paths.
    """
    if link is None:
        return None

    # Numeric ID — delegate to the existing pipeline.
    if isinstance(link, int):
        try:
            if client is None:
                client = mtproto_get_client()  # type: ignore[name-defined]
            if client is None:
                return None
            return await resolve_entity_full(client, link)  # type: ignore[name-defined]
        except Exception:  # noqa: BLE001
            return None

    s = str(link).strip()
    if not s:
        return None

    # Normalize: strip surrounding whitespace, accept forms without scheme.
    if s.startswith("https://") or s.startswith("http://"):
        normalized = s
    elif s.startswith("t.me/"):
        normalized = "https://" + s
    elif s.startswith("@"):
        # @username form.
        try:
            if client is None:
                client = mtproto_get_client()  # type: ignore[name-defined]
            if client is None:
                return None
            return await resolve_entity_full(client, s)
        except Exception:  # noqa: BLE001
            return None
    elif s.lstrip("-").isdigit():
        try:
            if client is None:
                client = mtproto_get_client()  # type: ignore[name-defined]
            if client is None:
                return None
            return await resolve_entity_full(client, int(s))
        except Exception:  # noqa: BLE001
            return None
    else:
        normalized = s

    v85_diag("MESSAGE_LINK_RESOLVE_START", link=normalized[:120])

    if client is None:
        try:
            client = mtproto_get_client()  # type: ignore[name-defined]
        except Exception:  # noqa: BLE001
            client = None
        if client is None:
            v85_diag("MESSAGE_LINK_RESOLVE_FAILED",
                     link=normalized[:80], reason="client_unavailable")
            return None

    # V85.3 FIX BUG ENT-1: invite links (t.me/+abc, t.me/joinchat/abc) are
    # NOT entity-resolvable via the public API — reject explicitly so they
    # are not misread as a profile link to "+abc".
    if _TG_LINK_INVITE.search(normalized):
        v85_diag("MESSAGE_LINK_RESOLVE_FAILED",
                 link=normalized[:80], reason="invite_link_not_supported")
        return None

    # Private link: https://t.me/c/<chat_id>/<msg_id>
    m = _TG_LINK_PRIVATE.search(normalized)
    if m:
        chat_id_raw = int(m.group(1))
        # Marked channel/supergroup ID is -100<chat_id>.
        marked_id = -1000000000000 - chat_id_raw
        try:
            ent = await resolve_entity_full(client, marked_id)  # type: ignore[name-defined]
            v85_diag("MESSAGE_LINK_RESOLVE_OK",
                     link=normalized[:80], kind="private", chat_id=marked_id)
            return ent
        except Exception as exc:  # noqa: BLE001
            v85_diag("MESSAGE_LINK_RESOLVE_FAILED",
                     link=normalized[:80], reason="private_resolve_error",
                     exc=str(exc)[:100])
            return None

    # V85.3 FIX BUG ENT-2: private channel link WITHOUT msg id
    # (https://t.me/c/<chat_id>) — previously misread as a public link to
    # username "c".  Resolve via the marked channel ID.
    m = _TG_LINK_PRIVATE_NO_MSG.search(normalized)
    if m:
        chat_id_raw = int(m.group(1))
        marked_id = -1000000000000 - chat_id_raw
        try:
            ent = await resolve_entity_full(client, marked_id)  # type: ignore[name-defined]
            v85_diag("MESSAGE_LINK_RESOLVE_OK",
                     link=normalized[:80], kind="private_no_msg", chat_id=marked_id)
            return ent
        except Exception as exc:  # noqa: BLE001
            v85_diag("MESSAGE_LINK_RESOLVE_FAILED",
                     link=normalized[:80], reason="private_no_msg_resolve_error",
                     exc=str(exc)[:100])
            return None

    # Public link with msg id: https://t.me/<username>/<msg_id>
    m = _TG_LINK_PUBLIC_MSG.search(normalized)
    if m:
        username = m.group(1)
        try:
            ent = await resolve_entity_full(client, f"@{username}")  # type: ignore[name-defined]
            v85_diag("MESSAGE_LINK_RESOLVE_OK",
                     link=normalized[:80], kind="public_msg", username=username)
            return ent
        except Exception as exc:  # noqa: BLE001
            v85_diag("MESSAGE_LINK_RESOLVE_FAILED",
                     link=normalized[:80], reason="public_resolve_error",
                     exc=str(exc)[:100])
            return None

    # Profile / channel link: https://t.me/<username>
    m = _TG_LINK_PROFILE.search(normalized)
    if m:
        username = m.group(1).rstrip("/")
        try:
            ent = await resolve_entity_full(client, f"@{username}")  # type: ignore[name-defined]
            v85_diag("MESSAGE_LINK_RESOLVE_OK",
                     link=normalized[:80], kind="profile", username=username)
            return ent
        except Exception as exc:  # noqa: BLE001
            v85_diag("MESSAGE_LINK_RESOLVE_FAILED",
                     link=normalized[:80], reason="profile_resolve_error",
                     exc=str(exc)[:100])
            return None

    v85_diag("MESSAGE_LINK_RESOLVE_FAILED",
             link=normalized[:80], reason="unrecognized_format")
    return None


class EntityResolver:
    """V85 §9 — unified resolution pipeline facade.

    Every feature (screenshot, profile viewer, downloader, forwarded
    message resolver, MTProto lookup) should route through
    ``EntityResolver.resolve(...)`` so they all share the same cache +
    fallback chain.
    """

    @staticmethod
    async def resolve(chat_ref: str | int, client: Any | None = None) -> Any | None:
        # 1) Message link?
        ent = await resolve_message_link(chat_ref, client=client)
        if ent is not None:
            return ent
        # 2) Forwarded message cache + dialogs + contacts + common groups +
        #    username lookup (already implemented in resolve_entity_full).
        try:
            if client is None:
                client = mtproto_get_client()  # type: ignore[name-defined]
            if client is None:
                return None
            return await resolve_entity_full(client, chat_ref)  # type: ignore[name-defined]
        except Exception:  # noqa: BLE001
            return None


# ===========================================================================
# V85 §5 — RefreshCoordinator (Requirement 5)
# ===========================================================================

class RefreshCoordinator:
    """V85 §5 — synchronize caches + state without restarting the bot.

    Refresh is idempotent: any subsystem that fails to refresh is logged
    but does not abort the rest of the cycle.
    """

    _lock = asyncio.Lock()

    @classmethod
    async def refresh_all(cls) -> dict[str, Any]:
        report: dict[str, Any] = {"started": time.time(), "steps": {}}
        v85_diag("REFRESH_START")
        # RELI-J-015: skip if another refresh is already in progress so a
        # concurrent /v85refresh invocation does not pile up behind the lock
        # (which previously could serialize multiple full refresh cycles and
        # amplify load).
        if cls._lock.locked():
            report["skipped"] = True
            report["reason"] = "another refresh in progress"
            report["finished"] = time.time()
            v85_diag("REFRESH_SKIPPED", reason="lock_busy")
            return report
        async with cls._lock:
            # 1) Accounts / sessions.
            try:
                cluster = get_userbot_cluster()  # type: ignore[name-defined]
                rep = await cluster.startup_validate()
                report["steps"]["accounts"] = rep
                v85_diag("REFRESH_UPDATED", subsystem="accounts",
                         total=rep.get("total", 0),
                         connected=rep.get("connected", 0))
            except Exception as exc:  # noqa: BLE001
                report["steps"]["accounts"] = {"error": str(exc)[:120]}
                v85_diag("REFRESH_FAILED", subsystem="accounts",
                         exc=str(exc)[:120])

            # 2) Discovery cache + kick.
            # V85.4 FIX BUG R-1: ``auto_discovery_kick`` was never defined —
            # the globals() guard always evaluated False, but the code still
            # reported "kicked".  Use the real ``auto_discovery_start()``
            # function (idempotent — no-op if already running) and clear the
            # discovery query-state cache so stale cooldowns don't block.
            try:
                started = await auto_discovery_start()  # type: ignore[name-defined]
                report["steps"]["discovery"] = started
                v85_diag("REFRESH_DISCOVERY", status=started)
            except Exception as exc:  # noqa: BLE001
                report["steps"]["discovery"] = {"error": str(exc)[:120]}
                v85_diag("REFRESH_DISCOVERY", status="failed",
                         exc=str(exc)[:120])

            # V85.4 FIX BUG R-3: actually INVALIDATE stale caches so /v85refresh
            # can recover from corruption without a process restart.  These
            # are the caches that previously persisted stale state across
            # refreshes.
            try:
                _vc_entity_cache.clear()
                _vc_entity_cache_by_client.clear()
                _vc_known_call_ids.clear()
                _vc_target_cooldowns.clear()
                # PERF-J-001: Don't clear _vc_reconcile_cooldowns — prevents
                # FloodWait burst on next reconcile cycle.
                # _vc_reconcile_cooldowns.clear()
                # RELI-J-004: Don't clear _vc_in_flight_joins — active joins
                # will re-acquire; clearing mid-flight can cause duplicate
                # concurrent joins.
                # _vc_in_flight_joins.clear()
                v85_diag("REFRESH_UPDATED", subsystem="caches_cleared",
                         caches=["entity", "entity_scoped", "known_call_ids",
                                 "target_cooldowns"])
            except Exception as exc:  # noqa: BLE001
                v85_diag("REFRESH_FAILED", subsystem="cache_clear",
                         exc=str(exc)[:120])

            # 3) VC state — force a reconcile so participation records are
            # re-verified against live Telegram state (not just a snapshot read).
            try:
                st = await vc_get_status()  # type: ignore[name-defined]
                report["steps"]["vc"] = {
                    "running": st.get("running", False),
                    "active_targets": len(st.get("targets", []) if isinstance(st.get("targets"), list) else []),
                }
                v85_diag("REFRESH_VC", status="ok")
            except Exception as exc:  # noqa: BLE001
                report["steps"]["vc"] = {"error": str(exc)[:120]}
                v85_diag("REFRESH_VC", status="failed",
                         exc=str(exc)[:120])

            # 4) Client pool health.
            try:
                report["steps"]["client_pool"] = ClientPool.health_snapshot()
            except Exception as exc:  # noqa: BLE001
                report["steps"]["client_pool"] = {"error": str(exc)[:120]}

            # 5) Provider health.
            try:
                report["steps"]["providers"] = ProviderManager.snapshot()
            except Exception as exc:  # noqa: BLE001
                report["steps"]["providers"] = {"error": str(exc)[:120]}

        report["finished"] = time.time()
        report["duration_s"] = round(report["finished"] - report["started"], 3)
        v85_diag("REFRESH_COMPLETED", duration_s=report["duration_s"])
        return report


# ===========================================================================
# V85 §1 — RuntimeController (centralized startup)
# ===========================================================================

class RuntimeController:
    """V85 §1 — single authoritative startup coordinator.

    Responsibilities (in order):
      1. Acquire InstanceGuard (prevents duplicate polling).
      2. Emit UPDATE_MODE diagnostic (WEBHOOK or POLLING).
      3. Initialize caches (delegated to existing _post_init).
      4. Initialize discovery (auto_discovery_start).
      5. Initialize VC (vc_tour + reconcile + watcher-ready).
      6. Initialize refresh worker (RefreshCoordinator loop).
      7. Initialize health monitor (existing _watchdog_start).
      8. Initialize scheduler (existing _scheduled_loop).
      9. Initialize diagnostics (v85_diag).
     10. Initialize update mode (run_webhook OR run_polling, never both).

    The controller is IDEMPOTENT: every step is guarded by a flag so a
    second call is a no-op. This is the fix for the ``Conflict:
    terminated by other getUpdates request`` runtime error visible in
    the V80 logs.
    """

    _initialized = False
    _update_mode: str = "UNSET"
    _lock = asyncio.Lock()

    @classmethod
    async def post_init(cls, app: Application) -> None:
        """Called by PTB's post_init hook. Idempotent."""
        async with cls._lock:
            if cls._initialized:
                v85_diag("RUNTIME_POST_INIT_SKIP", reason="already_initialized")
                return
            cls._initialized = True

        # Determine update mode.
        if config.use_webhook and config.webhook_url:
            cls._update_mode = "WEBHOOK"
        else:
            cls._update_mode = "POLLING"
        v85_diag("RUNTIME_UPDATE_MODE", mode=cls._update_mode,
                 webhook_url=bool(config.webhook_url))

        # Acquire instance guard.
        guard_result = await InstanceGuard.acquire()
        v85_diag("INSTANCE_CHECK_START", result=guard_result)
        if guard_result == "INSTANCE_ALREADY_RUNNING":
            # Don't hard-fail; just log. The original _post_init will
            # still run because subsystems may have legitimate reasons
            # to re-bind (e.g. database reconnect). The polling loop
            # itself is what we protect against.
            logger.warning("INSTANCE_ALREADY_RUNNING — duplicate polling "
                           "may occur; investigate stale workers.")

        v85_diag("RUNTIME_POST_INIT_OK", mode=cls._update_mode)

    @classmethod
    async def post_stop(cls, app: Application) -> None:
        """Called by PTB's post_stop hook. Releases the InstanceGuard."""
        try:
            await InstanceGuard.release()
            v85_diag("RUNTIME_POST_STOP_OK")
        except Exception as exc:  # noqa: BLE001
            v85_diag("RUNTIME_POST_STOP_FAILED", exc=str(exc)[:120])
        cls._initialized = False

    @classmethod
    def update_mode(cls) -> str:
        return cls._update_mode

    @classmethod
    def status(cls) -> dict[str, Any]:
        return {
            "initialized": cls._initialized,
            "update_mode": cls._update_mode,
            "instance_active": InstanceGuard.is_active(),
            "instance_pid": InstanceGuard._pid,
            "buttons": ButtonRegistry.stats(),
            "client_pool": ClientPool.health_snapshot(),
            "providers": ProviderManager.snapshot(),
            "diag_recent": v85_diag_snapshot()[-20:],
        }


# ===========================================================================
# V96 — TaskSupervisor: unified task registry, cancellation, diagnostics.
#
# This is Phase 2 of the architectural migration. It wraps the existing
# supervised_create_task() function with a richer registry that tracks:
#   - task name + creation time
#   - restart policy (never / on_failure / always)
#   - feature-flag gate (so disabled services are never restarted)
#   - current state (starting / running / done / cancelled / failed)
#   - last error
#
# The registry is used by:
#   - _post_stop() for graceful shutdown (cancel all registered tasks)
#   - _watchdog_loop() for restart decisions
#   - /taskdump for diagnostics
#
# DESIGN PRINCIPLE: this does NOT replace supervised_create_task(). It wraps
# it. Existing call sites continue to work. New call sites should use
# TaskSupervisor.register() for the richer features.
# ===========================================================================


class TaskSupervisor:
    """V96: unified task registry with restart policies + feature-flag gates.

    Every background service should register its task here so that:
      1. _post_stop can cancel ALL tasks in one place (no more missed cancellations)
      2. The watchdog can check the restart policy before restarting
      3. /taskdump can show service state + uptime + last error
    """

    # Registry: name → task metadata
    _registry: dict[str, dict[str, Any]] = {}
    _lock = asyncio.Lock()

    # Restart policies
    RESTART_NEVER = "never"
    RESTART_ON_FAILURE = "on_failure"
    RESTART_ALWAYS = "always"

    @classmethod
    def register(
        cls,
        task: asyncio.Task,
        *,
        name: str,
        restart_policy: str = "never",
        feature_flag: str | None = None,
        restarter: Callable[[], None] | None = None,
    ) -> None:
        """Register a supervised task.

        Args:
            task: the asyncio.Task to track
            name: unique service name (e.g. "auto_discovery", "vc_watcher")
            restart_policy: "never" | "on_failure" | "always"
            feature_flag: the config attribute that gates this service
                          (e.g. "vc_discovery_enabled"). If the flag is False,
                          the watchdog will NOT restart this task.
            restarter: callable to restart the service (called by watchdog)
        """
        cls._registry[name] = {
            "task": task,
            "name": name,
            "started_at": time.monotonic(),
            "restart_policy": restart_policy,
            "feature_flag": feature_flag,
            "restarter": restarter,
            "state": "running",
            "last_error": "",
            "restart_count": 0,
        }

        def _on_done(t: asyncio.Task) -> None:
            entry = cls._registry.get(name)
            if entry is None:
                return
            if t.cancelled():
                entry["state"] = "cancelled"
            elif t.exception() is not None:
                entry["state"] = "failed"
                entry["last_error"] = f"{type(t.exception()).__name__}: {str(t.exception())[:150]}"
            else:
                entry["state"] = "done"

        task.add_done_callback(_on_done)

    @classmethod
    def is_feature_enabled(cls, name: str) -> bool:
        """Check if a registered service's feature flag is enabled."""
        entry = cls._registry.get(name)
        if entry is None:
            return True  # unknown service — don't block
        flag = entry.get("feature_flag")
        if flag is None:
            return True  # no feature flag — always enabled
        return bool(getattr(config, flag, True))

    @classmethod
    def should_restart(cls, name: str) -> bool:
        """Check if a dead service should be restarted."""
        entry = cls._registry.get(name)
        if entry is None:
            return False
        # Check feature flag first
        if not cls.is_feature_enabled(name):
            return False
        policy = entry.get("restart_policy", "never")
        state = entry.get("state", "done")
        if policy == cls.RESTART_NEVER:
            return False
        if policy == cls.RESTART_ALWAYS:
            return True
        # RESTART_ON_FAILURE
        return state == "failed"

    @classmethod
    async def cancel_all(cls, timeout: float = 10.0) -> None:
        """Cancel all registered tasks. Used by _post_stop."""
        tasks_to_cancel = []
        for name, entry in list(cls._registry.items()):
            task = entry.get("task")
            if task is not None and not task.done():
                task.cancel()
                tasks_to_cancel.append(task)
            entry["state"] = "cancelled"
        if tasks_to_cancel:
            try:
                await asyncio.wait_for(
                    asyncio.gather(*tasks_to_cancel, return_exceptions=True),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                logger.warning(
                    "TaskSupervisor: %d tasks did not cancel within %.0fs",
                    len(tasks_to_cancel), timeout,
                )
            except Exception:  # noqa: BLE001
                pass
        cls._registry.clear()

    @classmethod
    def snapshot(cls) -> list[dict[str, Any]]:
        """Return a snapshot of all registered tasks for diagnostics."""
        out = []
        now = time.monotonic()
        for name, entry in sorted(cls._registry.items()):
            task = entry.get("task")
            uptime = now - entry.get("started_at", now)
            out.append({
                "name": name,
                "state": entry.get("state", "unknown"),
                "uptime_s": round(uptime, 1),
                "restart_policy": entry.get("restart_policy", "never"),
                "feature_flag": entry.get("feature_flag"),
                "feature_enabled": cls.is_feature_enabled(name),
                "restart_count": entry.get("restart_count", 0),
                "last_error": entry.get("last_error", ""),
                "task_done": task.done() if task else True,
                "task_cancelled": task.cancelled() if task else False,
            })
        return out

    @classmethod
    def get_task(cls, name: str) -> asyncio.Task | None:
        """Get the task object for a registered service."""
        entry = cls._registry.get(name)
        if entry is None:
            return None
        return entry.get("task")


# ===========================================================================
# V96 — Enhanced RuntimeController: consolidated startup/shutdown.
#
# Phase 1 of the architectural migration. The existing RuntimeController
# only handled InstanceGuard + update mode. This enhanced version adds:
#   - service lifecycle management (start/stop all background services)
#   - startup timing diagnostics
#   - shutdown timing diagnostics
#   - integration with TaskSupervisor
#
# The existing _post_init and _post_stop functions are PRESERVED — they
# now delegate to RuntimeController for the orchestration, but the actual
# service start/stop calls remain in _post_init/_post_stop to minimize
# migration risk. Future phases will move the service start calls into
# RuntimeController methods.
# ===========================================================================


class RuntimeControllerV96:
    """V96: enhanced runtime controller with timing diagnostics.

    This is a companion to the existing RuntimeController (which handles
    InstanceGuard + update mode). RuntimeControllerV96 adds:
      - startup phase timing
      - shutdown phase timing
      - service state tracking
      - integration with TaskSupervisor

    Design: this class does NOT replace RuntimeController. Both coexist.
    _post_init calls RuntimeController.post_init() first (InstanceGuard),
    then RuntimeControllerV96.record_startup() (timing).
    """

    _startup_phases: dict[str, float] = {}
    _shutdown_phases: dict[str, float] = {}
    _startup_total: float = 0.0
    _shutdown_total: float = 0.0

    @classmethod
    def record_startup_phase(cls, phase: str, duration_ms: float) -> None:
        """Record the duration of a startup phase."""
        cls._startup_phases[phase] = duration_ms

    @classmethod
    def record_shutdown_phase(cls, phase: str, duration_ms: float) -> None:
        """Record the duration of a shutdown phase."""
        cls._shutdown_phases[phase] = duration_ms

    @classmethod
    async def timed_start(cls, phase: str, coro: Awaitable, *, timeout: float = 60) -> Any:
        """Start a phase with timing + timeout. Returns the result."""
        t0 = time.monotonic()
        try:
            result = await asyncio.wait_for(coro, timeout=timeout)
            duration_ms = (time.monotonic() - t0) * 1000
            cls.record_startup_phase(phase, duration_ms)
            logger.info(
                "STARTUP_PHASE name=%s duration_ms=%.0f status=ok",
                phase, duration_ms,
            )
            return result
        except asyncio.TimeoutError:
            duration_ms = (time.monotonic() - t0) * 1000
            cls.record_startup_phase(phase, duration_ms)
            logger.warning(
                "STARTUP_PHASE name=%s duration_ms=%.0f status=timeout",
                phase, duration_ms,
            )
        except Exception as exc:  # noqa: BLE001
            duration_ms = (time.monotonic() - t0) * 1000
            cls.record_startup_phase(phase, duration_ms)
            logger.warning(
                "STARTUP_PHASE name=%s duration_ms=%.0f status=error exc=%s",
                phase, duration_ms, str(exc)[:120],
            )
        return None

    @classmethod
    async def timed_stop(cls, phase: str, coro: Awaitable, *, timeout: float = 10) -> None:
        """Stop a phase with timing + timeout."""
        t0 = time.monotonic()
        try:
            await asyncio.wait_for(coro, timeout=timeout)
            duration_ms = (time.monotonic() - t0) * 1000
            cls.record_shutdown_phase(phase, duration_ms)
            logger.info(
                "SHUTDOWN_PHASE name=%s duration_ms=%.0f status=ok",
                phase, duration_ms,
            )
        except asyncio.TimeoutError:
            duration_ms = (time.monotonic() - t0) * 1000
            cls.record_shutdown_phase(phase, duration_ms)
            logger.warning(
                "SHUTDOWN_PHASE name=%s duration_ms=%.0f status=timeout",
                phase, duration_ms,
            )
        except Exception as exc:  # noqa: BLE001
            duration_ms = (time.monotonic() - t0) * 1000
            cls.record_shutdown_phase(phase, duration_ms)
            logger.warning(
                "SHUTDOWN_PHASE name=%s duration_ms=%.0f status=error exc=%s",
                phase, duration_ms, str(exc)[:120],
            )

    @classmethod
    def startup_summary(cls) -> dict[str, Any]:
        """Return a summary of startup timing for diagnostics."""
        return {
            "total_ms": round(cls._startup_total, 1),
            "phases": dict(cls._startup_phases),
        }

    @classmethod
    def shutdown_summary(cls) -> dict[str, Any]:
        """Return a summary of shutdown timing for diagnostics."""
        return {
            "total_ms": round(cls._shutdown_total, 1),
            "phases": dict(cls._shutdown_phases),
        }

    @classmethod
    def service_registry(cls) -> list[dict[str, Any]]:
        """Return the TaskSupervisor snapshot for /v85status."""
        return TaskSupervisor.snapshot()


# ===========================================================================
# V85 §11 — Screenshot tool unified flow (Requirement 11)
# ===========================================================================

async def v85_screenshot(chat_ref: str | int) -> Path | None:
    """V85 §11 — unified screenshot entrypoint.

    Flow:
        Input → Detect Type → Resolve → Capture
    Hides raw exceptions from users (returns None on failure).
    """
    if not chat_ref:
        return None
    v85_diag("SCREENSHOT_START", chat_ref=str(chat_ref)[:80])
    try:
        path = await mtproto_take_screenshot(chat_ref)  # type: ignore[name-defined]
        if path is not None:
            v85_diag("SCREENSHOT_OK", chat_ref=str(chat_ref)[:80],
                     path=str(path)[:120])
        else:
            v85_diag("SCREENSHOT_FAILED", chat_ref=str(chat_ref)[:80],
                     reason="no_path")
        return path
    except Exception as exc:  # noqa: BLE001
        v85_diag("SCREENSHOT_FAILED", chat_ref=str(chat_ref)[:80],
                 exc=str(exc)[:120])
        return None


# ===========================================================================
# V85 §15 — Send-restriction classification (Requirement 15)
# ===========================================================================

_SEND_RESTRICTION_CACHE: dict[int, tuple[float, str]] = {}
_SEND_RESTRICTION_TTL = 300.0  # 5 min


def v85_classify_send_failure(chat_id: int, exc: BaseException) -> str:
    """Classify a send failure into one of:
      - chat_restricted
      - media_only
      - write_forbidden
      - muted
      - banned
      - unknown
    Caches the classification briefly so we don't retry too aggressively.
    """
    name = type(exc).__name__
    msg = str(exc).lower()
    cls = "unknown"
    if "ban" in name.lower() or "ban" in msg or "deactivated" in msg:
        cls = "banned"
    elif "mute" in msg or "sendplain" in name.lower() or "plain" in msg:
        cls = "media_only" if "plain" in msg else "muted"
    elif "forbidden" in name.lower() or "forbidden" in msg:
        cls = "write_forbidden"
    elif "restricted" in msg or "restrict" in name.lower():
        cls = "chat_restricted"
    _SEND_RESTRICTION_CACHE[chat_id] = (time.time(), cls)
    # v99.07 FIX-18: prune expired entries — the cache was write-only
    # (v85_send_restriction_cached checks the TTL but never deleted),
    # so it grew monotonically with every restricted chat. The sweep is
    # amortized: only when the cache exceeds the working-set bound.
    if len(_SEND_RESTRICTION_CACHE) > 256:
        _now_sr = time.time()
        for _sr_chat in [c for c, (ts, _c) in list(_SEND_RESTRICTION_CACHE.items())
                         if _now_sr - ts >= _SEND_RESTRICTION_TTL]:
            _SEND_RESTRICTION_CACHE.pop(_sr_chat, None)
    v85_diag("SEND_RESTRICTION", chat_id=chat_id, cls=cls, exc=name)
    return cls


def v85_send_restriction_cached(chat_id: int) -> str | None:
    """Return the cached restriction class if still valid, else None."""
    try:
        ts, cls = _SEND_RESTRICTION_CACHE.get(chat_id, (0.0, ""))
        if cls and (time.time() - ts) < _SEND_RESTRICTION_TTL:
            return cls
    except Exception:  # noqa: BLE001
        pass
    return None


# ===========================================================================
# V85 §12 — Connection management audit hook (Requirement 12)
# ===========================================================================

_V85_HTTP_CLIENTS: list[Any] = []


def v85_register_http_client(client: Any) -> None:
    """Register a long-lived HTTP client for shutdown tracking."""
    _V85_HTTP_CLIENTS.append(client)


async def v85_close_all_http_clients() -> int:
    """Close every registered HTTP client. Returns count closed."""
    closed = 0
    for c in list(_V85_HTTP_CLIENTS):
        try:
            close = getattr(c, "aclose", None) or getattr(c, "close", None)
            if close is None:
                continue
            res = close()
            if hasattr(res, "__await__"):
                await res
            closed += 1
        except Exception:  # noqa: BLE001
            pass
    _V85_HTTP_CLIENTS.clear()
    v85_diag("CONNECTION_MGR_CLOSED", count=closed)
    return closed


# ===========================================================================
# V85 §4 + §8 — Discovery + VC Watcher audit helpers (Requirement 4, 8)
# ===========================================================================

async def v85_discovery_audit() -> dict[str, Any]:
    """Audit discovery state. Surfaces silent failures."""
    out: dict[str, Any] = {}
    try:
        # auto_discovery_state() exists in V80 — returns the current cycle
        # count, queue size, last_run, etc.
        st = auto_discovery_state() if 'auto_discovery_state' in globals() else {}  # type: ignore[name-defined]
        out["state"] = st
        v85_diag("DISCOVERY_AUDIT",
                 cycle=st.get("cycle", 0) if isinstance(st, dict) else 0,
                 queued=st.get("queued", 0) if isinstance(st, dict) else 0)
    except Exception as exc:  # noqa: BLE001
        out["error"] = str(exc)[:120]
        v85_diag("DISCOVERY_AUDIT_FAILED", exc=str(exc)[:120])
    return out


async def v85_vc_watcher_audit() -> dict[str, Any]:
    """Audit VC watcher state."""
    out: dict[str, Any] = {}
    try:
        # Use module attribute access — voicechat reassigns these via `global`.
        import mediagrab_bot.voicechat as _vc
        _state = getattr(_vc, "_vc_watcher_state", {})
        _task = getattr(_vc, "_vc_watcher_task", None)
        out["state"] = dict(_state) if _state else {}
        out["running"] = bool(_task and not _task.done())
        v85_diag("VC_WATCHER_AUDIT",
                 running=out["running"],
                 events=out["state"].get("events_processed", 0) if isinstance(out["state"], dict) else 0)
    except Exception as exc:  # noqa: BLE001
        out["error"] = str(exc)[:120]
        v85_diag("VC_WATCHER_AUDIT_FAILED", exc=str(exc)[:120])
    return out


# ===========================================================================
# V85 §17 — Performance audit (Requirement 17)
# ===========================================================================

def v85_performance_snapshot() -> dict[str, Any]:
    """Snapshot of duplicate workers / caches / schedulers / callbacks."""
    snap: dict[str, Any] = {}
    try:
        snap["active_tasks"] = len(_active_tasks) if '_active_tasks' in globals() else 0  # type: ignore[name-defined]
        snap["bg_tasks"] = len(_app_bg_tasks) if '_app_bg_tasks' in globals() else 0  # type: ignore[name-defined]
        snap["button_registry"] = ButtonRegistry.stats()
        snap["client_pool"] = ClientPool.health_snapshot()
        snap["providers"] = ProviderManager.snapshot()
        snap["diag_buffer_size"] = len(_V85_DIAG_BUFFER)
    except Exception as exc:  # noqa: BLE001
        snap["error"] = str(exc)[:120]
    return snap


# ===========================================================================
# V85 §18 — UI consistency hooks (Requirement 18)
# ===========================================================================

async def v85_refresh_dashboard_safely(chat_id: int, message_id: int) -> bool:
    """Refresh a dashboard message without producing stale values."""
    try:
        text = await vc_dashboard_text()  # type: ignore[name-defined]
        markup = vc_dashboard_menu()  # type: ignore[name-defined]
        ButtonRegistry.validate_markup(markup)
        await safe_edit_message_text(  # type: ignore[name-defined]
            None, chat_id, message_id, text, reply_markup=markup,
        )
        return True
    except Exception as exc:  # noqa: BLE001
        v85_diag("UI_REFRESH_FAILED", chat_id=chat_id,
                 exc=str(exc)[:120])
        return False


# ===========================================================================
# V85 — /v85status command (admin-only diagnostic surface)
# ===========================================================================

async def v85_status_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Admin-only /v85status command — shows V85 runtime state."""
    if not update.effective_user or update.effective_user.id not in config.admin_ids:
        await safe_reply_text(update.message, "🚫 Not authorised.")  # type: ignore[name-defined]
        return
    snap = RuntimeController.status()
    lines = [
        "🛠 *V85 Runtime Status*",
        f"• initialized: `{snap.get('initialized')}`",
        f"• update_mode: `{snap.get('update_mode')}`",
        f"• instance_active: `{snap.get('instance_active')}` (pid={snap.get('instance_pid')})",
        f"• unique_callbacks: `{snap.get('buttons', {}).get('unique_callbacks', 0)}`",
        f"• duplicate_callbacks: `{len(snap.get('buttons', {}).get('duplicates', []))}`",
        f"• client_pool: `{snap.get('client_pool', {}).get('clients', {})}`",
        f"• providers: `{snap.get('providers', {})}`",
        "",
        "*Recent diagnostics:*",
    ]
    for d in snap.get("diag_recent", [])[-12:]:
        lines.append(f"`{d.get('line', '')[:120]}`")
    # V96: show TaskSupervisor registry.
    try:
        _ts = TaskSupervisor.snapshot()
        if _ts:
            lines.append("")
            lines.append(f"*Supervised services ({len(_ts)}):*")
            for svc in _ts[:10]:  # limit to first 10
                lines.append(
                    f"• `{svc['name']}`: {svc['state']} uptime={svc['uptime_s']:.0f}s "
                    f"restart={svc['restart_policy']} flag={svc['feature_flag']}"
                )
    except Exception:  # noqa: BLE001
        pass
    await safe_send_message(  # type: ignore[name-defined]
        context.bot, update.effective_chat.id,
        "\n".join(lines), parse_mode="Markdown",
    )


# ===========================================================================
# v99.03 RC-8/RC-10 — /deploy_check + /v85accounts commands (admin-only).
# --------------------------------------------------------------------------
# RUNTIME-PROVEN (the 2026-09-11 v99.02 production log): the operator had
# NO live surface to see that (a) the deployment was partial
# (BUILD_IDENTITY_MISMATCH line 2 — asset missing) and (b) one of the
# three .session files was dead (SESSION_UNAUTHORIZED at line 131, never
# surfaced as "this account needs re-login").  The report "still facing
# issues + there are two accounts but showing one" was the direct result:
# every diagnostic fact existed ONLY in a 3,292-line log file.  These two
# commands put the same facts one Telegram message away — they are pure
# READ-ONLY views over deploy_health (RC-8) and mtproto's session health
# registry (RC-10); they never mutate state and never issue RPCs.
# ===========================================================================

async def v99_03_deploy_check_command(
        update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Admin-only /deploy_check — the deployment health view (RC-8/RC-9)."""
    if not update.effective_user or update.effective_user.id not in config.admin_ids:
        await safe_reply_text(update.message, "🚫 Not authorised.")  # type: ignore[name-defined]
        return
    lines = ["🔍 *Deployment Check* (v99.03 RC-8/RC-9)"]
    try:
        from . import deploy_health as _dh
        snap = _dh.build_identity_state()
        heal = _dh.self_heal_report()
        state = str(snap.get("state", "unknown"))
        icon = "✅" if state == "verified" else ("❌" if state == "mismatch" else "⚪")
        lines.append(f"{icon} build identity: `{state}`")
        if snap.get("stamp_version"):
            lines.append(f"• stamp version: `{snap['stamp_version']}` "
                         f"(runtime `{snap.get('runtime_version', '?')}`)")
        if snap.get("detail"):
            lines.append(f"• detail: `{str(snap['detail'])[:160]}`")
        disabled = _dh.vc_pipeline_disabled_reason()
        lines.append(f"• VC pipeline: `{'DISABLED — ' + disabled if disabled else 'enabled'}`")
        if heal:
            lines.append(f"• self-heal: `{'✅ ' if heal.get('ok') else '❌ '}"
                         f"{', '.join(heal.get('assets', []))} "
                         f"from {heal.get('source', '')[:80]}`")
        elif state == "mismatch":
            lines.append("• self-heal: `not attempted / not possible "
                         "(no matching deployment ZIP on disk)`")
    except Exception as exc:  # noqa: BLE001
        lines.append(f"• deploy_health: `unavailable ({type(exc).__name__})`")
    # The stamped silence asset (RC-1/RC-9 surface).
    try:
        import os as _os9903
        _asset = _os9903.path.join(_os9903.path.dirname(__file__),
                                   "assets", "vc_silence_600s.opus")
        if _os9903.path.isfile(_asset):
            lines.append(f"• silence asset: `✅ present "
                         f"({_os9903.path.getsize(_asset):,} bytes)`")
        else:
            lines.append("• silence asset: `❌ MISSING — VC joins cannot use "
                         "the real silent stream`")
    except Exception:  # noqa: BLE001
        pass
    # FD census (RC-3 surface — the v99.02 census, read-only here).
    try:
        from .handlers import _fd_census  # noqa: PLC0415
        import asyncio as _aio9903
        census = await _aio9903.get_event_loop().run_in_executor(
            None, _fd_census)
        if census.get("available"):
            lines.append(f"• FD census: `total={census['total']} "
                         f"soft={census['soft']} "
                         f"sockets={census['sockets']}`")
    except Exception:  # noqa: BLE001
        pass
    # Session health summary (RC-10 surface).
    try:
        from .mtproto import account_session_health  # noqa: PLC0415
        h = account_session_health()
        lines.append(
            f"• sessions: `total_files={h['total_files']} live={h['live']} "
            f"dead={h['dead']} unregistered={h['unregistered']}` "
            "(/v85accounts for details)")
    except Exception:  # noqa: BLE001
        pass
    lines.append("")
    lines.append("Runbook: extract the FULL deployment ZIP (never just "
                 "`.py`); see DEPLOYMENT.md v99.03 §runbook.")
    await safe_reply_text(update.message, "\n".join(lines),  # type: ignore[name-defined]
                          parse_mode="Markdown")


async def v99_03_accounts_command(
        update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Admin-only /v85accounts — the per-session account health view (RC-10)."""
    if not update.effective_user or update.effective_user.id not in config.admin_ids:
        await safe_reply_text(update.message, "🚫 Not authorised.")  # type: ignore[name-defined]
        return
    lines = ["👤 *Account Session Health* (v99.03 RC-10)"]
    try:
        from .mtproto import account_session_health  # noqa: PLC0415
        h = account_session_health()
        lines.append(
            f"`total_files={h['total_files']} live={h['live']} "
            f"dead={h['dead']} unregistered={h['unregistered']} "
            f"expected_cluster={h['expected_cluster']}`")
        lines.append("")
        for d in h.get("details", []):
            status = str(d.get("status", "?"))
            if status == "unauthorized":
                icon = "💀"
            elif status.startswith("cluster_account") or status == "primary_global":
                icon = "✅"
            else:
                icon = "⚪"
            extra = ""
            if d.get("username"):
                extra += f" @{d['username']}"
            if d.get("account_id"):
                extra += f" (`{d['account_id']}`)"
            lines.append(f"{icon} `{d.get('file', '?')}`: {status}{extra}")
            if status == "unauthorized":
                lines.append(
                    f"   ↳ *action:* `{d.get('action', 'delete_and_relogin')}` "
                    "— delete the session file and re-login "
                    "(`SESSION_REMEDIATION` in the log has the exact command)")
        # Also list registered cluster accounts (accounts.json view).
        try:
            from .mtproto import get_userbot_cluster  # noqa: PLC0415
            cluster = get_userbot_cluster()
            accounts = cluster.list_accounts() if cluster else []
            if accounts:
                lines.append("")
                lines.append(f"*Registered cluster accounts ({len(accounts)}):*")
                for acc in accounts[:12]:
                    lines.append(
                        f"• `{acc['account_id']}` @{acc.get('username') or '(none)'} "
                        f"status=`{acc.get('status', '?')}`")
        except Exception:  # noqa: BLE001
            pass
    except Exception as exc:  # noqa: BLE001
        lines.append(f"`unavailable ({type(exc).__name__}: "
                     f"{str(exc)[:100]})`")
    await safe_reply_text(update.message, "\n".join(lines),  # type: ignore[name-defined]
                          parse_mode="Markdown")


# ===========================================================================
# V86 — /multimodal command (admin-only multimodal AI diagnostics surface)
# ===========================================================================

async def multimodal_status_command(update: Update,
                                    context: ContextTypes.DEFAULT_TYPE) -> None:
    """Admin-only /multimodal command — shows multimodal AI configuration status."""
    if not update.effective_user or update.effective_user.id not in config.admin_ids:
        await safe_reply_text(update.message, "🚫 Not authorised.")
        return
    try:
        witai_avail = bool(witai_service.available) if hasattr(witai_service, "available") else False
    except Exception:  # noqa: BLE001
        witai_avail = False
    lines = [
        "🎛 *Multimodal AI Status*",
        f"• multimodal_enabled: `{getattr(config, 'multimodal_enabled', True)}`",
        f"• witai_enabled: `{getattr(config, 'witai_enabled', False)}`",
        f"• witai_available: `{witai_avail}`",
        f"• voice_provider: `{getattr(config, 'voice_provider', 'auto')}`",
        f"• intent_provider: `{getattr(config, 'intent_provider', 'auto')}`",
        f"• vision_provider: `{getattr(config, 'vision_provider', 'gemini')}`",
        f"• voice_reply_enabled: `{getattr(config, 'voice_reply_enabled', False)}`",
        f"• ocr_enabled: `{getattr(config, 'ocr_enabled', True)}`",
        "",
        "*Providers:*",
        f"• Gemini: `{'✅' if config.gemini_api_key else '❌'}`",
        f"• Groq: `{'✅' if config.groq_api_key else '❌'}`",
        f"• OpenRouter: `{'✅' if config.openrouter_api_key else '❌'}`",
        f"• Wit.ai: `{'✅' if getattr(config, 'witai_enabled', False) else '❌'}`",
    ]
    await safe_reply_text(update.message, "\n".join(lines), parse_mode="Markdown")


# ===========================================================================
# V85 — final module initialization log
# ===========================================================================

v85_diag("V85_MODULE_LOADED", version="v85", ts=int(time.time()))
logger.info("V85 module loaded — RuntimeController, InstanceGuard, "
            "ButtonRegistry, ClientPool, ProviderManager, EntityResolver, "
            "resolve_message_link, RefreshCoordinator ready.")


# ===========================================================================
# v99.07 FIX-44: 7 lines of unprotected historical narrative removed
# Wraps the existing vc_watcher_start, auto_discovery_start, and VC
# (VC_WATCHER_STARTED, VC_WATCHER_FAILED, VC_CONTROL_START,
# at the actual event time. These wrappers are idempotent and never

# VC_WATCHER_STARTED / VC_WATCHER_FAILED — wrap vc_watcher_start.
try:
    _v85_orig_vc_watcher_start = vc_watcher_start  # type: ignore[name-defined]

    async def vc_watcher_start(*args: Any, **kwargs: Any) -> str:  # type: ignore[no-redef]
        # OBS-J-001: do NOT emit VC_WATCHER_STARTED at entry — only emit on
        # success below. The entry-time emission produced misleading
        # diagnostics when the start subsequently failed.
        try:
            result = await _v85_orig_vc_watcher_start(*args, **kwargs)
        except Exception as exc:  # noqa: BLE001
            v85_diag("VC_WATCHER_FAILED", exc=str(exc)[:120])
            raise
        if result in ("already_running", "mtproto_not_started",
                      "tour_running_stop_first", "join_all_running_stop_first"):
            v85_diag("VC_WATCHER_FAILED", reason=result)
        else:
            v85_diag("VC_WATCHER_STARTED", result=result)
        return result
    v85_diag("VC_WATCHER_PATCH_INSTALLED", target="vc_watcher_start")
except Exception as exc:  # noqa: BLE001
    v85_diag("VC_WATCHER_PATCH_FAILED", exc=str(exc)[:120])


# DISCOVERY_START / DISCOVERY_COMPLETED / DISCOVERY_FAILED — wrap
# auto_discovery_start. We can't easily hook per-cycle, but we emit
# DISCOVERY_START here and the V85 discovery audit helper emits
# COMPLETED/FAILED based on state transitions.
try:
    _v85_orig_auto_discovery_start = auto_discovery_start  # type: ignore[name-defined]

    async def auto_discovery_start(*args: Any, **kwargs: Any) -> str:  # type: ignore[no-redef]
        v85_diag("DISCOVERY_START", ts=int(time.time()))
        try:
            result = await _v85_orig_auto_discovery_start(*args, **kwargs)
            # OBS-J-002: only emit DISCOVERY_COMPLETED when discovery actually
            # started. Other results (already_running, mtproto_not_started,
            # disabled, etc.) are no-ops — emit DISCOVERY_NOOP instead so the
            # audit trail distinguishes a real completion from a skipped one.
            if result == "started":
                v85_diag("DISCOVERY_COMPLETED", result=str(result)[:80])
            else:
                v85_diag("DISCOVERY_NOOP", reason=str(result)[:80])
            return result
        except Exception as exc:  # noqa: BLE001
            v85_diag("DISCOVERY_FAILED", exc=str(exc)[:120])
            raise
    v85_diag("DISCOVERY_PATCH_INSTALLED", target="auto_discovery_start")
except Exception as exc:  # noqa: BLE001
    v85_diag("DISCOVERY_PATCH_FAILED", exc=str(exc)[:120])


# VC_CONTROL_START — wrap the public VC control entry points. The actual
# VC-control functions are vc_start_tour, vc_stop_tour, vc_pause_tour,
# vc_resume_tour, vc_skip_current, vc_leave_target, vc_join_all_active_start,
# vc_join_all_active_stop. Wrap each one.
try:
    for _v85_vc_fn_name in ("vc_start_tour", "vc_stop_tour",
                            "vc_pause_tour", "vc_resume_tour",
                            "vc_skip_current", "vc_leave_target",
                            "vc_join_all_active_start",
                            "vc_join_all_active_stop"):
        if _v85_vc_fn_name in globals():
            _orig = globals()[_v85_vc_fn_name]
            if not callable(_orig) or getattr(_orig, "_v85_wrapped", False):
                continue

            async def _v85_vc_wrapper(*args: Any, _orig_fn: Any = _orig,
                                      _fn_name: str = _v85_vc_fn_name,
                                      **kwargs: Any) -> Any:
                v85_diag("VC_CONTROL_START", fn=_fn_name,
                         ts=int(time.time()))
                try:
                    if inspect.iscoroutinefunction(_orig_fn):
                        return await _orig_fn(*args, **kwargs)
                    return _orig_fn(*args, **kwargs)
                except Exception as exc:  # noqa: BLE001
                    v85_diag("VC_FAILED", fn=_fn_name, exc=str(exc)[:120])
                    raise

            _v85_vc_wrapper._v85_wrapped = True  # type: ignore[attr-defined]
            globals()[_v85_vc_fn_name] = _v85_vc_wrapper
    v85_diag("VC_CONTROL_PATCH_INSTALLED")
except Exception as exc:  # noqa: BLE001
    v85_diag("VC_CONTROL_PATCH_FAILED", exc=str(exc)[:120])


# ===========================================================================
# v99.03 RC-9 — deployment self-heal: re-extract stamped assets from the
# on-disk deployment ZIP when the boot identity check finds them missing.
# ---------------------------------------------------------------------------
# RUNTIME-PROVEN (the 2026-09-11 02:45:10 v99.02 production log, line 2):
#   BUILD_IDENTITY_MISMATCH detail=[assets/vc_silence_600s.opus:
#   stamp=e6ad24a0ecd48db2 actual=missing] — the operator extracted only
#   the .py files from the deployment ZIP; the 226,371-byte asset shipped
#   IN that ZIP never reached the runtime tree.  The v99.02 gate honestly
#   blocked all 40 subsequent joins; v99.03 additionally repairs the most
#   common operator error at boot: when the deployment ZIP is still on
#   disk (the standard upload-then-extract flow), the stamped asset is
#   re-extracted from it AFTER a sha256 verification against the stamp,
#   atomically (tmp + os.replace), and the identity is re-verified.
#
# Safety rules (all enforced below):
#   * ONLY the exact stamped asset rel-paths are ever extracted — no
#     arbitrary ZIP members, no path traversal (".." is rejected).
#   * The member's sha256[:16] MUST equal the stamp expectation BEFORE
#     anything is written; a wrong-content ZIP is refused (fall through
#     to the RC-8 fail-fast instead of installing unknown bytes).
#   * Member size is bounded (< 8 MB) — the shipped asset is 226 KB.
#   * Writes are atomic (tempfile in the destination dir + os.replace).
#   * VC_DISABLE_DEPLOY_SELF_HEAL=1 turns the mechanism off for operators
#     who prefer strict fail-fast (the RC-8 refusal then applies).
# ===========================================================================


def _v9903_self_heal_disabled() -> bool:
    """RC-9 operator kill-switch."""
    return os.environ.get("VC_DISABLE_DEPLOY_SELF_HEAL") == "1"


def _v9903_self_heal_zip_candidates(module_dir: str) -> list[str]:
    """Deployment ZIP candidates, newest-first, deduped.

    Mirrors the operator runbook layout: the ZIP typically sits next to
    the extracted tree (``/home/container/mediagrab_bot*.zip`` and
    ``./mediagrab_bot*.zip`` — i.e. ONE level above the package dir,
    which is also the usual process cwd).  Searched roots: the process
    cwd, the package's parent dir (the deployment root), and the
    package dir itself.
    """
    import glob as _v9903_glob
    roots: list[str] = []
    for _root in (os.getcwd(),
                  os.path.abspath(os.path.join(module_dir, "..")),
                  module_dir):
        try:
            if _root and os.path.isdir(_root) and _root not in roots:
                roots.append(_root)
        except Exception:  # noqa: BLE001
            pass
    candidates: dict[str, float] = {}
    for _root in roots:
        try:
            for _zp in _v9903_glob.glob(os.path.join(_root, "mediagrab_bot*.zip")):
                try:
                    candidates[os.path.abspath(_zp)] = os.path.getmtime(_zp)
                except OSError:
                    candidates[os.path.abspath(_zp)] = 0.0
        except Exception:  # noqa: BLE001
            pass
    return [p for p, _ in sorted(candidates.items(), key=lambda kv: -kv[1])]


def _v9903_self_heal_assets(stamp_asset_hashes: dict,
                             runtime_asset_hashes: dict,
                             module_dir: str) -> dict:
    """RC-9: repair missing/altered stamped assets from the on-disk ZIP.

    Returns {"ok": bool, "source": str, "assets": [rel, ...],
    "sha256": {rel: expected_hash}, "reason": str}.  Never raises — a
    failed heal is a fall-through to the RC-8 fail-fast, not a boot risk.
    """
    out: dict = {"ok": False, "source": "", "assets": [],
                 "sha256": {}, "reason": "not_attempted"}
    try:
        if _v9903_self_heal_disabled():
            out["reason"] = "disabled_by_env"
            return out
        needed: dict[str, str] = {}
        for _rel, _expected in (stamp_asset_hashes or {}).items():
            _actual = (runtime_asset_hashes or {}).get(_rel, "?")
            if str(_expected) != str(_actual):
                needed[str(_rel)] = str(_expected)
        if not needed:
            out["reason"] = "nothing_to_heal"
            out["ok"] = True
            return out
        import zipfile as _v9903_zipfile
        import tempfile as _v9903_tempfile
        # v99.03 RC-9: hashlib under the MODULE-LOCAL name — bootstrap's
        # `import hashlib as _hashlib` lives INSIDE main() (a function
        # local), so a module-level helper referencing `_hashlib` would
        # NameError at call time (caught by the exec-extraction efficacy
        # test before it could ever reach production). Import it here,
        # under the same alias, so the function is self-contained.
        import hashlib as _v9903_hashlib
        candidates = _v9903_self_heal_zip_candidates(module_dir)
        if not candidates:
            out["reason"] = "no_deployment_zip_found"
            # v99.04 RC-14: NO early return here — the embedded stage
            # below may still heal the asset from asset_embedded.py (the
            # .py-only deployment case).  The reason survives for the
            # BOTH-sources-absent case (v99.03 contract preserved).
        for _zip_path in candidates:
            try:
                with _v9903_zipfile.ZipFile(_zip_path, "r") as _zf:
                    _names = set(_zf.namelist())
                    _member_map: dict[str, str] = {}
                    for _rel in needed:
                        if os.path.normpath(_rel).startswith("..") \
                                or os.path.isabs(_rel):
                            continue  # never extract traversing paths
                        for _cand in (os.path.join("mediagrab_bot", _rel), _rel):
                            if _cand in _names:
                                _member_map[_rel] = _cand
                                break
                    if len(_member_map) != len(needed):
                        continue  # this ZIP does not carry every needed asset
                    _extracted: list[str] = []
                    for _rel, _member in _member_map.items():
                        _info = _zf.getinfo(_member)
                        if _info.file_size <= 0 or _info.file_size > 8 * 1024 * 1024:
                            out["reason"] = ("asset_size_out_of_bounds "
                                             f"{_rel} size={_info.file_size}")
                            continue
                        _data = _zf.read(_member)
                        _actual = _v9903_hashlib.sha256(_data).hexdigest()[:16]
                        if _actual != needed[_rel]:
                            out["reason"] = (f"sha256_mismatch {_rel} "
                                             f"expected={needed[_rel]} "
                                             f"actual={_actual}")
                            continue
                        _dest = os.path.join(module_dir, _rel)
                        os.makedirs(os.path.dirname(_dest), exist_ok=True)
                        _fd, _tmp = _v9903_tempfile.mkstemp(
                            prefix=".v9903_heal_", suffix=".tmp",
                            dir=os.path.dirname(_dest))
                        try:
                            with os.fdopen(_fd, "wb") as _tf:
                                _tf.write(_data)
                            os.replace(_tmp, _dest)
                        except Exception:
                            try:
                                os.unlink(_tmp)
                            except OSError:
                                pass
                            raise
                        _extracted.append(_rel)
                        out["sha256"][_rel] = needed[_rel]
                        logger.info(
                            "DEPLOY_SELF_HEAL asset=%s source=%s sha256=%s "
                            "bytes=%d — stamped asset re-extracted from the "
                            "on-disk deployment ZIP and sha256-verified "
                            "against the build stamp (v99.03 RC-9)",
                            os.path.basename(_rel), _zip_path,
                            needed[_rel], len(_data),
                        )
                    if len(_extracted) == len(needed):
                        out["ok"] = True
                        out["source"] = _zip_path
                        out["assets"] = _extracted
                        out["reason"] = "healed"
                        return out
            except Exception as _zip_exc:  # noqa: BLE001
                out["reason"] = (f"zip_error {type(_zip_exc).__name__}: "
                                 f"{str(_zip_exc)[:120]}")
                continue
        if not out.get("reason") or out["reason"] == "not_attempted":
            out["reason"] = "no_zip_contained_all_needed_assets"
        # ------------------------------------------------------------------
        # v99.04 RC-14 — the EMBEDDED-asset fallback.  RUNTIME-PROVEN via
        # the 2026-09-11 v99.03 production log (runs 3+4, 06:25→07:16):
        # DEPLOY_SELF_HEAL_FAILED reason=no_deployment_zip_found fired at
        # BOTH boots because the operator's channel transfers .py FILES
        # ONLY — no deployment ZIP ever exists on the box, so the v99.03
        # ZIP-only heal can never fire there.  The stamped asset is
        # therefore ALSO shipped as base64 text inside
        # asset_embedded.py (a .py file the channel reliably delivers).
        # Safety rules (IDENTICAL to the ZIP stage — identity checking is
        # NOT weakened):
        #   * the decoded bytes' sha256[:16] MUST equal the stamp
        #     expectation BEFORE anything is written (a corrupted/edited
        #     embed is refused — falls through to RC-8);
        #   * size is bounded and must match the embed's declared size;
        #   * writes stay atomic (mkstemp + os.replace);
        #   * the same VC_DISABLE_DEPLOY_SELF_HEAL kill-switch applies.
        # All imports are FUNCTION-LOCAL and the stage is fully inline so
        # the v99.03 exec-extraction tests (which run THIS exact function
        # body with only os/hashlib/logger in scope) keep their contracts:
        # in their scratch scenarios asset_embedded.py does not exist, so
        # the stage is a no-op and the ZIP-stage reason survives.
        # ------------------------------------------------------------------
        try:
            _v9904_embedded: dict = {}
            _v9904_emb_src = ""
            try:
                from . import asset_embedded as _v9904_ae  # package context
                _v9904_embedded = dict(getattr(_v9904_ae, "EMBEDDED_ASSETS",
                                               {}) or {})
                _v9904_emb_src = "import:asset_embedded.py"
            except Exception:  # noqa: BLE001
                _v9904_emb_path = os.path.join(module_dir,
                                                "asset_embedded.py")
                if os.path.isfile(_v9904_emb_path):
                    try:
                        with open(_v9904_emb_path, "r",
                                  encoding="utf-8") as _v9904_emb_f:
                            _v9904_emb_src_text = _v9904_emb_f.read()
                        _v9904_ns: dict = {"__builtins__": {}}
                        exec(compile(  # noqa: S102
                                _v9904_emb_src_text,
                                "<asset_embedded.py>", "exec"), _v9904_ns)
                        _v9904_embedded = dict(_v9904_ns.get(
                            "EMBEDDED_ASSETS", {}) or {})
                        _v9904_emb_src = f"file:{_v9904_emb_path}"
                    except Exception as _v9907_ae_exc:  # noqa: BLE001
                        # v99.07 FIX-41: a MALFORMED asset_embedded.py was
                        # previously swallowed silently (empty dict, no
                        # diagnostic) — the embedded heal stage then
                        # no-op'd with no trace of WHY. Emit the explicit
                        # marker (the RC-8 failure path below stays the
                        # authoritative verdict).
                        _v9904_embedded = {}
                        logger.warning(
                            "ASSET_EMBEDDED_MALFORMED — asset_embedded.py "
                            "exists but could not be executed: %s: %s — "
                            "the embedded heal stage is unavailable; the "
                            "ZIP heal stage verdict stands (v99.07 FIX-41)",
                            type(_v9907_ae_exc).__name__,
                            str(_v9907_ae_exc)[:160],
                        )
            if _v9904_embedded and needed:
                import base64 as _v9904_b64
                import tempfile as _v9904_tf
                _v9904_extracted: list[str] = []
                for _rel, _expected in needed.items():
                    _v9904_entry = _v9904_embedded.get(_rel)
                    if not isinstance(_v9904_entry, dict):
                        if out["reason"] == "no_deployment_zip_found":
                            out["reason"] = (f"no_repair_source_for {_rel}")
                        continue
                    try:
                        _v9904_data = _v9904_b64.b64decode(
                            str(_v9904_entry.get("b64", "")), validate=True)
                    except Exception:  # noqa: BLE001
                        out["reason"] = f"embedded_b64_decode_failed {_rel}"
                        continue
                    _v9904_size = int(_v9904_entry.get("size", 0) or 0)
                    if _v9904_size <= 0 or _v9904_size != len(_v9904_data) \
                            or _v9904_size > 8 * 1024 * 1024:
                        out["reason"] = (f"embedded_size_out_of_bounds {_rel} "
                                         f"size={_v9904_size}")
                        continue
                    _v9904_actual = _v9903_hashlib.sha256(
                        _v9904_data).hexdigest()[:16]
                    if _v9904_actual != _expected:
                        out["reason"] = (f"embedded_sha256_mismatch {_rel} "
                                         f"expected={_expected} "
                                         f"actual={_v9904_actual}")
                        continue
                    _v9904_dest = os.path.join(module_dir, _rel)
                    os.makedirs(os.path.dirname(_v9904_dest), exist_ok=True)
                    _v9904_fd, _v9904_tmp = _v9904_tf.mkstemp(
                        prefix=".v9904_heal_", suffix=".tmp",
                        dir=os.path.dirname(_v9904_dest))
                    try:
                        with os.fdopen(_v9904_fd, "wb") as _v9904_tf_h:
                            _v9904_tf_h.write(_v9904_data)
                        os.replace(_v9904_tmp, _v9904_dest)
                    except Exception:
                        try:
                            os.unlink(_v9904_tmp)
                        except OSError:
                            pass
                        raise
                    _v9904_extracted.append(_rel)
                    out["sha256"][_rel] = _expected
                    logger.info(
                        "DEPLOY_SELF_HEAL asset=%s source=embedded:%s "
                        "sha256=%s bytes=%d — stamped asset restored from "
                        "the EMBEDDED copy shipped as .py text (v99.04 "
                        "RC-14; .py-only deployments are complete)",
                        os.path.basename(_rel), _v9904_emb_src, _expected,
                        len(_v9904_data),
                    )
                if _v9904_extracted and len(_v9904_extracted) == len(needed):
                    out["ok"] = True
                    out["source"] = f"embedded:{_v9904_emb_src}"
                    out["assets"] = _v9904_extracted
                    out["reason"] = "healed"
                    return out
        except Exception as _v9904_emb_exc:  # noqa: BLE001
            # The embedded stage must never break the ZIP-stage verdict.
            logger.debug("embedded-asset heal stage failed (non-fatal): "
                         "%s: %s", type(_v9904_emb_exc).__name__,
                         str(_v9904_emb_exc)[:120])
        return out
    except Exception as _heal_exc:  # noqa: BLE001
        out["ok"] = False
        out["reason"] = f"heal_error {type(_heal_exc).__name__}: " \
                        f"{str(_heal_exc)[:120]}"
        return out


# ---------------------------------------------------------------------------
# v99.04 RC-17 — the deploy-health RECOVERY loop (no-restart repair path).
#
# RUNTIME-PROVEN CONTEXT (the 2026-09-11 v99.03 production log, runs 3+4):
# the boot identity was decided ONCE at 06:25:28 / 06:27:15 and the only
# repair path was "restart the bot after fixing the tree" — the operator
# restarted twice in 2 minutes trying to make the new .py set take
# effect.  Mission §9 (v99.04): healthy → broken → repaired →
# automatically healthy again, WITHOUT a restart.
#
# Mechanics: when (and only when) the boot verdict was "mismatch", this
# loop re-verifies the FULL identity (version + module hashes + stamped
# assets) every 120s, re-running the RC-9/RC-14 heal (ZIP first, then
# the embedded .py copy) for asset mismatches.  On success it publishes
# the verified state to deploy_health — and because EVERY consumer
# (the vc_pipeline entry gate, the discovery/reconcile skips, the
# heartbeat) re-reads deploy_health.vc_pipeline_disabled_reason() at
# USE time, VC joins resume IMMEDIATELY with no restart.  Module-hash
# mismatches (a genuinely mixed .py deployment) are also detected: the
# operator can fix the files while the bot runs and the loop flips the
# state the moment the tree matches the stamp again.
# ---------------------------------------------------------------------------
_v9904_deploy_recovery_task = None
_V9904_RECOVERY_INTERVAL_S = 120


def _v9904_get_deploy_health():
    """Import deploy_health in BOTH package and exec-harness contexts.

    Production uses the package-relative import; the v99.04
    exec-extraction tests (and any scratch-tree tooling) run these
    function bodies without a package parent, where the relative import
    raises — fall back to the plain module name (the tests put the
    package dir on sys.path)."""
    try:
        from . import deploy_health as _v9904_dh_mod  # package context
        return _v9904_dh_mod
    except Exception:  # noqa: BLE001
        import importlib as _v9904_il
        return _v9904_il.import_module("deploy_health")


def _v9904_reverify_identity(module_dir: str) -> dict:
    """RC-17: recompute the FULL boot-identity verdict on demand.

    Self-contained (function-local imports only) so the v99.04
    exec-extraction tests run the SHIPPED bytes.  Returns
    {"state": "verified"|"mismatch"|"unreadable", "detail": str,
    "heal": <RC-9/RC-14 report or None>}.  A mismatch that involves
    stamped ASSETS triggers one heal attempt (ZIP → embedded) and a full
    re-evaluation, exactly like the boot path.
    """
    import hashlib as _v9904_hashlib
    import json as _v9904_json
    out: dict = {"state": "unknown", "detail": "", "heal": None}
    try:
        with open(os.path.join(module_dir, "build_stamp.json"), "r",
                  encoding="utf-8") as _v9904_sf:
            _v9904_stamp = _v9904_json.loads(_v9904_sf.read())
        _v9904_expected_version = str(_v9904_stamp.get("version", "") or "")
        _v9904_modules = dict(_v9904_stamp.get("modules", {}) or {})
        _v9904_assets = dict(_v9904_stamp.get("assets", {}) or {})
    except Exception as _v9904_stamp_exc:  # noqa: BLE001
        out["state"] = "unreadable"
        out["detail"] = (f"{type(_v9904_stamp_exc).__name__}: "
                         f"{str(_v9904_stamp_exc)[:120]}")
        return out

    def _v9904_eval() -> list[str]:
        _v9904_mism: list[str] = []
        # v99.04: the version comes from the package import when running
        # in-process (production), with a FILE-READ fallback that parses
        # __bot_version__ from the deployed tree's own __init__.py — the
        # exec-harness/packaged-simulation contexts have no package
        # parent, and a relative-import failure must NOT fabricate a
        # "runtime=unknown" version mismatch (caught by the packaged
        # partial-deployment simulation).
        _v9904_pkg_ver = ""
        try:
            from . import __bot_version__ as _v9904_pkg_ver_imp
            _v9904_pkg_ver = str(_v9904_pkg_ver_imp)
        except Exception:  # noqa: BLE001
            # File-read fallback: parse the assignment line directly (no
            # regex, no package parent needed).
            try:
                with open(os.path.join(module_dir, "__init__.py"), "r",
                          encoding="utf-8") as _v9904_if:
                    for _v9904_ln in _v9904_if.read().splitlines():
                        if _v9904_ln.startswith("__bot_version__"):
                            _v9904_pkg_ver = _v9904_ln.split(
                                "=", 1)[1].strip().strip("'\"")
                            break
            except Exception:  # noqa: BLE001
                _v9904_pkg_ver = ""
        if _v9904_expected_version and _v9904_pkg_ver \
                and _v9904_expected_version != _v9904_pkg_ver:
            _v9904_mism.append(f"version: stamp={_v9904_expected_version} "
                               f"runtime={_v9904_pkg_ver}")
        for _v9904_mod, _v9904_exp in _v9904_modules.items():
            try:
                with open(os.path.join(module_dir, _v9904_mod), "rb") as _mf:
                    _v9904_act = _v9904_hashlib.sha256(
                        _mf.read()).hexdigest()[:16]
            except Exception:  # noqa: BLE001
                _v9904_act = "missing"
            if str(_v9904_exp) != str(_v9904_act):
                _v9904_mism.append(f"{_v9904_mod}: stamp={_v9904_exp} "
                                   f"actual={_v9904_act}")
        for _v9904_rel, _v9904_exp_a in _v9904_assets.items():
            try:
                with open(os.path.join(module_dir, _v9904_rel), "rb") as _af:
                    _v9904_act_a = _v9904_hashlib.sha256(
                        _af.read()).hexdigest()[:16]
            except FileNotFoundError:
                _v9904_act_a = "missing"
            except Exception:  # noqa: BLE001
                _v9904_act_a = "?"
            if str(_v9904_exp_a) != str(_v9904_act_a):
                _v9904_mism.append(f"{_v9904_rel}: stamp={_v9904_exp_a} "
                                   f"actual={_v9904_act_a}")
        return _v9904_mism

    _v9904_mismatches = _v9904_eval()
    if _v9904_mismatches and any(
            str(_m).startswith("assets/") for _m in _v9904_mismatches):
        # One more heal attempt — the operator may have dropped the ZIP
        # in, or the embedded .py may have arrived since boot.
        _v9904_runtime_assets: dict[str, str] = {}
        for _v9904_rel in _v9904_assets:
            try:
                with open(os.path.join(module_dir, _v9904_rel), "rb") as _af:
                    _v9904_runtime_assets[_v9904_rel] = \
                        _v9904_hashlib.sha256(_af.read()).hexdigest()[:16]
            except FileNotFoundError:
                _v9904_runtime_assets[_v9904_rel] = "missing"
            except Exception:  # noqa: BLE001
                _v9904_runtime_assets[_v9904_rel] = "?"
        try:
            out["heal"] = _v9903_self_heal_assets(
                _v9904_assets, _v9904_runtime_assets, module_dir)
        except Exception as _v9904_heal_exc:  # noqa: BLE001
            logger.debug("RC-17 recovery heal failed (non-fatal): %s: %s",
                         type(_v9904_heal_exc).__name__,
                         str(_v9904_heal_exc)[:120])
        # Re-evaluate AFTER the heal (module files are untouched by it).
        _v9904_mismatches = _v9904_eval()
    if _v9904_mismatches:
        out["state"] = "mismatch"
        out["detail"] = "; ".join(_v9904_mismatches)[:300]
    else:
        out["state"] = "verified"
        out["detail"] = (f"stamp_version={_v9904_expected_version} "
                         f"modules={len(_v9904_modules)} "
                         f"assets={len(_v9904_assets)}")
    return out


async def _v9904_deploy_health_recovery_loop() -> None:
    """RC-17: while the boot identity is mismatched, re-verify + re-heal
    every 120s; publish the recovered state the moment the tree matches
    the stamp again (joins resume without a restart)."""
    _v9904_dh = _v9904_get_deploy_health()
    _v9904_module_dir = os.path.dirname(__file__)
    logger.warning(
        "DEPLOY_HEALTH_RECOVERY_LOOP started interval=%ds — the boot "
        "identity FAILED; the FULL identity (version + modules + stamped "
        "assets) will be re-verified in the background and the RC-9/RC-14 "
        "heal re-attempted (deployment ZIP, then the embedded .py copy). "
        "Repair the tree while the bot runs; VC joins resume AUTOMATICALLY "
        "once the identity verifies — no restart needed (v99.04 RC-17).",
        _V9904_RECOVERY_INTERVAL_S,
    )
    try:
        while True:
            await asyncio.sleep(_V9904_RECOVERY_INTERVAL_S)
            try:
                if not _v9904_dh.build_identity_mismatch():
                    # Recovered elsewhere (or reset) — nothing to do.
                    return
                _v9904_verdict = _v9904_reverify_identity(
                    _v9904_module_dir)
                if _v9904_verdict.get("state") == "verified":
                    _v9904_heal = _v9904_verdict.get("heal") or {}
                    if _v9904_heal.get("ok"):
                        try:
                            _v9904_dh.mark_self_heal(
                                True, list(_v9904_heal.get("assets", [])),
                                str(_v9904_heal.get("source", "")),
                                dict(_v9904_heal.get("sha256", {})))
                        except Exception:  # noqa: BLE001
                            pass
                    _v9904_prev = _v9904_dh.build_identity_state()
                    _v9904_dh.set_build_identity(
                        "verified", str(_v9904_verdict.get("detail", "")),
                        stamp_version=str(
                            _v9904_prev.get("stamp_version", "") or ""),
                        runtime_version=str(
                            _v9904_prev.get("runtime_version", "") or ""),
                    )
                    logger.info(
                        "DEPLOY_HEALTH_RECOVERED detail=[%s] healed=[%s] — "
                        "the deployment was repaired WHILE RUNNING; the VC "
                        "pipeline re-opens IMMEDIATELY (no restart; v99.04 "
                        "RC-17).",
                        str(_v9904_verdict.get("detail", ""))[:200],
                        ",".join(_v9904_heal.get("assets", []) or []) or "no",
                    )
                    return
                logger.debug(
                    "DEPLOY_HEALTH_RECOVERY_ATTEMPT state=%s detail=[%s] "
                    "(v99.04 RC-17)",
                    _v9904_verdict.get("state", "?"),
                    str(_v9904_verdict.get("detail", ""))[:160],
                )
            except asyncio.CancelledError:
                raise
            except Exception as _v9904_cyc_exc:  # noqa: BLE001
                logger.debug("deploy-health recovery cycle failed "
                             "(non-fatal): %s: %s",
                             type(_v9904_cyc_exc).__name__,
                             str(_v9904_cyc_exc)[:120])
    except asyncio.CancelledError:
        logger.info("DEPLOY_HEALTH_RECOVERY_LOOP cancelled (v99.04 RC-17)")
        raise


def _v9904_deploy_recovery_schedule() -> None:
    """RC-17: start the recovery loop IFF the boot verdict was a mismatch.

    Called from _post_init (async context, loop running).  Idempotent;
    never raises."""
    global _v9904_deploy_recovery_task
    try:
        _v9904_dh = _v9904_get_deploy_health()
        if not _v9904_dh.build_identity_mismatch():
            return
        if _v9904_deploy_recovery_task is not None \
                and not _v9904_deploy_recovery_task.done():
            return
        _v9904_deploy_recovery_task = supervised_create_task(
            _v9904_deploy_health_recovery_loop(),
            name="deploy_health_recovery",
        )
        logger.info("DEPLOY_HEALTH_RECOVERY_SCHEDULED interval=%ds — the "
                    "boot identity FAILED; background re-verification is "
                    "active; repair the tree at any time (v99.04 RC-17).",
                    _V9904_RECOVERY_INTERVAL_S)
    except Exception as _v9904_sched_exc:  # noqa: BLE001
        logger.debug("deploy-health recovery scheduling failed "
                     "(non-fatal): %s: %s",
                     type(_v9904_sched_exc).__name__,
                     str(_v9904_sched_exc)[:120])




def main() -> None:
    # v97.90: CRITICAL FIX — call setup_logging() FIRST, before anything else.
    # Root cause of "diagnostic logging not working": setup_logging() is defined
    # in utils_real.py but was NEVER CALLED. It was only called from _bot_core.py:88
    # — but _bot_core.py is NOT imported by bootstrap.py or __init__.py.
    # bootstrap.py creates its logger via `logging.getLogger("mediagrab")` which
    # gives a bare logger with NO file handler → DIAGNOSTIC_BOOT never prints,
    # no diagnostic file is created.
    # FIX: call setup_logging() at the very start of main().
    try:
        setup_logging()
    except Exception as exc:
        print(f"CRITICAL: setup_logging() failed: {type(exc).__name__}: {exc}", file=sys.stderr)

    # v97.88: DEPLOYMENT_IDENTITY — emit at startup so the runtime can verify
    # which source version is actually deployed. This is printed to stderr
    # (always visible) AND logged.
    # v97.92: extend the source-hash set to include mtproto.py, bootstrap.py,
    # handlers.py, and join_all_worker.py — the previous set (voicechat,
    # utils_real, config) missed the modules most involved in the runtime
    # cascade (mtproto reconnect + bootstrap shutdown + handlers admin
    # routes). Adding them lets the next deployment verify ALL critical
    # modules' integrity from the runtime log alone.
    import hashlib as _hashlib
    _module_dir = os.path.dirname(__file__)
    _vc_path = os.path.join(_module_dir, "voicechat.py")
    _ur_path = os.path.join(_module_dir, "utils_real.py")
    _cfg_path = os.path.join(_module_dir, "config.py")
    _mt_proto_path = os.path.join(_module_dir, "mtproto.py")
    _bootstrap_path = os.path.join(_module_dir, "bootstrap.py")
    _handlers_path = os.path.join(_module_dir, "handlers.py")
    _join_all_worker_path = os.path.join(_module_dir, "join_all_worker.py")
    # v98.12-FINAL2 FIX-ID (§11 — RUNTIME-PROVEN via bot-diagnostic.log
    # 2026-09-04 03:35:34/05:18:37: BOTH production startups logged
    # BUILD_IDENTITY_MISMATCH [__init__.py: stamp=db5aa9a9 actual=?]
    # while ALL 8 other module hashes matched the packaged v98.12 zip —
    # the stamp verification loop looks up every stamp module in
    # _v9812_runtime_hashes, but that dict never computed __init__.py,
    # so ``actual=?`` → a FALSE mismatch on every clean deployment,
    # destroying operator trust in the §21 identity system. The package
    # __init__ is now hashed like every other stamped module.
    _init_path = os.path.join(_module_dir, "__init__.py")
    _init_sha = "?"
    try:
        with open(_init_path, "rb") as _f:
            _init_sha = _hashlib.sha256(_f.read()).hexdigest()[:16]
    except Exception:
        pass
    _vc_sha = "?"
    _ur_sha = "?"
    _cfg_sha = "?"
    _mt_sha = "?"
    _bs_sha = "?"
    _hd_sha = "?"
    _jw_sha = "?"
    for _path, _var in [
        (_vc_path, "_vc_sha"), (_ur_path, "_ur_sha"), (_cfg_path, "_cfg_sha"),
        (_mt_proto_path, "_mt_sha"), (_bootstrap_path, "_bs_sha"),
        (_handlers_path, "_hd_sha"), (_join_all_worker_path, "_jw_sha"),
    ]:
        try:
            with open(_path, "rb") as _f:
                _hash = _hashlib.sha256(_f.read()).hexdigest()[:16]
            if _var == "_vc_sha":
                _vc_sha = _hash
            elif _var == "_ur_sha":
                _ur_sha = _hash
            elif _var == "_cfg_sha":
                _cfg_sha = _hash
            elif _var == "_mt_sha":
                _mt_sha = _hash
            elif _var == "_bs_sha":
                _bs_sha = _hash
            elif _var == "_hd_sha":
                _hd_sha = _hash
            else:
                _jw_sha = _hash
        except Exception:
            pass
    _pytgcalls_ver = "?"
    try:
        import pytgcalls
        _pytgcalls_ver = getattr(pytgcalls, "__version__", "?")
    except ImportError:
        _pytgcalls_ver = "not_installed"
    _telethon_ver = "?"
    try:
        import telethon
        _telethon_ver = getattr(telethon, "__version__", "?")
    except ImportError:
        _telethon_ver = "not_installed"
    # v98.12 §21 (DEPLOYMENT IDENTITY — RUNTIME-CORRELATED via (6).log: the
    # runtime reported version=v98.09 while mtproto_sha256 matched the
    # v98.11 tree — a MIXED deployment identity that made log forensics
    # ambiguous). The version now comes from the package's single source of
    # truth (`mediagrab_bot.__bot_version__`) — never a hardcoded string —
    # and the identity line gains: (1) the build stamp verification result
    # (stamped-at-zip-time module hashes; mismatch = the deployed tree was
    # modified after packaging — logged LOUDLY, never silently), (2) the
    # detected supervisor, (3) the startup timestamp.
    try:
        from . import __bot_version__ as _v9812_pkg_version
    except ImportError:
        _v9812_pkg_version = "unknown"
    # v98.12 §21: runtime hashes for the stamp comparison — computed BEFORE
    # the stamp block so the identity line works even when the stamp is
    # missing (dev/test trees).
    _v9812_runtime_hashes = {
        "voicechat.py": _vc_sha, "utils_real.py": _ur_sha,
        "config.py": _cfg_sha, "mtproto.py": _mt_sha,
        "bootstrap.py": _bs_sha, "handlers.py": _hd_sha,
        "join_all_worker.py": _jw_sha,
        "__init__.py": _init_sha,  # v98.12-FINAL2 FIX-ID: was missing → false "actual=?" mismatch on every clean deployment
        "mtproto_generation.py": "?",
        # v99.01 FIX-B (RUNTIME-PROVEN via bot-diagnostic.log 2026-09-09
        # 15:39:26: "BUILD_IDENTITY_MISMATCH stamp_version=v99.00
        # runtime_version=v99.00 detail=[vc_pipeline.py:
        # stamp=23104d682dc734f8 actual=?]" on a CLEAN v99.00 deployment):
        # v99.00 added vc_pipeline.py to the STAMP side
        # (tools/stamp_build.py §17) but NOT to this runtime-hash map —
        # the stamp loop then read actual=? → a FALSE mismatch on every
        # clean deployment, the same class as the v98.12-FINAL2 FIX-ID
        # __init__.py incident ("destroying operator trust in the §21
        # identity system"). The canonical pipeline is now hashed at
        # startup like every other stamped module (the runtime itself
        # proves the file is present+correct — the log's pipeline line
        # numbers matched the v99.00 source byte-exactly).
        "vc_pipeline.py": "?",
    }
    try:
        with open(os.path.join(_module_dir, "mtproto_generation.py"), "rb") as _mg_f:
            _v9812_runtime_hashes["mtproto_generation.py"] = _hashlib.sha256(
                _mg_f.read()).hexdigest()[:16]
    except Exception:
        pass
    try:
        with open(os.path.join(_module_dir, "vc_pipeline.py"), "rb") as _vcp_f:
            _v9812_runtime_hashes["vc_pipeline.py"] = _hashlib.sha256(
                _vcp_f.read()).hexdigest()[:16]
    except Exception:
        pass
    # v99.02 FIX-1a (RC-1, RUNTIME-PROVEN via v99.01 production logs
    # 2026-09-09 17:55 → 2026-09-10 03:20): the v99.01 production tree was
    # missing assets/vc_silence_600s.opus (a PARTIAL deployment — only .py
    # files were copied; the ZIP contains the 226,371-byte asset) yet
    # BUILD_IDENTITY_VERIFIED passed: the stamp's ASSETS dict was never
    # verified at runtime, only stamp.modules. The bot then ran 10 hours
    # with EVERY join falling back to the null-stream transport
    # (98× VC_SILENCE_ASSET_MISSING → 168 dispatches → 0 verifications →
    # VC_JOIN_SUCCESS=0 + join-churn FD pressure). Stamped DATA assets are
    # now hashed at startup exactly like stamped modules — a missing or
    # altered asset is a BUILD_IDENTITY_MISMATCH with an explicit
    # [assets/<name>: stamp=… actual=missing] entry, catching partial
    # deployments at boot instead of 6 hours later.
    _v9812_runtime_asset_hashes: dict[str, str] = {}
    try:
        for _asset_rel in ("assets/vc_silence_600s.opus",):
            try:
                with open(os.path.join(_module_dir, _asset_rel), "rb") as _af:
                    _v9812_runtime_asset_hashes[_asset_rel] = _hashlib.sha256(
                        _af.read()).hexdigest()[:16]
            except FileNotFoundError:
                _v9812_runtime_asset_hashes[_asset_rel] = "missing"
            except Exception:
                _v9812_runtime_asset_hashes[_asset_rel] = "unreadable"
    except Exception:
        pass
    _v9812_stamp_state = "missing"
    _v9812_stamp_detail = "no build stamp"
    # v99.03 RC-8: pre-initialized so the deploy_health publication below can
    # reference it on every path (missing/unreadable stamp included).
    _v9812_expected_version = ""
    _v9812_stamp_path = os.path.join(_module_dir, "build_stamp.json")
    try:
        import json as _v9812_json
        with open(_v9812_stamp_path, "r", encoding="utf-8") as _v9812_sf:
            _v9812_stamp = _v9812_json.load(_v9812_sf)
        _v9812_expected_version = str(_v9812_stamp.get("version", ""))
        _v9812_hashes = _v9812_stamp.get("modules") or {}
        # v99.02 FIX-1a: stamped DATA assets participate in the identity
        # comparison with the same semantics as modules (missing → a
        # explicit mismatch entry, never a silent pass).
        _v9812_asset_hashes = _v9812_stamp.get("assets") or {}
        _v9812_mismatches: list[str] = []
        if _v9812_expected_version and _v9812_expected_version != _v9812_pkg_version:
            _v9812_mismatches.append(
                f"version: stamp={_v9812_expected_version} runtime={_v9812_pkg_version}")
        for _v9812_mod, _v9812_expected_sha in _v9812_hashes.items():
            _v9812_actual = _v9812_runtime_hashes.get(_v9812_mod, "?")
            if str(_v9812_expected_sha) != str(_v9812_actual):
                _v9812_mismatches.append(
                    f"{_v9812_mod}: stamp={_v9812_expected_sha} actual={_v9812_actual}")
        # v99.02 FIX-1a: asset identity loop (see the runtime-hash block
        # comment above — the v99.01 production deployment passed
        # BUILD_IDENTITY_VERIFIED while the silence asset was absent).
        for _v9812_asset, _v9812_expected_asha in _v9812_asset_hashes.items():
            _v9812_actual_a = _v9812_runtime_asset_hashes.get(_v9812_asset, "?")
            if str(_v9812_expected_asha) != str(_v9812_actual_a):
                _v9812_mismatches.append(
                    f"{_v9812_asset}: stamp={_v9812_expected_asha} "
                    f"actual={_v9812_actual_a}")
        if _v9812_mismatches:
            # v99.07 FIX-19: lowercase — the other states are
            # "verified"/"missing"/"unreadable"; deploy_health
            # normalizes anyway, but the raw string in
            # DEPLOYMENT_IDENTITY build_stamp= is now consistent.
            _v9812_stamp_state = "mismatch"
            _v9812_stamp_detail = "; ".join(_v9812_mismatches)[:300]
            logger.error(
                "BUILD_IDENTITY_MISMATCH stamp_version=%s runtime_version=%s "
                "detail=[%s] — the deployed tree DOES NOT match the packaged "
                "build (v98.12 §21: mixed deployment detected; source of the "
                "runtime log will NOT match the packaged artifact)",
                _v9812_expected_version, _v9812_pkg_version, _v9812_stamp_detail,
            )
            # v99.03 RC-9 (RUNTIME-PROVEN via the 2026-09-11 v99.02 log: "the
            # operator extracted only .py files; the ZIP with the asset sat
            # beside the tree for the whole 36-minute run"): when the mismatch
            # includes stamped ASSETS, attempt to re-extract exactly those
            # assets from the on-disk deployment ZIP (sha256-verified against
            # the stamp, atomic write) and RE-VERIFY the full identity.  A
            # successful heal converts this MISMATCH into VERIFIED below; a
            # failed heal falls through and RC-8 (deploy_health publication,
            # after the try block) fail-fasts the VC pipeline.
            _v9903_asset_mismatch_present = any(
                str(_m).startswith("assets/") for _m in _v9812_mismatches)
            if _v9903_asset_mismatch_present:
                try:
                    _v9903_heal = _v9903_self_heal_assets(
                        _v9812_asset_hashes, _v9812_runtime_asset_hashes,
                        _module_dir)
                    if _v9903_heal.get("ok") and _v9903_heal.get("assets"):
                        # Recompute the runtime asset hashes for the healed set.
                        for _asset_rel in _v9903_heal["assets"]:
                            try:
                                with open(os.path.join(_module_dir, _asset_rel), "rb") as _af:
                                    _v9812_runtime_asset_hashes[_asset_rel] = \
                                        _hashlib.sha256(_af.read()).hexdigest()[:16]
                            except Exception:  # noqa: BLE001
                                pass
                        # Re-evaluate the FULL mismatch list (modules unchanged;
                        # only the asset entries can differ after the heal).
                        _v9812_mismatches = []
                        if _v9812_expected_version and _v9812_expected_version != _v9812_pkg_version:
                            _v9812_mismatches.append(
                                f"version: stamp={_v9812_expected_version} runtime={_v9812_pkg_version}")
                        for _v9812_mod, _v9812_expected_sha in _v9812_hashes.items():
                            _v9812_actual = _v9812_runtime_hashes.get(_v9812_mod, "?")
                            if str(_v9812_expected_sha) != str(_v9812_actual):
                                _v9812_mismatches.append(
                                    f"{_v9812_mod}: stamp={_v9812_expected_sha} actual={_v9812_actual}")
                        for _v9812_asset, _v9812_expected_asha in _v9812_asset_hashes.items():
                            _v9812_actual_a = _v9812_runtime_asset_hashes.get(_v9812_asset, "?")
                            if str(_v9812_expected_asha) != str(_v9812_actual_a):
                                _v9812_mismatches.append(
                                    f"{_v9812_asset}: stamp={_v9812_expected_asha} "
                                    f"actual={_v9812_actual_a}")
                        if not _v9812_mismatches:
                            _v9812_stamp_state = "verified"
                            _v9812_stamp_detail = (
                                f"stamp_version={_v9812_expected_version} "
                                f"modules={len(_v9812_hashes)} "
                                f"assets={len(_v9812_asset_hashes)} "
                                f"self_healed=1 source={_v9903_heal.get('source', '')}")
                            logger.info(
                                "BUILD_IDENTITY_VERIFIED stamp_version=%s modules=%d "
                                "assets=%d self_healed=1 — stamped assets re-extracted "
                                "(source=%s; v99.03 RC-9 ZIP / v99.04 RC-14 embedded) "
                                "and the full identity re-verified",
                                _v9812_expected_version, len(_v9812_hashes),
                                len(_v9812_asset_hashes),
                                _v9903_heal.get("source", ""),
                            )
                            # v99.03 RC-9: the successful heal is also recorded in
                            # deploy_health for /deploy_check (mark_self_heal).
                            try:
                                from . import deploy_health as _v9903_dh_heal
                                _v9903_dh_heal.mark_self_heal(
                                    True, list(_v9903_heal["assets"]),
                                    str(_v9903_heal.get("source", "")),
                                    dict(_v9903_heal.get("sha256", {})))
                            except Exception:  # noqa: BLE001
                                pass
                        else:
                            _v9812_stamp_detail = "; ".join(_v9812_mismatches)[:300]
                            logger.error(
                                "BUILD_IDENTITY_MISMATCH stamp_version=%s "
                                "runtime_version=%s detail=[%s] — REMAINS after the "
                                "RC-9 self-heal healed only some assets; the VC "
                                "pipeline will be disabled (v99.03 RC-8)",
                                _v9812_expected_version, _v9812_pkg_version,
                                _v9812_stamp_detail,
                            )
                    else:
                        logger.warning(
                            "DEPLOY_SELF_HEAL_FAILED reason=%s — could not "
                            "repair the stamped assets from any on-disk "
                            "deployment ZIP NOR from the embedded .py copy "
                            "(asset_embedded.py); the VC pipeline will be "
                            "disabled (v99.03 RC-8/RC-9 + v99.04 RC-14). "
                            "Runbook: deploy the COMPLETE v99.04 .py set "
                            "(asset_embedded.py included — then the asset "
                            "self-heals), or extract the FULL deployment "
                            "ZIP, or set "
                            "VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH=1 to run "
                            "degraded.",
                            _v9903_heal.get("reason", "unknown"),
                        )
                except Exception as _v9903_heal_exc:  # noqa: BLE001
                    logger.warning(
                        "DEPLOY_SELF_HEAL_FAILED reason=exception exc=%s: %s — "
                        "falling through to the RC-8 fail-fast (v99.03)",
                        type(_v9903_heal_exc).__name__,
                        str(_v9903_heal_exc)[:120],
                    )
        else:
            _v9812_stamp_state = "verified"
            _v9812_stamp_detail = (
                f"stamp_version={_v9812_expected_version} "
                f"modules={len(_v9812_hashes)} assets={len(_v9812_asset_hashes)}")
            logger.info(
                "BUILD_IDENTITY_VERIFIED stamp_version=%s modules=%d "
                "assets=%d — deployed tree matches the packaged build "
                "(v98.12 §21 + v99.02 FIX-1a: stamped data assets verified)",
                _v9812_expected_version, len(_v9812_hashes),
                len(_v9812_asset_hashes),
            )
    except FileNotFoundError:
        _v9812_stamp_state = "missing"
        _v9812_stamp_detail = "build_stamp.json not packaged (dev/test tree)"
    except Exception as _v9812_stamp_exc:  # noqa: BLE001
        _v9812_stamp_state = "unreadable"
        _v9812_stamp_detail = f"{type(_v9812_stamp_exc).__name__}: {str(_v9812_stamp_exc)[:120]}"
    # ---------------------------------------------------------------------
    # v99.03 RC-8: publish the FINAL identity verdict to deploy_health —
    # the shared state the VC pipeline entry gate, the discovery/reconcile
    # loops, the heartbeat, and /deploy_check all read.  This is the exact
    # point where "the code knows the deployment is broken" becomes "the
    # whole bot knows": with a MISMATCH (post-self-heal), ONE clear
    # operator-facing ERROR line is emitted here at boot, joins/discovery/
    # reconcile refuse to run (see vc_pipeline.run_vc_join entry gate), and
    # the Bot API surface stays available for diagnosis.  Fail-open for
    # dev/test trees (missing/unreadable stamp → never disabled).
    # ---------------------------------------------------------------------
    try:
        from . import deploy_health as _v9903_dh
        _v9903_dh.set_build_identity(
            _v9812_stamp_state, _v9812_stamp_detail,
            stamp_version=str(_v9812_expected_version or ""),
            runtime_version=str(_v9812_pkg_version or ""),
        )
        if _v9903_dh.vc_pipeline_disabled_reason() is not None:
            logger.error(
                "VC_PIPELINE_DISABLE reason=build_identity_mismatch — the "
                "boot build-identity check FAILED and the RC-9 self-heal could "
                "not repair it: ALL VC joins will be refused at pipeline entry "
                "(zero entity-resolution RPCs) and discovery/reconcile cycles "
                "are skipped. The Bot API surface stays available (/deploy_check, "
                "/v85accounts, /v85status). Repair: re-extract the FULL "
                "deployment ZIP — see DEPLOYMENT.md v99.03 §runbook. Override: "
                "VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH=1 (v99.03 RC-8)."
            )
    except Exception as _v9903_dh_exc:  # noqa: BLE001
        logger.debug("deploy_health publication failed (non-fatal): %s",
                     _v9903_dh_exc)
    _v9812_supervisor = "unknown"
    try:
        if os.environ.get("INVOCATION_ID") or os.environ.get("JOURNAL_STREAM"):
            _v9812_supervisor = "systemd"
        elif os.path.isfile("/proc/1/comm"):
            with open("/proc/1/comm", "r", encoding="utf-8") as _v9812_p1:
                _v9812_supervisor = _v9812_p1.read().strip() or "unknown"
    except Exception:
        pass
    import datetime as _v9812_dt
    _dep_msg = (
        f"DEPLOYMENT_IDENTITY version={_v9812_pkg_version} "
        f"build_stamp={_v9812_stamp_state} "
        f"supervisor={_v9812_supervisor} "
        f"voicechat_sha256={_vc_sha} "
        f"utils_real_sha256={_ur_sha} "
        f"config_sha256={_cfg_sha} "
        f"mtproto_sha256={_mt_sha} "
        f"bootstrap_sha256={_bs_sha} "
        f"handlers_sha256={_hd_sha} "
        f"join_all_worker_sha256={_jw_sha} "
        f"mtproto_generation_sha256={_v9812_runtime_hashes.get('mtproto_generation.py', '?')} "
        # v99.01 FIX-B: the canonical pipeline's identity is now part of
        # the startup identity line — this deployment's forensics had to
        # INFER the vc_pipeline identity from log line numbers because
        # the identity line omitted it (while the stamp expected it).
        f"vc_pipeline_sha256={_v9812_runtime_hashes.get('vc_pipeline.py', '?')} "
        # v99.02 FIX-1a: the silence asset's identity joins the startup
        # identity line (the v99.01 forensics had to INFER the missing
        # asset from 98× VC_SILENCE_ASSET_MISSING warnings; the identity
        # line now states it directly — 'missing' when absent).
        f"vc_silence_asset_sha256={_v9812_runtime_asset_hashes.get('assets/vc_silence_600s.opus', '?')} "
        f"python={sys.version.split()[0]} "
        f"python_executable={sys.executable} "
        f"pytgcalls_version={_pytgcalls_ver} "
        f"telethon_version={_telethon_ver} "
        f"started_at={_v9812_dt.datetime.now().isoformat(timespec='seconds')} "
        f"pid={os.getpid()} "
        f"cwd={os.getcwd()}"
    )
    # v99.07 FIX-19: matched the normalized lowercase state.
    if _v9812_stamp_state == "mismatch":
        _dep_msg += f" stamp_detail=[{_v9812_stamp_detail}]"
    print(_dep_msg, file=sys.stderr)
    logger.info("=== MediaGrab AI Bot starting (Bot API only) ===")
    logger.info(_dep_msg)
    # v98.09 ARCH (§28): STARTUP CONFIGURATION VALIDATION — the
    # boundedness model is validated BEFORE any discovery/reconcile work
    # runs (impossible combinations are rejected with a clear diagnostic
    # here, not discovered later inside a frozen cycle). The validator
    # reads only getattr() — fully exception-guarded; a validation
    # failure NEVER blocks boot (it logs VC_ARCH_CONFIG_INVALID and the
    # operator fixes the config; the per-key clamps in config.py remain
    # the hard guard).
    try:
        from .vc_architecture import validate_vc_arch_config
        _v98a_cfg_ok, _v98a_cfg_problems = validate_vc_arch_config(config)
        # The validator itself emits VC_ARCH_CONFIG_VALIDATED (ok) /
        # VC_ARCH_CONFIG_INVALID (rejected) at INFO/ERROR level; this
        # bootstrap-side echo makes the startup integration observable
        # in the bootstrap log stream too (§28: startup validation is a
        # first-class lifecycle event, not a silent internal check).
        if _v98a_cfg_ok and not _v98a_cfg_problems:
            logger.debug(
                "VC_ARCH_CONFIG_VALIDATED (v98.09 §28 bootstrap echo — "
                "validator emitted the full budget line)")
        if _v98a_cfg_ok and _v98a_cfg_problems:
            # ok=True with problems = WARNING-class (e.g. no supervisor).
            for _p in _v98a_cfg_problems:
                logger.warning("VC_ARCH_CONFIG_WARNING %s", _p)
    except Exception as _v98a_cfg_exc:  # noqa: BLE001
        logger.warning(
            "VC_ARCH config validation could not run: %s", _v98a_cfg_exc)
    # V85 §3: cross-process instance guard. The runtime logs show:
    #   telegram.error.Conflict: terminated by other getUpdates request;
    #   make sure that only one bot instance is running
    # This happens when a previous container is still alive holding the
    # long-poll while a new one starts. We use a PID file as a
    # cross-process guard: if a stale PID is still alive, we abort
    # startup with a clear diagnostic instead of fighting for getUpdates.
    _V85_PID_FILE = Path(config.project_root) / "data" / ".v85_instance.pid"
    # v99.07 FIX-22 (consume side): detect + archive the canary exit marker
    # left by a previous os._exit(86) — the boot log then states, from disk
    # evidence alone, that the previous termination was a canary wedge
    # (vs a clean shutdown), independent of the supervisor journal.
    try:
        _v9907_cmark = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "data",
            "vc_canary_exit_86.marker")
        if os.path.isfile(_v9907_cmark):
            try:
                with open(_v9907_cmark, "r", encoding="utf-8") as _cmf:
                    _v9907_cinfo = " ".join(_cmf.read().split())[:200]
            except Exception:  # noqa: BLE001
                _v9907_cinfo = "(unreadable)"
            logger.warning(
                "VC_CANARY_EXIT_MARKER_DETECTED — the previous process "
                "terminated via canary os._exit(86) (event-loop wedge); "
                "marker: %s (v99.07 FIX-22)",
                _v9907_cinfo,
            )
            try:
                os.replace(
                    _v9907_cmark,
                    _v9907_cmark + ".consumed_" + str(int(time.time())))
            except OSError:
                try:
                    os.unlink(_v9907_cmark)
                except OSError:
                    pass
    except Exception:  # noqa: BLE001
        pass
    try:
        # v97.92: harden the PID file guard against TOCTOU races + PID reuse.
        #   - Check /proc/<pid>/cmdline for "mediagrab_bot" on Linux so an
        #     unrelated daemon reusing the dead bot's PID doesn't false-abort.
        #   - Use atomic write via tempfile + os.replace so a concurrent
        #     startup can't observe a half-written PID file.
        if _V85_PID_FILE.exists():
            try:
                prev_pid = int(_V85_PID_FILE.read_text().strip())
            except (ValueError, OSError):
                prev_pid = 0
            alive = False
            if prev_pid:
                try:
                    os.kill(prev_pid, 0)  # signal 0 = existence check
                    alive = True
                except OSError:
                    alive = False
                # v97.92: verify the PID actually belongs to a bot process.
                # On Linux, read /proc/<pid>/cmdline; if it doesn't contain
                # "mediagrab_bot", treat the PID as reused by an unrelated daemon.
                if alive:
                    _cmdline_path = f"/proc/{prev_pid}/cmdline"
                    try:
                        with open(_cmdline_path, "rb") as _cpf:
                            _cmdline = _cpf.read().decode("utf-8", errors="replace")
                        if "mediagrab_bot" not in _cmdline and "bootstrap" not in _cmdline:
                            logger.warning(
                                "V85_PID_REUSE_DETECTED prev_pid=%d is alive but "
                                "cmdline does not contain mediagrab_bot — treating "
                                "as stale (PID reused by unrelated process). "
                                "Reclaiming (v97.92).",
                                prev_pid,
                            )
                            alive = False
                    except (OSError, FileNotFoundError):
                        # /proc not available (non-Linux) — trust os.kill.
                        pass
            if alive:
                logger.error(
                    "INSTANCE_ALREADY_RUNNING prev_pid=%d — aborting startup to "
                    "avoid getUpdates Conflict. Stop the other process first.",
                    prev_pid,
                )
                # v98.12-FINAL2 §13: the second live process is REJECTED —
                # exactly one process owns the Telegram/VC accounts.
                logger.error(
                    "VC_PROCESS_OWNERSHIP_REJECTED pid=%s owner_pid=%s "
                    "single_instance=yes — this process exits; the live "
                    "owner keeps all VC/Telegram account state "
                    "(v98.12-FINAL2 §13)",
                    os.getpid(), prev_pid,
                )
                v85_diag("INSTANCE_ALREADY_RUNNING", prev_pid=prev_pid)
                sys.exit(2)
            else:
                # v98.08 FIX-XX (F6', RUNTIME-PROVEN: L4 "Stale PID file
                # found (prev_pid=1060 not alive)" — manual restarts are
                # the current "supervisor"; the 17:23:43 canary exit(86)
                # left the bot dark until a human intervened). Recovery
                # accounting: read the previous heartbeat file for its
                # uptime/last_beat, detect the supervisor, and log ONE
                # STARTUP_RECOVERY line so downtime is measurable from
                # the diagnostic log alone.
                try:
                    _v808_prev_uptime = -1
                    _v808_prev_beat_age = -1.0
                    try:
                        _v808_hb_path = os.path.join(
                            os.path.dirname(os.path.abspath(__file__)),
                            "data", "bot_heartbeat.json")
                        if os.path.isfile(_v808_hb_path):
                            with open(_v808_hb_path, encoding="utf-8") as _hf:
                                _v808_hb = json.load(_hf)
                            _v808_prev_uptime = int(
                                _v808_hb.get("uptime_seconds", -1) or -1)
                            _v808_lb = float(_v808_hb.get("last_beat", 0) or 0)
                            if _v808_lb > 0:
                                _v808_prev_beat_age = max(
                                    0.0, time.time() - _v808_lb)
                    except Exception:  # noqa: BLE001
                        pass
                    _v808_supervisor = "none"
                    try:
                        if os.environ.get("INVOCATION_ID") or \
                                os.environ.get("SYSTEMD_EXEC_PID"):
                            _v808_supervisor = "systemd"
                        else:
                            _v808_p1 = "/proc/1/comm"
                            if os.path.isfile(_v808_p1):
                                with open(_v808_p1, encoding="utf-8") as _pf:
                                    _v808_p1c = _pf.read().strip().lower()
                                if _v808_p1c in ("systemd",):
                                    _v808_supervisor = "systemd-user-mode"
                    except Exception:  # noqa: BLE001
                        pass
                    # v99.07 FIX-21: the trio below fired at INFO on EVERY
                    # boot that reclaims a stale PID file (the routine case
                    # under any crash/kill supervisor restart) — pure noise.
                    # Routine reclaim (previous heartbeat recent — a normal
                    # supervised restart) logs at DEBUG; only a genuine
                    # outage signature (heartbeat silent > 600s) keeps INFO.
                    _v9907_routine_reclaim = (
                        0.0 <= _v808_prev_beat_age <= 600.0)
                    _v9907_rec_log = logger.debug if _v9907_routine_reclaim else logger.info
                    _v9907_rec_log(
                        "STARTUP_RECOVERY prev_pid=%s prev_exit=unknown "
                        "uptime_prev=%ss heartbeat_silent_for=%.0fs "
                        "supervisor=%s — exit code lives in the supervisor "
                        "journal (86 = canary wedge; 0 = clean) (v98.08 "
                        "FIX-XX: the 24/7 gap — install deploy/mediagrab.service "
                        "for restart < 60s; v99.07 FIX-21 routine_reclaim=%s)",
                        prev_pid, _v808_prev_uptime, _v808_prev_beat_age,
                        _v808_supervisor, _v9907_routine_reclaim)
                    _v9907_rec_log(
                        "BOT_SUPERVISOR_DETECTED supervisor=%s "
                        "restart_policy=%s (v98.08 FIX-XX)",
                        _v808_supervisor,
                        "Restart=always,10s" if _v808_supervisor.startswith("systemd")
                        else "manual — bot is NOT supervised, install "
                        "deploy/mediagrab.service")
                    # v98.09 ARCH (§28): expose the supervisor detection to
                    # the startup config validator (canary-exit-without-
                    # supervisor = the 2026-09-01 dark-restart mode).
                    try:
                        setattr(config, "_vc_arch_supervisor_detected",
                                _v808_supervisor.startswith("systemd"))
                    except Exception:  # noqa: BLE001
                        pass
                except Exception:  # noqa: BLE001
                    pass
                # v99.07 FIX-21: routine reclaim demoted to DEBUG (see the
                # STARTUP_RECOVERY note above); the ownership marker below
                # remains the INFO-level record of the transition.
                _v9907_rec_log(
                    "Stale PID file found (prev_pid=%s not alive) — reclaiming.",
                    prev_pid,
                )
                # v98.12-FINAL2 §13 (single-instance ownership marker): the
                # stale lock is reclaimed by THIS process — exactly one live
                # owner after this point.
                logger.info(
                    "VC_PROCESS_OWNERSHIP_ACQUIRED pid=%s prev_pid=%s "
                    "stale_lock=reclaimed single_instance=yes "
                    "(v98.12-FINAL2 §13)",
                    os.getpid(), prev_pid,
                )
        # v97.92: atomic write via tempfile + os.replace so two processes
        # starting near-simultaneously can't both win the race.
        _V85_PID_FILE.parent.mkdir(parents=True, exist_ok=True)
        import tempfile as _tempfile_mod
        _tmp_fd, _tmp_path = _tempfile_mod.mkstemp(
            dir=str(_V85_PID_FILE.parent), prefix=".v85_pid_", suffix=".tmp"
        )
        try:
            with os.fdopen(_tmp_fd, "w") as _f:
                _f.write(str(os.getpid()))
            os.replace(_tmp_path, _V85_PID_FILE)
        except OSError:
            # Fallback: direct write (preserves v97.91 behavior).
            try:
                os.unlink(_tmp_path)
            except OSError:
                pass
            _V85_PID_FILE.write_text(str(os.getpid()))
    except Exception as exc:  # noqa: BLE001
        logger.warning("V85 PID-file guard failed (non-fatal): %s", exc)

    # V85 §2: emit update mode + version banner.
    try:
        _update_mode_v85 = "WEBHOOK" if (config.use_webhook and config.webhook_url) else "POLLING"
        logger.info(
            "V85_STARTUP mode=%s file=%s pid=%d",
            _update_mode_v85, os.path.abspath(__file__), os.getpid(),
        )
        v85_diag("V85_STARTUP", mode=_update_mode_v85, pid=os.getpid())
    except Exception:  # noqa: BLE001
        pass

    # v97: enable faulthandler for thread dumps on freeze.
    # Send SIGUSR1 to the bot process to dump all thread stacks:
    #   kill -USR1 <python_pid>
    try:
        # v99.07 FIX-20: faulthandler is imported at module top (v98.07
        # FIX-SS) — the duplicate function-local import is removed.
        import signal as _sig
        faulthandler.enable()
        faulthandler.register(_sig.SIGUSR1)
        logger.info("FAULTHANDLER enabled — send SIGUSR1 (kill -USR1 %d) for thread dump", os.getpid())
    except Exception as exc:  # noqa: BLE001
        logger.warning("faulthandler enable failed (non-fatal): %s", exc)

    # P2 #17 fix: startup version/source identity logging.  The previous
    # runtime log showed tracebacks referencing "botv18.py" while the
    # deployed process was actually V20 — making it ambiguous which code
    # was running.  Now log the source file path, a build tag, git commit
    # (if available via env), and key feature flags so the log self-documents
    # exactly what is running.
    import os as _os
    _source_path = _os.path.abspath(__file__)
    # v98.08 FIX-BBB (F7', RUNTIME-PROVEN: L9 printed the stale literal
    # "build=v85" while L3's DEPLOYMENT_IDENTITY said version=v98.07 —
    # two version claims, one of them wrong). The build label now falls
    # back to the DEPLOYMENT version (mediagrab package __bot_version__)
    # instead of a frozen "v85" literal; env override still wins.
    try:
        from . import __bot_version__ as _pkg_version
    except Exception:  # noqa: BLE001
        _pkg_version = "unknown"
    _build_version = _os.environ.get(
        "BOT_BUILD_VERSION", str(_pkg_version))
    _git_commit = _os.environ.get("GIT_COMMIT", "unknown")
    logger.info(
        "BOT_VERSION identity: file=%s build=%s git=%s python=%s",
        _source_path, _build_version, _git_commit,
        _os.environ.get("PYTHON_VERSION", ""),
    )
    logger.info(
        "BOT_FEATURE_FLAGS vc_tour=%s vc_watcher_interval=%s vc_multi_max=%s "
        "vc_discovery_enabled=%s vc_discovery_interval=%s "
        "vc_auto_join_after_discovery=%s vc_discovery_mode=%s "
        "vc_discovery_default_queries=%s mtproto=%s",
        config.vc_tour_enabled, config.vc_watcher_interval,
        config.vc_multi_max_targets, config.vc_discovery_enabled,
        config.vc_discovery_interval, config.vc_auto_join_after_discovery,
        config.vc_discovery_mode,
        len(_vc_discovery_builtin_defaults()),
        config.mtproto_configured,
    )
    # v99.06 FIX-3b (config): the one-group-one-account invariant is ON by
    # default; an operator who disables it via VC_JOIN_ONE_GROUP_ONE_ACCOUNT
    # =false MUST see a boot-time WARNING (the spec: operators see it).
    try:
        _v9906_inv_raw = str(_os.environ.get(
            "VC_JOIN_ONE_GROUP_ONE_ACCOUNT", "") or "").strip().lower()
        if _v9906_inv_raw in ("0", "false", "no", "off"):
            logger.warning(
                "VC_INVARIANT_DISABLED one_group_one_account=false — "
                "two accounts MAY join the same group (double-join risk; "
                "v99.06 FIX-3b operator opt-out)"
            )
    except Exception:  # noqa: BLE001
        pass
    logger.info(
        "Limits: download=%dMB, upload=%dMB, concurrent=%d, retries=%d, "
        "frames=%d, inline=%s, webhook=%s",
        config.max_file_size_mb,
        config.upload_limit_bytes // (1024 * 1024),
        config.max_concurrent_downloads, config.max_retries, config.num_frames,
        config.inline_enabled, config.use_webhook,
    )

    app = build_application()

    # V50 Fix: do NOT create a separate event loop for signal handlers.
    # PTB's run_polling()/run_webhook() creates and manages its own loop.
    # A manually created loop would be unused, never closed, and signal
    # handlers attached to it would never fire. Use OS-level signal.signal()
    # instead, which doesn't need an event loop.
    import signal as _signal_mod
    for sig in (_signal_mod.SIGINT, _signal_mod.SIGTERM):
        try:
            _signal_mod.signal(sig, lambda s, f: app.stop_running())
        except (ValueError, OSError):
            pass  # not in main thread

    try:
        if config.use_webhook and config.webhook_url:
            # V85 §2: WEBHOOK mode — polling MUST be disabled. The else
            # branch is the only other path, so exactly one mode runs.
            logger.info("Starting in WEBHOOK mode at %s:%d%s "
                        "(polling DISABLED — exactly one update mode active)",
                        config.webhook_listen, config.webhook_port,
                        config.webhook_path)
            v85_diag("UPDATE_MODE", mode="WEBHOOK", polling=False)
            # SEC-I-002: Telegram sends X-Telegram-Bot-Api-Secret-Token
            # header on every webhook update; PTB rejects requests that
            # do not match this token. Prefer a config-defined secret,
            # fall back to the WEBHOOK_SECRET_TOKEN env var.
            # v99.07 FIX-23 (P1): the old final fallback left
            # secret_token=None — PTB then accepted updates with NO
            # secret verification. When neither source is configured,
            # a per-boot random secret is generated (PTB re-registers
            # the webhook with it at startup, so Telegram sends it on
            # every update) + a loud WARNING tells the operator to pin
            # WEBHOOK_SECRET_TOKEN for cross-restart stability.
            # Verification is never silently disabled.
            _v9907_secret = (
                getattr(config, "webhook_secret_token", "")
                or os.environ.get("WEBHOOK_SECRET_TOKEN", "")
                or ""
            )
            if not _v9907_secret:
                import secrets as _v9907_secrets
                _v9907_secret = _v9907_secrets.token_urlsafe(32)
                logger.warning(
                    "WEBHOOK_SECRET_MISSING — neither config "
                    "webhook_secret_token nor WEBHOOK_SECRET_TOKEN is "
                    "set; a random per-boot secret was generated "
                    "(secret verification is NEVER disabled; pin "
                    "WEBHOOK_SECRET_TOKEN for cross-restart stability; "
                    "v99.07 FIX-23)"
                )
            app.run_webhook(
                listen=config.webhook_listen,
                port=config.webhook_port,
                url_path=config.webhook_path,
                webhook_url=config.webhook_url + config.webhook_path,
                allowed_updates=Update.ALL_TYPES,
                secret_token=_v9907_secret,
            )
        else:
            # V85 §2: POLLING mode — webhook MUST be disabled.
            logger.info("Starting in POLLING mode "
                        "(webhook DISABLED — exactly one update mode active)")
            v85_diag("UPDATE_MODE", mode="POLLING", webhook=False)
            app.run_polling(allowed_updates=Update.ALL_TYPES)
    except KeyboardInterrupt:
        logger.info("Interrupted by user.")
    finally:
        # V85 §3: release the cross-process PID guard.
        # RELI-J-001: only unlink if the file still contains THIS process's
        # PID — another instance may have already taken ownership and we
        # must not delete its lock file.
        try:
            if _V85_PID_FILE.exists():
                try:
                    stored_pid = int(_V85_PID_FILE.read_text().strip())
                except (ValueError, OSError):
                    stored_pid = 0
                if stored_pid == os.getpid():
                    _V85_PID_FILE.unlink()
                else:
                    logger.info(
                        "PID file kept (owned by pid=%s, current pid=%d) — "
                        "another instance is live.", stored_pid, os.getpid(),
                    )
        except Exception:  # noqa: BLE001
            pass
        # V96: log shutdown phase timing summary.
        try:
            _shut_summary = RuntimeControllerV96.shutdown_summary()
            if _shut_summary["phases"]:
                logger.info(
                    "SHUTDOWN_PHASES summary phases=%s",
                    json.dumps(_shut_summary["phases"]),
                )
        except Exception:  # noqa: BLE001
            pass
        logger.info("=== MediaGrab AI Bot stopped ===")


if __name__ == "__main__":
    main()
