"""Frame extractor — extracted from _bot_core.py.

Extracts evenly-spaced frames from video files using ffmpeg.
Depends on: subprocess, pathlib, logging.
"""

from __future__ import annotations

import asyncio
import logging
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Optional

import httpx
from telegram import Update
from telegram.ext import ContextTypes

from .config import config
from .utils_real import remove_path, unique_path, get_bot, _sanitize_error
from .ui_keyboards import witai_settings_menu

logger = logging.getLogger("mediagrab")

# FFmpeg / ffprobe binary paths (lazy detection).
_FFMPEG = None
_FFPROBE = None

_FFMPEG = shutil.which("ffmpeg") or "ffmpeg"
_FFPROBE = shutil.which("ffprobe") or "ffprobe"


class FrameExtractionError(Exception):
    pass


async def extract_frames(
    video_path: Path,
    *,
    num_frames: Optional[int] = None,
    out_dir: Optional[Path] = None,
    fmt: str = "png",
    timeout: int = 300,
) -> list[Path]:
    """Extract ``num_frames`` evenly-spaced frames from *video_path*."""
    n = num_frames or config.num_frames
    n = max(1, min(n, 12))
    video_path = Path(video_path)
    if not video_path.exists():
        raise FrameExtractionError(f"Video not found: {video_path}")

    out_dir = Path(out_dir) if out_dir else config.frames_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    duration = await _probe_duration(video_path)
    if not duration or duration < 0.1:
        raise FrameExtractionError("Could not determine video duration.")

    timestamps = _even_timestamps(duration, n)
    frames: list[Path] = []
    tasks: list[asyncio.Task] = []
    try:
        # ASYNC-C-005/006: wrap coroutines in Tasks explicitly so we can
        # cancel any that are still pending if extraction as a whole fails.
        tasks = [
            asyncio.ensure_future(_extract_at(video_path, ts, out_dir, i, fmt, timeout))
            for i, ts in enumerate(timestamps)
        ]
        for coro in asyncio.as_completed(tasks):
            frame = await coro
            if frame:
                frames.append(frame)
        frames.sort()
        if not frames:
            raise FrameExtractionError("No frames were extracted.")
        logger.info("Extracted %d/%d frames from %s", len(frames), n, video_path.name)
        return frames
    except Exception:
        # ASYNC-C-005: cancel any still-pending extraction tasks so they
        # don't keep running (and writing files) after we've aborted.
        for t in tasks:
            if not t.done():
                t.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        for f in frames:
            await remove_path(f)
        raise


async def _extract_at(
    video_path: Path, ts: float, out_dir: Path, index: int,
    fmt: str, timeout: int,
) -> Optional[Path]:
    """Extract a single frame at timestamp ``ts`` (seconds)."""
    name = f"{video_path.stem}_f{index:02d}_{int(ts):06d}.{fmt}"
    out = unique_path(out_dir, name)
    cmd = [
        _FFMPEG, "-y", "-loglevel", "error",
        "-ss", f"{ts:.3f}", "-i", str(video_path),
        "-frames:v", "1", "-q:v", "2",
        str(out),
    ]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            logger.warning("ffmpeg timeout at ts=%.1f for %s", ts, video_path.name)
            await remove_path(out)
            return None
        if proc.returncode != 0:
            err = stderr.decode(errors="replace")[:200] if stderr else ""
            logger.warning("ffmpeg failed at ts=%.1f: %s", ts, err)
            await remove_path(out)
            return None
        if not out.exists() or out.stat().st_size == 0:
            await remove_path(out)
            return None
        return out
    except FileNotFoundError as exc:
        raise FrameExtractionError("ffmpeg is not installed") from exc


async def _probe_duration(video_path: Path) -> float:
    """Get duration in seconds via ffprobe."""
    cmd = [
        _FFPROBE, "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(video_path),
    ]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=60)
    except (FileNotFoundError, asyncio.TimeoutError) as exc:
        # v99.02 FIX-7c (RC-7): kill + reap the timed-out ffprobe child so
        # the process + pipe FDs don't linger (same class as media_tools).
        try:
            proc.kill()  # type: ignore[union-attr]
            await proc.communicate()  # type: ignore[union-attr]
        except Exception:  # noqa: BLE001
            pass
        logger.warning("ffprobe failed: %s — falling back to ffmpeg parse", exc)
        return await _duration_via_ffmpeg(video_path)
    text = stdout.decode(errors="replace").strip()
    m = re.search(r"[-+]?\d*\.?\d+", text)
    return float(m.group()) if m else 0.0


async def _duration_via_ffmpeg(video_path: Path) -> float:
    """Fallback duration detection by parsing ffmpeg stderr."""
    cmd = [_FFMPEG, "-i", str(video_path)]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=60)
    except (FileNotFoundError, asyncio.TimeoutError):
        # v99.02 FIX-7c (RC-7): kill + reap the timed-out ffmpeg child.
        try:
            proc.kill()  # type: ignore[union-attr]
            await proc.communicate()  # type: ignore[union-attr]
        except Exception:  # noqa: BLE001
            pass
        return 0.0
    text = stderr.decode(errors="replace")
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", text)
    if not m:
        return 0.0
    h, mi, s = int(m.group(1)), int(m.group(2)), float(m.group(3))
    return h * 3600 + mi * 60 + s


def _even_timestamps(duration: float, n: int) -> list[float]:
    """Evenly spaced timestamps, avoiding the very first/last frames."""
    if n == 1:
        return [duration / 2]
    step = duration / (n + 1)
    return [round(step * (i + 1), 3) for i in range(n)]


# ════════════════════════════════════════════════════════════════════════════
# Services — Wit.ai (V86 multimodal upgrade)
# ════════════════════════════════════════════════════════════════════════════
"""Wit.ai integration for STT, intent detection, entity extraction, and language detection.

Optional: only active when config.witai_enabled is True and WITAI_SERVER_TOKEN is set.
All methods are async, non-blocking, and gracefully degrade (return None/empty on failure).
"""


class WitaiService:
    """Async Wit.ai client. Singleton-style — instantiated once at module level."""

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None
        self._lock = asyncio.Lock()
        self._cached_token: str = ""  # V87: track the token the client was built with

    def _ensure_client(self) -> httpx.AsyncClient:
        current_token = config.witai_server_token or ""
        # V87: rebuild client if token changed (runtime token replacement).
        if self._client is not None and not self._client.is_closed and self._cached_token != current_token:
            logger.info("WITAI_CLIENT_REBUILD reason=token_changed")
            try:
                # Close old client asynchronously — but _ensure_client is sync,
                # so we schedule the close and create a new client immediately.
                # v97.44 FIX: use supervised_create_task (was bare loop.create_task)
                # so exceptions are retrieved (no "Future exception was never retrieved").
                old_client = self._client
                self._client = None
                try:
                    from .utils_real import supervised_create_task
                    supervised_create_task(
                        old_client.aclose(), name="frame_extractor_client_close"
                    )
                except Exception:
                    pass
            except Exception:
                pass
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(connect=15.0, read=120.0, write=60.0, pool=30.0),
                headers={"Authorization": f"Bearer {current_token}",
                         "Accept": "application/json"},
                limits=httpx.Limits(max_connections=5, max_keepalive_connections=2),
            )
            self._cached_token = current_token
        return self._client

    async def invalidate_client(self) -> None:
        """V87: Force the HTTP client to be rebuilt on next use.

        Called when the Wit.ai token is changed at runtime.
        """
        if self._client is not None and not self._client.is_closed:
            try:
                await self._client.aclose()
            except Exception:
                pass
        self._client = None
        self._cached_token = ""
        logger.info("WITAI_CLIENT_INVALIDATED")

    @property
    def available(self) -> bool:
        return bool(config.witai_enabled and config.witai_server_token)

    async def speech_to_text(self, audio_path: Path, *, language: str = "auto") -> dict[str, Any]:
        """Transcribe an audio file via Wit.ai /speech endpoint.
        Returns {"text": str, "language": str, "confidence": float, "entities": list, "intents": list} or {"text": "", ...} on failure.
        """
        from .multimodal import _ffprobe_duration  # lazy: avoids frame_extractor -> multimodal cycle
        if not self.available:
            return {"text": "", "language": language, "confidence": 0.0, "entities": [], "intents": []}
        # V86.1 (D4): Telegram voice messages are OGG Opus, which Wit.ai's
        # /speech endpoint does not accept. Convert to WAV (16kHz mono 16-bit)
        # first; the original file is left untouched and the temp WAV is
        # cleaned up in the ``finally`` block below.
        witai_path = await self._convert_for_witai(audio_path)
        try:
            client = self._ensure_client()
            # V87: use the AUDIO size limit (not image) and enforce duration.
            st = witai_path.stat()
            if st.st_size > config.multimodal_max_audio_bytes:
                return {"text": "", "error": f"audio_too_large ({st.st_size} > {config.multimodal_max_audio_bytes} bytes)"}
            # V87.1: measure actual audio duration via ffprobe (the Path object
            # does NOT have a duration_seconds attribute — the previous
            # getattr(audio_path, 'duration_seconds', 0) was dead code that
            # always returned 0). Use the existing _ffprobe_duration helper
            # which runs ffprobe with a 15s timeout and returns None on failure.
            measured_duration = await _ffprobe_duration(str(witai_path))
            if measured_duration is not None:
                if measured_duration > config.multimodal_max_audio_seconds:
                    return {"text": "", "error": f"audio_too_long ({measured_duration:.0f}s > {config.multimodal_max_audio_seconds}s)"}
            else:
                # ffprobe unavailable or failed — log and continue (the
                # router-level check already validated duration from Telegram
                # metadata, so this is a defense-in-depth check that we
                # can't enforce without ffprobe).
                logger.debug("WITAI_DURATION_CHECK_SKIPPED reason=ffprobe_unavailable path=%s", witai_path)
            # V86.1 (D4): send WAV with audio/wav; fall back to audio/mpeg for
            # any non-WAV input that survived the conversion step (e.g. ffmpeg
            # unavailable — we then send the original OGG as audio/mpeg which
            # is the legacy behaviour).
            content_type = "audio/wav" if witai_path.suffix.lower() == ".wav" else "audio/mpeg"
            with open(witai_path, "rb") as fh:
                resp = await client.post(
                    f"{config.witai_api_url}/speech?v=20240304",
                    content=fh.read(),
                    headers={"Content-Type": content_type,
                             "Authorization": f"Bearer {config.witai_server_token}"},
                )
            if resp.status_code != 200:
                logger.warning("WITAI_STT_FAILED status=%s body=%s ct=%s", resp.status_code, resp.text[:200], content_type)
                return {"text": "", "error": f"http_{resp.status_code}"}
            data = resp.json()
            text = data.get("text", "") or ""
            # Wit.ai returns entities and intents at top level
            entities = data.get("entities", {}) or {}
            intents = data.get("intents", []) or []
            traits = data.get("traits", {}) or {}
            # Flatten entities: {slot_name: [{value, confidence, ...}]}
            flat_entities = []
            for slot, vals in entities.items():
                for v in (vals or []):
                    flat_entities.append({"slot": slot, "value": v.get("value", ""), "confidence": v.get("confidence", 0)})
            intent_list = [{"name": i.get("name", ""), "confidence": i.get("confidence", 0)} for i in (intents or [])]
            return {
                "text": text,
                "language": data.get("detected_language", language) or language,
                "confidence": data.get("speech", {}).get("confidence", 0.0) if isinstance(data.get("speech"), dict) else 0.0,
                "entities": flat_entities,
                "intents": intent_list,
                "traits": traits,
            }
        except Exception as exc:
            logger.warning("WITAI_STT_ERROR exc=%s: %s", type(exc).__name__, str(exc)[:200])
            return {"text": "", "error": str(exc)[:120]}
        finally:
            # Clean up the converted temp file if it's different from the original.
            if witai_path != audio_path and witai_path.exists():
                try:
                    witai_path.unlink()
                except OSError:
                    pass

    async def _convert_for_witai(self, audio_path: Path) -> Path:
        """Convert audio to a Wit.ai-compatible format (WAV 16kHz mono 16-bit).

        Telegram voice messages are OGG Opus; Wit.ai's /speech endpoint works
        best with WAV. This uses ffmpeg to convert. If ffmpeg is unavailable or
        the file is already WAV, returns the original path unchanged.
        """
        suffix = audio_path.suffix.lower()
        if suffix in (".wav",):
            return audio_path  # already WAV — no conversion needed
        # Reuse the module-level ffmpeg path resolved at import time (line 5044).
        ffmpeg = _FFMPEG
        if not shutil.which(ffmpeg):
            logger.warning("WITAI_NO_FFMPEG — sending raw audio as-is (may fail for OGG Opus)")
            return audio_path
        # Convert to WAV 16kHz mono 16-bit (PCM s16le) — Wit.ai's preferred format.
        tmp_wav = audio_path.with_suffix(audio_path.suffix + ".witai.wav")
        try:
            proc = await asyncio.create_subprocess_exec(
                ffmpeg, "-y", "-loglevel", "error",
                "-i", str(audio_path),
                "-ar", "16000", "-ac", "1", "-acodec", "pcm_s16le",
                str(tmp_wav),
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                _, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.communicate()
                logger.warning("WITAI_FFMPEG_TIMEOUT — sending raw audio as-is")
                try:
                    tmp_wav.unlink()
                except OSError:
                    pass
                return audio_path
            if proc.returncode != 0:
                logger.warning("WITAI_FFMPEG_FAILED rc=%s stderr=%s",
                               proc.returncode, stderr.decode(errors="replace")[:200] if stderr else "")
                try:
                    tmp_wav.unlink()
                except OSError:
                    pass
                return audio_path  # fall back to original
            return tmp_wav
        except Exception as exc:  # noqa: BLE001
            logger.warning("WITAI_CONVERT_ERROR exc=%s", str(exc)[:200])
            try:
                tmp_wav.unlink()
            except OSError:
                pass
            return audio_path

    async def message_understanding(self, text: str) -> dict[str, Any]:
        """Intent + entity extraction via Wit.ai /message endpoint.
        Returns {"intents": [...], "entities": [...], "traits": {...}, "language": str} or empty on failure.
        """
        if not self.available:
            return {"intents": [], "entities": [], "traits": {}, "language": "auto"}
        try:
            client = self._ensure_client()
            resp = await client.get(
                f"{config.witai_api_url}/message?v=20240304",
                params={"q": text[:280]},
            )
            if resp.status_code != 200:
                logger.warning("WITAI_MSG_FAILED status=%s", resp.status_code)
                return {"intents": [], "entities": [], "traits": {}, "language": "auto"}
            data = resp.json()
            entities = data.get("entities", {}) or {}
            intents = data.get("intents", []) or []
            traits = data.get("traits", {}) or {}
            flat_entities = []
            for slot, vals in entities.items():
                for v in (vals or []):
                    flat_entities.append({"slot": slot, "value": v.get("value", ""), "confidence": v.get("confidence", 0)})
            intent_list = [{"name": i.get("name", ""), "confidence": i.get("confidence", 0)} for i in (intents or [])]
            return {
                "intents": intent_list,
                "entities": flat_entities,
                "traits": traits,
                "language": data.get("detected_language", "auto") or "auto",
            }
        except Exception as exc:
            logger.warning("WITAI_MSG_ERROR exc=%s: %s", type(exc).__name__, str(exc)[:200])
            return {"intents": [], "entities": [], "traits": {}, "language": "auto"}

    async def detect_language(self, text: str) -> str:
        """Use Wit.ai to detect language. Returns ISO code or 'auto'."""
        if not self.available:
            return "auto"
        result = await self.message_understanding(text)
        lang = result.get("language", "auto")
        return lang or "auto"

    async def close(self) -> None:
        if self._client is not None and not self._client.is_closed:
            try:
                await self._client.aclose()
            except Exception:
                pass
        self._client = None


# Module-level singleton.
witai_service = WitaiService()


async def _witai_voice_check_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """V86.4: Handler for the Voice Pipeline Check button."""
    chat_id = update.effective_chat.id
    msg_id = update.callback_query.message.message_id
    try:
        await context.bot.edit_message_text(
            chat_id=chat_id, message_id=msg_id,
            text="🎤 *Voice Pipeline Check*\n\n_Running diagnostics... this may take 10-30 seconds._",
            parse_mode="Markdown",
        )
        report = await _voice_pipeline_check()
        text = _voice_pipeline_check_text(report)
        await context.bot.edit_message_text(
            chat_id=chat_id, message_id=msg_id,
            text=text[:4096],
            reply_markup=witai_settings_menu(),
            parse_mode="Markdown",
        )
    except Exception as exc:
        logger.warning("WITAI_VOICE_CHECK_ERROR exc=%s", exc)
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id, message_id=msg_id,
                text=f"❌ Voice pipeline check failed: `{type(exc).__name__}: {str(exc)[:120]}`",
                reply_markup=witai_settings_menu(),
                parse_mode="Markdown",
            )
        except Exception:
            pass


async def _witai_test_connection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Test the Wit.ai connection by sending a simple message-understanding request."""
    chat_id = update.effective_chat.id
    msg_id = update.callback_query.message.message_id
    try:
        if not getattr(config, "witai_enabled", False):
            await context.bot.edit_message_text(
                chat_id=chat_id, message_id=msg_id,
                text="❌ Wit.ai is disabled. Enable it first.",
                reply_markup=witai_settings_menu(),
                parse_mode="Markdown",
            )
            return
        token = getattr(config, "witai_server_token", "")
        if not token.strip():
            await context.bot.edit_message_text(
                chat_id=chat_id, message_id=msg_id,
                text="❌ No Wit.ai server token set. Set one first.",
                reply_markup=witai_settings_menu(),
                parse_mode="Markdown",
            )
            return
        await context.bot.edit_message_text(
            chat_id=chat_id, message_id=msg_id,
            text="🧪 Testing Wit.ai connection...\n\n_Sending test query: \"hello world\"_",
            parse_mode="Markdown",
        )
        result = await witai_service.message_understanding("hello world")
        intents = result.get("intents", [])
        language = result.get("language", "auto")
        if intents:
            intent_lines = ', '.join(
                f"`{i['name']}` ({i['confidence']:.2f})" for i in intents[:3]
            )
            text = (
                "✅ *Wit.ai connection successful!*\n\n"
                f"• Test query: `hello world`\n"
                f"• Detected language: `{language}`\n"
                f"• Intents: {intent_lines}\n"
                f"• Entities: {len(result.get('entities', []))}\n"
            )
        else:
            text = (
                "✅ *Wit.ai connection OK* (no intents detected for test query)\n\n"
                f"• Detected language: `{language}`\n"
                f"• Response received (HTTP 200)\n"
                "_This is normal — 'hello world' may not match any trained intents._"
            )
        await context.bot.edit_message_text(
            chat_id=chat_id, message_id=msg_id,
            text=text,
            reply_markup=witai_settings_menu(),
            parse_mode="Markdown",
        )
    except Exception as exc:
        safe_err = _sanitize_error(f"Wit.ai test failed: {exc}")
        logger.warning("WITAI_TEST_FAILED admin=%s exc=%s", update.effective_user.id, safe_err)
        await context.bot.edit_message_text(
            chat_id=chat_id, message_id=msg_id,
            text=f"❌ *Wit.ai test failed*\n\n`{safe_err[:200]}`",
            reply_markup=witai_settings_menu(),
            parse_mode="Markdown",
        )


def _witai_diagnostics_text() -> str:
    """Build a diagnostics text for the Wit.ai settings menu."""
    enabled = getattr(config, "witai_enabled", False)
    token_set = bool((getattr(config, "witai_server_token", "") or "").strip())
    available = bool(witai_service.available) if hasattr(witai_service, "available") else False
    vp = getattr(config, "voice_provider", "auto")
    ip = getattr(config, "intent_provider", "auto")
    api_url = getattr(config, "witai_api_url", "https://api.wit.ai")
    lines = [
        "📊 *Wit.ai Diagnostics*",
        "",
        "*Configuration:*",
        f"• witai_enabled: `{enabled}`",
        f"• token_set: `{'✅' if token_set else '❌'}`",
        f"• service_available: `{'✅' if available else '❌'}`",
        f"• voice_provider: `{vp}`",
        f"• intent_provider: `{ip}`",
        f"• api_url: `{api_url}`",
        "",
        "*Routing:*",
    ]
    if available:
        lines.append("• STT: Wit.ai will be tried first for voice/audio messages")
        lines.append("• Intent: Wit.ai will be tried first for text intent detection")
    else:
        lines.append("• STT: Gemini/Groq fallback (Wit.ai not available)")
        lines.append("• Intent: Local keyword fallback (Wit.ai not available)")
    lines.append("")
    lines.append("*OGG Conversion:*")
    ffmpeg_path = shutil.which("ffmpeg") or "ffmpeg"
    lines.append(f"• ffmpeg: `{ffmpeg_path}` (`{'✅ found' if shutil.which('ffmpeg') else '❌ not found'}`)")
    lines.append("")
    lines.append("_Wit.ai requires ffmpeg to convert Telegram OGG Opus voice → WAV._")
    return "\n".join(lines)


async def _voice_pipeline_check() -> dict[str, Any]:
    """V86.4: Voice Pipeline Check — runs a full end-to-end diagnostics of
    the voice message pipeline and returns a structured report.

    Checks every stage:
      1. Telegram Voice Download (bot.get_file)
      2. ffmpeg installed
      3. ffmpeg OGG→WAV conversion
      4. Audio validation (ffprobe)
      5. WAV file properties (duration, channels, sample rate)
      6. STT provider selection
      7. Wit.ai API availability
      8. Wit.ai transcript (if available)
      9. Intent detection
     10. Current AI provider
     11. AI reply generation
     12. TTS provider
     13. Voice reply generation

    Returns a dict with per-stage results + overall health.
    """
    # Lazy imports: multimodal + talkative functions live in other subsystems;
    # importing at module level would create a frame_extractor -> multimodal/talkative cycle.
    from .multimodal import _multimodal_pick_stt_provider, _multimodal_detect_intent
    from .talkative import talkative_effective_provider
    from .talkative_hooks import talkative_generate
    import time as _time
    report: dict[str, Any] = {
        "stages": [],
        "overall_pass": True,
        "total_latency_ms": 0,
    }
    overall_start = _time.monotonic()

    def _stage(name: str, status: str, elapsed_ms: int, detail: str = "", exc: str = "") -> None:
        report["stages"].append({
            "stage": name, "status": status,
            "elapsed_ms": elapsed_ms,
            "detail": detail, "exception": exc,
        })
        if status == "FAIL":
            report["overall_pass"] = False

    # Stage 1: Telegram Voice Download (check bot is registered).
    t0 = _time.monotonic()
    try:
        bot = get_bot()
        if bot is None:
            _stage("Telegram Bot", "FAIL", int((_time.monotonic() - t0) * 1000),
                   exc="Bot not registered")
        else:
            me = await bot.get_me()
            _stage("Telegram Bot", "PASS", int((_time.monotonic() - t0) * 1000),
                   detail=f"@{me.username}")
    except Exception as exc:
        _stage("Telegram Bot", "FAIL", int((_time.monotonic() - t0) * 1000),
               exc=f"{type(exc).__name__}: {str(exc)[:80]}")

    # Stage 2: ffmpeg installed.
    t0 = _time.monotonic()
    ffmpeg_path = shutil.which("ffmpeg")
    if ffmpeg_path:
        _stage("ffmpeg Installed", "PASS", int((_time.monotonic() - t0) * 1000),
               detail=ffmpeg_path)
    else:
        _stage("ffmpeg Installed", "FAIL", int((_time.monotonic() - t0) * 1000),
               exc="ffmpeg not found on PATH")

    # Stage 3: ffmpeg conversion test (create a tiny silent WAV from nothing).
    t0 = _time.monotonic()
    if ffmpeg_path:
        try:
            import tempfile as _tmp
            tmp_in = _tmp.mktemp(suffix=".ogg")
            tmp_out = _tmp.mktemp(suffix=".wav")
            # Generate a 0.1s silent OGG (as a proxy for Telegram voice).
            proc = await asyncio.create_subprocess_exec(
                ffmpeg_path, "-y", "-loglevel", "error",
                "-f", "lavfi", "-i", "anullsrc=r=48000:cl=mono",
                "-t", "0.1", "-acodec", "libopus", tmp_in,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )
            await asyncio.wait_for(proc.communicate(), timeout=10)
            # Convert OGG → WAV.
            proc2 = await asyncio.create_subprocess_exec(
                ffmpeg_path, "-y", "-loglevel", "error",
                "-i", tmp_in,
                "-ar", "16000", "-ac", "1", "-acodec", "pcm_s16le",
                tmp_out,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )
            await asyncio.wait_for(proc2.communicate(), timeout=10)
            wav_path = Path(tmp_out)
            if wav_path.exists() and wav_path.stat().st_size > 0:
                _stage("ffmpeg Conversion", "PASS", int((_time.monotonic() - t0) * 1000),
                       detail=f"OGG→WAV OK ({wav_path.stat().st_size} bytes)")
            else:
                _stage("ffmpeg Conversion", "FAIL", int((_time.monotonic() - t0) * 1000),
                       exc="WAV output file is empty or missing")
            # Cleanup.
            try: Path(tmp_in).unlink()
            except OSError: pass
            try: wav_path.unlink()
            except OSError: pass
        except Exception as exc:
            _stage("ffmpeg Conversion", "FAIL", int((_time.monotonic() - t0) * 1000),
                   exc=f"{type(exc).__name__}: {str(exc)[:80]}")
    else:
        _stage("ffmpeg Conversion", "SKIP", 0, detail="ffmpeg not installed")

    # Stage 4: ffprobe installed (audio validation).
    t0 = _time.monotonic()
    ffprobe_path = shutil.which("ffprobe")
    if ffprobe_path:
        _stage("Audio Validation (ffprobe)", "PASS", int((_time.monotonic() - t0) * 1000),
               detail=ffprobe_path)
    else:
        _stage("Audio Validation (ffprobe)", "FAIL", int((_time.monotonic() - t0) * 1000),
               exc="ffprobe not found on PATH")

    # Stage 5: WAV properties (informational — we can't test without a real file).
    _stage("WAV Properties", "INFO", 0,
           detail="Requires a real voice message to test (duration, channels, sample rate)")

    # Stage 6: STT provider selection.
    t0 = _time.monotonic()
    stt_provider = _multimodal_pick_stt_provider()
    _stage("STT Provider", "PASS" if stt_provider != "local" else "FAIL",
           int((_time.monotonic() - t0) * 1000),
           detail=f"Selected: {stt_provider}")

    # Stage 7: Wit.ai API availability.
    t0 = _time.monotonic()
    witai_avail = bool(witai_service.available) if hasattr(witai_service, "available") else False
    if witai_avail:
        _stage("Wit.ai API", "PASS", int((_time.monotonic() - t0) * 1000),
               detail="Token set + enabled")
    else:
        enabled = getattr(config, "witai_enabled", False)
        token_set = bool((getattr(config, "witai_server_token", "") or "").strip())
        reason = []
        if not enabled:
            reason.append("witai_enabled=False")
        if not token_set:
            reason.append("no token")
        _stage("Wit.ai API", "FAIL", int((_time.monotonic() - t0) * 1000),
               exc=", ".join(reason) if reason else "unknown")

    # Stage 8: Wit.ai transcript (test with a dummy text query).
    t0 = _time.monotonic()
    if witai_avail:
        try:
            result = await witai_service.message_understanding("hello")
            if result.get("intents") is not None:
                _stage("Wit.ai Transcript", "PASS", int((_time.monotonic() - t0) * 1000),
                       detail=f"API responded (intents: {len(result.get('intents', []))})")
            else:
                _stage("Wit.ai Transcript", "FAIL", int((_time.monotonic() - t0) * 1000),
                       exc="No intents field in response")
        except Exception as exc:
            _stage("Wit.ai Transcript", "FAIL", int((_time.monotonic() - t0) * 1000),
                   exc=f"{type(exc).__name__}: {str(exc)[:80]}")
    else:
        _stage("Wit.ai Transcript", "SKIP", 0, detail="Wit.ai not available")

    # Stage 9: Intent detection.
    t0 = _time.monotonic()
    try:
        intent_result = await _multimodal_detect_intent("hello")
        _stage("Intent Detection", "PASS", int((_time.monotonic() - t0) * 1000),
               detail=f"intent={intent_result.get('intent', '?')} conf={intent_result.get('confidence', 0):.2f}")
    except Exception as exc:
        _stage("Intent Detection", "FAIL", int((_time.monotonic() - t0) * 1000),
               exc=f"{type(exc).__name__}: {str(exc)[:80]}")

    # Stage 10: Current AI provider.
    t0 = _time.monotonic()
    try:
        eff_provider, _, _, _, _ = await talkative_effective_provider()
        if eff_provider:
            # Check if the provider has a key.
            key_attr = f"{eff_provider}_api_key"
            has_key = bool(getattr(config, key_attr, ""))
            _stage("AI Provider", "PASS" if has_key else "FAIL",
                   int((_time.monotonic() - t0) * 1000),
                   detail=f"Provider: {eff_provider} (key: {'✅' if has_key else '❌'})")
        else:
            _stage("AI Provider", "FAIL", int((_time.monotonic() - t0) * 1000),
                   exc="No provider available")
    except Exception as exc:
        _stage("AI Provider", "FAIL", int((_time.monotonic() - t0) * 1000),
               exc=f"{type(exc).__name__}: {str(exc)[:80]}")

    # Stage 11: AI reply generation (quick test).
    t0 = _time.monotonic()
    try:
        test_result = await talkative_generate(
            [{"role": "user", "content": "Say 'OK' in one word."}],
            "You are a test. Reply with exactly: OK",
            {"provider": "auto", "max_reply_chars": 50, "request_timeout": 15},
        )
        if test_result.success and test_result.text:
            _stage("AI Reply Generation", "PASS", int((_time.monotonic() - t0) * 1000),
                   detail=f"Provider: {test_result.provider}, reply: {test_result.text[:30]}")
        elif test_result.text:
            _stage("AI Reply Generation", "WARN", int((_time.monotonic() - t0) * 1000),
                   detail=f"Fallback: {test_result.text[:30]} (provider={test_result.provider})")
        else:
            _stage("AI Reply Generation", "FAIL", int((_time.monotonic() - t0) * 1000),
                   exc=f"No reply: {test_result.error[:80] if test_result.error else 'unknown'}")
    except Exception as exc:
        _stage("AI Reply Generation", "FAIL", int((_time.monotonic() - t0) * 1000),
               exc=f"{type(exc).__name__}: {str(exc)[:80]}")

    # Stage 12: TTS provider.
    t0 = _time.monotonic()
    groq_key = getattr(config, "groq_api_key", "")
    if groq_key:
        _stage("TTS Provider", "PASS", int((_time.monotonic() - t0) * 1000),
               detail="Groq playai-tts available")
    else:
        _stage("TTS Provider", "FAIL", int((_time.monotonic() - t0) * 1000),
               exc="No TTS provider (Groq key required for voice replies)")

    # Stage 13: Voice reply generation (informational — requires TTS).
    if groq_key and getattr(config, "voice_reply_enabled", False):
        _stage("Voice Reply Generation", "PASS", 0,
               detail="voice_reply_enabled=True + Groq key set")
    elif groq_key:
        _stage("Voice Reply Generation", "INFO", 0,
               detail="TTS available but voice_reply_enabled=False")
    else:
        _stage("Voice Reply Generation", "FAIL", 0,
               exc="No TTS provider configured")

    report["total_latency_ms"] = int((_time.monotonic() - overall_start) * 1000)
    return report


def _voice_pipeline_check_text(report: dict[str, Any]) -> str:
    """Format the voice pipeline check report as Markdown text."""
    lines = ["🎤 *Voice Pipeline Check*", ""]
    for stage in report.get("stages", []):
        icon = {"PASS": "✅", "FAIL": "❌", "WARN": "⚠️", "INFO": "ℹ️", "SKIP": "⏭️"}.get(stage["status"], "❓")
        name = stage["stage"]
        elapsed = stage["elapsed_ms"]
        detail = stage.get("detail", "")
        exc = stage.get("exception", "")
        line = f"{icon} *{name}* ({elapsed}ms)"
        if detail:
            line += f"\n   `{detail}`"
        if exc:
            line += f"\n   ❌ `{exc}`"
        lines.append(line)
    lines.append("")
    overall = "✅ ALL CHECKS PASSED" if report.get("overall_pass") else "❌ SOME CHECKS FAILED"
    lines.append(f"*Overall:* {overall}")
    lines.append(f"*Total latency:* `{report.get('total_latency_ms', 0)}ms`")
    return "\n".join(lines)
