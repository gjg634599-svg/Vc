"""QR code generator — extracted from _bot_core.py.

Generates high-resolution PNG QR codes using the qrcode library.
Depends on a unique_path function for generating unique file paths
(injected at import time to avoid circular dependencies).
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

import qrcode

logger = logging.getLogger("mediagrab")

# unique_path is injected from _bot_core to avoid circular import.
# It is set by _bot_core.py at import time.
_unique_path_fn = None


def _set_unique_path(fn):
    """Called by _bot_core.py to inject the unique_path function."""
    global _unique_path_fn
    _unique_path_fn = fn


def _unique_path(directory, filename: str):
    if _unique_path_fn is None:
        # Fallback: generate a simple unique name
        import time as _t
        stem = Path(filename).stem
        suffix = Path(filename).suffix
        return directory / f"{stem}_{int(_t.time() * 1000)}{suffix}"
    return _unique_path_fn(directory, filename)


class QRError(Exception):
    pass


async def generate_qr(text: str, out_dir: Path, *,
                      box_size: int = 10, border: int = 2) -> Path:
    """Render ``text`` as a high-resolution PNG qr code. Returns its path."""
    if not text or not text.strip():
        raise QRError("Cannot encode empty text.")
    if len(text) > 2900:
        raise QRError("Text too long for a QR code (max ~2900 chars).")

    out_dir.mkdir(parents=True, exist_ok=True)
    out = _unique_path(out_dir, "qr.png")

    def _do() -> None:
        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=box_size,
            border=border,
        )
        qr.add_data(text)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        img.save(out, format="PNG")

    try:
        await asyncio.to_thread(_do)
    except Exception as exc:  # noqa: BLE001
        raise QRError(f"QR generation failed: {exc}") from exc
    logger.info("QR generated for %d-char input -> %s", len(text), out.name)
    return out
