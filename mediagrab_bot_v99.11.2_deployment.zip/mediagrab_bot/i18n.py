"""Internationalisation — extracted from _bot_core.py.

Provides multi-language UI string translation for 7 languages:
English, Hindi, Spanish, French, Arabic, Chinese, Portuguese.

Pure data + functions, zero dependencies.
"""

from __future__ import annotations

from typing import Mapping

_EN: dict[str, str] = {
    "main_menu": "🏠 Main Menu\n\nChoose what you'd like to do:",
    "download": "📥 Download",
    "ai_analyze": "🎬 AI Analyze",
    "inspect": "🔍 Inspect Chat",
    "toolbox": "🧰 Media Toolbox",
    "library": "⭐ Library",
    "stats": "📊 Stats",
    "qr": "🔳 QR Code",
    "history": "📜 History",
    "settings": "⚙️ Settings",
    "help": "ℹ️ Help",
    "batch": "📦 Batch",
    "scheduled": "⏰ Scheduled",
    "admin": "🛡️ Admin",
    "backup": "💾 Backup",
    "back": "🔙 Back",
    "cancel": "❌ Cancel",
    "done": "✅ Done",
    "welcome": (
        "👋 Welcome to MediaGrab AI Bot\n\n"
        "Your all-in-one assistant for media downloading, AI analysis and more.\n\n"
        "Tap a button below to begin — no commands needed."
    ),
}

_HI: dict[str, str] = {
    "main_menu": "🏠 मुख्य मेनू\n\nआप क्या करना चाहते हैं चुनें:",
    "download": "📥 डाउनलोड",
    "ai_analyze": "🎬 एआई विश्लेषण",
    "back": "🔙 वापस",
    "cancel": "❌ रद्द करें",
    "done": "✅ पूर्ण",
    "welcome": "👋 MediaGrab AI Bot में आपका स्वागत है\n\nशुरू करने के लिए नीचे एक बटन टैप करें।",
}

_ES: dict[str, str] = {
    "main_menu": "🏠 Menú principal\n\nElige qué quieres hacer:",
    "download": "📥 Descargar",
    "back": "🔙 Atrás",
    "cancel": "❌ Cancelar",
    "done": "✅ Hecho",
}

_FR: dict[str, str] = {
    "main_menu": "🏠 Menu principal\n\nChoisissez une action :",
    "download": "📥 Télécharger",
    "back": "🔙 Retour",
    "cancel": "❌ Annuler",
    "done": "✅ Terminé",
}

_AR: dict[str, str] = {
    "main_menu": "🏠 القائمة الرئيسية\n\nاختر ما تريد فعله:",
    "download": "📥 تحميل",
    "back": "🔙 رجوع",
    "cancel": "❌ إلغاء",
    "done": "✅ تم",
}

_ZH: dict[str, str] = {
    "main_menu": "🏠 主菜单\n\n请选择您要执行的操作：",
    "download": "📥 下载",
    "back": "🔙 返回",
    "cancel": "❌ 取消",
    "done": "✅ 完成",
}

_PT: dict[str, str] = {
    "main_menu": "🏠 Menu principal\n\nEscolha o que deseja fazer:",
    "download": "📥 Baixar",
    "back": "🔙 Voltar",
    "cancel": "❌ Cancelar",
    "done": "✅ Concluído",
}

_LANGS: dict[str, Mapping[str, str]] = {
    "English": _EN,
    "हिन्दी": _HI,
    "Español": _ES,
    "français": _FR,
    "العربية": _AR,
    "中文": _ZH,
    "português": _PT,
}


def supported_languages() -> tuple[str, ...]:
    return tuple(_LANGS.keys())


def t(language: str | None, key: str) -> str:
    """Translate ``key`` for the given language; fall back to English."""
    table = _LANGS.get(language or "English", _EN)
    return table.get(key, _EN.get(key, key))


def has_language(lang: str) -> bool:
    return lang in _LANGS
