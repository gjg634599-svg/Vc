"""Media processor — extracted from _bot_core.py.

Download concurrency limiter, retry helper, file sender, and notification utilities.
Dependencies (config, remove_path) are injected to avoid circular imports.
"""

from __future__ import annotations

import asyncio
import functools
import json
import logging
import random
from pathlib import Path
from typing import Any, Awaitable, Callable, TypeVar

import aiofiles  # v97.12 FIX: async file I/O for send_file_back
from telegram.ext import ContextTypes

from .config import config

logger = logging.getLogger("mediagrab")

T = TypeVar("T")

# Injected dependencies
_config = None
_remove_path_fn = None


def _set_dependencies(config, remove_path_fn):
    """Called by _bot_core.py to inject dependencies."""
    global _config, _remove_path_fn
    _config = config
    _remove_path_fn = remove_path_fn


# Global concurrency limiter for downloads/analyses.
# v97.12 FIX: lazy-init so MAX_CONCURRENT_DOWNLOADS config is respected.
_download_sem: asyncio.Semaphore | None = None


def download_slot() -> asyncio.Semaphore:
    """Context manager acquiring one of the limited download slots."""
    global _download_sem
    if _download_sem is None:
        _n = (_config.max_concurrent_downloads if _config else 4)
        _download_sem = asyncio.Semaphore(max(1, _n))
    return _download_sem


async def with_retries(
    func: Callable[..., Awaitable[T]],
    *args,
    retries: int | None = None,
    base_delay: float = 1.5,
    **kwargs,
) -> T:
    """Call ``func`` with retries and exponential back-off.

    ASYNC-C-004: non-retryable exceptions (programming errors, missing files,
    type errors, JSON decode errors, etc.) are raised immediately — retrying
    them just wastes time.
    NET-C-002: jitter is applied to the back-off delay so concurrent retries
    don't synchronise (thundering herd).
    """
    # Errors that indicate a programming/logic bug or a permanent failure —
    # retrying these is pointless and just delays the user's error.
    _NON_RETRYABLE = (
        ValueError, TypeError, FileNotFoundError, PermissionError,
        json.JSONDecodeError, KeyError, AttributeError,
    )
    # v97.12 FIX: FileTooLarge is non-retryable (by class name to avoid
    # circular import).  Retrying it 5× wastes ~22s.
    _NON_RETRYABLE_NAMES = frozenset({"FileTooLarge", "DownloadError"})
    attempts = retries if retries is not None else config.max_retries
    last_exc: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            return await func(*args, **kwargs)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            last_exc = exc
            if isinstance(exc, _NON_RETRYABLE):
                raise
            # v97.12 FIX: non-retryable by class name.
            if type(exc).__name__ in _NON_RETRYABLE_NAMES:
                raise
            if attempt == attempts:
                logger.warning("with_retries exhausted (%d): %s", attempt, exc)
                raise
            # v97.12 FIX: respect RetryAfter.retry_after if present.
            if hasattr(exc, "retry_after") and exc.retry_after:
                delay = min(float(exc.retry_after) + 1.0, 60.0)
            else:
                base = min(base_delay * (2 ** (attempt - 1)), 30.0)
                delay = base * (0.5 + random.random() * 0.5)
            logger.info("retry %d/%d after %.1fs (%s)", attempt, attempts, delay, exc)
            await asyncio.sleep(delay)
    assert last_exc is not None
    raise last_exc


def retrying(retries: int | None = None, base_delay: float = 1.5):
    """Decorator form of :func:`with_retries`."""

    def deco(fn: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        @functools.wraps(fn)
        async def wrapper(*args, **kwargs) -> T:
            return await with_retries(
                fn, *args, retries=retries, base_delay=base_delay, **kwargs
            )

        return wrapper

    return deco


async def send_file_back(
    chat_id: int,
    file_path: Path,
    caption: str,
    context: ContextTypes.DEFAULT_TYPE,
    progress_cb: Callable[[float, int, int], Awaitable[None]] | None = None,
) -> str:
    """Send a downloaded file back to the user via the Bot API.

    Returns a short status string: "ok" | "too_large" | "error:<msg>".
    """
    path = Path(file_path)
    if not path.exists():
        return f"error:file missing ({path.name})"
    size = path.stat().st_size

    if size > _config.upload_limit_bytes:
        return "too_large"

    try:
        # v97.30 FIX: Local Bot API zero-copy delivery.  When local_mode or
        # local_bot_api_enabled is True, the Bot API server runs on the SAME
        # machine as the bot.  Passing the ABSOLUTE resolved path as a string
        # lets the Bot API server read the file directly from disk — no
        # re-upload through the bot process.  This is HUGE for large files:
        # a 500MB video is delivered in <1s (disk read) instead of 30+s
        # (multipart upload through the bot's memory).
        #
        # The v97.21 attempt failed because it passed a relative path; the
        # v97.22 revert was overly conservative (always using a file handle).
        # The correct fix: pass str(path.resolve()) — an ABSOLUTE path that
        # the Bot API server can access regardless of its CWD.  Both the bot
        # and the Bot API server run on the same host, so the path is valid.
        #
        # v97.19: capture the sent Message to extract file_id for caching.
        _is_local = _config.local_mode or _config.local_bot_api_enabled
        if _is_local:
            # Local Bot API: pass absolute path string for zero-copy delivery.
            _abs_path = str(path.resolve())
            _sent_msg = await context.bot.send_document(
                chat_id=chat_id,
                document=_abs_path,
                filename=path.name,
                caption=caption[:1024],
                read_timeout=_config.download_timeout,
                write_timeout=_config.download_timeout,
                connect_timeout=60,
                pool_timeout=60,
            )
        else:
            # Cloud Bot API: use a file handle (PTB reads + uploads via multipart).
            with path.open("rb") as fh:
                _sent_msg = await context.bot.send_document(
                    chat_id=chat_id,
                    document=fh,
                    filename=path.name,
                    caption=caption[:1024],
                    read_timeout=_config.download_timeout,
                    write_timeout=_config.download_timeout,
                    connect_timeout=60,
                    pool_timeout=60,
                )
        if progress_cb is not None:
            try:
                await progress_cb(100.0, size, size)
            except Exception:  # noqa: BLE001
                pass
        # v97.19: extract file_id from the sent message for caching.
        _sent_file_id = None
        _sent_file_unique_id = None
        if _sent_msg and getattr(_sent_msg, "document", None):
            _sent_file_id = getattr(_sent_msg.document, "file_id", None)
            _sent_file_unique_id = getattr(_sent_msg.document, "file_unique_id", None)
        # Return "ok" plus the file_id (pipe-delimited) for caching.
        if _sent_file_id:
            return f"ok|{_sent_file_id}|{_sent_file_unique_id or ''}"
        return "ok"
    except Exception as exc:  # noqa: BLE001
        logger.warning("send_document failed: %s", exc)
        return f"error:{exc}"


async def notify(chat_id: int, context: ContextTypes.DEFAULT_TYPE,
                 text: str, reply_markup=None) -> None:
    """Best-effort notification sender (used when notifications are enabled)."""
    try:
        await context.bot.send_message(
            chat_id=chat_id, text=text, reply_markup=reply_markup,
            parse_mode="Markdown",
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("notify failed: %s", exc)


async def safe_unlink(path) -> None:
    if path:
        await _remove_path_fn(path)


