"""Runtime diagnostics — temporary instrumentation to identify blocking coroutines.

This module provides:
  - Event loop lag monitor (measures scheduling delays)
  - Task dump (lists all running asyncio tasks with their await states)
  - Update handler timing (measures time from update receipt to reply)

All instrumentation is gated behind the MEDIAGRAB_DEBUG_RUNTIME env var.
When not enabled, the functions are no-ops with zero overhead.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from typing import Any

logger = logging.getLogger("mediagrab.runtime_debug")

_DEBUG = os.environ.get("MEDIAGRAB_DEBUG_RUNTIME", "").lower() in ("1", "true", "yes")

# Track update handler timing.
_update_timings: dict[int, dict[str, Any]] = {}
_update_counter: int = 0


def is_debug_enabled() -> bool:
    return _DEBUG


async def event_loop_lag_monitor() -> None:
    """Monitor event loop lag. Logs when lag > 100ms."""
    if not _DEBUG:
        return
    logger.info("RUNTIME_DEBUG: event loop lag monitor started")
    while True:
        try:
            t0 = time.monotonic()
            await asyncio.sleep(1.0)
            t1 = time.monotonic()
            lag = (t1 - t0) - 1.0
            if lag > 0.1:
                logger.warning(
                    "RUNTIME_DEBUG: EVENT_LOOP_LAG lag=%.3fs — event loop is blocked",
                    lag,
                )
            elif lag > 0.05:
                logger.debug("RUNTIME_DEBUG: event_loop_lag=%.3fs", lag)
        except asyncio.CancelledError:
            raise
        except Exception:
            pass


async def task_dump_loop() -> None:
    """Dump all running asyncio tasks every 5 seconds."""
    if not _DEBUG:
        return
    logger.info("RUNTIME_DEBUG: task dump monitor started")
    while True:
        try:
            await asyncio.sleep(5.0)
            current_task = asyncio.current_task()
            tasks = asyncio.all_tasks()
            logger.info("RUNTIME_DEBUG: TASK_DUMP count=%d", len(tasks))
            for t in sorted(tasks, key=lambda x: x.get_name() or ""):
                if t is current_task:
                    continue
                name = t.get_name() or "(unnamed)"
                done = t.done()
                cancelled = t.cancelled()
                # Get the coroutine's current state
                coro = t.get_coro()
                coro_name = ""
                if coro:
                    coro_name = getattr(coro, "__qualname__", str(coro))
                # Check if the task is waiting on something
                try:
                    # In Python 3.12+, we can check _fut_waiter
                    waiter = getattr(t, "_fut_waiter", None)
                    if waiter is not None:
                        waiter_repr = repr(waiter)[:80]
                    else:
                        waiter_repr = "(running or done)"
                except Exception:
                    waiter_repr = "(unknown)"
                logger.info(
                    "RUNTIME_DEBUG: TASK name=%s coro=%s done=%s cancelled=%s waiter=%s",
                    name, coro_name, done, cancelled, waiter_repr,
                )
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.debug("RUNTIME_DEBUG: task_dump error: %s", exc)


def start_runtime_debug() -> None:
    """Start the runtime debug monitors (if enabled)."""
    if not _DEBUG:
        return
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(event_loop_lag_monitor(), name="runtime_debug_lag")
        loop.create_task(task_dump_loop(), name="runtime_debug_tasks")
        logger.info("RUNTIME_DEBUG: monitors started (MEDIAGRAB_DEBUG_RUNTIME=true)")
    except RuntimeError:
        pass  # no running loop


def log_update_received(update_id: int, update_type: str) -> None:
    """Log when an update is received by PTB."""
    if not _DEBUG:
        return
    logger.info(
        "RUNTIME_DEBUG: UPDATE_RECEIVED id=%s type=%s t=%.3f",
        update_id, update_type, time.monotonic(),
    )


def log_handler_start(update_id: int, handler_name: str) -> None:
    """Log when a handler starts processing."""
    if not _DEBUG:
        return
    logger.info(
        "RUNTIME_DEBUG: HANDLER_START id=%s handler=%s t=%.3f",
        update_id, handler_name, time.monotonic(),
    )


def log_handler_end(update_id: int, handler_name: str, success: bool = True) -> None:
    """Log when a handler finishes."""
    if not _DEBUG:
        return
    logger.info(
        "RUNTIME_DEBUG: HANDLER_END id=%s handler=%s success=%s t=%.3f",
        update_id, handler_name, success, time.monotonic(),
    )


def log_db_wait(operation: str) -> float:
    """Log DB operation start. Returns start time."""
    if not _DEBUG:
        return 0.0
    t = time.monotonic()
    logger.debug("RUNTIME_DEBUG: DB_WAIT op=%s t=%.3f", operation, t)
    return t


def log_db_done(operation: str, start_t: float) -> None:
    """Log DB operation completion with duration."""
    if not _DEBUG or start_t == 0.0:
        return
    duration = time.monotonic() - start_t
    if duration > 0.05:
        logger.warning(
            "RUNTIME_DEBUG: DB_SLOW op=%s duration=%.3fs",
            operation, duration,
        )
    else:
        logger.debug("RUNTIME_DEBUG: DB_DONE op=%s duration=%.3fs", operation, duration)


def log_telethon_wait(rpc_name: str) -> float:
    """Log Telethon RPC start."""
    if not _DEBUG:
        return 0.0
    t = time.monotonic()
    logger.debug("RUNTIME_DEBUG: RPC_WAIT rpc=%s t=%.3f", rpc_name, t)
    return t


def log_telethon_done(rpc_name: str, start_t: float) -> None:
    """Log Telethon RPC completion."""
    if not _DEBUG or start_t == 0.0:
        return
    duration = time.monotonic() - start_t
    if duration > 3.0:
        logger.warning(
            "RUNTIME_DEBUG: RPC_SLOW rpc=%s duration=%.3fs",
            rpc_name, duration,
        )
    else:
        logger.debug("RUNTIME_DEBUG: RPC_DONE rpc=%s duration=%.3fs", rpc_name, duration)
