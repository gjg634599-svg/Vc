"""AI modes — extracted from _bot_core.py.

Defines the 5 AI analysis modes (movie, transcribe, ocr, describe, translate)
and their prompts, normalisers, and result renderers.
Pure data + functions, depends only on stdlib (re, typing).
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Callable

ACCEPTS = {
    "movie": {"video"},
    "transcribe": {"audio", "video"},
    "ocr": {"image", "video"},
    "describe": {"image", "video"},
    "translate": {"image", "video"},
}

MODE_LABELS: dict[str, str] = {
    "movie": "🎬 Movie / Series ID",
    "transcribe": "🎵 Audio Transcription",
    "ocr": "🔤 Text Extraction (OCR)",
    "describe": "📝 Scene Description",
    "translate": "🌐 Image Translation",
}

MODE_ORDER = ("movie", "transcribe", "ocr", "describe", "translate")


_MOVIE_PROMPT = """\
You are a media identification expert. You will receive several frames
extracted from a video file. Identify the source as precisely as possible.

Respond ONLY with a single JSON object (no markdown, no explanation) with
exactly these keys:

{
  "category": "Movie" | "TV Series" | "Anime" | "Unknown",
  "title":    the title of the movie, series or anime,
  "season":   season number as a string (e.g. "2") or "" if not applicable,
  "episode":  episode number or title as a string (e.g. "5" or "The One...") or "",
  "year":     release year as a string (e.g. "2019") or "" if unknown,
  "language": the primary spoken/written language (e.g. "English", "Japanese") or "",
  "quality":  the video quality you can infer from the frames (e.g. "720p", "1080p", "4K") or "",
  "confidence": your confidence score from 0.0 to 1.0
}

Rules:
- If you cannot identify the media, set category to "Unknown", leave other
  fields empty strings, and confidence low.
- Use the visible text (titles, subtitles, channel logos) as primary evidence.
- Never wrap the JSON in code fences or add commentary."""

_TRANSCRIBE_PROMPT = """\
You are an expert transcription AI. You will receive an audio file.
Transcribe all speech you can hear, accurately and in the original language.

Respond ONLY with a single JSON object:
{
  "language": the detected spoken language (e.g. "English"),
  "text":     the full transcription,
  "confidence": your confidence from 0.0 to 1.0
}
If there is no speech, set text to "" and confidence to 0.0. Do not add
commentary or code fences."""

_OCR_PROMPT = """\
You are an OCR expert. You will receive one or more images.
Extract ALL visible text exactly as it appears, preserving line breaks.

Respond ONLY with a single JSON object:
{
  "language": the detected script/language of the text (e.g. "English"),
  "text":     all extracted text, newline-separated,
  "confidence": your confidence from 0.0 to 1.0
}
If there is no text, set text to "" and confidence to 0.0. No commentary."""

_DESCRIBE_PROMPT = """\
You are an image description expert. You will receive one or more images
(or frames from a video).
Describe what you see in clear, concise detail: setting, subjects, actions,
text, mood, and any notable visual elements.

Respond ONLY with a single JSON object:
{
  "summary":   a one-sentence summary,
  "details":   a longer paragraph description,
  "tags":      a comma-separated list of relevant tags,
  "confidence": your confidence from 0.0 to 1.0
}
No commentary or code fences."""

_TRANSLATE_PROMPT = """\
You are a translation expert. You will receive one or more images containing
text. First read the text via OCR, then translate it into the target language.

Respond ONLY with a single JSON object:
{
  "source_language": the detected source language,
  "source_text":     the original text exactly as shown,
  "translated_text": the translation into the target language,
  "confidence":      your confidence from 0.0 to 1.0
}
If there is no text, set both text fields to "" and confidence to 0.0.
No commentary or code fences."""


PROMPTS: dict[str, str] = {
    "movie": _MOVIE_PROMPT,
    "transcribe": _TRANSCRIBE_PROMPT,
    "ocr": _OCR_PROMPT,
    "describe": _DESCRIBE_PROMPT,
    "translate": _TRANSLATE_PROMPT,
}


def build_prompt(mode: str, *, target_language: str | None = None) -> str:
    """Return the prompt for the given mode, with mode-specific substitutions."""
    base = PROMPTS.get(mode, _DESCRIBE_PROMPT)
    if mode == "translate" and target_language:
        # SEC-C-005: target_language is user-controlled and interpolated into
        # the prompt — clamp its length and reject anything that isn't a
        # plausible language name so it can't smuggle prompt-injection
        # payloads or shell metacharacters through to the model.
        safe = (target_language or "")[:40]
        if not re.match(r"^[A-Za-z][A-Za-z\s\-']{1,40}$", safe):
            safe = "the target language"
        return base.replace(
            "translate it into the target language.",
            f"translate it into {safe}.",
        )
    return base


def _norm_movie(data: dict) -> dict[str, Any]:
    return {
        "category": data.get("category", "Unknown"),
        "title": data.get("title", ""),
        "season": data.get("season", ""),
        "episode": data.get("episode", ""),
        "year": data.get("year", ""),
        "language": data.get("language", ""),
        "quality": data.get("quality", ""),
        "confidence": _conf(data.get("confidence")),
    }


def _norm_transcribe(data: dict) -> dict[str, Any]:
    return {
        "language": data.get("language", ""),
        "text": data.get("text", ""),
        "confidence": _conf(data.get("confidence")),
    }


def _norm_ocr(data: dict) -> dict[str, Any]:
    return {
        "language": data.get("language", ""),
        "text": data.get("text", ""),
        "confidence": _conf(data.get("confidence")),
    }


def _norm_describe(data: dict) -> dict[str, Any]:
    return {
        "summary": data.get("summary", ""),
        "details": data.get("details", ""),
        "tags": data.get("tags", ""),
        "confidence": _conf(data.get("confidence")),
    }


def _norm_translate(data: dict) -> dict[str, Any]:
    return {
        "source_language": data.get("source_language", ""),
        "source_text": data.get("source_text", ""),
        "translated_text": data.get("translated_text", ""),
        "confidence": _conf(data.get("confidence")),
    }


NORMALISERS: dict[str, Callable[[dict], dict[str, Any]]] = {
    "movie": _norm_movie,
    "transcribe": _norm_transcribe,
    "ocr": _norm_ocr,
    "describe": _norm_describe,
    "translate": _norm_translate,
}


def _conf(val) -> float:
    try:
        if val is None:
            return 0.0
        if isinstance(val, str) and val.strip().endswith("%"):
            return max(0.0, min(1.0, float(val.strip("% ")) / 100.0))
        f = float(val)
        if f > 1.0:
            f = f / 100.0
        return max(0.0, min(1.0, f))
    except (TypeError, ValueError):
        return 0.0


def normalise(mode: str, data: dict) -> dict[str, Any]:
    fn = NORMALISERS.get(mode, _norm_describe)
    try:
        return fn(data)
    except Exception:  # noqa: BLE001
        return {"confidence": 0.0, "raw": data}


def accepts(mode: str, media_kind: str) -> bool:
    """Whether a mode accepts a given media kind (video/audio/image)."""
    return media_kind in ACCEPTS.get(mode, set())


def media_kind_for(file_path) -> str:
    """Classify a downloaded file path into video/audio/image/other."""
    p = Path(file_path)
    ext = p.suffix.lower().lstrip(".")
    video = {"mp4", "mkv", "avi", "mov", "webm", "flv", "wmv", "m4v", "ts", "mpg", "mpeg", "3gp"}
    audio = {"mp3", "m4a", "aac", "flac", "ogg", "opus", "wav", "wma"}
    image = {"jpg", "jpeg", "png", "webp", "bmp", "gif", "tiff", "heic"}
    if ext in video:
        return "video"
    if ext in audio:
        return "audio"
    if ext in image:
        return "image"
    return "other"


_MD_ESCAPE_RE = re.compile(r"([_*`\[\]])")


def _esc_md(value: Any) -> str:
    """v99.07 FIX-34: escape legacy-Markdown metacharacters in model text.

    ``render_result`` interpolates model-produced strings into Markdown
    that is sent with parse_mode="Markdown"; unescaped `` ` ``/``*``/
    ``_``/``[``/``]`` in the model's output broke the parse mode (reply
    failed to send or rendered mangled). None → "" so the ``or '—'``
    fallbacks in render_result keep working.
    """
    s = "" if value is None else str(value)
    return _MD_ESCAPE_RE.sub(r"\\\1", s)


def render_result(mode: str, r: dict[str, Any]) -> str:
    # v99.07 FIX-34: every MODEL-PRODUCED value is passed through _esc_md()
    # before interpolation — the render output is sent with
    # parse_mode="Markdown" (legacy), and unescaped backticks/asterisks/
    # underscores/brackets inside model text previously broke the parse
    # (the whole reply failed to send or rendered mangled). Labels,
    # headers and fallback dashes are code-controlled and stay literal.
    conf = r.get("confidence")
    conf_s = f"{conf * 100:.0f}%" if conf is not None else "—"

    if mode == "movie":
        def cell(label, val):
            return f"  • *{label}:* {_esc_md(val) if val not in (None, '', 'Unknown') else '—'}"
        return (
            "🎬 *AI Analysis Result*\n\n"
            f"{cell('Category', r.get('category'))}\n"
            f"{cell('Title', r.get('title'))}\n"
            f"{cell('Season', r.get('season'))}\n"
            f"{cell('Episode', r.get('episode'))}\n"
            f"{cell('Year', r.get('year'))}\n"
            f"{cell('Language', r.get('language'))}\n"
            f"{cell('Quality', r.get('quality'))}\n"
            f"{cell('Confidence', conf_s)}\n"
        )
    if mode == "transcribe":
        return (
            "🎵 *Transcription*\n\n"
            f"🌐 *Language:* {_esc_md(r.get('language')) or '—'}\n"
            f"🎯 *Confidence:* {conf_s}\n\n"
            f"📝 *Text:*\n{_esc_md(r.get('text')) or '_(no speech detected)_'}"
        )
    if mode == "ocr":
        return (
            "🔤 *Extracted Text*\n\n"
            f"🌐 *Language:* {_esc_md(r.get('language')) or '—'}\n"
            f"🎯 *Confidence:* {conf_s}\n\n"
            f"📝 *Text:*\n```\n{_esc_md(r.get('text')) or '_(no text found)_'}\n```"
        )
    if mode == "describe":
        return (
            "📝 *Scene Description*\n\n"
            f"*Summary:* {_esc_md(r.get('summary')) or '—'}\n\n"
            f"*Details:*\n{_esc_md(r.get('details')) or '—'}\n\n"
            f"🏷️ *Tags:* {_esc_md(r.get('tags')) or '—'}\n"
            f"🎯 *Confidence:* {conf_s}"
        )
    if mode == "translate":
        return (
            "🌐 *Translation*\n\n"
            f"🔤 *Source language:* {_esc_md(r.get('source_language')) or '—'}\n\n"
            f"📝 *Original:*\n```\n{_esc_md(r.get('source_text')) or '_(no text)_'}\n```\n\n"
            f"✅ *Translation:*\n{_esc_md(r.get('translated_text')) or '—'}\n\n"
            f"🎯 *Confidence:* {conf_s}"
        )
    return f"🤖 Result\n\n{r}"
