"""User state machine — manages per-user workflow state.

This module was physically extracted from _bot_core.py (lines 9193-9363).
It is completely self-contained: depends only on stdlib (asyncio, time,
collections.defaultdict).

The state machine tracks which "mode" each user is in (e.g. awaiting a
download forward, awaiting an inspect input, etc.). This allows the
central router (route_message) to dispatch text input to the correct
handler based on what the user is currently doing.

State is held in-memory (_states dict) and pruned periodically by
prune_stale_user_states() to prevent unbounded growth.
"""

from __future__ import annotations

import asyncio
import time
from collections import defaultdict
from typing import Any

# ---------------------------------------------------------------------------
# State constants
# ---------------------------------------------------------------------------

IDLE = "idle"
AWAIT_DOWNLOAD_FORWARD = "await_download_forward"
AWAIT_ANALYZE = "await_analyze"
AWAIT_INSPECT = "await_inspect"
AWAIT_TOOLBOX = "await_toolbox"          # value stored as "tb:<tool>"
AWAIT_LIBRARY_SEARCH = "await_library_search"
AWAIT_QR = "await_qr"
AWAIT_BATCH = "await_batch"              # collecting a media group
AWAIT_SCHEDULE = "await_schedule"        # awaiting a time + media
AWAIT_BACKUP_IMPORT = "await_backup_import"
AWAIT_ADMIN_BCAST = "await_admin_bcast"
AWAIT_LINK_DOWNLOAD = "await_link_download"      # link/username input
AWAIT_LINK_MESSAGE_ID = "await_link_message_id"  # message id after resolve
AWAIT_MTPROTO_SCREENSHOT = "await_mtproto_screenshot"
AWAIT_MTPROTO_DOWNLOAD = "await_mtproto_download"
AWAIT_MTPROTO_MSGID = "await_mtproto_msgid"   # picking a message id after history
AWAIT_MEDIA_BROWSE = "await_media_browse"     # user entered a channel to browse
AWAIT_VC_JOIN_TARGET = "await_vc_join_target"
AWAIT_VC_CHECK_TARGET = "await_vc_check_target"
AWAIT_VC_STAY = "await_vc_stay"
AWAIT_VC_COOLDOWN = "await_vc_cooldown"

# ---------------------------------------------------------------------------
# In-memory caches (module-level singletons)
# ---------------------------------------------------------------------------

_states: dict[int, str] = defaultdict(lambda: IDLE)
_tool: dict[int, str] = {}               # user_id -> active toolbox tool
_last_download: dict[int, dict] = {}     # user_id -> last completed download meta
# Phase 6 (P1 — state cache pruning): track last activity per user so the
# periodic cleanup loop can evict stale IDLE entries without breaking active
# workflows.  Monotonic time is used for TTL calculations.
_user_last_activity: dict[int, float] = {}  # user_id -> monotonic timestamp
_STATE_TTL_SECONDS = 3600  # 1 hour — prune IDLE users inactive for this long
_STATE_PRUNE_BATCH = 200   # max entries to prune per cycle (bound work)

_states_lock = asyncio.Lock()


# ---------------------------------------------------------------------------
# Activity tracking
# ---------------------------------------------------------------------------

def _touch_user_activity(user_id: int) -> None:
    """Record that *user_id* had state activity (called under _states_lock
    or from sync setters)."""
    _user_last_activity[user_id] = time.monotonic()


# ---------------------------------------------------------------------------
# Async state accessors
# ---------------------------------------------------------------------------

async def set_state(user_id: int, state: str) -> None:
    async with _states_lock:
        _states[user_id] = state
        _touch_user_activity(user_id)


async def get_state(user_id: int) -> str:
    return _states.get(user_id, IDLE)


async def reset(user_id: int) -> None:
    async with _states_lock:
        _states[user_id] = IDLE
        _tool.pop(user_id, None)
        _touch_user_activity(user_id)


async def set_tool(user_id: int, tool: str) -> None:
    async with _states_lock:
        _tool[user_id] = tool
        _touch_user_activity(user_id)


async def get_tool(user_id: int) -> str:
    return _tool.get(user_id, "")


async def set_last_download(user_id: int, meta: dict) -> None:
    async with _states_lock:
        _last_download[user_id] = meta
        _touch_user_activity(user_id)


async def get_last_download(user_id: int) -> dict | None:
    return _last_download.get(user_id)


# ---------------------------------------------------------------------------
# Sync state accessors (for use in non-async contexts)
# ---------------------------------------------------------------------------

def set_state_sync(user_id: int, state: str) -> None:
    _states[user_id] = state
    _touch_user_activity(user_id)


def get_state_sync(user_id: int) -> str:
    return _states.get(user_id, IDLE)


def set_tool_sync(user_id: int, tool: str) -> None:
    _tool[user_id] = tool
    _touch_user_activity(user_id)


def get_tool_sync(user_id: int) -> str:
    return _tool.get(user_id, "")


def set_last_download_sync(user_id: int, meta: dict) -> None:
    _last_download[user_id] = meta
    _touch_user_activity(user_id)


def get_last_download_sync(user_id: int) -> dict | None:
    return _last_download.get(user_id)


# ---------------------------------------------------------------------------
# Active workflow states (never pruned)
# ---------------------------------------------------------------------------

# Set of states that represent an ACTIVE workflow — these must NEVER be
# pruned by the state-cache cleanup, regardless of wall-clock time.
_ACTIVE_WORKFLOW_STATES = frozenset({
    AWAIT_DOWNLOAD_FORWARD, AWAIT_ANALYZE, AWAIT_INSPECT, AWAIT_TOOLBOX,
    AWAIT_LIBRARY_SEARCH, AWAIT_QR, AWAIT_BATCH, AWAIT_SCHEDULE,
    AWAIT_BACKUP_IMPORT, AWAIT_ADMIN_BCAST, AWAIT_LINK_DOWNLOAD,
    AWAIT_LINK_MESSAGE_ID, AWAIT_MTPROTO_SCREENSHOT,
    AWAIT_MTPROTO_DOWNLOAD, AWAIT_MTPROTO_MSGID, AWAIT_VC_JOIN_TARGET,
    AWAIT_VC_CHECK_TARGET, AWAIT_VC_STAY, AWAIT_VC_COOLDOWN,
    "await_gemini_key",
})


# ---------------------------------------------------------------------------
# Stale-state pruning
# ---------------------------------------------------------------------------

def prune_stale_user_states(max_age_seconds: int = _STATE_TTL_SECONDS,
                            batch_limit: int = _STATE_PRUNE_BATCH) -> dict[str, int]:
    """Evict stale IDLE user state entries (Phase 6 — P1 state pruning).

    Only evicts users whose state is IDLE (no active workflow) AND whose
    last activity is older than *max_age_seconds*.  NEVER evicts a user
    in an active workflow state — active downloads, broadcasts, admin
    input flows, VC target input, Talkative pending input, and scheduled
    workflows are all preserved regardless of wall-clock time.

    Also prunes stale ``_tool`` and ``_last_download`` entries for the
    same evicted users.  Bounds work per cycle via *batch_limit*.

    Returns a dict with pruned counts for debug logging.
    """
    now = time.monotonic()
    pruned_states = 0
    pruned_tools = 0
    pruned_downloads = 0
    pruned_activity = 0
    evicted: list[int] = []
    for uid, last_ts in list(_user_last_activity.items()):
        if len(evicted) >= batch_limit:
            break
        if (now - last_ts) < max_age_seconds:
            continue
        # Check the user's state — only prune if IDLE (not in an active
        # workflow).  This is the critical safety guard.
        st = _states.get(uid, IDLE)
        if st != IDLE and st in _ACTIVE_WORKFLOW_STATES:
            continue
        evicted.append(uid)
    for uid in evicted:
        # Only remove if STILL idle (could have changed during iteration).
        st = _states.get(uid, IDLE)
        if st == IDLE or st not in _ACTIVE_WORKFLOW_STATES:
            _states.pop(uid, None)
            pruned_states += 1
        _tool.pop(uid, None)
        pruned_tools += 1
        _last_download.pop(uid, None)
        pruned_downloads += 1
        _user_last_activity.pop(uid, None)
        pruned_activity += 1
    return {
        "states": pruned_states, "tools": pruned_tools,
        "downloads": pruned_downloads, "activity": pruned_activity,
    }
