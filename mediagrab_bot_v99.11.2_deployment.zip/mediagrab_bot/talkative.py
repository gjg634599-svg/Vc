"""Talkative subsystem — physically extracted from _bot_core.py.

Conversational AI subsystem: trigger detection, provider chain
(Groq → OpenRouter → Gemini → fallback), sessions, memory, adaptive
group context, media reactions, VC talkative integration.

Cross-subsystem dependencies resolved without importing _bot_core:
  - vc_talkative_* (VC) -> imported from voicechat.
  - _adaptive_* registered via talkative_hooks DI bridge (called by voicechat).
  - MTProto entity resolution / userbot handler -> imported from mtproto.
"""

from __future__ import annotations

import asyncio
import functools
import hashlib
import inspect
import json
import logging
import os
import re
import time
from collections import defaultdict, OrderedDict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Awaitable, Callable, Optional

import httpx
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, filters, Application
from telegram.error import BadRequest, Forbidden, NetworkError, TimedOut, RetryAfter

from .config import _env_int, config
from .text_utils import md_escape
from .db_layer import (
    repo, get_db, _db,
    talkative_add_memory, talkative_add_stat, talkative_cleanup_expired_sessions,
    talkative_cleanup_old_memory, talkative_effective_enabled,
    talkative_effective_provider, talkative_effective_settings,
    talkative_get_active_session, talkative_get_memory,
    talkative_get_wake_words, talkative_trim_memory,
    talkative_get_global_settings, talkative_get_chat_settings,
    talkative_update_global_settings, talkative_set_chat_setting,
    talkative_apply_effective_runtime, talkative_remove_wake_word,
    talkative_clear_memory, talkative_add_wake_word,
)
from .utils_real import (
    extension_category, get_bot, human_size, is_available, periodic_cleanup,
    register_bot, remove_path, safe_edit_message_text, safe_filename,
    safe_reply_text, safe_send_document, safe_send_message, supervised_create_task,
    telegram_media_type, unique_path, _active_tasks,
    _redact_secrets, _sanitize_error, _ui_check, _ui_claim, _ui_invalidate, _ui_release,
    _ui_owners, _userbot_id, _cache_userbot_identity,
    _userbot_username, _userbot_display_name,
)
from .states import (
    IDLE, set_state, get_state, reset, set_tool, get_tool,
    set_last_download, get_last_download, get_state_sync,
    AWAIT_ADMIN_BCAST, AWAIT_ANALYZE, AWAIT_BACKUP_IMPORT, AWAIT_BATCH,
    AWAIT_DOWNLOAD_FORWARD, AWAIT_INSPECT, AWAIT_LIBRARY_SEARCH,
    AWAIT_LINK_DOWNLOAD, AWAIT_LINK_MESSAGE_ID, AWAIT_MEDIA_BROWSE,
    AWAIT_MTPROTO_DOWNLOAD, AWAIT_MTPROTO_MSGID, AWAIT_MTPROTO_SCREENSHOT,
    AWAIT_QR, AWAIT_SCHEDULE, AWAIT_TOOLBOX,
    AWAIT_VC_CHECK_TARGET, AWAIT_VC_COOLDOWN, AWAIT_VC_JOIN_TARGET, AWAIT_VC_STAY,
)
from .ui_keyboards import talkative_menu, talkative_memory_controls_menu
from .media_processor import download_slot, with_retries, retrying, send_file_back, notify, safe_unlink
from .ai_modes import (
    ACCEPTS, MODE_LABELS, MODE_ORDER, PROMPTS, build_prompt,
    NORMALISERS, normalise, accepts, media_kind_for, render_result,
)
from .mtproto import (
    VCTransportError, _redact_ah, resolve_entity_full,
    mtproto_get_client, mtproto_is_available, mtproto_is_started,
    get_userbot_cluster, UserbotCluster,
)
from .voicechat import (
    vc_talkative_start, vc_talkative_stop,
    vc_talkative_get_capabilities, vc_talkative_refresh_capabilities,
    _vc_known_call_ids, _vc_target_cooldowns, _vc_target_locks,
    _vc_talkative_sessions, _vc_reconcile_cooldowns, _vc_in_flight_joins,
    _vc_participations, _VC_TARGET_COOLDOWN_SECONDS, _INTENT_TAG_MAP,
)
from .talkative_hooks import register_talkative_hooks
from .diag_hooks import v85_diag

# ai_analyzer helpers (pre-existing lost code — same broken import as _bot_core baseline).
from .ai_analyzer import _get_client, _run_in_thread, _extract_text

logger = logging.getLogger("mediagrab")


_talkative_telethon_pending_inputs: dict[int, str] = {}

# V51 Fix #5: per-chat send-permission cache.
# Prevents repeated send attempts to non-writable/restricted chats.
# Bounded (max 500 chats), TTL-based (300s), per-chat, reason-aware.


_send_permission_cache: dict[int, dict[str, Any]] = {}


_SEND_PERM_MAX = 500


_SEND_PERM_TTL = 300.0  # 5 minutes


def _send_perm_check(chat_id: int) -> tuple[bool, str]:
    """V51 Fix #5: check if a chat is known to be non-writable.

    Returns (allowed, reason). If the chat was recently marked as
    non-writable, returns (False, reason). Otherwise returns (True, "").
    """
    entry = _send_permission_cache.get(chat_id)
    if entry is None:
        return True, ""
    if time.monotonic() - entry["ts"] > _SEND_PERM_TTL:
        # TTL expired — recheck.
        _send_permission_cache.pop(chat_id, None)
        return True, ""
    return False, entry["reason"]


def _send_perm_mark_forbidden(chat_id: int, reason: str) -> None:
    """V51 Fix #5: mark a chat as non-writable with a bounded TTL."""
    if len(_send_permission_cache) >= _SEND_PERM_MAX:
        # Evict oldest entry.
        oldest = min(_send_permission_cache, key=lambda k: _send_permission_cache[k]["ts"])
        _send_permission_cache.pop(oldest, None)
    _send_permission_cache[chat_id] = {"reason": reason, "ts": time.monotonic()}
    logger.warning(
        "TALKATIVE_SEND_PERM_CACHE chat=%s marked as non-writable reason=%s ttl=%.0fs",
        chat_id, reason, _SEND_PERM_TTL,
    )

# Fix 5: ALL command-like messages are excluded — any text starting with "/"
# is a command, including unknown commands and /command@username.
# The old filter only checked known VC commands; now every "/" prefix is
# excluded, which is the correct behavior (commands are handled by the
# Telethon _vc_handle_vc_command handler, not Talkative).


async def talkative_userbot_register_handler() -> bool:
    """Register the Telethon NewMessage handler for Talkative V2.

    Routes BOTH private DMs and group messages into the shared adaptive core.
    Caches the userbot's own identity for mention/reply/self detection.
    Returns True if registered successfully.
    """
    global _talkative_userbot_handler_registered
    if _talkative_userbot_handler_registered:
        return True
    client = mtproto_get_client()
    if client is None:
        logger.warning("Talkative userbot handler: MTProto client not available.")
        return False
    if not client.is_connected():
        logger.warning("Talkative userbot handler: MTProto client not connected.")
        return False
    # Cache the userbot's identity (Fix 2: never reuse Bot API identity).
    await _cache_userbot_identity()
    from telethon import events

    @client.on(events.NewMessage(incoming=True))
    async def _on_talkative_message(event):  # type: ignore[no-untyped-def]
        # v97.51: enqueue to bounded queue instead of inline processing.
        # Talkative does AI processing (heavy) — must not block dispatch.
        from .voicechat import _vc_callback_enqueue
        _vc_callback_enqueue(_talkative_userbot_handle_message, event, "talkative")

    _talkative_userbot_handler_registered = True
    logger.info("Talkative userbot handler registered on live MTProto client (id=%s, username=@%s).",
                _userbot_id, _userbot_username)
    return True


# V54 Fix #1: classify incoming Telethon media type.


def _classify_telethon_media(event) -> str:
    """Classify the media type of an incoming Telethon event.

    Returns one of: "voice", "audio", "sticker", "gif", "photo", "video",
    "document", or "" (no media).
    """
    msg = event.message
    if msg is None:
        return ""
    # Voice note (ogg audio)
    if getattr(msg, "voice", None) is not None:
        return "voice"
    # Audio file
    if getattr(msg, "audio", None) is not None:
        return "audio"
    # Sticker
    if getattr(msg, "sticker", None) is not None:
        return "sticker"
    # GIF / animation
    if getattr(msg, "gif", None) is not None or getattr(msg, "animation", None) is not None:
        return "gif"
    # Photo
    if getattr(msg, "photo", None) is not None:
        return "photo"
    # Video
    if getattr(msg, "video", None) is not None:
        return "video"
    # Document (catch-all for other file types)
    if getattr(msg, "document", None) is not None:
        return "document"
    return ""


# ===========================================================================
# V60 Voice Enrollment Subsystem — Bot API native, real provider, real
# validation, guaranteed cleanup, single authoritative state.
#
# CONFIRMED ROOT CAUSE (V59 and earlier):
#   The Voice Enrollment UI is opened inside the Telegram Bot API bot chat
#   through the callback `talk:clone:enroll`. That callback started the
#   enrollment using `update.effective_user.id` / `update.effective_chat.id`
#   (Bot API identifiers). However, the submitted voice/audio sample was
#   consumed ONLY by the Telethon userbot handler
#   (`@client.on(events.NewMessage(incoming=True))`). A voice note sent to
#   the Scipee bot chat is received by python-telegram-bot / Bot API. It is
#   NOT received as an incoming message by the separate Telethon userbot
#   account. Result: sample was never consumed, no status reply, enrollment
#   was permanently broken.
#
# V60 FIX:
#   1. Single authoritative enrollment-state service keyed by
#      (admin_user_id, bot_chat_id) — used by BOTH the Bot API voice/audio
#      handler AND the cancel callback. No two independent pending-state
#      dictionaries that drift out of sync.
#   2. A real high-priority private-chat Bot API MessageHandler (group=-1)
#      for VOICE / AUDIO / audio documents. Registered BEFORE the default
#      route_message handler and the group=10 Talkative wrapper, so it
#      runs FIRST. If no enrollment state matches, the update simply falls
#      through to normal processing.
#   3. Sample is downloaded through the Bot API file flow
#      (`context.bot.get_file(file_id)` + `download_to_drive(custom_path=...)`)
#      — never via Telethon `download_media()`. The real Telegram MIME type
#      and extension are preserved.
#   4. Real audio validation via `ffprobe`. No duration estimation from
#      file size. If ffprobe is missing, an explicit configuration error
#      is reported — never a silent guess.
#   5. Real voice-clone provider adapter (ElevenLabs REST). Reads
#      VOICE_CLONE_PROVIDER / VOICE_CLONE_API_KEY from environment. The
#      provider's real enrollment/profile-creation API is called. Only
#      `profile_created = True` after the provider confirms success.
#      Never fabricates a profile ID.
#   6. Secure DB persistence via parameterized SQL. The `voice_profiles`
#      table is verified to exist before runtime use. Stores
#      owner_user_id / provider / provider_profile_id / status / timestamps.
#      Never stores raw voice sample, API key, or temp path.
#   7. Guaranteed cleanup via try/finally — temp directory and all
#      intermediate files are removed on every exit path (success,
#      validation failure, provider failure, DB failure, timeout, cancel,
#      exception).
#   8. Pending state lifecycle — cleared on success, unrecoverable failure,
#      provider failure, timeout, cancel, and unexpected exception. Stale
#      states auto-expire.
#   9. Cancel flow that clears the SAME authoritative state used by the
#      Bot API voice/audio handler.
#  10. Deterministic one-shot claim — a single asyncio.Lock guarantees a
#      voice sample is processed exactly once. Duplicate updates are
#      dropped with a warning.
#  11. User-friendly status messages — no dict dumps, no Python exception
#      names, no tracebacks, no raw provider responses, no API keys, no
#      internal file paths in the Telegram UI.
#  12. Stage diagnostics — every stage logged with stage name + safe
#      detail. Failure stages identify the exact failed step without
#      exposing secrets.
#  13. Startup self-check — verifies handler registration, ffmpeg/ffprobe
#      availability, voice_profiles table availability, configured provider
#      adapter, and required provider key. Reports a truthful status
#      (Ready / Missing FFmpeg / Missing Provider / Missing API Key /
#      Handler Not Registered / Database Not Ready).
# ===========================================================================


# V60 Fix #4: SINGLE authoritative enrollment-state service.
# Keyed by (admin_user_id, bot_chat_id) so the Bot API voice/audio handler
# and the cancel callback see the same state. No more two-dictionary drift.


async def _talkative_userbot_handle_message(event) -> None:
    """#14: Telethon userbot conversational handler.

    Routes incoming DM + group messages into the existing adaptive core.
    Sends replies via the userbot (event.reply / client.send_message).
    Never sends conversational output through the Bot API.

    Fix 1: Real shared workflow-priority guard — checks Telethon-side
    command filter AND a Telethon-side pending-input registry so pending
    Discovery, VC, setup, admin and other workflow inputs never reach
    Talkative.
    Fix 5: Every command-like message (including unknown commands and
    /command@username) is excluded before Talkative processing.
    Fix 6: Private message text previews are NOT logged by default;
    only metadata (sender, chat, type, length).
    """
    # V54 Fix #1: detect media BEFORE requiring text. Media-only messages
    # (voice notes, stickers, GIFs, images, audio) must not be dropped.
    text = (event.raw_text or "").strip()

    # V54 Fix #1: classify incoming media type.
    media_type = _classify_telethon_media(event)
    if not text and not media_type:
        return  # no text and no supported media — nothing to process

    # V42 Fix #14: cheapest authoritative checks FIRST, before any expensive
    # get_sender/get_chat/context/DB/engagement work. This prevents busy
    # groups from flooding logs and burning CPU when Talkative is off.

    # 1. Command filter (cheapest — string check only) — only for text messages.
    if text and text.startswith("/"):
        logger.debug("TALKATIVE_REJECT reason=command")
        return

    # 2. Self/outgoing filter — use cached _userbot_id (no client.get_me() call).
    #    V63 Fix: event.get_sender() can raise FloodWaitError (caused by
    #    GetUsersRequest). Wrap in try/except + fall back to event.sender_id
    #    (which is available without an API call). This prevents the Telethon
    #    handler from crashing on FloodWait, which was causing unhandled
    #    exceptions in the update dispatcher.
    try:
        sender = await event.get_sender()
        sender_id = getattr(sender, "id", 0)
    except Exception as sender_exc:  # noqa: BLE001 — FloodWaitError, ChannelPrivateError, etc.
        # Fall back to event.sender_id (available from the event itself,
        # no API call needed). This may be None for anonymous channel posts.
        sender_id = getattr(event, "sender_id", None) or 0
        if sender_id:
            logger.debug(
                "TALKATIVE_GET_SENDER_FALLBACK sender_id=%s exc=%s: %s",
                sender_id, type(sender_exc).__name__, str(sender_exc)[:120],
            )
        else:
            # No sender_id at all — can't process this message.
            logger.debug("TALKATIVE_REJECT reason=no_sender_id exc=%s", type(sender_exc).__name__)
            return
    if not sender_id:
        return
    if _userbot_id is not None and sender_id == _userbot_id:
        logger.debug("TALKATIVE_REJECT reason=self_message sender=%s", sender_id)
        return  # self-message
    # V85.5 FIX (RELI-G-007): reject messages from OTHER bots (Telegram bot
    # accounts set sender.bot / sender.is_bot). This prevents feedback loops
    # where this userbot replies to another bot's automated messages.
    # ``sender`` may be undefined if ``event.get_sender()`` raised above and
    # we fell back to ``event.sender_id`` — in that case we have no bot flag
    # and skip this check (the message is processed normally).
    _sender_obj = locals().get("sender")
    if _sender_obj is not None and (
        getattr(_sender_obj, "bot", False) or getattr(_sender_obj, "is_bot", False)
    ):
        logger.debug("TALKATIVE_REJECT reason=other_bot sender=%s", sender_id)
        return

    try:
        chat = await event.get_chat()
    except Exception as chat_exc:  # noqa: BLE001 — FloodWaitError, ChannelPrivateError, etc.
        # Fall back to event.chat_id (available without an API call).
        chat_id = getattr(event, "chat_id", None)
        if chat_id is None:
            logger.debug("TALKATIVE_REJECT reason=no_chat_id exc=%s", type(chat_exc).__name__)
            return
        chat = None  # we have the ID but not the full chat object
    else:
        chat_id = getattr(chat, "id", None)
        if chat_id is None:
            return

    is_private = not bool(getattr(event, "is_group", False))
    chat_type = "private" if is_private else "group"

    # V44 Fix #4 + V46 Fix: record pipeline diagnostic for BOTH private and group.
    if is_private:
        _dm_diag_record(sender_id, "private_event_seen", True)
        _dm_diag_record(sender_id, "peer_id", sender_id)
        _dm_diag_record(sender_id, "media_type", media_type)
    else:
        _group_diag_record(chat_id, "event_seen", True)
        _group_diag_record(chat_id, "chat_id", chat_id)
        _group_diag_record(chat_id, "media_type", media_type)

    # V60 Fix #4: voice enrollment is now handled by the Bot API
    # high-priority MessageHandler (_voice_enroll_bot_api_handler) in
    # group=-1. A voice note sent to the BOT CHAT is received by the Bot
    # API, NOT by this Telethon userbot account. The Telethon-side
    # enrollment check that used to live here was the root cause of the
    # V59 breakage: it waited for an event that never arrived in this
    # transport. It has been removed. The Telethon userbot never consumes
    # enrollment samples — see _voice_enroll_bot_api_handler.

    # 3. Effective global enabled state (V41 Fix #6 + V42 Fix #14).
    #    This is the AUTHORITATIVE gate — if Talkative is globally off, reject
    #    immediately with NO further work (no context, no DB reads, no logging flood).
    try:
        eff_enabled, eff_source = await talkative_effective_enabled()
    except Exception:  # noqa: BLE001
        eff_enabled, eff_source = False, "error"
    if not eff_enabled:
        # V42 Fix #13: demote routine rejection to DEBUG — don't flood INFO logs.
        if is_private:
            _dm_diag_record(sender_id, "terminal_reason", "global_disabled")
        else:
            _group_diag_record(chat_id, "terminal_reason", "global_disabled")
        logger.debug(
            "TALKATIVE_REJECT reason=global_disabled chat=%s sender=%s source=%s",
            chat_id, sender_id, eff_source)
        return

    # 4. Workflow-priority guard (Telethon-side pending-input registry).
    if sender_id in _talkative_telethon_pending_inputs:
        pending = _talkative_telethon_pending_inputs[sender_id]
        if is_private:
            _dm_diag_record(sender_id, "workflow_block", pending)
            _dm_diag_record(sender_id, "terminal_reason", "workflow_pending")
        else:
            _group_diag_record(chat_id, "workflow_block", pending)
            _group_diag_record(chat_id, "terminal_reason", "workflow_pending")
        logger.debug("TALKATIVE_REJECT reason=workflow_pending sender=%s pending=%s",
                     sender_id, pending)
        return

    # 5. Mode resolution — if the chat mode is off, reject with NO deeper work.
    mode = await talkative_get_mode(chat_id)
    if is_private:
        _dm_diag_record(sender_id, "effective_chat_mode", mode)
    else:
        _group_diag_record(chat_id, "effective_chat_mode", mode)
    if not _talkative_mode_allows_chat(mode):
        # V42 Fix #13: demote to DEBUG — thousands of these flood the log.
        if is_private:
            _dm_diag_record(sender_id, "terminal_reason", "chat_mode_off")
        else:
            _group_diag_record(chat_id, "terminal_reason", "chat_mode_off")
        logger.debug("TALKATIVE_REJECT reason=chat_mode_off chat=%s mode=%s", chat_id, mode)
        return

    # --- At this point, Talkative is enabled and the chat mode allows it. ---
    # Deeper work (context, engagement, provider) happens below.

    # V42 Fix #13: input logging moved here — only log when the message PASSES
    # the enabled + mode gates. Busy groups with mode=off won't flood the log.
    # V42 Fix #20: demote to DEBUG for routine input.
    if is_private:
        logger.debug("TALKATIVE_USERBOT_INPUT sender=%s chat=%s type=private len=%d",
                     sender_id, chat_id, len(text))
    else:
        logger.debug("TALKATIVE_USERBOT_INPUT sender=%s chat=%s type=group text=%s",
                     sender_id, chat_id, text[:60])

    # V42 Fix #14: workflow-priority guard + mode resolution already done above
    # (steps 4 and 5). Skip the duplicate checks here.

    # V46 Fix: helper to record diagnostic for BOTH private and group events.
    # Every gate must record a terminal_reason — no silent returns.
    def _record_stage(stage, value, terminal=None):
        if is_private:
            _dm_diag_record(sender_id, stage, value)
            if terminal:
                _dm_diag_record(sender_id, "terminal_reason", terminal)
        # V46 Fix: group events also get stage recording via _group_diag.
        else:
            _group_diag_record(chat_id, stage, value)
            if terminal:
                _group_diag_record(chat_id, "terminal_reason", terminal)

    # Get effective settings.
    try:
        settings = await talkative_effective_settings(chat_id)
    except Exception:  # noqa: BLE001
        _record_stage("settings", {"error": True}, terminal="settings_error")
        logger.debug("TALKATIVE_REJECT reason=settings_error chat=%s", chat_id)
        return
    # V47 Fix: the `enabled` column in per-chat settings is the OLD dashboard
    # toggle. The mode gate (step 5 above) is the AUTHORITATIVE gate — it
    # already resolved to "chat" or "both" for this message. For DMs where
    # enabled=None (no explicit per-chat row), do NOT reject — the mode
    # resolution already determined eligibility. Only reject if enabled is
    # EXPLICITLY set to False (not None).
    settings_enabled = settings.get("enabled", None)
    if settings_enabled is False:
        _record_stage("settings", {"enabled": False}, terminal="chat_disabled")
        logger.debug("TALKATIVE_REJECT reason=chat_disabled chat=%s", chat_id)
        return
    _record_stage("settings", {"enabled": settings_enabled})

    # Trigger detection (Telethon-specific).
    # V48 Fix: in "chat" or "both" mode, groups should NOT require an explicit
    # trigger (mention/reply/wake word) to reach the engagement stage. The
    # engagement scoring system already decides whether to actually reply based
    # on engagement thresholds. Only "vc" mode requires explicit triggers for
    # chat engagement (since VC mode is primarily about voice, not text).
    # V46/V47 incorrectly rejected ALL ambient group messages before engagement
    # scoring could run, even in "chat" mode.
    trigger = await _talkative_userbot_detect_trigger(event, is_private, settings)
    _record_stage("trigger", {"type": trigger, "is_private": is_private})
    if trigger is None:
        if is_private:
            # DMs should always trigger — this is unexpected.
            _record_stage("trigger", {"rejected": True}, terminal="no_trigger_dm")
            logger.debug("TALKATIVE_REJECT reason=no_trigger_dm chat=%s", chat_id)
            return
        # V48 Fix: for groups in "chat" or "both" mode, allow ambient messages
        # through to engagement scoring. The trigger is "ambient" — the
        # engagement scorer will apply the threshold to decide whether to reply.
        # Only reject if the mode is "vc" (VC-only mode should not engage on
        # ambient text — only explicit triggers).
        if mode in ("chat", "both"):
            trigger = "ambient"
            _record_stage("trigger", {"type": "ambient", "allowed": True})
        else:
            # mode is "vc" — explicit trigger required for text chat.
            _record_stage("trigger", {"rejected": True}, terminal="group_trigger_rejected")
            logger.debug("TALKATIVE_REJECT reason=group_trigger_rejected chat=%s mode=%s", chat_id, mode)
            return

    # Cooldown.
    cooldown_seconds = int(settings.get("cooldown_seconds",
                                        config.talkative_cooldown_seconds))
    allowed, remaining = _talkative_check_cooldown(chat_id, sender_id, cooldown_seconds)
    _record_stage("cooldown", {"allowed": allowed, "remaining": round(remaining, 1)})
    if not allowed:
        _record_stage("cooldown", {"rejected": True}, terminal="cooldown")
        logger.debug("TALKATIVE_REJECT reason=cooldown chat=%s sender=%s remaining=%.1fs",
                    chat_id, sender_id, remaining)
        return

    # Global RPM.
    rpm_ok = _talkative_check_global_rpm(int(config.talkative_global_rpm))
    _record_stage("rpm", {"allowed": rpm_ok})
    if not rpm_ok:
        _record_stage("rpm", {"rejected": True}, terminal="global_rpm")
        logger.debug("TALKATIVE_REJECT reason=global_rpm chat=%s", chat_id)
        return

    # Canonical event claim (#19).
    sender_name = (getattr(sender, "first_name", None)
                   or getattr(sender, "username", None) or str(sender_id))
    a_ctx = await _adaptive_get_context(chat_id)
    # V54 Fix #1: for media-only messages, use a placeholder text describing the media.
    context_text = text if text else f"[{media_type} message]" if media_type else "[empty]"
    a_ctx.add_turn(sender_id, sender_name, context_text,
                   role="user", source="chat")
    a_ctx.reset_consecutive_bot()

    # Engagement decision.
    try:
        engagement_score, eng_reason = await _adaptive_engagement_score(
            a_ctx, trigger=trigger, user_id=sender_id,
            text=context_text, is_private=is_private, settings=settings,
        )
    except Exception as exc:  # noqa: BLE001
        engagement_score, eng_reason = 0.0, "scoring_error"
        _record_stage("engagement", {"error": str(type(exc).__name__)}, terminal="engagement_scoring_error")

    _record_stage("engagement", {"score": round(engagement_score, 2), "reason": eng_reason,
                                  "threshold": config.talkative_engagement_threshold})
    if engagement_score < config.talkative_engagement_threshold:
        _talkative_engine_metrics["replies_suppressed"] += 1
        # V49 Fix: preserve score+reason in the rejection diagnostic.
        # V48 overwrote the engagement stage with {"rejected": True, "threshold": ...},
        # losing the actual score and reason. Now we keep all fields.
        _record_stage("engagement", {"score": round(engagement_score, 2), "reason": eng_reason,
                                      "rejected": True, "threshold": config.talkative_engagement_threshold},
                      terminal="engagement_rejected")
        logger.debug("TALKATIVE_REJECT reason=engagement_rejected chat=%s score=%.2f reason=%s",
                    chat_id, engagement_score, eng_reason)
        return

    # P5 UPGRADE (Task 3): Wit.ai intent detection wired into the Talkative
    # pipeline. Runs AFTER the engagement-threshold gate so we don't burn a
    # Wit.ai call on messages we would have rejected anyway. The call is
    # wrapped in try/except — if Wit.ai is down / not configured, the local
    # fallback inside _multimodal_detect_intent still returns a usable
    # intent, and any unexpected exception is swallowed so the Talkative
    # pipeline keeps working.
    detected_intent = ""
    intent_confidence = 0.0
    try:
        from .multimodal import _multimodal_detect_intent
        _intent_info = await _multimodal_detect_intent(context_text)
        detected_intent = str(_intent_info.get("intent", "") or "").strip().lower()
        try:
            intent_confidence = float(_intent_info.get("confidence", 0.0) or 0.0)
        except (TypeError, ValueError):
            intent_confidence = 0.0
    except Exception as intent_exc:  # noqa: BLE001 — Wit.ai must NEVER break Talkative
        logger.debug("TALKATIVE_INTENT_DETECT_ERROR chat=%s exc=%s: %s",
                     chat_id, type(intent_exc).__name__, str(intent_exc)[:120])
        detected_intent, intent_confidence = "", 0.0
    _record_stage("intent", {"intent": detected_intent or "unknown",
                              "confidence": round(intent_confidence, 2)})
    if detected_intent:
        logger.debug("TALKATIVE_INTENT chat=%s intent=%s confidence=%.2f",
                     chat_id, detected_intent, intent_confidence)
    # P5: skip reply for intents that should NOT trigger a conversational
    # response — "command" (let the command handler own it) and "farewell"
    # (don't say goodbye unprompted; the user is leaving, not engaging).
    # Greetings / thanks / questions / statements still flow through.
    if detected_intent in ("command", "farewell"):
        _talkative_engine_metrics["replies_suppressed"] += 1
        _record_stage("intent", {"intent": detected_intent, "rejected": True},
                      terminal=f"intent_{detected_intent}_skip")
        logger.debug("TALKATIVE_REJECT reason=intent_%s_skip chat=%s",
                     detected_intent, chat_id)
        return

    # Anti-spam budget.
    spam_ok, spam_reason = a_ctx.check_spam_budget()
    _record_stage("spam_budget", {"ok": spam_ok, "reason": spam_reason})
    if not spam_ok:
        _talkative_engine_metrics["replies_suppressed"] += 1
        _record_stage("spam_budget", {"rejected": True}, terminal="spam_budget")
        logger.debug("TALKATIVE_REJECT reason=spam_budget chat=%s reason=%s", chat_id, spam_reason)
        return

    # Consecutive-bot guard — don't let the bot reply too many times in a row.
    # V50 Fix: use the correct attribute name `consecutive_bot_messages`
    # (V46 used `consecutive_bot` which doesn't exist → AttributeError crash).
    if a_ctx.consecutive_bot_messages >= config.talkative_max_consecutive_bot:
        _talkative_engine_metrics["replies_suppressed"] += 1
        _record_stage("consecutive_bot", {"count": a_ctx.consecutive_bot_messages, "limit": config.talkative_max_consecutive_bot},
                      terminal="consecutive_bot_limit")
        logger.debug("TALKATIVE_REJECT reason=consecutive_bot_limit chat=%s count=%d",
                    chat_id, a_ctx.consecutive_bot_messages)
        return
    _record_stage("consecutive_bot", {"count": a_ctx.consecutive_bot_messages, "ok": True})

    # Claim response slot.
    event_id = f"telethon:{chat_id}:{event.id}"
    claim_ok = await _adaptive_claim_response(a_ctx, event_id)
    _record_stage("duplicate_claim", {"claimed": claim_ok})
    if not claim_ok:
        _talkative_engine_metrics["duplicate_blocked"] += 1
        _record_stage("duplicate_claim", {"rejected": True}, terminal="duplicate_claim")
        logger.debug("TALKATIVE_REJECT reason=duplicate_claim chat=%s event=%s", chat_id, event.id)
        return
    # V42 Fix #13: demote routine ACCEPTED to DEBUG.
    logger.debug("TALKATIVE_ACCEPTED chat=%s event=%s mode=%s trigger=%s",
                chat_id, event.id, mode, trigger)

    # V51 Fix #5: check send permission BEFORE expensive provider generation.
    # If the chat is known to be non-writable, skip generation entirely.
    perm_allowed, perm_reason = _send_perm_check(chat_id)
    _record_stage("send_permission", {"allowed": perm_allowed, "reason": perm_reason})
    if not perm_allowed:
        _talkative_engine_metrics["replies_suppressed"] += 1
        _record_stage("send_permission", {"rejected": True},
                      terminal=f"send_{perm_reason}")
        logger.debug("TALKATIVE_REJECT reason=send_%s chat=%s (cached)", perm_reason, chat_id)
        return

    try:
        # V86 (P6 Task 2): Try the Media Reaction Engine FIRST — it may send
        # a sticker / GIF / emoji reaction instead of (or in addition to) a
        # text reply.  If it returns "media_sent", skip text generation
        # entirely.  On any error, fall through to text generation.
        #
        # Adaptation: the Media Reaction Engine was written against the
        # python-telegram-bot (PTB) API, but this handler is a TELETHON
        # userbot handler.  We pass a duck-typed _TelethonMediaAdapter that
        # masquerades as BOTH the PTB `update` and the PTB `context` (it
        # exposes .effective_chat / .message / .bot with PTB-shaped methods
        # that delegate to the live Telethon client).  Insertion is INSIDE
        # the try/finally so the response-slot claim is released on return.
        try:
            _media_client = mtproto_get_client()
            _media_adapter = _TelethonMediaAdapter(
                event, _media_client, is_private=is_private,
            )
            media_result = await talkative_media_process(
                _media_adapter, _media_adapter,
                trigger=trigger, text=context_text,
                a_ctx=a_ctx, settings=settings,
            )
            if media_result == "media_sent":
                logger.info("TALKATIVE_MEDIA_SENT chat=%s intent_trigger=%s",
                            chat_id, trigger)
                _record_stage("media_engine", {"result": "media_sent"},
                              terminal="media_sent")
                _talkative_set_cooldown(chat_id, sender_id)
                _talkative_record_rpm()
                return  # media replaced text
            if media_result == "reaction_sent":
                _record_stage("media_engine", {"result": "reaction_sent"})
                # Reaction is a light touch — fall through to text generation.
        except Exception as exc:  # noqa: BLE001
            logger.debug("TALKATIVE_MEDIA_ENGINE_ERROR exc=%s: %s",
                         type(exc).__name__, str(exc)[:120])
            _record_stage("media_engine", {"error": type(exc).__name__})
            # Fall through to text generation on any error.

        # Gather memory + context.
        memory_turns = int(settings.get("memory_turns", config.talkative_memory_turns))
        try:
            memory = await talkative_get_memory(chat_id, sender_id, limit=memory_turns * 2)
        except Exception:  # noqa: BLE001
            memory = []

        messages: list[dict[str, str]] = []
        # Compact summary.
        if a_ctx.compact_summary:
            messages.append({"role": "system", "content": f"Summary: {a_ctx.compact_summary}"})
        # Recent turns from adaptive context.
        for turn in a_ctx.recent_turns[-8:]:
            messages.append({"role": turn["role"], "content": turn["content"]})
        # Memory.
        for m in memory:
            messages.append({"role": m.get("role", "user"), "content": m.get("content", "")})
        # Current message — V54 Fix #1: use context_text for media-only messages.
        messages.append({"role": "user", "content": context_text})

        _talkative_record_chat_message(chat_id, "user", context_text)

        # V41 Fix #7: use the EFFECTIVE provider (dashboard DB → env → default),
        # not just settings.provider which may fall through to env default.
        try:
            eff_provider, eff_psrc, eff_model, eff_ready, eff_reason = (
                await talkative_effective_provider())
        except Exception:  # noqa: BLE001
            eff_provider, eff_psrc, eff_model, eff_ready, eff_reason = (
                config.talkative_provider, "error", "", False, "resolver_error")
        if not eff_ready:
            # V85.3 FIX BUG C1: distinguish "no key configured" (hard reject)
            # from "in cooldown" (proceed so the fallback chain inside
            # talkative_generate can skip the cooled-down primary and try
            # the configured fallback providers).  Previously the bot
            # hard-rejected whenever the primary was in cooldown, making
            # the fallback chain unreachable.
            if "not configured" in eff_reason or "unknown provider" in eff_reason:
                _record_stage("provider", {"ready": False, "reason": eff_reason}, terminal="provider_unavailable")
                logger.warning(
                    "TALKATIVE_REJECT reason=provider_unavailable chat=%s provider=%s reason=%s",
                    chat_id, eff_provider, eff_reason)
                return
            # Cooldown / transient — log + fall through to talkative_generate
            # so the fallback chain gets a chance.
            _record_stage("provider", {"ready": False, "cooldown": True,
                                       "reason": eff_reason, "fallback_attempt": True})
            logger.info(
                "TALKATIVE_PROVIDER_COOLDOWN chat=%s provider=%s reason=%s — "
                "attempting fallback chain",
                chat_id, eff_provider, eff_reason)
        _record_stage("provider", {"ready": True, "name": eff_provider, "source": eff_psrc})
        # Model routing — use the effective provider.
        # V55 Fix #1: use context_text consistently for all downstream processing.
        routing = _adaptive_route_model(context_text, source="chat",
                                        configured_provider=eff_provider)
        max_chars = min(int(config.talkative_max_reply_chars),
                        _adaptive_response_length_guidance(context_text, source="chat"))
        call_settings = {
            "provider": routing["provider"],
            "max_reply_chars": max_chars,
            "request_timeout": config.talkative_request_timeout,
        }

        # V55 Fix #1: language detection on placeholder strings like [voice message]
        # is meaningless. For media-only input, use "auto" unless real STT provided
        # a transcript (which would be in context_text as actual text).
        # P5 (Task 6): _adaptive_detect_language already detects JP (Hiragana/
        # Katakana) and KO (Hangul) via Unicode block analysis — verified.
        if text:
            detected_lang = _adaptive_detect_language(text)
        else:
            detected_lang = "auto"  # media-only — no text to detect language from
        # P5: cache the detected language on the context so subsequent turns
        # can use it even if the next message is media-only.
        try:
            a_ctx.detected_language = detected_lang
        except Exception:  # noqa: BLE001
            pass
        chat_title = getattr(chat, "title", "") or ""
        # P5 (Tasks 1, 3, 6): pass detected intent + language + recent
        # conversation summary into the upgraded system-prompt builder so
        # the LLM gets richer context. The standalone "Reply in:" line is
        # no longer needed — it's folded into the prompt builder.
        try:
            _conv_summary = (a_ctx.compact_summary or "")[:400]
        except Exception:  # noqa: BLE001
            _conv_summary = ""
        system_prompt = _talkative_build_system_prompt(
            settings, trigger, chat_title,
            intent=detected_intent,
            detected_language=detected_lang,
            conversation_summary=_conv_summary,
        )

        # V42 Fix #13: demote routine provider start to DEBUG.
        logger.debug(
            "TALKATIVE_PROVIDER_START chat=%s provider=%s source=%s model=%s",
            chat_id, routing["provider"], eff_psrc, eff_model)
        try:
            result = await talkative_generate(messages, system_prompt, call_settings)
            _talkative_engine_metrics["replies_generated"] += 1
            _record_stage("generation_result", {"success": True, "provider": routing["provider"]})
            # V42 Fix #13: demote routine success to DEBUG.
            logger.debug(
                "TALKATIVE_GENERATION_SUCCESS chat=%s provider=%s source=%s",
                chat_id, routing["provider"], eff_psrc)
        except Exception as exc:  # noqa: BLE001
            _talkative_engine_metrics["llm_failures"] += 1
            _record_stage("generation_result", {"success": False, "error": type(exc).__name__}, terminal="generation_failed")
            # V44 Fix #1: promote generation failure to ERROR (actionable).
            logger.error(
                "TALKATIVE_GENERATION_FAILED chat=%s provider=%s exc=%s: %s",
                chat_id, routing["provider"], type(exc).__name__, _sanitize_error(str(exc))[:100])
            return

        reply_text = (result.text or "").strip()
        if not reply_text:
            _record_stage("generation_result", {"success": True, "empty": True}, terminal="empty_transcript")
            logger.debug("TALKATIVE_REJECT reason=empty_transcript chat=%s provider=%s",
                        chat_id, routing["provider"])
            return

        # Duplicate suppression.
        if a_ctx.is_duplicate_reply(reply_text):
            _talkative_engine_metrics["duplicate_blocked"] += 1
            _record_stage("duplicate_reply", {"blocked": True}, terminal="duplicate_reply")
            logger.debug("TALKATIVE_REJECT reason=duplicate_reply chat=%s", chat_id)
            return

        # Stale check.
        if await _adaptive_check_stale(a_ctx, event_id, max_age=10.0):
            _talkative_engine_metrics["stale_cancelled"] += 1
            _record_stage("stale_check", {"stale": True}, terminal="stale_cancelled")
            logger.debug("TALKATIVE_REJECT reason=stale_cancelled chat=%s event=%s", chat_id, event_id)
            return
        _record_stage("stale_check", {"stale": False})

        # Send via userbot.
        try:
            # V92 FIX: guard against TypeError "Cannot cast NoneType to any
            # kind of Peer" — this happens when event.get_chat() returned None
            # (entity resolution failed) and event.reply() tries to resolve
            # the peer internally. Use the explicit chat_id + client.send_message
            # with a fallback to event.reply only if the entity is resolvable.
            _sent = False
            try:
                _client = mtproto_get_client()
                if _client is not None and chat_id:
                    await _client.send_message(
                        int(chat_id), reply_text, link_preview=False)
                    _sent = True
            except Exception as _send_exc:  # noqa: BLE001
                # Fall back to event.reply — but only if the event has a
                # resolvable peer (not None).
                if "NoneType" not in str(_send_exc) and "Cannot cast" not in str(_send_exc):
                    try:
                        await event.reply(reply_text, link_preview=False)
                        _sent = True
                    except Exception:
                        _sent = False
            if not _sent:
                raise TypeError(
                    f"Cannot send reply to chat_id={chat_id} — peer unresolved "
                    f"(entity resolution returned None)"
                )
            _talkative_engine_metrics["replies_sent"] += 1
            _record_stage("send_result", {"success": True, "len": len(reply_text)})
            _record_stage("terminal_reason", "send_success")
            # V42 Fix #13: demote routine reply-sent to DEBUG.
            logger.debug(
                "TALKATIVE_USERBOT_REPLY_SENT chat=%s sender=%s len=%d provider=%s source=%s",
                chat_id, sender_id, len(reply_text), routing["provider"], eff_psrc)
        except Exception as exc:  # noqa: BLE001
            # V51 Fix #5: classify permanent permission failures and cache them.
            exc_name = type(exc).__name__
            if exc_name == "ChatWriteForbiddenError":
                _send_perm_mark_forbidden(chat_id, "forbidden")
                _record_stage("send_result", {"success": False, "error": exc_name},
                              terminal="send_forbidden")
                logger.error("TALKATIVE_SEND_FORBIDDEN chat=%s — cached for %ds",
                            chat_id, int(_SEND_PERM_TTL))
                return
            elif exc_name == "ChatAdminRequiredError":
                _send_perm_mark_forbidden(chat_id, "admin_required")
                _record_stage("send_result", {"success": False, "error": exc_name},
                              terminal="send_admin_required")
                logger.error("TALKATIVE_SEND_ADMIN_REQUIRED chat=%s — cached for %ds",
                            chat_id, int(_SEND_PERM_TTL))
                return
            elif exc_name == "UserBannedInChannelError":
                _send_perm_mark_forbidden(chat_id, "banned")
                _record_stage("send_result", {"success": False, "error": exc_name},
                              terminal="send_banned")
                logger.error("TALKATIVE_SEND_BANNED chat=%s — cached for %ds",
                            chat_id, int(_SEND_PERM_TTL))
                return
            else:
                # Transient or unknown failure — don't cache.
                _record_stage("send_result", {"success": False, "error": exc_name},
                              terminal="send_failed")
                logger.error("TALKATIVE_SEND_FAILED chat=%s exc=%s: %s",
                            chat_id, exc_name, _sanitize_error(str(exc))[:100])
                return

        # Memory + context update.
        try:
            # V55 Fix #8: use context_text, not raw text (which may be empty for media).
            await talkative_add_memory(chat_id, sender_id, "user", context_text)
            await talkative_add_memory(chat_id, sender_id, "assistant", reply_text)
            await talkative_trim_memory(chat_id, sender_id, memory_turns * 2)
        except Exception:  # noqa: BLE001
            pass
        _talkative_record_chat_message(chat_id, "assistant", reply_text)
        a_ctx.add_turn(0, "userbot", reply_text, role="assistant", source="chat")
        a_ctx.add_bot_reply(reply_text)

        # Stats + cooldown.
        try:
            await talkative_add_stat(chat_id, sender_id, trigger, result.provider, True)
        except Exception:  # noqa: BLE001
            pass
        _talkative_set_cooldown(chat_id, sender_id)
        _talkative_record_rpm()
        # V86 (P6 Task 3): a text reply succeeded (the Media Reaction Engine
        # either returned None or "reaction_sent").  Reset the per-chat
        # consecutive-media counter so the engine isn't permanently disabled
        # after hitting the max_consecutive cap (fixes the prior audit's
        # dead-code finding — _media_reset_consecutive was never invoked).
        try:
            await _media_reset_consecutive(chat_id)
        except Exception:  # noqa: BLE001
            pass

    finally:
        await _adaptive_release_response(a_ctx, event_id)


async def _talkative_userbot_detect_trigger(
    event, is_private: bool, settings: dict[str, Any],
) -> "Optional[str]":
    """V47 Fix: detect trigger for Telethon userbot messages with bounded reasons.

    Fix 2: Uses cached _userbot_id / _userbot_username / _userbot_display_name
    for mention/name/reply detection. NEVER uses Bot API bot identity.

    V47 changes:
    - For groups: checks Telegram message entities for proper mention detection
      (not just text substring match). Also checks username normalization,
      reply-to-userbot, configured wake words, and active sessions.
    - Returns a trigger string on success, or None on rejection.
    - The caller records the exact rejection reason via _record_stage.

    For private DM: always trigger (no wake word required).
    For groups: mention / reply-to-userbot / wake word / follow-up.

    V54 Fix #1: media-only messages are also valid triggers in private DMs.
    """
    text = (event.raw_text or "").strip()
    # V54 Fix #1: don't return None for media-only messages.
    # Check if there's media instead.
    if not text:
        # Check for media — if there's media, it's a valid event.
        media_type = _classify_telethon_media(event)
        if not media_type:
            return None  # no text and no media
        # V54 Fix #1: media-only DMs always trigger.
        if is_private:
            return "private_media"
        # For groups, media-only messages are treated as ambient.
        return None  # groups still need text-based trigger for media-only

    # Private DM: always respond (no wake word required).
    if is_private:
        return "private"

    # V47 Fix: check userbot identity availability first.
    if _userbot_id is None and not _userbot_username:
        # Cannot detect any trigger without userbot identity.
        return None

    # V47 Fix: check Telegram message entities for proper mention detection.
    # Telethon exposes entities via event.get_entities() or event.entities.
    # A MentionEntity contains the username (without @).
    try:
        entities = event.entities or []
        for ent in entities:
            # Telethon's MessageEntityMention has a `user_id` for text mentions
            # or just the username string for @mentions.
            ent_type = type(ent).__name__
            if ent_type == "MessageEntityMention":
                # Extract the mentioned text from the message.
                start = getattr(ent, "offset", 0)
                length = getattr(ent, "length", 0)
                if start is not None and length is not None and length > 0:
                    mentioned_text = text[start:start + length].lstrip("@").lower()
                    if _userbot_username:
                        uname = _userbot_username.lstrip("@").lower()
                        if mentioned_text == uname:
                            return "mention"
            elif ent_type == "MessageEntityTextLink":
                # Could be a t.me link to the userbot.
                url = getattr(ent, "url", "") or ""
                if _userbot_username:
                    uname = _userbot_username.lstrip("@").lower()
                    if f"t.me/{uname}" in url.lower() or f"telegram.me/{uname}" in url.lower():
                        return "mention"
    except Exception:  # noqa: BLE001
        pass

    # V47 Fix: fallback text-based mention check (for clients that don't
    # send entities, or for copy-pasted mentions).
    if _userbot_username:
        uname = _userbot_username.lstrip("@").lower()
        # Check both @username and bare username with word boundary.
        if f"@{uname}" in text.lower():
            return "mention"
        # Also check word-boundary match (e.g. "Gradieer" without @).
        if _talkative_word_boundary_match(text, uname):
            return "mention"

    # Reply to userbot — use cached _userbot_id.
    try:
        reply = await event.get_reply_message()
        if reply is not None:
            reply_from = getattr(reply, "from_id", None)
            if reply_from is not None and _userbot_id is not None:
                reply_user_id = getattr(reply_from, "user_id", None)
                if reply_user_id and reply_user_id == _userbot_id:
                    return "reply"
    except Exception:  # noqa: BLE001
        pass

    # Userbot display name — use cached _userbot_display_name.
    if _userbot_display_name:
        if _talkative_word_boundary_match(text, _userbot_display_name):
            return "name"

    # Wake words.
    try:
        chat_id = getattr(event, "chat_id", 0)
        wake_words = await talkative_get_wake_words(chat_id)
        for w in wake_words:
            word = (w.get("wake_word") or "").strip()
            if word and _talkative_word_boundary_match(text, word):
                return "wake_word"
    except Exception:  # noqa: BLE001
        pass

    # Active session (follow-up conversation — no repeated wake word required).
    try:
        chat_id = getattr(event, "chat_id", 0)
        sender_id = getattr(event, "sender_id", 0)
        session = await talkative_get_active_session(chat_id, sender_id)
        if session is not None:
            return "active_session"
    except Exception:  # noqa: BLE001
        pass

    return None


# --- In-group text command handler (registered with MTProto) ----------------


@dataclass
class TalkativeResult:
    """Outcome of a Talkative provider call."""
    text: str
    provider: str
    model: str
    success: bool
    error: str = ""


# In-memory per-chat message cache for group context (bounded ring buffer).
# V85.5 FIX (PERF-G-002): use OrderedDict so we get O(1) move_to_end /
# popitem(last=False) for LRU eviction of whole chats. The per-chat list
# is still bounded to _TALKATIVE_HISTORY_MAX entries; the dict itself is
# bounded to _TALKATIVE_HISTORY_MAX_CHATS chats.


_talkative_chat_history: "OrderedDict[int, list[dict[str, str]]]" = OrderedDict()


_TALKATIVE_HISTORY_MAX = 64  # max entries per chat


_TALKATIVE_HISTORY_MAX_CHATS = 500  # V85.5 FIX (PERF-G-002): max tracked chats

# Per-(chat_id, user_id) cooldown timestamps (monotonic).


_talkative_cooldowns: dict[tuple[int, int], float] = {}

# Global RPM sliding-window (monotonic timestamps of recent successes).
# V85.5 FIX (PERF-G-001): use collections.deque so popleft() is O(1)
# instead of the O(n) list.pop(0) it replaced.
from collections import deque as _deque


_talkative_rpm_window: _deque[float] = _deque()

# Background cleanup task handle (cancelled in _post_stop).


_talkative_cleanup_task: Optional[asyncio.Task] = None

# httpx client (lazily created, closed in _post_stop).


_talkative_http_client: Optional[httpx.AsyncClient] = None

# v97 FIX: module-level initialization of the handler registration flag.
# Previously this was only set inside talkative_userbot_register_handler()
# via `global`, but was NEVER initialized at module scope. When
# talkative_handle_message() read it at line 5387 before registration
# had been called, Python raised NameError: name
# '_talkative_userbot_handler_registered' is not defined.
_talkative_userbot_handler_registered: bool = False


def _talkative_record_chat_message(chat_id: int, role: str, content: str) -> None:
    """Append a message to the in-memory chat-history cache (bounded).

    V85.5 FIX (PERF-G-002): ``_talkative_chat_history`` is now an
    OrderedDict. After appending, we ``move_to_end(chat_id)`` so the
    most-recently-active chat is always at the tail, then evict the
    least-recently-active chats (``popitem(last=False)``) if the dict
    exceeds ``_TALKATIVE_HISTORY_MAX_CHATS``.
    """
    if chat_id == 0:
        return
    history = _talkative_chat_history.setdefault(chat_id, [])
    history.append({"role": role, "content": content})
    if len(history) > _TALKATIVE_HISTORY_MAX:
        del history[: len(history) - _TALKATIVE_HISTORY_MAX]
    # PERF-G-002: LRU-evict the least-recently-active chat if we've hit
    # the chat-count cap. move_to_end keeps this chat at the tail.
    _talkative_chat_history.move_to_end(chat_id)
    while len(_talkative_chat_history) > _TALKATIVE_HISTORY_MAX_CHATS:
        _talkative_chat_history.popitem(last=False)


def _talkative_get_group_context(chat_id: int, limit: int) -> list[dict[str, str]]:
    """Return the most recent ``limit`` chat messages for group context."""
    if chat_id == 0 or limit <= 0:
        return []
    history = _talkative_chat_history.get(chat_id, [])
    if not history:
        return []
    return history[-limit:]


def _talkative_check_cooldown(chat_id: int, user_id: int,
                              cooldown_seconds: int) -> tuple[bool, float]:
    """Return (allowed, remaining_seconds)."""
    if cooldown_seconds <= 0:
        return True, 0.0
    key = (chat_id, user_id)
    now = time.monotonic()
    last = _talkative_cooldowns.get(key, 0.0)
    elapsed = now - last
    if elapsed < cooldown_seconds:
        return False, (cooldown_seconds - elapsed)
    return True, 0.0


def _talkative_set_cooldown(chat_id: int, user_id: int) -> None:
    _talkative_cooldowns[(chat_id, user_id)] = time.monotonic()


def _talkative_check_global_rpm(rpm_limit: int) -> bool:
    """Sliding-window rate limit. Returns True if a new request is allowed.

    NOTE: This function ONLY checks; it does NOT record a timestamp. The
    caller is responsible for calling ``_talkative_record_rpm()`` after a
    successful reply (so a failed request doesn't consume quota).
    """
    if rpm_limit <= 0:
        return True
    now = time.monotonic()
    # Drop entries older than 60s.
    cutoff = now - 60.0
    # V85.5 FIX (PERF-G-001): deque.popleft() is O(1).
    while _talkative_rpm_window and _talkative_rpm_window[0] < cutoff:
        _talkative_rpm_window.popleft()
    if len(_talkative_rpm_window) >= rpm_limit:
        return False
    return True


def _talkative_record_rpm() -> None:
    """Append a 'now' timestamp to the RPM window."""
    _talkative_rpm_window.append(time.monotonic())


async def _talkative_get_http_client() -> httpx.AsyncClient:
    """Return the shared httpx client (lazily created)."""
    global _talkative_http_client
    if _talkative_http_client is None or _talkative_http_client.is_closed:
        _talkative_http_client = httpx.AsyncClient(
            timeout=httpx.Timeout(config.talkative_request_timeout),
            headers={"User-Agent": "MediaGrabBot-Talkative/1.0"},
        )
    return _talkative_http_client


async def _talkative_close_http_client() -> None:
    global _talkative_http_client
    if _talkative_http_client is not None and not _talkative_http_client.is_closed:
        try:
            await _talkative_http_client.aclose()
        except Exception as exc:  # noqa: BLE001
            logger.debug("Talkative httpx close error: %s", exc)
    _talkative_http_client = None


# --- Provider implementations -----------------------------------------------


async def talkative_groq_request(
    messages: list[dict[str, str]],
    system_prompt: str,
    max_chars: int,
    timeout: int,
) -> TalkativeResult:
    """Call Groq's OpenAI-compatible chat-completions endpoint.

    Never logs the API key. Retries 429 (with Retry-After) and 5xx once with
    exponential backoff. Caps the response to ``max_chars`` characters.
    """
    api_key = config.groq_api_key
    model = config.groq_model or "llama-3.3-70b-versatile"
    if not api_key:
        return TalkativeResult(
            text="", provider="groq", model=model,
            success=False, error="GROQ_API_KEY not configured",
        )
    # Build the request body. Groq expects OpenAI-style messages.
    body_messages: list[dict[str, str]] = []
    if system_prompt:
        body_messages.append({"role": "system", "content": system_prompt})
    body_messages.extend(messages)
    payload = {
        "model": model,
        "messages": body_messages,
        "temperature": 0.7,
        "max_tokens": min(2048, max(256, max_chars // 3)),
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    url = "https://api.groq.com/openai/v1/chat/completions"
    client = await _talkative_get_http_client()

    last_error = ""
    for attempt in range(1, 4):  # 3 attempts max
        try:
            resp = await client.post(
                url, json=payload, headers=headers,
                timeout=httpx.Timeout(timeout),
            )
            if resp.status_code == 429:
                # Rate limited — honour Retry-After if present.
                retry_after = float(resp.headers.get("Retry-After", "5") or "5")
                retry_after = min(max(1.0, retry_after), 30.0)
                last_error = f"Groq 429 rate limited (retry_after={retry_after}s)"
                logger.info("Talkative Groq 429 — sleeping %ss (attempt %d).",
                            retry_after, attempt)
                await asyncio.sleep(retry_after)
                continue
            if 500 <= resp.status_code < 600:
                last_error = f"Groq {resp.status_code} server error"
                backoff = 1.5 ** attempt
                logger.warning("Talkative Groq %d — backing off %ss (attempt %d).",
                               resp.status_code, backoff, attempt)
                await asyncio.sleep(backoff)
                continue
            if resp.status_code in (401, 403):
                # Auth failure — NEVER retry, NEVER log the response body
                # (may contain sensitive info). Classify explicitly as
                # auth_failed so _provider_record_failure sets a 300s cooldown.
                logger.warning("Talkative Groq HTTP %d — authentication failed (key invalid/expired).", resp.status_code)
                return TalkativeResult(
                    text="", provider="groq", model=model,
                    success=False,
                    error=f"Groq HTTP {resp.status_code}: authentication failed (invalid API key)",
                )
            if resp.status_code != 200:
                # Other client error — don't retry. Sanitize the snippet.
                snippet = _sanitize_error(resp.text[:200] if resp.text else "")
                return TalkativeResult(
                    text="", provider="groq", model=model,
                    success=False,
                    error=f"Groq HTTP {resp.status_code}: {snippet}",
                )
            data = resp.json()
            choices = data.get("choices") or []
            if not choices:
                return TalkativeResult(
                    text="", provider="groq", model=model,
                    success=False, error="Groq returned no choices",
                )
            text = (choices[0].get("message") or {}).get("content") or ""
            text = (text or "").strip()
            if max_chars > 0 and len(text) > max_chars:
                text = text[:max_chars]
            return TalkativeResult(
                text=text, provider="groq", model=model,
                success=True,
            )
        except httpx.TimeoutException as exc:
            last_error = f"Groq timeout: {exc}"
            logger.warning("Talkative Groq timeout (attempt %d): %s", attempt, exc)
            await asyncio.sleep(1.0 * attempt)
            continue
        except httpx.HTTPError as exc:
            last_error = f"Groq HTTP error: {exc}"
            logger.warning("Talkative Groq HTTP error (attempt %d): %s", attempt, exc)
            await asyncio.sleep(1.0 * attempt)
            continue
    return TalkativeResult(
        text="", provider="groq", model=model,
        success=False, error=last_error or "Groq exhausted retries",
    )


async def talkative_openrouter_request(
    messages: list[dict[str, str]],
    system_prompt: str,
    max_chars: int,
    timeout: int,
) -> TalkativeResult:
    """Call OpenRouter's chat-completions endpoint."""
    api_key = config.openrouter_api_key
    model = config.openrouter_model
    if not api_key or not model:
        return TalkativeResult(
            text="", provider="openrouter", model=model or "",
            success=False,
            error="OPENROUTER_API_KEY or OPENROUTER_MODEL not configured",
        )
    body_messages: list[dict[str, str]] = []
    if system_prompt:
        body_messages.append({"role": "system", "content": system_prompt})
    body_messages.extend(messages)
    payload = {
        "model": model,
        "messages": body_messages,
        "temperature": 0.7,
        "max_tokens": min(2048, max(256, max_chars // 3)),
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    url = "https://openrouter.ai/api/v1/chat/completions"
    client = await _talkative_get_http_client()

    last_error = ""
    for attempt in range(1, 4):
        try:
            resp = await client.post(
                url, json=payload, headers=headers,
                timeout=httpx.Timeout(timeout),
            )
            if resp.status_code == 429:
                retry_after = float(resp.headers.get("Retry-After", "5") or "5")
                retry_after = min(max(1.0, retry_after), 30.0)
                last_error = f"OpenRouter 429 (retry_after={retry_after}s)"
                await asyncio.sleep(retry_after)
                continue
            if 500 <= resp.status_code < 600:
                last_error = f"OpenRouter {resp.status_code} server error"
                await asyncio.sleep(1.5 ** attempt)
                continue
            if resp.status_code in (401, 403):
                logger.warning("Talkative OpenRouter HTTP %d — authentication failed.", resp.status_code)
                return TalkativeResult(
                    text="", provider="openrouter", model=model,
                    success=False,
                    error=f"OpenRouter HTTP {resp.status_code}: authentication failed (invalid API key)",
                )
            if resp.status_code != 200:
                snippet = _sanitize_error(resp.text[:200] if resp.text else "")
                return TalkativeResult(
                    text="", provider="openrouter", model=model,
                    success=False,
                    error=f"OpenRouter HTTP {resp.status_code}: {snippet}",
                )
            data = resp.json()
            choices = data.get("choices") or []
            if not choices:
                return TalkativeResult(
                    text="", provider="openrouter", model=model,
                    success=False, error="OpenRouter returned no choices",
                )
            text = (choices[0].get("message") or {}).get("content") or ""
            text = (text or "").strip()
            if max_chars > 0 and len(text) > max_chars:
                text = text[:max_chars]
            return TalkativeResult(
                text=text, provider="openrouter", model=model,
                success=True,
            )
        except httpx.TimeoutException as exc:
            last_error = f"OpenRouter timeout: {exc}"
            await asyncio.sleep(1.0 * attempt)
            continue
        except httpx.HTTPError as exc:
            last_error = f"OpenRouter HTTP error: {exc}"
            await asyncio.sleep(1.0 * attempt)
            continue
    return TalkativeResult(
        text="", provider="openrouter", model=model,
        success=False, error=last_error or "OpenRouter exhausted retries",
    )


async def talkative_gemini_request(
    messages: list[dict[str, str]],
    system_prompt: str,
    max_chars: int,
    timeout: int,
) -> TalkativeResult:
    """Use the existing Gemini client as a fallback provider.

    V85.5 FIX (AI-G-001): prefer structured ``contents`` (one ContentDict per
    message, with ``system_instruction`` set on the config) so the model sees
    proper turn boundaries. Falls back to the legacy flat-text prompt if the
    structured call raises (e.g. older SDK without ContentDict support).
    """
    model = config.default_ai_model
    if not config.gemini_api_key:
        return TalkativeResult(
            text="", provider="gemini", model=model,
            success=False, error="GEMINI_API_KEY not configured",
        )
    # Compose a flat prompt (used as fallback).
    flat_parts: list[str] = []
    if system_prompt:
        flat_parts.append(system_prompt)
        flat_parts.append("")
    for m in messages:
        role = m.get("role", "user")
        content = m.get("content", "")
        if role == "assistant":
            flat_parts.append(f"Assistant: {content}")
        elif role == "system":
            flat_parts.append(f"System: {content}")
        else:
            flat_parts.append(f"User: {content}")
    flat_parts.append("")
    flat_parts.append("Assistant:")
    flat_prompt = "\n".join(flat_parts)

    try:
        client = _get_client(None)
        from google.genai import types  # type: ignore

        max_tokens = min(2048, max(256, max_chars // 3))

        # AI-G-001: structured-contents path (preferred).
        async def _structured_call() -> str:
            contents = []
            for m in messages:
                role = m.get("role", "user")
                content = m.get("content", "")
                # Map OpenAI-style roles to Gemini roles. Gemini only
                # accepts "user" and "model"; "system" is handled via
                # system_instruction below, so fold stray system messages
                # into the next user turn's text.
                gemini_role = "user" if role == "user" else "model"
                if role == "system" and not system_prompt:
                    # No system_instruction set — emit as a user turn.
                    contents.append(types.ContentDict(
                        role="user", parts=[types.Part.from_text(text=content)],
                    ))
                    continue
                contents.append(types.ContentDict(
                    role=gemini_role, parts=[types.Part.from_text(text=content)],
                ))
            cfg = types.GenerateContentConfig(
                temperature=0.7,
                max_output_tokens=max_tokens,
            )
            if system_prompt:
                cfg.system_instruction = system_prompt  # type: ignore[attr-defined]

            def _call():
                return client.models.generate_content(
                    model=model,
                    contents=contents,
                    config=cfg,
                )
            response = await asyncio.wait_for(
                _run_in_thread(_call), timeout=float(timeout),
            )
            return _extract_text(response).strip()

        # AI-G-001: flat-text fallback path (legacy).
        async def _flat_call() -> str:
            def _call():
                return client.models.generate_content(
                    model=model,
                    contents=flat_prompt,
                    config=types.GenerateContentConfig(
                        temperature=0.7,
                        max_output_tokens=max_tokens,
                    ),
                )
            response = await asyncio.wait_for(
                _run_in_thread(_call), timeout=float(timeout),
            )
            return _extract_text(response).strip()

        try:
            text = await _structured_call()
        except (AttributeError, TypeError) as _struct_exc:
            # Older SDK without ContentDict/Part.from_text — fall back to flat.
            logger.debug(
                "GEMINI_STRUCTURED_FALLBACK reason=%s: %s — using flat-text prompt",
                type(_struct_exc).__name__, _struct_exc,
            )
            text = await _flat_call()
        except asyncio.TimeoutError:
            return TalkativeResult(
                text="", provider="gemini", model=model,
                success=False, error="Gemini timeout",
            )
        except Exception as _struct_exc:  # noqa: BLE001
            # Any other structured-path failure — try the flat-text path
            # before giving up (preserves the previous behaviour).
            logger.debug(
                "GEMINI_STRUCTURED_FALLBACK reason=%s: %s — using flat-text prompt",
                type(_struct_exc).__name__, _struct_exc,
            )
            try:
                text = await _flat_call()
            except asyncio.TimeoutError:
                return TalkativeResult(
                    text="", provider="gemini", model=model,
                    success=False, error="Gemini timeout",
                )
        if max_chars > 0 and len(text) > max_chars:
            text = text[:max_chars]
        return TalkativeResult(
            text=text, provider="gemini", model=model,
            success=True,
        )
    except asyncio.TimeoutError:
        return TalkativeResult(
            text="", provider="gemini", model=model,
            success=False, error="Gemini timeout",
        )
    except Exception as exc:  # noqa: BLE001
        # Sanitize — Gemini SDK exceptions may embed the API key or
        # sensitive response-body content. Never log raw exc.
        safe_err = _sanitize_error(f"Gemini error: {exc}")
        exc_type = type(exc).__name__
        # Detect auth-related Gemini errors for explicit classification.
        exc_low = str(exc).lower()
        if "permissiondenied" in exc_type.lower() or "unauthenticated" in exc_type.lower() \
           or "api key not valid" in exc_low or "api_key_invalid" in exc_low:
            logger.warning("Talkative Gemini — authentication failed (key invalid/expired).")
            return TalkativeResult(
                text="", provider="gemini", model=model,
                success=False, error="Gemini HTTP 401: authentication failed (invalid API key)",
            )
        return TalkativeResult(
            text="", provider="gemini", model=model,
            success=False, error=safe_err,
        )


# Provider registry (ordered fallback chain).


_TALKATIVE_PROVIDERS: dict[str, Callable[..., Awaitable[TalkativeResult]]] = {
    "groq": talkative_groq_request,
    "openrouter": talkative_openrouter_request,
    "gemini": talkative_gemini_request,
}


# ===========================================================================
# V62 Provider Health Subsystem — deterministic classifier, atomic state
# machine, generation-guarded notifications, reservation-vs-delivery
# separation, confirmed recovery, sanitized reasons.
#
# V61 → V62 FIXES (17 issues):
#   1. HTTP status precedence over broad keyword heuristics.
#   2. 401 and 403 classified separately (403 → `forbidden`).
#   3. Unknown errors → `unknown_error` (NOT `provider_internal_error`).
#   4. Humanized reason consistent with authoritative status.
#   5. Dedicated `forbidden` class in all maps/sets/UI.
#   6. Billing keywords narrowed; cannot override conflicting HTTP status.
#   7. `unknown_error` not in serious alert classes.
#   8. Notification send-time guard: generation + state + reservation token.
#   9. Notification reservation separated from delivered state.
#  10. Recovery DM depends on *delivered* failure notification.
#  11. Stale success accounting: validate generation BEFORE metrics.
#  12. Successes during active cooldown do NOT count toward recovery.
#  13. Sync wrappers retained but logged if called from async context.
#  14. Provider states initialized at startup (no lazy concurrent mutation).
#  15. Legacy `_recovery_notify_supervised` routed through authoritative path.
#  16. Provider-specific key button (OpenRouter failure never opens Gemini key).
#  17. Stronger secret redaction (sk-*, bearer, x-api-key, query-string keys).
# ===========================================================================


_provider_health: dict[str, dict[str, Any]] = {}
"""Per-provider health state. Keys: provider name. Values: dict with:
  state: untested | healthy | failing | recovering
  generation: monotonic failure epoch (incremented on healthy/recovering → failing)
  failure_class: last failure class ("" if healthy)
  cooldown_until: monotonic timestamp when cooldown ends (0 = no cooldown)
  cooldown_seconds: current cooldown duration (for exponential backoff)
  last_error: sanitized short reason (no API keys / payloads)
  last_failure_at: monotonic timestamp of last failure
  last_success_at: monotonic timestamp of last success
  total_failures: cumulative counter
  total_successes: cumulative counter (raw telemetry — includes stale)
  total_eligible_successes: success count that passed generation check
  consecutive_successes: recovery confirmation counter (reset on failure)
  recovery_candidate_since: monotonic timestamp when recovery candidacy started
  alert_sent: True if failure alert was DELIVERED for current episode
  last_alert_at: monotonic timestamp of last delivered failure DM
  last_alert_generation: generation for which last failure DM was DELIVERED
  last_recovery_at: monotonic timestamp of last delivered recovery DM
  last_notification_type: last DELIVERED notification type ("failure"|"recovery"|"")
  last_notification_generation: generation for which last DM was DELIVERED
  # V62 Fix #9: reservation fields (separate from delivered).
  pending_notification_type: "" | "failure" | "recovery"
  pending_notification_generation: generation reserved for
  pending_notification_token: unique token to validate the reservation
  last_delivered_notification_type: "failure" | "recovery" | ""
  last_delivered_notification_generation: generation actually delivered
  last_delivered_notification_at: monotonic timestamp of confirmed delivery
"""


_provider_locks: dict[str, asyncio.Lock] = {}
"""Per-provider async lock. All state transitions are atomic under this lock.
Notification network I/O occurs OUTSIDE the lock."""

# V61 Fix #3: recovery confirmation thresholds.


_PROVIDER_RECOVERY_MIN_SUCCESSES = 2


_PROVIDER_RECOVERY_STABILITY_SECONDS = 5.0

# V62 Fix #5: Cooldown durations (seconds) by failure class.
# `forbidden` gets a moderate cooldown (not as long as auth_failed — 403 may
# be a transient policy restriction, not a bad key).


_PROVIDER_COOLDOWN = {
    "resource_exhausted": 60.0,      # 1 min base, exponential backoff
    "billing_exhausted": 300.0,     # 5 min — credits issue, don't retry fast
    "rate_limited": 30.0,
    "auth_failed": 300.0,            # 5 min — key is wrong, no point retrying fast
    "forbidden": 120.0,             # V62: 2 min — permission/policy, moderate
    "timeout": 15.0,
    "network_failure": 10.0,
    "invalid_request": 60.0,         # bad request won't fix itself
    "model_unavailable": 120.0,
    "provider_internal_error": 30.0,
    "cancelled": 0.0,                # no cooldown for cancellation
    "unknown_error": 15.0,          # V62: short cooldown, don't storm
}

# Max cooldown cap (seconds).


_PROVIDER_COOLDOWN_MAX = 3600.0  # 1 hour

# Admin alert dedup: suppress repeated identical alerts for this long.


_PROVIDER_ALERT_DEDUP_SECONDS = 300.0  # 5 min

# V62 Fix #5/#7: Failure classes considered "serious" (warrant admin alert).
# `forbidden` IS serious (admin should know about access denial).
# `unknown_error` is NOT serious (no evidence of real outage).


_PROVIDER_SERIOUS_CLASSES = frozenset({
    "resource_exhausted", "auth_failed", "forbidden", "model_unavailable",
    "provider_internal_error", "billing_exhausted",
})

# V62 Fix #16: provider-specific key button policy.
# Only `auth_failed` gets the "Add API Key" button. Other classes get
# class-specific remediation guidance instead.


_PROVIDER_KEY_BUTTON_CLASSES = frozenset({"auth_failed"})

# V62: known providers initialized at startup to avoid lazy concurrent mutation.


_KNOWN_PROVIDERS = ("groq", "openrouter", "gemini")

# V85.5 FIX (ASYNC-G-002): strong-reference set for fire-and-forget provider
# notification tasks so the asyncio scheduler doesn't garbage-collect them
# mid-flight. Applies to both failure and recovery notifications.


_provider_notify_tasks: set = set()


def _provider_spawn_notify_task(coro: Awaitable[Any]) -> None:
    """ASYNC-G-002: schedule a provider-notification coroutine as a
    strong-referenced background task.

    The task is added to ``_provider_notify_tasks`` and removed via a
    done-callback, so the asyncio scheduler can never garbage-collect it
    before it completes. Best-effort: if no event loop is running, the
    coroutine is silently dropped (preserving the previous behaviour).
    """
    try:
        t = asyncio.create_task(coro)
    except RuntimeError:
        return  # no running loop
    _provider_notify_tasks.add(t)
    t.add_done_callback(_provider_notify_tasks.discard)


def _provider_lock(provider: str) -> asyncio.Lock:
    """Get or create the per-provider asyncio.Lock.

    Lazy creation is safe because asyncio is single-threaded — this function
    has no await points, so two coroutines cannot interleave here. Under GIL,
    dict get/set is atomic.
    """
    lock = _provider_locks.get(provider)
    if lock is None:
        lock = asyncio.Lock()
        _provider_locks[provider] = lock
    return lock


def _provider_init_states() -> None:
    """V62 Fix #14: initialize known provider states at startup.

    Called from _post_init to avoid lazy concurrent mutation of _provider_health.
    Safe to call multiple times (idempotent).
    """
    for p in _KNOWN_PROVIDERS:
        if p not in _provider_health:
            _provider_health[p] = _provider_default_state()


def _provider_default_state() -> dict[str, Any]:
    """V62: return a fresh default provider state dict."""
    return {
        "state": "untested",
        "generation": 0,
        "failure_class": "",
        "cooldown_until": 0.0,
        "cooldown_seconds": 0.0,
        "last_error": "",
        "last_failure_at": 0.0,
        "last_success_at": 0.0,
        "total_failures": 0,
        "total_successes": 0,
        "total_eligible_successes": 0,
        "consecutive_successes": 0,
        "recovery_candidate_since": 0.0,
        "alert_sent": False,
        "last_alert_at": 0.0,
        "last_alert_generation": -1,
        "last_recovery_at": 0.0,
        "last_notification_type": "",
        "last_notification_generation": -1,
        # V62 Fix #9: reservation fields (separate from delivered).
        "pending_notification_type": "",
        "pending_notification_generation": -1,
        "pending_notification_token": "",
        "last_delivered_notification_type": "",
        "last_delivered_notification_generation": -1,
        "last_delivered_notification_at": 0.0,
    }


# V62 Fix #1: robust HTTP status extraction.
# Matches: HTTP 403, HTTP/1.1 403, status=403, status_code=403,
# "response status 403", "403 Forbidden", etc.
# Does NOT match standalone numbers that aren't HTTP status context.


_HTTP_STATUS_RE = re.compile(
    r'(?:HTTP(?:/\d(?:\.\d)?)?\s+|status[_\s]*code?\s*[=:]\s*|response\s+status\s+|status\s+)'
    r'([1-5]\d{2})',
    re.IGNORECASE,
)


def _provider_extract_http_status(error: str) -> int | None:
    """V62 Fix #1: extract authoritative HTTP status from an error string.

    Returns the status code as an int, or None if no authoritative status
    is found. Does NOT classify arbitrary standalone numbers as HTTP status.
    """
    if not error:
        return None
    m = _HTTP_STATUS_RE.search(error)
    if m:
        try:
            return int(m.group(1))
        except ValueError:
            return None
    return None


# V62 Fix #1/#2/#3/#5/#6: deterministic classifier with explicit precedence.


def _provider_classify_error(provider: str, error: str) -> str:
    """V62: classify a provider error string into a failure class.

    Precedence (highest to lowest):
      1. Explicit HTTP status (authoritative).
      2. Structured provider error code (if extractable).
      3. Provider-specific semantic mapping.
      4. Safe keyword fallback.
      5. unknown_error (default — NOT provider_internal_error).

    Mapping:
      400 → invalid_request
      401 → auth_failed
      402 → billing_exhausted
      403 → forbidden  (V62: dedicated class, NOT auth_failed)
      408 → timeout
      409 → invalid_request
      422 → invalid_request
      429 → rate_limited
      500-599 → provider_internal_error
      404 → model_unavailable if model semantics; else invalid_request
    """
    e = (error or "")
    e_low = e.lower()

    # 1. Authoritative HTTP status (highest precedence).
    status = _provider_extract_http_status(e)
    if status is not None:
        return _provider_classify_status(status, e_low)

    # 2. Structured provider error code (Gemini RESOURCE_EXHAUSTED, etc.).
    if "resource_exhausted" in e_low:
        return "resource_exhausted"
    if "rate limit" in e_low or "rate_limit" in e_low:
        return "rate_limited"

    # 3. Provider-specific semantic mapping.
    # V62 Fix #6: billing keywords are NARROWED. Only match strong phrases
    # that indicate actual exhaustion/payment requirement.
    if _matches_billing_exhaustion(e_low):
        return "billing_exhausted"

    # 4. Safe keyword fallback.
    # V85.5 FIX (ERR-G-001): narrow the broad substring checks. The previous
    # ``if "unauthorized" in e_low or "auth" in e_low`` matched any error
    # containing the substring "auth" (e.g. "author", "oauth2_callback",
    # "threadauth"), misclassifying innocent errors as auth_failed. Use
    # word-boundary regex for the narrow, specific keywords instead.
    if re.search(r"\b(unauthorized|auth_failed|invalid[\s_-]?api[\s_-]?key)\b", e_low):
        return "auth_failed"
    if re.search(r"\bforbidden\b", e_low):
        return "forbidden"
    if re.search(r"\b(timeout|timed[\s_-]?out)\b", e_low):
        return "timeout"
    if re.search(r"\b(connection|network|dns|refused|unreachable|reset[\s_-]?by[\s_-]?peer)\b", e_low):
        return "network_failure"
    if re.search(r"\b(bad[\s_-]?request|invalid[\s_-]?request|invalid[\s_-]?parameter)\b", e_low):
        return "invalid_request"
    if re.search(r"\bnot[\s_-]?found\b", e_low) or (
        re.search(r"\bmodel\b", e_low) and re.search(r"\bnot\b", e_low)
    ):
        return "model_unavailable"
    if re.search(r"\b(internal[\s_-]?server|server[\s_-]?error|500|502|503|504)\b", e_low):
        return "provider_internal_error"
    if re.search(r"\bcancel(l?ed)?\b", e_low):
        return "cancelled"
    if re.search(r"\bquota\b", e_low):
        return "resource_exhausted"

    # 5. Default — V62 Fix #3: unknown_error, NOT provider_internal_error.
    return "unknown_error"


def _provider_classify_status(status: int, e_low: str) -> str:
    """V62 Fix #1/#2: classify based on authoritative HTTP status code."""
    if status == 400:
        return "invalid_request"
    if status == 401:
        return "auth_failed"
    if status == 402:
        return "billing_exhausted"
    if status == 403:
        # V62 Fix #2: dedicated forbidden class.
        # Even if the body mentions "credits", the authoritative 403 wins.
        return "forbidden"
    if status == 404:
        # Model unavailable only if model semantics in the body.
        if "model" in e_low or "not found" in e_low:
            return "model_unavailable"
        return "invalid_request"
    if status == 408:
        return "timeout"
    if status == 409:
        return "invalid_request"
    if status == 422:
        return "invalid_request"
    if status == 429:
        return "rate_limited"
    if 500 <= status <= 599:
        return "provider_internal_error"
    # Unknown status code.
    return "unknown_error"


def _matches_billing_exhaustion(e_low: str) -> bool:
    """V62 Fix #6: narrow billing keyword matching.

    Only matches strong phrases that indicate actual credits/billing
    exhaustion. Does NOT match a bare "credits" or "billing" word.
    """
    strong_phrases = (
        "insufficient credits",
        "credits exhausted",
        "payment required",
        "balance exhausted",
        "quota purchase required",
        "billing exhausted",
        "out of credits",
        "no credits",
    )
    return any(p in e_low for p in strong_phrases)


# V62 Fix #4: humanized reason consistent with authoritative status.


def _provider_humanize_reason(provider: str, error: str, cls: str) -> str:
    """V62 Fix #4: produce a user-friendly sanitized reason.

    The humanized text is ALWAYS consistent with the authoritative HTTP
    status (if one was parsed). Never displays a reason whose semantic label
    conflicts with the parsed status.

    Examples:
      HTTP 401: Authentication failed
      HTTP 402: Billing or credits required
      HTTP 403: Access forbidden or permission denied
      HTTP 429: Rate limit exceeded
      HTTP 500: Upstream provider server error
    """
    e = (error or "").strip()
    # V62 Fix #4: re-extract status to ensure consistency.
    status = _provider_extract_http_status(e)

    # Provider display name.
    prov_display = {
        "openrouter": "OpenRouter",
        "gemini": "Gemini",
        "groq": "Groq",
    }.get((provider or "").lower(), (provider or "Provider").title())

    # V62 Fix #4: status-based human text (authoritative).
    if status is not None:
        status_text = {
            400: "Invalid request",
            401: "Authentication failed",
            402: "Billing or credits required",
            403: "Access forbidden or permission denied",
            404: "Resource not found",
            408: "Request timeout",
            409: "Conflict",
            422: "Invalid request",
            429: "Rate limit exceeded",
        }.get(status)
        if status_text is None and 500 <= status <= 599:
            status_text = "Upstream provider server error"
        if status_text is None:
            status_text = "Request failed"
        return f"HTTP {status}: {prov_display} {status_text}"

    # No authoritative status — use class-based text.
    class_text = {
        "resource_exhausted": f"{prov_display} quota exceeded",
        "billing_exhausted": f"{prov_display} billing/credits exhausted",
        "rate_limited": f"{prov_display} rate limit exceeded",
        "auth_failed": f"{prov_display} authentication failed",
        "forbidden": f"{prov_display} access forbidden",
        "timeout": "Connection timeout",
        "network_failure": f"{prov_display} network connection error",
        "invalid_request": f"{prov_display} invalid request",
        "model_unavailable": f"{prov_display} model unavailable",
        "provider_internal_error": f"{prov_display} upstream server error",
        "cancelled": "Request cancelled",
        "unknown_error": f"{prov_display} unknown error",
    }.get(cls, f"{prov_display} error")

    # If we have a safe snippet of the error, append it (truncated + sanitized).
    # But only for non-status cases, and only if it doesn't conflict.
    return class_text


def _provider_get_state(provider: str) -> dict[str, Any]:
    """V62: get or create the health state for a provider.

    States are initialized at startup via _provider_init_states(), but this
    function handles dynamic providers safely (lazy creation under GIL is
    atomic for dict get/set).
    """
    st = _provider_health.get(provider)
    if st is None:
        st = _provider_default_state()
        _provider_health[provider] = st
    return st


def _provider_current_generation(provider: str) -> int:
    """V61 Fix #2/#5: sync read of the current failure generation.

    Safe to call without the lock. Used by request paths to capture the
    generation at request start, so a stale success can be detected.
    """
    st = _provider_health.get(provider)
    if st is None:
        return 0
    return int(st.get("generation", 0))


def _provider_in_cooldown(provider: str) -> bool:
    """True if the provider is currently in cooldown (should NOT be called)."""
    st = _provider_get_state(provider)
    if st["cooldown_until"] > 0 and time.monotonic() < st["cooldown_until"]:
        return True
    return False


def _provider_cooldown_remaining(provider: str) -> float:
    """Seconds remaining in cooldown (0 if not in cooldown)."""
    st = _provider_get_state(provider)
    if st["cooldown_until"] <= 0:
        return 0.0
    remaining = st["cooldown_until"] - time.monotonic()
    return max(0.0, remaining)


def _provider_effective_state(provider: str) -> str:
    """V61 Fix #8: sync read — the effective state for display."""
    st = _provider_get_state(provider)
    cur = st.get("state", "untested")
    if cur == "failing" and st["cooldown_until"] > 0:
        if time.monotonic() >= st["cooldown_until"]:
            return "recovering"
    return cur


# V63 Fix #1: provider diagnostic helpers for auth_failed logging.


def _provider_model_name(provider: str) -> str:
    """Return the configured model name for a provider (for diagnostics)."""
    p = (provider or "").lower()
    if p == "gemini":
        return config.default_ai_model or "gemini-2.5-flash"  # v97.48: gemini-2.0-flash deprecated
    if p == "groq":
        return config.groq_model or "llama-3.3-70b-versatile"
    if p == "openrouter":
        return config.openrouter_model or "unknown"
    return "unknown"


def _provider_api_key_configured(provider: str) -> bool:
    """Return True if the provider's API key is configured."""
    p = (provider or "").lower()
    if p == "gemini":
        return bool(config.gemini_api_key)
    if p == "groq":
        return bool(config.groq_api_key)
    if p == "openrouter":
        return bool(config.openrouter_api_key)
    return False


def _provider_endpoint(provider: str) -> str:
    """Return the API endpoint URL for a provider (for diagnostics)."""
    p = (provider or "").lower()
    if p == "gemini":
        return "https://generativelanguage.googleapis.com/v1beta"
    if p == "groq":
        return "https://api.groq.com/openai/v1/chat/completions"
    if p == "openrouter":
        return "https://openrouter.ai/api/v1/chat/completions"
    return "unknown"


# V62 Fix #13: sync wrapper retained for backward compat but logs a warning
# if called from an async context (production paths should await the async form).


def _provider_record_failure(provider: str, error: str,
                              gen_at_start: int | None = None) -> str:
    """V62 Fix #13: sync wrapper — NON-AUTHORITATIVE in async contexts.

    Logs a warning if called from a running event loop. Production async
    call sites MUST use ``await _provider_record_failure_async(...)``.
    Only safe in truly synchronous paths (import-time, shutdown).
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = None
    if loop is None or not loop.is_running():
        return _provider_record_failure_sync(provider, error)
    # V62 Fix #13: warn about fire-and-forget in async context.
    logger.warning(
        "PROVIDER_RECORD_FAILURE_SYNC_IN_ASYNC provider=%s — fire-and-forget scheduled; "
        "caller should use await _provider_record_failure_async() for authoritative state",
        provider,
    )
    try:
        # V85.5 FIX (ASYNC-G-002): strong-reference the fire-and-forget
        # task so it isn't garbage-collected before it completes.
        _t = asyncio.create_task(_provider_record_failure_async(provider, error, gen_at_start))
        _provider_notify_tasks.add(_t)
        _t.add_done_callback(_provider_notify_tasks.discard)
    except RuntimeError:
        return _provider_record_failure_sync(provider, error)
    return _provider_classify_error(provider, error)


async def _provider_record_failure_async(provider: str, error: str,
                                          gen_at_start: int | None = None) -> str:
    """V62: record a provider failure atomically.

    Acquires per-provider lock. Increments generation on
    healthy/recovering → failing transition. Reserves a notification
    (V62 Fix #9: separate from delivered). Schedules admin alert
    OUTSIDE the lock; the alert function re-validates + commits delivery.

    Returns the failure class.
    """
    cls = _provider_classify_error(provider, error)
    # V85 §14: emit granular provider diagnostic on the authoritative async
    # hot path.  Every provider failure flows through here, so the
    # PROVIDER_AUTH_FAILED / PROVIDER_BILLING / PROVIDER_QUOTA /
    # PROVIDER_DISABLED tokens required by the brief now fire on the real
    # path (not only via the ProviderManager facade).
    try:
        if cls == "auth_failed":
            v85_diag("PROVIDER_AUTH_FAILED", provider=provider, cls=cls)
        elif cls == "billing_exhausted":
            v85_diag("PROVIDER_BILLING", provider=provider, cls=cls)
        elif cls in ("resource_exhausted", "rate_limited", "quota_exhausted"):
            v85_diag("PROVIDER_QUOTA", provider=provider, cls=cls)
        else:
            # forbidden / network_failure / timeout / model_unavailable /
            # invalid_request / provider_internal_error / unknown_error →
            # provider temporarily disabled.
            v85_diag("PROVIDER_DISABLED", provider=provider, cls=cls)
    except Exception:  # noqa: BLE001
        pass
    human_reason = _provider_humanize_reason(provider, error, cls)
    safe_reason = _sanitize_error(human_reason)

    notify_failure: dict[str, Any] | None = None
    new_cd = 0.0
    new_gen = 0
    total_failures = 0

    async with _provider_lock(provider):
        st = _provider_get_state(provider)
        now = time.monotonic()
        prev_state = st.get("state", "untested")
        prev_gen = int(st.get("generation", 0))

        # Lazy cooldown expiry.
        if prev_state == "failing" and st["cooldown_until"] > 0 and now >= st["cooldown_until"]:
            prev_state = "recovering"

        is_new_episode = prev_state in ("healthy", "untested", "recovering")

        st["failure_class"] = cls
        st["last_error"] = safe_reason
        st["last_failure_at"] = now
        st["total_failures"] = int(st.get("total_failures", 0)) + 1
        st["consecutive_successes"] = 0
        st["recovery_candidate_since"] = 0.0

        # Cooldown with exponential backoff.
        base = _PROVIDER_COOLDOWN.get(cls, 30.0)
        current_cd = float(st.get("cooldown_seconds", 0.0))
        if is_new_episode or current_cd == 0.0:
            new_cd = base
        else:
            new_cd = min(current_cd * 2, _PROVIDER_COOLDOWN_MAX)
        st["cooldown_seconds"] = new_cd
        st["cooldown_until"] = now + new_cd

        if is_new_episode:
            new_gen = prev_gen + 1
            st["generation"] = new_gen
        else:
            new_gen = prev_gen
        st["state"] = "failing"
        total_failures = int(st.get("total_failures", 0))

        # V62 Fix #7/#9: notification RESERVATION (not delivered).
        # unknown_error is NOT serious — no alert reserved.
        serious = cls in _PROVIDER_SERIOUS_CLASSES
        if serious:
            last_alert_gen = int(st.get("last_alert_generation", -1))
            last_alert_at = float(st.get("last_alert_at", 0.0))
            should_alert = (
                last_alert_gen != new_gen
                or (now - last_alert_at) >= _PROVIDER_ALERT_DEDUP_SECONDS
            )
            if should_alert:
                # V62 Fix #9: reserve notification (separate from delivered).
                token = f"{provider}_{new_gen}_{int(now * 1000)}"
                st["pending_notification_type"] = "failure"
                st["pending_notification_generation"] = new_gen
                st["pending_notification_token"] = token
                # NOTE: last_notification_type / last_notification_generation
                # / alert_sent / last_alert_* are NOT updated here — they
                # track DELIVERED notifications, updated only after the
                # Telegram send succeeds in _provider_notify_admin.
                notify_failure = {
                    "provider": provider,
                    "failure_class": cls,
                    "reason": safe_reason,
                    "human_reason": human_reason,
                    "cooldown": new_cd,
                    "generation": new_gen,
                    "token": token,
                }

    # Schedule notification OUTSIDE the lock.
    if notify_failure is not None:
        # V85.5 FIX (ASYNC-G-002): strong-reference the notification task.
        _provider_spawn_notify_task(_provider_notify_admin(
            notify_failure["provider"],
            notify_failure["failure_class"],
            notify_failure["human_reason"],
            notify_failure["cooldown"],
            notify_failure["generation"],
            notify_failure["token"],
        ))

    logger.warning(
        "TALKATIVE_PROVIDER_CIRCUIT provider=%s class=%s state=%s gen=%d cooldown=%.0fs "
        "error=%s total_failures=%d",
        provider, cls, "failing", new_gen, new_cd, safe_reason[:200],
        total_failures,
    )
    logger.error(
        "TALKATIVE_PROVIDER_FAILURE_DETAIL provider=%s class=%s raw_error=%s",
        provider, cls, _sanitize_error(error)[:300],
    )
    # V63 Fix #1: when auth_failed is classified, log a rich diagnostic
    # so the admin can verify the HTTP status, provider, sanitized body,
    # selected failure class, and cooldown reason.
    if cls == "auth_failed":
        status = _provider_extract_http_status(error)
        logger.warning(
            "AUTH_FAILED_DIAGNOSTIC provider=%s http_status=%s model=%s "
            "api_key_configured=%s endpoint=%s failure_class=%s cooldown=%.0fs "
            "sanitized_body=%s",
            provider,
            status if status else "none",
            _provider_model_name(provider),
            _provider_api_key_configured(provider),
            _provider_endpoint(provider),
            cls,
            _PROVIDER_COOLDOWN.get(cls, 30.0),
            _sanitize_error(error)[:200],
        )
    return cls


def _provider_record_failure_sync(provider: str, error: str) -> str:
    """Best-effort sync failure recording (no event loop). No notifications."""
    cls = _provider_classify_error(provider, error)
    safe_reason = _sanitize_error(_provider_humanize_reason(provider, error, cls))
    st = _provider_get_state(provider)
    now = time.monotonic()
    prev_state = st.get("state", "untested")
    if prev_state == "failing" and st["cooldown_until"] > 0 and now >= st["cooldown_until"]:
        prev_state = "recovering"
    is_new_episode = prev_state in ("healthy", "untested", "recovering")
    st["failure_class"] = cls
    st["last_error"] = safe_reason
    st["last_failure_at"] = now
    st["total_failures"] = int(st.get("total_failures", 0)) + 1
    st["consecutive_successes"] = 0
    st["recovery_candidate_since"] = 0.0
    base = _PROVIDER_COOLDOWN.get(cls, 30.0)
    current_cd = float(st.get("cooldown_seconds", 0.0))
    new_cd = base if (is_new_episode or current_cd == 0.0) else min(current_cd * 2, _PROVIDER_COOLDOWN_MAX)
    st["cooldown_seconds"] = new_cd
    st["cooldown_until"] = now + new_cd
    if is_new_episode:
        st["generation"] = int(st.get("generation", 0)) + 1
    st["state"] = "failing"
    return cls


# V62 Fix #13: sync wrapper retained but warns in async contexts.


def _provider_record_success(provider: str, gen_at_start: int | None = None) -> None:
    """V62 Fix #13: sync wrapper — NON-AUTHORITATIVE in async contexts."""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = None
    if loop is None or not loop.is_running():
        _provider_record_success_sync(provider, gen_at_start)
        return
    logger.warning(
        "PROVIDER_RECORD_SUCCESS_SYNC_IN_ASYNC provider=%s — fire-and-forget scheduled; "
        "caller should use await _provider_record_success_async() for authoritative state",
        provider,
    )
    try:
        # V85.5 FIX (ASYNC-G-002): strong-reference the fire-and-forget
        # task so it isn't garbage-collected before it completes.
        _t = asyncio.create_task(_provider_record_success_async(provider, gen_at_start))
        _provider_notify_tasks.add(_t)
        _t.add_done_callback(_provider_notify_tasks.discard)
    except RuntimeError:
        _provider_record_success_sync(provider, gen_at_start)


async def _provider_record_success_async(provider: str,
                                          gen_at_start: int | None = None) -> None:
    """V62 Fix #5/#11/#12: record a provider success atomically.

    V62 changes:
      - Stale generation check happens BEFORE any metric increment (Fix #11).
      - Successes during active cooldown do NOT increment
        consecutive_successes (Fix #12).
      - Recovery DM depends on DELIVERED failure notification, not
        reserved (Fix #10).
      - total_successes (raw) is separate from total_eligible_successes.
    """
    notify_recovery: dict[str, Any] | None = None

    async with _provider_lock(provider):
        st = _provider_get_state(provider)
        now = time.monotonic()
        current_gen = int(st.get("generation", 0))
        prev_state = st.get("state", "untested")

        # V62 Fix #11: validate generation BEFORE any metric increment.
        # A stale success (from an in-flight request that started before
        # a newer failure) is logged but does NOT touch recovery state.
        is_stale = (gen_at_start is not None and gen_at_start != current_gen)

        if prev_state in ("healthy", "untested"):
            # Healthy provider — count the success.
            st["last_success_at"] = now
            st["total_successes"] = int(st.get("total_successes", 0)) + 1
            if not is_stale:
                st["total_eligible_successes"] = int(st.get("total_eligible_successes", 0)) + 1
                st["consecutive_successes"] = int(st.get("consecutive_successes", 0)) + 1
            st["state"] = "healthy"
            return

        # prev_state is "failing" or "recovering".
        # V62 Fix #12: if still in active cooldown (failing state, cooldown
        # not expired), do NOT count toward recovery.
        if prev_state == "failing" and st["cooldown_until"] > 0 and now < st["cooldown_until"]:
            # Active cooldown — record raw telemetry only.
            st["last_success_at"] = now
            st["total_successes"] = int(st.get("total_successes", 0)) + 1
            # Do NOT increment consecutive_successes.
            # Do NOT set recovery_candidate_since.
            logger.info(
                "TALKATIVE_PROVIDER_SUCCESS_DURING_COOLDOWN provider=%s — not counted toward recovery",
                provider,
            )
            return

        # Cooldown expired — transition to recovering.
        if prev_state == "failing" and st["cooldown_until"] > 0 and now >= st["cooldown_until"]:
            prev_state = "recovering"
            st["state"] = "recovering"
            # V62 Fix #12: reset recovery counters on entry to recovering.
            st["consecutive_successes"] = 0
            st["recovery_candidate_since"] = 0.0

        # prev_state == "recovering"
        # V62 Fix #11: reject stale success.
        if is_stale:
            st["last_success_at"] = now
            st["total_successes"] = int(st.get("total_successes", 0)) + 1
            logger.info(
                "TALKATIVE_PROVIDER_STALE_SUCCESS provider=%s gen_start=%d gen_now=%d — ignored for recovery",
                provider, gen_at_start, current_gen,
            )
            return

        # Eligible success.
        st["last_success_at"] = now
        st["total_successes"] = int(st.get("total_successes", 0)) + 1
        st["total_eligible_successes"] = int(st.get("total_eligible_successes", 0)) + 1
        st["consecutive_successes"] = int(st.get("consecutive_successes", 0)) + 1
        if st["recovery_candidate_since"] == 0.0:
            st["recovery_candidate_since"] = now

        consec = int(st.get("consecutive_successes", 0))
        last_fail = float(st.get("last_failure_at", 0.0))
        stability_ok = (now - last_fail) >= _PROVIDER_RECOVERY_STABILITY_SECONDS
        min_successes_ok = consec >= _PROVIDER_RECOVERY_MIN_SUCCESSES

        if stability_ok and min_successes_ok:
            # Confirmed recovery.
            st["state"] = "healthy"
            st["failure_class"] = ""
            st["cooldown_until"] = 0.0
            st["cooldown_seconds"] = 0.0
            st["last_error"] = ""
            st["recovery_candidate_since"] = 0.0
            st["consecutive_successes"] = 0
            st["last_recovery_at"] = now

            # V62 Fix #10: recovery DM ONLY if a failure alert was
            # DELIVERED (not just reserved) for this generation.
            delivered_type = st.get("last_delivered_notification_type", "")
            delivered_gen = int(st.get("last_delivered_notification_generation", -1))
            if delivered_type == "failure" and delivered_gen == current_gen:
                # Reserve recovery notification.
                token = f"{provider}_recv_{current_gen}_{int(now * 1000)}"
                st["pending_notification_type"] = "recovery"
                st["pending_notification_generation"] = current_gen
                st["pending_notification_token"] = token
                notify_recovery = {
                    "provider": provider,
                    "generation": current_gen,
                    "token": token,
                }

    # Schedule recovery notification OUTSIDE the lock.
    if notify_recovery is not None:
        # V85.5 FIX (ASYNC-G-002): strong-reference the recovery notification.
        _provider_spawn_notify_task(_provider_notify_admin_recovery(
            notify_recovery["provider"],
            notify_recovery["generation"],
            notify_recovery["token"],
        ))
        logger.info("TALKATIVE_PROVIDER_CIRCUIT provider=%s RECOVERED gen=%d",
                    provider, notify_recovery["generation"])


def _provider_record_success_sync(provider: str,
                                   gen_at_start: int | None = None) -> None:
    """Best-effort sync success recording (no event loop). No notifications."""
    st = _provider_get_state(provider)
    now = time.monotonic()
    current_gen = int(st.get("generation", 0))
    prev_state = st.get("state", "untested")
    is_stale = (gen_at_start is not None and gen_at_start != current_gen)
    if prev_state in ("healthy", "untested"):
        st["last_success_at"] = now
        st["total_successes"] = int(st.get("total_successes", 0)) + 1
        if not is_stale:
            st["total_eligible_successes"] = int(st.get("total_eligible_successes", 0)) + 1
            st["consecutive_successes"] = int(st.get("consecutive_successes", 0)) + 1
        st["state"] = "healthy"
        return
    if prev_state == "failing" and st["cooldown_until"] > 0 and now < st["cooldown_until"]:
        st["last_success_at"] = now
        st["total_successes"] = int(st.get("total_successes", 0)) + 1
        return
    if prev_state == "failing" and st["cooldown_until"] > 0 and now >= st["cooldown_until"]:
        prev_state = "recovering"
        st["state"] = "recovering"
        st["consecutive_successes"] = 0
        st["recovery_candidate_since"] = 0.0
    if is_stale:
        st["last_success_at"] = now
        st["total_successes"] = int(st.get("total_successes", 0)) + 1
        return
    st["last_success_at"] = now
    st["total_successes"] = int(st.get("total_successes", 0)) + 1
    st["total_eligible_successes"] = int(st.get("total_eligible_successes", 0)) + 1
    st["consecutive_successes"] = int(st.get("consecutive_successes", 0)) + 1
    if st["recovery_candidate_since"] == 0.0:
        st["recovery_candidate_since"] = now
    consec = int(st.get("consecutive_successes", 0))
    last_fail = float(st.get("last_failure_at", 0.0))
    if (now - last_fail) >= _PROVIDER_RECOVERY_STABILITY_SECONDS and consec >= _PROVIDER_RECOVERY_MIN_SUCCESSES:
        st["state"] = "healthy"
        st["failure_class"] = ""
        st["cooldown_until"] = 0.0
        st["cooldown_seconds"] = 0.0
        st["last_error"] = ""
        st["recovery_candidate_since"] = 0.0
        st["consecutive_successes"] = 0
        st["last_recovery_at"] = now


# V62 Fix #17: stronger secret redaction.


async def _provider_notify_admin(provider: str, failure_class: str,
                                  reason: str, cooldown: float,
                                  expected_gen: int,
                                  expected_token: str) -> None:
    """V62 Fix #8/#9: send a failure alert DM to all admins.

    Reservation-vs-delivery separation:
      - The caller reserved a notification under lock (token + generation).
      - At send time, re-validate: generation + state + reservation token.
      - Only AFTER successful Telegram delivery, commit the delivered state
        (reacquire lock, verify token still valid, update delivered fields).

    Never holds the provider lock during Telegram network I/O.
    """
    # V62 Fix #8: send-time guard — verify reservation is still valid.
    should_send = await _provider_verify_notification_reservation(
        provider, expected_gen, expected_token, "failure"
    )
    if not should_send:
        logger.info(
            "TALKATIVE_PROVIDER_ALERT_SKIP provider=%s expected_gen=%d — reservation invalidated",
            provider, expected_gen,
        )
        return

    # V62 Fix #9: always commit delivery result (delivered or not) via
    # try/finally so the reservation is cleared even on early return / exception.
    delivered = False
    try:
        bot_inst = get_bot()
        if bot_inst is None:
            logger.error(
                "TALKATIVE_PROVIDER_ALERT_FAILED provider=%s class=%s reason=no_bot_instance",
                provider, failure_class,
            )
            return  # delivered stays False → commit will clear reservation
        model = ""
        if provider == "gemini":
            model = config.default_ai_model or "gemini-2.5-flash"  # v97.48: gemini-2.0-flash deprecated
        elif provider == "groq":
            model = config.groq_model or "llama-3.3-70b-versatile"
        elif provider == "openrouter":
            model = config.openrouter_model or "unknown"
        from datetime import datetime, timezone
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        safe_reason = _sanitize_error(reason)[:150]
        # V62 Fix #10: user-friendly issue label.
        issue_label = {
            "resource_exhausted": "Quota exceeded",
            "billing_exhausted": "Billing/credits exhausted",
            "rate_limited": "Rate limited",
            "auth_failed": "Authentication failed",
            "forbidden": "Access forbidden",
            "timeout": "Connection timeout",
            "network_failure": "Network error",
            "invalid_request": "Invalid request",
            "model_unavailable": "Model unavailable",
            "provider_internal_error": "Provider server error",
            "cancelled": "Request cancelled",
            "unknown_error": "Unknown error",
        }.get(failure_class, "Provider error")
        text = (
            f"⚠️ *Provider Health Alert*\n\n"
            f"Provider: `{provider}`\n"
            f"Model: `{model}`\n"
            f"Issue: {issue_label}\n"
            f"Timestamp: `{ts}`\n"
            f"Cooldown: `{cooldown:.0f}s`\n"
            f"Reason: `{safe_reason}`\n\n"
            f"_The provider is in cooldown. Requests will use fallback if configured._"
        )
        # V62 Fix #16: provider-specific key button — ONLY for auth_failed.
        # Other classes get class-specific guidance text instead.
        reply_markup = None
        if failure_class in _PROVIDER_KEY_BUTTON_CLASSES:
            try:
                from telegram import InlineKeyboardButton, InlineKeyboardMarkup
                reply_markup = InlineKeyboardMarkup([
                    [InlineKeyboardButton(f"🔑 Add {provider.title()} API Key",
                                          callback_data="talk:provider_key:add")],
                ])
            except ImportError:
                pass

        # Send to all admins.
        sent_count = 0
        failed_admins: list[str] = []
        for admin_id in config.admin_ids:
            try:
                await bot_inst.send_message(chat_id=admin_id, text=text,
                                       parse_mode="Markdown",
                                       reply_markup=reply_markup)
                sent_count += 1
            except Exception as exc:  # noqa: BLE001
                failed_admins.append(f"{admin_id}:{type(exc).__name__}")

        delivered = sent_count > 0

        if failed_admins:
            logger.error(
                "TALKATIVE_PROVIDER_ALERT_PARTIAL provider=%s class=%s sent=%d/%d failed=%s",
                provider, failure_class, sent_count, len(config.admin_ids),
                ",".join(failed_admins[:5]),
            )
        else:
            logger.info("TALKATIVE_PROVIDER_ALERT provider=%s class=%s admins_notified=%d gen=%d",
                        provider, failure_class, sent_count, expected_gen)
            if delivered:
                _alerts_log_provider_failure(provider, failure_class, safe_reason, expected_gen)
    except Exception as exc:  # noqa: BLE001
        logger.error("TALKATIVE_PROVIDER_ALERT_FAILED provider=%s exc=%s: %s",
                     provider, type(exc).__name__, _sanitize_error(str(exc))[:120])
    finally:
        await _provider_commit_notification_delivery(
            provider, expected_gen, expected_token, "failure", delivered
        )


async def _provider_notify_admin_recovery(provider: str,
                                           expected_gen: int,
                                           expected_token: str) -> None:
    """V62 Fix #8/#9/#10: send a recovery DM when a provider is confirmed healthy.

    Reservation-vs-delivery separation (same as failure alerts).
    """
    # V62 Fix #8: send-time guard.
    should_send = await _provider_verify_notification_reservation(
        provider, expected_gen, expected_token, "recovery"
    )
    if not should_send:
        logger.info(
            "TALKATIVE_PROVIDER_RECOVERY_SKIP provider=%s expected_gen=%d — reservation invalidated",
            provider, expected_gen,
        )
        return

    # V62 Fix #9: always commit via try/finally.
    delivered = False
    try:
        bot_inst = get_bot()
        if bot_inst is None:
            logger.error(
                "TALKATIVE_PROVIDER_RECOVERY_FAILED provider=%s reason=no_bot_instance",
                provider,
            )
            return
        from datetime import datetime, timezone
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        text = (
            f"✅ *Provider Recovered*\n\n"
            f"Provider: `{provider}`\n"
            f"Timestamp: `{ts}`\n\n"
            f"_The provider is healthy again._"
        )
        sent_count = 0
        failed_admins: list[str] = []
        for admin_id in config.admin_ids:
            try:
                await bot_inst.send_message(chat_id=admin_id, text=text,
                                       parse_mode="Markdown")
                sent_count += 1
            except Exception as exc:  # noqa: BLE001
                failed_admins.append(f"{admin_id}:{type(exc).__name__}")

        delivered = sent_count > 0

        if failed_admins:
            logger.error(
                "TALKATIVE_PROVIDER_RECOVERY_PARTIAL provider=%s sent=%d/%d failed=%s",
                provider, sent_count, len(config.admin_ids),
                ",".join(failed_admins[:5]),
            )
        else:
            logger.info("TALKATIVE_PROVIDER_RECOVERY provider=%s gen=%d",
                        provider, expected_gen)
            if delivered:
                _alerts_log_provider_recovery(provider, expected_gen)
    except Exception as exc:  # noqa: BLE001
        logger.error("TALKATIVE_PROVIDER_RECOVERY_FAILED provider=%s exc=%s: %s",
                     provider, type(exc).__name__, _sanitize_error(str(exc))[:120])
    finally:
        await _provider_commit_notification_delivery(
            provider, expected_gen, expected_token, "recovery", delivered
        )


async def _provider_verify_notification_reservation(provider: str,
                                                     expected_gen: int,
                                                     expected_token: str,
                                                     notif_type: str) -> bool:
    """V62 Fix #8: verify a notification reservation is still valid before sending.

    Checks under lock:
      - generation matches
      - state is appropriate (failing for failure, healthy for recovery)
      - pending_notification_token matches
      - pending_notification_type matches
    """
    async with _provider_lock(provider):
        st = _provider_get_state(provider)
        current_gen = int(st.get("generation", 0))
        if current_gen != expected_gen:
            return False
        pending_type = st.get("pending_notification_type", "")
        pending_token = st.get("pending_notification_token", "")
        if pending_type != notif_type:
            return False
        if pending_token != expected_token:
            return False
        # State check: failure alerts require failing state; recovery
        # requires healthy state.
        cur_state = st.get("state", "untested")
        if notif_type == "failure" and cur_state != "failing":
            return False
        if notif_type == "recovery" and cur_state != "healthy":
            return False
        return True


async def _provider_commit_notification_delivery(provider: str,
                                                   gen: int,
                                                   token: str,
                                                   notif_type: str,
                                                   delivered: bool) -> None:
    """V62 Fix #9: commit the delivery result after Telegram send.

    Reacquires the lock, verifies the reservation token is still valid,
    then updates the DELIVERED fields. If the reservation was invalidated
    (e.g. a newer failure superseded), do NOT commit stale delivered state.
    """
    async with _provider_lock(provider):
        st = _provider_get_state(provider)
        current_gen = int(st.get("generation", 0))
        pending_token = st.get("pending_notification_token", "")
        # Only commit if the reservation is still ours.
        if current_gen != gen or pending_token != token:
            logger.info(
                "PROVIDER_NOTIF_COMMIT_SKIP provider=%s gen=%d current_gen=%d — reservation superseded",
                provider, gen, current_gen,
            )
            return
        if delivered:
            now = time.monotonic()
            st["last_delivered_notification_type"] = notif_type
            st["last_delivered_notification_generation"] = gen
            st["last_delivered_notification_at"] = now
            # Also update the legacy fields (for backward compat with
            # recovery eligibility checks).
            st["last_notification_type"] = notif_type
            st["last_notification_generation"] = gen
            if notif_type == "failure":
                st["alert_sent"] = True
                st["last_alert_at"] = now
                st["last_alert_generation"] = gen
        # Clear the reservation regardless (delivered or not).
        st["pending_notification_type"] = ""
        st["pending_notification_generation"] = -1
        st["pending_notification_token"] = ""


def talkative_get_provider_health() -> dict[str, Any]:
    """V42 Fix #2/#15 + V61/V62: get the health state of all providers."""
    result = {}
    for provider in ("groq", "openrouter", "gemini"):
        st = _provider_get_state(provider)
        eff_state = _provider_effective_state(provider)
        in_cd = _provider_in_cooldown(provider)
        result[provider] = {
            "state": "cooldown" if in_cd else eff_state,
            "generation": int(st.get("generation", 0)),
            "failure_class": st.get("failure_class", ""),
            "cooldown_remaining": _provider_cooldown_remaining(provider),
            "last_error": st.get("last_error", "")[:100],
            "total_failures": int(st.get("total_failures", 0)),
            "total_successes": int(st.get("total_successes", 0)),
            "total_eligible_successes": int(st.get("total_eligible_successes", 0)),
            "last_success_at": float(st.get("last_success_at", 0.0)),
            "last_failure_at": float(st.get("last_failure_at", 0.0)),
            "consecutive_successes": int(st.get("consecutive_successes", 0)),
            "last_notification_type": st.get("last_delivered_notification_type", ""),
            "pending_notification_type": st.get("pending_notification_type", ""),
        }
    return result


# V62: Dashboard snapshot writer.
# Persists in-process provider health + talkative metrics to JSON files under
# data/ so the Next.js admin dashboard (scripts/bot_status_export.py) can
# surface real bot state. Side-effect-free; never writes secrets.


def _atomic_write(path: Path, data: str) -> None:
    """V85.5 FIX (RELI-G-005): write ``data`` to ``path`` atomically.

    Writes to a uniquely-named temp file in the same directory, then
    ``os.replace``s it onto the target. ``os.replace`` is atomic on POSIX
    and Windows for same-filesystem renames, so a reader never sees a
    half-written file. Best-effort: any error raises OSError (caller is
    expected to wrap in try/except).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    # Use a unique temp suffix so concurrent writers don't clobber each
    # other's temp files.
    tmp_name = f".{path.name}.{os.getpid()}.{int(time.time() * 1000)}.tmp"
    tmp_path = path.parent / tmp_name
    try:
        tmp_path.write_text(data)
        os.replace(tmp_path, path)
    except Exception:
        # Best-effort cleanup of the temp file on failure.
        try:
            tmp_path.unlink()
        except OSError:
            pass
        raise


_ALERTS_LOG_PATH = Path(config.project_root) / "data" / "alerts_log.json"


_ALERTS_LOG_MAX = 200


def _alerts_log_append(entry: dict[str, Any]) -> None:
    """Append an alert entry to the alerts log (best-effort, never raises).

    The log is a JSON array, newest last. Capped at _ALERTS_LOG_MAX entries
    (oldest dropped first). Thread-safe via atomic read-modify-write under GIL.

    V85.5 FIX (RELI-G-005): uses ``_atomic_write`` so a concurrent reader
    (the dashboard) never sees a truncated JSON array.
    """
    try:
        _ALERTS_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        existing: list = []
        if _ALERTS_LOG_PATH.exists():
            try:
                raw = _ALERTS_LOG_PATH.read_text()
                data = json.loads(raw)
                if isinstance(data, list):
                    existing = data
            except (json.JSONDecodeError, OSError):
                existing = []
        existing.append(entry)
        # Prune.
        if len(existing) > _ALERTS_LOG_MAX:
            existing = existing[-_ALERTS_LOG_MAX:]
        _atomic_write(_ALERTS_LOG_PATH, json.dumps(existing, default=str))
    except Exception as exc:  # noqa: BLE001
        logger.debug("ALERTS_LOG_APPEND_FAILED exc=%s", exc)


def _alerts_log_provider_failure(provider: str, failure_class: str,
                                  reason: str, generation: int) -> None:
    """Record a provider failure alert in the alerts log."""
    _alerts_log_append({
        "id": f"fail_{provider}_{generation}_{int(time.time())}",
        "type": "provider_failure",
        "provider": provider,
        "failure_class": failure_class,
        "generation": generation,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "epoch": int(time.time()),
        "message": f"{provider} entered cooldown ({failure_class}): {reason[:100]}",
        "severity": "warning",
    })


def _alerts_log_provider_recovery(provider: str, generation: int) -> None:
    """Record a provider recovery alert in the alerts log."""
    _alerts_log_append({
        "id": f"recv_{provider}_{generation}_{int(time.time())}",
        "type": "provider_recovery",
        "provider": provider,
        "generation": generation,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "epoch": int(time.time()),
        "message": f"{provider} recovered — confirmed healthy",
        "severity": "success",
    })


# V63: Admin control-channel handlers.
# The Next.js dashboard writes sentinel files to data/; the bot picks them up
# on each snapshot tick and executes the requested action. This is a safe,
# decoupled control channel — no direct process spawning or IPC.
#
# V85.5 FIX (SEC-G-001/002/003): the control channel is now HMAC-authenticated.
# Every sentinel file MUST contain a JSON object with a `sig` field whose value
# is the hex HMAC-SHA256 of the canonical JSON encoding of the rest of the
# payload (sorted keys, no whitespace), keyed by `ADMIN_TRIGGER_SECRET`.
# Sentinel files without a valid signature are rejected with a warning and the
# requested action is skipped — admins MUST update the dashboard to sign
# requests. If `ADMIN_TRIGGER_SECRET` is unset, a one-time warning is logged
# and all sentinel files are rejected (fail-closed).
import hmac as _hmac  # local import — Section A (top-level imports) is out of edit range


async def _gemini_key_validate(candidate_key: str) -> tuple[bool, str]:
    """V43 Fix #6: validate a candidate Gemini API key with a minimal bounded request.

    Returns (valid, sanitized_reason). Never logs the key.

    V85.4 FIX (Req 2): temporary failures (429 rate-limited, 5xx provider
    unavailable, timeout, DNS, SSL, connection errors) no longer return
    ``valid=False``.  They return ``(True, "transient:...")`` so the caller
    (``_provider_key_activate``) still saves the key — the key may be
    perfectly valid; only the probe was temporarily unavailable.  Only
    authoritative key failures (400 bad request, 401/403 auth/permission,
    402 billing) return ``valid=False``.
    """
    if not candidate_key or not candidate_key.strip():
        return False, "Empty key"
    key = candidate_key.strip()
    # V85.3 FIX BUG A1: do NOT reject based on the "AIza" prefix.  Google
    # has rotated Gemini key formats over time (AI Studio keys, OAuth
    # tokens, service-account keys use different prefixes).  A prefix-only
    # check silently rejects valid keys before the authoritative API probe
    # runs.  Keep only a minimal length sanity check, then let the real
    # :generateContent probe decide validity by HTTP status.
    if len(key) < 20:
        return False, "Key too short"
    # Minimal bounded Gemini request to validate the key.
    try:
        import httpx
        model = config.default_ai_model or "gemini-2.5-flash"  # v97.48: gemini-2.0-flash deprecated
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
        payload = {
            "contents": [{"parts": [{"text": "OK"}]}],
            "generationConfig": {"maxOutputTokens": 1},
        }
        async with httpx.AsyncClient(timeout=httpx.Timeout(15.0)) as client:
            resp = await client.post(url, json=payload)
        if resp.status_code == 200:
            return True, "ok"
        elif resp.status_code == 400:
            return False, "Invalid key (400 Bad Request)"
        elif resp.status_code == 401:
            return False, "Invalid key (401 Unauthorized)"
        elif resp.status_code == 403:
            # V85.4: 403 = permission denied (distinct from 401 invalid key).
            return False, "Permission denied (403 Forbidden)"
        elif resp.status_code == 402:
            return False, "Billing exhausted (402 Payment Required)"
        elif resp.status_code == 429:
            # V85.4: rate-limited — do NOT invalidate the key.
            return True, "transient:rate_limited (429) — key not rejected"
        elif 500 <= resp.status_code < 600:
            # V85.4: provider unavailable — do NOT invalidate the key.
            return True, f"transient:provider_unavailable (HTTP {resp.status_code})"
        else:
            # V85.4: unknown HTTP status — treat as transient (don't reject key).
            return True, f"transient:unknown_http_{resp.status_code}"
    except (httpx.TimeoutException, httpx.ConnectError, httpx.NetworkError) as exc:
        # V85.4: timeout / DNS / connection — do NOT invalidate the key.
        return True, f"transient:network_error ({type(exc).__name__})"
    except Exception as exc:  # noqa: BLE001
        # V85.4: any other exception (e.g. SSL) — treat as transient.
        return True, f"transient:error ({type(exc).__name__})"


# V58 Fix: provider-aware key validation.


async def _provider_key_validate(provider: str, candidate_key: str) -> tuple[bool, str]:
    """V58 Fix: validate a candidate API key for the specified provider.

    Returns (valid, sanitized_reason). Never logs the key.
    """
    if not candidate_key or not candidate_key.strip():
        return False, "Empty key"
    key = candidate_key.strip()

    if provider == "gemini":
        return await _gemini_key_validate(key)
    elif provider == "groq":
        # Groq uses Bearer token auth.
        if len(key) < 20:
            return False, "Key too short for Groq"
        try:
            import httpx
            url = "https://api.groq.com/openai/v1/models"
            headers = {"Authorization": f"Bearer {key}"}
            async with httpx.AsyncClient(timeout=httpx.Timeout(15.0)) as client:
                resp = await client.get(url, headers=headers)
            if resp.status_code == 200:
                return True, "ok"
            elif resp.status_code == 401:
                return False, "Invalid Groq key (401 Unauthorized)"
            elif resp.status_code == 403:
                return False, "Groq permission denied (403 Forbidden)"
            elif resp.status_code == 429:
                # V85.4: rate-limited — do NOT invalidate the key.
                return True, "transient:rate_limited (429) — key not rejected"
            elif 500 <= resp.status_code < 600:
                # V85.4: provider unavailable — do NOT invalidate the key.
                return True, f"transient:provider_unavailable (HTTP {resp.status_code})"
            else:
                # V85.4: unknown HTTP status — treat as transient.
                return True, f"transient:unknown_http_{resp.status_code}"
        except (httpx.TimeoutException, httpx.ConnectError, httpx.NetworkError) as exc:
            return True, f"transient:network_error ({type(exc).__name__})"
        except Exception as exc:
            return True, f"transient:error ({type(exc).__name__})"
    elif provider == "openrouter":
        # OpenRouter uses Bearer token auth.
        if len(key) < 20:
            return False, "Key too short for OpenRouter"
        try:
            import httpx
            url = "https://openrouter.ai/api/v1/auth/key"
            headers = {"Authorization": f"Bearer {key}"}
            async with httpx.AsyncClient(timeout=httpx.Timeout(15.0)) as client:
                resp = await client.get(url, headers=headers)
            if resp.status_code == 200:
                return True, "ok"
            elif resp.status_code == 401:
                return False, "Invalid OpenRouter key (401 Unauthorized)"
            elif resp.status_code == 403:
                return False, "OpenRouter permission denied (403 Forbidden)"
            elif resp.status_code == 402:
                return False, "OpenRouter billing exhausted (402 Payment Required)"
            elif resp.status_code == 429:
                # V85.4: rate-limited — do NOT invalidate the key.
                return True, "transient:rate_limited (429) — key not rejected"
            elif 500 <= resp.status_code < 600:
                # V85.4: provider unavailable — do NOT invalidate the key.
                return True, f"transient:provider_unavailable (HTTP {resp.status_code})"
            else:
                # V85.4: unknown HTTP status — treat as transient.
                return True, f"transient:unknown_http_{resp.status_code}"
        except (httpx.TimeoutException, httpx.ConnectError, httpx.NetworkError) as exc:
            return True, f"transient:network_error ({type(exc).__name__})"
        except Exception as exc:
            return True, f"transient:error ({type(exc).__name__})"
    else:
        return False, f"Unknown provider: {provider}"


async def _provider_key_activate(provider: str, candidate_key: str) -> tuple[bool, str]:
    """V58 Fix: validate + atomically activate a new API key for any provider.

    V85.4 FIX (Req 2): a transient validation result (``valid=True,
    reason="transient:..."``) means the probe was temporarily unavailable
    (429 / 5xx / timeout / network) but the key was NOT rejected.  The key
    is still activated — the runtime provider health engine will confirm
    or deny it on the next real request.  This separates "key validation"
    (is the key format/auth accepted?) from "runtime status" (is the
    provider reachable right now?).
    """
    # 1. Validate the candidate key.
    valid, reason = await _provider_key_validate(provider, candidate_key)
    if not valid:
        return False, reason
    # V85.4: log transient activations so the admin knows the probe was
    # inconclusive (key saved, will be confirmed at runtime).
    if reason.startswith("transient:"):
        logger.info(
            "PROVIDER_KEY_ACTIVATED_TRANSIENT provider=%s reason=%s — key saved, "
            "runtime health will confirm (Req 2: temp failures do not invalidate keys)",
            provider, reason,
        )
        v85_diag("PROVIDER_KEY_SAVED_TRANSIENT", provider=provider, reason=reason[:80])
    # 2. Atomically activate.
    key = candidate_key.strip()
    try:
        if provider == "gemini":
            object.__setattr__(config, "gemini_api_key", key)
            global _gemini_client_cache
            try:
                _gemini_client_cache = None
            except NameError:
                pass
        elif provider == "groq":
            object.__setattr__(config, "groq_api_key", key)
        elif provider == "openrouter":
            object.__setattr__(config, "openrouter_api_key", key)
        else:
            return False, f"Unknown provider: {provider}"
    except Exception as exc:
        return False, f"Runtime activation failed: {type(exc).__name__}"
    # V61: clear exhaustion/cooldown state via the atomic success recorder.
    # Key activation is an explicit admin action that proves the key works
    # end-to-end (validation + post-activation health check already passed
    # above). Record it as a real success — this will trigger confirmed
    # recovery (≥2 successes + stability) if the provider was failing.
    # Capture generation before clearing (the success path checks it).
    gen_before = _provider_current_generation(provider)
    try:
        await _provider_record_success_async(provider, gen_at_start=gen_before)
    except Exception:  # noqa: BLE001
        # Fallback: direct state clear if the async path isn't available.
        st = _provider_get_state(provider)
        st["state"] = "healthy"
        st["failure_class"] = ""
        st["cooldown_until"] = 0.0
        st["cooldown_seconds"] = 0.0
        st["last_error"] = ""
    logger.info("TALKATIVE_PROVIDER_KEY_ACTIVATED provider=%s (key redacted)", provider)
    del key
    return True, "ok"


# V45 Fix #1: dedicated async lock for Gemini key activation.


async def talkative_generate(
    messages: list[dict[str, str]],
    system_prompt: str,
    settings: dict[str, Any],
) -> TalkativeResult:
    """V43 Fix #4: explicit admin-controlled fallback provider dispatch.

    Tries the configured primary provider first. If it fails, ONLY tries
    providers that are EXPLICITLY configured in TALKATIVE_FALLBACK_PROVIDERS.
    Credentials alone NEVER imply fallback consent.

    V42 changes preserved:
    - Providers in cooldown are SKIPPED (no request storm).
    - Failures are classified + recorded in provider health state.
    - Admin DMs on first serious failure (deduplicated).
    - If ALL providers are in cooldown, fails gracefully.
    """
    max_chars = int(settings.get("max_reply_chars", config.talkative_max_reply_chars))
    timeout = int(settings.get("request_timeout", config.talkative_request_timeout))
    primary = (settings.get("provider") or config.talkative_provider or "groq").lower()

    # V43 Fix #4: build the chain — primary first, then ONLY explicitly
    # configured fallback providers. No auto-discovery of other providers.
    chain: list[str] = [primary]
    fallback_str = (config.talkative_fallback_providers or "").strip()
    if fallback_str:
        for cand in fallback_str.split(","):
            cand = cand.strip().lower()
            if cand in ("groq", "openrouter", "gemini") and cand not in chain:
                chain.append(cand)
    # If no explicit fallback is configured, chain = [primary] only.

    visited: set[str] = set()
    last_result: Optional[TalkativeResult] = None
    skipped_cooldown: list[str] = []
    for provider_name in chain:
        if provider_name in visited:
            continue
        visited.add(provider_name)
        handler = _TALKATIVE_PROVIDERS.get(provider_name)
        if handler is None:
            continue
        # V42 Fix #2: skip providers in cooldown (no request storm).
        if _provider_in_cooldown(provider_name):
            remaining = _provider_cooldown_remaining(provider_name)
            skipped_cooldown.append(f"{provider_name}({remaining:.0f}s)")
            logger.info(
                "TALKATIVE_PROVIDER_SKIP provider=%s in_cooldown=%.0fs — skipping",
                provider_name, remaining,
            )
            last_result = TalkativeResult(
                text="", provider=provider_name, model="",
                success=False,
                error=f"{provider_name} in cooldown ({remaining:.0f}s remaining)",
            )
            continue
        try:
            # V61 Fix #5: capture the failure generation at request start so
            # a stale success (from an in-flight request that started before
            # a newer failure) can be detected and ignored for recovery.
            gen_at_start = _provider_current_generation(provider_name)
            # V94 FIX: enforce a hard timeout on ALL provider calls so a slow
            # AI provider (Groq/Gemini/OpenRouter) cannot block the update
            # dispatcher. The provider's own timeout is a courtesy; this is
            # a hard guarantee.
            try:
                result = await asyncio.wait_for(
                    handler(messages, system_prompt, max_chars, timeout),
                    timeout=max(timeout + 10, 60),
                )
            except asyncio.TimeoutError:
                result = TalkativeResult(
                    text="", provider=provider_name, model="",
                    success=False,
                    error=f"provider_timeout_after_{max(timeout + 10, 60)}s",
                )
        except asyncio.CancelledError:
            await _provider_record_failure_async(provider_name, "cancelled", gen_at_start)
            raise
        except Exception as exc:  # noqa: BLE001
            # Sanitize — never log raw exception (may contain API key / token).
            safe_msg = _sanitize_error(f"{provider_name} raised: {exc}")
            logger.warning("Talkative provider %s raised: %s", provider_name, safe_msg)
            result = TalkativeResult(
                text="", provider=provider_name, model="",
                success=False, error=safe_msg,
            )
        last_result = result
        if result.success and result.text:
            # V61 Fix #3: record success with generation — does NOT immediately
            # recover. Requires ≥2 consecutive successes + stability window.
            await _provider_record_success_async(provider_name, gen_at_start)
            return result
        # V42 Fix #2: record failure — classifies, sets cooldown, sends admin DM.
        await _provider_record_failure_async(provider_name, result.error or "unknown", gen_at_start)
        # V92 FIX: promote provider failure to INFO so it's visible in production
        # logs. The previous DEBUG level made it impossible to diagnose why
        # "all_providers_failed" occurred — the admin saw no error details.
        logger.info(
            "TALKATIVE_PROVIDER_FAILED provider=%s class=%s error=%s — trying next.",
            provider_name,
            _provider_classify_error(provider_name, result.error or ""),
            (result.error or "")[:120],
        )

    # All providers failed or in cooldown.
    if skipped_cooldown and last_result and not last_result.success:
        # v97.20 FIX: rate-limit the ALL_COOLDOWN log to once per 60s.
        # The old code logged this warning on EVERY talkative_generate call,
        # causing thousands of identical log lines when a provider had a long
        # cooldown (e.g. 3509s).  Now we log once, then suppress for 60s.
        global _last_all_cooldown_log_at
        _now = time.monotonic()
        if _now - _last_all_cooldown_log_at > 60.0:
            _last_all_cooldown_log_at = _now
            logger.warning(
                "TALKATIVE_PROVIDER_ALL_COOLDOWN skipped=%s — failing gracefully "
                "(suppressing for 60s)",
                ",".join(skipped_cooldown),
            )
        return TalkativeResult(
            text="",
            provider=(last_result.provider if last_result else "none"),
            model=(last_result.model if last_result else ""),
            success=False,
            error=f"All providers in cooldown: {', '.join(skipped_cooldown)}",
        )

    # All providers failed (not cooldown) — return a local fallback.
    # V85.5 FIX (AI-G-003): return success=False with provider="local_fallback"
    # so callers can distinguish a real provider response from a canned
    # apology. The fallback text is preserved so the caller can still send
    # it to the user if it wants to.
    # V92 FIX: log the full chain + last error so the admin can diagnose
    # WHY all providers failed. Previously this was silent.
    logger.warning(
        "TALKATIVE_ALL_PROVIDERS_FAILED chain=%s last_provider=%s last_error=%s",
        chain,
        (last_result.provider if last_result else "none"),
        (last_result.error[:150] if last_result and last_result.error else "none"),
    )
    fallback_text = "Wait, my brain lagged for a second 😅 try that again?"
    return TalkativeResult(
        text=fallback_text,
        provider="local_fallback",
        model="",
        success=False,  # AI-G-003: this is NOT a real provider success
        error=(last_result.error if last_result else "all_providers_failed"),
    )


# --- Trigger detection ------------------------------------------------------


_TALKATIVE_URL_RE = re.compile(r"https?://\S+", re.IGNORECASE)


_TALKATIVE_MENTION_RE = re.compile(r"@([A-Za-z][A-Za-z0-9_]{4,})")


def _talkative_word_boundary_match(text: str, needle: str) -> bool:
    """Case-insensitive whole-word match. Won't match inside URLs or words."""
    if not needle or not text:
        return False
    needle = needle.strip().lower()
    if not needle:
        return False
    text_lower = text.lower()
    # Skip if the needle appears inside a URL.
    # Walk through occurrences with word boundaries.
    pattern = re.compile(r"\b" + re.escape(needle) + r"\b", re.IGNORECASE)
    for m in pattern.finditer(text_lower):
        start = m.start()
        # Check whether this match is inside a URL.
        in_url = False
        for url_m in _TALKATIVE_URL_RE.finditer(text):
            if url_m.start() <= start < url_m.end():
                in_url = True
                break
        if not in_url:
            return True
    return False


def talkative_detect_trigger(update: Update, context: ContextTypes.DEFAULT_TYPE) -> Optional[str]:
    """Detect why this message should trigger a Talkative reply.

    Returns one of:
      * ``"reply"``           — direct reply to the bot's own message
      * ``"mention"``         — @botusername in the text
      * ``"name"``            — bot display name in the text (word-boundary)
      * ``"wake_word"``       — a configured wake word present
      * ``"active_session"``  — user has an active Talkative session in this chat
      * ``"private"``         — private chat auto-reply
      * ``None``              — no trigger

    Detection is case-insensitive and boundary-aware. Mentions inside URLs
    are NOT considered triggers.
    """
    message = update.message
    if message is None:
        return None
    text = (message.text or message.caption or "").strip()
    if not text:
        return None

    chat_id = update.effective_chat.id if update.effective_chat else 0
    user_id = update.effective_user.id if update.effective_user else 0

    # 1. Reply to bot's message.
    reply = message.reply_to_message
    if reply is not None:
        reply_from = getattr(reply, "from_user", None)
        # Check if the replied-to message is from the bot.
        if _bot_id is not None and reply_from is not None and reply_from.id == _bot_id:
            return "reply"
        # Also handle replies to the bot's own sent messages (via Bot API
        # sender_chat for channels, etc.).
        sender_chat = getattr(reply, "sender_chat", None)
        if sender_chat is not None and _bot_id is not None:
            if getattr(sender_chat, "id", None) == _bot_id:
                return "reply"

    # 2. Mention (@botusername).
    if _bot_username:
        uname = _bot_username.lstrip("@").lower()
        for m in _TALKATIVE_MENTION_RE.finditer(text):
            if m.group(1).lower() == uname:
                # Make sure it's not inside a URL.
                start = m.start()
                in_url = any(
                    url_m.start() <= start < url_m.end()
                    for url_m in _TALKATIVE_URL_RE.finditer(text)
                )
                if not in_url:
                    return "mention"

    # 3. Bot display name (word-boundary, case-insensitive).
    if _bot_display_name:
        if _talkative_word_boundary_match(text, _bot_display_name):
            return "name"

    # 4. Wake words (sync wrapper — DB call needs await; handled below).
    # We can't await here (this is a sync function). The async wrapper
    # ``talkative_detect_trigger_async`` performs the wake-word DB lookup.
    # For the sync version, skip wake words (they'll be checked by the caller).

    # 5. Active session for this (chat_id, user_id)? Also can't await here.
    # Handled by the async wrapper.

    # 6. Private chat auto-reply.
    chat_type = getattr(update.effective_chat, "type", None)
    if chat_type == "private":
        return "private"

    return None


async def talkative_detect_trigger_async(
    update: Update, context: ContextTypes.DEFAULT_TYPE,
) -> Optional[str]:
    """Async trigger detection — includes wake_word + active_session checks.

    Priority:
      1. reply           (reply to bot's message)
      2. mention         (@botusername)
      3. name            (bot display name in text)
      4. wake_word       (configured wake words — DB lookup)
      5. active_session  (existing active session for this chat+user)
      6. private         (private chat auto-reply)
    """
    message = update.message
    if message is None:
        return None
    text = (message.text or message.caption or "").strip()
    if not text:
        return None

    chat_id = update.effective_chat.id if update.effective_chat else 0
    user_id = update.effective_user.id if update.effective_user else 0

    # 1. Reply.
    reply = message.reply_to_message
    if reply is not None:
        reply_from = getattr(reply, "from_user", None)
        if _bot_id is not None and reply_from is not None and reply_from.id == _bot_id:
            return "reply"
        sender_chat = getattr(reply, "sender_chat", None)
        if sender_chat is not None and _bot_id is not None:
            if getattr(sender_chat, "id", None) == _bot_id:
                return "reply"

    # 2. Mention.
    if _bot_username:
        uname = _bot_username.lstrip("@").lower()
        for m in _TALKATIVE_MENTION_RE.finditer(text):
            if m.group(1).lower() == uname:
                start = m.start()
                in_url = any(
                    url_m.start() <= start < url_m.end()
                    for url_m in _TALKATIVE_URL_RE.finditer(text)
                )
                if not in_url:
                    return "mention"

    # 3. Name.
    if _bot_display_name:
        if _talkative_word_boundary_match(text, _bot_display_name):
            return "name"

    # 4. Wake words.
    try:
        wake_words = await talkative_get_wake_words(chat_id)
        for w in wake_words:
            word = (w.get("wake_word") or "").strip()
            if word and _talkative_word_boundary_match(text, word):
                return "wake_word"
    except Exception as exc:  # noqa: BLE001
        logger.debug("Talkative wake-word lookup failed: %s", exc)

    # 5. Active session.
    try:
        session = await talkative_get_active_session(chat_id, user_id)
        if session is not None:
            return "active_session"
    except Exception as exc:  # noqa: BLE001
        logger.debug("Talkative session lookup failed: %s", exc)

    # 6. Private chat auto-reply.
    chat_type = getattr(update.effective_chat, "type", None)
    if chat_type == "private":
        return "private"

    return None


# --- Priority workflow guard ------------------------------------------------


# Every state constant the existing workflows use. If the user is in ANY of
# these states, Talkative MUST NOT handle the message — the existing handler
# for that state takes priority.


_TALKATIVE_PRIORITY_STATES: tuple[str, ...] = (
    AWAIT_DOWNLOAD_FORWARD,
    AWAIT_ANALYZE,
    AWAIT_INSPECT,
    AWAIT_TOOLBOX,
    AWAIT_LIBRARY_SEARCH,
    AWAIT_QR,
    AWAIT_BATCH,
    AWAIT_SCHEDULE,
    AWAIT_BACKUP_IMPORT,
    AWAIT_ADMIN_BCAST,
    AWAIT_LINK_DOWNLOAD,
    AWAIT_LINK_MESSAGE_ID,
    AWAIT_MTPROTO_SCREENSHOT,
    AWAIT_MTPROTO_DOWNLOAD,
    AWAIT_MTPROTO_MSGID,
    AWAIT_MEDIA_BROWSE,
    AWAIT_VC_JOIN_TARGET,
    AWAIT_VC_CHECK_TARGET,
    AWAIT_VC_STAY,
    AWAIT_VC_COOLDOWN,
    "await_gemini_key",
)

# User-data flow keys that indicate an in-progress workflow (e.g. mid-link
# resolution, mid-media-browse, mid-scheduled-task). If any of these are
# set, Talkative defers to the existing flow.
#
# ``talkative_pending_input`` is included so that when an admin is in a
# Talkative configuration input mode (wake_add / personality_select) but
# types text that does NOT match the expected prefix, Talkative does not
# fire as a regular chatbot — the admin is configuring, not chatting.
# The marker is also a transient one-shot suppressor: route_message sets
# ``_talkative_just_handled`` after consuming a valid ``wake:``/``personality:``
# input, and talkative_handle_message consumes it to avoid a double
# response (config-reply + chatbot-reply) for the SAME update.


_TALKATIVE_PRIORITY_USER_DATA_KEYS: tuple[str, ...] = (
    "link_from_chat",
    "link_chat_info",
    "mb_chat_ref",
    "mb_by_cat",
    "mb_chat_info",
    "mtproto_chat_ref",
    "sched_run_at",
    "sched_mode",
    "imgconv_msg_id",
    "imgconv_chat_id",
    "talkative_pending_input",
)


def _talk_set_pending_input(context: ContextTypes.DEFAULT_TYPE,
                            mode: str) -> None:
    """Atomically set the Talkative pending-input marker.

    Replaces any previous marker (e.g. switching from wake mode to
    personality mode) in a single assignment so there is no window where
    zero or two markers are live.  ``mode`` must be a non-empty string
    (``"wake_add"`` or ``"personality_select"``).
    """
    if context is None or context.user_data is None:
        return
    context.user_data["talkative_pending_input"] = mode


def _talk_clear_pending_input(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Clear the Talkative pending-input marker if present.

    Called on every exit path from a Talkative configuration input mode:
    valid input, invalid input, Back, menu navigation, cancellation, and
    when switching to a different workflow.  Idempotent.
    """
    if context is None or context.user_data is None:
        return
    context.user_data.pop("talkative_pending_input", None)


def _talkative_has_priority_workflow(context: ContextTypes.DEFAULT_TYPE,
                                     update: Update) -> bool:
    """Return True if an existing workflow should take priority over Talkative.

    Checks:
      * The user's current state (any AWAIT_* constant).
      * ``context.user_data`` for in-progress flow keys.
      * ``talkative_pending_input`` (admin is mid Talkative config input).
      * ``_talkative_just_handled`` (route_message just consumed a valid
        ``wake:``/``personality:`` input on this exact update — prevents
        a double response from the group=10 Talkative chatbot handler).
    """
    user_id = update.effective_user.id if update.effective_user else 0
    if user_id == 0:
        return False
    # State check (sync lookup to avoid await overhead — this is a hot path).
    state = get_state_sync(user_id)
    if state and state != IDLE and state in _TALKATIVE_PRIORITY_STATES:
        return True
    # User-data flow keys.
    user_data = context.user_data if context is not None else None
    if user_data:
        for key in _TALKATIVE_PRIORITY_USER_DATA_KEYS:
            if user_data.get(key):
                return True
    return False


# --- System prompt builder --------------------------------------------------


def _sanitize_prompt_field(s: str, max_len: int = 200) -> str:
    """V85.5 FIX (AI-G-002): strip newlines and control characters from a
    user-supplied string before interpolating it into an LLM system prompt.

    Prevents prompt-injection via multi-line personality / chat-title fields
    (a malicious admin could otherwise embed additional instructions, role
    overrides, or empty lines that confuse the model). Truncates to
    ``max_len`` so a single field can't dominate the prompt budget.
    """
    if not s:
        return ""
    # Strip ALL control chars except regular spaces (0x20). This includes
    # \n, \r, \t, \v, \f, \x00-\x1F, \x7F (DEL), and Unicode line/paragraph
    # separators (\x85, \u2028, \u2029).
    cleaned = re.sub(r"[\x00-\x1f\x7f-\xa9\xad\u2028\u2029]", " ", str(s))
    # Collapse runs of whitespace into a single space.
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    if max_len > 0:
        cleaned = cleaned[:max_len]
    return cleaned


def _talkative_build_system_prompt(settings: dict[str, Any],
                                   trigger: str,
                                   chat_title: str = "",
                                   *,
                                   intent: str = "",
                                   detected_language: str = "",
                                   conversation_summary: str = "") -> str:
    """Build the system prompt for the LLM call.

    V85.5 FIX (AI-G-002): ``personality`` and ``chat_title`` are sanitized
    via ``_sanitize_prompt_field`` before interpolation to prevent
    prompt-injection via multi-line / control-char payloads.

    P5 UPGRADE: richer personality description, detected-language instruction,
    conversation-intent hint, and recent conversation summary are folded into
    the prompt so the LLM produces more natural, context-aware, multilingual
    replies. All user-controlled AND runtime-derived fields are sanitized.
    Total prompt is capped at ~1500 chars to avoid token bloat.
    """
    # AI-G-002: sanitize user-controlled fields before interpolation.
    personality = _sanitize_prompt_field(
        (settings.get("personality") or "").strip(), max_len=200,
    )
    safe_chat_title = _sanitize_prompt_field(chat_title, max_len=200)
    language_mode = (settings.get("language_mode") or "auto").strip()
    # P5: sanitize runtime-derived fields too — they originate from user text.
    safe_intent = _sanitize_prompt_field(intent or "", max_len=60)
    safe_lang = _sanitize_prompt_field(detected_language or "", max_len=16)
    safe_summary = _sanitize_prompt_field(conversation_summary or "", max_len=400)
    safe_trigger = _sanitize_prompt_field(trigger or "", max_len=40)
    parts: list[str] = []
    # P5: richer, warmer, context-aware personality description.
    parts.append(
        "You are 'MediaGrab AI Bot', a warm, helpful, witty Telegram "
        "assistant. You give concise, natural, conversational replies. "
        "You remember context from earlier in the conversation and refer "
        "back to it when relevant. You adapt your tone to match the user — "
        "casual when they are casual, focused when they are technical. "
        "Avoid markdown formatting unless explicitly asked — Telegram parses "
        "Markdown strictly and your message may fail to send. Plain text only."
    )
    if personality:
        parts.append(f"Personality: {personality}")
    # P5: explicit detected-language instruction (falls back to language_mode).
    if safe_lang and safe_lang not in ("auto", "en"):
        parts.append(f"Reply in the user's language ({safe_lang}). "
                     f"Match their script and vocabulary naturally.")
    elif language_mode and language_mode != "auto":
        parts.append(f"Always reply in: {language_mode}")
    else:
        parts.append(
            "Reply in the same language the user wrote in. "
            "If unsure, use English."
        )
    if safe_chat_title:
        parts.append(f"Chat context: this conversation is happening in the "
                     f"'{safe_chat_title}' chat.")
    # P5: conversation summary (from memory compression).
    if safe_summary:
        parts.append(f"Earlier in this conversation: {safe_summary}")
    # P5: detected intent hint — steer the LLM's framing of the reply.
    if safe_intent and safe_intent not in ("unknown", "statement", ""):
        intent_hint = {
            "greeting": "The user is greeting you — reply warmly and briefly.",
            "question": "The user is asking a question — answer helpfully and concisely.",
            "thanks": "The user is thanking you — acknowledge warmly, no need to be verbose.",
            "farewell": "The user is saying goodbye — bid farewell briefly.",
        }.get(safe_intent, f"The user's intent appears to be: {safe_intent}.")
        parts.append(intent_hint)
    parts.append(
        f"Trigger reason: the bot was invoked via '{safe_trigger}'. "
        f"Respond naturally — do not mention the trigger type to the user."
    )
    parts.append(
        "If a user asks about downloading media, AI analysis, QR codes, "
        "media tools, or any bot feature, briefly mention the relevant "
        "menu button they can tap. Don't make up features that don't exist."
    )
    prompt = "\n\n".join(parts)
    # P5: cap at ~1500 chars to avoid token bloat. Truncate cleanly at the
    # last paragraph boundary so we never cut mid-sentence into garbage.
    if len(prompt) > 1500:
        cut = prompt[:1497].rsplit("\n\n", 1)
        prompt = (cut[0] if len(cut) > 1 else cut[0]) + "…"
    return prompt


# ===========================================================================
# ADAPTIVE MULTIMODAL CONTEXT-AWARE TALKATIVE ENGINE
# ===========================================================================
# Shared adaptive conversational core for both text chat and live VC.
# Extends the existing Talkative infrastructure — does NOT create a duplicate
# chatbot or parallel memory system.
#
# Architecture:
#   - SharedAdaptiveCore: per-group context, topic, summary, engagement score
#   - EngagementDecisionEngine: 12+ signal scoring → respond/silent/clarify
#   - TextChatAdapter: upgrades talkative_handle_message with engagement
#   - VCAudioAdapter: VAD→STT→turn→engage→AI→TTS→playback framework
#   - MemoryManager: importance scoring, decay, summarization, cross-mode
#   - ConcurrencyManager: per-chat lock, in-flight registry, stale cancel
#
# Reuses: talkative_generate, talkative_effective_settings, _talkative_*,
#         talkative_memory, talkative_sessions, _talkative_has_priority_workflow,
#         VC participation registry, Multi-VC architecture, task supervision.
# ===========================================================================


# --- Per-group adaptive context (in-memory, bounded) ---


@dataclass
class AdaptiveGroupContext:
    """Bounded per-group conversation context shared across text + VC.

    #1: tracks active topic, recent turns, unresolved questions, who asked
    what, recent bot replies, and a compact conversation summary.
    """
    chat_id: int
    active_topic: str = ""
    recent_turns: list[dict[str, Any]] = field(default_factory=list)  # bounded
    unresolved_questions: list[str] = field(default_factory=list)
    recent_bot_replies: list[str] = field(default_factory=list)  # for dedup #17
    compact_summary: str = ""
    # Engagement state (#6 adaptive talk probability)
    engagement_score: float = 0.3  # 0.0-1.0, starts neutral-low
    consecutive_bot_messages: int = 0
    last_bot_message_at: float = 0.0
    # Per-user context inside the group
    user_contexts: dict[int, dict[str, Any]] = field(default_factory=dict)
    # Language detection (#13)
    detected_language: str = "auto"
    # Group culture (#14)
    avg_response_length: int = 100
    formality: str = "casual"
    # VC audio state (per-group, isolated for Multi-VC safety #26)
    vc_active: bool = False
    vc_speaking: bool = False
    vc_consecutive_turns: int = 0
    vc_last_speech_end: float = 0.0
    vc_speaker_map: dict[int, str] = field(default_factory=dict)  # ssrc/user_id → display name
    # Concurrency (#19)
    generation_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    in_flight_responses: dict[str, dict[str, Any]] = field(default_factory=dict)
    # Anti-spam budget (#18)
    reply_timestamps: list[float] = field(default_factory=list)
    # Feedback learning (#27)
    positive_signals: int = 0
    negative_signals: int = 0
    ignored_replies: int = 0

    def add_turn(self, speaker_id: int, speaker_name: str, content: str,
                 *, role: str = "user", source: str = "chat") -> None:
        """Add a conversation turn (bounded to 30 recent turns)."""
        self.recent_turns.append({
            "speaker_id": speaker_id, "speaker_name": speaker_name,
            "content": content[:500], "role": role, "source": source,
            "ts": time.monotonic(),
        })
        if len(self.recent_turns) > 30:
            del self.recent_turns[: len(self.recent_turns) - 30]
        # Track per-user context
        uc = self.user_contexts.setdefault(speaker_id, {
            "name": speaker_name, "turns": 0, "last_message": "",
        })
        uc["turns"] += 1
        uc["last_message"] = content[:200]
        # Detect topic change (simple: if content shares no words with recent)
        if role == "user":
            self._detect_topic_change(content)

    def _detect_topic_change(self, content: str) -> None:
        """#1: detect topic changes and decay stale context."""
        if not self.active_topic:
            # First message — set as topic (first 5 significant words).
            words = [w for w in content.split() if len(w) > 2][:5]
            self.active_topic = " ".join(words)
            return
        # Simple word-overlap check: if < 20% overlap with active_topic,
        # consider it a topic change.
        topic_words = set(self.active_topic.lower().split())
        content_words = set(content.lower().split())
        if topic_words:
            overlap = len(topic_words & content_words) / len(topic_words)
            if overlap < 0.2:
                # Topic changed — decay old context slightly.
                self.active_topic = " ".join(
                    [w for w in content.split() if len(w) > 2][:5])
                logger.debug("TALKATIVE_TOPIC_CHANGE chat=%s new_topic=%s",
                             self.chat_id, self.active_topic[:40])

    def add_bot_reply(self, reply: str) -> None:
        """Track recent bot replies for duplicate suppression (#17)."""
        self.recent_bot_replies.append(reply[:300])
        if len(self.recent_bot_replies) > 10:
            del self.recent_bot_replies[: len(self.recent_bot_replies) - 10]
        self.consecutive_bot_messages += 1
        self.last_bot_message_at = time.monotonic()
        # Anti-spam budget
        self.reply_timestamps.append(time.monotonic())
        # Trim to last 60 seconds
        cutoff = time.monotonic() - 60
        self.reply_timestamps = [t for t in self.reply_timestamps if t > cutoff]

    def reset_consecutive_bot(self) -> None:
        """Call when a non-bot message arrives (resets anti-spam counter)."""
        self.consecutive_bot_messages = 0

    def is_duplicate_reply(self, text: str) -> bool:
        """#17: check if the proposed reply is semantically repetitive.

        P5 UPGRADE:
        - Lowered word-overlap threshold from 0.8 → 0.65 (more aggressive).
        - Normalize whitespace + punctuation before comparison so trivial
          differences (extra spaces, trailing periods, em-dashes vs hyphens)
          don't evade detection.
        - Detect common filler openings ("I'll help you with that",
          "Sure, I can do that", "Of course!") — if the last 2 bot replies
          used a similar filler, flag the new one as a duplicate even if
          the body text differs. This stops the bot from prefixing every
          reply with the same polite throat-clearing.
        """
        # P5: normalize whitespace + punctuation for stable comparison.
        def _norm(s: str) -> str:
            s = (s or "").lower()
            # Collapse all whitespace runs to single spaces.
            s = re.sub(r"\s+", " ", s)
            # Strip leading/trailing punctuation + spaces.
            s = re.sub(r"^[\s\W_]+|[\s\W_]+$", "", s)
            # Collapse repeated punctuation (e.g. "..." → ".", "!!" → "!").
            s = re.sub(r"([!?.,])\1+", r"\1", s)
            return s.strip()[:200]

        text_norm = _norm(text)
        if not text_norm:
            return False
        # P5: filler-pattern detection. If the proposed reply starts with a
        # common polite filler AND any of the last 2 bot replies also started
        # with a filler, treat as duplicate (the bot is stuck in a polite
        # opening loop).
        filler_patterns = (
            "i'll help you with that", "i will help you with that",
            "sure, i can do that", "sure i can do that",
            "of course", "certainly", "absolutely",
            "i'd be happy to", "i would be happy to",
            "let me help you", "i can help you with",
            "no problem", "no worries",
        )
        text_starts_with_filler = any(
            text_norm.startswith(fp) for fp in filler_patterns)
        if text_starts_with_filler:
            recent_filler_count = 0
            for prev in self.recent_bot_replies[-2:]:
                prev_norm = _norm(prev)
                if any(prev_norm.startswith(fp) for fp in filler_patterns):
                    recent_filler_count += 1
            if recent_filler_count >= 1:
                return True  # P5: filler-loop detected
        for prev in self.recent_bot_replies:
            prev_norm = _norm(prev)
            if text_norm == prev_norm:
                return True
            # P5: word-overlap check — threshold lowered 0.8 → 0.65.
            prev_words = set(prev_norm.split())
            text_words = set(text_norm.split())
            if prev_words and text_words:
                overlap = len(prev_words & text_words) / max(len(prev_words), len(text_words))
                if overlap > 0.65 and len(text_words) > 3:
                    return True
        return False

    def check_spam_budget(self) -> tuple[bool, str]:
        """#18: check anti-spam participation budget. Returns (allowed, reason)."""
        # Max replies per minute
        if len(self.reply_timestamps) >= config.talkative_max_replies_per_minute:
            return False, "rate_limit_per_minute"
        # Max consecutive bot messages
        if self.consecutive_bot_messages >= config.talkative_max_consecutive_bot:
            return False, "max_consecutive_bot"
        return True, ""


# Global registry of per-group adaptive contexts (bounded).


_adaptive_contexts: dict[int, AdaptiveGroupContext] = {}


_adaptive_contexts_lock = asyncio.Lock()


async def _adaptive_get_context(chat_id: int) -> AdaptiveGroupContext:
    """Get or create the adaptive context for a group (thread-safe)."""
    ctx = _adaptive_contexts.get(chat_id)
    if ctx is not None:
        return ctx
    async with _adaptive_contexts_lock:
        ctx = _adaptive_contexts.get(chat_id)
        if ctx is None:
            ctx = AdaptiveGroupContext(chat_id=chat_id)
            _adaptive_contexts[chat_id] = ctx
            # Bounded: trim if too many groups
            if len(_adaptive_contexts) > 500:
                # Remove oldest by last activity
                oldest = min(_adaptive_contexts.values(),
                             key=lambda c: c.last_bot_message_at)
                _adaptive_contexts.pop(oldest.chat_id, None)
        return ctx


# --- Engagement Decision Engine (#5, #6) ---


async def _adaptive_engagement_score(
    ctx: AdaptiveGroupContext,
    *, trigger: str, user_id: int, text: str, is_private: bool,
    settings: dict[str, Any],
) -> tuple[float, str]:
    """V49 Fix: calculate an engagement score (0.0-1.0) and decision reason.

    V49 changes:
    - Private DMs with private_auto_reply=True start at 0.8 (not 0.4) and
      bypass the per-chat engagement multiplier. This ensures DMs actually
      get a reply when private auto-reply is enabled.
    - Ambient group messages start at 0.3 (not 0.05) — the old 0.05 base
      × 0.5 multiplier = 0.025 was structurally guaranteed to fail.
    - The per-chat engagement multiplier defaults to 1.0 (not 0.5). The old
      default of 0.5 halved ALL scores, making nearly everything fail.
    - Mention/reply/wake_word start at 0.7 (not 0.5) to ensure they pass
      the 0.5 threshold even before bonus points.

    Returns (score, reason).
    """
    score = 0.0
    reasons: list[str] = []

    # V49 Fix: private DMs with auto-reply enabled get high engagement.
    if trigger in ("private", "private_media"):
        # Check if private auto-reply is enabled.
        par = bool(settings.get("private_auto_reply", config.talkative_private_auto_reply))
        if par:
            score = 0.8  # V49: was 0.4 — too low to pass threshold after multiplier
            reasons.append("private_auto_reply")
        else:
            score = 0.3
            reasons.append("private_no_auto_reply")
    # Direct mention / reply / wake word → high engagement
    elif trigger in ("reply", "mention", "name", "wake_word"):
        score += 0.7  # V49: was 0.5 — too low after 0.5 multiplier
        reasons.append(f"trigger={trigger}")
    elif trigger == "active_session":
        score += 0.5  # V49: was 0.3
        reasons.append("ongoing_conversation")
    else:
        # Ambient — V57 Fix #4: base 0.55 so ambient passes the 0.5 threshold
        # in chat/both mode. Was 0.3 (below threshold → engagement_rejected).
        # The engagement gate is still meaningful: busy_group reduction (×0.5),
        # negative feedback (×0.7), and consecutive-bot limit can still suppress.
        score += 0.55
        reasons.append("ambient")

    # Follow-up intent detection (#2): "why?", "how?", "show me", "continue"
    text_lower = text.lower().strip()
    follow_ups = {"why", "how", "show me", "what about", "continue",
                  "explain", "more", "again", "repeat", "elaborate"}
    if any(text_lower.startswith(fu) or text_lower == fu for fu in follow_ups):
        score += 0.2
        reasons.append("follow_up_intent")

    # P5 UPGRADE: stronger direct-question detection. Old code only added
    # +0.1 when a literal '?' was present. Now we also detect question
    # words and English/Spanish/Chinese question marks, with a larger
    # boost so genuine questions clear the engagement threshold even in
    # noisy groups.
    question_words = ("what", "why", "how", "when", "where", "who",
                      "which", "can you", "could you", "would you",
                      "do you", "are you", "is it", "should i",
                      "\u00bf", "\uff1f")
    is_question = ("?" in text) or any(
        text_lower.startswith(qw) or f" {qw}" in text_lower
        for qw in question_words)
    if is_question:
        score += 0.15  # P5: was 0.1
        reasons.append("direct_question")

    # P5 UPGRADE: bot-name mention boost. The trigger detection above
    # already routes proper @mentions / replies to trigger=mention|reply
    # (score += 0.7), but a user can also type the bot's display name in
    # flowing prose without triggering the entity-based mention check.
    # Catch that case here so the bot replies when explicitly called.
    try:
        _ub_name = (_userbot_display_name or "").lower().strip()
        _ub_uname = (_userbot_username or "").lstrip("@").lower().strip()
    except Exception:  # noqa: BLE001 — globals may be unset
        _ub_name, _ub_uname = "", ""
    if _ub_name and len(_ub_name) > 2 and _ub_name in text_lower:
        score += 0.2
        reasons.append("bot_name_mention")
    elif _ub_uname and len(_ub_uname) > 2 and _ub_uname in text_lower:
        score += 0.2
        reasons.append("bot_username_mention")

    # Topic relevance (#5): if the text shares words with active_topic
    if ctx.active_topic:
        topic_words = set(ctx.active_topic.lower().split())
        text_words = set(text_lower.split())
        if topic_words and text_words:
            overlap = len(topic_words & text_words) / len(topic_words)
            score += overlap * 0.1
            if overlap > 0.3:
                reasons.append("topic_relevant")

    # Recent bot participation (#5): if bot spoke recently, boost slightly.
    # P5 UPGRADE: distinguish "bot just replied <10s ago" (avoid double-
    # replying, reduce score) from "bot replied 10-60s ago" (boost — the
    # conversation is active and a follow-up is likely on-topic). The old
    # code boosted uniformly for any reply within 60s, which caused the
    # bot to double-reply in fast-moving chats.
    if ctx.last_bot_message_at > 0:
        elapsed = time.monotonic() - ctx.last_bot_message_at
        if elapsed < 10:
            score -= 0.2
            reasons.append("bot_just_replied")
        elif elapsed < 60:
            score += 0.1
            reasons.append("recent_bot_participation")

    # P5 UPGRADE: very-active-user-conversation signal. If the group has
    # seen many user turns in the last 60s (rapid-fire chat), slightly
    # reduce the score to avoid spamming. This is independent of the
    # bot-activity-based busy_group_reduction below.
    try:
        _now_mono = time.monotonic()
        _recent_user_turns = sum(
            1 for t in ctx.recent_turns
            if t.get("role") == "user"
            and _now_mono - float(t.get("ts", 0.0)) < 60.0
        )
    except Exception:  # noqa: BLE001
        _recent_user_turns = 0
    if _recent_user_turns >= 6:
        score -= 0.1
        reasons.append("very_active_user_conversation")

    # Adaptive talk probability (#6): adjust based on feedback signals
    if ctx.negative_signals > ctx.positive_signals:
        score *= 0.7  # reduce if users have been ignoring/correcting
        reasons.append("negative_feedback_penalty")
    elif ctx.positive_signals > ctx.negative_signals:
        score *= 1.2  # boost if users have been engaging
        reasons.append("positive_feedback_boost")

    # Group activity level (#5): busy groups → reduce ambient participation
    recent_activity = len([t for t in ctx.reply_timestamps if t > time.monotonic() - 60])
    if recent_activity > 3 and trigger not in ("reply", "mention", "name", "wake_word", "private", "private_media"):
        score *= 0.5
        reasons.append("busy_group_reduction")

    # Consecutive bot messages (#18): if already at max, heavily penalize
    if ctx.consecutive_bot_messages >= config.talkative_max_consecutive_bot:
        score = 0.0
        reasons.append("max_consecutive_bot_reached")

    # V49 Fix: per-chat engagement preference defaults to 1.0 (was 0.5).
    # The old 0.5 default halved ALL scores, making nearly everything fail.
    # For private DMs with auto-reply, skip this multiplier entirely.
    # V55 Fix #2: private_media gets the same multiplier bypass as private.
    if trigger not in ("private", "private_media") or not settings.get("private_auto_reply", config.talkative_private_auto_reply):
        chat_engagement = float(settings.get("engagement_score", 1.0))  # V49: was 0.5
        score *= chat_engagement

    # Clamp
    score = max(0.0, min(1.0, score))
    return score, "+".join(reasons) if reasons else "default"


# --- Concurrency Protection + Stale Response Cancellation (#19, #20) ---


async def _adaptive_claim_response(
    ctx: AdaptiveGroupContext, event_id: str,
) -> bool:
    """#19: atomically claim a response slot for a conversation event.

    Returns True if claimed (proceed with generation), False if another
    worker is already generating for the same event.
    """
    async with ctx.generation_lock:
        if event_id in ctx.in_flight_responses:
            return False  # already in-flight
        ctx.in_flight_responses[event_id] = {
            "started_at": time.monotonic(),
            "topic": ctx.active_topic,
        }
        return True


async def _adaptive_release_response(
    ctx: AdaptiveGroupContext, event_id: str,
) -> None:
    """Release a claimed response slot."""
    async with ctx.generation_lock:
        ctx.in_flight_responses.pop(event_id, None)


async def _adaptive_check_stale(
    ctx: AdaptiveGroupContext, event_id: str,
    *, max_age: float = 10.0,
) -> bool:
    """#20: check if a response is stale before sending.

    Returns True if stale (should cancel), False if still fresh.
    """
    async with ctx.generation_lock:
        entry = ctx.in_flight_responses.get(event_id)
        if entry is None:
            return True  # already released or superseded
        age = time.monotonic() - entry["started_at"]
        if age > max_age:
            return True
        # Check if topic changed during generation
        if entry.get("topic") != ctx.active_topic and ctx.active_topic:
            return True
        return False


# --- Memory Importance Scoring + Decay (#11, #12) ---


def _adaptive_score_memory_importance(
    content: str, role: str, *,
    is_preference: bool = False, is_correction: bool = False,
    is_question: bool = False, is_recurring: bool = False,
) -> float:
    """#11: score memory importance (0.0-1.0) before persistence.

    Higher: explicit preferences, unresolved tasks, recurring topics,
    corrections, stable conversation facts.
    Lower: greetings, random jokes, repetitive messages, irrelevant chatter.
    """
    score = 0.3  # baseline
    if is_preference:
        score = 0.9
    elif is_correction:
        score = 0.8
    elif is_question:
        score = 0.6
    elif is_recurring:
        score = 0.7
    # Penalize greetings and short messages
    content_lower = content.lower().strip()
    greetings = {"hi", "hello", "hey", "yo", "sup", "gm", "gn", "bye"}
    if content_lower in greetings or len(content_lower) < 5:
        score *= 0.3
    # Boost factual statements (contains "is", "are", "was", "will be")
    if any(w in content_lower for w in (" is ", " are ", " was ", " will be ")):
        score += 0.1
    return max(0.0, min(1.0, score))


async def _adaptive_memory_decay(ctx: AdaptiveGroupContext) -> None:
    """#12: apply TTL decay to stale memory. Summarize when token limit approached."""
    try:
        db = await get_db()
        now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        # Expire low-importance memory past TTL
        await db.execute(
            "DELETE FROM talkative_memory "
            "WHERE chat_id = ? AND importance < 0.3 "
            "AND ttl_expires_at IS NOT NULL AND ttl_expires_at < ?",
            (ctx.chat_id, now_iso),
        )
        await db.commit()
        # Check if we need to summarize
        async with db.execute(
            "SELECT COUNT(*) as c FROM talkative_memory "
            "WHERE chat_id = ? AND is_summary = 0",
            (ctx.chat_id,),
        ) as cur:
            count = (await cur.fetchone())["c"]
        if count > config.talkative_memory_summarize_threshold:
            # P5 (Task 5): explicit log line the moment summarization is
            # triggered (before the actual summarize call). The summarize
            # function itself logs TALKATIVE_MEMORY_SUMMARIZED on success.
            logger.info(
                "TALKATIVE_MEMORY_SUMMARIZE_TRIGGERED chat=%s raw_turns=%d "
                "threshold=%d — compressing old turns to keep memory bounded",
                ctx.chat_id, count, int(config.talkative_memory_summarize_threshold),
            )
            await _adaptive_summarize_memory(ctx)
    except Exception as exc:  # noqa: BLE001
        logger.debug("TALKATIVE_MEMORY_DECAY error: %s", exc)


async def _adaptive_summarize_memory(ctx: AdaptiveGroupContext) -> None:
    """#12: summarize older conversation turns into a compact summary.

    #9 fix: uses LLM-based semantic summarization instead of shallow
    concatenation.  Falls back to structured deterministic compression
    if the LLM call fails.
    #10 fix: validates the summary is non-empty BEFORE deleting raw turns.
    #11 fix: uses a transaction so raw turns are only deleted if the summary
    insertion succeeds — atomic, no data loss on failure.
    #76 / ERR-H-007 fix: uses aiosqlite's ``async with db`` context manager
    (NOT raw BEGIN/COMMIT/ROLLBACK) for transaction safety — auto-commits
    on success, auto-rolls-back on exception, and avoids the
    "cannot use COMMIT inside a transaction" pitfall in newer sqlite
    versions. Verified functional in P5 audit.
    """
    try:
        db = await get_db()
        # Fetch old non-summary memory
        async with db.execute(
            "SELECT role, content FROM talkative_memory "
            "WHERE chat_id = ? AND is_summary = 0 "
            "ORDER BY created_at ASC LIMIT ?",
            (ctx.chat_id, config.talkative_memory_summarize_threshold),
        ) as cur:
            rows = await cur.fetchall()
        if not rows:
            return
        # #9: try LLM-based semantic summarization first.
        summary = ""
        try:
            # Build a summarization prompt.
            conversation_text = "\n".join(
                f"{r['role']}: {r['content'][:200]}" for r in rows
            )
            summarize_messages = [
                {"role": "system", "content": (
                    "Summarize the following conversation in 2-3 sentences. "
                    "Preserve: key topics discussed, any decisions made, "
                    "unresolved questions, and important facts. "
                    "Be concise. Plain text only."
                )},
                {"role": "user", "content": conversation_text[:3000]},
            ]
            # V41 Fix #7: use the EFFECTIVE provider (dashboard DB → env → default).
            try:
                _eff_prov, _eff_src, _eff_model, _eff_ready, _eff_reason = (
                    await talkative_effective_provider())
            except Exception:  # noqa: BLE001
                _eff_prov, _eff_src, _eff_ready = config.talkative_provider, "error", False
            result = await talkative_generate(
                summarize_messages,
                "You are a conversation summarizer. Be concise and factual.",
                {"provider": _eff_prov,
                 "max_reply_chars": 500,
                 "request_timeout": 10},
            )
            if result.success and result.text and len(result.text.strip()) > 10:
                summary = result.text.strip()[:500]
        except Exception:  # noqa: BLE001
            pass  # fall back to deterministic compression
        # #9 fallback: deterministic structured compression if LLM failed.
        if not summary:
            # Extract key information: topics, questions, facts.
            topics: set[str] = set()
            questions: list[str] = []
            facts: list[str] = []
            for r in rows:
                content = r["content"]
                if "?" in content:
                    questions.append(content[:80])
                # Extract significant words (len>3) as topic candidates.
                for w in content.split():
                    wl = w.lower().strip(".,!?;:\"'")
                    if len(wl) > 3 and wl not in ("that", "this", "with", "have",
                                                   "they", "your", "from", "will"):
                        topics.add(wl)
            # Build structured summary.
            parts = []
            if topics:
                parts.append(f"Topics: {', '.join(list(topics)[:8])}")
            if questions:
                parts.append(f"Open questions: {'; '.join(questions[:3])}")
            if not parts:
                # Last resort: first 80 chars of each turn (better than 50).
                parts = [f"{r['role']}: {r['content'][:80]}" for r in rows[:5]]
            summary = " | ".join(parts)[:500]
        # #10/#11: validate summary before destructive deletion.
        if not summary or len(summary.strip()) < 5:
            logger.warning("TALKATIVE_SUMMARIZE_SKIP chat=%s — summary too short, keeping raw turns", ctx.chat_id)
            return
        # #76: atomic transaction — delete + insert as one unit.
        # ERR-H-007: use aiosqlite's `async with db` context manager instead of
        # raw BEGIN/COMMIT/ROLLBACK — it auto-commits on success and auto-
        # rolls-back on exception (and avoids "cannot use COMMIT inside a
        # transaction" / nested-transaction pitfalls in newer sqlite versions).
        try:
            async with db:
                # Delete old raw turns.
                await db.execute(
                    "DELETE FROM talkative_memory "
                    "WHERE chat_id = ? AND is_summary = 0 "
                    "AND id IN (SELECT id FROM talkative_memory "
                    "WHERE chat_id = ? AND is_summary = 0 ORDER BY created_at ASC LIMIT ?)",
                    (ctx.chat_id, ctx.chat_id, config.talkative_memory_summarize_threshold),
                )
                # Insert summary.
                await db.execute(
                    "INSERT INTO talkative_memory (chat_id, user_id, role, content, "
                    "importance, is_summary) VALUES (?, 0, 'system', ?, 0.8, 1)",
                    (ctx.chat_id, summary),
                )
        except Exception as exc:  # noqa: BLE001
            logger.warning("TALKATIVE_SUMMARIZE_TRANSACTION_FAILED chat=%s: %s", ctx.chat_id, exc)
            return
        ctx.compact_summary = summary[:500]
        _talkative_engine_metrics["summaries_created"] += 1
        logger.info("TALKATIVE_MEMORY_SUMMARIZED chat=%s turns_summarized=%d summary_len=%d",
                    ctx.chat_id, len(rows), len(summary))
    except Exception as exc:  # noqa: BLE001
        logger.debug("TALKATIVE_SUMMARIZE error: %s", exc)


# --- Per-Group Mode Management (#4) ---


async def talkative_get_mode(chat_id: int) -> str:
    """V45 Fix #3/#5: get the effective Talkative mode for a chat.

    V45 changes:
    - When `talkative_mode` is NULL but `enabled=True` exists in the per-chat
      row, derive the mode from `enabled` (bridge the dashboard toggle to the
      runtime gate). This fixes the contradiction where the dashboard shows
      "Enabled: ✅ on" but the runtime gate shows "mode=off".
    - For private DMs (positive chat_id), when no explicit per-chat row exists
      and `private_auto_reply=True`, return "chat" (Fix #5: absent peer row
      + private_auto_reply ON → eligible).
    - Deterministic precedence:
      1. Explicit per-chat talkative_mode (non-NULL)
      2. Explicit per-chat enabled (True → "chat", False → "off")
      3. Global talkative_mode (non-NULL)
      4. config.talkative_default_mode

    Returns: off / chat / vc / both
    """
    try:
        db = await get_db()
        # 1. Check per-chat override: both talkative_mode AND enabled.
        async with db.execute(
            "SELECT talkative_mode, enabled FROM talkative_chat_settings WHERE chat_id = ?",
            (chat_id,),
        ) as cur:
            row = await cur.fetchone()
        if row:
            # 1a. Explicit talkative_mode (non-NULL) — highest priority.
            tm = row["talkative_mode"] if "talkative_mode" in row.keys() else None
            if tm:
                return tm.strip().lower()
            # 1b. V45 Fix #3: derive mode from `enabled` column (bridge).
            # This fixes the dashboard "Enable in this chat" → runtime gate
            # contradiction. If enabled=True and talkative_mode is NULL,
            # the mode should be "chat" (not "off").
            en = row["enabled"] if "enabled" in row.keys() else None
            if en is not None:
                en_val = bool(int(en))
                if en_val:
                    return "chat"
                else:
                    return "off"
        # 2. V45 Fix #5: for private DMs (positive chat_id), if no explicit
        # per-chat row exists and private_auto_reply is ON, the peer is
        # eligible for chat. Don't let an absent row silently become OFF
        # while the UI says Private auto-reply is ON.
        if chat_id > 0:
            # Private DM — check private_auto_reply.
            async with db.execute(
                "SELECT private_auto_reply FROM talkative_global_settings WHERE id = 1"
            ) as cur:
                glob_row = await cur.fetchone()
            if glob_row:
                par = glob_row["private_auto_reply"] if "private_auto_reply" in glob_row.keys() else None
                if par is not None and bool(int(par)):
                    return "chat"
        # 3. Fall back to global talkative_mode.
        async with db.execute(
            "SELECT talkative_mode FROM talkative_global_settings WHERE id = 1"
        ) as cur:
            row = await cur.fetchone()
        if row and row["talkative_mode"]:
            return row["talkative_mode"].strip().lower()
    except Exception as exc:  # noqa: BLE001
        logger.debug("TALKATIVE_MODE_GET error chat=%s: %s", chat_id, exc)
    # 4. Fall back to config default.
    return config.talkative_default_mode.strip().lower()


async def talkative_set_mode(chat_id: int | None, mode: str) -> None:
    """#4: set Talkative mode for a group (chat_id=None = global default)."""
    mode = mode.strip().lower()
    if mode not in ("off", "chat", "vc", "both"):
        return
    try:
        db = await get_db()
        if chat_id is None:
            await db.execute(
                "UPDATE talkative_global_settings SET talkative_mode = ?, "
                "updated_at = datetime('now') WHERE id = 1",
                (mode,),
            )
        else:
            # Upsert per-group setting
            await db.execute(
                "INSERT INTO talkative_chat_settings (chat_id, talkative_mode, updated_at) "
                "VALUES (?, ?, datetime('now')) "
                "ON CONFLICT(chat_id) DO UPDATE SET "
                "talkative_mode = excluded.talkative_mode, "
                "updated_at = datetime('now')",
                (chat_id, mode),
            )
        await db.commit()
        logger.info("TALKATIVE_MODE_SET chat=%s mode=%s", chat_id, mode)
    except Exception as exc:  # noqa: BLE001
        logger.warning("TALKATIVE_MODE_SET error: %s", exc)


def _talkative_mode_allows_chat(mode: str) -> bool:
    """Check if the mode allows text chat engagement."""
    return mode in ("chat", "both")


def _talkative_mode_allows_vc(mode: str) -> bool:
    """Check if the mode allows VC audio engagement."""
    return mode in ("vc", "both")


# --- Adaptive Model Routing (#22) ---


def _adaptive_route_model(
    text: str, *, source: str = "chat",
    configured_provider: str = "",
) -> dict[str, str]:
    """#22: route by task complexity.

    #26/#27/#28 fix: respects the configured provider instead of always
    returning "groq".  The admin's configured provider is used as the base.
    AI-H-002: callers only consume ``provider`` — the legacy ``max_chars``
    field was decorative and is removed.

    Returns ``{"provider": provider}`` for the talkative_generate call.
    """
    text_lower = text.lower().strip()
    # Use the admin's configured provider as the base.
    provider = configured_provider or config.talkative_provider or "groq"
    return {"provider": provider}


# --- Dynamic Response Length (#15) ---


def _adaptive_response_length_guidance(
    text: str, source: str = "chat",
) -> int:
    """#15: determine max response length based on intent.

    greeting → short; simple question → concise; technical → detailed;
    VC → generally shorter than text.
    """
    text_lower = text.lower().strip()
    greetings = {"hi", "hello", "hey", "yo", "sup", "gm", "gn", "bye"}
    if text_lower in greetings:
        return 100
    if source == "vc":
        return 300  # VC responses should be short
    if "?" in text and len(text) < 50:
        return 300  # simple question
    tech = ("error", "code", "debug", "python", "api", "config", "install")
    if any(t in text_lower for t in tech):
        return 1500  # detailed
    return 800  # default


# --- Language Mirroring (#13) ---


def _adaptive_detect_language(text: str) -> str:
    """#13: detect the dominant script/language of the text.

    Returns a language hint: en, hi, ur, ar, ru, zh, ja, ko, or 'auto'.
    Uses Unicode block analysis (no external library needed).
    """
    if not text:
        return "auto"
    # Count Unicode blocks
    devanagari = sum(1 for c in text if '\u0900' <= c <= '\u097F')
    arabic = sum(1 for c in text if '\u0600' <= c <= '\u06FF')
    cyrillic = sum(1 for c in text if '\u0400' <= c <= '\u04FF')
    cjk = sum(1 for c in text if '\u4E00' <= c <= '\u9FFF')
    # AI-H-004: Japanese (Hiragana + Katakana) and Korean (Hangul) detection.
    hiragana = sum(1 for c in text if '\u3040' <= c <= '\u309F')
    katakana = sum(1 for c in text if '\u30A0' <= c <= '\u30FF')
    hangul = sum(1 for c in text if '\uAC00' <= c <= '\uD7AF')
    ascii_count = sum(1 for c in text if c.isascii() and c.isalpha())
    total = (devanagari + arabic + cyrillic + cjk + ascii_count
             + hiragana + katakana + hangul)
    if total == 0:
        return "auto"
    # AI-H-004: Japanese kana presence is a strong signal — beats CJK alone
    # (Chinese text never contains hiragana/katakana).
    if hiragana + katakana > 0:
        return "ja"
    # AI-H-004: Korean Hangul syllables — >30% of detected script chars.
    if hangul > 0 and hangul / total > 0.3:
        return "ko"
    # Hinglish detection: if Devanagari present but ASCII also significant
    if devanagari > 0 and ascii_count > devanagari:
        return "hinglish"
    if devanagari / total > 0.3:
        return "hi"
    if arabic / total > 0.3:
        return "ur"  # could be Arabic or Urdu — use 'ur' for broader coverage
    if cyrillic / total > 0.3:
        return "ru"
    if cjk / total > 0.3:
        return "zh"
    return "en"


# Register Talkative hooks used by the VC subsystem (voicechat.py) via the
# talkative_hooks DI bridge. This lets voicechat call _adaptive_* /
# talkative_generate / talkative_get_mode / _talkative_build_system_prompt
# without importing talkative at module level (avoids voicechat -> talkative cycle).
register_talkative_hooks({
    "_adaptive_check_stale": _adaptive_check_stale,
    "_adaptive_claim_response": _adaptive_claim_response,
    "_adaptive_release_response": _adaptive_release_response,
    "_adaptive_detect_language": _adaptive_detect_language,
    "_adaptive_response_length_guidance": _adaptive_response_length_guidance,
    "_adaptive_route_model": _adaptive_route_model,
    "_talkative_mode_allows_vc": _talkative_mode_allows_vc,
    "_adaptive_get_context": _adaptive_get_context,
    "_adaptive_engagement_score": _adaptive_engagement_score,
    "_talkative_build_system_prompt": _talkative_build_system_prompt,
    "talkative_generate": talkative_generate,
    "talkative_get_mode": talkative_get_mode,
})


# --- VC Audio Pipeline (V41 Fix #1/#2/#3/#4/#5 — Real Implementation) ---
#
# V86: vc_talkative_start/stop are wired into VC join/leave paths.
# Complete path:
#   Telegram VC incoming audio capture → bounded audio queue → PCM normalization
#   → channel/sample-width normalization → resampling → VAD → utterance
#   segmentation → STT → existing Talkative AI/Gemini generation → TTS →
#   playback-format conversion → real Telegram VC playback
#
# Every stage has a bounded queue with backpressure, stale-frame dropping,
# overflow metrics, stage timeouts, and cancellation propagation.
#
# Generation IDs / session epochs prevent stale STT/AI/TTS/playback results
# from committing after interruption or session replacement.
#
# Barge-in stops actual playback, cancels stale generation/TTS work, flushes
# stale queued output, and begins the new speaker turn safely.
#
# Echo protection: the userbot's own audio source is filtered before STT.
# While bot playback is active, source identity + playback timing + echo
# guards prevent the feedback loop:
#   bot TTS → incoming capture → STT → AI → new bot TTS

# --- Bounded queue sizes (backpressure at every stage) ---


def _media_detect_intent(text: str) -> str | None:
    """Detect conversational intent/mood from text.

    Returns an intent key (funny, celebration, etc.) or None.
    Uses keyword + pattern matching — no external library needed.
    """
    text_lower = text.lower().strip()
    # Funny: laughter indicators
    if any(p in text_lower for p in ("haha", "lol", "lmao", "rofl", "😂", "🤣",
                                      "joke", "funny", "hilarious")):
        return "funny"
    # Celebration
    if any(p in text_lower for p in ("congrats", "congratulations", "well done",
                                      "celebrate", "party", "🎉", "cheers")):
        return "celebration"
    # Congratulations (subset of celebration but more specific)
    if "congratulations" in text_lower or "proud of you" in text_lower:
        return "congratulations"
    # Surprise
    if any(p in text_lower for p in ("wow", "omg", "no way", "seriously",
                                      "unbelievable", "😱", "😮")):
        return "surprise"
    # Confusion
    if any(p in text_lower for p in ("what?", "huh", "confused", "i don't understand",
                                      "wait what", "🤔", "❓")):
        return "confusion"
    # Sadness
    if any(p in text_lower for p in ("sad", "sorry to hear", "unfortunate",
                                      "depressing", "😢", "😭", "rip")):
        return "sadness"
    # Greeting
    if any(p in text_lower for p in ("hello", "hi ", "hey", "good morning",
                                      "good evening", "welcome", "👋")):
        return "greeting"
    # Goodbye
    if any(p in text_lower for p in ("bye", "goodbye", "see you", "good night",
                                      "gn", "farewell", "👋")):
        return "goodbye"
    # Teasing
    if any(p in text_lower for p in ("just kidding", "gotcha", "wink", "😜",
                                      "teasing", "prank")):
        return "teasing"
    # Agreement
    if any(p in text_lower for p in ("yes", "yeah", "agree", "exactly",
                                      "correct", "right", "👍", "💯")):
        return "agreement"
    # Disagreement
    if any(p in text_lower for p in ("no", "disagree", "wrong", "nope",
                                      "not really", "👎", "facepalm")):
        return "disagreement"
    return None


async def _media_library_get_by_tags(tags: list[str],
                                     *, limit: int = 10) -> list[dict[str, Any]]:
    """Fetch approved media from the curated library matching any of *tags*."""
    if not tags:
        return []
    try:
        db = await get_db()
        # v97 SEC fix: parameterize LIKE patterns to prevent SQL injection.
        # Previously used f"tags LIKE '%{t}%'" which allowed tag values
        # containing ' or % to break out of the string literal.
        # Now uses ? placeholders with f"%{t}%" as parameter values.
        safe_tags = tags[:5]
        conditions = " OR ".join("tags LIKE ?" for _ in safe_tags)
        params = [f"%{t}%" for t in safe_tags] + [limit]
        async with db.execute(
            f"SELECT id, media_type, file_id, tags, description, use_count "
            f"FROM talkative_media_library "
            f"WHERE approved = 1 AND blocked = 0 AND ({conditions}) "
            f"ORDER BY use_count ASC LIMIT ?",
            tuple(params),
        ) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]
    except Exception as exc:  # noqa: BLE001
        logger.debug("MEDIA_LIBRARY_GET error: %s", exc)
        return []


# DEAD CODE — no callers. Wire via admin callback to enable library curation.


async def _media_library_add(*, media_type: str, file_id: str,
                             tags: str, description: str = "") -> dict[str, Any]:
    """Add media to the curated library (admin only)."""
    if media_type not in ("sticker", "gif", "animation"):
        return {"ok": False, "error": "invalid_type"}
    if not file_id:
        return {"ok": False, "error": "no_file_id"}
    try:
        db = await get_db()
        await db.execute(
            "INSERT INTO talkative_media_library "
            "(media_type, file_id, tags, description) VALUES (?, ?, ?, ?)",
            (media_type, file_id, tags, description),
        )
        await db.commit()
        logger.info("MEDIA_LIBRARY_ADD type=%s tags=%s", media_type, tags[:50])
        return {"ok": True, "error": ""}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": str(exc)[:100]}


# DEAD CODE — no callers. Wire via admin callback to enable library curation.


async def _media_library_block(media_id: int) -> dict[str, Any]:
    """Block a media item (admin only)."""
    try:
        db = await get_db()
        await db.execute(
            "UPDATE talkative_media_library SET blocked = 1 WHERE id = ?",
            (media_id,),
        )
        await db.commit()
        return {"ok": True, "error": ""}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": str(exc)[:100]}


# V86 (P6 Task 4): seed the curated library with a small default emoji set so
# the Media Reaction Engine has something to send even before an admin curates
# real stickers/GIFs. Pure emoji reactions need no file_id — the emoji
# character itself is stored in the file_id column.


async def _media_seed_default_library() -> None:
    """Seed talkative_media_library with default emoji reactions (no file_id needed)."""
    try:
        db = await get_db()
        # Check if already seeded.
        async with db.execute("SELECT COUNT(*) FROM talkative_media_library") as cur:
            row = await cur.fetchone()
        if row and row[0] > 0:
            return  # already has entries
        # Insert default reaction mappings (intent → emoji). file_id is empty
        # for pure emoji reactions — the emoji itself is the file_id.
        defaults = [
            ("greeting", "👋", "emoji"),
            ("thanks", "👍", "emoji"),
            ("farewell", "👋", "emoji"),
            ("funny", "😂", "emoji"),
            ("love", "❤️", "emoji"),
            ("agree", "👍", "emoji"),
            ("disagree", "👎", "emoji"),
            ("question", "🤔", "emoji"),
            ("celebration", "🎉", "emoji"),
        ]
        for intent, emoji, mtype in defaults:
            await db.execute(
                "INSERT INTO talkative_media_library (media_type, file_id, tags, description, approved, blocked) "
                "VALUES (?, ?, ?, ?, 1, 0)",
                (mtype, emoji, intent, f"Default {intent} reaction"),
            )
        await db.commit()
        logger.info("MEDIA_LIBRARY_SEEDED count=%d", len(defaults))
    except Exception as exc:  # noqa: BLE001
        logger.warning("MEDIA_LIBRARY_SEED_FAILED exc=%s", exc)


async def _media_get_prefs(chat_id: int) -> dict[str, Any]:
    """Get per-group media preferences (with defaults)."""
    try:
        db = await get_db()
        async with db.execute(
            "SELECT * FROM talkative_media_prefs WHERE chat_id = ?",
            (chat_id,),
        ) as cur:
            row = await cur.fetchone()
        if row:
            return dict(row)
    except Exception:  # noqa: BLE001
        pass
    return {
        "chat_id": chat_id, "media_enabled": 1,
        "sticker_frequency": 0.3, "gif_frequency": 0.2,
        "last_media_at": None, "consecutive_media": 0,
    }


async def _media_record_sent(chat_id: int, media: dict[str, Any]) -> None:
    """Record a media send in history (for duplicate suppression + learning)."""
    try:
        db = await get_db()
        now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        await db.execute(
            "INSERT INTO talkative_media_history "
            "(chat_id, media_id, media_type, file_id, tags) VALUES (?, ?, ?, ?, ?)",
            (chat_id, media.get("id", 0), media.get("media_type", ""),
             media.get("file_id", ""), media.get("tags", "")),
        )
        # Update per-group prefs: consecutive_media + last_media_at.
        await db.execute(
            "INSERT INTO talkative_media_prefs (chat_id, consecutive_media, last_media_at) "
            "VALUES (?, 1, ?) "
            "ON CONFLICT(chat_id) DO UPDATE SET "
            "  consecutive_media = talkative_media_prefs.consecutive_media + 1, "
            "  last_media_at = ?",
            (chat_id, now_iso, now_iso),
        )
        # Update library use_count.
        if media.get("id"):
            await db.execute(
                "UPDATE talkative_media_library SET use_count = use_count + 1 WHERE id = ?",
                (media["id"],),
            )
        await db.commit()
    except Exception as exc:  # noqa: BLE001
        logger.debug("MEDIA_RECORD_SENT error: %s", exc)


async def _media_reset_consecutive(chat_id: int) -> None:
    """Reset consecutive media counter when a non-media turn happens."""
    try:
        db = await get_db()
        await db.execute(
            "UPDATE talkative_media_prefs SET consecutive_media = 0 WHERE chat_id = ?",
            (chat_id,),
        )
        await db.commit()
    except Exception:  # noqa: BLE001
        pass


async def _media_is_duplicate(chat_id: int, file_id: str,
                              window_seconds: int) -> bool:
    """Check if this media was recently sent to this group (duplicate suppression)."""
    try:
        db = await get_db()
        cutoff = (datetime.now(timezone.utc)
                  - timedelta(seconds=window_seconds)).strftime("%Y-%m-%d %H:%M:%S")
        async with db.execute(
            "SELECT 1 FROM talkative_media_history "
            "WHERE chat_id = ? AND file_id = ? AND sent_at > ? LIMIT 1",
            (chat_id, file_id, cutoff),
        ) as cur:
            return await cur.fetchone() is not None
    except Exception:  # noqa: BLE001
        return False


async def _media_check_cooldown(chat_id: int, cooldown_seconds: int) -> bool:
    """Check if media cooldown has elapsed. Returns True if allowed."""
    try:
        db = await get_db()
        async with db.execute(
            "SELECT last_media_at FROM talkative_media_prefs WHERE chat_id = ?",
            (chat_id,),
        ) as cur:
            row = await cur.fetchone()
        if not row or not row["last_media_at"]:
            return True  # no previous media
        last = datetime.strptime(row["last_media_at"], "%Y-%m-%d %H:%M:%S").replace(
            tzinfo=timezone.utc)
        elapsed = (datetime.now(timezone.utc) - last).total_seconds()
        return elapsed >= cooldown_seconds
    except Exception:  # noqa: BLE001
        return True


async def _media_select_response_type(
    ctx: "AdaptiveGroupContext",
    *, trigger: str, intent: str | None, text: str,
    is_private: bool, settings: dict[str, Any],
) -> str:
    """Decide the response type: text / sticker / gif / emoji / vc / silence.

    Uses engagement score + intent + per-group media preferences + anti-spam
    budget + probability to choose the best response type.

    Returns one of: "text", "sticker", "gif", "emoji", "vc", "silence".
    """
    # Check if media is globally enabled.
    if not config.talkative_media_enabled:
        return "text"
    # Check per-group media prefs.
    prefs = await _media_get_prefs(ctx.chat_id)
    if not int(prefs.get("media_enabled", 1)):
        return "text"
    # Anti-spam: max consecutive media.
    if int(prefs.get("consecutive_media", 0)) >= config.talkative_media_max_consecutive:
        return "text"
    # Cooldown check.
    if not await _media_check_cooldown(ctx.chat_id, config.talkative_media_cooldown):
        _talkative_engine_metrics["media_cooldown_hits"] = _talkative_engine_metrics.get("media_cooldown_hits", 0) + 1
        return "text"
    # If no intent detected, prefer text (no random media).
    if intent is None:
        return "text"
    # Stronger media probability for direct mentions/replies.
    base_prob = config.talkative_media_probability
    if trigger in ("reply", "mention", "name", "wake_word"):
        base_prob *= 2.0  # double probability for direct engagement
    # Adjust by per-group sticker/GIF frequency.
    sticker_freq = float(prefs.get("sticker_frequency", 0.3))
    gif_freq = float(prefs.get("gif_frequency", 0.2))
    # Decide: text vs media.
    import random as _random
    roll = _random.random()
    if roll > base_prob:
        return "text"
    # Choose media type: sticker vs gif.
    if _random.random() < sticker_freq / (sticker_freq + gif_freq + 0.001):
        return "sticker"
    return "gif"


async def _media_send(bot, chat_id: int, media: dict[str, Any],
                      *, reply_to_message_id: int = 0) -> bool:
    """Send a media item to the chat. Returns True on success.

    V86 (P6 Task 5): added ``reply_to_message_id`` + ``media_type == "emoji"``
    branch so pure emoji reactions (file_id = emoji character) can be sent via
    ``bot.set_message_reaction`` — no real Telegram file_id required.
    """
    try:
        media_type = media.get("media_type", "sticker")
        file_id = media.get("file_id", "")
        if not file_id:
            return False
        if media_type == "sticker":
            await bot.send_sticker(chat_id=chat_id, sticker=file_id)
        elif media_type in ("gif", "animation"):
            await bot.send_animation(chat_id=chat_id, animation=file_id)
        elif media_type == "emoji":
            # Pure emoji reaction — needs the message to react to.
            if not reply_to_message_id:
                return False
            await bot.set_message_reaction(
                chat_id=chat_id, message_id=reply_to_message_id,
                reaction=[{"type": "emoji", "emoji": file_id}],
            )
        else:
            return False
        _talkative_engine_metrics["media_sent"] = _talkative_engine_metrics.get("media_sent", 0) + 1
        if media_type == "sticker":
            _talkative_engine_metrics["stickers_sent"] = _talkative_engine_metrics.get("stickers_sent", 0) + 1
        elif media_type == "emoji":
            _talkative_engine_metrics["reactions_sent"] = _talkative_engine_metrics.get("reactions_sent", 0) + 1
        else:
            _talkative_engine_metrics["gifs_sent"] = _talkative_engine_metrics.get("gifs_sent", 0) + 1
        return True
    except Exception as exc:  # noqa: BLE001
        logger.debug("MEDIA_SEND error: %s", exc)
        return False


async def _media_try_reaction(
    bot, chat_id: int, message_id: int, intent: str | None,
) -> bool:
    """Try to send an emoji reaction (if supported by the Bot API).

    Returns True if a reaction was sent.
    """
    if not intent:
        return False
    # Map intents to emoji reactions.
    intent_emoji: dict[str, str] = {
        "funny": "😂", "celebration": "🎉", "congratulations": "👍",
        "surprise": "😮", "confusion": "🤔", "sadness": "😢",
        "greeting": "👋", "goodbye": "👋", "teasing": "😜",
        "agreement": "👍", "disagreement": "👎",
    }
    emoji = intent_emoji.get(intent)
    if not emoji:
        return False
    try:
        await bot.set_message_reaction(chat_id=chat_id, message_id=message_id,
                                       reaction=[{"type": "emoji", "emoji": emoji}])
        _talkative_engine_metrics["reactions_sent"] = _talkative_engine_metrics.get("reactions_sent", 0) + 1
        return True
    except Exception:  # noqa: BLE001
        return False


# ---------------------------------------------------------------------------
# V86 (P6): Telethon → PTB adapter for the Media Reaction Engine.
#
# The Media Reaction Engine (`talkative_media_process`) was originally written
# against the python-telegram-bot (PTB) API — it expects PTB-style `update`
# and `context` objects (`update.effective_chat.id`, `update.effective_chat.type`,
# `update.message.message_id`, `context.bot.send_sticker` / `.send_animation` /
# `.set_message_reaction`).
#
# The live Talkative message handler (`_talkative_userbot_handle_message`) is a
# TELETHON handler — it receives a Telethon `events.NewMessage.Event` and uses
# `event.reply(...)` / `client.send_file(...)` for sends. To wire the engine
# into the live path without rewriting it, we expose a thin duck-typed adapter
# that masquerades as BOTH the PTB `update` AND the PTB `context` (since the
# only thing `talkative_media_process` reads off `context` is `context.bot`).
# ---------------------------------------------------------------------------


class _PTBChatAdapter:
    """Minimal stand-in for `telegram.Chat` used by the media engine."""

    __slots__ = ("id", "type")

    def __init__(self, *, chat_id: int, is_private: bool) -> None:
        self.id = chat_id
        self.type = "private" if is_private else "group"


class _PTBMessageAdapter:
    """Minimal stand-in for `telegram.Message` used by the media engine."""

    __slots__ = ("message_id",)

    def __init__(self, *, message_id: int) -> None:
        self.message_id = message_id


class _PTBBotAdapter:
    """PTB-like Bot facade that delegates sends to a Telethon client.

    Real sticker/GIF file_ids are transport-specific: a file_id obtained via
    the Bot API cannot be re-sent via Telethon and vice-versa. For the
    curated default library (pure emoji reactions) this is irrelevant — only
    ``set_message_reaction`` is exercised. For future sticker/GIF curation
    the file_ids MUST be obtained via Telethon itself.
    """

    __slots__ = ("_client",)

    def __init__(self, telethon_client) -> None:
        self._client = telethon_client

    async def send_sticker(self, *, chat_id: int, sticker: str) -> None:
        if self._client is None:
            raise RuntimeError("Telethon client unavailable")
        await self._client.send_file(chat_id, sticker, force_document=False)

    async def send_animation(self, *, chat_id: int, animation: str) -> None:
        if self._client is None:
            raise RuntimeError("Telethon client unavailable")
        await self._client.send_file(chat_id, animation, force_document=False)

    async def set_message_reaction(self, *, chat_id: int, message_id: int,
                                   reaction: list) -> None:
        if self._client is None:
            raise RuntimeError("Telethon client unavailable")
        # PTB reaction format: [{"type": "emoji", "emoji": "<emoji>"}]
        emoji: str | None = None
        if isinstance(reaction, list):
            for r in reaction:
                if isinstance(r, dict) and r.get("type") == "emoji":
                    emoji = r.get("emoji")
                    break
        if not emoji:
            return
        # Telethon >= 1.24 exposes client.send_reaction(entity, msg_id, emoji).
        send_reaction = getattr(self._client, "send_reaction", None)
        if send_reaction is not None:
            await send_reaction(chat_id, message_id, emoji)
            return
        # Fallback for older Telethon versions: raw API.
        from telethon.tl.functions.messages import SendReactionRequest
        from telethon.tl.types import ReactionEmoji
        peer = await self._client.get_input_entity(chat_id)
        await self._client(SendReactionRequest(
            peer=peer, msg_id=message_id,
            reaction=[ReactionEmoji(emoticon=emoji)],
        ))


class _TelethonMediaAdapter:
    """Combined PTB-like `update` + `context` adapter for talkative_media_process.

    Pass a single instance as BOTH the ``update`` and ``context`` arguments:
        adapter = _TelethonMediaAdapter(event, client, is_private=is_private)
        await talkative_media_process(adapter, adapter, trigger=..., ...)
    """

    __slots__ = ("_event", "_client", "effective_chat", "message", "bot")

    def __init__(self, telethon_event, telethon_client, *, is_private: bool) -> None:
        self._event = telethon_event
        self._client = telethon_client
        chat_id = int(getattr(telethon_event, "chat_id", 0) or 0)
        msg_id = int(getattr(telethon_event, "id", 0) or 0)
        self.effective_chat = _PTBChatAdapter(chat_id=chat_id, is_private=is_private)
        self.message = _PTBMessageAdapter(message_id=msg_id)
        self.bot = _PTBBotAdapter(telethon_client)


async def talkative_media_process(
    update: "Update", context: "ContextTypes.DEFAULT_TYPE",
    *, trigger: str, text: str, a_ctx: "AdaptiveGroupContext",
    settings: dict[str, Any],
) -> str | None:
    """Process a message for potential media reaction.

    This is called AFTER the adaptive engagement decision but BEFORE text
    generation.  If it returns a media file_id, the caller sends the media
    instead of (or in addition to) text.  If it returns None, the caller
    proceeds with text generation.

    Returns:
        - "media_sent": media was selected and sent (skip text generation).
        - "reaction_sent": emoji reaction was sent (still do text generation).
        - None: no media action (proceed with text generation).
    """
    chat_id = update.effective_chat.id if update.effective_chat else 0
    if chat_id == 0:
        return None
    # Detect intent/mood.
    intent = _media_detect_intent(text)
    if intent is None:
        return None
    # Select response type.
    is_private = (getattr(update.effective_chat, "type", None) == "private")
    response_type = await _media_select_response_type(
        a_ctx, trigger=trigger, intent=intent, text=text,
        is_private=is_private, settings=settings,
    )
    if response_type == "text" or response_type == "silence":
        return None
    if response_type == "sticker" or response_type == "gif":
        # Fetch matching media from curated library.
        tags = _INTENT_TAG_MAP.get(intent, [])
        media_list = await _media_library_get_by_tags(tags, limit=5)
        if not media_list:
            return None  # no matching media in library
        # Pick a random media item (least-used first for diversity).
        import random as _random
        media = _random.choice(media_list[:3])
        # Duplicate suppression: check if this media was recently sent.
        if await _media_is_duplicate(chat_id, media["file_id"],
                                      config.talkative_media_dedup_window):
            _talkative_engine_metrics["media_duplicate_blocked"] = (
                _talkative_engine_metrics.get("media_duplicate_blocked", 0) + 1)
            logger.debug("MEDIA_DUPLICATE_BLOCKED chat=%s file_id=%s",
                         chat_id, media["file_id"][:20])
            return None
        # Send the media.
        # V86 (P6 Task 5): pass the incoming message_id so the emoji branch
        # inside _media_send can call set_message_reaction on the right msg.
        msg_id_for_reaction = (update.message.message_id
                               if getattr(update, "message", None) else 0)
        sent = await _media_send(context.bot, chat_id, media,
                                 reply_to_message_id=msg_id_for_reaction)
        if sent:
            await _media_record_sent(chat_id, media)
            logger.info("MEDIA_SENT chat=%s type=%s intent=%s tags=%s",
                        chat_id, media["media_type"], intent,
                        media.get("tags", "")[:30])
            return "media_sent"
        return None
    # Emoji reaction (lighter touch — doesn't replace text).
    if response_type == "emoji":
        msg_id = update.message.message_id if update.message else 0
        if msg_id:
            sent = await _media_try_reaction(context.bot, chat_id, msg_id, intent)
            if sent:
                return "reaction_sent"
    return None


# --- Talkative Engine Metrics (#28) ---

# V44 Fix #4: DM Pipeline event-correlated diagnostic.
# Stores bounded per-peer stage state for the last N private DM events.
# NEVER stores message content — only stage outcomes + metadata.


_dm_pipeline_diag: dict[int, dict[str, Any]] = {}


_DM_DIAG_MAX_PEERS = 50  # bounded — LRU eviction


def _dm_diag_record(peer_id: int, stage: str, value: Any) -> None:
    """Record a stage outcome for a peer's DM pipeline event.

    Stages: private_event_seen, peer_id, effective_chat_mode, workflow_block,
    duplicate_claim, cooldown, provider, generation_result, stale_check,
    send_result.

    NEVER stores message content.
    """
    if peer_id not in _dm_pipeline_diag:
        # LRU eviction.
        if len(_dm_pipeline_diag) >= _DM_DIAG_MAX_PEERS:
            oldest = min(_dm_pipeline_diag, key=lambda k: _dm_pipeline_diag[k].get("_ts", 0))
            _dm_pipeline_diag.pop(oldest, None)
        _dm_pipeline_diag[peer_id] = {"peer_id": peer_id, "_ts": time.monotonic()}
    _dm_pipeline_diag[peer_id][stage] = value
    _dm_pipeline_diag[peer_id]["_ts"] = time.monotonic()


_group_pipeline_diag: dict[int, dict[str, Any]] = {}


_GROUP_DIAG_MAX = 50  # bounded — LRU eviction


def _group_diag_record(chat_id: int, stage: str, value: Any) -> None:
    """Record a stage outcome for a group pipeline event.

    Stages: event_seen, chat_id, effective_chat_mode, trigger, cooldown, rpm,
    engagement, spam_budget, consecutive_bot, duplicate_claim, provider,
    generation_result, stale_check, send_result, terminal_reason.

    NEVER stores message content.
    """
    if chat_id not in _group_pipeline_diag:
        if len(_group_pipeline_diag) >= _GROUP_DIAG_MAX:
            oldest = min(_group_pipeline_diag, key=lambda k: _group_pipeline_diag[k].get("_ts", 0))
            _group_pipeline_diag.pop(oldest, None)
        _group_pipeline_diag[chat_id] = {"chat_id": chat_id, "_ts": time.monotonic()}
    _group_pipeline_diag[chat_id][stage] = value
    _group_pipeline_diag[chat_id]["_ts"] = time.monotonic()


# v97.20: rate-limit for TALKATIVE_PROVIDER_ALL_COOLDOWN log (once per 60s).
_last_all_cooldown_log_at: float = 0.0

_talkative_engine_metrics: dict[str, int] = {
    "replies_generated": 0,
    "replies_sent": 0,
    "replies_suppressed": 0,
    "duplicate_blocked": 0,
    "stale_cancelled": 0,
    "interruptions": 0,
    "memory_hits": 0,
    "summaries_created": 0,
    "stt_failures": 0,
    "tts_failures": 0,
    "llm_failures": 0,
    "vc_replies_sent": 0,
    # Media reaction engine metrics
    "stickers_sent": 0,
    "gifs_sent": 0,
    "reactions_sent": 0,
    "media_sent": 0,
    "media_suppressed": 0,
    "media_duplicate_blocked": 0,
    "media_cooldown_hits": 0,
}


def _talkative_engine_metrics_snapshot() -> dict[str, Any]:
    """#28: snapshot of engine metrics for dashboard."""
    active_chat_sessions = sum(1 for ctx in _adaptive_contexts.values()
                               if ctx.recent_turns)
    active_vc_listeners = sum(1 for s in _vc_talkative_sessions.values()
                              if s.get("active"))
    active_tts = sum(1 for s in _vc_talkative_sessions.values()
                     if s.get("speaking"))
    return {
        **_talkative_engine_metrics,
        "active_chat_sessions": active_chat_sessions,
        "active_vc_listeners": active_vc_listeners,
        "active_tts_playback": active_tts,
        "tracked_groups": len(_adaptive_contexts),
    }


async def _bot_api_talkative_fallback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """V86.3: Bot API conversational fallback when Telethon userbot is not registered.

    V86.5 FIX: This fallback does NOT check talkative_effective_enabled() —
    that function gates the FULL Telethon Talkative handler (which requires
    MTProto, wake words, media reactions, etc).  The Bot API fallback is a
    MINIMAL conversational path that should work whenever the bot is running
    and at least one AI provider key is configured, regardless of whether
    the full Talkative subsystem is enabled.

    The only gate is: at least one provider must be ready (key configured +
    not in cooldown).  If no provider is ready, the fallback silently returns
    (no point generating a request that will fail).
    """
    msg = update.message
    if msg is None:
        return
    chat = update.effective_chat
    user = update.effective_user
    if chat is None or user is None:
        return

    text = (msg.text or "").strip()
    if not text:
        return

    # v99.07 FIX-6 (RUNTIME-CRITICAL: the 2026-09-19 log shows
    # TALKATIVE_ALL_PROVIDERS_FAILED + BOT_API_TALKATIVE_NO_REPLY firing at
    # 06:21:38, 06:22:17, 06:22:28 — all while TALKATIVE_EFFECTIVE
    # enabled=False source=dashboard_db. The V86.5 decision to run this
    # minimal conversational path regardless of the Talkative switch
    # produced provider calls + log noise for a subsystem the admin
    # DISABLED). The admin's OFF switch is now authoritative here too:
    # effective-enabled=False silences the Bot API fallback. (Fail-open
    # only when the state cannot be read — matches the Telethon handler's
    # per-message gate semantics.)
    try:
        from .db_layer import talkative_effective_enabled
        _v9907_eff, _v9907_src = await talkative_effective_enabled()
    except Exception:  # noqa: BLE001
        _v9907_eff, _v9907_src = None, "error"
    if _v9907_eff is False:
        logger.debug(
            "BOT_API_TALKATIVE_SKIP reason=talkative_disabled source=%s "
            "(v99.07 FIX-6: the admin's OFF switch gates this fallback too)",
            _v9907_src,
        )
        return
    # V86.5 (narrowed by v99.07 FIX-6 above): when enabled, check that at
    # least one provider is available.
    # V86.6 FIX: talkative_effective_provider() only checks the PRIMARY
    # provider. If the primary is in cooldown but a fallback provider is
    # configured, talkative_generate() will try the fallback. So we should
    # only skip if NO provider key is configured at all (not just if the
    # primary is in cooldown).
    try:
        eff_provider, _, _, ready, reason = await talkative_effective_provider()
        if not ready:
            # V86.6: Check if ANY fallback provider has a key configured.
            # talkative_generate will try them in order.
            any_key = (
                bool(getattr(config, "groq_api_key", ""))
                or bool(getattr(config, "gemini_api_key", ""))
                or bool(getattr(config, "openrouter_api_key", "") and getattr(config, "openrouter_model", ""))
            )
            if not any_key:
                logger.debug("BOT_API_TALKATIVE_SKIP no_provider_keys reason=%s", reason)
                return
            # A fallback provider has a key — let talkative_generate try them.
            logger.debug("BOT_API_TALKATIVE_PRIMARY_NOT_READY reason=%s — trying fallback chain", reason)
    except Exception:
        return  # don't crash on DB errors

    # 2. Engagement check (simplified).
    # In private chat: always respond.
    # In group chat: only respond if the bot is mentioned or replied to.
    is_private = chat.type == "private"
    if not is_private:
        # Check if the bot was mentioned or replied to.
        is_reply_to_bot = (
            msg.reply_to_message is not None
            and msg.reply_to_message.from_user is not None
            and msg.reply_to_message.from_user.id == context.bot.id
        )
        bot_username = (await context.bot.get_me()).username or ""
        is_mentioned = f"@{bot_username.lower()}" in text.lower()
        if not is_reply_to_bot and not is_mentioned:
            return  # not engaged — stay silent in groups

    # 3. Check cooldown.
    try:
        if not _talkative_check_cooldown(chat.id, user.id):
            return  # in cooldown
    except Exception:
        pass  # don't block on cooldown errors

    # 4. Check global RPM.
    try:
        if not _talkative_check_global_rpm(config.talkative_global_rpm):
            return  # rate limited
    except Exception:
        pass

    # 5. Build system prompt + generate reply.
    try:
        settings = await talkative_effective_settings(chat.id)
        system_prompt = _talkative_build_system_prompt(settings, "bot_api_fallback", "")
        # Add language detection.
        detected_lang = _adaptive_detect_language(text)
        if detected_lang and detected_lang != "auto":
            system_prompt += f"\n\nReply in: {detected_lang}"

        messages = [{"role": "user", "content": text}]

        # Add recent memory if available.
        try:
            memory = await talkative_get_memory(chat.id, user.id,
                                                 limit=int(settings.get("memory_turns", 5)))
            if memory:
                messages = memory + messages
        except Exception:
            pass  # memory is best-effort

        result = await talkative_generate(
            messages, system_prompt,
            {"provider": "auto",
             "max_reply_chars": int(settings.get("max_reply_chars", config.talkative_max_reply_chars)),
             "request_timeout": int(settings.get("request_timeout", config.talkative_request_timeout))},
        )

        if result.success and result.text:
            # Anti-repetition: check if this is a duplicate of recent replies.
            # (Simplified — no AdaptiveGroupContext in Bot API fallback.)
            reply_text = result.text.strip()

            # Send the reply.
            await safe_reply_text(msg, reply_text)

            # Record in memory.
            try:
                await talkative_add_memory(chat.id, user.id, "user", text)
                await talkative_add_memory(chat.id, user.id, "assistant", reply_text)
                await talkative_trim_memory(chat.id, user.id,
                                            int(settings.get("memory_turns", 5)) * 2)
            except Exception:
                pass  # memory is best-effort

            # Set cooldown.
            try:
                _talkative_set_cooldown(chat.id, user.id)
                _talkative_record_rpm()
            except Exception:
                pass

            # Record stat.
            try:
                await talkative_add_stat(chat.id, user.id, "bot_api_fallback",
                                          result.provider, True)
            except Exception:
                pass

            logger.info("BOT_API_TALKATIVE_REPLY chat=%s user=%s provider=%s len=%d",
                        chat.id, user.id, result.provider, len(reply_text))
        else:
            # Generation failed — send fallback text if available.
            if result.text:
                await safe_reply_text(msg, result.text)
            logger.info("BOT_API_TALKATIVE_NO_REPLY chat=%s user=%s error=%s",
                        chat.id, user.id, (result.error or "")[:100])
    except Exception as exc:  # noqa: BLE001
        logger.warning("BOT_API_TALKATIVE_GENERATE_ERROR exc=%s: %s",
                       type(exc).__name__, str(exc)[:200])


# --- Main handler -----------------------------------------------------------


async def talkative_handle_message(update: Update,
                                   context: ContextTypes.DEFAULT_TYPE) -> None:
    """Talkative Mode V2 — Bot API handler.

    V86.3 FIX: When the Telethon userbot handler is NOT registered (MTProto
    not started / not connected), this handler ACTS as the conversational
    fallback — it runs the same engagement scoring, trigger detection, and
    talkative_generate pipeline, but sends replies via the Bot API instead
    of via Telethon.

    When the Telethon userbot IS registered, this handler is a no-op
    (the userbot handles all conversation; Bot API is control-plane only).
    """
    # Defensive: skip if no message or no effective user.
    if update.message is None or update.effective_user is None:
        return
    if not update.message.text:
        return
    if update.message.text.startswith("/"):
        return

    # Consume the one-shot suppressor set by route_message for config inputs.
    if context.user_data and context.user_data.pop("_talkative_just_handled", None):
        return

    # V86.3: If the Telethon userbot handler IS registered, Bot API is
    # control-plane only — do NOT generate conversational replies here.
    if _talkative_userbot_handler_registered:
        return

    # V86.3: Telethon userbot is NOT registered — Bot API fallback path.
    # Run the conversational pipeline here so the bot can still chat when
    # MTProto is not available.
    try:
        await _bot_api_talkative_fallback(update, context)
    except Exception as exc:  # noqa: BLE001
        logger.warning("BOT_API_TALKATIVE_FALLBACK_ERROR exc=%s: %s",
                       type(exc).__name__, str(exc)[:200])


async def _talkative_handle_message_wrapper(update: Update,
                                            context: ContextTypes.DEFAULT_TYPE) -> None:
    """Wrapper that ensures the adaptive response slot is always released."""
    try:
        await talkative_handle_message(update, context)
    finally:
        # #19: always release the claimed response slot.
        chat_id = update.effective_chat.id if update.effective_chat else 0
        if chat_id:
            ctx = _adaptive_contexts.get(chat_id)
            if ctx:
                event_id = f"chat:{chat_id}:{update.update_id}"
                await _adaptive_release_response(ctx, event_id)


# --- Background cleanup -----------------------------------------------------


async def _talkative_cleanup_loop() -> None:
    """Background loop: expire sessions + trim old memory every 300s.

    Idempotent — safe to run multiple times concurrently (it isn't, but
    the registration guard prevents that).
    """
    logger.info("Talkative cleanup loop started (interval=300s).")
    while True:
        try:
            await asyncio.sleep(300)
            expired = await talkative_cleanup_expired_sessions()
            deleted = await talkative_cleanup_old_memory(max_age_days=7)
            # Clear stale cooldowns (older than 1 hour).
            now = time.monotonic()
            stale_keys = [k for k, ts in _talkative_cooldowns.items()
                          if (now - ts) > 3600]
            for k in stale_keys:
                _talkative_cooldowns.pop(k, None)
            # Trim RPM window defensively.
            cutoff = now - 60.0
            # V85.5 FIX (PERF-G-001): deque.popleft() is O(1).
            while _talkative_rpm_window and _talkative_rpm_window[0] < cutoff:
                _talkative_rpm_window.popleft()
            # V85.3 FIX BUG 6.2/6.3/6.4: prune unbounded VC state dicts.
            # _vc_target_cooldowns / _vc_reconcile_cooldowns grow per failed
            # group; _vc_known_call_ids grows per discovered group.  Prune
            # entries older than 4× the target cooldown so the dicts stay
            # bounded over a long-running bot.
            try:
                prune_after = now - (_VC_TARGET_COOLDOWN_SECONDS * 4)
                stale_cd = [g for g, ts in _vc_target_cooldowns.items()
                            if ts < prune_after]
                for g in stale_cd:
                    _vc_target_cooldowns.pop(g, None)
                stale_rc = [g for g, ts in _vc_reconcile_cooldowns.items()
                            if ts < prune_after]
                for g in stale_rc:
                    _vc_reconcile_cooldowns.pop(g, None)
                # PERF-F-001: prune per-target asyncio.Lock entries that are
                # no longer associated with any active in-flight join,
                # cooldown, or known call.  Without this, _vc_target_locks
                # grows by one entry per distinct group_id ever probed and
                # is never reclaimed (a long-running bot would accumulate
                # thousands of unused Lock objects).
                _active_gids = (set(_vc_in_flight_joins)
                                | set(_vc_target_cooldowns.keys())
                                | set(_vc_known_call_ids.keys()))
                _stale_locks = [g for g, lk in _vc_target_locks.items()
                                if g not in _active_gids and not lk.locked()]
                for g in _stale_locks:
                    _vc_target_locks.pop(g, None)
                # PERF-F-002: prune zero-value _vc_known_call_ids entries.
                # These are written by `_vc_known_call_ids.setdefault(gid, 0)`
                # as placeholders when classification has no vc_info; they
                # never become non-zero and consume memory forever.  Drop
                # them so the next cycle re-probes the group naturally.
                # (0 is falsy — same as a missing key for every consumer.)
                # V95 FIX: also prune non-zero entries for groups that are
                # no longer in the participation registry (the VC has ended
                # or the bot left). Without this, every group ever discovered
                # accumulates forever.
                _stale_kc = [g for g, cid in _vc_known_call_ids.items()
                             if cid == 0]
                for g in _stale_kc:
                    _vc_known_call_ids.pop(g, None)
                # V95: prune non-zero entries for groups no longer joined.
                try:
                    _joined_gids = {p.chat_id for p in _vc_participations.values()
                                    if p.state == "joined"}
                    _stale_nonzero = [g for g in _vc_known_call_ids
                                      if g not in _joined_gids
                                      and g not in _vc_in_flight_joins]
                    for g in _stale_nonzero:
                        _vc_known_call_ids.pop(g, None)
                except Exception:  # noqa: BLE001
                    pass
            except Exception:  # noqa: BLE001
                pass
            # V85.3 FIX BUG 6.5: prune stale SEND_RESTRICTION_CACHE entries.
            try:
                from .bootstrap import _SEND_RESTRICTION_CACHE, _SEND_RESTRICTION_TTL  # lazy: breaks talkative -> bootstrap cycle
                stale_sr = [c for c, (ts, _cls) in _SEND_RESTRICTION_CACHE.items()
                            if (time.time() - ts) > _SEND_RESTRICTION_TTL * 4]
                for c in stale_sr:
                    _SEND_RESTRICTION_CACHE.pop(c, None)
            except Exception:  # noqa: BLE001
                pass
            # V85.3 FIX BUG 8 (chat history): bound _talkative_chat_history to
            # the 500 most recently active chats (LRU by last append).  Each
            # chat's list is already capped at _TALKATIVE_HISTORY_MAX entries.
            # V85.5 FIX (PERF-G-002): the OrderedDict + move_to_end / popitem
            # path in _talkative_record_chat_message now does this inline, so
            # this defensive prune is a no-op in steady state. Kept as a
            # belt-and-braces fallback for chats that get traffic via other
            # paths (e.g. _talkative_get_group_context callers).
            try:
                while len(_talkative_chat_history) > _TALKATIVE_HISTORY_MAX_CHATS:
                    _talkative_chat_history.popitem(last=False)
            except Exception:  # noqa: BLE001
                pass
            # V85.3 FIX BUG DB-9..15: periodic DB retention sweep.  Several
            # tables are written on every interaction but never DELETEd,
            # causing unbounded growth over the bot's lifetime.  Prune them
            # here (best-effort, each in its own try/except so one failure
            # doesn't block the rest).
            try:
                _db = await get_db()
                retention_stmts = [
                    # talkative_stats: one row per AI invocation.
                    "DELETE FROM talkative_stats WHERE created_at < datetime('now','-30 days')",
                    # talkative_sessions: inactive sessions older than 7 days.
                    "DELETE FROM talkative_sessions WHERE active = 0 AND expires_at < datetime('now','-7 days')",
                    # talkative_media_history: duplicate-suppression rows.
                    "DELETE FROM talkative_media_history WHERE sent_at < datetime('now','-7 days')",
                    # vc_visits: one row per VC join/leave.
                    "DELETE FROM vc_visits WHERE created_at < datetime('now','-90 days')",
                    # vc_discovery_runs: one row per cycle; keep last 1000.
                    "DELETE FROM vc_discovery_runs WHERE id NOT IN "
                    "(SELECT id FROM vc_discovery_runs ORDER BY started_at DESC LIMIT 1000)",
                    # vc_discovery_results: stale discovered groups.
                    "DELETE FROM vc_discovery_results WHERE last_checked_at < datetime('now','-14 days')",
                    # inspected_chats: old inspection records.
                    # v99.11 P1 FIX(a): the v99.10 statement used the
                    # NONEXISTENT column ``checked_at`` (schema has
                    # ``created_at``) — the DELETE failed every sweep,
                    # silently swallowed by the inner except → the table
                    # grew unbounded.
                    "DELETE FROM inspected_chats WHERE created_at < datetime('now','-30 days')",
                ]
                total_deleted = 0
                _v9911_stmt_errors = 0
                for stmt in retention_stmts:
                    try:
                        cur = await _db.execute(stmt)
                        total_deleted += cur.rowcount or 0
                    except Exception as _stmt_exc:  # noqa: BLE001
                        _v9911_stmt_errors += 1
                        logger.debug(
                            "V85.3 retention stmt failed: %s: %s",
                            type(_stmt_exc).__name__, str(_stmt_exc)[:120],
                        )
                # v99.11 P1 FIX(b): ALWAYS commit/rollback after the DML
                # batch.  The v99.10 code committed only when rows were
                # deleted — with zero deletions the connection kept an
                # OPEN WRITE TRANSACTION (holding the WAL write lock,
                # blocking checkpoints) until some other coroutine's
                # commit closed it at an arbitrary point.
                if _v9911_stmt_errors < len(retention_stmts):
                    await _db.commit()
                else:
                    await _db.rollback()
                if total_deleted:
                    logger.info("V85.3 DB retention sweep deleted %d stale rows", total_deleted)
            except Exception:  # noqa: BLE001
                pass
            if expired or deleted or stale_keys:
                logger.info(
                    "Talkative cleanup: expired_sessions=%d, deleted_memory=%d, "
                    "stale_cooldowns=%d",
                    expired, deleted, len(stale_keys),
                )
        except asyncio.CancelledError:
            logger.info("Talkative cleanup loop cancelled.")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.exception("Talkative cleanup loop error: %s", exc)


def _talkative_start_cleanup_task() -> None:
    """Start the background cleanup task (idempotent)."""
    global _talkative_cleanup_task
    if _talkative_cleanup_task is not None and not _talkative_cleanup_task.done():
        return
    _talkative_cleanup_task = asyncio.create_task(_talkative_cleanup_loop())


async def _talkative_stop_cleanup_task() -> None:
    """Cancel the background cleanup task and close the httpx client."""
    global _talkative_cleanup_task
    if _talkative_cleanup_task is not None and not _talkative_cleanup_task.done():
        _talkative_cleanup_task.cancel()
        try:
            await asyncio.wait_for(_talkative_cleanup_task, timeout=5)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            pass
    _talkative_cleanup_task = None
    await _talkative_close_http_client()


# --- Bot identity fetch -----------------------------------------------------


async def _talkative_fetch_bot_identity(app: Application) -> None:
    """Fetch and cache the bot's id / username / display name.

    Called from ``_post_init`` after ``register_bot``. Caches into the
    module-level globals so ``talkative_detect_trigger`` can use them.
    """
    global _bot_id, _bot_username, _bot_display_name
    try:
        me = await asyncio.wait_for(app.bot.get_me(), timeout=15)
        _bot_id = me.id
        _bot_username = me.username
        _bot_display_name = (me.first_name or me.username or "").strip()
        logger.info("Talkative: bot identity cached (id=%s, username=%s, name=%s).",
                    _bot_id, _bot_username, _bot_display_name)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Talkative: could not fetch bot identity: %s", exc)


# ===========================================================================
# Handlers — download
# ===========================================================================


def _talk_is_admin(user_id: int) -> bool:
    return user_id in config.admin_ids


def _talkative_status_text(global_s: dict, chat_s: dict,
                           chat_id: int) -> str:
    """Render the Talkative status block."""
    g_enabled = "✅ on" if global_s.get("enabled") else "⚪️ off"
    provider = global_s.get("provider", "groq")
    personality = (global_s.get("personality") or "").strip() or "—"
    language = global_s.get("language_mode", "auto")
    timeout = global_s.get("session_timeout_seconds", 300)
    memory = global_s.get("memory_turns", 10)
    cooldown = global_s.get("cooldown_seconds", 3)
    gctx = "✅" if global_s.get("group_context_enabled") else "⚪️"
    gctx_msgs = global_s.get("group_context_messages", 8)
    typing = "✅" if global_s.get("typing_enabled") else "⚪️"
    private = "✅" if global_s.get("private_auto_reply") else "⚪️"
    # Per-chat overrides.
    c_enabled = chat_s.get("enabled")
    c_label = "inherit (global)" if c_enabled is None else (
        "✅ on" if c_enabled else "❌ off"
    )
    return (
        f"*💬 Talkative Mode*\n\n"
        f"*Global settings*\n"
        f"Enabled: {g_enabled}\n"
        f"Provider: `{md_escape(provider)}`\n"
        f"Personality: {md_escape(personality[:80])}\n"
        f"Language: `{md_escape(language)}`\n"
        f"Session timeout: `{timeout}s`\n"
        f"Memory turns: `{memory}`\n"
        f"Cooldown: `{cooldown}s`\n"
        f"Group context: {gctx} (`{gctx_msgs}` msgs)\n"
        f"Typing indicator: {typing}\n"
        f"Private auto-reply: {private}\n\n"
        f"*This chat* (`{chat_id}`)\n"
        f"Enabled: {c_label}\n\n"
        f"_Tap a button below to change settings._"
    )


async def talk__show_menu(update: Update,
                          context: ContextTypes.DEFAULT_TYPE) -> None:
    """Open the Talkative admin menu (admin-only).

    P0 FIX — pending-input lifecycle: opening the menu clears any active
    Talkative configuration input marker (wake_add / personality_select).
    The menu is not an input screen, so leaving a marker stale here would
    cause the next plain-text message to be incorrectly routed (or, with
    the priority-guard fix, silently swallowed).  This covers the Back
    button, the talk:menu callback, and the talk:back callback (which
    also calls this function).

    P0 FIX #3 — update-safe: supports BOTH slash-command and inline-callback
    invocations (update.callback_query may be None when invoked via /talkative).
    """
    q = update.callback_query
    if not _talk_is_admin(update.effective_user.id):
        if q is not None:
            await q.answer("Not authorised.", show_alert=True)
        else:
            await safe_send_message(
                context.bot, update.effective_chat.id, "🚫 Not authorised.",
            )
        return
    if q is not None:
        await q.answer()
    _talk_clear_pending_input(context)
    chat_id = update.effective_chat.id if update.effective_chat else 0
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    text = _talkative_status_text(global_s, chat_s, chat_id)
    if q is not None:
        await safe_edit_message_text(
            context.bot, update.effective_chat.id, q.message.message_id,
            text, reply_markup=talkative_menu(global_s, chat_s),
        )
    else:
        await safe_send_message(
            context.bot, update.effective_chat.id, text,
            reply_markup=talkative_menu(global_s, chat_s),
        )


async def talk__enable_global(update: Update,
                              context: ContextTypes.DEFAULT_TYPE) -> None:
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    await update.callback_query.answer("Talkative enabled globally.")
    await talkative_update_global_settings(enabled=True)
    # V41 Fix #6: apply the runtime change immediately — register the
    # Telethon handler so messages are processed without requiring a restart.
    try:
        active = await talkative_apply_effective_runtime()
        logger.info("TALKATIVE_DASHBOARD_ENABLE applied (active=%s).", active)
    except Exception as exc:  # noqa: BLE001
        logger.warning("TALKATIVE_DASHBOARD_ENABLE apply failed: %s", exc)
    chat_id = update.effective_chat.id if update.effective_chat else 0
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_menu(global_s, chat_s),
    )


async def talk__disable_global(update: Update,
                               context: ContextTypes.DEFAULT_TYPE) -> None:
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    await update.callback_query.answer("Talkative disabled globally.")
    await talkative_update_global_settings(enabled=False)
    # V41 Fix #6: apply the runtime change immediately. The handler stays
    # registered (Telethon can't cleanly remove a single decorated handler),
    # but the per-message gate now checks effective-enabled=False and rejects
    # all messages. This is logged for transparency.
    try:
        active = await talkative_apply_effective_runtime()
        logger.info("TALKATIVE_DASHBOARD_DISABLE applied (active=%s).", active)
    except Exception as exc:  # noqa: BLE001
        logger.warning("TALKATIVE_DASHBOARD_DISABLE apply failed: %s", exc)
    chat_id = update.effective_chat.id if update.effective_chat else 0
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_menu(global_s, chat_s),
    )


async def talk__enable_chat(update: Update,
                            context: ContextTypes.DEFAULT_TYPE) -> None:
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    chat_id = update.effective_chat.id if update.effective_chat else 0
    await update.callback_query.answer("Talkative enabled in this chat.")
    await talkative_set_chat_setting(chat_id, enabled=True)
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_menu(global_s, chat_s),
    )


async def talk__disable_chat(update: Update,
                             context: ContextTypes.DEFAULT_TYPE) -> None:
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    chat_id = update.effective_chat.id if update.effective_chat else 0
    await update.callback_query.answer("Talkative disabled in this chat.")
    await talkative_set_chat_setting(chat_id, enabled=False)
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_menu(global_s, chat_s),
    )


async def talk__cycle_provider(update: Update,
                               context: ContextTypes.DEFAULT_TYPE) -> None:
    """Cycle the global provider through groq → openrouter → gemini → groq."""
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    global_s = await talkative_get_global_settings()
    current = (global_s.get("provider") or "groq").lower()
    cycle = ["groq", "openrouter", "gemini"]
    try:
        idx = cycle.index(current)
    except ValueError:
        idx = -1
    nxt = cycle[(idx + 1) % len(cycle)]
    await talkative_update_global_settings(provider=nxt)
    await update.callback_query.answer(f"Provider → {nxt}")
    chat_id = update.effective_chat.id if update.effective_chat else 0
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_menu(global_s, chat_s),
    )


async def talk__cycle_memory(update: Update,
                             context: ContextTypes.DEFAULT_TYPE) -> None:
    """Cycle memory turns: 5 → 10 → 20 → 0 (disabled) → 5."""
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    global_s = await talkative_get_global_settings()
    current = int(global_s.get("memory_turns", 10))
    cycle = [5, 10, 20, 0]
    try:
        idx = cycle.index(current)
    except ValueError:
        idx = -1
    nxt = cycle[(idx + 1) % len(cycle)]
    await talkative_update_global_settings(memory_turns=nxt)
    await update.callback_query.answer(f"Memory turns → {nxt}")
    chat_id = update.effective_chat.id if update.effective_chat else 0
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_menu(global_s, chat_s),
    )


async def talk__cycle_timeout(update: Update,
                              context: ContextTypes.DEFAULT_TYPE) -> None:
    """Cycle session timeout: 60 → 300 → 600 → 1800 → 60."""
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    global_s = await talkative_get_global_settings()
    current = int(global_s.get("session_timeout_seconds", 300))
    cycle = [60, 300, 600, 1800]
    try:
        idx = cycle.index(current)
    except ValueError:
        idx = -1
    nxt = cycle[(idx + 1) % len(cycle)]
    await talkative_update_global_settings(session_timeout_seconds=nxt)
    await update.callback_query.answer(f"Session timeout → {nxt}s")
    chat_id = update.effective_chat.id if update.effective_chat else 0
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_menu(global_s, chat_s),
    )


async def talk__cycle_cooldown(update: Update,
                               context: ContextTypes.DEFAULT_TYPE) -> None:
    """Cycle cooldown: 0 → 3 → 10 → 30 → 0."""
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    global_s = await talkative_get_global_settings()
    current = int(global_s.get("cooldown_seconds", 3))
    cycle = [0, 3, 10, 30]
    try:
        idx = cycle.index(current)
    except ValueError:
        idx = -1
    nxt = cycle[(idx + 1) % len(cycle)]
    await talkative_update_global_settings(cooldown_seconds=nxt)
    await update.callback_query.answer(f"Cooldown → {nxt}s")
    chat_id = update.effective_chat.id if update.effective_chat else 0
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_menu(global_s, chat_s),
    )


async def talk__toggle_group_ctx(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE) -> None:
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    global_s = await talkative_get_global_settings()
    current = bool(global_s.get("group_context_enabled", True))
    await talkative_update_global_settings(group_context_enabled=not current)
    await update.callback_query.answer(
        f"Group context → {'on' if not current else 'off'}")
    chat_id = update.effective_chat.id if update.effective_chat else 0
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_menu(global_s, chat_s),
    )


async def talk__cycle_group_ctx_msgs(update: Update,
                                     context: ContextTypes.DEFAULT_TYPE) -> None:
    """V48 Fix: cycle group context message depth: 4 → 8 → 12 → 16 → 4."""
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    global_s = await talkative_get_global_settings()
    current = int(global_s.get("group_context_messages", 8))
    cycle = [4, 8, 12, 16]
    try:
        idx = cycle.index(current)
    except ValueError:
        idx = 0
    new_val = cycle[(idx + 1) % len(cycle)]
    await talkative_update_global_settings(group_context_messages=new_val)
    await update.callback_query.answer(f"Group context depth → {new_val} msgs")
    chat_id = update.effective_chat.id if update.effective_chat else 0
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_memory_controls_menu(),
    )


async def talk__cycle_language(update: Update,
                               context: ContextTypes.DEFAULT_TYPE) -> None:
    """Cycle language_mode: auto → English → Spanish → Hindi → auto."""
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    global_s = await talkative_get_global_settings()
    current = (global_s.get("language_mode") or "auto").lower()
    cycle = ["auto", "English", "Spanish", "Hindi"]
    try:
        idx = cycle.index(current)
    except ValueError:
        idx = -1
    nxt = cycle[(idx + 1) % len(cycle)]
    await talkative_update_global_settings(language_mode=nxt)
    await update.callback_query.answer(f"Language → {nxt}")
    chat_id = update.effective_chat.id if update.effective_chat else 0
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_menu(global_s, chat_s),
    )


async def talk__toggle_typing(update: Update,
                              context: ContextTypes.DEFAULT_TYPE) -> None:
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    global_s = await talkative_get_global_settings()
    current = bool(global_s.get("typing_enabled", True))
    await talkative_update_global_settings(typing_enabled=not current)
    await update.callback_query.answer(
        f"Typing → {'on' if not current else 'off'}")
    chat_id = update.effective_chat.id if update.effective_chat else 0
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_menu(global_s, chat_s),
    )


async def talk__toggle_private_auto(update: Update,
                                    context: ContextTypes.DEFAULT_TYPE) -> None:
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    global_s = await talkative_get_global_settings()
    current = bool(global_s.get("private_auto_reply", True))
    await talkative_update_global_settings(private_auto_reply=not current)
    await update.callback_query.answer(
        f"Private auto-reply → {'on' if not current else 'off'}")
    chat_id = update.effective_chat.id if update.effective_chat else 0
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_menu(global_s, chat_s),
    )


async def talk__show_wake_words(update: Update,
                                context: ContextTypes.DEFAULT_TYPE) -> None:
    """List configured wake words for this chat (and globals)."""
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    await update.callback_query.answer()
    chat_id = update.effective_chat.id if update.effective_chat else 0
    rows: list[list[InlineKeyboardButton]] = []
    text_lines = ["*🔔 Wake words*\n"]
    # Globals.
    g_words = await talkative_get_wake_words(None)
    text_lines.append(f"*Global* ({len(g_words)})")
    if not g_words:
        text_lines.append("  _none_")
    for w in g_words:
        wid = w.get("id")
        text_lines.append(f"  • `{md_escape(w.get('wake_word', ''))}`")
        rows.append([InlineKeyboardButton(
            f"🗑 {w.get('wake_word', '')}", callback_data=f"talk:wakedel:{wid}",
        )])
    # Chat-specific.
    if chat_id:
        c_words = await talkative_get_wake_words(chat_id)
        text_lines.append(f"\n*This chat* ({len(c_words)})")
        if not c_words:
            text_lines.append("  _none_")
        for w in c_words:
            wid = w.get("id")
            text_lines.append(f"  • `{md_escape(w.get('wake_word', ''))}`")
            rows.append([InlineKeyboardButton(
                f"🗑 {w.get('wake_word', '')}", callback_data=f"talk:wakedel:{wid}",
            )])
    text_lines.append(
        "\n_Send a message starting with `wake:` to add a wake word "
        "(e.g. `wake: hey bot`). Use the buttons below to delete._"
    )
    rows.append([InlineKeyboardButton("🔙 Back", callback_data="talk:menu")])
    # Set the pending-input marker so route_message routes the next
    # "wake: ..." text to the wake-word handler.  Uses the helper for an
    # atomic replace of any previous marker (e.g. if the admin navigated
    # here from the personality screen).
    _talk_set_pending_input(context, "wake_add")
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        "\n".join(text_lines),
        reply_markup=InlineKeyboardMarkup(rows),
    )


async def talk__delete_wake_word(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE,
                                 word_id: int) -> None:
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    ok = await talkative_remove_wake_word(word_id)
    await update.callback_query.answer(
        "Deleted." if ok else "Not found.", show_alert=not ok)
    # Re-render the wake-words view.
    await talk__show_wake_words(update, context)


async def talk__handle_wake_word_input(update: Update,
                                       context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle ``wake: <word>`` input to add a wake word.

    P0 FIX — pending-input lifecycle: the marker is cleared FIRST (via the
    helper) on EVERY path — valid input, invalid input, empty word — so
    no stale ``wake_add`` marker can survive this handler.  This is a
    one-shot input mode: after one attempt (success or failure), the
    admin must re-open the wake-words screen to enter another word.
    """
    if not _talk_is_admin(update.effective_user.id):
        await safe_reply_text(update.message, "🚫 Not authorised.")
        return
    text = (update.message.text or "").strip()
    # Clear the pending input marker on every path (one-shot mode).
    _talk_clear_pending_input(context)
    # Strip the leading "wake:" prefix (case-insensitive).
    m = re.match(r"^wake:\s*(.+)$", text, re.IGNORECASE)
    if not m:
        await safe_reply_text(update.message,
                              "⚠️ Send `wake: <word>` to add a wake word.")
        return
    word = m.group(1).strip().lower()
    if not word:
        await safe_reply_text(update.message, "⚠️ Empty wake word.")
        return
    chat_id = update.effective_chat.id if update.effective_chat else 0
    # If private chat, add as global; else add as chat-specific.
    target_chat = None if (chat_id == 0 or
                           getattr(update.effective_chat, "type", None) == "private") \
                  else chat_id
    await talkative_add_wake_word(target_chat, word)
    await safe_reply_text(
        update.message,
        f"✅ Wake word `{md_escape(word)}` added "
        f"({'global' if target_chat is None else 'this chat'}).",
    )


async def talk__clear_memory(update: Update,
                             context: ContextTypes.DEFAULT_TYPE) -> None:
    """Clear Talkative memory for the current chat."""
    if not _talk_is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    chat_id = update.effective_chat.id if update.effective_chat else 0
    deleted = await talkative_clear_memory(chat_id)
    await update.callback_query.answer(f"Cleared {deleted} entries.")
    chat_id = update.effective_chat.id if update.effective_chat else 0
    global_s = await talkative_get_global_settings()
    chat_s = await talkative_get_chat_settings(chat_id)
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        f"🧹 *Cleared {deleted} memory entries for this chat.*\n\n"
        + _talkative_status_text(global_s, chat_s, chat_id),
        reply_markup=talkative_menu(global_s, chat_s),
    )


async def talk__handle_personality_input(update: Update,
                                         context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle ``personality: <text>`` input to set the global personality.

    P0 FIX — pending-input lifecycle: the marker is cleared FIRST (via the
    helper) on EVERY path — valid input, invalid input, clear — so no
    stale ``personality_select`` marker can survive this handler.  This
    is a one-shot input mode.
    """
    if not _talk_is_admin(update.effective_user.id):
        await safe_reply_text(update.message, "🚫 Not authorised.")
        return
    text = (update.message.text or "").strip()
    # Clear the pending input marker on every path (one-shot mode).
    _talk_clear_pending_input(context)
    m = re.match(r"^personality:\s*(.*)$", text, re.IGNORECASE | re.DOTALL)
    if not m:
        await safe_reply_text(
            update.message,
            "⚠️ Send `personality: <text>` to set, or `personality: clear`.",
        )
        return
    new_p = m.group(1).strip()
    if new_p.lower() in ("clear", "none", "off", "reset"):
        new_p = ""
    await talkative_update_global_settings(personality=new_p)
    label = new_p if new_p else "(cleared)"
    await safe_reply_text(
        update.message,
        f"✅ Global personality set to:\n{md_escape(label[:400])}",
    )


# ===========================================================================
# Handler namespace aliases (so menu.py code works unchanged)
# ===========================================================================


talkative_handler = SimpleNamespace(
    show_menu=talk__show_menu,
    enable_global=talk__enable_global,
    disable_global=talk__disable_global,
    enable_chat=talk__enable_chat,
    disable_chat=talk__disable_chat,
    cycle_provider=talk__cycle_provider,
    cycle_memory=talk__cycle_memory,
    cycle_timeout=talk__cycle_timeout,
    cycle_cooldown=talk__cycle_cooldown,
    toggle_group_ctx=talk__toggle_group_ctx,
    cycle_group_ctx_msgs=talk__cycle_group_ctx_msgs,
    cycle_language=talk__cycle_language,
    toggle_typing=talk__toggle_typing,
    toggle_private_auto=talk__toggle_private_auto,
    show_wake_words=talk__show_wake_words,
    delete_wake_word=talk__delete_wake_word,
    handle_wake_word_input=talk__handle_wake_word_input,
    clear_memory=talk__clear_memory,
    handle_personality_input=talk__handle_personality_input,
    handle_message=talkative_handle_message,
)


# ===========================================================================
# Handlers — menu (central router + message router)
# ===========================================================================
