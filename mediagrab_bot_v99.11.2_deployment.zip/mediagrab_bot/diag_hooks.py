"""Diagnostic hooks — DI bridge for v85_diag (V85 diagnostic logger).

The VC subsystem (and other subsystems) call ``v85_diag(event, **fields)``
to emit structured diagnostic lines. The real implementation lives in
``bootstrap.py`` (it appends to an internal buffer for /v85status).

Importing bootstrap from voicechat/talkative/etc. would create a cycle
(those modules are imported by _bot_core which is imported by bootstrap).
This module breaks the cycle with a registration pattern.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Optional

logger = logging.getLogger("mediagrab")

_v85_diag_fn: Optional[Callable[..., None]] = None


def register_diag_hooks(v85_diag: Callable[..., None]) -> None:
    """Register the real v85_diag implementation (called by bootstrap at import time)."""
    global _v85_diag_fn
    _v85_diag_fn = v85_diag


def v85_diag(event: str, **fields: Any) -> None:
    """Emit a structured V85 diagnostic line (routes to the registered impl)."""
    if _v85_diag_fn is not None:
        _v85_diag_fn(event, **fields)
    else:  # pragma: no cover — only before bootstrap registers
        logger.debug("V85_DIAG (unregistered) event=%s fields=%s", event, list(fields))


__all__ = ["register_diag_hooks", "v85_diag"]
