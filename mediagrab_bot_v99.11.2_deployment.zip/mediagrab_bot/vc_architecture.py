"""v98.09 ARCHITECTURE HARDENING CORE — bounded execution, lifecycle,
backpressure, single-flight, canary classification, config validation.

ENGINEERING PRINCIPLE (v98.09 §48): the v98.08 query-selection infinite
loop (voicechat.py::_auto_discovery_run_one_cycle, pids 10077/25848,
2026-09-01 — see FIX-CCC in voicechat.py) was not an isolated bug; it
was evidence that the architecture allowed an event-loop operation to
lack a STRUCTURAL execution bound. This module is the systematized
answer: one place where every budget, phase, gate, registry and
classifier lives, with termination proven by construction.

DESIGN INVARIANTS (module-wide, AST-auditable):
  * No function in this module contains a ``while`` loop. Every loop is
    a ``for`` over a finite sequence with monotonic progress — the
    class of defect that froze v98.08 cannot reappear here.
  * Every registry is cardinality-bounded with deterministic eviction.
  * Every gate defers (never drops, never deletes, never excludes).
  * Every marker emitted here is NEW (v98.09); all v98.08 markers are
    preserved unchanged in their original modules (see the observability
    contract in PATCH_MANIFEST_v98.09.txt §7).
  * Stdlib-only imports at module scope (asyncio/logging/dataclasses/
    os/time/typing) — no Telethon/PTB: importable by tests and by the
    static audit without the bot's optional dependencies.

This module is an INTERNAL implementation detail of mediagrab_bot. It
intentionally does NOT change any public option, default, env var, log
marker, or CLI surface of v98.08/v98.09 — it adds structure underneath
the existing product (compatibility adapters live at the voicechat /
bootstrap integration points).
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("mediagrab_bot.vc_arch")


# ===========================================================================
# §5/§14/§29/§30 — GLOBAL BOUNDEDNESS MODEL (budget registry)
# ===========================================================================
# Every budget: explicit default (derived from v98.08's existing
# behavior — NO behavior change unless the operator overrides), env-var
# override, documented minimum/maximum, and a rationale. No production
# behavior depends on an undocumented magic number.

@dataclass(frozen=True)
class BudgetSpec:
    name: str
    default: int
    env: str
    minimum: int
    maximum: int
    rationale: str


VC_ARCH_BUDGETS: Dict[str, BudgetSpec] = {
    # Concurrency budgets (§14 backpressure). Defaults == the v98.08
    # effective concurrency so throughput is unchanged.
    "max_discovery_in_flight": BudgetSpec(
        "max_discovery_in_flight", 4, "VC_ARCH_MAX_DISCOVERY_IN_FLIGHT", 1, 64,
        "Upper bound on concurrent discovery query pipelines per cycle; "
        "default 4 == vc_discovery_metadata_concurrency (v98.08 behavior)."),
    "max_entity_resolution_in_flight": BudgetSpec(
        "max_entity_resolution_in_flight", 8, "VC_ARCH_MAX_ENTITY_RESOLUTION_IN_FLIGHT", 1, 64,
        "Upper bound on concurrent entity resolutions; default 8 == the "
        "v98.08 _vc_get_telegram_rpc_semaphore(8) budget."),
    "max_classification_in_flight": BudgetSpec(
        "max_classification_in_flight", 4, "VC_ARCH_MAX_CLASSIFICATION_IN_FLIGHT", 1, 64,
        "Upper bound on concurrent VC classify probes; default 4 == the "
        "v98.08 discovery semaphore (metadata concurrency)."),
    "max_join_in_flight": BudgetSpec(
        "max_join_in_flight", 3, "VC_ARCH_MAX_JOIN_IN_FLIGHT", 1, 32,
        "Upper bound on concurrent VC joins; default 3 == "
        "vc_multi_join_concurrency (v98.08)."),
    "max_reconcile_in_flight": BudgetSpec(
        "max_reconcile_in_flight", 4, "VC_ARCH_MAX_RECONCILE_IN_FLIGHT", 1, 64,
        "Upper bound on concurrent reconcile checks; default 4 == the "
        "v98.08 reconcile batch width."),
    # Queue / memory budgets (§30).
    "max_dispatch_queue_depth": BudgetSpec(
        "max_dispatch_queue_depth", 200, "VC_ARCH_MAX_DISPATCH_QUEUE_DEPTH", 1, 10000,
        "Deferred-work queue depth bound before callers are deferred with "
        "an observable reason (defer, never drop)."),
    "negcache_max_entries": BudgetSpec(
        "negcache_max_entries", 10000, "VC_ARCH_NEGCACHE_MAX_ENTRIES", 100, 1000000,
        "Maximum cardinality of the FIX-ZZ negative-result cache. "
        "Safeguard only (v98.08 effective bound was the 25/60s budget); "
        "deterministic eviction, fail-safe direction (see negcache_sweep)."),
    "task_population_bound": BudgetSpec(
        "task_population_bound", 5000, "VC_ARCH_TASK_POPULATION_BOUND", 100, 100000,
        "Observability bound for the owned-task population marker; "
        "exceeding it logs VC_ARCH_TASK_POPULATION (never kills work)."),
    # Retry budget (§21) — preserves the v98.08 FIX-ZZ sliding window.
    "retry_budget_per_window": BudgetSpec(
        "retry_budget_per_window", 25, "VC_ARCH_RETRY_BUDGET_PER_WINDOW", 1, 1000,
        "Max re-resolve attempts per retry window; default 25 == the "
        "v98.08 _VC_RERESOLVE_BUDGET_MAX (preserved exactly)."),
    "retry_window_seconds": BudgetSpec(
        "retry_window_seconds", 60, "VC_ARCH_RETRY_WINDOW_SECONDS", 1, 3600,
        "Sliding retry-budget window; default 60s == v98.08."),
}

# Gates that exist as runtime objects (created lazily per event loop).
_GATES: Dict[str, "BoundedGate"] = {}


def arch_budget(name: str, cfg: Optional[Any] = None) -> int:
    """Resolve a budget: config attribute (if the bot config exposes one)
    → env var → documented default. Always clamped to [min, max]."""
    spec = VC_ARCH_BUDGETS.get(name)
    if spec is None:
        raise KeyError(f"unknown budget: {name}")
    value: Optional[int] = None
    if cfg is not None:
        attr = f"vc_arch_{name}"
        if hasattr(cfg, attr):
            try:
                value = int(getattr(cfg, attr))
            except (TypeError, ValueError):
                value = None
    if value is None:
        raw = os.environ.get(spec.env, "")
        if raw.strip():
            try:
                value = int(raw.strip())
            except (TypeError, ValueError):
                value = None
    if value is None:
        value = spec.default
    if value < spec.minimum:
        value = spec.minimum
    if value > spec.maximum:
        value = spec.maximum
    return int(value)


# ===========================================================================
# §6 — DISCOVERY BOUNDED STATE MACHINE
# ===========================================================================
# The discovery cycle is modeled as an explicitly-bounded phase machine.
# Every phase has: entry marker, exit, deadline consultation, cancellation
# behavior, failure behavior. The machine records a bounded transition
# history (cardinality-bounded, deterministic) and a live snapshot for
# the canary dump (§25).

DISCOVERY_PHASES: Tuple[str, ...] = (
    "idle",
    "start",            # cycle entry: state reset, counter unification
    "candidate_build",  # merged pool load (autonomous+builtin+env+dash)
    "query_plan",       # bounded selection (FIX-CCC helper) → plan
    "query_execution",  # per-query search loop (wall-cap checked here)
    "classification",   # entity probes (gate + single-flight)
    "join_resolve",     # capacity-aware auto-join attempts
    "reconcile",        # found/missing reconciliation (deduped)
    "settle",           # rotation settle window / deferred settle
    "complete",         # terminal success
    "failed",           # terminal failure (bounded, observable)
    "cancelled",        # terminal cancellation (stop flag)
)
_PHASE_TERMINAL: Tuple[str, ...] = ("complete", "failed", "cancelled", "idle")


class DiscoveryPhaseMachine:
    """Bounded phase machine for ONE discovery cycle.

    Termination: ``enter`` is called a finite number of times per cycle
    (<= len(DISCOVERY_PHASES) forward transitions by convention), the
    history deque is bounded (max_history), and no method loops.
    """

    MAX_HISTORY = 64  # cardinality bound; old transitions summarized

    def __init__(self, cycle_id: int = 0, deadline: Optional[float] = None,
                 cap_seconds: float = 90.0) -> None:
        self.cycle_id = int(cycle_id)
        self.deadline = deadline
        self.cap_seconds = float(cap_seconds)
        self.phase: str = "idle"
        self.t0: float = time.monotonic()
        self.t_enter: float = self.t0
        self.history: List[Tuple[str, float, str]] = []
        self.queries_total: int = 0
        self.query_index: int = 0
        self.current_query: str = ""
        self.failures: List[str] = []  # bounded by record_failure (33 max)
        self.failures_dropped: int = 0  # overflow beyond the 32-entry list

    # -- transitions -------------------------------------------------------
    def enter(self, phase: str, *, detail: str = "") -> None:
        """Record a phase transition. Invalid/backward transitions are
        accepted but logged (the machine is an observer + budget guard,
        not a scheduler: it never blocks discovery)."""
        now = time.monotonic()
        elapsed = now - self.t_enter
        if phase not in DISCOVERY_PHASES:
            phase = "failed"
            detail = f"unknown_phase:{phase} {detail}"[:120]
        logger.info(
            "VC_DISCOVERY_PHASE cycle=%d phase=%s prev=%s held=%.1fs %s",
            self.cycle_id, phase, self.phase, elapsed, detail,
        )
        self.phase = phase
        self.t_enter = now
        self.history.append((phase, now, detail[:120]))
        if len(self.history) > self.MAX_HISTORY:
            # Deterministic bound: keep the most recent transitions.
            drop = len(self.history) - self.MAX_HISTORY
            del self.history[:drop]
            self.failures.append(f"history_truncated:{drop}")

    def record_query_progress(self, index: int, query: str) -> None:
        """Live query cursor — read by the canary context snapshot (§25)."""
        self.query_index = int(index)
        self.current_query = str(query)[:120]

    def record_failure(self, reason: str) -> None:
        """Bounded failure log (<= 32 entries + one overflow marker;
        further overflow is COUNTED, never stored — the list cannot grow
        past 33 no matter how many failures a cycle records)."""
        if len(self.failures) < 32:
            self.failures.append(str(reason)[:120])
        else:
            self.failures_dropped += 1
            if "overflow" not in self.failures:
                self.failures.append("overflow")

    def remaining(self, *, now: Optional[float] = None) -> float:
        """Seconds left on the cycle deadline (negative = over budget)."""
        if self.deadline is None:
            return self.cap_seconds
        _now = time.monotonic() if now is None else now
        return self.deadline - _now

    def over_budget(self, *, now: Optional[float] = None) -> bool:
        return self.remaining(now=now) < 0.0

    def snapshot(self) -> Dict[str, Any]:
        """Live state for the canary dump (§25) and tests (§36)."""
        return {
            "cycle_id": self.cycle_id,
            "phase": self.phase,
            "phase_elapsed": round(time.monotonic() - self.t_enter, 1),
            "cycle_elapsed": round(time.monotonic() - self.t0, 1),
            "cap_seconds": self.cap_seconds,
            "over_budget": self.over_budget(),
            "queries_total": self.queries_total,
            "query_index": self.query_index,
            "current_query": self.current_query,
            "failures": list(self.failures[-8:]),
            "transitions": len(self.history),
        }

    def finish(self, *, cancelled: bool = False, reason: str = "") -> str:
        """Terminal transition — exactly once per cycle (idempotent)."""
        if self.phase in ("complete", "failed", "cancelled"):
            return self.phase
        if cancelled:
            self.enter("cancelled", detail=reason or "stop_flag")
        elif self.failures and not reason:
            self.enter("complete", detail="with_recorded_failures")
        else:
            self.enter("complete", detail=reason or "ok")
        return self.phase


# Module-level live machine (ONE cycle at a time — matches the
# _auto_discovery_lock mutual exclusion in voicechat.py).
_ACTIVE_MACHINE: Optional[DiscoveryPhaseMachine] = None


def phase_cycle_start(cycle_id: int, deadline: Optional[float],
                      cap_seconds: float = 90.0) -> DiscoveryPhaseMachine:
    """Enter the START phase for a new cycle (creates the live machine)."""
    global _ACTIVE_MACHINE
    _ACTIVE_MACHINE = DiscoveryPhaseMachine(
        cycle_id=cycle_id, deadline=deadline, cap_seconds=cap_seconds)
    _ACTIVE_MACHINE.enter("start", detail="cycle_entry")
    return _ACTIVE_MACHINE


def phase_enter(phase: str, *, detail: str = "") -> None:
    """Record a phase transition on the live machine (no-op if absent)."""
    if _ACTIVE_MACHINE is not None:
        _ACTIVE_MACHINE.enter(phase, detail=detail)


def phase_record_query(index: int, query: str) -> None:
    if _ACTIVE_MACHINE is not None:
        _ACTIVE_MACHINE.record_query_progress(index, query)


def phase_record_failure(reason: str) -> None:
    if _ACTIVE_MACHINE is not None:
        _ACTIVE_MACHINE.record_failure(reason)


def phase_finish(*, cancelled: bool = False, reason: str = "") -> None:
    if _ACTIVE_MACHINE is not None:
        _ACTIVE_MACHINE.finish(cancelled=cancelled, reason=reason)


def phase_snapshot() -> Dict[str, Any]:
    """Canary-facing live snapshot (§25: 'current discovery state,
    current query index' inside the dump)."""
    if _ACTIVE_MACHINE is None:
        return {"phase": "none", "active": False}
    snap = _ACTIVE_MACHINE.snapshot()
    snap["active"] = True
    return snap


# ===========================================================================
# §7 — DISCOVERY QUERY PLANNER (internal abstraction, compat adapter)
# ===========================================================================
# The planner RECORDS and VALIDATES the plan produced by the existing
# FIX-CCC bounded selector (voicechat.py::_vc_discovery_select_queries_
# bounded). The selector stays the authority (test contract: the cycle
# calls it at exactly one site) — the planner is the structural
# representation + invariant guard around it.

@dataclass
class DiscoveryQueryPlan:
    """§7 conceptual DiscoveryQueryPlan (internal, not public API)."""
    cycle_id: int
    scope: str
    account: str
    deadline: Optional[float]
    exploit: List[Dict[str, Any]] = field(default_factory=list)
    explore: List[Dict[str, Any]] = field(default_factory=list)
    selected: List[Dict[str, Any]] = field(default_factory=list)
    omitted_due_to_budget: List[Dict[str, Any]] = field(default_factory=list)
    budget_class: str = "item_bound"   # §5: query construction → ITEM bound
    invariant_ok: bool = True
    violation: str = ""

    def validate(self, max_q: int) -> bool:
        """Invariants: selected <= max_q; selected ⊆ exploit ∪ explore;
        every selected item appears at most once; plan is finite."""
        ok = True
        why: List[str] = []
        if len(self.selected) > max(0, int(max_q)):
            ok = False
            why.append(f"selected {len(self.selected)} > max_q {max_q}")
        ids = [id(q) for q in self.selected]
        if len(ids) != len(set(ids)):
            ok = False
            why.append("duplicate item in selected")
        pool = self.exploit + self.explore
        pool_ids = {id(q) for q in pool}
        for q in self.selected:
            if id(q) not in pool_ids:
                ok = False
                why.append("selected item not from candidate pool")
                break
        self.invariant_ok = ok
        self.violation = "; ".join(why)[:200]
        return ok


def record_query_plan(merged: List[Dict[str, Any]], max_q: int,
                      selected: List[Dict[str, Any]], *,
                      scope: str = "_global", account: str = "_global",
                      cycle_id: int = 0,
                      deadline: Optional[float] = None,
                      quiet: bool = False) -> DiscoveryQueryPlan:
    """Build + validate the DiscoveryQueryPlan for this cycle.

    Called immediately after the FIX-CCC selection in
    _auto_discovery_run_one_cycle (the compatibility adapter). Emits
    VC_DISCOVERY_QUERY_PLAN with the plan's budget facts, including
    omitted_due_to_budget (§31: every deferred/omitted item has an
    OBSERVABLE reason — never a silent drop).
    """
    plan = DiscoveryQueryPlan(
        cycle_id=int(cycle_id), scope=str(scope)[:80], account=str(account)[:80],
        deadline=deadline,
        exploit=list(merged[:int(len(merged) * 0.8)]) if len(merged) > 4 else list(merged),
        explore=list(merged[int(len(merged) * 0.8):]) if len(merged) > 4 else [],
        selected=list(selected),
    )
    # Omitted-by-budget: pool items not selected (bounded sample for logs).
    sel_ids = {id(q) for q in plan.selected}
    plan.omitted_due_to_budget = [q for q in merged if id(q) not in sel_ids][:5]
    ok = plan.validate(max_q)
    if not quiet:
        logger.info(
            "VC_DISCOVERY_QUERY_PLAN cycle=%d scope=%s account=%s "
            "exploit=%d explore=%d selected=%d max_q=%d omitted=%d "
            "budget_class=%s invariant_ok=%s%s",
            plan.cycle_id, plan.scope, plan.account,
            len(plan.exploit), len(plan.explore), len(plan.selected),
            int(max_q), len(merged) - len(plan.selected), plan.budget_class,
            ok, (f" violation={plan.violation}" if not ok else ""),
        )
    if not ok:
        phase_record_failure(f"plan_violation:{plan.violation}")
    return plan


# ===========================================================================
# §16 — SINGLE-FLIGHT PROTECTION (coalescing)
# ===========================================================================

class SingleFlight:
    """Coalesces concurrent identical operations: the first caller runs
    the factory; concurrent callers with the SAME key await the leader's
    result. Different keys never coalesce (account/scope isolation §11).

    Boundedness: the registry holds at most ``max_keys`` in-flight
    entries (deterministic reject — never unbounded growth), entries are
    removed on completion, and no method loops.
    """

    def __init__(self, name: str, max_keys: int = 1024) -> None:
        self.name = str(name)
        self.max_keys = int(max_keys)
        self._inflight: Dict[Tuple[Any, ...], "asyncio.Future[Any]"] = {}
        self.coalesced = 0
        self.rejected = 0

    async def run(self, key: Tuple[Any, ...],
                  factory: Callable[[], Awaitable[Any]]) -> Any:
        loop = asyncio.get_running_loop()
        ent = self._inflight.get(key)
        if ent is not None:
            self.coalesced += 1
            logger.debug(
                "VC_ARCH_SINGLE_FLIGHT_COALESCED op=%s key=%s waiters_reuse=1",
                self.name, str(key)[:160])
            return await ent
        if len(self._inflight) >= self.max_keys:
            # Registry full: do NOT coalesce this one — run it directly
            # (fail-safe: extra work, never a dropped/dangling operation).
            self.rejected += 1
            logger.info(
                "VC_ARCH_SINGLE_FLIGHT_REGISTRY_FULL op=%s size=%d bound=%d "
                "— running uncoalesced (fail-safe: extra RPC, no drop)",
                self.name, len(self._inflight), self.max_keys)
            return await factory()
        fut: "asyncio.Future[Any]" = loop.create_future()
        self._inflight[key] = fut
        try:
            result = await factory()
        except BaseException as exc:  # noqa: BLE001 — propagate to ALL waiters
            if not fut.done():
                fut.set_exception(exc)
            self._inflight.pop(key, None)
            raise
        if not fut.done():
            fut.set_result(result)
        self._inflight.pop(key, None)
        return result

    def inflight_count(self) -> int:
        return len(self._inflight)


# ===========================================================================
# §14/§31 — BOUNDED GATE (backpressure, graceful degradation)
# ===========================================================================

class BoundedGate:
    """Concurrency + queue-depth bound for one operation class.

    acquire() semantics (§14/§31 graceful degradation):
      * capacity available → acquired immediately;
      * capacity full, and the wait queue (INCLUDING this caller, who
        would occupy depth position ``_waiting + 1``) would be at or
        beyond ``max_depth`` → DEFERRED immediately with an observable
        marker (the §14 wording "waiters >= max_depth" counts the
        caller: a queue of max_depth-1 parkers is the most this gate
        will hold, the max_depth-th arrival defers instead of parking);
      * otherwise the caller parks for a SINGLE bounded
        ``asyncio.wait_for(event.wait())`` — never a retry loop, never
        an unbounded park: the wait is bounded by the caller's
        ``deadline`` (§19 deadline propagation) or, when the caller
        provides none, by ``default_wait`` seconds (bounded by
        construction; ``release()`` wakes parked callers earlier).
      * deadline passed (or default wait exhausted) → re-check capacity
        ONCE, then DEFER. Deferral NEVER drops, deletes or excludes —
        the caller requeues/retries later.

    release() wakes parked callers via the event; racing callers that
    lose the race fall through to the capacity re-check and either
    acquire or defer deterministically.
    """

    DEFAULT_WAIT_SECONDS = 5.0  # no-deadline park bound (see class doc)

    def __init__(self, name: str, capacity: int, max_depth: int) -> None:
        self.name = str(name)
        self.capacity = max(1, int(capacity))
        self.max_depth = max(0, int(max_depth))
        self.default_wait = float(self.DEFAULT_WAIT_SECONDS)
        self._active = 0
        self._waiting = 0
        self._released: Optional[asyncio.Event] = None
        self.deferred = 0
        self.acquired = 0

    def _event(self) -> asyncio.Event:
        if self._released is None:
            self._released = asyncio.Event()
        return self._released

    def _defer(self, reason: str) -> bool:
        self.deferred += 1
        logger.info(
            "VC_ARCH_BACKPRESSURE_DEFERRED gate=%s reason=%s "
            "active=%d capacity=%d waiting=%d depth_bound=%d — operation "
            "deferred (retry next cycle; state preserved, nothing dropped)",
            self.name, reason, self._active, self.capacity,
            self._waiting, self.max_depth)
        return False

    async def acquire(self, deadline: Optional[float] = None) -> bool:
        """True = slot acquired (caller MUST release()); False = DEFER."""
        if self._active < self.capacity:
            self._active += 1
            self.acquired += 1
            return True
        # Depth bound counts THIS caller (would park at position
        # _waiting + 1): at-or-beyond the bound → defer, never park.
        if self._waiting + 1 >= self.max_depth:
            return self._defer("depth_bound")
        # Bounded park: caller deadline, else the gate's default_wait.
        if deadline is not None:
            timeout = max(0.0, deadline - time.monotonic())
            if timeout <= 0.0:
                return self._defer("deadline_passed")
        else:
            timeout = self.default_wait
        self._waiting += 1
        try:
            ev = self._event()
            ev.clear()
            try:
                await asyncio.wait_for(ev.wait(), timeout=timeout)
            except asyncio.TimeoutError:
                pass  # bounded park exhausted → re-check once, then defer
        finally:
            self._waiting -= 1
        # One deterministic re-check (NOT a loop): capacity may have been
        # released while we parked.
        if self._active < self.capacity:
            self._active += 1
            self.acquired += 1
            return True
        return self._defer("wait_exhausted")

    def release(self) -> None:
        if self._active > 0:
            self._active -= 1
        if self._released is not None:
            self._released.set()

    def snapshot(self) -> Dict[str, Any]:
        return {
            "gate": self.name, "active": self._active,
            "capacity": self.capacity, "waiting": self._waiting,
            "depth_bound": self.max_depth,
            "acquired_total": self.acquired, "deferred_total": self.deferred,
        }


def arch_gate(name: str, *, cfg: Optional[Any] = None,
              capacity: Optional[int] = None,
              max_depth: Optional[int] = None) -> BoundedGate:
    """Get-or-create the named gate bound to the configured budgets."""
    gate = _GATES.get(name)
    if gate is None:
        cap = capacity if capacity is not None else arch_budget(
            f"max_{name}_in_flight", cfg)
        depth = max_depth if max_depth is not None else arch_budget(
            "max_dispatch_queue_depth", cfg)
        gate = BoundedGate(name, cap, depth)
        _GATES[name] = gate
    return gate


def gates_snapshot() -> Dict[str, Dict[str, Any]]:
    return {k: g.snapshot() for k, g in sorted(_GATES.items())}


# ===========================================================================
# §20 — TASK OWNERSHIP REGISTRY
# ===========================================================================

class TaskRegistry:
    """Every task created through this registry has an OWNER, a PURPOSE,
    and a lifecycle (§20: no orphan tasks). The registry reaps done
    entries each track() call and on population() queries — bounded
    memory, observable population (marker when over bound).

    Cancellation: ``shutdown(deadline)`` cancels then awaits every live
    tracked task with a bounded drain window (stop accepting work →
    cancel → drain → await). Exceptions are collected, never swallowed
    silently: each is logged with owner context.
    """

    def __init__(self, name: str, population_bound: int = 5000) -> None:
        self.name = str(name)
        self.population_bound = int(population_bound)
        self._tasks: Dict[asyncio.Task, Dict[str, Any]] = {}
        self._cancelled = 0
        self._collected_exceptions = 0

    def track(self, coro: Awaitable[Any], *, owner: str,
              purpose: str = "") -> "asyncio.Task[Any]":
        task = asyncio.get_running_loop().create_task(coro)
        self._tasks[task] = {
            "owner": str(owner)[:80], "purpose": str(purpose)[:80],
            "created": time.monotonic(),
        }
        task.add_done_callback(self._reap)
        if len(self._tasks) > self.population_bound:
            logger.warning(
                "VC_ARCH_TASK_POPULATION registry=%s population=%d bound=%d "
                "— over observability bound (work continues; investigate "
                "task leaks)",
                self.name, len(self._tasks), self.population_bound)
        return task

    def _reap(self, task: "asyncio.Task[Any]") -> None:
        self._tasks.pop(task, None)
        if task.cancelled():
            self._cancelled += 1
            return
        exc = task.exception()
        if exc is not None:
            self._collected_exceptions += 1
            meta = {"owner": "reaped", "purpose": ""}
            logger.warning(
                "VC_ARCH_TASK_EXCEPTION registry=%s exc=%s — collected, "
                "not swallowed",
                self.name, type(exc).__name__)

    def population(self) -> int:
        return len(self._tasks)

    def live(self) -> List[Dict[str, Any]]:
        return [
            {"owner": m["owner"], "purpose": m["purpose"],
             "age_s": round(time.monotonic() - m["created"], 1),
             "done": t.done()}
            for t, m in list(self._tasks.items())[:64]
        ]

    async def shutdown(self, deadline: float = 30.0) -> Dict[str, int]:
        """§20 shutdown order: cancel producers → drain → await."""
        t0 = time.monotonic()
        pending = [t for t in self._tasks if not t.done()]
        for t in pending:
            t.cancel()
        remaining = [t for t in pending if not t.done()]
        if remaining:
            done, still = await asyncio.wait(
                remaining, timeout=max(0.0, deadline))
            for t in still:
                logger.warning(
                    "VC_ARCH_TASK_SHUTDOWN_TIMEOUT registry=%s task=%s "
                    "owner=%s — did not finish within drain window",
                    self.name, getattr(t, "get_name", lambda: "?")(),
                    self._tasks.get(t, {}).get("owner", "?"))
        stats = {
            "cancelled": self._cancelled,
            "exceptions": self._collected_exceptions,
            "drain_seconds": round(time.monotonic() - t0, 1),
        }
        logger.info(
            "VC_ARCH_TASK_REGISTRY_SHUTDOWN registry=%s cancelled=%d "
            "collected_exceptions=%d drain=%.1fs",
            self.name, stats["cancelled"], stats["exceptions"],
            stats["drain_seconds"])
        return stats


_ARCH_TASKS = TaskRegistry("vc_arch", arch_budget("task_population_bound"))


def arch_tasks() -> TaskRegistry:
    return _ARCH_TASKS


# ===========================================================================
# §13 — NEGATIVE-CACHE CARDINALITY SAFEGUARD
# ===========================================================================

def negcache_sweep(cache: Dict[Tuple[int, str], Dict[str, Any]],
                   max_entries: int, *, reason: str = "periodic") -> int:
    """Enforce the negative-cache cardinality bound (§13: 'never allow
    unbounded cache growth').

    Eviction is DETERMINISTIC and OBSERVABLE: entries are evicted in
    DESCENDING ``next_try`` order — the farthest-from-retry entries go
    first, which is the FAIL-SAFE direction: an evicted target becomes
    immediately retry-eligible (may cost one extra RPC; NEVER a
    permanent exclusion). TTL semantics of surviving entries are
    untouched; entries with an expired TTL are swept first (free wins).

    Called periodically (bootstrap liveness loop) + at cycle boundaries;
    the per-record hot path in voicechat.py is deliberately untouched
    (FIX-ZZ behavior + its exec-based v98.08 regression tests stay
    byte-stable).
    """
    try:
        bound = int(max_entries)
    except (TypeError, ValueError):
        return 0
    if bound <= 0 or len(cache) <= bound:
        return 0
    # Pass 1 (finite): drop expired-TTL entries — they are semantically
    # free to remove (the check() path would expire them anyway).
    now = time.monotonic()
    expired = [k for k, v in cache.items()
               if float(v.get("next_try", 0.0)) <= now]
    for k in expired:
        cache.pop(k, None)
    if len(cache) <= bound:
        return len(expired)
    # Pass 2 (finite, deterministic): over bound → evict by descending
    # next_try until at bound.
    over = len(cache) - bound
    ranked = sorted(
        cache.items(),
        key=lambda kv: float(kv[1].get("next_try", 0.0)),
        reverse=True,
    )
    evicted = 0
    for k, _v in ranked[:over]:
        cache.pop(k, None)
        evicted += 1
    logger.info(
        "VC_ARCH_NEGCACHE_SWEEP reason=%s expired=%d evicted=%d size=%d "
        "bound=%d order=descending_next_try (fail-safe: evicted targets "
        "become retry-eligible; NEVER an exclusion)",
        reason, len(expired), evicted, len(cache), bound)
    return len(expired) + evicted


# ===========================================================================
# §11 — SCOPE-TOKEN LIFECYCLE REGISTRY (stale id() reuse protection)
# ===========================================================================

_SCOPE_REGISTRY: Dict[str, Dict[str, Any]] = {}
_SCOPE_REBOUNDS: List[Dict[str, str]] = []


def scope_registry_update(live_map: Dict[str, str],
                          *, reason: str = "poll") -> List[str]:
    """Fold the live CLIENT_SCOPE_MAP (voicechat.py::_vc_client_scope_
    account_map) into the lifecycle registry; detect scope-token REBINDS
    (same ``client:<id>`` token now owned by a DIFFERENT account — the
    Python id() reuse hazard §11) and return the rebound token list.

    The caller (voicechat integration) clears negative-cache entries
    keyed to rebound tokens: an old client's backoff must never gate a
    NEW client inheriting the same id() (cross-account contamination).
    Bounded: registry size == live map size; rebind history <= 32.
    """
    rebound: List[str] = []
    for token, account in live_map.items():
        prev = _SCOPE_REGISTRY.get(token)
        if prev is not None and prev.get("account") not in (None, account):
            rebound.append(token)
            _SCOPE_REBOUNDS.append({
                "token": token,
                "old_account": str(prev.get("account")),
                "new_account": str(account),
                "reason": reason,
            })
        _SCOPE_REGISTRY[token] = {"account": account, "seen": time.monotonic()}
    # Tokens that disappeared (client replaced/disconnected/rotated).
    gone = [t for t in list(_SCOPE_REGISTRY.keys()) if t not in live_map]
    for t in gone:
        _SCOPE_REGISTRY.pop(t, None)
    if len(_SCOPE_REBOUNDS) > 32:
        del _SCOPE_REBOUNDS[:-32]
    if rebound:
        logger.warning(
            "VC_SCOPE_TOKEN_REBOUND count=%d tokens=%s reason=%s — "
            "id(client) reuse across accounts; clearing stale negative-"
            "cache entries for these tokens (isolation §11)",
            len(rebound), ",".join(sorted(rebound))[:160], reason)
    return rebound


def scope_registry_snapshot() -> Dict[str, Any]:
    return {
        "tokens": len(_SCOPE_REGISTRY),
        "accounts": len({v.get("account") for v in _SCOPE_REGISTRY.values()}),
        "rebinds": len(_SCOPE_REBOUNDS),
        "recent_rebinds": list(_SCOPE_REBOUNDS[-4:]),
    }


def scope_registry_clear() -> None:
    """Full invalidation (rotation / session import / shutdown §33)."""
    n = len(_SCOPE_REGISTRY)
    _SCOPE_REGISTRY.clear()
    if n:
        logger.info(
            "VC_SCOPE_REGISTRY_INVALIDATED tokens=%d reason=lifecycle "
            "— all scope tokens invalidated; live map is rebuilt on next "
            "use (no stale references)", n)


# ===========================================================================
# §21 — UNIFIED RETRY BUDGET (sliding window; FIX-ZZ semantics preserved)
# ===========================================================================

class RetryBudget:
    """Bounded sliding-window retry budget. Semantics identical to the
    v98.08 _vc_reresolve budget (<= N attempts / window seconds); this
    class adds an explicit marker + observability so retry storms are
    visible (§21). take() is O(pending) with a finite list prune — no
    loops that can spin."""

    def __init__(self, name: str, max_per_window: int, window: float) -> None:
        self.name = str(name)
        self.max_per_window = int(max_per_window)
        self.window = float(window)
        self.events: List[float] = []
        self.suppressed = 0

    def take(self, *, now: Optional[float] = None) -> bool:
        _now = time.monotonic() if now is None else now
        self.events = [t for t in self.events if _now - t < self.window]
        if len(self.events) >= self.max_per_window:
            self.suppressed += 1
            if self.suppressed == 1 or self.suppressed % 25 == 0:
                logger.info(
                    "VC_ARCH_RETRY_BUDGET_EXHAUSTED op=%s window=%.0fs "
                    "budget=%d suppressed=%d — deferring retries (backoff, "
                    "never dropping)",
                    self.name, self.window, self.max_per_window,
                    self.suppressed)
            return False
        self.events.append(_now)
        return True

    def snapshot(self) -> Dict[str, Any]:
        return {"op": self.name, "window": self.window,
                "budget": self.max_per_window,
                "used": len(self.events), "suppressed": self.suppressed}


def arch_retry_budget(cfg: Optional[Any] = None) -> RetryBudget:
    """The discovery re-resolve retry budget (defaults == v98.08 FIX-ZZ)."""
    return RetryBudget(
        "entity_re_resolve",
        arch_budget("retry_budget_per_window", cfg),
        float(arch_budget("retry_window_seconds", cfg)))


# ===========================================================================
# §25 — CANARY CLASSIFICATION + CONTEXT SNAPSHOT
# ===========================================================================

CANARY_CLASSES: Tuple[str, ...] = (
    "EVENT_LOOP_BLOCKED",       # sync code owns the loop thread (v98.08 class)
    "EVENT_LOOP_STARVED",       # loop alive but heartbeats delayed (queueing)
    "DISCOVERY_OVER_BUDGET",    # discovery cycle past its wall cap
    "RPC_STUCK",                # an RPC await is not returning
    "LOCK_WAIT",                # heartbeats queued behind a lock holder
    "TASK_BACKLOG",             # pending-task population swamped the loop
    "CPU_PRESSURE",             # saturated CPU delaying the 5s stamp
)

# Snapshot providers: bootstrap registers producers lazily so this
# stdlib-only module never imports voicechat (no import cycles).
_SNAPSHOT_PROVIDERS: Dict[str, Callable[[], Dict[str, Any]]] = {}


def register_snapshot_provider(name: str,
                               provider: Callable[[], Dict[str, Any]]) -> None:
    _SNAPSHOT_PROVIDERS[str(name)[:40]] = provider


def canary_context_snapshot(bot_version: str = "unknown") -> Dict[str, Any]:
    """§25 dump enrichment: PID, timestamp, bot version, cycle, account/
    scope, current discovery state, current query index, queue depths,
    task population, active operations. All providers are exception-
    guarded (a diagnostics mechanism must never BE the failure)."""
    snap: Dict[str, Any] = {
        "pid": os.getpid(),
        "ts": time.time(),
        "bot_version": str(bot_version)[:40],
        "discovery": phase_snapshot(),
        "gates": gates_snapshot(),
        "scope_registry": scope_registry_snapshot(),
    }
    for name, provider in list(_SNAPSHOT_PROVIDERS.items()):
        try:
            snap[str(name)[:40]] = provider()
        except Exception as exc:  # noqa: BLE001 — diagnostics must not fail
            snap[f"{name}_error"] = f"{type(exc).__name__}: {exc}"[:120]
    return snap


def render_canary_context(snap: Dict[str, Any]) -> str:
    """Render the snapshot as a deterministic text block for the dump
    file (written BEFORE the faulthandler stacks)."""
    lines: List[str] = [
        "=== VC_ARCH CONTEXT (v98.09 §25) ===",
        f"pid={snap.get('pid')} ts={snap.get('ts')} "
        f"bot_version={snap.get('bot_version')}",
    ]
    disc = snap.get("discovery") or {}
    if isinstance(disc, dict):
        lines.append(
            "discovery: " + " ".join(
                f"{k}={disc.get(k)}" for k in (
                    "phase", "query_index", "queries_total", "over_budget",
                    "cycle_elapsed", "cap_seconds", "active")
                if k in disc))
    gates = snap.get("gates") or {}
    if isinstance(gates, dict):
        for gname, g in sorted(gates.items()):
            if isinstance(g, dict):
                lines.append(
                    f"gate {gname}: active={g.get('active')}/"
                    f"{g.get('capacity')} waiting={g.get('waiting')} "
                    f"deferred={g.get('deferred_total')}")
    sr = snap.get("scope_registry") or {}
    if isinstance(sr, dict):
        lines.append(
            f"scope_registry: tokens={sr.get('tokens')} "
            f"accounts={sr.get('accounts')} rebinds={sr.get('rebinds')}")
    for k, v in snap.items():
        if k in ("pid", "ts", "bot_version", "discovery", "gates",
                 "scope_registry"):
            continue
        lines.append(f"{k}: {str(v)[:200]}")
    lines.append("=== END VC_ARCH CONTEXT ===")
    return "\n".join(lines)


def classify_canary_event(age: float, threshold: float,
                          evidence: Optional[Dict[str, Any]] = None
                          ) -> Tuple[str, str]:
    """Classify a canary trigger (§25: 'do not misclassify every delayed
    heartbeat as an RPC freeze').

    Decision table (deterministic, evidence-keyed; first match wins):
      1. loop_blocked_in_user_code + in discovery + over cycle budget
           → DISCOVERY_OVER_BUDGET
      2. loop_blocked_in_user_code + in discovery
           → EVENT_LOOP_BLOCKED (the 2026-09-01 v98.08 class)
      3. loop_blocked_in_user_code (anywhere)
           → EVENT_LOOP_BLOCKED
      4. task_backlog > bound  → TASK_BACKLOG
      5. lock_wait             → LOCK_WAIT
      6. rpc_awaiting          → RPC_STUCK
      7. cpu_pressure          → CPU_PRESSURE
      8. otherwise (loop alive, stamp stale) → EVENT_LOOP_STARVED

    Returns (class, rationale). Age/threshold are always included in the
    rationale for forensics.
    """
    ev = evidence or {}
    blocked = bool(ev.get("loop_blocked_in_user_code", False))
    in_disc = bool(ev.get("discovery_active", False))
    over = bool(ev.get("discovery_over_budget", False))
    base = f"age={age:.0f}s threshold={threshold:.0f}s"
    if blocked:
        if in_disc and over:
            return ("DISCOVERY_OVER_BUDGET",
                    f"{base} loop thread frozen in discovery code, cycle "
                    f"over wall cap")
        where = "in discovery code" if in_disc else "in user code"
        return ("EVENT_LOOP_BLOCKED",
                f"{base} loop thread frozen synchronously {where}")
    backlog = int(ev.get("task_backlog", 0) or 0)
    bound = int(ev.get("task_backlog_bound", 5000) or 5000)
    if backlog > bound:
        return ("TASK_BACKLOG",
                f"{base} pending_tasks={backlog} > bound={bound}")
    if ev.get("lock_wait"):
        return ("LOCK_WAIT",
                f"{base} heartbeat queued behind a lock holder")
    if ev.get("rpc_awaiting"):
        return ("RPC_STUCK",
                f"{base} an awaited RPC has not returned; loop alive")
    if ev.get("cpu_pressure"):
        return ("CPU_PRESSURE",
                f"{base} cpu_saturated=true; 5s stamp delayed by load")
    return ("EVENT_LOOP_STARVED",
            f"{base} loop alive but liveness stamp starved")


# ===========================================================================
# §28 — STARTUP CONFIGURATION VALIDATION
# ===========================================================================

def validate_vc_arch_config(cfg: Any) -> Tuple[bool, List[str]]:
    """Validate the VC/discovery configuration model at STARTUP (§28:
    reject impossible combinations with a clear diagnostic rather than
    failing later inside discovery).

    Reads ONLY getattr (works with the real config object, SimpleNames-
    pace test doubles, and dict-like shims). Returns (ok, problems).
    """
    problems: List[str] = []

    def g(name: str, default: Any = None) -> Any:
        return getattr(cfg, name, default)

    # 1. In-flight / concurrency budgets must be >= 1 (0 would deadlock
    #    every acquire; negative is nonsense).
    for attr in (
        "vc_arch_max_discovery_in_flight",
        "vc_arch_max_entity_resolution_in_flight",
        "vc_arch_max_classification_in_flight",
        "vc_arch_max_join_in_flight",
        "vc_arch_max_reconcile_in_flight",
        "vc_discovery_metadata_concurrency",
    ):
        val = g(attr)
        if val is not None:
            try:
                if int(val) < 1:
                    problems.append(
                        f"{attr}={val} must be >= 1 (a zero concurrency "
                        f"budget would deadlock all acquisitions)")
            except (TypeError, ValueError):
                problems.append(f"{attr}={val!r} is not an integer")

    # 2. Join concurrency vs auto-join: if auto-join is enabled the join
    #    budget must be >= 1 (redundant with #1 but explicit).
    if bool(g("vc_discovery_auto_join", True)):
        join_budget = g("vc_arch_max_join_in_flight")
        if join_budget is not None:
            try:
                if int(join_budget) < 1:
                    problems.append(
                        "vc_discovery_auto_join=true with "
                        f"vc_arch_max_join_in_flight={join_budget}: joins "
                        "would deadlock")
            except (TypeError, ValueError):
                pass

    # 3. Wall cap vs interval: the cycle cap must be < the interval
    #    (a cap >= interval means the cycle can never complete + rest).
    cap = g("vc_discovery_cycle_wall_cap")
    interval = g("vc_discovery_interval")
    if cap is not None and interval is not None:
        try:
            if int(cap) >= int(interval):
                problems.append(
                    f"vc_discovery_cycle_wall_cap={cap} >= "
                    f"vc_discovery_interval={interval} — the cycle would "
                    f"occupy the whole interval (no rest window; cap "
                    f"should be well below the interval)")
        except (TypeError, ValueError):
            pass

    # 4. Max queries vs results: queries_per_cycle * results_per_query
    #    must not exceed max_results_per_cycle * 5 (a 5x explosion means
    #    a misconfiguration that would hammer classification).
    maxq = g("vc_discovery_max_queries_per_cycle")
    rpq = g("vc_discovery_results_per_query")
    mrc = g("vc_discovery_max_results_per_cycle")
    if None not in (maxq, rpq, mrc):
        try:
            if int(maxq) * int(rpq) > int(mrc) * 5:
                problems.append(
                    f"vc_discovery_max_queries_per_cycle({maxq}) × "
                    f"results_per_query({rpq}) far exceeds "
                    f"max_results_per_cycle({mrc}) — candidate explosion")
        except (TypeError, ValueError):
            pass

    # 5. Negative-cache bound vs retry budget coherence.
    neg_bound = g("vc_arch_negcache_max_entries")
    if neg_bound is not None:
        try:
            if int(neg_bound) < 100:
                problems.append(
                    f"vc_arch_negcache_max_entries={neg_bound} < 100 — "
                    f"the safeguard would thrash (evicting nearly every "
                    f"cycle)")
        except (TypeError, ValueError):
            pass

    # 6. Canary: exit enabled + supervisor EXPLICITLY absent → the process
    #    would exit dark (the 2026-09-01 incident mode). The flag is set by
    #    bootstrap AFTER its systemd detection; a MISSING flag means "not
    #    yet detected at this call site" — no warning (bootstrap's own
    #    BOT_SUPERVISOR_DETECTED line carries that diagnostic).
    canary_exit = g("vc_heartbeat_canary")
    supervisor_flag = g("_vc_arch_supervisor_detected", None)
    if canary_exit is True and supervisor_flag is False:
        # WARNING-class problem (does not block startup).
        problems.append(
            "vc_heartbeat_canary=true but supervisor=none detected — "
            "exit(86) would leave the bot DARK until manual restart "
            "(2026-09-01 incident mode; install deploy/mediagrab.service)")

    ok = not any(p for p in problems if "supervisor" not in p)
    if ok:
        logger.info(
            "VC_ARCH_CONFIG_VALIDATED problems=%d — v98.09 boundedness "
            "model validated at startup (budgets: %s)",
            len(problems),
            " ".join(f"{k}={arch_budget(k, cfg)}"
                     for k in sorted(VC_ARCH_BUDGETS)))
    else:
        logger.error(
            "VC_ARCH_CONFIG_INVALID problems=%d — %s",
            len(problems), " | ".join(problems))
    return ok, problems


# ===========================================================================
# §27 — OBSERVABILITY CONTRACT (stable marker registry)
# ===========================================================================
# Existing v98.08 markers are preserved verbatim in their modules. These
# are the NEW v98.09 architecture markers (contract test asserts each).

ARCH_MARKERS: Tuple[str, ...] = (
    "VC_DISCOVERY_PHASE",
    "VC_DISCOVERY_QUERY_PLAN",
    "VC_ARCH_BACKPRESSURE_DEFERRED",
    "VC_ARCH_SINGLE_FLIGHT_REGISTRY_FULL",
    "VC_ARCH_SINGLE_FLIGHT_COALESCED",
    "VC_ARCH_TASK_POPULATION",
    "VC_ARCH_TASK_EXCEPTION",
    "VC_ARCH_TASK_REGISTRY_SHUTDOWN",
    "VC_ARCH_TASK_SHUTDOWN_TIMEOUT",
    "VC_ARCH_NEGCACHE_SWEEP",
    "VC_ARCH_RETRY_BUDGET_EXHAUSTED",
    "VC_SCOPE_TOKEN_REBOUND",
    "VC_SCOPE_REGISTRY_INVALIDATED",
    "VC_ARCH_CONFIG_VALIDATED",
    "VC_ARCH_CONFIG_INVALID",
    "VC_HEARTBEAT_CANARY_CLASSIFIED",
    "VC_ARCH_BUDGETS_HEARTBEAT",
)

# Markers inherited from v98.07/v98.08 that MUST remain present in the
# shipped sources (the preservation contract test walks these).
PRESERVED_MARKERS: Tuple[str, ...] = (
    "BOT_HEARTBEAT",
    "BOT_VERSION",
    "CLIENT_SCOPE_MAP",
    "VC_HEARTBEAT_CANARY_TRIGGERED",
    "VC_HEARTBEAT_CANARY_DUMP_WRITTEN",
    "STARTUP_RECOVERY",
    "BOT_SUPERVISOR_DETECTED",
    "AUTO_DISCOVERY_CYCLE_STARTED",
    "AUTO_DISCOVERY_CYCLE_CAPPED",
    "VC_ROTATION_BACKEND_DECISION",
    "VC_ROTATION_SETTLE_WINDOW",
    "VC_ENTITY_NEGATIVE_CACHE_SET",
    "VC_ENTITY_BACKOFF_SKIPPED",
    "VC_CLASSIFY_FAILURE",
    "VC_JOIN_SUCCESS",
    "VC_RECONCILE_DEFERRED_SETTLE",
    "VC_RECONCILE_FOUND_MISSING_SUMMARY",
    "TASK_POPULATION",
    "TASK_DUMP_SUPPRESSED",
)


# ===========================================================================
# §27/§30 — heartbeat budget line (rate-limited)
# ===========================================================================

_last_budget_heartbeat = 0.0
_BUDGET_HEARTBEAT_INTERVAL = 300.0  # 5 min cadence; markers rate-limited


def arch_budgets_heartbeat_line(*, now: Optional[float] = None,
                                force: bool = False) -> Optional[str]:
    """Compact one-line boundedness status for the heartbeat log
    (§26: diagnostics improved without increasing frequency — 5-min
    cadence, rate-limited). Returns None inside the quiet window."""
    global _last_budget_heartbeat
    _now = time.monotonic() if now is None else now
    if not force and _now - _last_budget_heartbeat < _BUDGET_HEARTBEAT_INTERVAL:
        return None
    _last_budget_heartbeat = _now
    parts = [f"{k}={arch_budget(k)}" for k in sorted(VC_ARCH_BUDGETS)]
    gates = gates_snapshot()
    gparts = [f"{n}:a={g['active']}/{g['capacity']}w={g['waiting']}d={g['deferred_total']}"
              for n, g in sorted(gates.items())]
    line = ("VC_ARCH_BUDGETS_HEARTBEAT " + " ".join(parts)
            + (" gates " + " ".join(gparts) if gparts else ""))
    return line


def emit_budgets_heartbeat(*, now: Optional[float] = None,
                           force: bool = False) -> None:
    """Log the boundedness heartbeat line (rate-limited unless forced)."""
    line = arch_budgets_heartbeat_line(now=now, force=force)
    if line:
        logger.info("%s", line)


# ===========================================================================
# §36 — INVARIANT CHECK ENTRY POINT (property-test surface)
# ===========================================================================

def check_invariants() -> Dict[str, Any]:
    """Live invariant report (§36): queries <= max_q (per plan), task
    population <= bound, cache sizes <= bounds, retry <= budget. Used
    by the property tests and available to operators via the test layer."""
    report: Dict[str, Any] = {"ts": time.time()}
    gates = gates_snapshot()
    for name, g in gates.items():
        report[f"gate_{name}_active_le_capacity"] = \
            g["active"] <= g["capacity"]
        report[f"gate_{name}_waiting_le_depth"] = \
            g["waiting"] <= max(0, g["depth_bound"])
    report["task_population"] = _ARCH_TASKS.population()
    report["task_population_le_bound"] = \
        _ARCH_TASKS.population() <= _ARCH_TASKS.population_bound
    report["scope_registry_size"] = len(_SCOPE_REGISTRY)
    report["rebind_history_le_32"] = len(_SCOPE_REBOUNDS) <= 32
    return report


# ===========================================================================
# §33 — lifecycle: reset for tests / hot reload
# ===========================================================================

def arch_reset_for_test() -> None:
    """Test seam: reset all module-level registries to pristine state.
    Production code never calls this."""
    global _ACTIVE_MACHINE, _GATES, _ARCH_TASKS, _SCOPE_REGISTRY
    global _SCOPE_REBOUNDS, _last_budget_heartbeat
    _ACTIVE_MACHINE = None
    _GATES = {}
    _ARCH_TASKS = TaskRegistry("vc_arch", arch_budget("task_population_bound"))
    _SCOPE_REGISTRY = {}
    _SCOPE_REBOUNDS = []
    _last_budget_heartbeat = 0.0
