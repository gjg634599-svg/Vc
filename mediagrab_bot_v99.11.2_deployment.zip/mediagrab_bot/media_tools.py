"""Media tools — extracted from _bot_core.py.

FFmpeg-based media utilities: audio extraction, thumbnail extraction,
video compression, image conversion, media info.
Depends on: subprocess, PIL, pathlib, logging.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import subprocess
from pathlib import Path
from typing import Any, Optional

from PIL import Image

from .utils_real import unique_path, remove_path
from .frame_extractor import _FFMPEG, _FFPROBE

logger = logging.getLogger("mediagrab")

class ToolError(Exception):
    pass


# Whitelist for ffmpeg ``-vf scale=W:H`` argument. (SEC-C-001)
_SCALE_RE = re.compile(r"^\d{1,5}:\d{1,5}$")


# MEDIA-C-002: cap the maximum image pixel count Pillow will decode.  Files
# exceeding this raise ``Image.DecompressionBombError`` on load, preventing
# a malicious upload from exhausting memory during conversion.
Image.MAX_IMAGE_PIXELS = 20_000_000


async def extract_audio(video_path: Path, out_dir: Path,
                        bitrate: str = "192k") -> Path:
    video_path = Path(video_path)
    out_dir.mkdir(parents=True, exist_ok=True)
    out = unique_path(out_dir, f"{video_path.stem}.mp3")
    cmd = [
        _FFMPEG, "-y", "-loglevel", "error",
        "-i", str(video_path),
        "-vn", "-acodec", "libmp3lame", "-b:a", bitrate,
        str(out),
    ]
    await _run_ffmpeg(cmd, out, label="extract_audio")
    return out


async def extract_thumbnail(video_path: Path, out_dir: Path,
                            ts: float = 1.0) -> Path:
    video_path = Path(video_path)
    out_dir.mkdir(parents=True, exist_ok=True)
    out = unique_path(out_dir, f"{video_path.stem}_thumb.jpg")
    cmd = [
        _FFMPEG, "-y", "-loglevel", "error",
        "-ss", f"{max(0.0, ts):.3f}", "-i", str(video_path),
        "-frames:v", "1", "-q:v", "2",
        str(out),
    ]
    await _run_ffmpeg(cmd, out, label="extract_thumbnail")
    return out


async def media_info(path: Path) -> dict:
    path = Path(path)
    cmd = [
        _FFPROBE, "-v", "error",
        "-print_format", "json",
        "-show_format", "-show_streams",
        str(path),
    ]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
    except (FileNotFoundError, asyncio.TimeoutError) as exc:
        # v99.02 FIX-7b (RC-7, deterministic leak): on timeout the
        # ffprobe child + its two pipe FDs were ABANDONED alive (no kill
        # — the process kept running and the pipes stayed open). Kill +
        # reap before raising so every timed-out probe is fully cleaned.
        try:
            proc.kill()  # type: ignore[union-attr]
            await proc.communicate()  # type: ignore[union-attr]
        except Exception:  # noqa: BLE001
            pass
        raise ToolError(f"ffprobe unavailable: {exc}") from exc
    if proc.returncode != 0:
        raise ToolError(
            f"ffprobe failed: {stderr.decode(errors='replace')[:200]}"
        )
    try:
        data = json.loads(stdout.decode(errors="replace"))
    except json.JSONDecodeError as exc:
        raise ToolError(f"ffprobe returned non-JSON: {exc}") from exc
    return _normalise_info(data)


def _normalise_info(data: dict) -> dict:
    fmt = data.get("format", {}) or {}
    streams = data.get("streams", []) or []
    v = next((s for s in streams if s.get("codec_type") == "video"), {})
    a = next((s for s in streams if s.get("codec_type") == "audio"), {})

    def g(d, *keys, default=None):
        for k in keys:
            if k in d and d[k] not in (None, ""):
                return d[k]
        return default

    out = {
        "format": g(fmt, "format_long_name", "format_name"),
        "duration": _fmt_duration(g(fmt, "duration")),
        "size_bytes": g(fmt, "size"),
        "bit_rate": g(fmt, "bit_rate"),
        "video_codec": g(v, "codec_long_name", "codec_name"),
        "width": g(v, "width"),
        "height": g(v, "height"),
        "fps": _parse_fps(g(v, "r_frame_rate")),
        "audio_codec": g(a, "codec_long_name", "codec_name"),
        "channels": g(a, "channels"),
        "sample_rate": g(a, "sample_rate"),
    }
    return {k: v for k, v in out.items() if v is not None}


def _fmt_duration(raw) -> str:
    try:
        secs = float(raw)
    except (TypeError, ValueError):
        return ""
    h = int(secs // 3600)
    m = int((secs % 3600) // 60)
    s = secs % 60
    if h:
        return f"{h}:{m:02d}:{s:05.2f}"
    return f"{m}:{s:05.2f}"


def _parse_fps(rate) -> str:
    if not rate or "/" not in rate:
        return str(rate) if rate else ""
    try:
        num, den = rate.split("/")
        den = float(den)
        if den == 0:
            return ""
        return f"{float(num) / den:.2f}"
    except (ValueError, ZeroDivisionError):
        return ""


async def compress_video(video_path: Path, out_dir: Path, *,
                         crf: int = 28, preset: str = "veryfast",
                         scale: Optional[str] = None) -> Path:
    video_path = Path(video_path)
    out_dir.mkdir(parents=True, exist_ok=True)
    out = unique_path(out_dir, f"{video_path.stem}_compressed.mp4")
    cmd = [
        _FFMPEG, "-y", "-loglevel", "error",
        "-i", str(video_path),
        "-c:v", "libx264", "-preset", preset, "-crf", str(crf),
        "-c:a", "aac", "-b:a", "128k",
    ]
    vf = []
    if scale:
        # SEC-C-001: scale is interpolated into the ffmpeg command; validate
        # it strictly matches ``W:H`` to prevent argument injection.
        if not _SCALE_RE.match(scale):
            raise ToolError(f"Invalid scale: {scale!r}")
        vf.append(f"scale={scale}")
    if vf:
        cmd += ["-vf", ",".join(vf)]
    cmd += ["-movflags", "+faststart", str(out)]
    await _run_ffmpeg(cmd, out, label="compress_video")
    return out


_PILLOW_FORMATS = {
    "png": "PNG", "jpg": "JPEG", "jpeg": "JPEG",
    "webp": "WEBP", "bmp": "BMP",
}


async def convert_image(img_path: Path, out_dir: Path, fmt: str) -> Path:
    fmt = (fmt or "").lower().lstrip(".")
    if fmt not in _PILLOW_FORMATS:
        raise ToolError(
            f"Unsupported target format '{fmt}'. Use one of: "
            + ", ".join(_PILLOW_FORMATS)
        )
    pil_fmt = _PILLOW_FORMATS[fmt]
    out_dir.mkdir(parents=True, exist_ok=True)
    out = unique_path(out_dir, f"{img_path.stem}.{fmt}")

    def _do() -> None:
        with Image.open(img_path) as im:
            # MEDIA-C-002: force Pillow to decode headers + pixels now so a
            # DecompressionBombError fires before we attempt to save.
            im.load()
            if pil_fmt == "JPEG" and im.mode in ("RGBA", "P", "LA"):
                im = im.convert("RGB")
            im.save(out, format=pil_fmt)

    try:
        await asyncio.to_thread(_do)
    except Exception as exc:  # noqa: BLE001
        await remove_path(out)
        raise ToolError(f"Image conversion failed: {exc}") from exc
    return out


async def _run_ffmpeg(cmd: list[str], out_path: Path, *,
                      label: str, timeout: int = 600) -> None:
    logger.info("%s: %s", label, " ".join(cmd[:3] + ["…", str(out_path)]))
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            await remove_path(out_path)
            raise ToolError(f"{label} timed out after {timeout}s")
        if proc.returncode != 0:
            err = stderr.decode(errors="replace")[:300] if stderr else ""
            await remove_path(out_path)
            raise ToolError(f"{label} failed: {err}")
        if not out_path.exists() or out_path.stat().st_size == 0:
            raise ToolError(f"{label} produced no output")
    except FileNotFoundError as exc:
        await remove_path(out_path)
        raise ToolError("ffmpeg is not installed") from exc
