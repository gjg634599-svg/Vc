"""Database layer — extracted from _bot_core.py.

Contains:
  - Schema definition (SCHEMA_SQL)
  - Migrations (MIGRATION_SQL, _run_migrations)
  - Connection lifecycle (init_db, get_db, close_db)
  - Core repositories (upsert_user, ensure_settings, add_download_history, etc.)
  - VC repositories (vc_upsert_group, vc_add_visit, etc.)
  - Talkative repositories (talkative_get_global_settings, etc.)
  - repo SimpleNamespace alias

Uses aiosqlite with WAL mode, busy_timeout, and a shared connection.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from collections import defaultdict, OrderedDict
# v99.07 FIX-28: the imports below were mid-file module-level imports
# (~line 2900) — legal but a hygiene violation (constraint: no
# module-level imports in the middle of a file); hoisted to the top.
import hashlib
import random
import re
import concurrent.futures
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from typing import Any, AsyncGenerator, Optional

import aiosqlite

from .config import config

logger = logging.getLogger("mediagrab")

# Injected config (set by _bot_core.py at import time)
_config = None


def _set_config(config):
    global _config
    _config = config


def _effective_config():
    """v99.07 FIX-9 (P0): the db_path source with a guaranteed fallback.

    The module imports ``config`` from .config at the top, but init_db()
    and friends dereferenced the INJECTED ``_config`` global — which is
    None unless _set_config() ran first (handlers.py calls it at import
    time, but any import-order change, partial import, or direct
    db_layer import left every DB call one AttributeError away from
    crashing). The injected config remains authoritative when set;
    otherwise the module-level config (the same object) is used.
    """
    # v99.07 FIX-9: fall back to the module-level config import.
    if _config is not None:
        return _config
    return config


# Database — schema
# ===========================================================================

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
    tg_id            INTEGER PRIMARY KEY,
    username         TEXT,
    first_name       TEXT,
    is_admin         INTEGER DEFAULT 0,
    created_at       TEXT NOT NULL DEFAULT (datetime('now')),
    last_active      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS user_settings (
    user_id          INTEGER PRIMARY KEY REFERENCES users(tg_id) ON DELETE CASCADE,
    preferred_quality TEXT NOT NULL DEFAULT '1080p',
    ai_model         TEXT NOT NULL DEFAULT 'gemini-2.5-flash',  -- v97.48: gemini-2.0-flash deprecated
    language         TEXT NOT NULL DEFAULT 'English',
    auto_delete      INTEGER NOT NULL DEFAULT 1,
    notifications    INTEGER NOT NULL DEFAULT 1,
    ai_mode          TEXT NOT NULL DEFAULT 'movie',
    gemini_api_key   TEXT,
    toolbox_audio_bitrate TEXT NOT NULL DEFAULT '192k',
    toolbox_video_crf INTEGER NOT NULL DEFAULT 28,
    updated_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tasks (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(tg_id) ON DELETE CASCADE,
    kind             TEXT NOT NULL,
    status           TEXT NOT NULL,
    progress         INTEGER NOT NULL DEFAULT 0,
    error            TEXT,
    created_at       TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS download_history (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(tg_id) ON DELETE CASCADE,
    task_id          INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
    file_name        TEXT NOT NULL,
    file_size        INTEGER NOT NULL DEFAULT 0,
    mime_type        TEXT,
    media_type       TEXT,
    source           TEXT NOT NULL,
    status           TEXT NOT NULL,
    file_unique_id   TEXT,
    message_link     TEXT,
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_dl_user ON download_history(user_id, created_at DESC);

-- v97.19: Media file_id cache — stores Telegram file references so repeat
-- requests for the same source media can be served instantly without
-- re-downloading and re-uploading.
CREATE TABLE IF NOT EXISTS media_cache (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    source_chat_id   TEXT NOT NULL,          -- original chat ref (@username or chat_id)
    source_message_id INTEGER NOT NULL,      -- original message ID
    file_id          TEXT NOT NULL,          -- Telegram file_id for instant resend
    file_unique_id   TEXT,                   -- Telegram file_unique_id (dedup key)
    file_name        TEXT,                   -- original filename
    file_size        INTEGER DEFAULT 0,      -- size in bytes
    media_type       TEXT,                   -- photo/video/document/audio/voice
    caption          TEXT,                   -- original caption (preserved)
    created_at       TEXT NOT NULL DEFAULT (datetime('now')),
    last_used_at     TEXT NOT NULL DEFAULT (datetime('now')),
    use_count        INTEGER NOT NULL DEFAULT 0,
    UNIQUE(source_chat_id, source_message_id)
);
CREATE INDEX IF NOT EXISTS idx_media_cache_lookup ON media_cache(source_chat_id, source_message_id);
CREATE INDEX IF NOT EXISTS idx_media_cache_lru ON media_cache(last_used_at);

CREATE TABLE IF NOT EXISTS ai_history (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(tg_id) ON DELETE CASCADE,
    task_id          INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
    file_name        TEXT NOT NULL,
    media_type       TEXT,
    category         TEXT,
    title            TEXT,
    season           TEXT,
    episode          TEXT,
    year             TEXT,
    language         TEXT,
    quality          TEXT,
    confidence       REAL,
    raw_json         TEXT,
    status           TEXT NOT NULL,
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ai_user ON ai_history(user_id, created_at DESC);

-- Saved / bookmarked media library
CREATE TABLE IF NOT EXISTS library (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(tg_id) ON DELETE CASCADE,
    file_name        TEXT NOT NULL,
    media_type       TEXT,
    file_size        INTEGER NOT NULL DEFAULT 0,
    file_id          TEXT,
    note             TEXT,
    tags             TEXT,
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_lib_user ON library(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_lib_name ON library(file_name);

-- Inspected chats / users (the "finder" history)
CREATE TABLE IF NOT EXISTS inspected_chats (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(tg_id) ON DELETE CASCADE,
    chat_id          INTEGER,
    username         TEXT,
    title            TEXT,
    chat_type        TEXT,
    members          INTEGER,
    description      TEXT,
    first_name       TEXT,
    last_name        TEXT,
    bio              TEXT,
    is_bot           INTEGER,
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_insp_user ON inspected_chats(user_id, created_at DESC);

-- Scheduled download queue
CREATE TABLE IF NOT EXISTS scheduled_tasks (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(tg_id) ON DELETE CASCADE,
    kind             TEXT NOT NULL,
    payload          TEXT NOT NULL,
    run_at           TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'pending',
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_sched_run ON scheduled_tasks(run_at, status);

-- Admin broadcasts
CREATE TABLE IF NOT EXISTS broadcasts (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id         INTEGER NOT NULL,
    text             TEXT NOT NULL,
    sent             INTEGER NOT NULL DEFAULT 0,
    failed           INTEGER NOT NULL DEFAULT 0,
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

-- VC Tour: discovered groups
CREATE TABLE IF NOT EXISTS vc_groups (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id         INTEGER NOT NULL UNIQUE,
    access_hash      INTEGER,
    title            TEXT,
    username         TEXT,
    public_link      TEXT,
    source           TEXT,                 -- dialog|explicit|config
    access_status    TEXT NOT NULL DEFAULT 'unknown', -- accessible|inaccessible|banned|restricted
    active_vc        INTEGER NOT NULL DEFAULT 0,
    discovered_at    TEXT NOT NULL DEFAULT (datetime('now')),
    last_checked_at  TEXT,
    last_seen_at     TEXT,                 -- last time this group was seen in discovery (stale-row reconciliation)
    last_joined_at   TEXT,
    last_error       TEXT
);
CREATE INDEX IF NOT EXISTS idx_vc_groups_active ON vc_groups(active_vc);

-- VC Tour: visit history
CREATE TABLE IF NOT EXISTS vc_visits (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id         INTEGER NOT NULL,
    group_title      TEXT,
    username         TEXT,
    group_link       TEXT,
    joined_at        TEXT,
    left_at          TEXT,
    planned_duration_seconds INTEGER,
    actual_duration_seconds  INTEGER,
    mode             TEXT,                 -- auto|manual
    status           TEXT,                 -- joined|completed|failed|disconnected
    leave_reason     TEXT,
    error            TEXT,
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_vc_visits_group ON vc_visits(group_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_vc_visits_recent ON vc_visits(created_at DESC);

-- VC Tour: persisted tour state (single row, id=1)
CREATE TABLE IF NOT EXISTS vc_tour_state (
    id               INTEGER PRIMARY KEY DEFAULT 1,
    running          INTEGER NOT NULL DEFAULT 0,
    paused           INTEGER NOT NULL DEFAULT 0,
    current_group_id INTEGER,
    current_queue_index INTEGER NOT NULL DEFAULT 0,
    queue_json       TEXT,
    started_at       TEXT,
    updated_at       TEXT NOT NULL DEFAULT (datetime('now')),
    stay_seconds     INTEGER NOT NULL DEFAULT 300,
    cooldown_seconds INTEGER NOT NULL DEFAULT 30
);
INSERT OR IGNORE INTO vc_tour_state (id, running, paused, stay_seconds, cooldown_seconds)
VALUES (1, 0, 0, 300, 30);

-- VC Tour: runtime settings (single row, id=1) — overrides env defaults
CREATE TABLE IF NOT EXISTS vc_settings (
    id                          INTEGER PRIMARY KEY DEFAULT 1,
    stay_seconds                INTEGER NOT NULL DEFAULT 300,
    cooldown_seconds            INTEGER NOT NULL DEFAULT 30,
    revisit_same_group          INTEGER NOT NULL DEFAULT 0,
    auto_resume_after_manual    INTEGER NOT NULL DEFAULT 1,
    join_notifications          INTEGER NOT NULL DEFAULT 1,
    leave_notifications         INTEGER NOT NULL DEFAULT 1,
    save_history                INTEGER NOT NULL DEFAULT 1,
    auto_start_vc               INTEGER NOT NULL DEFAULT 0,
    end_created_vc              INTEGER NOT NULL DEFAULT 0,
    discovery_enabled           INTEGER,  -- v97: NULL=use env default, 0=admin disabled, 1=admin enabled
    updated_at                  TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT OR IGNORE INTO vc_settings (id) VALUES (1);

-- ===========================================================================
-- Talkative Mode (Task ID 16) — conversational AI subsystem
-- ===========================================================================

-- Global Talkative settings (single row, id=1). Seed from env defaults.
CREATE TABLE IF NOT EXISTS talkative_global_settings (
    id                          INTEGER PRIMARY KEY DEFAULT 1,
    enabled                     INTEGER NOT NULL DEFAULT 0,
    provider                    TEXT NOT NULL DEFAULT 'groq',
    personality                 TEXT NOT NULL DEFAULT '',
    language_mode               TEXT NOT NULL DEFAULT 'auto',
    session_timeout_seconds     INTEGER NOT NULL DEFAULT 300,
    memory_turns                INTEGER NOT NULL DEFAULT 10,
    group_context_enabled       INTEGER NOT NULL DEFAULT 1,
    group_context_messages      INTEGER NOT NULL DEFAULT 8,
    cooldown_seconds            INTEGER NOT NULL DEFAULT 3,
    private_auto_reply          INTEGER NOT NULL DEFAULT 1,
    typing_enabled              INTEGER NOT NULL DEFAULT 1,
    updated_at                  TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT OR IGNORE INTO talkative_global_settings (
    id, enabled, provider, session_timeout_seconds, memory_turns,
    group_context_enabled, group_context_messages, cooldown_seconds,
    private_auto_reply, typing_enabled
) VALUES (
    1, 0, 'groq', 300, 10, 1, 8, 3, 1, 1
);

-- Per-chat overrides (NULLable everything except chat_id).
CREATE TABLE IF NOT EXISTS talkative_chat_settings (
    chat_id                     INTEGER PRIMARY KEY,
    enabled                     INTEGER,
    personality                 TEXT,
    language_mode               TEXT,
    session_timeout_seconds     INTEGER,
    memory_turns                INTEGER,
    group_context_enabled       INTEGER,
    cooldown_seconds            INTEGER,
    multimodal_enabled INTEGER NOT NULL DEFAULT 1,
    voice_reply_policy TEXT NOT NULL DEFAULT 'auto',  -- auto|never|always
    reaction_policy TEXT NOT NULL DEFAULT 'auto',     -- auto|never|always
    updated_at                  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Active Talkative sessions (one user per chat at a time).
CREATE TABLE IF NOT EXISTS talkative_sessions (
    chat_id                     INTEGER NOT NULL,
    user_id                     INTEGER NOT NULL,
    active                      INTEGER NOT NULL DEFAULT 1,
    started_at                  TEXT NOT NULL DEFAULT (datetime('now')),
    last_activity_at            TEXT NOT NULL DEFAULT (datetime('now')),
    expires_at                  TEXT NOT NULL,
    PRIMARY KEY (chat_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_talkative_sessions_active
    ON talkative_sessions(active, expires_at);

-- Conversation memory (per chat + user pair).
CREATE TABLE IF NOT EXISTS talkative_memory (
    id                          INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id                     INTEGER NOT NULL,
    user_id                     INTEGER NOT NULL,
    role                        TEXT NOT NULL,           -- 'user' | 'assistant' | 'system'
    content                     TEXT NOT NULL,
    created_at                  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_talkative_memory_chat_user
    ON talkative_memory(chat_id, user_id, created_at DESC);

-- Lightweight usage stats (for admin dashboard).
CREATE TABLE IF NOT EXISTS talkative_stats (
    id                          INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id                     INTEGER NOT NULL,
    user_id                     INTEGER NOT NULL,
    trigger_type                TEXT,                    -- reply|mention|name|wake|session|private
    provider                    TEXT,
    success                     INTEGER NOT NULL DEFAULT 0,
    created_at                  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_talkative_stats_created
    ON talkative_stats(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_talkative_stats_chat_user
    ON talkative_stats(chat_id, user_id, created_at DESC);

-- Wake words (chat_id NULL = global wake word).
-- DB-B-035/022: UNIQUE(chat_id, wake_word) + chat_id index for upsert + lookups.
CREATE TABLE IF NOT EXISTS talkative_wake_words (
    id                          INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id                     INTEGER,                 -- NULL = global
    wake_word                   TEXT NOT NULL,
    enabled                     INTEGER NOT NULL DEFAULT 1,
    created_at                  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(chat_id, wake_word)
);
CREATE INDEX IF NOT EXISTS idx_talkative_wake_words_chat
    ON talkative_wake_words(chat_id);

-- VC participations registry (Task ID 18 — evidence-based Multi-VC).
-- Tracks every chat where the userbot has an intentional or uncertain VC
-- participation.  This is the SOURCE OF TRUTH for multi-participation
-- tracking; the old single _current_chat_id field is preserved for the
-- sequential VC Tour's compatibility but is NOT the only tracked target.
CREATE TABLE IF NOT EXISTS vc_participations (
    chat_id                     INTEGER PRIMARY KEY,
    title                       TEXT,
    call_id                     INTEGER,
    access_hash                 INTEGER,
    state                       TEXT NOT NULL DEFAULT 'unknown',
    join_request_sent           INTEGER NOT NULL DEFAULT 0,
    request_accepted            INTEGER NOT NULL DEFAULT 0,
    local_transport_state       TEXT,    -- 'present' | 'absent' | 'unknown' | NULL
    telegram_participation      TEXT,    -- 'present' | 'absent' | 'unknown' | NULL
    locally_tracked             INTEGER NOT NULL DEFAULT 0,
    transport_controllable      INTEGER NOT NULL DEFAULT 0,
    intentional                 INTEGER NOT NULL DEFAULT 0,
    created_by_tour             INTEGER NOT NULL DEFAULT 0,
    cleanup_required            INTEGER NOT NULL DEFAULT 0,
    cleanup_outcome             TEXT,    -- 'success' | 'failed' | 'unknown' | NULL
    joined_at                   TEXT,
    last_verified_at            TEXT,
    last_leave_attempt_at       TEXT,
    last_error                  TEXT,
    updated_at                  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ===========================================================================
-- VC Group Discovery subsystem (broad public-search discovery)
-- ===========================================================================

-- Per-query persistent state (#20, #21): tracks last run, last success,
-- failures, FloodWait cooldown, and cumulative counters for each search
-- term so discovery progress survives process restarts.
CREATE TABLE IF NOT EXISTS vc_discovery_queries (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    query               TEXT NOT NULL UNIQUE,
    last_run_at         TEXT,
    last_success_at     TEXT,
    last_result_count   INTEGER NOT NULL DEFAULT 0,
    failure_count       INTEGER NOT NULL DEFAULT 0,
    floodwait_until     TEXT,
    last_error          TEXT,
    total_runs          INTEGER NOT NULL DEFAULT 0,
    total_results       INTEGER NOT NULL DEFAULT 0,
    first_seen_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_vc_discovery_queries_fw
    ON vc_discovery_queries(floodwait_until);

-- Discovery run history (#28, #21): one row per completed/aborted cycle.
CREATE TABLE IF NOT EXISTS vc_discovery_runs (
    id                          INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at                  TEXT NOT NULL,
    completed_at                TEXT,
    queries_run                 INTEGER NOT NULL DEFAULT 0,
    results_found               INTEGER NOT NULL DEFAULT 0,
    unique_groups               INTEGER NOT NULL DEFAULT 0,
    new_groups                  INTEGER NOT NULL DEFAULT 0,
    refreshed_groups            INTEGER NOT NULL DEFAULT 0,
    inaccessible_groups         INTEGER NOT NULL DEFAULT 0,
    active_vcs_found            INTEGER NOT NULL DEFAULT 0,
    auto_joins_attempted        INTEGER NOT NULL DEFAULT 0,
    auto_joins_confirmed        INTEGER NOT NULL DEFAULT 0,
    auto_joins_failed           INTEGER NOT NULL DEFAULT 0,
    deferred_targets            INTEGER NOT NULL DEFAULT 0,
    floodwait_count             INTEGER NOT NULL DEFAULT 0,
    errors                      INTEGER NOT NULL DEFAULT 0,
    complete                    INTEGER NOT NULL DEFAULT 0,
    cancelled                   INTEGER NOT NULL DEFAULT 0,
    floodwait_interrupted       INTEGER NOT NULL DEFAULT 0,
    last_query                  TEXT,
    last_error                  TEXT
);
CREATE INDEX IF NOT EXISTS idx_vc_discovery_runs_started
    ON vc_discovery_runs(started_at);

-- Per-target discovery cooldown (#19, #38): avoids repeatedly rechecking
-- the same dead/private/banned/inaccessible target too frequently.  This
-- is distinct from the in-memory _vc_target_cooldowns (join-failure
-- cooldown) — this one is about *discovery* re-scan frequency.
CREATE TABLE IF NOT EXISTS vc_discovery_cooldowns (
    group_id        INTEGER PRIMARY KEY,
    cooldown_until  TEXT NOT NULL,
    reason          TEXT,
    failure_count   INTEGER NOT NULL DEFAULT 0,
    last_checked_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_vc_discovery_cooldowns_until
    ON vc_discovery_cooldowns(cooldown_until);

-- ===========================================================================
-- Adaptive Autonomous Discovery Engine
-- ===========================================================================

-- Autonomous queries: learned from discovered group metadata, scored by
-- yield, retired when consistently unproductive.  Persists across restarts.
CREATE TABLE IF NOT EXISTS vc_autonomous_queries (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    query               TEXT NOT NULL UNIQUE,
    score               REAL NOT NULL DEFAULT 0,
    runs                INTEGER NOT NULL DEFAULT 0,
    unique_groups       INTEGER NOT NULL DEFAULT 0,
    zero_result_runs    INTEGER NOT NULL DEFAULT 0,
    consecutive_zeros   INTEGER NOT NULL DEFAULT 0,
    last_run_at         TEXT,
    last_success_at     TEXT,
    source_query        TEXT,          -- the query that discovered the metadata this was learned from
    source_group_id     INTEGER,       -- the group whose metadata produced this query
    retired             INTEGER NOT NULL DEFAULT 0,
    first_seen_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_vc_autonomous_queries_score
    ON vc_autonomous_queries(retired, score DESC);

-- Discovery results: unique discovered groups with verified public links,
-- discovery query provenance, and active-VC status.  One row per unique
-- group ID — even if discovered by multiple queries, only the first
-- discovery is stored (provenance is tracked in vc_discovery_provenance).
CREATE TABLE IF NOT EXISTS vc_discovery_results (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id            INTEGER NOT NULL UNIQUE,
    title               TEXT,
    username            TEXT,
    public_link         TEXT,          -- only from verified username; NULL if no public username
    discovery_query     TEXT,
    discovery_source    TEXT,          -- builtin_default|env|dashboard_manual|autonomous
    active_vc           INTEGER NOT NULL DEFAULT 0,
    status              TEXT NOT NULL DEFAULT 'new',  -- new|known|refreshed
    discovered_at       TEXT NOT NULL DEFAULT (datetime('now')),
    last_checked_at     TEXT
);
CREATE INDEX IF NOT EXISTS idx_vc_discovery_results_active
    ON vc_discovery_results(active_vc DESC, discovered_at DESC);

-- Discovery provenance: records every query that found the same group,
-- so the system can track multi-query discovery without duplicating the
-- displayed group in vc_discovery_results.
CREATE TABLE IF NOT EXISTS vc_discovery_provenance (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id            INTEGER NOT NULL,
    query               TEXT NOT NULL,
    source              TEXT NOT NULL,
    discovered_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_vc_discovery_provenance_gid
    ON vc_discovery_provenance(group_id);

-- ===========================================================================
-- V86 — Independent Discovery Module: History + Saved Results
-- ===========================================================================

-- Discovery History: one row per search execution (any type).
CREATE TABLE IF NOT EXISTS discovery_history (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    search_type     TEXT NOT NULL,           -- groups | channels | users | voice_chats | global
    query           TEXT NOT NULL,
    normalized_query TEXT,
    account_used    TEXT,                    -- account_id or "legacy"
    results_found   INTEGER NOT NULL DEFAULT 0,
    groups_found    INTEGER NOT NULL DEFAULT 0,
    channels_found  INTEGER NOT NULL DEFAULT 0,
    duration_ms     INTEGER NOT NULL DEFAULT 0,
    success         INTEGER NOT NULL DEFAULT 0,  -- 0 = failed, 1 = success
    reason          TEXT,                    -- failure reason (if any)
    searched_at     TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_discovery_history_time
    ON discovery_history(searched_at);
CREATE INDEX IF NOT EXISTS idx_discovery_history_type
    ON discovery_history(search_type);

-- Discovery Saved Results: user-saved entities for later use.
CREATE TABLE IF NOT EXISTS discovery_saved (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_type     TEXT NOT NULL,           -- group | channel | user | voice_chat
    entity_id       INTEGER NOT NULL,
    access_hash     TEXT,                    -- stored as string (consistent with vc_access_hashes)
    title           TEXT,
    username        TEXT,
    public_link     TEXT,
    saved_by        INTEGER,                 -- admin user_id who saved it
    saved_at        TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(entity_type, entity_id)
);
CREATE INDEX IF NOT EXISTS idx_discovery_saved_type
    ON discovery_saved(entity_type);

-- ===========================================================================
-- Context-Aware Sticker, GIF & Media Reaction Engine
-- ===========================================================================

-- Curated admin-approved media library (stickers, GIFs, animations).
-- Tags enable intent-based selection: laugh, congrats, wow, sad, hello, etc.
-- file_id is the Telegram file identifier for efficient resend.
CREATE TABLE IF NOT EXISTS talkative_media_library (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    media_type      TEXT NOT NULL,           -- sticker | gif | animation
    file_id         TEXT NOT NULL,           -- Telegram file_id for resend
    tags            TEXT NOT NULL DEFAULT '', -- comma-separated: laugh,congrats,wow
    description     TEXT,                    -- human-readable description
    approved        INTEGER NOT NULL DEFAULT 1,
    blocked         INTEGER NOT NULL DEFAULT 0,
    use_count       INTEGER NOT NULL DEFAULT 0,
    positive_signals INTEGER NOT NULL DEFAULT 0,
    negative_signals INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_talkative_media_tags
    ON talkative_media_library(tags);

-- Per-group media preferences (learned safe preferences).
CREATE TABLE IF NOT EXISTS talkative_media_prefs (
    chat_id             INTEGER PRIMARY KEY,
    media_enabled       INTEGER NOT NULL DEFAULT 1,
    sticker_frequency   REAL NOT NULL DEFAULT 0.3,  -- 0.0-1.0 probability
    gif_frequency       REAL NOT NULL DEFAULT 0.2,
    last_media_at       TEXT,
    consecutive_media   INTEGER NOT NULL DEFAULT 0,
    updated_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Per-group recent media history (for duplicate suppression).
CREATE TABLE IF NOT EXISTS talkative_media_history (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id         INTEGER NOT NULL,
    media_id        INTEGER NOT NULL,
    media_type      TEXT NOT NULL,
    file_id         TEXT NOT NULL,
    tags            TEXT,
    sent_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_talkative_media_history_chat
    ON talkative_media_history(chat_id, sent_at DESC);

-- ===========================================================================
-- Join All Active VC — checkpoint persistence (v97 production redesign)
-- ===========================================================================
-- One row per Join-All run. The worker writes a checkpoint after every
-- target so a crash or restart never loses more than the in-flight target.
CREATE TABLE IF NOT EXISTS vc_join_all_runs (
    run_id              TEXT PRIMARY KEY,
    started_at          TEXT NOT NULL,
    updated_at          TEXT NOT NULL,
    completed_at        TEXT,
    state               TEXT NOT NULL DEFAULT 'discovering',
    terminal_status     TEXT NOT NULL DEFAULT '',
    cancel_reason       TEXT NOT NULL DEFAULT '',
    last_error          TEXT NOT NULL DEFAULT '',
    total_targets       INTEGER NOT NULL DEFAULT 0,
    processed           INTEGER NOT NULL DEFAULT 0,
    current_index       INTEGER NOT NULL DEFAULT 0,
    joined_confirmed    INTEGER NOT NULL DEFAULT 0,
    already_joined      INTEGER NOT NULL DEFAULT 0,
    confirmation_unknown INTEGER NOT NULL DEFAULT 0,
    confirmed_not_joined INTEGER NOT NULL DEFAULT 0,
    skipped_call_ended  INTEGER NOT NULL DEFAULT 0,
    skipped_in_flight   INTEGER NOT NULL DEFAULT 0,
    failed              INTEGER NOT NULL DEFAULT 0,
    deferred            INTEGER NOT NULL DEFAULT 0,
    floodwait_count     INTEGER NOT NULL DEFAULT 0,
    targets_json        TEXT NOT NULL DEFAULT '[]',
    results_json        TEXT NOT NULL DEFAULT '{}',
    discovery_json      TEXT NOT NULL DEFAULT '{}',
    breaker_json        TEXT NOT NULL DEFAULT '{}',
    -- v99.11 P1 (durable checkpointing + crash-loop forensics):
    pid                 INTEGER NOT NULL DEFAULT 0,
    resume_attempts     INTEGER NOT NULL DEFAULT 0,
    resource_json       TEXT NOT NULL DEFAULT '{}',
    last_successful_target TEXT NOT NULL DEFAULT '',
    last_failed_target     TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_vc_join_all_runs_started
    ON vc_join_all_runs(started_at DESC);
CREATE INDEX IF NOT EXISTS idx_vc_join_all_runs_terminal
    ON vc_join_all_runs(terminal_status, started_at DESC);
"""

MIGRATION_SQL = [
    "ALTER TABLE user_settings ADD COLUMN ai_mode TEXT NOT NULL DEFAULT 'movie'",
    "ALTER TABLE user_settings ADD COLUMN gemini_api_key TEXT",
    "ALTER TABLE user_settings ADD COLUMN toolbox_audio_bitrate TEXT NOT NULL DEFAULT '192k'",
    "ALTER TABLE user_settings ADD COLUMN toolbox_video_crf INTEGER NOT NULL DEFAULT 28",
    "ALTER TABLE vc_settings ADD COLUMN auto_start_vc INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE vc_settings ADD COLUMN end_created_vc INTEGER NOT NULL DEFAULT 0",
    # Task ID 2 (Phase 11) — vc_participations: add the 4 spec-required fields
    # that were missing from the original schema.  Idempotent: _run_migrations
    # checks _column_exists before applying each ALTER.
    "ALTER TABLE vc_participations ADD COLUMN join_request_sent INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE vc_participations ADD COLUMN local_transport_state TEXT",
    "ALTER TABLE vc_participations ADD COLUMN intentional INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE vc_participations ADD COLUMN created_by_tour INTEGER NOT NULL DEFAULT 0",
    # Issue 13: last_seen_at for stale-row reconciliation.
    "ALTER TABLE vc_groups ADD COLUMN last_seen_at TEXT",
    # Feature B #52-#65: per-query enabled/disabled, priority, source
    # metadata, extended metrics, consecutive-failure, next-eligible, notes.
    # Additive only — idempotent via _column_exists check.
    "ALTER TABLE vc_discovery_queries ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE vc_discovery_queries ADD COLUMN priority INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE vc_discovery_queries ADD COLUMN source TEXT NOT NULL DEFAULT 'dashboard_manual'",
    "ALTER TABLE vc_discovery_queries ADD COLUMN unique_groups INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE vc_discovery_queries ADD COLUMN new_groups INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE vc_discovery_queries ADD COLUMN active_vcs_found INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE vc_discovery_queries ADD COLUMN consecutive_failures INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE vc_discovery_queries ADD COLUMN next_eligible_at TEXT",
    "ALTER TABLE vc_discovery_queries ADD COLUMN notes TEXT",
    # #9: unique index on vc_discovery_provenance to prevent duplicate rows.
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_vc_discovery_provenance_unique "
    "ON vc_discovery_provenance(group_id, query, source)",
    # --- Adaptive Multimodal Talkative Engine ---
    # Per-group mode: off / chat / vc / both (NULL = inherit global default).
    "ALTER TABLE talkative_chat_settings ADD COLUMN talkative_mode TEXT",
    # Global default mode.
    "ALTER TABLE talkative_global_settings ADD COLUMN talkative_mode TEXT NOT NULL DEFAULT 'off'",
    # Memory importance scoring (0.0-1.0; higher = more important).
    "ALTER TABLE talkative_memory ADD COLUMN importance REAL NOT NULL DEFAULT 0.5",
    "ALTER TABLE talkative_memory ADD COLUMN ttl_expires_at TEXT",
    # Compact conversation summary (replaces old raw turns when token limit approached).
    "ALTER TABLE talkative_memory ADD COLUMN is_summary INTEGER NOT NULL DEFAULT 0",
    # V52 Multimodal & Voice subsystem columns.
    "ALTER TABLE talkative_global_settings ADD COLUMN multimodal_enabled INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN voice_understand INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN voice_replies INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN match_reply_type INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN voice_clone_enabled INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN clone_for_voice_msgs INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN clone_voice_in_vc INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN use_voice_everywhere INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN standard_tts_fallback INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN sticker_replies INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN context_stickers INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN gif_replies INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN native_reactions INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN image_understanding INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN gif_understanding INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN sticker_understanding INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN media_dedup INTEGER",
    "ALTER TABLE talkative_global_settings ADD COLUMN voice_reply_policy TEXT",
    # V59 Fix #4: voice profile persistence table.
    """CREATE TABLE IF NOT EXISTS voice_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        owner_user_id INTEGER NOT NULL,
        provider TEXT NOT NULL,
        provider_profile_id TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'enrolled',
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        last_tested_at TEXT,
        last_test_result TEXT
    )""",
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_voice_profiles_owner ON voice_profiles(owner_user_id)",
    # --- v99.11 P1: Join-All durable checkpointing + crash-loop forensics ---
    # pid + resource_json: post-mortem proof of the resource state at every
    # checkpoint (the OOM approach is now visible even if the heartbeat
    # line never landed).  resume_attempts: the durable crash-loop counter
    # the startup guard couples backoff + admission reduction to.
    # last_successful/last_failed target: the exact boundary for
    # "repeated failures near the same index" correlation.
    # Idempotent via _column_exists.
    "ALTER TABLE vc_join_all_runs ADD COLUMN pid INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE vc_join_all_runs ADD COLUMN resume_attempts INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE vc_join_all_runs ADD COLUMN resource_json TEXT NOT NULL DEFAULT '{}'",
    "ALTER TABLE vc_join_all_runs ADD COLUMN last_successful_target TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE vc_join_all_runs ADD COLUMN last_failed_target TEXT NOT NULL DEFAULT ''",
    # DB-B-035: enforce UNIQUE(chat_id, wake_word) on existing installs whose
    # schema predates the constraint.  The migration runner deduplicates
    # existing rows before creating the unique index, so this is safe.
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_talkative_wake_words_unique "
    "ON talkative_wake_words(chat_id, wake_word)",
    # DB-B-022: chat_id index for wake-word lookups.
    "CREATE INDEX IF NOT EXISTS idx_talkative_wake_words_chat "
    "ON talkative_wake_words(chat_id)",
    # DB-B-023: stats lookup index.
    "CREATE INDEX IF NOT EXISTS idx_talkative_stats_chat_user "
    "ON talkative_stats(chat_id, user_id, created_at DESC)",
    # --- V86 multimodal: per-chat multimodal settings ---
    # Idempotent: _run_migrations checks _column_exists before applying each ALTER.
    "ALTER TABLE talkative_chat_settings ADD COLUMN multimodal_enabled INTEGER NOT NULL DEFAULT 1",
    "ALTER TABLE talkative_chat_settings ADD COLUMN voice_reply_policy TEXT NOT NULL DEFAULT 'auto'",
    "ALTER TABLE talkative_chat_settings ADD COLUMN reaction_policy TEXT NOT NULL DEFAULT 'auto'",
    # v97: DB-backed Auto Discovery runtime enable/disable.
    # NULL = use .env default (bootstrap); 0 = admin disabled; 1 = admin enabled.
    "ALTER TABLE vc_settings ADD COLUMN discovery_enabled INTEGER",
    # v97.1 MULTI-ACCOUNT: DB-backed VC Join Mode.
    # NULL/'primary' = single primary account (existing behavior, default).
    # 'distributed' = distribute active VCs across ALL healthy linked accounts.
    "ALTER TABLE vc_settings ADD COLUMN vc_join_mode TEXT",
    # v97.1 MULTI-ACCOUNT: record which account joined which VC.
    # NULL = unknown / primary-mode (backwards compatible).
    "ALTER TABLE vc_participations ADD COLUMN account_id TEXT",
    # v98.09-P3 §7/§19 — VC Knowledge Cache columns (idempotent ALTERs,
    # additive only; existing installations migrate transparently and old
    # rows simply read as "no cached call identity / never seen active").
    # last_active_vc_at: epoch-seconds timestamp of the LAST Tier-2
    #   verification that found an ACTIVE call (drives the short active-TTL
    #   freshness window; "active state changes quickly").
    # call_id / call_access_hash: the verified group-call identity from that
    #   verification — handed to Join-All so a fresh cache hit can skip the
    #   duplicate detection RPC (§9/§16) and go straight to the join attempt.
    "ALTER TABLE vc_groups ADD COLUMN last_active_vc_at REAL",
    "ALTER TABLE vc_groups ADD COLUMN call_id INTEGER",
    "ALTER TABLE vc_groups ADD COLUMN call_access_hash INTEGER",
    # v98.09-P3 §23: knowledge-cache fast lookup index (active + freshness).
    "CREATE INDEX IF NOT EXISTS idx_vc_groups_active_fresh "
    "ON vc_groups(active_vc, last_active_vc_at DESC)",
]


# ===========================================================================
# Database — connection
# ===========================================================================

_db: aiosqlite.Connection | None = None
# DB-B-002: serialise init_db() across concurrent coroutines so the
# connection is created exactly once even under race conditions.
_db_lock: asyncio.Lock | None = None

# v99.11 P1 — write-serialization lock: multi-statement write scopes
# (join-all checkpoints, batch writers) acquire this so their
# UPDATE+commit pairs cannot interleave on the single shared aiosqlite
# connection. Single-statement writers keep their existing autocommit
# pattern (SQLite serializes individual statements); this lock makes
# COMMIT BOUNDARIES deterministic for scoped writers.
_db_write_lock: asyncio.Lock | None = None


def _get_write_lock() -> asyncio.Lock:
    """Lazily create the write-serialization lock (event-loop safe)."""
    global _db_write_lock
    if _db_write_lock is None:
        _db_write_lock = asyncio.Lock()
    return _db_write_lock


class _DbWriteLockScope:
    """Async context manager: ACQUIRES the shared write-serialization
    lock for the whole block (async with db_write_lock(): ...)."""

    async def __aenter__(self) -> asyncio.Lock:
        lock = _get_write_lock()
        await lock.acquire()
        return lock

    async def __aexit__(self, exc_type, exc, tb) -> None:
        try:
            _get_write_lock().release()
        except RuntimeError:
            pass
        return None


def db_write_lock() -> "_DbWriteLockScope":
    """v99.11: async-with scope yielding the shared write-serialization
    lock — usage: ``async with db_write_lock(): ...`` (the lock is held
    for the whole block)."""
    return _DbWriteLockScope()


async def _column_exists(db, table: str, column: str) -> bool:
    async with db.execute(f"PRAGMA table_info({table})") as cur:
        rows = await cur.fetchall()
    return any(row[1] == column for row in rows)


async def _index_exists(db, index_name: str) -> bool:
    """Check if a SQLite index exists by name."""
    async with db.execute(
        "SELECT 1 FROM sqlite_master WHERE type='index' AND name=?",
        (index_name,),
    ) as cur:
        return await cur.fetchone() is not None


async def _run_migrations(db) -> None:
    """Execute migration SQL statements (idempotent).

    Handles TWO types of statements:
    1. ``ALTER TABLE <tbl> ADD COLUMN <col>`` — skipped if column already exists.
    2. ``CREATE UNIQUE INDEX IF NOT EXISTS ...`` — executed directly (idempotent
       via IF NOT EXISTS), but deduplicates existing rows FIRST to avoid
       uniqueness-violation errors.
    3. ``CREATE INDEX IF NOT EXISTS ...`` — executed directly (idempotent).

    #8/#91 fix: the previous runner ONLY processed ALTER TABLE ... ADD COLUMN
    statements (regex match), silently skipping all non-ALTER SQL.  This meant
    the ``CREATE UNIQUE INDEX`` migration for vc_discovery_provenance was never
    executed, and duplicate provenance rows could accumulate.  Now non-ALTER
    statements are executed with proper idempotency checks.

    #93 fix: distinguishes benign "duplicate column" errors from fatal
    migration errors.  Only swallows the expected "duplicate column name"
    exception; all other exceptions are logged at WARNING level.
    """
    for stmt in MIGRATION_SQL:
        stmt_stripped = stmt.strip()
        if not stmt_stripped:
            continue
        # Type 1: ALTER TABLE ... ADD COLUMN
        m = re.search(
            r"ALTER\s+TABLE\s+(\w+)\s+ADD\s+COLUMN\s+(\w+)",
            stmt_stripped,
            re.IGNORECASE,
        )
        if m:
            tbl = m.group(1)
            col = m.group(2)
            if not await _column_exists(db, tbl, col):
                try:
                    await db.execute(stmt)
                    logger.info("Migration: added column %s to %s", col, tbl)
                except Exception as exc:  # noqa: BLE001
                    exc_str = str(exc).lower()
                    if "duplicate column" in exc_str:
                        logger.debug("Migration skipped (%s.%s already exists)", tbl, col)
                    else:
                        # #93: non-benign migration error — log at WARNING.
                        logger.warning("Migration FAILED for %s.%s: %s", tbl, col, exc)
            continue
        # Type 2: CREATE [UNIQUE] INDEX IF NOT EXISTS ...
        if re.match(r"CREATE\s+(UNIQUE\s+)?INDEX\s+IF\s+NOT\s+EXISTS", stmt_stripped, re.IGNORECASE):
            # Extract index name for dedup check.
            idx_m = re.search(r"INDEX\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)", stmt_stripped, re.IGNORECASE)
            idx_name = idx_m.group(1) if idx_m else ""
            if idx_name and await _index_exists(db, idx_name):
                continue  # already created
            # #91: for UNIQUE indexes, deduplicate existing rows first.
            if re.match(r"CREATE\s+UNIQUE\s+INDEX", stmt_stripped, re.IGNORECASE):
                # Extract table + column info from the index definition.
                tbl_m = re.search(r"ON\s+(\w+)\s*\(([^)]+)\)", stmt_stripped, re.IGNORECASE)
                if tbl_m:
                    tbl_name = tbl_m.group(1)
                    cols_raw = tbl_m.group(2)
                    cols = [c.strip() for c in cols_raw.split(",")]
                    # Delete duplicate rows keeping the one with the lowest rowid.
                    cols_list = ", ".join(cols)
                    try:
                        await db.execute(
                            f"DELETE FROM {tbl_name} WHERE rowid NOT IN ("
                            f"  SELECT MIN(rowid) FROM {tbl_name} GROUP BY {cols_list}"
                            f")"
                        )
                        logger.info("Migration: deduplicated %s on (%s) before unique index", tbl_name, cols_list)
                    except Exception as exc:  # noqa: BLE001
                        logger.debug("Migration dedup skipped for %s: %s", tbl_name, exc)
            try:
                await db.execute(stmt)
                logger.info("Migration: created index %s", idx_name or "(unnamed)")
            except Exception as exc:  # noqa: BLE001
                logger.warning("Migration FAILED for index %s: %s", idx_name, exc)
            continue
        # Type 3: any other SQL — execute directly with error logging.
        # DB-B-018: surface non-ALTER migration failures at WARNING (not DEBUG)
        # so silent schema drift does not go unnoticed.
        try:
            await db.execute(stmt)
            logger.info("Migration: executed non-ALTER statement")
        except Exception as exc:  # noqa: BLE001
            logger.warning("Migration FAILED for non-ALTER statement: %s", exc)
    await db.commit()


async def init_db() -> aiosqlite.Connection:
    """Initialise the database connection and create tables."""
    global _db, _db_lock
    if _db is not None:
        return _db
    # DB-B-002: serialise the connection bootstrap to prevent two concurrent
    # callers from each opening their own aiosqlite connection (which would
    # leave one orphaned and bypass the shared PRAGMAs).
    if _db_lock is None:
        _db_lock = asyncio.Lock()
    async with _db_lock:
        # Double-check inside the lock — another coroutine may have finished
        # initialising while we were waiting.
        if _db is not None:
            return _db
        # v99.07 FIX-9: _config may be None (no _set_config caller ran) —
        # _effective_config() falls back to the module-level config import.
        _db_cfg = _effective_config()
        _db_cfg.db_path.parent.mkdir(parents=True, exist_ok=True)
        _db = await aiosqlite.connect(str(_db_cfg.db_path))
        _db.row_factory = aiosqlite.Row
        await _db.execute("PRAGMA journal_mode=WAL;")
        await _db.execute("PRAGMA synchronous=NORMAL;")
        await _db.execute("PRAGMA foreign_keys=ON;")
        # DB-B-003: wait up to 5s for a writer lock instead of raising
        # SQLITE_BUSY immediately under contention.
        await _db.execute("PRAGMA busy_timeout=5000;")
        # v99.11 P1: explicit WAL auto-checkpoint (1000 pages — SQLite's
        # default, made deliberate here): documents that passive
        # auto-checkpointing at commit is the intended steady-state WAL
        # bound; the periodic TRUNCATE checkpoint in utils_real now runs
        # on a DEDICATED connection (the shared-connection checkpoint
        # self-locked with SQLITE_LOCKED "database table is locked" —
        # busy_timeout cannot resolve a self-lock).
        await _db.execute("PRAGMA wal_autocheckpoint=1000;")
        # DB-B-025: performance PRAGMAs — 64MB page cache, in-memory temp
        # store, and 256MB memory-mapped I/O window.
        await _db.execute("PRAGMA cache_size=-65536;")
        await _db.execute("PRAGMA temp_store=MEMORY;")
        await _db.execute("PRAGMA mmap_size=268435456;")
        await _db.executescript(SCHEMA_SQL)
        await _run_migrations(_db)
        await _db.commit()
        logger.info("Database ready at %s", _effective_config().db_path)
        return _db


async def get_db() -> aiosqlite.Connection:
    if _db is None:
        return await init_db()
    return _db


async def close_db() -> None:
    """Close the shared DB connection. DB-B-028: tolerate close() failures so
    the global is always reset and the bot can shut down cleanly."""
    global _db
    if _db is not None:
        conn = _db
        try:
            await conn.close()
        except Exception as exc:  # noqa: BLE001
            logger.error("Error closing database connection: %s", exc)
        finally:
            _db = None
            logger.info("Database connection closed")


# ===========================================================================
# Database — repositories
# ===========================================================================


async def upsert_user(tg_id: int, username: str | None, first_name: str | None,
                      is_admin: bool = False) -> None:
    db = await get_db()
    await db.execute(
        """
        INSERT INTO users (tg_id, username, first_name, is_admin, last_active)
        VALUES (?, ?, ?, ?, datetime('now'))
        ON CONFLICT(tg_id) DO UPDATE SET
            username = excluded.username,
            first_name = excluded.first_name,
            is_admin = excluded.is_admin,
            last_active = datetime('now')
        """,
        (tg_id, username, first_name, 1 if is_admin else 0),
    )
    await db.commit()


async def ensure_settings(tg_id: int) -> dict[str, Any]:
    """Create default settings row if missing and return current settings."""
    db = await get_db()
    await db.execute(
        """
        INSERT OR IGNORE INTO user_settings
            (user_id, preferred_quality, ai_model, language, auto_delete, notifications)
        VALUES (?, ?, ?, ?, 1, 1)
        """,
        (tg_id, config.default_quality, config.default_ai_model, config.default_language),
    )
    await db.commit()
    async with db.execute(
        "SELECT * FROM user_settings WHERE user_id = ?", (tg_id,)
    ) as cur:
        row = await cur.fetchone()
    return dict(row) if row else {}


async def update_setting(tg_id: int, column: str, value: Any) -> dict[str, Any]:
    """Update a single settings column safely and return the new row."""
    allowed = {
        "preferred_quality", "ai_model", "language",
        "auto_delete", "notifications",
        "ai_mode", "gemini_api_key",
        "toolbox_audio_bitrate", "toolbox_video_crf",
    }
    if column not in allowed:
        raise ValueError(f"Cannot update unknown setting: {column}")
    await ensure_settings(tg_id)
    db = await get_db()
    await db.execute(
        f"UPDATE user_settings SET {column} = ?, updated_at = datetime('now') "
        f"WHERE user_id = ?",
        (value, tg_id),
    )
    await db.commit()
    return await ensure_settings(tg_id)


async def create_task(user_id: int, kind: str, status: str = "pending") -> int:
    db = await get_db()
    cur = await db.execute(
        "INSERT INTO tasks (user_id, kind, status) VALUES (?, ?, ?)",
        (user_id, kind, status),
    )
    await db.commit()
    return cur.lastrowid  # type: ignore[return-value]


_TASK_COLUMNS = {"status", "progress", "error", "kind"}


async def update_task(task_id: int, **fields: Any) -> None:
    if not fields:
        return
    # SEC-B-002 / DB-B-004: column whitelist — reject unknown keys so a caller
    # cannot inject arbitrary column names into the UPDATE via **fields.
    unknown = set(fields) - _TASK_COLUMNS
    if unknown:
        raise ValueError(f"update_task: unknown column(s): {sorted(unknown)}")
    cols = ", ".join(f"{k} = ?" for k in fields)
    values: list[Any] = list(fields.values())
    values.append(task_id)
    db = await get_db()
    await db.execute(
        f"UPDATE tasks SET {cols}, updated_at = datetime('now') WHERE id = ?",
        values,
    )
    await db.commit()


async def add_download_history(
    user_id: int, *, file_name: str, file_size: int, mime_type: str | None,
    media_type: str | None, source: str, status: str,
    task_id: int | None = None, file_unique_id: str | None = None,
    message_link: str | None = None,
) -> int:
    db = await get_db()
    cur = await db.execute(
        """
        INSERT INTO download_history
            (user_id, task_id, file_name, file_size, mime_type, media_type,
             source, status, file_unique_id, message_link)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (user_id, task_id, file_name, file_size, mime_type, media_type,
         source, status, file_unique_id, message_link),
    )
    await db.commit()
    return cur.lastrowid  # type: ignore[return-value]


async def recent_downloads(user_id: int, limit: int = 10) -> list[dict[str, Any]]:
    db = await get_db()
    async with db.execute(
        """
        SELECT file_name, file_size, media_type, source, status, created_at
        FROM download_history
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT ?
        """,
        (user_id, limit),
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# v97.19: Media file_id cache — the biggest speed improvement for repeat
# requests.  After the first download+upload, the Telegram file_id is cached.
# Subsequent requests for the same source media use sendDocument(file_id)
# instead of re-downloading and re-uploading — effectively instant delivery.
# ---------------------------------------------------------------------------

async def media_cache_lookup(source_chat_id: str, source_message_id: int) -> dict[str, Any] | None:
    """Look up a cached file_id by source chat + message ID.

    Returns a dict with file_id, file_name, file_size, media_type, caption,
    or None if not cached.
    """
    db = await get_db()
    async with db.execute(
        """SELECT file_id, file_unique_id, file_name, file_size, media_type, caption
           FROM media_cache
           WHERE source_chat_id = ? AND source_message_id = ?
           LIMIT 1""",
        (str(source_chat_id), int(source_message_id)),
    ) as cur:
        row = await cur.fetchone()
    if row is None:
        return None
    # Update last_used_at + use_count (fire-and-forget, non-blocking).
    try:
        await db.execute(
            "UPDATE media_cache SET last_used_at = datetime('now'), use_count = use_count + 1 "
            "WHERE source_chat_id = ? AND source_message_id = ?",
            (str(source_chat_id), int(source_message_id)),
        )
        await db.commit()
    except Exception:  # noqa: BLE001
        pass
    return dict(row)


async def media_cache_store(
    source_chat_id: str, source_message_id: int, *,
    file_id: str, file_unique_id: str | None = None,
    file_name: str | None = None, file_size: int = 0,
    media_type: str | None = None, caption: str | None = None,
) -> None:
    """Store a file_id in the media cache for instant resend on repeat requests."""
    db = await get_db()
    try:
        await db.execute(
            """INSERT OR REPLACE INTO media_cache
               (source_chat_id, source_message_id, file_id, file_unique_id,
                file_name, file_size, media_type, caption, created_at, last_used_at, use_count)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'), 0)""",
            (str(source_chat_id), int(source_message_id), file_id,
             file_unique_id, file_name, file_size, media_type, caption),
        )
        await db.commit()
    except Exception:  # noqa: BLE001
        pass


async def media_cache_cleanup(max_entries: int = 500) -> int:
    """LRU cleanup — remove oldest entries beyond max_entries.

    Returns the number of entries removed.
    """
    db = await get_db()
    cur = await db.execute(
        "DELETE FROM media_cache WHERE id NOT IN "
        "(SELECT id FROM media_cache ORDER BY last_used_at DESC LIMIT ?)",
        (max_entries,),
    )
    await db.commit()
    return cur.rowcount  # type: ignore[return-value]


async def add_ai_history(
    user_id: int, *, file_name: str, media_type: str | None,
    result: dict[str, Any] | None, status: str,
    task_id: int | None = None,
) -> int:
    db = await get_db()
    cur = await db.execute(
        """
        INSERT INTO ai_history
            (user_id, task_id, file_name, media_type, category, title,
             season, episode, year, language, quality, confidence, raw_json, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            user_id, task_id, file_name, media_type,
            (result or {}).get("category"),
            (result or {}).get("title"),
            (result or {}).get("season"),
            (result or {}).get("episode"),
            (result or {}).get("year"),
            (result or {}).get("language"),
            (result or {}).get("quality"),
            (result or {}).get("confidence"),
            json.dumps(result) if result else None,
            status,
        ),
    )
    await db.commit()
    return cur.lastrowid  # type: ignore[return-value]


async def recent_ai_analyses(user_id: int, limit: int = 10) -> list[dict[str, Any]]:
    db = await get_db()
    async with db.execute(
        """
        SELECT file_name, media_type, category, title, season, episode, year,
               language, confidence, status, created_at
        FROM ai_history
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT ?
        """,
        (user_id, limit),
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def clear_history(user_id: int, kind: str | None = None) -> int:
    """Delete history rows for a user. kind: 'download'|'ai'|None (both)."""
    db = await get_db()
    count = 0
    # DB-B-001: wrap the multi-statement DELETE pair in a single transaction
    # with explicit rollback so a failure on the second DELETE doesn't leave
    # the DB in a half-deleted state.
    try:
        if kind in (None, "download"):
            cur = await db.execute(
                "DELETE FROM download_history WHERE user_id = ?", (user_id,)
            )
            count += cur.rowcount or 0
        if kind in (None, "ai"):
            cur = await db.execute(
                "DELETE FROM ai_history WHERE user_id = ?", (user_id,)
            )
            count += cur.rowcount or 0
        await db.commit()
    except Exception:
        await db.rollback()
        raise
    logger.info("Cleared %d history rows for user %s (kind=%s)", count, user_id, kind)
    return count


async def stats() -> dict[str, int]:
    db = await get_db()
    out: dict[str, int] = {}
    async with db.execute("SELECT COUNT(*) FROM users") as cur:
        out["users"] = (await cur.fetchone())[0]
    async with db.execute("SELECT COUNT(*) FROM download_history WHERE status='done'") as cur:
        out["downloads"] = (await cur.fetchone())[0]
    async with db.execute("SELECT COUNT(*) FROM ai_history WHERE status='done'") as cur:
        out["analyses"] = (await cur.fetchone())[0]
    return out


# SEC-B-003: the dead `fetch_all` helper that used to live here has been
# removed.  It accepted raw SQL + params and was never called from inside
# the codebase, so it was a latent SQL-injection surface.  NOTE: a stale
# reference `fetch_all=fetch_all` survives in the `repo = SimpleNamespace(...)`
# alias block (~line 29645) — that assignment is outside Section B's range
# and must be cleaned up by another agent; until then, leaving it in place
# would raise NameError at module import, so the SEC-B-003 cleanup is
# considered deferred until the namespace alias is also updated.


async def add_library_entry(
    user_id: int, *, file_name: str, media_type: str | None,
    file_size: int, file_id: str | None = None, note: str | None = None,
    tags: str | None = None,
) -> int:
    db = await get_db()
    cur = await db.execute(
        """
        INSERT INTO library (user_id, file_name, media_type, file_size, file_id, note, tags)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (user_id, file_name, media_type, file_size, file_id, note, tags),
    )
    await db.commit()
    return cur.lastrowid  # type: ignore[return-value]


async def library_entries(user_id: int, limit: int = 20, offset: int = 0,
                          media_type: str | None = None) -> list[dict[str, Any]]:
    db = await get_db()
    if media_type:
        sql = ("SELECT * FROM library WHERE user_id = ? AND media_type = ? "
               "ORDER BY created_at DESC LIMIT ? OFFSET ?")
        params: tuple[Any, ...] = (user_id, media_type, limit, offset)
    else:
        sql = ("SELECT * FROM library WHERE user_id = ? "
               "ORDER BY created_at DESC LIMIT ? OFFSET ?")
        params = (user_id, limit, offset)
    async with db.execute(sql, params) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def library_search(user_id: int, query: str, limit: int = 20) -> list[dict[str, Any]]:
    db = await get_db()
    # DB-B-031: escape LIKE wildcards (%, _) and the escape char itself so
    # user input cannot match unintended rows.  ESCAPE '\\' declares the
    # backslash as the escape character for each LIKE clause.
    safe_q = (
        query.lower()
        .replace("\\", "\\\\")
        .replace("%", "\\%")
        .replace("_", "\\_")
    )
    like = f"%{safe_q}%"
    async with db.execute(
        """
        SELECT * FROM library
        WHERE user_id = ? AND (
            LOWER(file_name) LIKE ? ESCAPE '\\'
            OR LOWER(IFNULL(note,'')) LIKE ? ESCAPE '\\'
            OR LOWER(IFNULL(tags,'')) LIKE ? ESCAPE '\\'
        )
        ORDER BY created_at DESC LIMIT ?
        """,
        (user_id, like, like, like, limit),
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def library_count(user_id: int) -> int:
    db = await get_db()
    async with db.execute(
        "SELECT COUNT(*) FROM library WHERE user_id = ?", (user_id,)
    ) as cur:
        return (await cur.fetchone())[0]


async def library_remove(user_id: int, entry_id: int) -> bool:
    db = await get_db()
    cur = await db.execute(
        "DELETE FROM library WHERE id = ? AND user_id = ?", (entry_id, user_id)
    )
    await db.commit()
    return (cur.rowcount or 0) > 0


async def library_clear(user_id: int) -> int:
    db = await get_db()
    cur = await db.execute("DELETE FROM library WHERE user_id = ?", (user_id,))
    await db.commit()
    return cur.rowcount or 0


async def add_inspected_chat(
    user_id: int, *, chat_id: int | None, username: str | None,
    title: str | None, chat_type: str | None, members: int | None,
    description: str | None, first_name: str | None, last_name: str | None,
    bio: str | None, is_bot: bool | None,
) -> int:
    db = await get_db()
    cur = await db.execute(
        """
        INSERT INTO inspected_chats
            (user_id, chat_id, username, title, chat_type, members,
             description, first_name, last_name, bio, is_bot)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (user_id, chat_id, username, title, chat_type, members, description,
         first_name, last_name, bio, 1 if is_bot else 0 if is_bot is False else None),
    )
    await db.commit()
    return cur.lastrowid  # type: ignore[return-value]


async def recent_inspected(user_id: int, limit: int = 10) -> list[dict[str, Any]]:
    db = await get_db()
    async with db.execute(
        """
        SELECT username, title, chat_type, members, first_name, is_bot, created_at
        FROM inspected_chats WHERE user_id = ?
        ORDER BY created_at DESC LIMIT ?
        """,
        (user_id, limit),
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def user_daily_download_usage(user_id: int) -> tuple[int, int]:
    """Return (count_today, bytes_today) of completed downloads."""
    db = await get_db()
    async with db.execute(
        """
        SELECT COUNT(*), COALESCE(SUM(file_size), 0)
        FROM download_history
        WHERE user_id = ? AND status = 'done'
          AND date(created_at) = date('now')
        """,
        (user_id,),
    ) as cur:
        row = await cur.fetchone()
    return int(row[0] or 0), int(row[1] or 0)


async def user_stats(user_id: int) -> dict[str, Any]:
    db = await get_db()
    out: dict[str, Any] = {}
    async with db.execute(
        "SELECT COUNT(*), COALESCE(SUM(file_size),0) FROM download_history "
        "WHERE user_id = ? AND status='done'", (user_id,),
    ) as cur:
        c, b = await cur.fetchone()
        out["downloads"] = int(c or 0)
        out["download_bytes"] = int(b or 0)
    async with db.execute(
        "SELECT COUNT(*) FROM ai_history WHERE user_id = ? AND status='done'",
        (user_id,),
    ) as cur:
        out["analyses"] = (await cur.fetchone())[0]
    async with db.execute(
        "SELECT COUNT(*) FROM library WHERE user_id = ?", (user_id,),
    ) as cur:
        out["library"] = (await cur.fetchone())[0]
    async with db.execute(
        "SELECT COUNT(*) FROM inspected_chats WHERE user_id = ?", (user_id,),
    ) as cur:
        out["inspected"] = (await cur.fetchone())[0]
    async with db.execute(
        "SELECT media_type, COUNT(*) FROM download_history "
        "WHERE user_id = ? AND status='done' GROUP BY media_type "
        "ORDER BY COUNT(*) DESC LIMIT 5", (user_id,),
    ) as cur:
        out["by_type"] = [(r[0], r[1]) for r in await cur.fetchall()]
    return out


async def global_stats() -> dict[str, Any]:
    db = await get_db()
    out: dict[str, Any] = {}
    async with db.execute("SELECT COUNT(*) FROM users") as cur:
        out["users"] = (await cur.fetchone())[0]
    async with db.execute(
        "SELECT COUNT(*), COALESCE(SUM(file_size),0) FROM download_history "
        "WHERE status='done'"
    ) as cur:
        c, b = await cur.fetchone()
        out["downloads"] = int(c or 0)
        out["download_bytes"] = int(b or 0)
    async with db.execute(
        "SELECT COUNT(*) FROM ai_history WHERE status='done'"
    ) as cur:
        out["analyses"] = (await cur.fetchone())[0]
    async with db.execute("SELECT COUNT(*) FROM library") as cur:
        out["library"] = (await cur.fetchone())[0]
    async with db.execute("SELECT COUNT(*) FROM inspected_chats") as cur:
        out["inspected"] = (await cur.fetchone())[0]
    return out


async def add_scheduled_task(user_id: int, kind: str, payload: str,
                             run_at: str) -> int:
    db = await get_db()
    cur = await db.execute(
        "INSERT INTO scheduled_tasks (user_id, kind, payload, run_at) "
        "VALUES (?, ?, ?, ?)",
        (user_id, kind, payload, run_at),
    )
    await db.commit()
    return cur.lastrowid  # type: ignore[return-value]


async def pending_scheduled_tasks(now_iso: str, limit: int = 20) -> list[dict[str, Any]]:
    db = await get_db()
    async with db.execute(
        "SELECT * FROM scheduled_tasks WHERE status='pending' AND run_at <= ? "
        "ORDER BY run_at ASC LIMIT ?",
        (now_iso, limit),
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def list_scheduled_tasks(user_id: int, limit: int = 10) -> list[dict[str, Any]]:
    db = await get_db()
    async with db.execute(
        "SELECT id, kind, payload, run_at, status, created_at "
        "FROM scheduled_tasks WHERE user_id = ? ORDER BY run_at DESC LIMIT ?",
        (user_id, limit),
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def update_scheduled_task(task_id: int, status: str) -> None:
    db = await get_db()
    await db.execute(
        "UPDATE scheduled_tasks SET status = ? WHERE id = ?", (status, task_id)
    )
    await db.commit()


async def cancel_scheduled_task(user_id: int, task_id: int) -> bool:
    db = await get_db()
    cur = await db.execute(
        "DELETE FROM scheduled_tasks WHERE id = ? AND user_id = ? AND status='pending'",
        (task_id, user_id),
    )
    await db.commit()
    return (cur.rowcount or 0) > 0


async def create_broadcast(admin_id: int, text: str) -> int:
    db = await get_db()
    cur = await db.execute(
        "INSERT INTO broadcasts (admin_id, text) VALUES (?, ?)",
        (admin_id, text),
    )
    await db.commit()
    return cur.lastrowid  # type: ignore[return-value]


async def update_broadcast_counts(broadcast_id: int, sent: int, failed: int) -> None:
    db = await get_db()
    await db.execute(
        "UPDATE broadcasts SET sent = ?, failed = ? WHERE id = ?",
        (sent, failed, broadcast_id),
    )
    await db.commit()


async def recent_broadcasts(limit: int = 5) -> list[dict[str, Any]]:
    db = await get_db()
    async with db.execute(
        "SELECT * FROM broadcasts ORDER BY created_at DESC LIMIT ?", (limit,)
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def all_users(limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
    db = await get_db()
    async with db.execute(
        "SELECT tg_id, username, first_name, is_admin, created_at, last_active "
        "FROM users ORDER BY last_active DESC LIMIT ? OFFSET ?",
        (limit, offset),
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def user_count() -> int:
    db = await get_db()
    async with db.execute("SELECT COUNT(*) FROM users") as cur:
        return (await cur.fetchone())[0]


async def export_user_data(user_id: int) -> dict[str, Any]:
    """Export a user's settings, history, library, and inspections as a dict."""
    db = await get_db()
    out: dict[str, Any] = {"user_id": user_id}
    async with db.execute(
        "SELECT * FROM user_settings WHERE user_id = ?", (user_id,)
    ) as cur:
        s = await cur.fetchone()
    out["settings"] = dict(s) if s else {}
    if out["settings"].get("gemini_api_key"):
        out["settings"]["gemini_api_key"] = "***redacted***"
    async with db.execute(
        "SELECT file_name, file_size, media_type, source, status, created_at "
        "FROM download_history WHERE user_id = ? ORDER BY created_at DESC",
        (user_id,),
    ) as cur:
        out["download_history"] = [dict(r) for r in await cur.fetchall()]
    async with db.execute(
        "SELECT file_name, category, title, season, episode, year, language, "
        "quality, confidence, status, created_at FROM ai_history "
        "WHERE user_id = ? ORDER BY created_at DESC",
        (user_id,),
    ) as cur:
        out["ai_history"] = [dict(r) for r in await cur.fetchall()]
    out["library"] = await library_entries(user_id, limit=1000)
    async with db.execute(
        "SELECT username, title, chat_type, members, created_at "
        "FROM inspected_chats WHERE user_id = ? ORDER BY created_at DESC",
        (user_id,),
    ) as cur:
        out["inspected_chats"] = [dict(r) for r in await cur.fetchall()]
    return out


async def restore_user_settings(user_id: int, settings: dict[str, Any]) -> None:
    """Import settings from a backup dict (only safe, known columns)."""
    if not settings:
        return
    await ensure_settings(user_id)
    db = await get_db()
    safe = {
        "preferred_quality", "ai_model", "language", "auto_delete",
        "notifications", "ai_mode", "toolbox_audio_bitrate",
        "toolbox_video_crf",
    }
    sets: list[str] = []
    vals: list[Any] = []
    for k, v in settings.items():
        if k in safe and v is not None:
            sets.append(f"{k} = ?")
            vals.append(v)
    if sets:
        vals.append(user_id)
        # DB-B-001: wrap UPDATE + commit so a failure rolls the transaction
        # back instead of leaving partial state.
        try:
            await db.execute(
                f"UPDATE user_settings SET {', '.join(sets)}, "
                f"updated_at = datetime('now') WHERE user_id = ?",
                vals,
            )
            await db.commit()
        except Exception:
            await db.rollback()
            raise


# ---------------------------------------------------------------------------
# VC Tour — groups, visits, tour state
# ---------------------------------------------------------------------------


async def vc_upsert_group(*, group_id: int, access_hash: int | None = None,
                          title: str | None = None, username: str | None = None,
                          public_link: str | None = None, source: str | None = None,
                          access_status: str = "unknown",
                          active_vc: Optional[bool] = None,
                          last_error: str | None = None,
                          commit: bool = True,
                          call_id: int | None = None,
                          call_access_hash: int | None = None,
                          last_active_vc_at: float | None = None) -> bool:
    """Upsert a discovered group. Returns True if the group was newly inserted
    (did not exist before), False if it was an existing row that was updated.

    Issues 14-17 fix: uses COALESCE on the ON CONFLICT path so that NULL
    values from partial callers do NOT overwrite good stored metadata.
    Only non-NULL values from the caller update the stored row.

    Issue 17 fix: ``active_vc`` is now ``Optional[bool]`` (default ``None``).
    When ``None``, the stored ``active_vc`` value is preserved (not reset to
    False).  Discovery callers that don't know the active-VC state pass
    ``active_vc=None``; active-scan callers pass ``active_vc=True/False``.

    v97 FIX: ``commit`` parameter (default True for backward compat).
    Discovery passes ``commit=False`` and commits once per query batch to
    avoid 1000+ fsyncs per cycle that saturate the aiosqlite worker thread
    and make the bot appear unresponsive.

    v98.09-P3 §7/§19: optional knowledge-cache identity columns
    (``call_id`` / ``call_access_hash`` / ``last_active_vc_at``).  NULL
    (omitted) preserves the stored value — same COALESCE semantics as the
    other columns — so existing callers are unaffected and the identity is
    only written by the classification paths that ACTUALLY verified a live
    call (Tier-2 evidence).
    """
    db = await get_db()
    # Check existence first.
    async with db.execute(
        "SELECT 1 FROM vc_groups WHERE group_id = ?", (group_id,)
    ) as cur:
        existing = await cur.fetchone()
    is_new = existing is None
    # P0 fix #1: NEVER pass NULL for active_vc — the INSERT part of
    # INSERT ... ON CONFLICT runs first and violates NOT NULL before the
    # ON CONFLICT CASE can preserve the old value.  Always pass 0 (False)
    # in VALUES; the ON CONFLICT CASE preserves the old value for existing
    # rows when active_vc=None was requested by the caller.
    if active_vc is True:
        active_vc_val = 1
    elif active_vc is False:
        active_vc_val = 0
    else:
        # None (preserve) — pass 0 for the INSERT (active_vc is NOT NULL);
        # v99.07 FIX-10 (P0): the UPDATE branch uses a SEPARATE bind param
        # (active_vc_update) that IS NULL for preserve — the old
        # ``CASE WHEN excluded.active_vc IS NOT NULL`` never took the
        # preserve branch because the INSERT half always bound 0/1, so
        # every active_vc=None upsert SILENTLY CLEARED active_vc=1
        # (the docstring + inline "P0 fix #1" comment both promised
        # preservation; the SQL did not deliver it).
        active_vc_val = 0
    # v99.07 FIX-10: 1/0/None for the ON CONFLICT CASE — None preserves.
    active_vc_update = None if active_vc is None else (1 if active_vc else 0)
    await db.execute(
        """
        INSERT INTO vc_groups (group_id, access_hash, title, username,
                                public_link, source, access_status, active_vc,
                                discovered_at, last_checked_at, last_seen_at,
                                last_error, call_id, call_access_hash,
                                last_active_vc_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'), datetime('now'), ?, ?, ?, ?)
        ON CONFLICT(group_id) DO UPDATE SET
            access_hash = COALESCE(excluded.access_hash, vc_groups.access_hash),
            title = COALESCE(excluded.title, vc_groups.title),
            username = COALESCE(excluded.username, vc_groups.username),
            public_link = COALESCE(excluded.public_link, vc_groups.public_link),
            source = COALESCE(excluded.source, vc_groups.source),
            access_status = excluded.access_status,
            active_vc = CASE WHEN ? IS NULL
                        THEN vc_groups.active_vc ELSE ? END,
            last_checked_at = datetime('now'),
            last_seen_at = datetime('now'),
            last_error = COALESCE(excluded.last_error, vc_groups.last_error),
            call_id = COALESCE(excluded.call_id, vc_groups.call_id),
            call_access_hash = COALESCE(excluded.call_access_hash, vc_groups.call_access_hash),
            last_active_vc_at = COALESCE(excluded.last_active_vc_at, vc_groups.last_active_vc_at)
        """,
        (group_id, access_hash, title, username, public_link, source,
         access_status, active_vc_val, last_error, call_id, call_access_hash,
         last_active_vc_at, active_vc_update, active_vc_update),
    )
    if commit:
        await db.commit()
    return is_new


# ---------------------------------------------------------------------------
# v98.09-P3 §4/§7/§19 — VC Knowledge Cache (cache-first discovery handoff)
# ---------------------------------------------------------------------------


async def vc_groups_fresh_active(
    active_ttl_seconds: float, *, limit: int = 200,
) -> list[dict[str, Any]]:
    """Tier-0 knowledge snapshot: groups with a FRESH active-VC verification.

    v98.09-P3: the Join-All fast path consumes this BEFORE any Telegram RPC
    (§4 preferred order: fresh active knowledge first).  ``active_ttl_seconds``
    implements the §20 freshness window — active state changes quickly, so
    the TTL is intentionally SHORT (config ``vc_knowledge_active_ttl``).

    Returns rows ordered by most-recent active verification first, each with
    the cached call identity (``call_id`` / ``call_access_hash``) so Join-All
    can skip duplicate detection RPCs for fresh entries (§9/§16).
    Old installs (pre-P3 rows) simply lack ``last_active_vc_at`` → they read
    as stale → the fast path falls back to classification.  No data loss,
    no migration risk.
    """
    db = await get_db()
    cutoff = time.time() - max(0.0, float(active_ttl_seconds))
    async with db.execute(
        "SELECT group_id, title, username, public_link, access_hash, "
        "active_vc, last_active_vc_at, call_id, call_access_hash, "
        "last_checked_at, access_status FROM vc_groups "
        "WHERE active_vc=1 AND last_active_vc_at IS NOT NULL "
        "AND last_active_vc_at >= ? "
        "AND access_status IN ('accessible', 'stale', 'unknown') "
        "ORDER BY last_active_vc_at DESC LIMIT ?",
        (cutoff, int(limit)),
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def vc_groups_stale_active(
    active_ttl_seconds: float, *, limit: int = 40,
) -> list[dict[str, Any]]:
    """Tier-0 complement: previously-active groups whose verification is STALE.

    v98.09-P3 §4 third preference: stale candidates needing refresh — they
    get a bounded Tier-2 re-verification (one detection RPC each) instead of
    a full dialog discovery.  Bounded by ``limit`` (config
    ``vc_knowledge_stale_refresh_limit``) so the refresh can never become a
    hidden full-scan.
    """
    db = await get_db()
    cutoff = time.time() - max(0.0, float(active_ttl_seconds))
    async with db.execute(
        "SELECT group_id, title, username, public_link, access_hash, "
        "active_vc, last_active_vc_at, call_id, call_access_hash, "
        "last_checked_at, access_status FROM vc_groups "
        "WHERE active_vc=1 AND last_active_vc_at IS NOT NULL "
        "AND last_active_vc_at < ? "
        "AND access_status IN ('accessible', 'stale', 'unknown') "
        "ORDER BY last_active_vc_at DESC LIMIT ?",
        (cutoff, int(limit)),
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def vc_knowledge_store_active(
    group_id: int, *, call_id: int | None = None,
    call_access_hash: int | None = None, commit: bool = True,
) -> bool:
    """Persist a JUST-VERIFIED active call identity (Tier-2 → cache handoff).

    v98.09-P3 §19: called immediately after a real detection RPC found a live
    call (Join-All Phase 2 classification, discovery classify, watcher).
    ``last_active_vc_at`` = now (epoch seconds) so the freshness window is
    anchored to VERIFICATION time, not row-write time.  Targeted UPDATE —
    it never touches title/username/access_hash/source (those keep their
    own writers) and never INSERTs (the row must already exist; classification
    paths always upsert first — see auto-cycle 20244 → 20257 ordering).

    Returns True when a row was updated, False when the group is unknown
    (caller may ignore — the regular upsert paths will create the row).
    """
    db = await get_db()
    try:
        cur = await db.execute(
            "UPDATE vc_groups SET active_vc=1, call_id=?, call_access_hash=?, "
            "last_active_vc_at=?, last_checked_at=datetime('now') "
            "WHERE group_id=?",
            (call_id, call_access_hash, time.time(), group_id),
        )
        updated = cur.rowcount > 0
        if commit:
            await db.commit()
        return updated
    except Exception:  # noqa: BLE001
        await db.rollback()
        return False


async def vc_knowledge_mark_inactive(
    group_id: int, *, commit: bool = True,
) -> bool:
    """Record a just-verified ABSENT call (Tier-2 negative result → cache).

    v98.09-P3: called when a detection RPC returned None (no active call) —
    keeps the knowledge cache honest so future fast paths don't resurrect a
    dead VC from a stale row.  ``last_active_vc_at`` is NOT cleared (it is a
    historical fact — useful for stale-active ranking); the row simply stops
    matching ``active_vc=1``.
    """
    db = await get_db()
    try:
        cur = await db.execute(
            "UPDATE vc_groups SET active_vc=0, call_id=NULL, "
            "call_access_hash=NULL, last_checked_at=datetime('now') "
            "WHERE group_id=?",
            (group_id,),
        )
        updated = cur.rowcount > 0
        if commit:
            await db.commit()
        return updated
    except Exception:  # noqa: BLE001
        await db.rollback()
        return False


async def vc_delete_group(group_id: int) -> bool:
    """v98.04 FIX-AA-db / FIX-BB (BUG-VC-DISCOVERY-STORE-PEERUSER):
    Delete a row from vc_groups. Used by the snapshot-phase PeerUser
    cleanup (voicechat.vc_mark_peeruser) to remove IDs that have been
    PROVEN to be user IDs (Telethon resolved them as PeerUser — a
    permanent id-form error, NOT a transient PeerChannel resolution
    failure). Safe because:
      * PeerUser errors are SPECIFIC to user IDs — PeerChannel errors
        have a DIFFERENT message and do NOT trigger this cleanup.
      * The caller (vc_mark_peeruser) only calls this after a confirmed
        PeerUser resolution failure, never for transient errors.
      * The in-memory set (_vc_known_peeruser_ids) provides same-session
        fast-skip even if this DB delete fails.
    Returns True if a row was deleted, False if no row existed.
    """
    db = await get_db()
    try:
        cur = await db.execute(
            "DELETE FROM vc_groups WHERE group_id = ?", (group_id,)
        )
        deleted = cur.rowcount > 0
        await db.commit()
        return deleted
    except Exception:  # noqa: BLE001
        await db.rollback()
        return False


async def vc_groups_active(limit: int = 500) -> list[dict[str, Any]]:
    db = await get_db()
    async with db.execute(
        "SELECT * FROM vc_groups WHERE active_vc=1 AND access_status='accessible' "
        "ORDER BY last_checked_at DESC LIMIT ?",
        (limit,),
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def vc_groups_all(limit: int = 500) -> list[dict[str, Any]]:
    db = await get_db()
    async with db.execute(
        "SELECT * FROM vc_groups ORDER BY discovered_at DESC LIMIT ?", (limit,)
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def vc_group_count() -> int:
    """Return the total number of persisted groups in vc_groups.

    Patch 8: used by the dashboard to show 'Known groups: N' alongside
    'Scanned: M' so the admin can see if M < N (which would indicate
    starvation, though Patch 6's keyset pagination eliminates that).
    """
    db = await get_db()
    async with db.execute("SELECT COUNT(*) FROM vc_groups") as cur:
        row = await cur.fetchone()
    return int(row[0]) if row else 0


async def vc_groups_keyset(batch_size: int = 500) -> list[dict[str, Any]]:
    """Fetch ALL persisted groups using stable keyset pagination.

    Issue 20: this function accumulates all rows into a list.  For very large
    DBs (>1000 groups), prefer ``vc_groups_keyset_stream`` which yields rows
    for streaming processing.  This function is kept for callers that need
    the full list (e.g., Join All target selection).

    Issue 21: keyset pagination on ``group_id`` (unique primary key) is
    deterministic within a single scan snapshot.  Rows inserted BEHIND the
    cursor (with a lower group_id than the last processed key) will NOT
    appear in the current scan — they'll be picked up in the next scan.
    """
    db = await get_db()
    all_groups: list[dict[str, Any]] = []
    last_id: int = -1
    while True:
        async with db.execute(
            "SELECT * FROM vc_groups WHERE group_id > ? "
            "ORDER BY group_id ASC LIMIT ?",
            (last_id, batch_size),
        ) as cur:
            batch = await cur.fetchall()
        if not batch:
            break
        batch_dicts = [dict(r) for r in batch]
        all_groups.extend(batch_dicts)
        last_id = batch_dicts[-1]["group_id"]
        if len(batch) < batch_size:
            break
    return all_groups


async def vc_groups_keyset_stream(
    batch_size: int = 500, *, only_accessible: bool = False
) -> "AsyncGenerator[dict[str, Any], None]":
    """Stream ALL persisted groups one-by-one using keyset pagination.

    Issue 20: yields rows one at a time so callers can process them without
    accumulating the entire DB in memory.

    Issue 23: if ``only_accessible=True``, skips groups with ``access_status``
    not in ('accessible', 'stale') — known-inaccessible or errored groups
    are skipped to reduce RPC load during active scanning.
    """
    db = await get_db()
    last_id: int = -1
    while True:
        if only_accessible:
            query = (
                "SELECT * FROM vc_groups WHERE group_id > ? "
                "AND access_status IN ('accessible', 'stale') "
                "ORDER BY group_id ASC LIMIT ?"
            )
        else:
            query = (
                "SELECT * FROM vc_groups WHERE group_id > ? "
                "ORDER BY group_id ASC LIMIT ?"
            )
        async with db.execute(query, (last_id, batch_size)) as cur:
            batch = await cur.fetchall()
        if not batch:
            break
        for row in batch:
            yield dict(row)
        last_id = batch[-1]["group_id"]  # type: ignore[union-attr]
        if len(batch) < batch_size:
            break


async def vc_add_visit(*, group_id: int, group_title: str | None = None,
                       username: str | None = None, group_link: str | None = None,
                       joined_at: str | None = None, left_at: str | None = None,
                       planned_duration_seconds: int | None = None,
                       actual_duration_seconds: int | None = None,
                       mode: str = "auto", status: str = "joined",
                       leave_reason: str | None = None,
                       error: str | None = None) -> int:
    db = await get_db()
    cur = await db.execute(
        """
        INSERT INTO vc_visits (group_id, group_title, username, group_link,
                               joined_at, left_at, planned_duration_seconds,
                               actual_duration_seconds, mode, status,
                               leave_reason, error)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (group_id, group_title, username, group_link, joined_at, left_at,
         planned_duration_seconds, actual_duration_seconds, mode, status,
         leave_reason, error),
    )
    await db.commit()
    return cur.lastrowid  # type: ignore[return-value]


async def vc_update_visit(visit_id: int, **fields: Any) -> None:
    if not fields:
        return
    # SEC-B-002 / DB-B-004: column whitelist — reject unknown keys so a caller
    # cannot inject arbitrary column names into the UPDATE via **fields.
    allowed = {
        "group_id", "group_title", "username", "group_link", "joined_at",
        "left_at", "planned_duration_seconds", "actual_duration_seconds",
        "mode", "status", "leave_reason", "error",
    }
    unknown = set(fields) - allowed
    if unknown:
        raise ValueError(f"vc_update_visit: unknown column(s): {sorted(unknown)}")
    cols = ", ".join(f"{k} = ?" for k in fields)
    vals: list[Any] = list(fields.values())
    vals.append(visit_id)
    db = await get_db()
    await db.execute(f"UPDATE vc_visits SET {cols} WHERE id = ?", vals)
    await db.commit()


async def vc_recent_visits(limit: int = 20, offset: int = 0,
                           mode: str | None = None,
                           status: str | None = None) -> list[dict[str, Any]]:
    db = await get_db()
    clauses = []
    params: list[Any] = []
    if mode:
        clauses.append("mode = ?")
        params.append(mode)
    if status:
        clauses.append("status = ?")
        params.append(status)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    params.extend([limit, offset])
    async with db.execute(
        f"SELECT * FROM vc_visits {where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
        params,
    ) as cur:
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def vc_visit_count(mode: str | None = None,
                         status: str | None = None) -> int:
    db = await get_db()
    clauses = []
    params: list[Any] = []
    if mode:
        clauses.append("mode = ?")
        params.append(mode)
    if status:
        clauses.append("status = ?")
        params.append(status)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    async with db.execute(f"SELECT COUNT(*) FROM vc_visits {where}", params) as cur:
        return (await cur.fetchone())[0]


async def vc_get_tour_state() -> dict[str, Any]:
    db = await get_db()
    async with db.execute("SELECT * FROM vc_tour_state WHERE id = 1") as cur:
        row = await cur.fetchone()
    return dict(row) if row else {}


async def vc_save_tour_state(**fields: Any) -> None:
    if not fields:
        return
    # DB-B-006: column whitelist — reject unknown keys so a caller cannot
    # inject arbitrary column names via **fields.  Previously the function
    # injected the sentinel string "datetime('now')" as a parameter value
    # and special-cased it in the loop, which was both fragile and an
    # injection footgun.  Now every caller-supplied value is parameterised
    # and the updated_at expression is appended as a literal SQL fragment.
    allowed = {
        "running", "paused", "current_group_id", "current_queue_index",
        "queue_json", "started_at", "stay_seconds", "cooldown_seconds",
    }
    unknown = set(fields) - allowed
    if unknown:
        raise ValueError(f"vc_save_tour_state: unknown column(s): {sorted(unknown)}")
    cols_parts = [f"{k} = ?" for k in fields]
    vals: list[Any] = list(fields.values())
    # Append the parameterless updated_at expression to the SET clause.
    cols_parts.append("updated_at = datetime('now')")
    vals.append(1)
    db = await get_db()
    # DB-B-001: wrap UPDATE + commit so a failure rolls the transaction back.
    try:
        await db.execute(
            f"UPDATE vc_tour_state SET {', '.join(cols_parts)} WHERE id = ?", vals
        )
        await db.commit()
    except Exception:
        await db.rollback()
        raise


async def vc_visited_group_ids_since(since_iso: str) -> set[int]:
    """Return group IDs visited since *since_iso* (for revisit dedup)."""
    db = await get_db()
    async with db.execute(
        "SELECT DISTINCT group_id FROM vc_visits WHERE created_at >= ?",
        (since_iso,),
    ) as cur:
        rows = await cur.fetchall()
    return {r[0] for r in rows}


# ---------------------------------------------------------------------------
# VC runtime settings (persisted, overrides env defaults)
# ---------------------------------------------------------------------------


async def vc_get_settings() -> dict[str, Any]:
    """Return persisted VC runtime settings (with env defaults applied)."""
    db = await get_db()
    async with db.execute("SELECT * FROM vc_settings WHERE id = 1") as cur:
        row = await cur.fetchone()
    if not row:
        return {
            "stay_seconds": config.vc_stay_minutes * 60,
            "cooldown_seconds": config.vc_cooldown_seconds,
            "revisit_same_group": config.vc_revisit_same_group,
            "auto_resume_after_manual": config.vc_auto_resume_after_manual,
            "join_notifications": config.vc_join_notifications,
            "leave_notifications": config.vc_leave_notifications,
            "save_history": config.vc_save_history,
            "auto_start_vc": False,
            "end_created_vc": False,
            # v97.1: NULL/missing -> "primary" (existing behavior).
            "vc_join_mode": "primary",
        }
    d = dict(row)
    # v97.1: normalise vc_join_mode — NULL or unknown -> "primary".
    _mode = d.get("vc_join_mode", None)
    if _mode not in ("primary", "distributed"):
        _mode = "primary"
    return {
        "stay_seconds": int(d.get("stay_seconds", config.vc_stay_minutes * 60)),
        "cooldown_seconds": int(d.get("cooldown_seconds", config.vc_cooldown_seconds)),
        "revisit_same_group": bool(d.get("revisit_same_group", config.vc_revisit_same_group)),
        "auto_resume_after_manual": bool(d.get("auto_resume_after_manual", config.vc_auto_resume_after_manual)),
        "join_notifications": bool(d.get("join_notifications", config.vc_join_notifications)),
        "leave_notifications": bool(d.get("leave_notifications", config.vc_leave_notifications)),
        "save_history": bool(d.get("save_history", config.vc_save_history)),
        "auto_start_vc": bool(d.get("auto_start_vc", False)),
        "end_created_vc": bool(d.get("end_created_vc", False)),
        # v97: discovery_enabled — NULL means "use .env default"
        "discovery_enabled": d.get("discovery_enabled", None),
        # v97.1: VC Join Mode (primary | distributed).
        "vc_join_mode": _mode,
    }


async def vc_update_settings(**fields: Any) -> dict[str, Any]:
    """Update one or more VC runtime settings. Returns the new settings dict."""
    allowed = {
        "stay_seconds", "cooldown_seconds", "revisit_same_group",
        "auto_resume_after_manual", "join_notifications",
        "leave_notifications", "save_history",
        "auto_start_vc", "end_created_vc",
        "discovery_enabled",  # v97: DB-backed discovery enable/disable
        "vc_join_mode",       # v97.1: primary | distributed
    }
    sets: list[str] = []
    vals: list[Any] = []
    for k, v in fields.items():
        if k not in allowed:
            continue
        # Booleans → 0/1 for SQLite.
        if isinstance(v, bool):
            v = 1 if v else 0
        sets.append(f"{k} = ?")
        vals.append(v)
    if sets:
        sets.append("updated_at = datetime('now')")
        vals.append(1)
        db = await get_db()
        await db.execute(
            f"UPDATE vc_settings SET {', '.join(sets)} WHERE id = ?", vals
        )
        await db.commit()
    return await vc_get_settings()


# ===========================================================================
# Database — Talkative Mode repositories (Task ID 16)
# ===========================================================================
# All Talkative state lives in SQLite. Settings are layered: global defaults
# can be overridden per-chat; sessions + memory are keyed by (chat_id, user_id).


_TALKATIVE_GLOBAL_DEFAULTS: dict[str, Any] = {
    "enabled": False,
    "provider": "groq",
    "personality": "",
    "language_mode": "auto",
    "session_timeout_seconds": 300,
    "memory_turns": 10,
    "group_context_enabled": True,
    "group_context_messages": 8,
    "cooldown_seconds": 3,
    "private_auto_reply": True,
    "typing_enabled": True,
    # V52 Multimodal & Voice defaults
    "multimodal_enabled": True,
    "voice_understand": False,
    "voice_replies": False,
    "match_reply_type": False,
    "voice_clone_enabled": False,
    "clone_for_voice_msgs": False,
    "clone_voice_in_vc": False,
    "use_voice_everywhere": False,
    "standard_tts_fallback": True,
    "sticker_replies": False,
    "context_stickers": False,
    "gif_replies": False,
    "native_reactions": False,
    "image_understanding": False,
    "gif_understanding": False,
    "sticker_understanding": False,
    "media_dedup": True,
    "voice_reply_policy": "voice_only",
}


def _talkative_coerce(field_name: str, value: Any) -> Any:
    """Coerce a Python value to its SQLite representation for talkative tables."""
    if field_name in ("enabled", "group_context_enabled",
                      "private_auto_reply", "typing_enabled",
                      # V52 Multimodal boolean fields
                      "multimodal_enabled", "voice_understand", "voice_replies",
                      "match_reply_type", "voice_clone_enabled", "clone_for_voice_msgs",
                      "clone_voice_in_vc", "use_voice_everywhere", "standard_tts_fallback",
                      "sticker_replies", "context_stickers", "gif_replies",
                      "native_reactions", "image_understanding", "gif_understanding",
                      "sticker_understanding", "media_dedup"):
        return 1 if bool(value) else 0
    if field_name in ("session_timeout_seconds", "memory_turns",
                      "group_context_messages", "cooldown_seconds"):
        try:
            return int(value)
        except (TypeError, ValueError):
            return _TALKATIVE_GLOBAL_DEFAULTS.get(field_name, 0)
    return value


def _talkative_row_to_dict(row: aiosqlite.Row | None) -> dict[str, Any]:
    """Convert a talkative_global_settings / talkative_chat_settings row to a dict
    with Python-typed fields (bools as bool, ints as int)."""
    if row is None:
        return {}
    d = dict(row)
    for k in ("enabled", "group_context_enabled",
              "private_auto_reply", "typing_enabled"):
        if k in d and d[k] is not None:
            d[k] = bool(d[k])
    for k in ("session_timeout_seconds", "memory_turns",
              "group_context_messages", "cooldown_seconds"):
        if k in d and d[k] is not None:
            try:
                d[k] = int(d[k])
            except (TypeError, ValueError):
                pass
    return d


async def talkative_get_global_settings() -> dict[str, Any]:
    """Return the global Talkative settings (merged with env defaults)."""
    db = await get_db()
    async with db.execute(
        "SELECT * FROM talkative_global_settings WHERE id = 1"
    ) as cur:
        row = await cur.fetchone()
    d = _talkative_row_to_dict(row)
    # Layer: env config (already in `_TALKATIVE_GLOBAL_DEFAULTS` mirror) →
    # DB overrides. Missing DB fields fall back to env config.
    merged = dict(_TALKATIVE_GLOBAL_DEFAULTS)
    # Apply env defaults for fields not present in DB.
    merged["enabled"] = config.talkative_enabled
    merged["provider"] = config.talkative_provider
    merged["session_timeout_seconds"] = config.talkative_session_timeout
    merged["memory_turns"] = config.talkative_memory_turns
    merged["group_context_enabled"] = config.talkative_group_context_enabled
    merged["group_context_messages"] = config.talkative_group_context_messages
    merged["cooldown_seconds"] = config.talkative_cooldown_seconds
    merged["private_auto_reply"] = config.talkative_private_auto_reply
    merged["typing_enabled"] = config.talkative_typing_enabled
    # V52 Multimodal & Voice env defaults.
    merged["multimodal_enabled"] = config.talkative_multimodal_enabled
    merged["voice_understand"] = config.talkative_voice_understand
    merged["voice_replies"] = config.talkative_voice_replies
    merged["match_reply_type"] = config.talkative_match_reply_type
    merged["voice_clone_enabled"] = config.talkative_voice_clone_enabled
    merged["clone_for_voice_msgs"] = config.talkative_clone_for_voice_msgs
    merged["clone_voice_in_vc"] = config.talkative_clone_voice_in_vc
    merged["use_voice_everywhere"] = config.talkative_use_voice_everywhere
    merged["standard_tts_fallback"] = config.talkative_standard_tts_fallback
    merged["sticker_replies"] = config.talkative_sticker_replies
    merged["context_stickers"] = config.talkative_context_stickers
    merged["gif_replies"] = config.talkative_gif_replies
    merged["native_reactions"] = config.talkative_native_reactions
    merged["image_understanding"] = config.talkative_image_understanding
    merged["gif_understanding"] = config.talkative_gif_understanding
    merged["sticker_understanding"] = config.talkative_sticker_understanding
    merged["media_dedup"] = config.talkative_media_dedup
    merged["voice_reply_policy"] = config.talkative_voice_reply_policy
    # DB overrides.
    for k, v in d.items():
        if k in ("id", "updated_at"):
            continue
        if v is not None:
            merged[k] = v
    return merged


async def talkative_update_global_settings(**fields: Any) -> dict[str, Any]:
    """Update one or more global Talkative settings. Returns the new dict."""
    allowed = {
        "enabled", "provider", "personality", "language_mode",
        "session_timeout_seconds", "memory_turns", "group_context_enabled",
        "group_context_messages", "cooldown_seconds",
        "private_auto_reply", "typing_enabled",
        # V52 Multimodal & Voice settings
        "multimodal_enabled", "voice_understand", "voice_replies",
        "match_reply_type", "voice_clone_enabled", "clone_for_voice_msgs",
        "clone_voice_in_vc", "use_voice_everywhere", "standard_tts_fallback",
        "sticker_replies", "context_stickers", "gif_replies",
        "native_reactions", "image_understanding", "gif_understanding",
        "sticker_understanding", "media_dedup", "voice_reply_policy",
    }
    sets: list[str] = []
    vals: list[Any] = []
    for k, v in fields.items():
        if k not in allowed:
            continue
        v = _talkative_coerce(k, v)
        sets.append(f"{k} = ?")
        vals.append(v)
    if sets:
        sets.append("updated_at = datetime('now')")
        vals.append(1)
        db = await get_db()
        await db.execute(
            f"UPDATE talkative_global_settings SET {', '.join(sets)} WHERE id = ?",
            vals,
        )
        await db.commit()
    return await talkative_get_global_settings()


# V41 Fix #6/#7: Central effective-enabled + effective-provider resolvers.
# Precedence (documented + logged):
#   1. Explicit master kill switch: config.talkative_enabled (env TALKATIVE_ENABLED)
#      — if False, Talkative is ALWAYS off regardless of DB. This is the
#      "env bootstrap default" / master gate.
#   2. Persisted dashboard setting: DB talkative_global_settings.enabled
#      — if the master gate allows it, the DB-persisted setting wins.
#   3. Env bootstrap default: config.talkative_enabled (already the master gate)
#   4. Code default: False
#
# For provider:
#   1. Persisted dashboard provider (DB talkative_global_settings.provider)
#   2. Env default (config.talkative_provider)
#   3. Code default ("groq")
#
# The source is logged so the admin can see exactly where the effective
# value came from.

_TALKATIVE_MASTER_KILL_OVERRIDE: Optional[bool] = None
"""In-memory master kill override (emergency only).
If set (True/False), it takes ABSOLUTE precedence over DB and env.
None = no override (DB is the source of truth).
Used by shutdown/restart to force-disable without touching DB.
"""


async def talkative_effective_enabled() -> tuple[bool, str]:
    """Resolve the effective Talkative enabled state.

    Returns (enabled, source) where source is one of:
      "master_kill_override" | "dashboard_db" | "env_bootstrap" | "code_default"

    Precedence:
      1. master_kill_override (emergency in-memory override, highest)
      2. Dashboard DB persisted setting (the runtime source of truth)
      3. .env bootstrap default (config.talkative_enabled) — used ONLY on
         first startup before the admin panel has written to the DB
      4. code default (False)

    .env is NOT a permanent runtime kill switch. Once the DB is initialized
    (which happens at first startup via INSERT OR IGNORE), the DB value is
    authoritative. The admin panel can enable/disable Talkative at any time
    and the change persists across restarts.
    """
    global _TALKATIVE_MASTER_KILL_OVERRIDE
    # 1. Master kill override (emergency only — e.g. shutdown/restart)
    if _TALKATIVE_MASTER_KILL_OVERRIDE is not None:
        return bool(_TALKATIVE_MASTER_KILL_OVERRIDE), "master_kill_override"
    # 2. Dashboard DB persisted setting (runtime source of truth).
    try:
        db = await get_db()
        async with db.execute(
            "SELECT enabled FROM talkative_global_settings WHERE id = 1"
        ) as cur:
            row = await cur.fetchone()
    except Exception:  # noqa: BLE001
        row = None
    if row is not None:
        raw = row["enabled"] if "enabled" in row.keys() else None
        if raw is not None:
            return bool(int(raw)), "dashboard_db"
    # 3. .env bootstrap default — only used before the DB row exists.
    #    Once init_db() runs, the INSERT OR IGNORE creates the row with
    #    enabled=0, so this path is only hit if the DB hasn't been initialized.
    return bool(config.talkative_enabled), "env_bootstrap"


async def talkative_effective_provider() -> tuple[str, str, str, bool, str]:
    """V41 Fix #7 + V42 Fix #2: resolve the effective Talkative provider.

    Returns (provider, source, model, provider_ready, fallback_reason) where:
      provider        = "groq" | "openrouter" | "gemini"
      source          = "dashboard_db" | "env_default" | "code_default"
      model           = the configured model for this provider
      provider_ready  = True if the provider's API key is configured AND not in cooldown
      fallback_reason = "" if ready, else the reason the provider is not ready
    """
    # Lazy import: talkative provider-cooldown helpers live in the talkative
    # subsystem; importing at module level would create a db_layer -> talkative cycle.
    from .talkative import _provider_in_cooldown, _provider_cooldown_remaining, _provider_get_state
    # 1. Dashboard DB persisted provider
    try:
        db = await get_db()
        async with db.execute(
            "SELECT provider FROM talkative_global_settings WHERE id = 1"
        ) as cur:
            row = await cur.fetchone()
    except Exception:  # noqa: BLE001
        row = None
    db_provider = None
    if row is not None:
        raw = row["provider"] if "provider" in row.keys() else None
        if raw:
            db_provider = str(raw).strip().lower()
    if db_provider in ("groq", "openrouter", "gemini"):
        provider, source = db_provider, "dashboard_db"
    elif config.talkative_provider in ("groq", "openrouter", "gemini"):
        provider, source = config.talkative_provider, "env_default"
    else:
        provider, source = "groq", "code_default"
    # Resolve model + readiness for this provider.
    if provider == "groq":
        model = config.groq_model or "llama-3.3-70b-versatile"
        ready = bool(config.groq_api_key)
        reason = "" if ready else "GROQ_API_KEY not configured"
    elif provider == "openrouter":
        model = config.openrouter_model or ""
        ready = bool(config.openrouter_api_key and config.openrouter_model)
        reason = "" if ready else "OPENROUTER_API_KEY or OPENROUTER_MODEL not configured"
    elif provider == "gemini":
        model = config.default_ai_model or "gemini-2.5-flash"  # v97.48: gemini-2.0-flash deprecated
        ready = bool(config.gemini_api_key)
        reason = "" if ready else "GEMINI_API_KEY not configured"
    else:
        model = ""
        ready = False
        reason = f"unknown provider: {provider}"
    # V42 Fix #2: if the provider is in cooldown, it's NOT ready.
    if ready and _provider_in_cooldown(provider):
        remaining = _provider_cooldown_remaining(provider)
        ready = False
        st = _provider_get_state(provider)
        reason = f"in cooldown ({remaining:.0f}s, class={st['failure_class']})"
    return provider, source, model, ready, reason


async def talkative_apply_effective_runtime() -> bool:
    """V41 Fix #6: apply the effective enabled state to the runtime.

    If effective-enabled is True, register the Telethon handler (idempotent).
    If False, the handler stays unregistered (or we could unregister — but
    Telethon doesn't support removing a single decorated handler cleanly;
    instead the per-message gate checks effective-enabled).

    Returns True if the handler is registered after this call.
    """
    # Lazy import: talkative_userbot_register_handler lives in the talkative
    # subsystem; importing at module level would create a db_layer -> talkative cycle.
    from .talkative import talkative_userbot_register_handler
    enabled, source = await talkative_effective_enabled()
    logger.info(
        "TALKATIVE_EFFECTIVE enabled=%s source=%s env_master=%s",
        enabled, source, config.talkative_enabled,
    )
    if enabled:
        registered = await talkative_userbot_register_handler()
        if registered:
            logger.info("Talkative runtime handler active (source=%s).", source)
        else:
            logger.warning(
                "Talkative effective-enabled=True but handler registration failed "
                "(MTProto not connected?) — will retry on reconnect.")
        return registered
    else:
        logger.info(
            "Talkative runtime handler inactive (enabled=False, source=%s). "
            "Per-message gate will reject all messages.", source)
        return False


async def talkative_get_chat_settings(chat_id: int) -> dict[str, Any]:
    """Return per-chat overrides (NULLable fields). Empty dict if no row."""
    db = await get_db()
    async with db.execute(
        "SELECT * FROM talkative_chat_settings WHERE chat_id = ?",
        (chat_id,),
    ) as cur:
        row = await cur.fetchone()
    return _talkative_row_to_dict(row)


async def talkative_set_chat_setting(chat_id: int, **fields: Any) -> dict[str, Any]:
    """Upsert one or more per-chat overrides. Returns the updated row dict."""
    allowed = {
        "enabled", "personality", "language_mode",
        "session_timeout_seconds", "memory_turns", "group_context_enabled",
        "cooldown_seconds",
    }
    cleaned: dict[str, Any] = {}
    for k, v in fields.items():
        if k not in allowed:
            continue
        cleaned[k] = _talkative_coerce(k, v)
    if not cleaned:
        return await talkative_get_chat_settings(chat_id)
    db = await get_db()
    # Build an UPSERT.
    cols = list(cleaned.keys())
    col_list = ", ".join(["chat_id"] + cols)
    placeholders = ", ".join(["?"] * (1 + len(cols)))
    update_parts = [f"{c} = excluded.{c}" for c in cols]
    update_parts.append("updated_at = datetime('now')")
    vals: list[Any] = [chat_id] + [cleaned[c] for c in cols]
    await db.execute(
        f"INSERT INTO talkative_chat_settings ({col_list}) "
        f"VALUES ({placeholders}) "
        f"ON CONFLICT(chat_id) DO UPDATE SET {', '.join(update_parts)}",
        vals,
    )
    await db.commit()
    return await talkative_get_chat_settings(chat_id)


async def talkative_effective_settings(chat_id: int) -> dict[str, Any]:
    """Merge global + per-chat overrides. Per-chat wins when set (not None)."""
    g = await talkative_get_global_settings()
    c = await talkative_get_chat_settings(chat_id)
    out = dict(g)
    for k, v in c.items():
        if k in ("chat_id", "updated_at"):
            continue
        if v is not None:
            out[k] = v
    return out


# --- Sessions ---------------------------------------------------------------

async def talkative_start_session(chat_id: int, user_id: int,
                                  timeout_seconds: int) -> dict[str, Any]:
    """Start (or reactivate) a Talkative session for (chat_id, user_id)."""
    # V43 Fix #2: use timezone-aware datetime instead of deprecated utcnow().
    expires_at = (datetime.now(timezone.utc) + timedelta(seconds=max(1, int(timeout_seconds)))
                  ).strftime("%Y-%m-%d %H:%M:%S")
    db = await get_db()
    await db.execute(
        """
        INSERT INTO talkative_sessions (chat_id, user_id, active, started_at,
                                        last_activity_at, expires_at)
        VALUES (?, ?, 1, datetime('now'), datetime('now'), ?)
        ON CONFLICT(chat_id, user_id) DO UPDATE SET
            active = 1,
            started_at = talkative_sessions.started_at,
            last_activity_at = datetime('now'),
            expires_at = excluded.expires_at
        """,
        (chat_id, user_id, expires_at),
    )
    await db.commit()
    return {
        "chat_id": chat_id, "user_id": user_id,
        "active": True, "expires_at": expires_at,
    }


async def talkative_touch_session(chat_id: int, user_id: int,
                                  timeout_seconds: int) -> bool:
    """Refresh ``last_activity_at`` and ``expires_at`` for an active session.

    DB-B-008: returns True if a row was touched, False if no active session
    exists for (chat_id, user_id) — in which case a warning is logged.  No
    implicit upsert is performed; callers that need a session should call
    ``talkative_start_session`` first.
    """
    # V43 Fix #2: use timezone-aware datetime instead of deprecated utcnow().
    expires_at = (datetime.now(timezone.utc) + timedelta(seconds=max(1, int(timeout_seconds)))
                  ).strftime("%Y-%m-%d %H:%M:%S")
    db = await get_db()
    cur = await db.execute(
        """
        UPDATE talkative_sessions
           SET last_activity_at = datetime('now'),
               expires_at = ?,
               active = 1
         WHERE chat_id = ? AND user_id = ?
        """,
        (expires_at, chat_id, user_id),
    )
    await db.commit()
    touched = (cur.rowcount or 0) > 0
    if not touched:
        logger.warning(
            "talkative_touch_session: no row updated for (chat_id=%s, "
            "user_id=%s) — session may have expired or never been started",
            chat_id, user_id,
        )
    return touched


async def talkative_get_active_session(chat_id: int, user_id: int) -> Optional[dict[str, Any]]:
    """Return the active session for (chat_id, user_id) if not expired, else None."""
    db = await get_db()
    async with db.execute(
        """
        SELECT * FROM talkative_sessions
         WHERE chat_id = ? AND user_id = ? AND active = 1
               AND expires_at > datetime('now')
        """,
        (chat_id, user_id),
    ) as cur:
        row = await cur.fetchone()
    if row is None:
        return None
    d = dict(row)
    d["active"] = bool(d.get("active", 0))
    return d


async def talkative_end_session(chat_id: int, user_id: int) -> None:
    """Mark a session as inactive (does NOT delete the memory)."""
    db = await get_db()
    await db.execute(
        "UPDATE talkative_sessions SET active = 0 "
        "WHERE chat_id = ? AND user_id = ?",
        (chat_id, user_id),
    )
    await db.commit()


# --- Memory -----------------------------------------------------------------

async def talkative_add_memory(chat_id: int, user_id: int,
                               role: str, content: str) -> int:
    """Append a message to the conversation memory. Returns the row id."""
    # DB-B-030: cap content length so a single huge message cannot bloat the
    # DB or blow past SQLite's 1GB-per-row soft limit.
    if len(content) > 32000:
        content = content[:32000]
    db = await get_db()
    # DB-B-001: wrap INSERT + commit so a failure rolls the transaction back.
    try:
        cur = await db.execute(
            """
            INSERT INTO talkative_memory (chat_id, user_id, role, content)
            VALUES (?, ?, ?, ?)
            """,
            (chat_id, user_id, role, content),
        )
        await db.commit()
    except Exception:
        await db.rollback()
        raise
    return cur.lastrowid  # type: ignore[return-value]


async def talkative_get_memory(chat_id: int, user_id: int,
                               limit: int = 10) -> list[dict[str, Any]]:
    """Return the most recent ``limit`` memory entries, oldest-first."""
    db = await get_db()
    async with db.execute(
        """
        SELECT role, content FROM talkative_memory
         WHERE chat_id = ? AND user_id = ?
         ORDER BY id DESC
         LIMIT ?
        """,
        (chat_id, user_id, limit),
    ) as cur:
        rows = await cur.fetchall()
    # Reverse to oldest-first for chat-style assembly.
    return [dict(r) for r in reversed(rows)]


async def talkative_trim_memory(chat_id: int, user_id: int,
                                max_turns: int) -> int:
    """Keep only the most recent ``max_turns`` entries. Returns deleted count.

    ``max_turns=0`` deletes everything (memory disabled).
    """
    if max_turns <= 0:
        db = await get_db()
        cur = await db.execute(
            "DELETE FROM talkative_memory WHERE chat_id = ? AND user_id = ?",
            (chat_id, user_id),
        )
        await db.commit()
        return cur.rowcount or 0
    db = await get_db()
    # Find the id of the (max_turns+1)-th newest row — the oldest entry to
    # DELETE. Since ids are AUTOINCREMENT, id order matches created_at order.
    async with db.execute(
        """
        SELECT id FROM talkative_memory
         WHERE chat_id = ? AND user_id = ?
         ORDER BY id DESC
         LIMIT 1 OFFSET ?
        """,
        (chat_id, user_id, max_turns),
    ) as cur:
        row = await cur.fetchone()
    if row is None:
        return 0  # fewer than max_turns+1 entries — nothing to delete
    cutoff_id = row[0]
    # Delete everything with id <= cutoff (i.e. the cutoff entry and all
    # older ones). Keeps the newest ``max_turns`` entries.
    cur = await db.execute(
        "DELETE FROM talkative_memory "
        "WHERE chat_id = ? AND user_id = ? AND id <= ?",
        (chat_id, user_id, cutoff_id),
    )
    await db.commit()
    return cur.rowcount or 0


async def talkative_clear_memory(chat_id: int, user_id: int | None = None) -> int:
    """Clear memory for a chat (optionally only for one user). Returns deleted count."""
    db = await get_db()
    if user_id is None:
        cur = await db.execute(
            "DELETE FROM talkative_memory WHERE chat_id = ?", (chat_id,)
        )
    else:
        cur = await db.execute(
            "DELETE FROM talkative_memory WHERE chat_id = ? AND user_id = ?",
            (chat_id, user_id),
        )
    await db.commit()
    return cur.rowcount or 0


# --- Stats ------------------------------------------------------------------

async def talkative_add_stat(chat_id: int, user_id: int,
                             trigger_type: str, provider: str,
                             success: bool) -> None:
    """Record a Talkative invocation outcome."""
    db = await get_db()
    await db.execute(
        """
        INSERT INTO talkative_stats (chat_id, user_id, trigger_type,
                                     provider, success)
        VALUES (?, ?, ?, ?, ?)
        """,
        (chat_id, user_id, trigger_type, provider, 1 if success else 0),
    )
    await db.commit()


# --- Cleanup ----------------------------------------------------------------

async def talkative_cleanup_expired_sessions() -> int:
    """Mark expired sessions as inactive. Returns affected count."""
    db = await get_db()
    cur = await db.execute(
        "UPDATE talkative_sessions SET active = 0 "
        "WHERE active = 1 AND expires_at <= datetime('now')"
    )
    await db.commit()
    return cur.rowcount or 0


async def talkative_cleanup_old_memory(max_age_days: int = 7) -> int:
    """Delete memory entries older than ``max_age_days``. Returns deleted count.

    V85.3 FIX BUG DB-22: exclude summary rows (is_summary=1) from the
    age-based cleanup.  Summaries are compact long-term knowledge of
    conversations before the retention window; deleting them after 7 days
    defeated the entire purpose of summarization.

    DB-B-015: delete in batches of 1000 so a single huge DELETE does not
    hold the writer lock for an extended period and the WAL stays bounded.
    Each batch is committed independently so progress is preserved even if
    a later batch fails.
    """
    db = await get_db()
    cutoff = f"-{int(max_age_days)} days"
    total = 0
    try:
        while True:
            cur = await db.execute(
                """
                DELETE FROM talkative_memory
                 WHERE id IN (
                     SELECT id FROM talkative_memory
                      WHERE created_at < datetime('now', ?)
                        AND (is_summary = 0 OR is_summary IS NULL)
                      LIMIT 1000
                 )
                """,
                (cutoff,),
            )
            await db.commit()
            n = cur.rowcount or 0
            total += n
            if n < 1000:
                break
    except Exception:
        await db.rollback()
        raise
    return total


# --- Wake words -------------------------------------------------------------

async def talkative_get_wake_words(chat_id: int | None = None) -> list[dict[str, Any]]:
    """Return wake words for a chat (or global if chat_id is None).

    Always returns global wake words (chat_id IS NULL) plus chat-specific
    ones when ``chat_id`` is provided.
    """
    db = await get_db()
    if chat_id is None:
        async with db.execute(
            "SELECT * FROM talkative_wake_words WHERE chat_id IS NULL "
            "AND enabled = 1 ORDER BY id"
        ) as cur:
            rows = await cur.fetchall()
    else:
        async with db.execute(
            "SELECT * FROM talkative_wake_words "
            "WHERE enabled = 1 AND (chat_id IS NULL OR chat_id = ?) "
            "ORDER BY id",
            (chat_id,),
        ) as cur:
            rows = await cur.fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["enabled"] = bool(d.get("enabled", 0))
        out.append(d)
    return out


async def talkative_add_wake_word(chat_id: int | None, word: str) -> int:
    """Add a wake word. Returns the (new or re-enabled) row id.

    DB-B-016: cap wake-word length at 64 chars and use ON CONFLICT to
    re-enable a previously-disabled duplicate instead of raising a UNIQUE
    error.  The (chat_id, wake_word) UNIQUE constraint is enforced by the
    schema (new installs) and by the idx_talkative_wake_words_unique
    migration (existing installs).
    """
    word = (word or "").strip().lower()
    if not word:
        return 0
    if len(word) > 64:
        raise ValueError(
            f"talkative_add_wake_word: word too long ({len(word)} > 64 chars)"
        )
    db = await get_db()
    # DB-B-001: wrap INSERT + commit so a failure rolls the transaction back.
    try:
        cur = await db.execute(
            "INSERT INTO talkative_wake_words (chat_id, wake_word, enabled) "
            "VALUES (?, ?, 1) "
            "ON CONFLICT(chat_id, wake_word) DO UPDATE SET enabled = 1",
            (chat_id, word),
        )
        await db.commit()
    except Exception:
        await db.rollback()
        raise
    return cur.lastrowid  # type: ignore[return-value]


async def talkative_remove_wake_word(word_id: int) -> bool:
    """Delete a wake word by id. Returns True if a row was deleted."""
    db = await get_db()
    cur = await db.execute(
        "DELETE FROM talkative_wake_words WHERE id = ?", (int(word_id),)
    )
    await db.commit()
    return (cur.rowcount or 0) > 0


# ===========================================================================
# Services — i18n
# ===========================================================================

# (v99.07 FIX-28: this section's module-level imports — hashlib, random,
# re, concurrent.futures, OrderedDict — were hoisted to the top of the
# file; no module-level imports live mid-file any more.)

# Dedicated bounded executor for Gemini (sync SDK) calls — prevents a single
# slow AI request from starving the default executor. (ASYNC-C-001)
_AI_EXECUTOR = concurrent.futures.ThreadPoolExecutor(
    max_workers=8, thread_name_prefix="gemini"
)

# Whitelist for ffmpeg ``-vf scale=W:H`` argument. (SEC-C-001)
_SCALE_RE = re.compile(r"^\d{1,5}:\d{1,5}$")




# ===========================================================================
# repo — convenience namespace alias for all database repository functions.
# Moved here from _bot_core.py so that all subsystems (voicechat, talkative,
# handlers, etc.) can import it directly from db_layer without a cycle.
# v99.07 FIX-27: the namespace now exposes EVERY public repository function
# defined in this module (media_cache_*, the vc keyset/count/delete/fresh/
# stale/knowledge helpers, and the whole talkative_* family were missing —
# ~30 functions); `repo.<fn>` no longer AttributeErrors for half the module.
# ===========================================================================

repo = SimpleNamespace(
    upsert_user=upsert_user, ensure_settings=ensure_settings, update_setting=update_setting, create_task=create_task,
    update_task=update_task, add_download_history=add_download_history, recent_downloads=recent_downloads, add_ai_history=add_ai_history,
    recent_ai_analyses=recent_ai_analyses, clear_history=clear_history, stats=stats, add_library_entry=add_library_entry,
    library_entries=library_entries, library_search=library_search, library_count=library_count, library_remove=library_remove,
    library_clear=library_clear, add_inspected_chat=add_inspected_chat, recent_inspected=recent_inspected, user_daily_download_usage=user_daily_download_usage,
    user_stats=user_stats, global_stats=global_stats, add_scheduled_task=add_scheduled_task, pending_scheduled_tasks=pending_scheduled_tasks,
    list_scheduled_tasks=list_scheduled_tasks, update_scheduled_task=update_scheduled_task, cancel_scheduled_task=cancel_scheduled_task, create_broadcast=create_broadcast,
    update_broadcast_counts=update_broadcast_counts, recent_broadcasts=recent_broadcasts, all_users=all_users, user_count=user_count,
    export_user_data=export_user_data, restore_user_settings=restore_user_settings, vc_upsert_group=vc_upsert_group, vc_groups_active=vc_groups_active,
    vc_groups_all=vc_groups_all, vc_add_visit=vc_add_visit, vc_update_visit=vc_update_visit, vc_recent_visits=vc_recent_visits,
    vc_visit_count=vc_visit_count, vc_get_tour_state=vc_get_tour_state, vc_save_tour_state=vc_save_tour_state, vc_visited_group_ids_since=vc_visited_group_ids_since,
    vc_get_settings=vc_get_settings, vc_update_settings=vc_update_settings, media_cache_lookup=media_cache_lookup, media_cache_store=media_cache_store,
    media_cache_cleanup=media_cache_cleanup, vc_groups_fresh_active=vc_groups_fresh_active, vc_groups_stale_active=vc_groups_stale_active, vc_knowledge_store_active=vc_knowledge_store_active,
    vc_knowledge_mark_inactive=vc_knowledge_mark_inactive, vc_delete_group=vc_delete_group, vc_group_count=vc_group_count, vc_groups_keyset=vc_groups_keyset,
    vc_groups_keyset_stream=vc_groups_keyset_stream, talkative_get_global_settings=talkative_get_global_settings, talkative_update_global_settings=talkative_update_global_settings, talkative_effective_enabled=talkative_effective_enabled,
    talkative_effective_provider=talkative_effective_provider, talkative_apply_effective_runtime=talkative_apply_effective_runtime, talkative_get_chat_settings=talkative_get_chat_settings, talkative_set_chat_setting=talkative_set_chat_setting,
    talkative_effective_settings=talkative_effective_settings, talkative_start_session=talkative_start_session, talkative_touch_session=talkative_touch_session, talkative_get_active_session=talkative_get_active_session,
    talkative_end_session=talkative_end_session, talkative_add_memory=talkative_add_memory, talkative_get_memory=talkative_get_memory, talkative_trim_memory=talkative_trim_memory,
    talkative_clear_memory=talkative_clear_memory, talkative_add_stat=talkative_add_stat, talkative_cleanup_expired_sessions=talkative_cleanup_expired_sessions, talkative_cleanup_old_memory=talkative_cleanup_old_memory,
    talkative_get_wake_words=talkative_get_wake_words, talkative_add_wake_word=talkative_add_wake_word, talkative_remove_wake_word=talkative_remove_wake_word,
)
