"""
v97.56: Per-chat VC operation/state coordinator.
v97.58: BUG FIXES + FULL API for authoritative integration.

This module provides ONE authoritative per-chat state machine that all VC
operations must flow through. It replaces the distributed state across
_vc_state, _vc_participations, _vc_in_flight_joins, _vc_active_join_backends_by_chat,
and _vc_op_locks.

State machine:
    IDLE → RESOLVING → JOINING → JOINED → VERIFYING → ACTIVE → LEAVING → LEFT
                    ↘ FAILED ↗                    ↘ RECOVERING ↗
                                                                    ↘ UNKNOWN
                    ↘ DEFERRED (network/stale/breaker — wait, not fail)
                    ↘ CANCELLED (user/recovery cancelled — terminal until reset)

Key invariants:
- Exactly ONE authoritative owner of the current operation for each chat.
- No subsystem may independently mutate VC state behind the coordinator.
- A stale operation from generation N must NEVER modify state belonging to generation N+1.
- Different chats remain concurrently processable (no global serialization).
- UNKNOWN must NEVER equal LEFT (reconcile non-destructiveness — §19).
- Only POSITIVE evidence of absence may transition JOINED → LEFT.

v97.58 BUG FIXES (root-caused from source):
  BUG-1: Generation conflation. ``complete_operation`` compared ``op.client_generation``
         (the Telegram CLIENT generation) against ``_chat_generations[chat_id]`` (the
         CHAT OPERATION generation). These are different counters, so the stale-completion
         guard almost never fired. FIX: store the chat op-generation in the operation at
         ``begin_operation`` time and compare against THAT.
  BUG-2: Missing DEFERRED + CANCELLED states (master prompt §10/§13/§16 require them).
         DEFERRED = network/stale/breaker — wait, do not burn breaker attempts.
         CANCELLED = user/cancellation — terminal until explicitly reset.
  BUG-3: No ``backend_generation`` field (master prompt §10 requires both
         client_generation AND backend_generation for ownership).
  BUG-4: No ``cancel_operation`` API (cancellation-safety §12 requires a way to mark
         an in-flight op cancelled so a newer op can begin).
  BUG-5: No reconcile non-destructive API (§19 requires ``mark_unknown`` /
         ``mark_deferred`` that NEVER transitions JOINED→LEFT without positive evidence).
  BUG-6: No coalescing (§22 requires JOIN+JOIN+JOIN → one desired-state JOIN). The
         ``begin_operation`` returned ``busy`` for a 2nd JOIN, forcing callers to treat
         it as a skip/error. Added ``coalesce_or_begin`` which returns ``coalesced`` for
         idempotent same-direction ops so the caller can ack-and-drop.
  BUG-7: ``_get_lock`` created per-chat locks without a master guard. asyncio is
         single-threaded so the window is zero between ``get`` and ``set`` (no await
         in between), but the pattern is fragile. Hardened with ``setdefault``.
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from typing import Any, Optional
from enum import Enum

logger = logging.getLogger("mediagrab")


class VCChatState(Enum):
    """Per-chat VC operation state (master prompt §10 + v97.58 DEFERRED/CANCELLED)."""
    IDLE = "idle"
    RESOLVING = "resolving"
    JOINING = "joining"
    JOINED = "joined"
    VERIFYING = "verifying"
    ACTIVE = "active"
    LEAVING = "leaving"
    LEFT = "left"
    FAILED = "failed"
    DEFERRED = "deferred"          # v97.58: network/stale/breaker — wait, not fail
    RECOVERING = "recovering"
    UNKNOWN = "unknown"
    CANCELLED = "cancelled"        # v97.58: user/recovery cancelled — terminal until reset


# States that represent a successful join (coalesce-or-begin allows a 2nd JOIN to ack).
_JOINED_STATES = frozenset({VCChatState.JOINED, VCChatState.ACTIVE, VCChatState.VERIFYING})

# States where a new JOIN is genuinely in-progress (must NOT coalesce — wait or fail).
_JOIN_INFLIGHT_STATES = frozenset({VCChatState.RESOLVING, VCChatState.JOINING})

# Terminal states (operation is done, no active op).
_TERMINAL_STATES = frozenset({
    VCChatState.IDLE, VCChatState.LEFT, VCChatState.FAILED,
    VCChatState.UNKNOWN, VCChatState.DEFERRED, VCChatState.CANCELLED,
})


class VCOperation:
    """A single VC operation (join/leave/verify/reconcile).

    v97.58 FIX BUG-3: added ``backend_generation`` (master prompt §10).
    v97.58 FIX BUG-1: added ``op_generation`` — the chat's operation generation
    captured at begin time, used for stale-completion detection (NOT client_generation).
    """
    __slots__ = ("operation_id", "chat_id", "account_id", "client_generation",
                 "backend_generation", "operation_type", "started_at", "deadline",
                 "attempt", "state", "op_generation", "source")

    def __init__(self, chat_id: int, operation_type: str,
                 account_id: str = "", client_generation: int = 0,
                 backend_generation: int = 0,
                 deadline: float = 60.0, attempt: int = 1,
                 source: str = ""):
        self.operation_id = str(uuid.uuid4())[:8]
        self.chat_id = chat_id
        self.account_id = account_id
        self.client_generation = client_generation
        self.backend_generation = backend_generation   # v97.58 BUG-3
        self.operation_type = operation_type  # join/leave/verify/reconcile
        self.started_at = time.monotonic()
        self.deadline = deadline
        self.attempt = attempt
        self.state = "pending"
        self.op_generation = 0   # v97.58 BUG-1: set by coordinator at begin time
        self.source = source     # v97.58: caller tag (join_all/watcher/tour/manual/...)


# Per-chat state coordinator
class VCChatCoordinator:
    """Manages per-chat VC state, operations, and serialization.

    For each chat_id, there is exactly ONE current state + ONE active operation.
    Operations are serialized per-chat (different chats run concurrently).

    v97.58: All mutations happen under the per-chat lock. State transitions are
    classified (DEFERRED vs FAILED vs UNKNOWN) so callers can distinguish
    "wait and retry" from "genuine failure" from "uncertain — preserve".
    """

    def __init__(self):
        self._chat_states: dict[int, VCChatState] = {}
        self._chat_ops: dict[int, VCOperation] = {}  # active operation per chat
        self._chat_locks: dict[int, asyncio.Lock] = {}
        self._chat_op_generations: dict[int, int] = {}  # incremented per op (BUG-1)
        self._master_lock = asyncio.Lock()
        # v97.58: observability counters
        self._counters: dict[str, int] = {
            "begin": 0, "complete_ok": 0, "complete_stale": 0,
            "fail": 0, "cancel": 0, "coalesce": 0, "defer": 0, "mark_unknown": 0,
            "mark_deferred": 0, "record_absent": 0,
        }

    def _get_lock(self, chat_id: int) -> asyncio.Lock:
        """Get or create the per-chat lock.

        v97.58 FIX BUG-7: hardened with setdefault. asyncio is single-threaded so
        the original get-then-set was technically safe, but setdefault is the
        canonical atomic pattern and removes the fragility.
        """
        lock = self._chat_locks.get(chat_id)
        if lock is None:
            lock = asyncio.Lock()
            # setdefault is atomic in CPython; if a concurrent task already inserted
            # one, use theirs (they're functionally equivalent).
            existing = self._chat_locks.setdefault(chat_id, lock)
            if existing is not lock:
                lock = existing
        return lock

    def get_state(self, chat_id: int) -> VCChatState:
        """Get the current state for a chat."""
        return self._chat_states.get(chat_id, VCChatState.IDLE)

    def get_active_op(self, chat_id: int) -> Optional[VCOperation]:
        """Get the active operation for a chat, if any."""
        return self._chat_ops.get(chat_id)

    def get_op_generation(self, chat_id: int) -> int:
        """Get the current chat operation generation (v97.58 BUG-1: chat op-gen, not client gen)."""
        return self._chat_op_generations.get(chat_id, 0)

    def is_busy(self, chat_id: int) -> bool:
        """Check if a chat has an active operation."""
        return chat_id in self._chat_ops

    async def begin_operation(self, chat_id: int, operation_type: str,
                               account_id: str = "", client_generation: int = 0,
                               backend_generation: int = 0,
                               deadline: float = 60.0,
                               source: str = "") -> tuple[bool, Optional[VCOperation], str]:
        """Begin a VC operation for a chat.

        Returns (success, operation, reason).
        - (True, op, "ok") — operation began; caller MUST complete/fail it.
        - (False, None, "busy:<op>") — another op is in progress and not stale.
        - (False, None, "coalesced:<op>") — same-direction op in flight; caller may ack-and-drop.
        - (False, None, "already_<state>") — desired state already reached (idempotent skip).

        v97.58: if the current op has exceeded its deadline, it's reclaimed
        (state → RECOVERING) and the new op begins. This prevents a stuck op
        from blocking a chat forever.
        """
        self._counters["begin"] += 1
        async with self._get_lock(chat_id):
            current_op = self._chat_ops.get(chat_id)
            if current_op is not None:
                # Check if the current op has exceeded its deadline
                elapsed = time.monotonic() - current_op.started_at
                if elapsed > current_op.deadline:
                    # Stale operation — reclaim
                    logger.warning(
                        "VC_COORDINATOR_STALE_OP chat_id=%s op=%s elapsed=%.1fs deadline=%.1fs — reclaiming",
                        chat_id, current_op.operation_type, elapsed, current_op.deadline,
                    )
                    self._chat_ops.pop(chat_id, None)
                    self._chat_states[chat_id] = VCChatState.RECOVERING
                else:
                    # v97.58 FIX BUG-6: coalesce same-direction idempotent ops.
                    if (current_op.operation_type == operation_type
                            and operation_type in ("join", "leave", "verify")):
                        self._counters["coalesce"] += 1
                        return False, None, f"coalesced:{operation_type}"
                    return False, None, f"busy:{current_op.operation_type}"

            # v97.58: idempotent skip — if desired state already reached, ack.
            cur_state = self._chat_states.get(chat_id, VCChatState.IDLE)
            if operation_type == "join" and cur_state in _JOINED_STATES:
                return False, None, f"already_{cur_state.value}"
            if operation_type == "leave" and cur_state in (VCChatState.LEFT, VCChatState.IDLE):
                return False, None, f"already_{cur_state.value}"

            # Increment chat operation generation (BUG-1: this is the op-gen, not client gen)
            gen = self._chat_op_generations.get(chat_id, 0) + 1
            self._chat_op_generations[chat_id] = gen

            op = VCOperation(
                chat_id=chat_id, operation_type=operation_type,
                account_id=account_id, client_generation=client_generation,
                backend_generation=backend_generation,
                deadline=deadline, source=source,
            )
            op.op_generation = gen   # v97.58 BUG-1: capture for stale-completion check
            self._chat_ops[chat_id] = op

            # Transition state
            if operation_type == "join":
                self._chat_states[chat_id] = VCChatState.JOINING
            elif operation_type == "leave":
                self._chat_states[chat_id] = VCChatState.LEAVING
            elif operation_type == "verify":
                self._chat_states[chat_id] = VCChatState.VERIFYING
            elif operation_type == "reconcile":
                self._chat_states[chat_id] = VCChatState.RECOVERING

            logger.info(
                "VC_COORDINATOR_OP_START op_id=%s chat_id=%s op=%s op_gen=%d "
                "client_gen=%d backend_gen=%d account=%s source=%s",
                op.operation_id, chat_id, operation_type, gen,
                client_generation, backend_generation, account_id, source or "?",
            )
            return True, op, "ok"

    async def complete_operation(self, chat_id: int, op: VCOperation,
                                  success: bool, new_state: VCChatState,
                                  result_detail: str = "") -> bool:
        """Complete a VC operation. Returns True if the operation was still current.

        v97.58 FIX BUG-1: the stale-completion check now compares ``op.op_generation``
        (the chat op-gen captured at begin) against the CURRENT chat op-gen. If a
        newer op began in the meantime, this completion is STALE and rejected —
        the state is NOT mutated. The old code compared against ``op.client_generation``
        which was a different counter and almost never matched, making this guard
        dead code.
        """
        async with self._get_lock(chat_id):
            current_op = self._chat_ops.get(chat_id)
            if current_op is None or current_op.operation_id != op.operation_id:
                self._counters["complete_stale"] += 1
                logger.warning(
                    "VC_COORDINATOR_STALE_COMPLETION op_id=%s chat_id=%s — op no longer current, rejecting",
                    op.operation_id, chat_id,
                )
                return False

            # v97.58 FIX BUG-1: compare op_generation (chat op-gen), NOT client_generation.
            current_gen = self._chat_op_generations.get(chat_id, 0)
            if op.op_generation != current_gen:
                self._counters["complete_stale"] += 1
                logger.warning(
                    "VC_COORDINATOR_GENERATION_MISMATCH op_id=%s chat_id=%s op_gen=%d current_gen=%d — rejecting",
                    op.operation_id, chat_id, op.op_generation, current_gen,
                )
                return False

            # Complete the operation
            self._chat_ops.pop(chat_id, None)
            self._chat_states[chat_id] = new_state

            self._counters["complete_ok" if success else "fail"] += 1
            elapsed = time.monotonic() - op.started_at
            logger.info(
                "VC_COORDINATOR_OP_COMPLETE op_id=%s chat_id=%s op=%s success=%s "
                "new_state=%s elapsed=%.1fs detail=%s",
                op.operation_id, chat_id, op.operation_type, success,
                new_state.value, elapsed, result_detail[:100],
            )
            return True

    async def fail_operation(self, chat_id: int, op: VCOperation,
                              reason: str, recoverable: bool = True,
                              deferred: bool = False) -> None:
        """Fail a VC operation. Sets state to FAILED, RECOVERING, or DEFERRED.

        v97.58: ``deferred=True`` → DEFERRED (network/stale/breaker — wait, not fail).
        ``recoverable=True`` (default) → RECOVERING (retry allowed).
        ``recoverable=False`` → FAILED (genuine failure).
        """
        async with self._get_lock(chat_id):
            current_op = self._chat_ops.get(chat_id)
            if current_op is None or current_op.operation_id != op.operation_id:
                return  # stale — silently drop (a newer op owns this chat now)

            self._chat_ops.pop(chat_id, None)
            if deferred:
                self._chat_states[chat_id] = VCChatState.DEFERRED
                self._counters["defer"] += 1
            elif recoverable:
                self._chat_states[chat_id] = VCChatState.RECOVERING
            else:
                self._chat_states[chat_id] = VCChatState.FAILED

            logger.warning(
                "VC_COORDINATOR_OP_FAILED op_id=%s chat_id=%s op=%s reason=%s "
                "recoverable=%s deferred=%s",
                op.operation_id, chat_id, op.operation_type, reason, recoverable, deferred,
            )

    async def cancel_operation(self, chat_id: int, op: VCOperation,
                                reason: str = "") -> bool:
        """v97.58 FIX BUG-4: Cancel an in-flight operation.

        Cancellation is terminal for THIS op — the chat transitions to CANCELLED
        until a newer op resets it via ``begin_operation``. This allows a recovery
        flow to cancel a stuck join and start a fresh one.

        Returns True if the op was still current and got cancelled.
        """
        async with self._get_lock(chat_id):
            current_op = self._chat_ops.get(chat_id)
            if current_op is None or current_op.operation_id != op.operation_id:
                return False  # stale
            self._chat_ops.pop(chat_id, None)
            self._chat_states[chat_id] = VCChatState.CANCELLED
            self._counters["cancel"] += 1
            logger.info(
                "VC_COORDINATOR_OP_CANCELLED op_id=%s chat_id=%s op=%s reason=%s",
                op.operation_id, chat_id, op.operation_type, reason,
            )
            return True

    # ── v97.58 FIX BUG-5: reconcile non-destructive APIs (master prompt §19) ──

    async def mark_unknown(self, chat_id: int, reason: str = "") -> None:
        """Mark a chat's state as UNKNOWN — NEVER transitions JOINED→LEFT.

        Per §19: UNKNOWN must NEVER equal LEFT. Only POSITIVE evidence of absence
        (via ``record_evidence_absent``) may transition JOINED→LEFT. All uncertain
        conditions (MTProto disconnected, network unavailable, entity timeout,
        stale client, PyTgCalls timeout, verification timeout, callback timeout,
        reconnecting, uncertain participant result) transition to UNKNOWN.

        Idempotent: calling on an already-UNKNOWN chat is a no-op.
        """
        async with self._get_lock(chat_id):
            cur = self._chat_states.get(chat_id, VCChatState.IDLE)
            if cur == VCChatState.LEFT:
                # Never downgrade LEFT→UNKNOWN; LEFT is positive evidence already.
                return
            self._chat_states[chat_id] = VCChatState.UNKNOWN
            self._counters["mark_unknown"] += 1
            logger.info("VC_COORDINATOR_MARK_UNKNOWN chat_id=%s prev=%s reason=%s",
                        chat_id, cur.value, reason[:80])

    async def mark_deferred(self, chat_id: int, reason: str = "") -> None:
        """Mark a chat as DEFERRED — network/stale/breaker; wait, do not fail.

        Per §13/§16: when client disconnected, network unavailable, stale client,
        or breaker open, the target is DEFERRED not FAILED. The breaker must NOT
        record_failure for deferred states.
        """
        async with self._get_lock(chat_id):
            self._chat_states[chat_id] = VCChatState.DEFERRED
            self._counters["mark_deferred"] += 1
            logger.info("VC_COORDINATOR_MARK_DEFERRED chat_id=%s reason=%s",
                        chat_id, reason[:80])

    async def record_evidence_absent(self, chat_id: int, evidence: str = "") -> bool:
        """Record POSITIVE evidence that the bot is NOT in the VC.

        Per §19: ONLY positive evidence of absence may transition to LEFT.
        Resolves uncertainty: JOINED/ACTIVE/VERIFYING/RECOVERING/UNKNOWN/DEFERRED → LEFT.
        No-op on IDLE (never joined), LEFT (already left), FAILED/CANCELLED (those
        represent operation outcomes, not participation state — preserved as-is).

        Returns True if the transition to LEFT was applied.
        """
        async with self._get_lock(chat_id):
            cur = self._chat_states.get(chat_id, VCChatState.IDLE)
            # Positive evidence of absence resolves uncertainty → LEFT.
            if cur in _JOINED_STATES or cur in (
                    VCChatState.RECOVERING, VCChatState.UNKNOWN, VCChatState.DEFERRED):
                self._chat_states[chat_id] = VCChatState.LEFT
                self._counters["record_absent"] += 1
                logger.info(
                    "VC_COORDINATOR_EVIDENCE_ABSENT chat_id=%s prev=%s evidence=%s → LEFT",
                    chat_id, cur.value, evidence[:80],
                )
                return True
            return False

    async def mark_joined(self, chat_id: int, detail: str = "") -> None:
        """Mark a chat as JOINED after a successful join+verify.

        Use this from the join path's success branch to record the authoritative
        JOINED state. Idempotent.
        """
        async with self._get_lock(chat_id):
            self._chat_states[chat_id] = VCChatState.JOINED
            logger.info("VC_COORDINATOR_MARK_JOINED chat_id=%s detail=%s",
                        chat_id, detail[:80])

    async def reset_to_idle(self, chat_id: int) -> None:
        """Reset a chat to IDLE. Use after a confirmed leave or shutdown."""
        async with self._get_lock(chat_id):
            self._chat_ops.pop(chat_id, None)
            self._chat_states[chat_id] = VCChatState.IDLE

    # ── pre-flight checks (no state mutation) ──

    def can_join(self, chat_id: int) -> tuple[bool, str]:
        """Check if a join is allowed for this chat (pre-flight)."""
        state = self.get_state(chat_id)
        if self.is_busy(chat_id):
            op = self._chat_ops.get(chat_id)
            return False, f"busy:{op.operation_type if op else 'unknown'}"
        if state in _JOINED_STATES:
            return False, "already_joined"
        if state in _JOIN_INFLIGHT_STATES:
            return False, f"state:{state.value}"
        return True, "ok"

    def can_leave(self, chat_id: int) -> tuple[bool, str]:
        """Check if a leave is allowed for this chat (pre-flight)."""
        state = self.get_state(chat_id)
        if self.is_busy(chat_id):
            op = self._chat_ops.get(chat_id)
            return False, f"busy:{op.operation_type if op else 'unknown'}"
        if state in (VCChatState.IDLE, VCChatState.LEFT, VCChatState.LEAVING):
            return False, f"state:{state.value}"
        return True, "ok"

    def get_stats(self) -> dict[str, Any]:
        """Get coordinator stats for observability."""
        state_counts: dict[str, int] = {}
        for state in self._chat_states.values():
            state_counts[state.value] = state_counts.get(state.value, 0) + 1
        return {
            "total_chats": len(self._chat_states),
            "active_ops": len(self._chat_ops),
            "state_distribution": state_counts,
            "counters": dict(self._counters),
        }


# Global singleton
_vc_coordinator: VCChatCoordinator | None = None


def get_vc_coordinator() -> VCChatCoordinator:
    """Get the global VCChatCoordinator singleton."""
    global _vc_coordinator
    if _vc_coordinator is None:
        _vc_coordinator = VCChatCoordinator()
    return _vc_coordinator


def reset_vc_coordinator() -> None:
    """Reset the global coordinator (testing / clean shutdown)."""
    global _vc_coordinator
    _vc_coordinator = None
