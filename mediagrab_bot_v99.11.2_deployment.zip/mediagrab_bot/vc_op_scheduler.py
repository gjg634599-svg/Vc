"""
v97.59: VC operation scheduler — fast-ack vs long-op separation.

ARCHITECTURE (master prompt §5/§17/§21/§22):

Telegram callbacks must NEVER remain occupied for a long-running VC operation.
A callback should:
  1. validate + coalesce
  2. immediately acknowledge (Telegram answer_callback_query)
  3. submit a bounded operation to the VC scheduler
  4. return quickly

The user receives state updates asynchronously:
  QUEUED → STARTING → WAITING_FOR_NETWORK → JOINING → VERIFYING → JOINED
         → DEFERRED / RETRYING / FAILED

This module provides:

  VCOperationScheduler — bounded-concurrency, per-chat-serialized, fair
                         scheduler for VC operations (join/leave/verify).

Key features:
  - Per-chat serialization (different chats run concurrently)
  - Per-account concurrency cap (bounded, prevents unbounded task creation)
  - Fair scheduling across chats (round-robin, no starvation)
  - Operation deadlines (bounded; no operation runs forever)
  - Cancellation-safe (cancel propagates to the in-flight operation)
  - Critical commands never silently lost (parked if scheduler saturated)
  - Per-operation metrics (duration, result, deadline)
  - Backpressure integration (reduces concurrency when event-loop lags)

Integrates with vc_state_coordinator (authoritative state owner).
"""
from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Awaitable, Callable, Optional

logger = logging.getLogger("mediagrab")


class OpStatus(Enum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"
    DEFERRED = "deferred"          # network/stale/breaker — wait, not fail


@dataclass
class VCOpRequest:
    """A VC operation request submitted to the scheduler."""
    op_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    chat_id: int = 0
    account_id: str = ""
    op_type: str = ""           # join / leave / verify / reconcile
    source: str = ""            # callback / command / watcher / join_all
    fn: Optional[Callable[["VCOpRequest"], Awaitable[bool]]] = None
    deadline: float = 90.0
    submitted_at: float = field(default_factory=time.monotonic)
    started_at: float = 0.0
    completed_at: float = 0.0
    status: OpStatus = OpStatus.QUEUED
    error: str = ""
    # Coalescing key — ops with the same (chat_id, op_type) coalesce.
    # A 2nd QUEUED op for the same key replaces the 1st QUEUED op (latest wins).

    def coalesce_key(self) -> tuple[int, str]:
        return (self.chat_id, self.op_type)

    def age(self) -> float:
        return time.monotonic() - self.submitted_at


class VCOperationScheduler:
    """Bounded-concurrency, per-chat-serialized, fair VC operation scheduler.

    - Per-chat serialization: at most one RUNNING op per chat_id.
    - Per-account concurrency cap: at most N concurrent ops per account_id.
    - Fair: round-robin across chats (FIFO per chat, round-robin across chats).
    - Bounded queue: ops beyond the queue cap are coalesced (latest wins) for
      idempotent ops, or rejected for non-idempotent ops.
    - Critical ops (join/leave) never silently lost — parked if scheduler saturated.
    """

    def __init__(self, account_concurrency: int = 3, queue_cap: int = 200):
        self.account_concurrency = account_concurrency
        self.queue_cap = queue_cap
        # Per-account semaphores (created on demand).
        self._account_sems: dict[str, asyncio.Semaphore] = {}
        # Per-chat locks (serialization).
        self._chat_locks: dict[int, asyncio.Lock] = {}
        # Per-chat QUEUED ops (for coalescing — only the latest QUEUED op per chat+type).
        self._queued: dict[tuple[int, str], VCOpRequest] = {}
        # Fair-scheduling queue: (round_robin_counter, chat_id, op_type) -> op
        self._fair_queue: asyncio.Queue[tuple[int, VCOpRequest]] = asyncio.Queue()
        self._rr_counter = 0
        # Metrics.
        self._metrics: dict[str, int] = {
            "submitted": 0, "coalesced": 0, "parked": 0, "expired": 0,
            "started": 0, "success": 0, "failed": 0, "cancelled": 0, "timeout": 0,
            "deferred": 0,
        }
        # Per-op-type duration tracking (for p95/p99).
        self._durations: dict[str, list[float]] = {}
        self._running: int = 0
        self._stopping = False
        self._workers: list[asyncio.Task] = []

    def _get_account_sem(self, account_id: str) -> asyncio.Semaphore:
        sem = self._account_sems.get(account_id)
        if sem is None:
            sem = asyncio.Semaphore(self.account_concurrency)
            self._account_sems[account_id] = sem
        return sem

    def _get_chat_lock(self, chat_id: int) -> asyncio.Lock:
        lock = self._chat_locks.get(chat_id)
        if lock is None:
            lock = asyncio.Lock()
            self._chat_locks[chat_id] = lock
        return lock

    def submit(self, req: VCOpRequest) -> bool:
        """Submit a VC operation. Returns True if accepted (queued or coalesced).

        Coalescing: if a QUEUED op with the same (chat_id, op_type) exists, the
        new op REPLACES it (latest state wins). Returns True (coalesced).
        For RUNNING ops, the new op is queued (will run after the current one).
        """
        if self._stopping:
            logger.debug("VC_SCHED_SUBMIT_REJECTED reason=stopping op_id=%s", req.op_id)
            return False
        self._metrics["submitted"] += 1
        key = req.coalesce_key()
        # Coalesce: if a QUEUED op for the same chat+type exists, replace it.
        existing = self._queued.get(key)
        if existing is not None and existing.status == OpStatus.QUEUED:
            self._metrics["coalesced"] += 1
            logger.info(
                "VC_SCHED_COALESCE op_id=%s replaces=%s chat=%s type=%s",
                req.op_id, existing.op_id, req.chat_id, req.op_type,
            )
            # Replace in the fair queue (mark old as coalesced-away).
            existing.status = OpStatus.CANCELLED
            existing.error = "coalesced"
        self._queued[key] = req
        self._rr_counter += 1
        try:
            self._fair_queue.put_nowait((self._rr_counter, req))
            return True
        except asyncio.QueueFull:
            # Should never happen (queue_cap is large), but handle gracefully.
            self._metrics["parked"] += 1
            logger.warning(
                "VC_SCHED_QUEUE_FULL op_id=%s chat=%s type=%s — parked (coalesced in _queued)",
                req.op_id, req.chat_id, req.op_type,
            )
            return True  # parked in _queued; worker will pick it up

    async def _worker(self) -> None:
        """Worker: pulls ops from the fair queue, runs them with per-chat
        serialization + per-account concurrency cap."""
        while not self._stopping:
            try:
                _, req = await self._fair_queue.get()
                if self._stopping:
                    req.status = OpStatus.CANCELLED
                    req.error = "scheduler_stopping"
                    self._fair_queue.task_done()
                    continue
                # Skip coalesced-away ops.
                if req.status == OpStatus.CANCELLED:
                    self._fair_queue.task_done()
                    continue
                # Skip expired ops (deadline passed while queued).
                if req.age() > req.deadline:
                    req.status = OpStatus.TIMEOUT
                    req.error = "expired_in_queue"
                    self._metrics["expired"] += 1
                    self._queued.pop(req.coalesce_key(), None)
                    self._fair_queue.task_done()
                    continue
                # Per-account concurrency cap.
                async with self._get_account_sem(req.account_id):
                    # Per-chat serialization.
                    async with self._get_chat_lock(req.chat_id):
                        await self._run_op(req)
                self._fair_queue.task_done()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                logger.warning("VC_SCHED_WORKER_ERROR exc=%s", str(exc)[:120])

    async def _run_op(self, req: VCOpRequest) -> None:
        """Run a single VC operation with deadline + cancellation safety."""
        req.started_at = time.monotonic()
        req.status = OpStatus.RUNNING
        self._metrics["started"] += 1
        self._running += 1
        # Remove from queued (it's now running).
        self._queued.pop(req.coalesce_key(), None)
        try:
            remaining = max(1.0, req.deadline - req.age())
            result = await asyncio.wait_for(req.fn(req), timeout=remaining)
            req.completed_at = time.monotonic()
            if result:
                req.status = OpStatus.SUCCESS
                self._metrics["success"] += 1
            else:
                req.status = OpStatus.FAILED
                self._metrics["failed"] += 1
        except asyncio.TimeoutError:
            req.completed_at = time.monotonic()
            req.status = OpStatus.TIMEOUT
            req.error = "deadline_exceeded"
            self._metrics["timeout"] += 1
            logger.warning(
                "VC_SCHED_OP_TIMEOUT op_id=%s chat=%s type=%s deadline=%.1fs",
                req.op_id, req.chat_id, req.op_type, req.deadline,
            )
        except asyncio.CancelledError:
            req.completed_at = time.monotonic()
            req.status = OpStatus.CANCELLED
            req.error = "cancelled"
            self._metrics["cancelled"] += 1
            raise
        except Exception as exc:  # noqa: BLE001
            req.completed_at = time.monotonic()
            req.status = OpStatus.FAILED
            req.error = f"{type(exc).__name__}: {exc}"
            self._metrics["failed"] += 1
            logger.warning(
                "VC_SCHED_OP_ERROR op_id=%s chat=%s type=%s exc=%s",
                req.op_id, req.chat_id, req.op_type, req.error[:120],
            )
        finally:
            self._running -= 1
            # Duration tracking.
            dur = req.completed_at - req.started_at if req.completed_at else 0
            self._durations.setdefault(req.op_type, []).append(dur)
            # Keep only last 100 samples per type.
            if len(self._durations[req.op_type]) > 100:
                self._durations[req.op_type] = self._durations[req.op_type][-100:]
            logger.info(
                "VC_SCHED_OP_DONE op_id=%s chat=%s type=%s status=%s "
                "duration=%.1fs error=%s",
                req.op_id, req.chat_id, req.op_type, req.status.value,
                dur, req.error[:80],
            )

    def start(self, num_workers: int = 2) -> None:
        """Start the scheduler workers (idempotent)."""
        if self._workers:
            return
        self._stopping = False
        for i in range(num_workers):
            t = asyncio.create_task(self._worker(), name=f"vc_op_scheduler_w{i}")
            self._workers.append(t)
        logger.info("VC_SCHEDULER_STARTED workers=%d account_concurrency=%d",
                    num_workers, self.account_concurrency)

    async def stop(self, timeout: float = 10.0) -> None:
        """Stop the scheduler (idempotent, bounded). Cancels all workers + drains."""
        self._stopping = True
        # Cancel all workers.
        for t in self._workers:
            if not t.done():
                t.cancel()
        # Await termination.
        for t in self._workers:
            try:
                await asyncio.wait_for(t, timeout=timeout)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                pass
        self._workers.clear()
        # Mark remaining queued ops as cancelled.
        for req in self._queued.values():
            if req.status == OpStatus.QUEUED:
                req.status = OpStatus.CANCELLED
                req.error = "scheduler_stopped"
        self._queued.clear()
        logger.info("VC_SCHEDULER_STOPPED")

    def get_metrics(self) -> dict[str, Any]:
        """Return scheduler metrics for observability."""
        import statistics
        durations: dict[str, dict[str, float]] = {}
        for op_type, samples in self._durations.items():
            if not samples:
                continue
            sorted_s = sorted(samples)
            n = len(sorted_s)
            durations[op_type] = {
                "count": n,
                "avg": round(statistics.mean(samples), 2),
                "p95": round(sorted_s[int(n * 0.95)] if n > 1 else sorted_s[0], 2),
                "p99": round(sorted_s[int(n * 0.99)] if n > 1 else sorted_s[0], 2),
                "max": round(max(samples), 2),
            }
        return {
            "counters": dict(self._metrics),
            "running": self._running,
            "queued": len(self._queued),
            "fair_queue_depth": self._fair_queue.qsize(),
            "durations": durations,
            "account_concurrency_cap": self.account_concurrency,
        }


# Global singleton
_scheduler: VCOperationScheduler | None = None


def get_vc_scheduler() -> VCOperationScheduler:
    global _scheduler
    if _scheduler is None:
        _scheduler = VCOperationScheduler()
    return _scheduler


def reset_vc_scheduler() -> None:
    """Reset the global scheduler (testing / clean shutdown)."""
    global _scheduler
    _scheduler = None
