"""v99.01 — the CANONICAL Voice-Chat join pipeline (VC + Discovery rewrite).

This module is the single, authoritative implementation of the VC join
lifecycle.  Every entry point — manual ``/join``, Join-All (primary and
distributed), Discovery auto-join, watcher auto-join, deferred-drain joins,
retries and recovery — funnels through :func:`run_vc_join`, which is invoked
from ``PyTgCallsBackend.join()`` so that NO caller can bypass it.

Runtime-proven root causes this module fixes (bot-diagnostic (1).log,
2026-09-09 07:47–08:2x, build v98.13):

  RC-A  ``play(chat_id, None)`` (null-stream join) populates the LOCAL
        PyTgCalls calls container but does NOT register a Telegram-side
        participant — 33/33 transport-accepted joins had ZERO participant
        evidence (complete 84–100-participant scans proved absence).
        The pipeline joins with a REAL silent audio stream first
        (capability-probed AudioStream over a bundled silence asset),
        null-stream only as a last resort, and ONLY Telegram-side
        participant evidence can confirm a join.

  RC-B  Verification identity divergence: the v98.13 gate resolved its
        client via the cluster ROUTER (``mtproto_get_client()``) and the
        participant check fell back to the GLOBAL ``_vc_my_user_id`` when
        an account record lacked ``user_id``.  After rotation/reconnect
        those resolve to a DIFFERENT account than the one that joined —
        the check then looks for the wrong user_id through the wrong
        client and can never confirm.  The pipeline builds a
        :class:`VCAccountIdentity` per attempt: the EXACT client the
        backend is bound to, the user_id obtained from THAT client's
        ``get_me`` (cached per account), the backend, and the entity
        scope — all swapped ATOMICALLY on rotation (a new identity object
        is constructed; the old one is never mutated).

  RC-C  Cross-account entity poisoning ("Invalid channel object" /
        CHANNEL_INVALID): the flat ``_vc_entity_cache`` lost its scope
        annotation through ``cache_entity_scoped()``'s un-scoped rewrite,
        letting account B replay account A's access_hash.  The pipeline
        resolves entities per-scope, and on CHANNEL_INVALID performs the
        required recovery: invalidate the poisoned entries → fresh
        resolve on the SAME account (no foreign hash) → rebuild the
        InputPeer → retry (bounded).

  RC-D  Phantom joins were never repaired: transport-accepted +
        Telegram-absent left the chat "unknown_unverified" forever.  The
        pipeline implements the full failed-join recovery protocol: stop
        the stale local call → release backend state → refresh the
        account-specific entity → rebuild the InputPeer → retry with
        bounded exponential backoff → rotate account only when
        appropriate → end in an honest terminal state.

The state machine (user requirement 5):

    DISCOVERED → RESOLVING → RESOLVED → JOINING → TRANSPORT_ACCEPTED
              → TELEGRAM_VERIFYING → JOINED_CONFIRMED

    failure states: ENTITY_FAILED, TRANSPORT_FAILED, TELEGRAM_ABSENT,
    VERIFICATION_UNKNOWN, CALL_ENDED, FLOOD_WAIT, UNRECOVERABLE.

The local PyTgCalls ``calls`` container may NEVER directly transition the
machine to JOINED_CONFIRMED — only Telegram-side participant evidence can.

Observability: every completed attempt emits ``VC_ATTEMPT_FINAL`` with the
complete field set (chat, account, Telegram user id, entity source/type,
channel id, access-hash FINGERPRINT only, backend, call id, join result,
participant result, verification verdict, final state, retry reason,
exception class).  Raw access hashes, session strings, API hashes and bot
tokens are NEVER logged.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("mediagrab")

# ---------------------------------------------------------------------------
# §5 — the canonical VC join state machine
# ---------------------------------------------------------------------------


class VCJoinState:
    """Canonical VC join states (single source of truth)."""

    DISCOVERED = "DISCOVERED"
    RESOLVING = "RESOLVING"
    RESOLVED = "RESOLVED"
    JOINING = "JOINING"
    TRANSPORT_ACCEPTED = "TRANSPORT_ACCEPTED"
    TELEGRAM_VERIFYING = "TELEGRAM_VERIFYING"
    JOINED_CONFIRMED = "JOINED_CONFIRMED"
    # failure states
    ENTITY_FAILED = "ENTITY_FAILED"
    TRANSPORT_FAILED = "TRANSPORT_FAILED"
    TELEGRAM_ABSENT = "TELEGRAM_ABSENT"
    VERIFICATION_UNKNOWN = "VERIFICATION_UNKNOWN"
    CALL_ENDED = "CALL_ENDED"
    FLOOD_WAIT = "FLOOD_WAIT"
    UNRECOVERABLE = "UNRECOVERABLE"

    ALL = (
        DISCOVERED, RESOLVING, RESOLVED, JOINING, TRANSPORT_ACCEPTED,
        TELEGRAM_VERIFYING, JOINED_CONFIRMED, ENTITY_FAILED,
        TRANSPORT_FAILED, TELEGRAM_ABSENT, VERIFICATION_UNKNOWN,
        CALL_ENDED, FLOOD_WAIT, UNRECOVERABLE,
    )

    # Terminal-for-the-run states (the caller receives a typed outcome).
    TERMINAL = {
        JOINED_CONFIRMED, UNRECOVERABLE, VERIFICATION_UNKNOWN,
        CALL_ENDED, FLOOD_WAIT,
    }


# Validated transitions — the ONLY permitted moves.  TELEGRAM_ABSENT is a
# recoverable mid-loop state (recovery re-enters RESOLVING); FLOOD_WAIT is
# terminal for the attempt (the account parks; callers schedule the retry).
_VC_VALID_TRANSITIONS: dict[str, set[str]] = {
    VCJoinState.DISCOVERED: {
        VCJoinState.RESOLVING, VCJoinState.ENTITY_FAILED,
        VCJoinState.UNRECOVERABLE,
    },
    VCJoinState.RESOLVING: {
        VCJoinState.RESOLVED, VCJoinState.ENTITY_FAILED,
        VCJoinState.CALL_ENDED, VCJoinState.FLOOD_WAIT,
        VCJoinState.UNRECOVERABLE,
    },
    VCJoinState.RESOLVED: {
        VCJoinState.JOINING, VCJoinState.ENTITY_FAILED,
        VCJoinState.CALL_ENDED, VCJoinState.FLOOD_WAIT,
        VCJoinState.UNRECOVERABLE,
    },
    VCJoinState.JOINING: {
        VCJoinState.TRANSPORT_ACCEPTED, VCJoinState.TRANSPORT_FAILED,
        VCJoinState.ENTITY_FAILED, VCJoinState.CALL_ENDED,
        VCJoinState.FLOOD_WAIT, VCJoinState.UNRECOVERABLE,
    },
    VCJoinState.TRANSPORT_ACCEPTED: {
        VCJoinState.TELEGRAM_VERIFYING, VCJoinState.CALL_ENDED,
        VCJoinState.UNRECOVERABLE,
    },
    VCJoinState.TELEGRAM_VERIFYING: {
        VCJoinState.JOINED_CONFIRMED, VCJoinState.TELEGRAM_ABSENT,
        VCJoinState.VERIFICATION_UNKNOWN, VCJoinState.CALL_ENDED,
        VCJoinState.FLOOD_WAIT, VCJoinState.JOINING,
    },
    VCJoinState.TELEGRAM_ABSENT: {
        # §7 failed-join recovery: refresh entity → rebuild InputPeer → retry.
        VCJoinState.RESOLVING, VCJoinState.JOINING,
        VCJoinState.UNRECOVERABLE, VCJoinState.VERIFICATION_UNKNOWN,
    },
    VCJoinState.ENTITY_FAILED: {
        VCJoinState.RESOLVING, VCJoinState.UNRECOVERABLE,
    },
    VCJoinState.TRANSPORT_FAILED: {
        VCJoinState.JOINING, VCJoinState.RESOLVING,
        VCJoinState.UNRECOVERABLE,
    },
}


class VCJoinStateMachine:
    """Per-attempt-run state machine with validated, atomic transitions.

    Transitions are recorded with timestamps + reasons; an invalid
    transition raises ``RuntimeError`` immediately (fail-fast — the old
    code's contradictory states came from unvalidated ad-hoc writes).
    ``VC_PIPELINE_STATE`` is logged for every move (observability §16).
    """

    __slots__ = ("state", "chat_id", "_history")

    def __init__(self, chat_id: int) -> None:
        self.state = VCJoinState.DISCOVERED
        self.chat_id = chat_id
        self._history: list[tuple[str, str, float]] = [
            (VCJoinState.DISCOVERED, "init", time.monotonic())
        ]

    def transition(self, new_state: str, reason: str = "") -> None:
        cur = self.state
        if cur == new_state:
            return  # idempotent no-op (self-transition allowed)
        allowed = _VC_VALID_TRANSITIONS.get(cur, set())
        if new_state not in allowed:
            raise RuntimeError(
                f"VC pipeline invalid transition {cur} → {new_state} "
                f"(chat_id={self.chat_id}, reason={reason!r})"
            )
        self.state = new_state
        self._history.append((new_state, reason, time.monotonic()))
        logger.info(
            "VC_PIPELINE_STATE chat_id=%s %s → %s reason=%s",
            self.chat_id, cur, new_state, reason or "-",
        )

    @property
    def history(self) -> list[tuple[str, str, float]]:
        return list(self._history)


# ---------------------------------------------------------------------------
# §3 — per-account identity (atomic on rotation)
# ---------------------------------------------------------------------------


@dataclass
class VCAccountIdentity:
    """The COMPLETE per-account identity for a VC join.

    Every Telegram operation performed during a join uses THE SAME account:
    the entity is resolved through ``client``, the transport join goes
    through ``backend`` (bound to the SAME client), and verification runs
    through ``client`` looking for ``user_id`` (obtained via ``get_me`` on
    that exact client, cached per account).  Account rotation constructs a
    NEW identity object — the previous account's entity, InputPeer,
    access_hash, call identity and verification identity are never
    inherited (they are all looked up fresh through the new client).
    """
    account_id: str                 # stable: "global" or "acc_<phone>"
    client: Any                     # the EXACT Telethon client in use
    backend: Any                    # the PyTgCallsBackend bound to client
    user_id: Optional[int]          # Telegram user id of THIS account
    scope: str                      # entity-cache scope of THIS client
    user_id_source: str = ""        # cluster_record|get_me|unknown

    def fingerprint(self) -> str:
        return f"{self.account_id}/uid={self.user_id or '?'}"

    @staticmethod
    async def resolve(backend: Any, account_id: str = "") -> "VCAccountIdentity":
        """Build the identity for the account that will perform the join.

        ``backend`` is the PyTgCallsBackend doing the transport join; for
        the global backend the client is the backend's OWN bound client
        (``_mtproto``), NOT the router pick — the v98.13 gate used the
        router and could verify through a different account than joined.
        """
        aid = str(account_id or getattr(backend, "_account_id", "") or "global")
        client: Any = None
        scope = ""
        user_id: Optional[int] = None
        src = ""
        # 1) the backend's own bound client (exact transport account)
        #    for the GLOBAL backend; the cluster client (then the
        #    backend's bound client) for a per-account backend.
        bound = getattr(backend, "_mtproto", None)
        if aid == "global" and bound is not None:
            client = bound
        # 2) per-account: the cluster client for that account, then the
        #    backend's OWN bound client (the per-account backend's
        #    _mtproto IS the cluster client; the fallback covers a
        #    cluster-listing race without ever falling back to a
        #    FOREIGN account's client).
        if client is None and aid != "global":
            try:
                from .mtproto import get_userbot_cluster
                cluster = get_userbot_cluster()
                client = cluster.get_client(aid)
            except Exception as exc:  # noqa: BLE001
                logger.debug(
                    "VCAccountIdentity.resolve cluster lookup failed: %s", exc)
                client = None
            if client is None:
                client = bound
            if client is not None:
                try:
                    from .mtproto import get_userbot_cluster
                    cluster = get_userbot_cluster()
                    acc = cluster.get_account(aid)
                    if isinstance(acc, dict):
                        uid = acc.get("user_id")
                        if uid:
                            user_id = int(uid)
                            src = "cluster_record"
                except Exception:  # noqa: BLE001
                    pass
        # 3) fallbacks for the global path only after the bound client.
        if client is None and aid == "global":
            try:
                from .mtproto import mtproto_get_client_legacy
                client = mtproto_get_client_legacy()
            except Exception:  # noqa: BLE001
                client = None
        if client is None:
            try:
                from .mtproto import mtproto_get_client
                client = mtproto_get_client()
            except Exception:  # noqa: BLE001
                client = None
        # scope of the EXACT client.
        if client is not None:
            try:
                from .mtproto import _vc_client_scope
                scope = _vc_client_scope(client)
            except Exception:  # noqa: BLE001
                scope = ""
        # user_id via get_me on THAT client (never a foreign fallback).
        if user_id is None and client is not None:
            try:
                me = await asyncio.wait_for(client.get_me(), timeout=10)
                user_id = getattr(me, "id", None)
                if user_id is not None:
                    src = "get_me"
                    if aid != "global":
                        try:
                            from .mtproto import get_userbot_cluster
                            cluster = get_userbot_cluster()
                            acc = cluster.get_account(aid)
                            if isinstance(acc, dict):
                                acc["user_id"] = int(user_id)
                        except Exception:  # noqa: BLE001
                            pass
            except Exception as exc:  # noqa: BLE001
                logger.debug(
                    "VCAccountIdentity.get_me failed account=%s exc=%s: %s",
                    aid, type(exc).__name__, str(exc)[:100],
                )
        if user_id is None:
            src = "unknown"
        ident = VCAccountIdentity(
            account_id=aid, client=client, backend=backend,
            user_id=user_id, scope=scope, user_id_source=src,
        )
        logger.info(
            "VC_IDENTITY_RESOLVED account=%s user_id=%s uid_source=%s "
            "scope=%s client=%s (v99 pipeline §3)",
            aid, user_id if user_id is not None else "unknown", src,
            scope or "(unknown)", "yes" if client is not None else "NONE",
        )
        return ident


# ---------------------------------------------------------------------------
# §16 — observability
# ---------------------------------------------------------------------------


def _fp_access_hash(access_hash: Any) -> str:
    """Fingerprint an access hash for logging — NEVER the raw value."""
    try:
        if not access_hash:
            return "none"
        digest = hashlib.sha256(
            str(int(access_hash)).encode("utf-8")).hexdigest()[:8]
        return f"fp:{digest}"
    except Exception:  # noqa: BLE001
        return "fp:err"


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, "") or default)
    except Exception:  # noqa: BLE001
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, "") or default)
    except Exception:  # noqa: BLE001
        return default


def _env_flag(name: str, default: bool) -> bool:
    """v99.02: boolean env knob ('1'/'true'/'yes' → True, '0'/'false'/'no'
    → False, unset/empty → default)."""
    raw = (os.environ.get(name, "") or "").strip().lower()
    if not raw:
        return default
    return raw in ("1", "true", "yes", "on")


@dataclass
class VCJoinOutcome:
    """Typed result of one pipeline run (returned + logged as the summary)."""
    final_state: str = VCJoinState.UNRECOVERABLE
    verdict: str = "failed"          # joined|unverified|failed|call_ended|floodwait
    chat_id: int = 0
    marked_chat_id: int = 0
    account: str = ""
    tg_user_id: Optional[int] = None
    attempts: int = 0
    call_id: Any = None
    access_hash: Any = None
    entity_source: str = ""
    entity_type: str = ""
    backend: str = ""
    join_result: str = ""
    telegram_participant_result: str = ""
    verification_result: str = ""
    retry_reason: str = ""
    exc_class: str = ""
    detail: str = ""
    # v99.05 RC-F6 (FINAL REBUILD — mission §16 observability): every
    # attempt carries a correlation id; every success carries the evidence
    # needed to reconstruct WHY it was considered successful.
    attempt_id: str = ""
    verification_method: str = ""    # e.g. telegram_participant_query
    participant_identity: str = ""   # peer evidence string from the verify
    verification_timestamp: str = ""  # ISO time of the confirming query
    rpc_result: str = ""             # dispatch outcome summary


def _new_attempt_id() -> str:
    """v99.05: correlation id for one join attempt (short, log-greppable)."""
    try:
        return uuid.uuid4().hex[:12]
    except Exception:  # noqa: BLE001
        return f"{int(time.time() * 1000):x}"


def _emit_attempt_event(stage: str, out: VCJoinOutcome, **fields: Any) -> None:
    """v99.05 RC-F6 (mission §16): one structured stage event per pipeline
    phase — every event carries the attempt correlation id, the target,
    the owning account and (when known) the call id, so a failed join is
    reconstructable from the log without guessing."""
    try:
        extras = " ".join(f"{k}={v}" for k, v in fields.items())
        logger.info(
            "%s attempt_id=%s target=%s account=%s call_id=%s%s",
            stage,
            out.attempt_id or "-",
            out.marked_chat_id or out.chat_id or "-",
            out.account or "global",
            out.call_id if out.call_id is not None else "none",
            f" {extras}" if extras else "",
        )
    except Exception:  # noqa: BLE001
        pass


def _emit_attempt_final(out: VCJoinOutcome) -> None:
    """§16: the ONE machine-greppable summary line per completed attempt."""
    logger.info(
        "VC_ATTEMPT_FINAL attempt_id=%s chat_id=%s account=%s tg_user_id=%s "
        "attempt=%d entity_source=%s entity_type=%s channel_id=%s "
        "access_hash=%s backend=%s call_id=%s join_result=%s "
        "telegram_participant=%s verification_result=%s final_state=%s "
        "retry_reason=%s exc_class=%s verification_method=%s "
        "participant_identity=%s",
        out.attempt_id or "-",
        out.chat_id, out.account or "global",
        out.tg_user_id if out.tg_user_id is not None else "unknown",
        out.attempts, out.entity_source or "-", out.entity_type or "-",
        out.chat_id, _fp_access_hash(out.access_hash),
        out.backend or "-", out.call_id if out.call_id is not None else "none",
        out.join_result or "-", out.telegram_participant_result or "-",
        out.verification_result or "-", out.final_state,
        out.retry_reason or "-", out.exc_class or "-",
        out.verification_method or "-",
        out.participant_identity or "-",
    )


# ---------------------------------------------------------------------------
# §10 — strict per-(account, chat) in-flight coalescing
# ---------------------------------------------------------------------------

# Keyed by the JOIN OWNER account (stable ids: "global" / "acc_<id>") and
# the MARKED chat id — the same key space the v98.13 §DEDUP locks used.
_VC_PIPELINE_INFLIGHT: dict[tuple[str, int], "asyncio.Task"] = {}


async def _pipeline_inflight_get_or_run(key: tuple[str, int], factory):
    """Single-flight per (account, chat): concurrent callers JOIN the
    in-flight run and receive the SAME outcome — a duplicate
    JoinGroupCallRequest for the same account+chat is structurally
    impossible.  Cross-account and cross-chat runs are NOT serialized."""
    existing = _VC_PIPELINE_INFLIGHT.get(key)
    if existing is not None and not existing.done():
        logger.info(
            "VC_PIPELINE_COALESCED account=%s chat_id=%s — joining the "
            "in-flight join run (v99 §10)", key[0], key[1],
        )
        return await asyncio.shield(existing)
    task = asyncio.ensure_future(factory())
    _VC_PIPELINE_INFLIGHT[key] = task

    def _retrieve_if_orphaned(t: "asyncio.Task") -> None:
        # v99 §10 hygiene: when every caller was cancelled before awaiting
        # the shared flight, the typed pipeline exception (e.g.
        # VCJoinUnverifiedError) would otherwise surface as "Task exception
        # was never retrieved".  Retrieving it here marks it seen; a real
        # awaiter can still re-raise it normally.
        if t.done() and not t.cancelled():
            try:
                _ = t.exception()
            except Exception:  # noqa: BLE001
                pass

    task.add_done_callback(_retrieve_if_orphaned)
    try:
        return await asyncio.shield(task)
    finally:
        if _VC_PIPELINE_INFLIGHT.get(key) is task:
            _VC_PIPELINE_INFLIGHT.pop(key, None)


# ---------------------------------------------------------------------------
# The silent-audio join stream (RC-A fix)
# ---------------------------------------------------------------------------

_SILENCE_ASSET = Path(__file__).resolve().parent / "assets" / "vc_silence_600s.opus"
_stream_factory_cache: dict = {}


def _silence_asset_path() -> Optional[str]:
    p = os.environ.get("VC_SILENCE_ASSET", "") or str(_SILENCE_ASSET)
    try:
        return p if p and os.path.isfile(p) and os.path.getsize(p) > 1024 else None
    except Exception:  # noqa: BLE001
        return None


def _make_silent_stream():
    """Construct a REAL AudioStream over the bundled silence asset.

    RC-A: ``play(chat_id, None)`` was proven (33/33 in production) to NOT
    register a Telegram-side participant — the calls container gets an
    entry while the participant list never contains the account.  Joining
    with a genuine (silent) audio stream is the standard, reliable way a
    participant registers server-side.  Capability-probed across the
    pytgcalls 2.x/3.x stream-type layouts; returns None ONLY when no
    stream type can be constructed (the null-stream path then runs as a
    last resort, with verification still deciding the verdict).
    """
    path = _silence_asset_path()
    if path is None:
        logger.warning(
            "VC_SILENCE_ASSET_MISSING path=%s — joins will fall back to "
            "the null-stream transport (RC-A: verify-only evidence will "
            "decide) (v99 pipeline)", _SILENCE_ASSET,
        )
        return None
    try:
        import pytgcalls  # type: ignore  # noqa: F401
    except ImportError:
        return None
    candidates = [
        ("pytgcalls.types", "AudioStream"),
        ("pytgcalls.types", "MediaStream"),
        ("pytgcalls.types.input_stream", "AudioStream"),
        ("pytgcalls.mtypes", "AudioStream"),
    ]
    import importlib
    for mod_name, cls_name in candidates:
        try:
            mod = importlib.import_module(mod_name)
            cls = getattr(mod, cls_name, None)
            if cls is None or not callable(cls):
                continue
            stream = None
            try:
                stream = cls(path)  # 2.x-style: positional file path
            except Exception:  # noqa: BLE001
                try:
                    stream = cls(path, loop=True)  # 3.x-style kwargs
                except Exception:  # noqa: BLE001
                    stream = None
            if stream is None:
                continue
            # best-effort loop attribute (silence forever)
            try:
                setattr(stream, "loop", True)
            except Exception:  # noqa: BLE001
                pass
            if mod_name not in _stream_factory_cache:
                logger.info(
                    "VC_SILENCE_STREAM_READY type=%s.%s asset=%s "
                    "(loop=best-effort) (v99 RC-A fix)", mod_name, cls_name, path,
                )
            _stream_factory_cache[mod_name] = cls
            return stream
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "VC_SILENCE_STREAM_PROBE_FAILED %s.%s exc=%s: %s",
                mod_name, cls_name, type(exc).__name__, str(exc)[:100],
            )
            continue
    logger.warning(
        "VC_SILENCE_STREAM_UNAVAILABLE — no constructible AudioStream type "
        "in this pytgcalls build; null-stream transport will be used and "
        "Telegram-side verification decides (v99 RC-A)"
    )
    return None


# ---------------------------------------------------------------------------
# Transport classification helpers (reuse voicechat's §DC classifier)
# ---------------------------------------------------------------------------


def _classify_transport_exc(exc: BaseException) -> str:
    """floodwait | transient_dc | entity_level | call_ended | resource_pressure | deterministic."""
    try:
        from .voicechat import _vc_classify_join_transport_error
        base = _vc_classify_join_transport_error(f"{type(exc).__name__}: {exc}")
        if base in ("floodwait", "transient_dc", "resource_pressure"):
            return base
    except Exception:  # noqa: BLE001
        pass
    name = type(exc).__name__.lower()
    msg = str(exc).lower()
    # v99.10 FIX-B: native allocation failures (BlockingIOError errno 11
    # from pthread/socket creation inside ntgcalls, ENOMEM, EMFILE) are
    # process resource pressure — NOT DC transients and NOT deterministic
    # join failures. Check BEFORE the entity/call_ended branches so an
    # errno-11 raised through the transport never reaches the retry loop.
    if isinstance(exc, OSError):
        try:
            _errno = int(getattr(exc, "errno", 0) or 0)
        except Exception:  # noqa: BLE001
            _errno = 0
        if _errno in (11, 12, 23, 24):
            return "resource_pressure"
    if ("resource temporarily unavailable" in msg
            or "too many open files" in msg
            or "can't start new thread" in msg
            or "no buffer space" in msg):
        return "resource_pressure"
    if "channelinvalid" in name or "channelidinvalid" in name \
            or "invalid channel object" in msg:
        return "entity_level"
    if "groupcallinvalid" in name or "group call is invalid" in msg:
        return "call_ended"
    return "deterministic"


def _v9910_make_resource_pressure_error(exc_text: str) -> Exception:
    """v99.10 FIX-B/C helper: build the resource-pressure error.

    Late-bound + harness-safe: when the (test) voicechat module lacks the
    new ``VCResourcePressureError`` symbol the fallback is the ordinary
    ``VCTransportError`` carrying the same classifying message text —
    ``is_resource_pressure_error`` still recognises it, so the Join-All
    defer semantics are preserved in every environment.
    """
    try:
        from .voicechat import VCResourcePressureError
        return VCResourcePressureError(exc_text)
    except Exception:  # noqa: BLE001
        try:
            from .voicechat import VCTransportError
            return VCTransportError(exc_text)
        except Exception:  # noqa: BLE001
            return RuntimeError(exc_text)


def _floodwait_seconds(exc: BaseException) -> int:
    try:
        secs = int(getattr(exc, "seconds", 0) or 0)
        if secs > 0:
            return secs
    except Exception:  # noqa: BLE001
        pass
    import re
    m = re.search(r"a wait of (\d+) seconds", str(exc).lower())
    return int(m.group(1)) if m else 0


# ---------------------------------------------------------------------------
# THE CANONICAL PIPELINE
# ---------------------------------------------------------------------------


@dataclass
class _PipelineCfg:
    max_attempts: int = 3            # per-account join attempts (§7 bounded)
    max_accounts: int = 2            # original + rotations (§9 bounded)
    entity_retries: int = 2          # §4 invalidate→fresh resolve→retry
    verify_attempts: int = 3         # §6 bounded convergence
    verify_backoff_base: float = 1.0
    verify_budget: float = 12.0
    transport_retries: int = 2       # §8 Interdc/transport bounded backoff
    transport_backoff_base: float = 2.0
    recovery_backoff_base: float = 2.0  # §7 exponential recovery backoff
    join_timeout: float = 30.0
    prefer_real_stream: bool = True


def _load_cfg() -> _PipelineCfg:
    return _PipelineCfg(
        max_attempts=max(1, _env_int("VC_JOIN_PIPELINE_MAX_ATTEMPTS", 3)),
        max_accounts=max(1, _env_int("VC_JOIN_PIPELINE_MAX_ACCOUNTS", 2)),
        entity_retries=max(1, _env_int("VC_JOIN_ENTITY_RETRIES", 2)),
        verify_attempts=max(1, _env_int("VC_JOIN_TG_VERIFY_ATTEMPTS", 3)),
        verify_backoff_base=_env_float("VC_JOIN_TG_VERIFY_BACKOFF_BASE", 1.0),
        verify_budget=_env_float("VC_JOIN_TG_VERIFY_BUDGET", 12.0),
        transport_retries=max(0, _env_int("VC_JOIN_DC_MAX_RETRIES", 2)),
        transport_backoff_base=_env_float("VC_JOIN_DC_BACKOFF_BASE", 2.0),
        recovery_backoff_base=_env_float("VC_JOIN_RECOVERY_BACKOFF_BASE", 2.0),
        join_timeout=_env_float("VC_MULTI_JOIN_TIMEOUT", 30.0),
        prefer_real_stream=_env_flag("VC_JOIN_PREFER_REAL_STREAM", True),
    )


# ---------------------------------------------------------------------------
# v99.02 FIX-1 (RC-1) — the null-stream join gate.
#
# RUNTIME-PROVEN (v99.01 production logs 2026-09-09 17:55 → 2026-09-10
# 03:20, three rotations, ~10h):
#   * 98× VC_SILENCE_ASSET_MISSING — the deployed tree was missing
#     assets/vc_silence_600s.opus (a PARTIAL deployment: the v99.01 ZIP
#     contains the 226,371-byte asset, but only .py files were copied to
#     /home/container/mediagrab_bot; the runtime build-identity check
#     verified only stamp.modules, so BUILD_IDENTITY_VERIFIED passed
#     falsely — fixed separately in bootstrap.py v99.02 FIX-1a).
#   * Consequently EVERY join fell back to the null-stream transport
#     (play(chat, None)): 168 dispatches → 134 VC_JOIN_UNVERIFIED →
#     0 VC_JOIN_SUCCESS — matching the v98.13-era proof (33/33 complete
#     participant scans showed absence) that a null-stream "join" NEVER
#     registers a Telegram-side participant.
#   * The churn also correlates with the FD exhaustion that began at
#     23:58 (~1024 FDs over ~6h ≈ the ~32 dispatches/h × native transport
#     cost; the bot's own Python paths were proven clean by an offline FD
#     probe: 300 pipeline join cycles + 1000 atomic writes → ΔFD = 0).
#
# The v99.00 design allowed null-stream as a "last resort, verification
# decides". Production has now DECIDED: after 10 hours and 168 dispatches
# the null-stream transport produced zero Telegram-side verifications.
# Dispatching them is pure churn (native transports + reconcile load +
# registry noise). The gate therefore blocks null-stream dispatches by
# default and fails the join HONESTLY (deterministic VCTransportError →
# the standard failure backoff applies). Operators can still opt in for
# experimentation with VC_ALLOW_NULL_STREAM_JOIN=1.
# ---------------------------------------------------------------------------

_NULL_STREAM_GATE_WARNED = False


def _null_stream_join_allowed() -> bool:
    """v99.02 FIX-1: explicit operator opt-in for null-stream joins."""
    return _env_flag("VC_ALLOW_NULL_STREAM_JOIN", False)


def _null_stream_gate_reason(stream: Any) -> str:
    if _silence_asset_path() is None:
        return ("silence asset missing (expected beside the package: "
                f"{_SILENCE_ASSET}; deploy the FULL ZIP — see DEPLOYMENT.md "
                "v99.02 §asset)")
    return ("no constructible AudioStream type in this pytgcalls build "
            f"(stream={type(stream).__name__ if stream is not None else 'None'})")


def _null_stream_gate_block(out: Any, sm: Any, marked_chat: int,
                            account: str) -> BaseException:
    """v99.02 FIX-1: refuse the dispatch; return the exception to raise."""
    global _NULL_STREAM_GATE_WARNED
    from .voicechat import VCTransportError  # late-bound (run_vc_join style)
    reason = _null_stream_gate_reason(None)
    # v99.03 RC-12: the FIRST block for a (chat_id, reason) pair stays at
    # WARNING and OPENS the 300s suppression window; repeats that reach
    # this point fall to DEBUG (normally they never get here — the
    # run_vc_join entry check short-circuits them BEFORE entity
    # resolution).  See the _v9903_rc12 block above for the evidence.
    _suppressed_repeat = _null_stream_suppress_record(marked_chat, reason)
    if not _NULL_STREAM_GATE_WARNED:
        _NULL_STREAM_GATE_WARNED = True
        logger.critical(
            "VC_NULL_STREAM_JOINS_DISABLED reason=%s — the null-stream "
            "transport was RUNTIME-PROVEN (v99.01 production, 10h: 168 "
            "dispatches → 0 Telegram-side verifications) to never register "
            "a participant; joins are blocked until a REAL silent stream is "
            "available. Set VC_ALLOW_NULL_STREAM_JOIN=1 to override "
            "(v99.02 FIX-1/RC-1).",
            reason,
        )
    if _suppressed_repeat:
        logger.debug(
            "VC_JOIN_BLOCKED_NULL_STREAM chat_id=%s account=%s reason=%s "
            "(suppressed repeat — v99.03 RC-12)",
            marked_chat, account, reason,
        )
    else:
        logger.warning(
            "VC_JOIN_BLOCKED_NULL_STREAM chat_id=%s account=%s reason=%s "
            "(v99.02 FIX-1 — honest deterministic failure; standard join-failure "
            "backoff applies)",
            marked_chat, account, reason,
        )
    sm.transition(VCJoinState.TRANSPORT_FAILED, "null_stream_blocked")
    out.final_state = VCJoinState.TRANSPORT_FAILED
    out.verdict = "failed"
    out.join_result = "null_stream_blocked"
    out.retry_reason = "silence_stream_unavailable"
    out.exc_class = "VCTransportError"
    _emit_attempt_final(out)
    return VCTransportError(
        f"Join for {marked_chat} (account={account}) blocked: {reason}. "
        "The null-stream transport never registers a Telegram-side "
        "participant (runtime-proven); deploy the silence asset or set "
        "VC_ALLOW_NULL_STREAM_JOIN=1 to allow null-stream dispatches "
        "(v99.02 FIX-1)."
    )


# ---------------------------------------------------------------------------
# v99.03 RC-12 — blocked-join warning suppression + pre-resolution
# short-circuit.
#
# RUNTIME-PROVEN (the 2026-09-11 02:45:10 → 03:20:39 v99.02 production
# log, 1,086s): the null-stream gate fired 40× VC_JOIN_BLOCKED_NULL_STREAM
# across 31 DISTINCT chats (9 repeats) in 36 minutes — every one of those
# 40 attempts paid the FULL pre-gate pipeline cost (entity resolution ≈ 8
# RPCs each ≈ 320 wasted RPCs) against an environment the boot identity
# check had ALREADY declared broken (BUILD_IDENTITY_MISMATCH at line 2).
# Two v99.03 mechanisms close this:
#   * RC-8 (below, in run_vc_join) refuses entry ENTIRELY when the boot
#     identity mismatched — the dominant term (0 join attempts → 0 RPCs).
#   * RC-12 (here) collapses the residual noise when the pipeline is NOT
#     disabled but the gate still blocks (e.g. identity verified, yet no
#     constructible AudioStream type; or the operator overrode RC-8):
#     after the FIRST block for a (chat_id, reason) pair, repeats for that
#     pair within 300s are short-circuited at run_vc_join ENTRY — BEFORE
#     entity resolution — and their per-join WARNING collapses to DEBUG,
#     with a single VC_JOIN_BLOCKED_NULL_STREAM_SUPPRESSED chat_id=…
#     count=N reason=… summary line when the window expires.
# ---------------------------------------------------------------------------

_NULL_STREAM_SUPPRESS: dict[tuple[int, str], dict] = {}
_NULL_STREAM_SUPPRESS_WINDOW_S = 300.0


def _null_stream_suppress_key(chat_id: int, reason: str) -> tuple[int, str]:
    """Stable (chat, reason-class) key — the human-readable reason text is
    reduced to a coarse class so wording changes never fork the window."""
    if _silence_asset_path() is None:
        rcls = "silence asset missing"
    else:
        rcls = "no constructible AudioStream type"
    return (int(chat_id or 0), rcls)


def _null_stream_suppress_record(marked_chat: int,
                                  reason: str = "") -> bool:
    """Called by the gate when a block fires.

    Returns True when this block is a REPEAT inside an open window (the
    caller then logs at DEBUG instead of WARNING).  The FIRST block for a
    pair opens the window; a repeat only increments the counter.
    """
    key = _null_stream_suppress_key(marked_chat, reason)
    now = time.monotonic()
    rec = _NULL_STREAM_SUPPRESS.get(key)
    if rec is None:
        _NULL_STREAM_SUPPRESS[key] = {
            "window_start": now, "count": 1, "suppressed": 0}
        return False
    if now - rec["window_start"] >= _NULL_STREAM_SUPPRESS_WINDOW_S:
        # Window expired HERE (a block reached the gate exactly at the
        # boundary): flush the summary, then treat this as a fresh first.
        _null_stream_suppress_flush_key(key, now)
        _NULL_STREAM_SUPPRESS[key] = {
            "window_start": now, "count": 1, "suppressed": 0}
        return False
    rec["count"] = int(rec.get("count", 0)) + 1
    return True


def _null_stream_suppress_flush_key(key: tuple[int, str],
                                     now: float) -> None:
    """Emit the SUPPRESSED summary for one expired window (if it had
    suppressed repeats) and drop it."""
    rec = _NULL_STREAM_SUPPRESS.pop(key, None)
    if not rec:
        return
    suppressed = int(rec.get("suppressed", 0))
    if suppressed > 0:
        logger.warning(
            "VC_JOIN_BLOCKED_NULL_STREAM_SUPPRESSED chat_id=%s count=%d "
            "reason=%s window=%.0fs — repeats were short-circuited at "
            "pipeline entry (no entity-resolution RPCs) and logged at DEBUG "
            "(v99.03 RC-12)",
            key[0], suppressed, key[1], _NULL_STREAM_SUPPRESS_WINDOW_S,
        )


def _null_stream_suppress_check(chat_id: int, reason: str = "") -> bool:
    """RC-12 entry check: is this (chat, reason) pair inside an open window?

    Called at run_vc_join ENTRY — before VCAccountIdentity.resolve, before
    any entity-resolution RPC.  A True result means the caller must fail
    the join fast (deterministic VCTransportError, join_result=
    null_stream_blocked) and count the suppression.  An EXPIRED window is
    flushed here lazily (the summary line) so the next join logs a fresh
    WARNING and re-opens the window.
    """
    key = _null_stream_suppress_key(chat_id, reason)
    rec = _NULL_STREAM_SUPPRESS.get(key)
    if rec is None:
        return False
    now = time.monotonic()
    if now - rec["window_start"] >= _NULL_STREAM_SUPPRESS_WINDOW_S:
        _null_stream_suppress_flush_key(key, now)
        return False
    rec["suppressed"] = int(rec.get("suppressed", 0)) + 1
    return True


def _null_stream_suppress_flush() -> int:
    """Flush every expired window (heartbeat cadence, 300s).

    Returns the number of summaries emitted — lets the heartbeat line and
    the tests observe the flush without parsing logs.
    """
    now = time.monotonic()
    flushed = 0
    for key in list(_NULL_STREAM_SUPPRESS.keys()):
        rec = _NULL_STREAM_SUPPRESS.get(key)
        if rec is None:
            continue
        if now - rec["window_start"] >= _NULL_STREAM_SUPPRESS_WINDOW_S:
            before = len(_NULL_STREAM_SUPPRESS)
            _null_stream_suppress_flush_key(key, now)
            if len(_NULL_STREAM_SUPPRESS) < before:
                flushed += 1
    return flushed


def _null_stream_suppress_reset_for_tests() -> None:
    """Test hook: clear all windows."""
    _NULL_STREAM_SUPPRESS.clear()


# ---------------------------------------------------------------------------
# v99.03 RC-8 — fail-fast when the boot build-identity check failed.
#
# RUNTIME-PROVEN (the same 2026-09-11 v99.02 log): the identity check
# DECLARED the deployment broken at 02:45:10 (line 2) yet the bot kept
# attempting joins for 36 minutes — 40 attempts, 320 entity-resolution
# RPCs, all deterministically blocked.  The v99.02 gate made each failure
# HONEST; v99.03 makes the failure CHEAP: with a mismatched identity the
# pipeline refuses entry BEFORE identity resolution (zero RPCs), while
# the Bot API surface (/v85status, /v85accounts, /deploy_check) stays
# fully available so the operator can diagnose without logs.  Fail-open
# for dev/test trees (state "unknown"/"missing" never disables — see
# deploy_health.py); explicit operator override via
# VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH=1 (the FIX-1 knob convention).
# ---------------------------------------------------------------------------

_VC_PIPELINE_DISABLE_LOGGED = False


def _vc_pipeline_disable_refusal(chat_ref: Any, account_id: str,
                                 reason: str) -> BaseException:
    """Build the deterministic refusal exception + the once-per-process
    operator-facing ERROR line (VC_PIPELINE_DISABLE)."""
    global _VC_PIPELINE_DISABLE_LOGGED
    from .voicechat import VCTransportError  # late-bound (run_vc_join style)
    if not _VC_PIPELINE_DISABLE_LOGGED:
        _VC_PIPELINE_DISABLE_LOGGED = True
        logger.error(
            "VC_PIPELINE_DISABLE reason=%s — the deployed tree does NOT match "
            "the packaged build (BUILD_IDENTITY_MISMATCH at boot); ALL VC "
            "joins fail fast WITHOUT entity-resolution RPCs, discovery and "
            "reconcile cycles are skipped. Repair: re-extract the FULL "
            "deployment ZIP (see DEPLOYMENT.md v99.03 §runbook) or set "
            "VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH=1 to run degraded. "
            "Diagnose via /deploy_check, /v85accounts, /v85status "
            "(v99.03 RC-8).",
            reason,
        )
    logger.debug(
        "VC_JOIN_REFUSED_PIPELINE_DISABLED chat=%s account=%s reason=%s "
        "— zero-RPC fast refusal (v99.03 RC-8)",
        chat_ref, account_id or "global", reason,
    )
    return VCTransportError(
        f"VC pipeline disabled (reason={reason}): the boot build-identity "
        "check found the deployed tree does not match the packaged build; "
        "join refused before any entity resolution. Re-extract the FULL "
        "deployment ZIP or set VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH=1 "
        "(v99.03 RC-8)."
    )


def _marked_of(raw_id: int) -> int:
    return -1000000000000 - int(raw_id)


def _raw_of(marked: int) -> int:
    return abs(int(marked)) % 1000000000000 if marked < -1000000000000 else int(marked)


async def run_vc_join(
    backend: Any,
    chat_ref: Any,
    *,
    call_id: int = 0,
    access_hash: int = 0,
    muted: bool = True,
    account_id: str = "",
) -> VCJoinOutcome:
    """The canonical VC join — see the module docstring.

    Contract (identical to the historical ``PyTgCallsBackend.join`` so
    every existing caller keeps working):
      * returns a JOINED_CONFIRMED outcome ONLY on Telegram-side
        participant evidence,
      * raises ``VCJoinUnverifiedError`` when the transport accepted the
        join but Telegram verification stayed inconclusive,
      * raises ``VCTransportError`` for transport/entity/floodwait/call-
        ended failures (existing parsers keep working),
      * idempotent: an already-verified container entry short-circuits
        after a quick participant re-check.
    """
    from .voicechat import (  # late-bound: voicechat imports this lazily
        VCTransportError, VCJoinUnverifiedError,
    )
    cfg = _load_cfg()

    # ------------------------------------------------------------------
    # v99.03 RC-8: refuse entry when the boot identity check failed.
    # MUST run before VCAccountIdentity.resolve — a known-broken
    # deployment must not pay even ONE entity-resolution RPC (the
    # v99.02 production run wasted 40 attempts × ~8 RPCs after the boot
    # check had already declared the tree broken).  Fail-open for
    # dev/test trees (deploy_health defaults to "unknown" → not
    # disabled); VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH=1 overrides.
    # ------------------------------------------------------------------
    try:
        from . import deploy_health as _v9903_dh
        _v9903_disable = _v9903_dh.vc_pipeline_disabled_reason()
    except Exception:  # noqa: BLE001
        _v9903_disable = None
    if _v9903_disable is not None:
        raise _vc_pipeline_disable_refusal(chat_ref, account_id,
                                           _v9903_disable)

    # ------------------------------------------------------------------
    # v99.03 RC-12: short-circuit REPEATED null-stream-blocked joins at
    # entry — before identity resolution — while the (chat, reason)
    # suppression window is open.  The first block for a pair pays the
    # full pipeline cost and logs at WARNING; every repeat inside 300s
    # fails fast here with zero RPCs and collapses to DEBUG + a single
    # SUPPRESSED summary when the window expires.  NOTE: the check is
    # gated on the SAME null_ok condition as the v99.02 gate itself — an
    # operator who opted into null-stream dispatches (or disabled the
    # real-stream preference) must never be short-circuited by a stale
    # window from BEFORE they set the knob.
    # ------------------------------------------------------------------
    _v9903_null_ok = _null_stream_join_allowed() or not cfg.prefer_real_stream
    _v9903_key_chat = int(chat_ref) if isinstance(chat_ref, int) else 0
    if _v9903_key_chat and not _v9903_null_ok \
            and _null_stream_suppress_check(_v9903_key_chat):
        logger.debug(
            "VC_JOIN_BLOCKED_NULL_STREAM chat_id=%s account=%s "
            "(suppressed repeat — short-circuited at pipeline entry, zero "
            "entity-resolution RPCs; v99.03 RC-12)",
            _v9903_key_chat, account_id or "global",
        )
        raise VCTransportError(
            f"Join for {chat_ref} refused: repeated null-stream block "
            "inside the 300s suppression window (v99.03 RC-12 — zero "
            "entity-resolution RPCs; see "
            "VC_JOIN_BLOCKED_NULL_STREAM_SUPPRESSED when the window "
            "expires). Set VC_ALLOW_NULL_STREAM_JOIN=1 to allow "
            "null-stream dispatches (v99.02 FIX-1) or wait for the "
            "window to expire."
        )

    sm = VCJoinStateMachine(0)
    out = VCJoinOutcome(backend=getattr(backend, "backend_name", "pytgcalls"))
    # v99.05 RC-F6 (mission §16): one correlation id for the WHOLE attempt
    # lifecycle (every stage event + the final line + VC_JOIN_SUCCESS
    # carry it — one failed join is reconstructable from the log alone).
    out.attempt_id = _new_attempt_id()
    _emit_attempt_event(
        "VC_ATTEMPT_START", out, provided_call_id=call_id or "none",
        provided_access_hash=_fp_access_hash(access_hash),
        chat_ref=chat_ref,
    )

    # ------------------------------------------------------------------
    # Entry: identity resolution happens ONCE per account; rotation
    # constructs a NEW identity (atomic swap — no inherited state).
    # ------------------------------------------------------------------
    identity = await VCAccountIdentity.resolve(backend, account_id)
    account = identity.account_id
    marked_chat = int(chat_ref) if isinstance(chat_ref, int) else 0

    # ------------------------------------------------------------------
    # v99.06 FIX-3b (4.2): ONE-GROUP-ONE-ACCOUNT hard gate — after
    # identity resolution, BEFORE any entity-resolution RPC.  A second
    # account can never even dispatch a JoinGroupCallRequest for a group
    # owned by a different account (zero RPCs wasted).  This lives in
    # run_vc_join — the single writer — so EVERY entry point (manual
    # /join, Join-All primary + distributed, discovery auto-join,
    # watcher auto-join, deferred drain, recovery retries) is covered;
    # a caller-level check would be bypassable.
    # Exempt: identity.account_id == existing_owner (idempotent re-entry
    # through the same account — the "already joined" fast path).
    # Comparison is on EFFECTIVE ids (the chameleon "global" token is
    # translated to the primary's real binding via FIX-1).  Operator
    # kill-switch: VC_JOIN_ONE_GROUP_ONE_ACCOUNT=false.
    # ------------------------------------------------------------------
    try:
        from .voicechat import (
            _vc_group_owner, _vc_effective_account_id,
            _vc_one_group_one_account_enabled,
        )
        if _vc_one_group_one_account_enabled() and marked_chat:
            _v9906_owner = _vc_group_owner(marked_chat)
            _v9906_requester = _vc_effective_account_id(identity.account_id)
            if _v9906_owner and _v9906_owner != _v9906_requester:
                logger.warning(
                    "VC_JOIN_SKIPPED_ALREADY_OWNED chat_id=%s owner=%s "
                    "requester=%s (v99.06 FIX-3b one-group-one-account "
                    "invariant — zero RPCs)",
                    marked_chat, _v9906_owner, _v9906_requester,
                )
                out.final_state = "skipped_already_owned"
                out.chat_id = marked_chat
                out.marked_chat_id = marked_chat
                out.account = identity.account_id
                _emit_attempt_event(
                    "VC_ATTEMPT_FINAL", out,
                    outcome="skipped_already_owned",
                    owner=_v9906_owner,
                )
                raise VCTransportError(
                    f"Chat {marked_chat} is already joined by account "
                    f"{_v9906_owner}; one-group-one-account invariant "
                    f"(v99.06)."
                )
    except VCTransportError:
        raise
    except Exception as _v9906_gate_exc:  # noqa: BLE001
        # The gate itself must never break joins (fail-open, logged).
        logger.debug(
            "VC_JOIN_OWNERSHIP_GATE_ERROR chat_id=%s exc=%s",
            marked_chat, _v9906_gate_exc,
        )

    async def _run() -> VCJoinOutcome:
        nonlocal identity, account, marked_chat, call_id, access_hash, backend
        out.account = account
        out.tg_user_id = identity.user_id
        attempts_total = 0
        accounts_tried: list = []
        last_retry_reason = ""
        last_exc_class = ""
        orig_backend = backend

        while True:
            attempts_total += 1
            out.attempts = attempts_total
            if account not in accounts_tried:
                accounts_tried.append(account)
            sm.state = VCJoinState.DISCOVERED

            # ---------------- RESOLVING (per-account entity) ----------
            sm.transition(VCJoinState.RESOLVING, f"attempt_{attempts_total}")
            entity = None
            entity_source = ""
            entity_cls = ""
            for er in range(cfg.entity_retries):
                use_hash = access_hash if er == 0 else 0  # §4: after a
                # CHANNEL_INVALID the provided hash is DROPPED and the
                # entity is resolved fresh on the SAME account.
                try:
                    from .mtproto import resolve_vc_entity
                    res = await asyncio.wait_for(
                        resolve_vc_entity(
                            identity.client, chat_ref,
                            chat_id=marked_chat or (
                                chat_ref if isinstance(chat_ref, int) else 0),
                            access_hash=use_hash,
                        ),
                        timeout=25.0,
                    )
                except asyncio.TimeoutError:
                    res = {"ok": False, "error": "resolve_timeout"}
                except Exception as exc:  # noqa: BLE001
                    res = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
                if res.get("ok") and res.get("entity") is not None:
                    entity = res["entity"]
                    entity_source = str(res.get("source", "unknown"))
                    # scope-safe: if the resolution was served by a
                    # DIFFERENT account (source=account_rotation:X), the
                    # JOIN must run through that account — rotate the
                    # identity BEFORE dispatching (v99 §3).
                    rot = ""
                    if "account_rotation:" in entity_source:
                        try:
                            rot = entity_source.split("account_rotation:")[1] \
                                .split(":")[0].split(",")[0].strip()
                        except Exception:  # noqa: BLE001
                            rot = ""
                    if rot and rot != account and rot not in accounts_tried \
                            and len(accounts_tried) < cfg.max_accounts:
                        eligible = True
                        _rot_why = "ok"
                        try:
                            from .voicechat import _vc_join_account_eligible
                            eligible, _rot_why = _vc_join_account_eligible(rot)
                        except Exception:  # noqa: BLE001
                            eligible, _rot_why = True, "error_fail_open"
                        if _rot_why == "stagger_cooldown":
                            # v99.09 FIX-A (2026-09-19 17:37:16 production
                            # kill chain): the 2-5s post-join stagger is a
                            # SOFT cooldown (voicechat._vc_join_account_
                            # eligible — "callers may still wait it out"),
                            # but this rotation gate treated it as a HARD
                            # one and SILENTLY skipped the rotation. The
                            # join then consumed the resolver's entity on
                            # the WRONG client's GetFullChannelRequest →
                            # CHANNEL_INVALID → detect:VCTransportError →
                            # ENTITY_FAILED ×3 → (FIX-B's predecessor)
                            # invalid-transition crash. Correctness beats
                            # staggering: WAIT OUT the ≤5s soft cooldown,
                            # then rotate — the stagger's purpose (space
                            # consecutive joins) is preserved because the
                            # join lands AFTER the cooldown, not during it.
                            _v9909_wait = 0.0
                            try:
                                from .voicechat import _vc_join_account_stats
                                _v9909_rec = _vc_join_account_stats(rot)
                                _v9909_wait = max(
                                    0.0,
                                    float(_v9909_rec.get(
                                        "cooldown_until", 0.0)) - time.monotonic(),
                                )
                            except Exception:  # noqa: BLE001
                                _v9909_wait = 0.0
                            if _v9909_wait > 0:
                                logger.info(
                                    "VC_PIPELINE_ROTATE_TO_RESOLVER_WAIT "
                                    "chat_id=%s rot=%s seconds=%.1f — waiting "
                                    "out the soft post-join stagger before "
                                    "rotating (v99.09 FIX-A: skipping the "
                                    "rotation made the join consume a "
                                    "foreign-scope entity)",
                                    marked_chat or chat_ref, rot,
                                    min(_v9909_wait, 5.5),
                                )
                                await asyncio.sleep(min(_v9909_wait, 5.5))
                            eligible = True
                        if eligible:
                            logger.info(
                                "VC_PIPELINE_ROTATE_TO_RESOLVER chat_id=%s "
                                "from=%s to=%s — the entity was resolved by "
                                "this account; the join must use it (v99 §3)",
                                marked_chat or chat_ref, account, rot,
                            )
                            try:
                                from .voicechat import vc_get_backend
                                nb = vc_get_backend(account_id=rot)
                                if not getattr(nb, "_started", False):
                                    await nb.start()
                                if getattr(nb, "_started", False):
                                    new_ident = await VCAccountIdentity.resolve(
                                        nb, rot)
                                    # ATOMIC swap: a brand-new identity
                                    # object; the entity and call identity
                                    # are re-derived below through the NEW
                                    # client — nothing is inherited.
                                    identity, account = new_ident, rot
                                    backend = nb  # the rotated backend owns
                                    # the transport dispatch from here on.
                                    out.account = account
                                    out.tg_user_id = identity.user_id
                                    accounts_tried.append(account)
                                    out.backend = getattr(
                                        nb, "backend_name", "pytgcalls")
                                    # re-resolve through the new client.
                                    continue
                            except Exception as exc:  # noqa: BLE001
                                logger.warning(
                                    "VC_PIPELINE_ROTATE_TO_RESOLVER_FAILED "
                                    "account=%s exc=%s: %s", rot,
                                    type(exc).__name__, exc,
                                )
                        else:
                            # v99.09 FIX-A observability: a HARD skip
                            # (FloodWait-parked resolver, account budget
                            # exhausted) was previously COMPLETELY silent —
                            # the 2026-09-19 log only showed the downstream
                            # CHANNEL_INVALID storm with no hint WHY the
                            # rotation never fired. Marker is an ADDITION
                            # (no rename); the join proceeds as before and
                            # the §4/§7 recovery ladder still owns the retry.
                            logger.info(
                                "VC_PIPELINE_ROTATE_TO_RESOLVER_SKIPPED "
                                "chat_id=%s rot=%s reason=%s — the entity "
                                "belongs to %s's scope but that account "
                                "cannot take the join right now; the "
                                "attempt proceeds on %s (v99.09 FIX-A)",
                                marked_chat or chat_ref, rot, _rot_why,
                                rot, account,
                            )
                    break
                # entity-level failure diagnostics + §4 recovery
                err = str(res.get("error", "unknown"))
                last_exc_class = "EntityResolveError"
                last_retry_reason = f"entity_resolve:{err[:80]}"
                if "channelinvalid" in err.lower() \
                        or "invalid channel object" in err.lower():
                    try:
                        await _evict_poisoned_entity(marked_chat or chat_ref,
                                                     identity)
                    except Exception:  # noqa: BLE001
                        pass
                    logger.warning(
                        "VC_PIPELINE_ENTITY_INVALID chat=%s account=%s "
                        "retry=%d/%d — evicting poisoned entity entries, "
                        "re-resolving WITHOUT the provided hash (v99 §4)",
                        marked_chat or chat_ref, account, er + 1,
                        cfg.entity_retries,
                    )
                    continue
                break

            if entity is None:
                sm.transition(VCJoinState.ENTITY_FAILED, last_retry_reason)
                if attempts_total < cfg.max_attempts:
                    await asyncio.sleep(min(
                        cfg.recovery_backoff_base * (2 ** (attempts_total - 1)),
                        8.0))
                    last_retry_reason = "entity_backoff_retry"
                    continue
                sm.transition(VCJoinState.UNRECOVERABLE, "entity_failed")
                out.final_state = VCJoinState.UNRECOVERABLE
                out.verdict = "failed"
                out.entity_source = "-"
                out.exc_class = last_exc_class
                out.retry_reason = last_retry_reason
                _emit_attempt_final(out)
                raise VCTransportError(
                    f"Cannot resolve chat {chat_ref} for account "
                    f"{account} after {cfg.entity_retries} scoped attempts "
                    f"({last_retry_reason}) (v99 pipeline §4)."
                )

            # derive the marked chat id from the entity (authoritative)
            try:
                raw_id = int(getattr(entity, "id", 0) or 0)
            except Exception:  # noqa: BLE001
                raw_id = 0
            try:
                from telethon.tl.types import Channel  # type: ignore
            except ImportError:
                Channel = ()  # type: ignore
            if entity is not None and Channel and isinstance(entity, Channel):
                entity_cls = "Channel"
                if not raw_id:
                    raw_id = _raw_of(marked_chat) if marked_chat else 0
                marked_chat = _marked_of(raw_id)
            else:
                entity_cls = type(entity).__name__
                marked_chat = marked_chat or (-raw_id if raw_id > 0 else raw_id)
            sm.chat_id = marked_chat
            out.chat_id = _raw_of(marked_chat) if marked_chat < -1000000000000 \
                else abs(marked_chat)
            out.marked_chat_id = marked_chat
            out.entity_source = entity_source
            out.entity_type = entity_cls
            sm.transition(VCJoinState.RESOLVED, entity_source)
            _emit_attempt_event(
                "VC_TARGET_RESOLVED", out, entity_source=entity_source,
                entity_type=entity_cls,
            )
            _emit_attempt_event(
                "VC_ACCOUNT_SELECTED", out, tg_user_id=identity.user_id
                if identity.user_id is not None else "unknown",
                accounts_tried=len(accounts_tried),
            )

            # ---------------- RESOLVED → call identity ------------------
            # v99 §18 FAST PATH: every production caller (Join-All
            # knowledge cache, discovery, watcher, manual /join) detects
            # the call IMMEDIATELY before invoking join() and provides a
            # nonzero (call_id, access_hash).  On the FIRST attempt the
            # provided identity is used with ZERO extra RPC on the
            # critical path (the v98.10 KB-FASTPATH contract:
            # ``targets_from_cache`` must not pay a
            # GetFullChannelRequest).  Correctness is unaffected — the
            # Telegram-side participant verification gate still decides
            # success, and a STALE provided identity surfaces as
            # absent/call_ended and falls into the bounded §7 recovery,
            # which re-detects FRESH on the joining account (attempts ≥ 2
            # always run the authoritative detection below).
            call_info = None
            provided_identity = bool(int(call_id or 0)) and bool(int(access_hash or 0))
            if provided_identity and attempts_total == 1:
                logger.info(
                    "VC_PIPELINE_CALL_IDENTITY_FASTPATH chat_id=%s "
                    "account=%s call_id=%s — using the caller-provided "
                    "identity (the participant gate still verifies; a "
                    "stale identity falls into bounded recovery) (v99 §18)",
                    marked_chat or chat_ref, account, call_id,
                )
            else:
                # The authoritative call identity is fetched by the JOINING
                # account (not inherited from discovery) — this is what
                # guarantees call_id/access_hash consistency for the
                # verification query (attempt ≥ 2: the provided identity
                # is suspect after a phantom/absent/stale-entity result).
                try:
                    from .voicechat import vc_detect_active_call
                    call_info = await asyncio.wait_for(
                        vc_detect_active_call(identity.client, entity),
                        timeout=15.0,
                    )
                except asyncio.TimeoutError:
                    call_info = None
                except Exception as exc:  # noqa: BLE001
                    if _classify_transport_exc(exc) == "entity_level":
                        try:
                            await _evict_poisoned_entity(marked_chat, identity)
                        except Exception:  # noqa: BLE001
                            pass
                        sm.transition(VCJoinState.ENTITY_FAILED,
                                      f"detect:{type(exc).__name__}")
                        if attempts_total < cfg.max_attempts:
                            last_retry_reason = "detect_entity_refresh"
                            continue
                        # v99.09 FIX-B (2026-09-19 17:37:20 production
                        # crash): an entity-level detect failure with the
                        # retry budget EXHAUSTED fell through to the
                        # ``no_active_call`` branch below, which asked for
                        # ENTITY_FAILED → CALL_ENDED — not in
                        # _VC_VALID_TRANSITIONS → RuntimeError masked the
                        # real cause (chat -1001861200510: the invalid-
                        # transition crash, not "no active call", was what
                        # the caller saw) and burned an account-breaker
                        # failure. The designed entity-failure terminal
                        # path is ENTITY_FAILED → UNRECOVERABLE (the same
                        # shape as the entity-resolution exhaustion above)
                        # and the ORIGINAL exception is re-raised so the
                        # caller sees the true cause. The breaker still
                        # counts the failure; nothing is weakened.
                        sm.transition(VCJoinState.UNRECOVERABLE,
                                      "detect_entity_failed")
                        out.final_state = VCJoinState.UNRECOVERABLE
                        out.verdict = "failed"
                        out.exc_class = type(exc).__name__
                        out.retry_reason = last_retry_reason or \
                            "detect_entity_refresh"
                        _emit_attempt_final(out)
                        raise
                    call_info = None
                if not call_info:
                    sm.transition(VCJoinState.CALL_ENDED, "no_active_call")
                    out.call_id = call_id or None
                    out.final_state = VCJoinState.CALL_ENDED
                    out.verdict = "call_ended"
                    out.join_result = "no_active_call"
                    _emit_attempt_final(out)
                    raise VCTransportError(
                        f"No active voice chat in {marked_chat} for account "
                        f"{account} (v99 pipeline)."
                    )
                call_id = int(call_info.get("call_id") or 0)
                access_hash = int(call_info.get("access_hash") or 0)
            out.call_id = call_id
            out.access_hash = access_hash
            _emit_attempt_event(
                "VC_CALL_RESOLVED", out,
                source="provided" if (provided_identity and attempts_total == 1)
                else "detected",
                access_hash=_fp_access_hash(access_hash),
                attempt_no=attempts_total,
            )

            # ---------------- JOINING (transport dispatch) -------------
            sm.transition(VCJoinState.JOINING, "transport_dispatch")
            # v99 §3/§9 ownership bookkeeping: record the backend that
            # ACTUALLY owns this chat's transport (rotated backends must
            # be discoverable by verify_joined/leave/reconcile).
            try:
                from .voicechat import _vc_active_join_backends_by_chat
                _vc_active_join_backends_by_chat[marked_chat] = backend
                if orig_backend is not None and backend is not orig_backend:
                    orig_backend._active_join_backend = backend
                    logger.info(
                        "VC_ACTIVE_JOIN_BACKEND_SET account=%s "
                        "(rotated from %s) chat=%s (v99 pipeline)",
                        account,
                        getattr(orig_backend, "_account_id", "") or "global",
                        marked_chat,
                    )
                logger.info(
                    "VC_BACKEND_OWNER_SET chat_id=%s account=%s (v99 pipeline)",
                    marked_chat, account,
                )
            except Exception:  # noqa: BLE001
                pass
            # Idempotent re-entry: if the container already holds this
            # chat for THIS backend, the join may already be live — do a
            # QUICK verification; only a PRESENT verdict short-circuits.
            try:
                already = await backend._is_target_in_calls_container(marked_chat)
            except Exception:  # noqa: BLE001
                already = None
            if already is True:
                # Idempotent re-entry: the container already holds this
                # chat — container presence IS transport acceptance; the
                # quick Telegram-side recheck decides whether the join is
                # live.  Only a PRESENT verdict short-circuits.
                sm.transition(VCJoinState.TRANSPORT_ACCEPTED,
                              "container_holds_target")
                sm.transition(VCJoinState.TELEGRAM_VERIFYING, "idempotent_recheck")
                quick = await _verify_participation(
                    identity, marked_chat, call_id, access_hash,
                    attempts=1, backoff=0.5, budget=6.0,
                )
                if quick == "present":
                    await _on_verified(identity, marked_chat, call_id,
                                       access_hash, entity_source, entity_cls)
                    sm.transition(VCJoinState.JOINED_CONFIRMED,
                                  "idempotent_recheck_present")
                    out.final_state = VCJoinState.JOINED_CONFIRMED
                    out.verdict = "joined"
                    out.join_result = "already_in_call_verified"
                    out.verification_result = "present"
                    _emit_attempt_final(out)
                    return out
                # container holds a stale/phantom object → return to the
                # JOINING state: clean it and run the REAL join (never
                # skip on local-only evidence).
                logger.info(
                    "VC_PIPELINE_STALE_CONTAINER chat_id=%s account=%s — "
                    "container entry unverified (%s); cleaning and "
                    "re-joining (v99 §7)",
                    marked_chat, account, quick,
                )
                try:
                    # v99.11 P0: reason-coded — the pipeline's OWN
                    # in-flight target (idempotent re-entry found an
                    # unverified container object); never an unrelated
                    # ACTIVE transport.
                    await _cleanup_local_call(
                        backend, marked_chat,
                        reason_code="FAILED_JOIN_CLEANUP",
                        evidence="idempotent re-entry: quick verify != "
                                 "present for the join's own target",
                    )
                except Exception:  # noqa: BLE001
                    pass
                sm.transition(VCJoinState.JOINING, "stale_container_cleanup")

            # RC-A: dispatch with a REAL silent stream first.
            stream = _make_silent_stream() if cfg.prefer_real_stream else None
            # v99.02 FIX-1 (RC-1): the null-stream gate — see the block
            # comment above _null_stream_join_allowed(). Applies when the
            # REAL stream could not be constructed for ANY reason (missing
            # asset, no AudioStream type). Honesty preserved: this is a
            # deterministic failure with the standard retry backoff, never
            # a success-path shortcut. An operator who explicitly sets
            # VC_JOIN_PREFER_REAL_STREAM=0 has already opted into the
            # null-stream transport — the gate honors that (and the
            # VC_ALLOW_NULL_STREAM_JOIN=1 escape hatch always applies).
            _null_ok = (not cfg.prefer_real_stream) or _null_stream_join_allowed()
            if stream is None and not _null_ok:
                raise _null_stream_gate_block(out, sm, marked_chat, account)
            out.join_result = "dispatch_silent_stream" if stream is not None \
                else "dispatch_null_stream"
            # v99.10 FIX-C: the pre-dispatch resource guard. Each REAL-
            # stream join allocates a native ntgcalls media pipeline
            # (threads + SRTP/jitter/decoder buffers + ~4 UDP sockets);
            # the 2026-09-20 v99.09 run hit the container memory ceiling
            # at ~60 concurrent joined VCs (EAGAIN errno-11 ×41 + two
            # mid-join SIGKILLs). Blocked → defer semantics: raise the
            # resource-pressure error BEFORE dispatching (no retry, no
            # breaker record) — the Join-All worker waits for pressure to
            # clear instead of spawning into exhaustion. Harness-safe:
            # a (test) voicechat without the guard symbol simply skips
            # the check — the guard must never break the join path.
            _v9910_guard = None
            try:
                from .voicechat import _vc_resource_pressure_check as _v9910_guard
            except Exception:  # noqa: BLE001
                _v9910_guard = None
            _v9910_blocked, _v9910_why = False, ""
            if _v9910_guard is not None:
                try:
                    _v9910_blocked, _v9910_why = _v9910_guard(quiet=True)
                except Exception:  # noqa: BLE001
                    _v9910_blocked, _v9910_why = False, ""
            if _v9910_blocked:
                sm.transition(VCJoinState.TRANSPORT_FAILED,
                              "resource_pressure_guard")
                out.final_state = VCJoinState.TRANSPORT_FAILED
                out.verdict = "resource_pressure"
                out.join_result = "transport_resource_pressure"
                out.retry_reason = "resource_pressure_guard"
                _emit_attempt_final(out)
                logger.warning(
                    "VC_RESOURCE_PRESSURE chat_id=%s account=%s "
                    "guard=%s — join DEFERRED before dispatch (v99.10 "
                    "FIX-C; no retry under pressure, no breaker record)",
                    marked_chat, account, _v9910_why,
                )
                raise _v9910_make_resource_pressure_error(
                    f"resource pressure guard blocked the join for "
                    f"{marked_chat} ({_v9910_why}) — target deferred "
                    f"(v99.10 FIX-C)"
                )
            transport_error: Optional[BaseException] = None
            entity_level_break = False
            _emit_attempt_event(
                "VC_JOIN_RPC_START", out, strategy=out.join_result,
                attempt_no=attempts_total,
            )
            for tr in range(cfg.transport_retries + 1):
                try:
                    await asyncio.wait_for(
                        backend._transport_dispatch(
                            marked_chat, stream, muted=muted),
                        timeout=cfg.join_timeout,
                    )
                    transport_error = None
                    break
                except asyncio.CancelledError:
                    raise
                except asyncio.TimeoutError as exc:
                    transport_error = exc
                except Exception as exc:  # noqa: BLE001
                    transport_error = exc
                if transport_error is None:
                    break
                _emit_attempt_event(
                    "VC_JOIN_RPC_RESULT", out,
                    result="raised", exc_class=type(transport_error).__name__,
                    transport_retry=tr + 1,
                )
                cls = _classify_transport_exc(transport_error)
                last_exc_class = type(transport_error).__name__
                if cls == "floodwait":
                    fw = _floodwait_seconds(transport_error)
                    try:
                        from .voicechat import _vc_join_account_park_floodwait
                        _vc_join_account_park_floodwait(account, fw)
                    except Exception:  # noqa: BLE001
                        pass
                    sm.transition(VCJoinState.FLOOD_WAIT, f"{fw}s")
                    out.final_state = VCJoinState.FLOOD_WAIT
                    out.verdict = "floodwait"
                    out.join_result = "transport_floodwait"
                    out.retry_reason = f"floodwait_{fw}s"
                    out.exc_class = last_exc_class
                    _emit_attempt_final(out)
                    raise VCTransportError(
                        f"PyTgCalls join failed: A wait of {fw} seconds "
                        f"is required (caused by JoinGroupCallRequest)"
                    ) from transport_error
                if cls == "resource_pressure":
                    # v99.10 FIX-B/C: native allocation failure (EAGAIN/
                    # ENOMEM/EMFILE). Do NOT retry here — the v99.09 run
                    # retried errno-11 3× in 6s under memory pressure and
                    # every retry failed (the allocator was starved).
                    # Do NOT burn the attempt budget either: raise the
                    # dedicated resource-pressure error (a
                    # VCTransportError subclass in the real package —
                    # every existing catch site keeps working) so the
                    # Join-All worker DEFERS the target, records NO
                    # breaker failure, and waits for pressure to clear
                    # (VC_JOIN_ALL_RESOURCE_PRESSURE_WAIT).
                    sm.transition(VCJoinState.TRANSPORT_FAILED,
                                  "resource_pressure")
                    out.final_state = VCJoinState.TRANSPORT_FAILED
                    out.verdict = "resource_pressure"
                    out.join_result = "transport_resource_pressure"
                    out.retry_reason = "resource_pressure"
                    out.exc_class = last_exc_class
                    _emit_attempt_final(out)
                    raise _v9910_make_resource_pressure_error(
                        f"resource pressure: native allocation failed "
                        f"during PyTgCalls join for {marked_chat} "
                        f"({transport_error}) — target deferred, no retry "
                        f"under pressure (v99.10 FIX-B)"
                    ) from transport_error
                if cls == "entity_level":
                    # §4: invalidate → fresh resolve → rebuild → retry.
                    try:
                        await _evict_poisoned_entity(marked_chat, identity)
                    except Exception:  # noqa: BLE001
                        pass
                    sm.transition(VCJoinState.ENTITY_FAILED,
                                  "transport_channel_invalid")
                    last_retry_reason = "transport_entity_refresh"
                    entity_level_break = True
                    break  # re-enter RESOLVING via the attempt loop
                if cls == "call_ended":
                    sm.transition(VCJoinState.CALL_ENDED, "call_invalid")
                    out.final_state = VCJoinState.CALL_ENDED
                    out.verdict = "call_ended"
                    out.join_result = "transport_call_ended"
                    out.exc_class = last_exc_class
                    _emit_attempt_final(out)
                    raise VCTransportError(
                        f"Telegram-side verification: the active call "
                        f"ENDED during the join attempt for "
                        f"{marked_chat} (call_id={call_id})."
                    ) from transport_error
                if cls == "transient_dc" and tr < cfg.transport_retries:
                    delay = cfg.transport_backoff_base * (2 ** tr)
                    logger.warning(
                        "VC_PIPELINE_TRANSPORT_RETRY chat_id=%s "
                        "account=%s retry=%d/%d backoff=%.1fs class=%s "
                        "— SAME PyTgCalls client (never reconnect), "
                        "exponential backoff (v99 §8)",
                        marked_chat, account, tr + 1,
                        cfg.transport_retries, delay, cls,
                    )
                    await asyncio.sleep(delay)
                    continue
                break  # deterministic — no transport retry

            if entity_level_break:
                # entity-level transport failure → bounded re-resolve
                if attempts_total < cfg.max_attempts:
                    await asyncio.sleep(min(
                        cfg.recovery_backoff_base * (2 ** (attempts_total - 1)),
                        8.0))
                    continue
                sm.transition(VCJoinState.UNRECOVERABLE, "entity_loop_exhausted")
                out.final_state = VCJoinState.UNRECOVERABLE
                out.verdict = "failed"
                out.exc_class = last_exc_class
                _emit_attempt_final(out)
                raise VCTransportError(
                    f"Entity resolution kept failing for {marked_chat} "
                    f"(account={account}) — unrecoverable (v99 §4)."
                ) from (transport_error or RuntimeError("entity loop"))

            if transport_error is not None:
                sm.transition(VCJoinState.TRANSPORT_FAILED, last_exc_class)
                if attempts_total < cfg.max_attempts:
                    last_retry_reason = "transport_backoff_retry"
                    await asyncio.sleep(min(
                        cfg.recovery_backoff_base * (2 ** (attempts_total - 1)),
                        8.0))
                    continue
                sm.transition(VCJoinState.UNRECOVERABLE, "transport_exhausted")
                out.final_state = VCJoinState.UNRECOVERABLE
                out.verdict = "failed"
                out.retry_reason = last_retry_reason
                out.exc_class = last_exc_class
                _emit_attempt_final(out)
                raise VCTransportError(
                    f"PyTgCalls join failed: {transport_error}"
                ) from transport_error

            # ---------------- TRANSPORT_ACCEPTED → VERIFY --------------
            sm.transition(VCJoinState.TRANSPORT_ACCEPTED,
                          "container_holds_target")
            out.rpc_result = out.join_result
            _emit_attempt_event(
                "VC_JOIN_RPC_RESULT", out, result="dispatched",
                rpc=out.join_result,
            )
            # ------------------------------------------------------------------
            # v99.05 RC-F4 (FINAL REBUILD — verify-time identity hygiene):
            # the transport join (PyTgCalls play()) resolves the CURRENT
            # call itself at dispatch; the pipeline's (call_id,
            # access_hash) may be a discovery-time snapshot (the §18
            # fastpath).  If the call rotated between discovery and
            # dispatch, the join went to the NEW call while the verify
            # would query the OLD identity ("joining one call while
            # verifying another" — mission §4/§5).  The hygiene lives
            # INSIDE _verify_participation and fires ONLY on a non-present
            # verdict (absent, or the stale_call GroupcallInvalid signal):
            # re-detect the CURRENT pair on the joining account's client →
            # pair CHANGED → VC_CALL_IDENTITY_CHANGED + adopt + re-verify;
            # pair unchanged → the negative stands.  Zero extra RPC on the
            # happy path (present on first verify) — the v99 §18 fastpath
            # contract is preserved.
            # ------------------------------------------------------------------
            sm.transition(VCJoinState.TELEGRAM_VERIFYING, "participant_gate")
            _emit_attempt_event(
                "VC_VERIFY_START", out, attempt_no=attempts_total,
                verify_attempts=cfg.verify_attempts,
            )
            # v99.05 RC-F4: the verify may adopt the CURRENT call pair
            # during identity hygiene (call rotation) — the ADOPTED
            # identity is the one the verdict was reached against and the
            # one that MUST be recorded on success (never the pre-verify
            # snapshot).
            _v9905_identity_out: dict = {}
            verdict = await _verify_participation(
                identity, marked_chat, call_id, access_hash,
                attempts=cfg.verify_attempts,
                backoff=cfg.verify_backoff_base,
                budget=cfg.verify_budget,
                identity_out=_v9905_identity_out,
            )
            if _v9905_identity_out.get("call_id"):
                _v9905_adopted = int(_v9905_identity_out["call_id"])
                _v9905_adopted_ah = int(_v9905_identity_out.get(
                    "access_hash") or 0)
                if _v9905_adopted != int(call_id or 0) \
                        or _v9905_adopted_ah != int(access_hash or 0):
                    call_id = _v9905_adopted
                    access_hash = _v9905_adopted_ah
                    out.call_id = call_id
                    out.access_hash = access_hash
                    _emit_attempt_event(
                        "VC_CALL_RECONCILE", out, result="identity_adopted",
                        new_access_hash=_fp_access_hash(access_hash),
                    )
            out.telegram_participant_result = verdict
            out.verification_result = verdict
            _emit_attempt_event(
                "VC_VERIFY_RESULT", out, verdict=verdict,
                attempt_no=attempts_total,
            )
            # v99.05 RC-F6: success evidence — capture the participant
            # identity + method + timestamp from the verifying query so
            # VC_JOIN_SUCCESS is reconstructable (mission §3).
            if verdict == "present":
                out.verification_method = "telegram_participant_query"
                try:
                    from .voicechat import _vc_last_participation_check
                    _v9905_ev = dict(_vc_last_participation_check)
                    out.participant_identity = str(
                        _v9905_ev.get("participant_identity", "")
                        or "peer=confirmed")
                    out.verification_timestamp = str(
                        _v9905_ev.get("checked_at", "") or "")
                except Exception:  # noqa: BLE001
                    out.participant_identity = "peer=confirmed"
                out.rpc_result = out.join_result
                await _on_verified(identity, marked_chat, call_id, access_hash,
                                   entity_source, entity_cls)
                sm.transition(VCJoinState.JOINED_CONFIRMED,
                              "participant_confirmed")
                out.final_state = VCJoinState.JOINED_CONFIRMED
                out.verdict = "joined"
                out.join_result = "transport_accepted"
                _emit_attempt_final(out)
                return out

            if verdict == "call_ended":
                # authoritative re-detect said the call is gone
                logger.warning(
                    "VC_JOIN_CALL_ENDED_DURING_JOIN chat_id=%s call_id=%s "
                    "account=%s — active call ended (authoritative "
                    "re-detect); cleaning up and reporting recoverable "
                    "failure (v99 §GATE)",
                    marked_chat, call_id, account,
                )
                try:
                    # v99.11 P0: reason-coded — the call object died
                    # mid-join (authoritative re-detect); the join's OWN
                    # target.
                    await _cleanup_local_call(
                        backend, marked_chat,
                        reason_code="CALL_ENDED_DURING_JOIN",
                        evidence="authoritative re-detect: the call "
                                 "object no longer exists server-side",
                    )
                except Exception:  # noqa: BLE001
                    pass
                sm.transition(VCJoinState.CALL_ENDED,
                              "participant_query_dead_call")
                out.final_state = VCJoinState.CALL_ENDED
                out.verdict = "call_ended"
                _emit_attempt_final(out)
                raise VCTransportError(
                    f"The active call ENDED during the join attempt for "
                    f"{marked_chat} (call_id={call_id}); local container "
                    f"object cleaned up. Recoverable — next cycle "
                    f"re-detects and rejoins (v99 §GATE)."
                )

            if verdict == "absent":
                # §7 FAILED-JOIN RECOVERY — v99.05 semantics (FINAL REBUILD):
                # the transport dispatched, the identity was reconciled
                # post-dispatch (RC-F4), and _verify_participation already
                # ran its identity hygiene (re-detect + re-verify with the
                # CURRENT pair).  A verdict that survived that hygiene means
                # Telegram answered, for our exact account id, with a
                # sustained NEGATIVE (empty targeted answer, streak-guarded)
                # against the CURRENT call identity: the join genuinely did
                # not stick.  Cleanup is justified as a FAILED join (not a
                # "phantom": the historical wording assumed the local join
                # was fake — the 2026-09-12 production evidence proved the
                # OPPOSITE failure mode was real too, a working join
                # destroyed by a blind verifier; with peer-based matching +
                # identity hygiene both failure modes are now correctly
                # classified).
                sm.transition(VCJoinState.TELEGRAM_ABSENT,
                              "telegram_absent_current_identity")
                last_retry_reason = "telegram_absent_recovery"
                # 1-3: stop the local call + release backend state —
                # explicit reason: the join FAILED Telegram-side
                # verification (mission §15: log whether cleanup was
                # performed because the join genuinely failed or because a
                # stale attempt was superseded).
                try:
                    await _cleanup_local_call(
                        backend, marked_chat,
                        # v99.11 P0: reason-coded — a FAILED join (the
                        # verdict survived identity hygiene: sustained
                        # negative against the CURRENT call identity).
                        reason_code="FAILED_JOIN_CLEANUP",
                        evidence="telegram_absent: sustained negative "
                                 "verification against the CURRENT call "
                                 "identity (v99.05 §15)",
                    )
                    logger.info(
                        "VC_JOIN_CLEANUP_REASON chat_id=%s account=%s "
                        "attempt=%d/%d reason=telegram_absent reason_code="
                        "FAILED_JOIN_CLEANUP — the local "
                        "call object was removed because Telegram-side "
                        "verification PROVED non-participation for this "
                        "account against the CURRENT call identity (a "
                        "genuinely failed join, v99.05 §15; v99.11 leave "
                        "policy)",
                        marked_chat, account, attempts_total,
                        cfg.max_attempts,
                    )
                except Exception as _v9905_cu:  # noqa: BLE001
                    logger.warning(
                        "VC_JOIN_CLEANUP_FAILED chat_id=%s account=%s "
                        "exc=%s (v99.05 §15)",
                        marked_chat, account, type(_v9905_cu).__name__,
                    )
                # 4-6: refresh the account-specific entity (§4 — the
                # resolver runs WITHOUT the provided hash), rebuild the
                # InputPeer, retry with bounded exponential backoff.
                can_retry = attempts_total < cfg.max_attempts
                if can_retry:
                    # alternate the stream strategy on retries: a failed
                    # silent-stream join retries with the OTHER transport
                    # form (null-stream), and vice versa.
                    cfg.prefer_real_stream = not cfg.prefer_real_stream
                    delay = min(
                        cfg.recovery_backoff_base * (2 ** (attempts_total - 1)),
                        30.0)
                    logger.warning(
                        "VC_PIPELINE_ABSENT_RECOVERY chat_id=%s account=%s "
                        "attempt=%d/%d backoff=%.1fs — Telegram-side "
                        "verification proved non-participation against the "
                        "CURRENT call identity (identity-hygiene passed); "
                        "local call cleaned as FAILED, retrying (v99 §7 + "
                        "v99.05 RC-F4)",
                        marked_chat, account, attempts_total,
                        cfg.max_attempts, delay,
                    )
                    await asyncio.sleep(delay)
                    continue
                # 8: rotate account ONLY when appropriate (§9): another
                # eligible account that has not been tried yet.
                # v99.06 FIX-3b: BEFORE rotating, transition THIS
                # account's participation record to a terminal non-joined
                # state — the join is PROVEN absent and the local call was
                # just left, so "left" is the honest state.  Without this,
                # the one-group-one-account registry rule would refuse the
                # rotated account's verified force-register (a non-terminal
                # owner blocks ownership transfer) and the registry would
                # keep pointing at the account that is provably NOT in the
                # call (the wrong-client leave/verify class of bugs).
                try:
                    from .voicechat import vc_registry_register
                    await vc_registry_register(
                        marked_chat, state="left", request_accepted=False,
                        intentional=True, account_id=account,
                    )
                except Exception as _v9906_left_exc:  # noqa: BLE001
                    logger.debug(
                        "VC_PIPELINE_ABSENT_LEFT_RECORD exc=%s",
                        _v9906_left_exc,
                    )
                rotated = await _try_rotate_account(
                    backend, identity, account, accounts_tried, cfg)
                if rotated is not None:
                    new_backend, new_ident, new_account = rotated
                    identity, account = new_ident, new_account
                    backend = new_backend
                    out.account = account
                    out.tg_user_id = identity.user_id
                    out.backend = getattr(backend, "backend_name", "pytgcalls")
                    logger.info(
                        "VC_PIPELINE_ACCOUNT_ROTATED chat_id=%s %s → %s — "
                        "atomic identity swap (entity/InputPeer/call/user_id "
                        "re-derived through the new account) (v99 §9)",
                        marked_chat, accounts_tried[-1], account,
                    )
                    continue
                # 9-10: honest terminal state.
                sm.transition(VCJoinState.UNRECOVERABLE, "absent_after_recovery")
                out.final_state = VCJoinState.UNRECOVERABLE
                out.verdict = "failed"
                out.retry_reason = last_retry_reason
                _emit_attempt_final(out)
                raise VCTransportError(
                    f"Join for {marked_chat} (account={account}) failed "
                    f"Telegram-side verification: after {attempts_total} "
                    f"attempts (each with identity hygiene against the "
                    f"CURRENT call) Telegram sustainedly answered ABSENT "
                    f"(absent) for this account id — a genuinely failed "
                    f"join; the local join was cleaned up. Honest terminal "
                    f"failure (v99 §7 + v99.05 RC-F1/RC-F4: peer-based "
                    f"matching — see the 2026-09-12 production log for the "
                    f"historical false-absence signature this replaces)."
                )

            # verdict == "unknown" — honest UNKNOWN (never success, never
            # destructive): preserve local state for the reconcile scan.
            logger.warning(
                "VC_JOIN_UNVERIFIED chat_id=%s call_id=%s account=%s "
                "telegram_verified=unknown verdict=unknown — transport "
                "accepted but Telegram-side participant verification did "
                "NOT confirm participation; NOT reporting success (state "
                "preserved, reconcile recheck converges) (v99 §GATE)",
                marked_chat, call_id, account,
            )
            sm.transition(VCJoinState.VERIFICATION_UNKNOWN, "inconclusive")
            out.final_state = VCJoinState.VERIFICATION_UNKNOWN
            out.verdict = "unverified"
            out.retry_reason = "verification_inconclusive"
            try:
                await _record_unverified(marked_chat, call_id, access_hash,
                                         identity, entity_source)
            except Exception:  # noqa: BLE001
                pass
            _emit_attempt_final(out)
            raise VCJoinUnverifiedError(
                f"Join transport accepted for {marked_chat} "
                f"(call_id={call_id}, account={account}) but Telegram-side "
                f"participant verification did NOT confirm participation "
                f"(verdict=unknown). The join is NOT reported as "
                f"successful; local state preserved and the reconcile "
                f"participant scan will re-check (v99 pipeline §GATE)."
            )

    # §10 single-flight key: only coalesce when the marked id is already
    # known (int refs — the join-all/distributed/discovery dominant path).
    # String refs resolve inside the run; concurrent string joins for the
    # same chat are additionally guarded by the resolver's single-flight.
    if isinstance(chat_ref, int):
        if chat_ref < -1000000000000:
            marked_key = int(chat_ref)
        elif chat_ref > 0:
            marked_key = _marked_of(chat_ref)
        else:
            marked_key = 0
    else:
        marked_key = 0
    if marked_key:
        outcome = await _pipeline_inflight_get_or_run((account, marked_key), _run)
    else:
        outcome = await _run()
    return outcome


# ---------------------------------------------------------------------------
# Verification (§6) — the pipeline's bounded convergence loop
# ---------------------------------------------------------------------------


async def _verify_participation(
    identity: VCAccountIdentity,
    marked_chat: int,
    call_id: int,
    access_hash: int,
    *,
    attempts: int,
    backoff: float,
    budget: float,
    identity_out: Optional[dict] = None,
) -> str:
    """Bounded Telegram-side participant verification through the EXACT
    join-owner account.  Uses the fixed ``vc_check_telegram_participation``
    (identity-correct client + user_id + v99.05 RC-F1 peer-based matching).

    v99.05 RC-F4 (FINAL REBUILD) — verify identity hygiene: an "absent"
    verdict is only trusted after re-detecting the CURRENT call identity
    on the owner account:
      * no active call           → "call_ended" (the target is gone),
      * (id, access_hash) CHANGED → adopt the current pair + re-verify
        (the verdict was against a stale identity — the mission §13
        STALE_CALL rule: rediscover, retry with the new identity),
      * pair unchanged           → the negative stands ("absent").

    ``identity_out`` (optional dict): filled with the FINAL identity the
    verdict was reached against ({"call_id", "access_hash"}) — the CALLER
    must record THIS identity on success (a hygiene-adopted pair must
    propagate to the registry + outcome, never the pre-verify snapshot).

    The historical flow called ``_vc_call_gone_evidence_check`` here,
    which ALSO re-registered ``state=joined`` + logged "join PRESERVED"
    on every absent verdict (the phantom registry writes that left the
    coverage reconciler reporting active=6 joined=6 after 3 FAILED
    targets on 2026-09-12) — the pipeline is now the ONLY writer of join
    state (mission §2 single source of truth).
    """
    from .voicechat import vc_check_telegram_participation

    def _emit_identity() -> None:
        if identity_out is not None:
            identity_out["call_id"] = int(call_id or 0)
            identity_out["access_hash"] = int(access_hash or 0)

    started = time.monotonic()
    last = "not_run"
    for attempt in range(1, attempts + 1):
        if time.monotonic() - started > budget:
            break
        try:
            last = await asyncio.wait_for(
                vc_check_telegram_participation(
                    marked_chat, call_id=call_id, access_hash=access_hash,
                    account_id=identity.account_id,
                    client=identity.client,
                ),
                timeout=15.0,
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            last = "unknown"
        if last == "present":
            _emit_identity()
            return "present"
        if last == "unknown":
            # v99.05 RC-F4: STALE_CALL hygiene — a GroupcallInvalid on the
            # verify query sets the evidence flag ``stale_call`` (the
            # queried (id, access_hash) pair is NOT a live call).  This is
            # the mission §13 STALE_CALL rule: rediscover the CURRENT call
            # identity and retry the verification ONCE with the new
            # identity (the historical code conflated this with absence).
            _stale = False
            try:
                from .voicechat import _vc_last_participation_check as _ev
                _stale = bool(_ev.get("stale_call")) and int(
                    _ev.get("chat_id", 0) or 0) == int(marked_chat)
            except Exception:  # noqa: BLE001
                _stale = False
            if _stale:
                _cur = await _current_call_identity(identity, marked_chat)
                if _cur is not None and not (_cur[0] == 0 and _cur[1] == 0):
                    if _cur[0] != int(call_id or 0) \
                            or _cur[1] != int(access_hash or 0):
                        logger.info(
                            "VC_CALL_IDENTITY_CHANGED chat_id=%s "
                            "old_call_id=%s new_call_id=%s "
                            "old_access_hash=%s new_access_hash=%s "
                            "source=stale_call_hygiene account=%s — the "
                            "verify query hit GroupcallInvalid on a STALE "
                            "identity; adopting the CURRENT pair and "
                            "re-verifying (mission §13 STALE_CALL) "
                            "(v99.05 RC-F4)",
                            marked_chat, call_id, _cur[0],
                            _fp_access_hash(access_hash),
                            _fp_access_hash(_cur[1]), identity.account_id,
                        )
                        call_id, access_hash = _cur[0], _cur[1]
                        await asyncio.sleep(0.5)
                        try:
                            last = await asyncio.wait_for(
                                vc_check_telegram_participation(
                                    marked_chat, call_id=call_id,
                                    access_hash=access_hash,
                                    account_id=identity.account_id,
                                    client=identity.client,
                                ),
                                timeout=15.0,
                            )
                        except asyncio.CancelledError:
                            raise
                        except Exception:  # noqa: BLE001
                            last = "unknown"
                        if last == "present":
                            _emit_identity()
                            return "present"
        if last == "absent":
            # v99.05 RC-F4: identity hygiene BEFORE trusting a negative —
            # pure re-detect (NO registry writes, NO "preserved" verdicts).
            # Semantics of _current_call_identity:
            #   None            → authoritatively NO active call (GetFullChannel
            #                     succeeded; full_chat.call is None)
            #   (0, 0)          → the probe itself failed (inconclusive — do
            #                     NOT trust the negative, do NOT destroy)
            #   (cid, ah)       → the CURRENT active-call identity pair
            _cur = await _current_call_identity(
                identity, marked_chat)
            if _cur is None:
                _emit_identity()
                return "call_ended"
            _cur_id, _cur_ah = _cur
            if _cur_id == 0 and _cur_ah == 0:
                # Probe inconclusive — the absent verdict is NOT trusted
                # (mission §15: never destroy a potentially-valid join on
                # weak evidence). UNKNOWN, reconcile re-checks.
                logger.info(
                    "VC_VERIFY_IDENTITY_PROBE_INCONCLUSIVE chat_id=%s "
                    "account=%s — the absent verdict is not trusted; "
                    "returning unknown (non-destructive) (v99.05 RC-F4)",
                    marked_chat, identity.account_id,
                )
                _emit_identity()
                return "unknown"
            if _cur_id != int(call_id or 0) or _cur_ah != int(access_hash or 0):
                logger.info(
                    "VC_CALL_IDENTITY_CHANGED chat_id=%s old_call_id=%s "
                    "new_call_id=%s old_access_hash=%s new_access_hash=%s "
                    "source=verify_hygiene account=%s — the absent verdict "
                    "was queried against a STALE identity; adopting the "
                    "CURRENT pair and re-verifying (mission §13 STALE_CALL: "
                    "rediscover + retry with the new identity) (v99.05 RC-F4)",
                    marked_chat, call_id, _cur_id,
                    _fp_access_hash(access_hash), _fp_access_hash(_cur_ah),
                    identity.account_id,
                )
                call_id, access_hash = _cur_id, _cur_ah
                await asyncio.sleep(0.5)
                try:
                    last = await asyncio.wait_for(
                        vc_check_telegram_participation(
                            marked_chat, call_id=call_id,
                            access_hash=access_hash,
                            account_id=identity.account_id,
                            client=identity.client,
                        ),
                        timeout=15.0,
                    )
                except asyncio.CancelledError:
                    raise
                except Exception:  # noqa: BLE001
                    last = "unknown"
                if last == "present":
                    _emit_identity()
                    return "present"
            # pair unchanged → the negative stands
            _emit_identity()
            return "absent"
        if last == "unknown" and attempt < attempts and \
                (time.monotonic() - started) + backoff * (2 ** (attempt - 1)) \
                <= budget:
            logger.info(
                "VC_PIPELINE_VERIFY_RETRY chat_id=%s account=%s "
                "attempt=%d/%d result=%s backoff=%.1fs (v99 §6)",
                marked_chat, identity.account_id, attempt, attempts, last,
                backoff * (2 ** (attempt - 1)),
            )
            await asyncio.sleep(backoff * (2 ** (attempt - 1)))
    _emit_identity()
    if last == "present":
        return "present"
    if last == "absent":
        return "absent"
    return "unknown"


async def _current_call_identity(
        identity: VCAccountIdentity,
        marked_chat: int) -> Optional[tuple[int, int]]:
    """v99.05 RC-F4: PURE current-call-identity probe on the join-owner
    account's client (single bounded GetFullChannel; entity from cache).
    Returns:
      * None          — authoritatively NO active call (the re-detect
                        succeeded and found full_chat.call is None),
      * (0, 0)        — the probe itself failed (inconclusive),
      * (cid, ah)     — the CURRENT active-call identity pair.

    Deliberately NO registry writes, NO backend mutation, NO "preserved"
    verdicts — the pipeline state machine is the single writer (mission
    §2).  This replaces the absent-path use of
    ``_vc_call_gone_evidence_check`` whose registry register(state=joined)
    produced the 2026-09-12 phantom bookkeeping."""
    try:
        from .voicechat import vc_detect_active_call, resolve_vc_entity
        _client = identity.client
        if _client is None:
            return (0, 0)
        _entity = None
        try:
            from .voicechat import _vc_entity_cache
            _ent = _vc_entity_cache.get(int(marked_chat))
            if _ent is not None and _ent.get("entity") is not None:
                _entity = _ent["entity"]
        except Exception:  # noqa: BLE001
            _entity = None
        if _entity is None and marked_chat > 0:
            try:
                from .voicechat import _vc_entity_cache
                _ent = _vc_entity_cache.get(-1000000000000 - int(marked_chat))
                if _ent is not None and _ent.get("entity") is not None:
                    _entity = _ent["entity"]
            except Exception:  # noqa: BLE001
                _entity = None
        if _entity is None:
            _res = await asyncio.wait_for(
                resolve_vc_entity(_client, int(marked_chat),
                                  chat_id=int(marked_chat), access_hash=0),
                timeout=10.0)
            if _res.get("ok"):
                _entity = _res.get("entity")
        if _entity is None:
            return (0, 0)
        _info = await asyncio.wait_for(
            vc_detect_active_call(_client, _entity), timeout=12.0)
        if not _info:
            return None
        return (int(_info.get("call_id") or 0),
                int(_info.get("access_hash") or 0))
    except asyncio.CancelledError:
        raise
    except Exception as exc:  # noqa: BLE001
        logger.debug(
            "VC_PIPELINE_CURRENT_IDENTITY_PROBE_FAILED chat_id=%s exc=%s: %s "
            "(v99.05 RC-F4 — inconclusive)",
            marked_chat, type(exc).__name__, str(exc)[:80],
        )
        return (0, 0)


# ---------------------------------------------------------------------------
# State/DB writes (§15) — joined ONLY on Telegram-verified evidence
# ---------------------------------------------------------------------------


async def _on_verified(identity: VCAccountIdentity, marked_chat: int,
                       call_id: int, access_hash: int,
                       entity_source: str, entity_cls: str) -> None:
    """Record the verified join: registry (state=joined, owner=this
    account — force-overwrite on verified evidence), strong verify
    evidence, join accounting, stale negatives cleared."""
    raw = _raw_of(marked_chat)
    try:
        from .voicechat import (
            vc_registry_register, _vc_record_verify_evidence,
            _vc_entity_negative_clear_for_chat,
        )
        await vc_registry_register(
            marked_chat, call_id=call_id or None,
            access_hash=access_hash or None, request_accepted=True,
            state="joined", intentional=True, account_id=identity.account_id,
            force_account=True,  # v99 §15: a VERIFIED re-join legitimately
            # changes the owner (the old sticky-first-writer behaviour
            # left a stale owner after rotation).
        )
        # v99.01 FIX-A (runtime-proven: 29× "TypeError: object NoneType
        # can't be used in 'await' expression" in the v99.00 deployment
        # bot-diagnostic.log): _vc_record_verify_evidence is a
        # SYNCHRONOUS bookkeeping function (voicechat.py v98.12 §35
        # evidence registry — plain ``def``, returns None, called
        # synchronously at all six voicechat.py sites).  Awaiting it
        # evaluates the sync body and then awaits None → TypeError; the
        # old except-TypeError "older signature" fallback re-raised the
        # SAME error (it awaited again), and the outer except-Exception
        # swallowed it — on this path that abort also skipped the
        # _vc_entity_negative_clear_for_chat hygiene below.  The
        # "signature without account_id" story was wrong (account_id
        # exists since v98.12) and only masked the mismatch: removed.
        # The sync call cannot raise await-related TypeErrors; the outer
        # except-Exception guard still bounds genuine bookkeeping faults.
        _vc_record_verify_evidence(
            marked_chat, outcome="joined", strength="strong",
            reason=f"pipeline:participant_confirmed:{entity_source}",
            account_id=identity.account_id, call_id=call_id,
        )
        # NOTE (v99 §3): per-account join ACCOUNTING (the 2-5s stagger
        # cooldown, v98.07 FIX-RR) is recorded by the voicechat join
        # SUCCESS site with the OWNING-account credit (v98.08 FIX-YY
        # phantom-account fix) — NOT here, to avoid double counting.
        _vc_entity_negative_clear_for_chat(raw)
        _vc_entity_negative_clear_for_chat(marked_chat)
    except Exception as exc:  # noqa: BLE001
        logger.debug("VC_PIPELINE_ON_VERIFIED_BOOKKEEPING exc=%s: %s",
                     type(exc).__name__, exc)


async def _record_unverified(marked_chat: int, call_id: int, access_hash: int,
                             identity: VCAccountIdentity,
                             entity_source: str) -> None:
    """Honest UNKNOWN: registry state must NOT say joined."""
    try:
        from .voicechat import vc_registry_register, _vc_record_verify_evidence
        await vc_registry_register(
            marked_chat, call_id=call_id or None,
            access_hash=access_hash or None, request_accepted=True,
            state="unknown", intentional=True,
            account_id=identity.account_id,
        )
        # v99.01 FIX-A: the same sync-call fix as in _on_verified —
        # awaiting the sync §35 evidence recorder raised the runtime
        # TypeError (logged as VC_PIPELINE_RECORD_UNVERIFIED exc=…);
        # calling it synchronously is the correct contract.
        _vc_record_verify_evidence(
            marked_chat, outcome="unknown", strength="weak",
            reason=f"pipeline:inconclusive:{entity_source}",
            account_id=identity.account_id, call_id=call_id,
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("VC_PIPELINE_RECORD_UNVERIFIED exc=%s: %s",
                     type(exc).__name__, exc)


# ---------------------------------------------------------------------------
# §11 — cleanup + §4 entity eviction + §9 rotation
# ---------------------------------------------------------------------------


async def _cleanup_local_call(backend: Any, marked_chat: int,
                              *, reason_code: str = "FAILED_JOIN_CLEANUP",
                              evidence: str = "") -> None:
    """Stop the stale local call + release backend state (§11).  Safe even
    when the join only partially succeeded.

    v99.11 P0 (native-cleanup ≠ Telegram-leave audit): this cleanup is
    the PIPELINE's OWN failed NEW join releasing its partially-created
    transport — the chat passed here is ALWAYS the join currently in
    flight (idempotent re-entry / call_ended / telegram_absent recovery
    paths), NEVER an unrelated ACTIVE transport.  The destructive call
    is reason-coded through the leave policy (FAILED_JOIN_CLEANUP /
    CALL_ENDED_DURING_JOIN) so it is explicit and auditable, and the
    owner-map pops happen ONLY for this same chat.
    """
    try:
        from .vc_resources import transport_lifecycle as _tl
        _tl.mark_stopping(marked_chat, reason=reason_code)
    except Exception:  # noqa: BLE001
        _tl = None

    # v99.11.1 FIX-1: per-operation FD census at the failed-join cleanup
    # boundary — the "cleanup" phase pairs with the native_join_dispatch
    # "before/failed" phases: every partial native allocation MUST be
    # observable as released here (the acquisition↥release pairing
    # evidence for exception paths).
    try:
        from .vc_resources import fd_op_phase as _v9911_fdop_cl
        _v9911_fdop_cl("failed_join_cleanup", marked_chat, "cleanup")
    except Exception:  # noqa: BLE001
        pass

    async def _v9911_factory():
        return await backend._leave_target(marked_chat)

    # v99.11 harness contract (the v99.10 guard pattern): a pipeline
    # imported against a fake package WITHOUT the vc_leave_policy module
    # (offline harnesses stub only voicechat + mtproto) keeps the direct
    # v99.10 leave — this path is the pipeline's OWN failed join, never
    # an ACTIVE transport; in production the policy module always exists
    # (same package) and the reason-coded chokepoint governs.
    try:
        from .vc_leave_policy import vc_leave_execute
    except Exception:  # noqa: BLE001
        vc_leave_execute = None

    try:
        if vc_leave_execute is not None:
            _ok = await vc_leave_execute(
                marked_chat, reason_code,
                "vc_pipeline._cleanup_local_call", _v9911_factory,
                evidence=evidence or
                "the pipeline's own in-flight join target",
            )
        else:
            _ok = await _v9911_factory() is not None
        logger.info(
            "VC_PIPELINE_LOCAL_CLEANUP chat_id=%s outcome=%s reason_code=%s "
            "(v99 §11; v99.11 leave policy: authorized=%s)",
            marked_chat, "success" if _ok else "denied_or_failed",
            reason_code, reason_code,
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("VC_PIPELINE_LOCAL_CLEANUP_EXC chat_id=%s exc=%s: %s",
                     marked_chat, type(exc).__name__, exc)
    try:
        from .voicechat import _vc_active_join_backends_by_chat
        _vc_active_join_backends_by_chat.pop(marked_chat, None)
        _vc_active_join_backends_by_chat.pop(_raw_of(marked_chat), None)
    except Exception:  # noqa: BLE001
        pass
    try:
        if _tl is not None:
            _tl.mark_released(marked_chat, reason=reason_code)
    except Exception:  # noqa: BLE001
        pass


async def _evict_poisoned_entity(chat_key: Any,
                                 identity: VCAccountIdentity) -> None:
    """§4: invalidate poisoned cross-scope cache entries for this chat."""
    raw = int(chat_key) if isinstance(chat_key, int) else 0
    marked = _marked_of(raw) if raw > 0 else raw
    try:
        from .voicechat import _vc_evict_poisoned_entity_cache
        _vc_evict_poisoned_entity_cache(raw, marked, identity.scope)
    except Exception as exc:  # noqa: BLE001
        logger.debug("VC_PIPELINE_EVICT_EXC chat=%s exc=%s", chat_key, exc)
    try:
        from .mtproto import _vc_entity_cache, _v9810_hash_invalid_record
        for k in {raw, marked}:
            if not k:
                continue
            entry = _vc_entity_cache.get(k)
            if isinstance(entry, dict):
                esc = entry.get("scope") or ""
                if esc and esc != identity.scope:
                    _vc_entity_cache.pop(k, None)
                    logger.info(
                        "VC_PIPELINE_ENTITY_EVICTED chat=%s "
                        "entry_scope=%s consumer=%s (v99 §4)",
                        k, esc, identity.scope,
                    )
                try:
                    _v9810_hash_invalid_record(
                        identity.scope, int(k),
                        int(entry.get("access_hash") or 0))
                except Exception:  # noqa: BLE001
                    pass
    except Exception as exc:  # noqa: BLE001
        logger.debug("VC_PIPELINE_EVICT_SCOPE_EXC exc=%s", exc)


async def _try_rotate_account(backend: Any, identity: VCAccountIdentity,
                              account: str, tried: list,
                              cfg: _PipelineCfg):
    """§9: pick the next eligible account (least-loaded, not parked in
    FloodWait, not already tried) and build its identity ATOMICALLY."""
    if len(tried) >= cfg.max_accounts:
        return None
    try:
        from .voicechat import (
            _vc_join_account_eligible, _vc_join_account_rank, vc_get_backend,
        )
        from .mtproto import get_userbot_cluster
        cluster = get_userbot_cluster()
        candidates = []
        for acc in cluster.get_healthy_accounts():
            aid = acc.get("account_id") or ""
            if not aid or aid in tried:
                continue
            ok, _why = _vc_join_account_eligible(aid)
            if not ok:
                # v98.07 FIX-RR (preserved observability): a candidate
                # found but NOT eligible (parked in FloodWait / cooldown /
                # unhealthy) is skipped EXPLICITLY — the rotation pin is
                # only applied to eligible accounts.
                logger.info(
                    "VC_JOIN_ROTATION_PIN_SKIPPED account=%s reason=%s — "
                    "candidate not eligible (parked/cooldown/unhealthy); "
                    "trying the next (v98.07 FIX-RR preserved, v99 §9)",
                    aid, _why,
                )
                continue
            candidates.append(aid)
        # least-loaded pick, v98.07 FIX-RR (preserved): rank =
        # (last_join_at, joins_in_flight, joins_made) ascending → the
        # least-recently-used / least-loaded account is tried FIRST.
        candidates.sort(key=lambda a: _vc_join_account_rank(a))
        for aid in candidates:
            try:
                nb = vc_get_backend(account_id=aid)
                if not getattr(nb, "_started", False):
                    await nb.start()
                ident = await VCAccountIdentity.resolve(nb, aid)
                if ident.client is None:
                    continue
                return (nb, ident, aid)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "VC_PIPELINE_ROTATION_CANDIDATE_FAILED account=%s "
                    "exc=%s: %s", aid, type(exc).__name__, exc,
                )
                continue
    except Exception as exc:  # noqa: BLE001
        logger.debug("VC_PIPELINE_ROTATE_SEARCH_FAILED exc=%s", exc)
    return None


# ---------------------------------------------------------------------------
# Public helpers (used by voicechat's rewiring + tests)
# ---------------------------------------------------------------------------


async def quick_recheck_evidence(
    backend: Any, marked_chat: int, call_id: int, access_hash: int,
    account_id: str = "",
) -> str:
    """The v98.13 §GATE idempotent re-join path replacement: re-verify an
    existing container entry instead of trusting it.  Returns
    present|absent|unknown|call_ended."""
    identity = await VCAccountIdentity.resolve(backend, account_id)
    return await _verify_participation(
        identity, marked_chat, call_id, access_hash,
        attempts=1, backoff=0.5, budget=6.0,
    )


__all__ = [
    "VCJoinState", "VCJoinStateMachine", "VCAccountIdentity",
    "VCJoinOutcome", "run_vc_join", "quick_recheck_evidence",
    "_make_silent_stream", "_verify_participation",
    # v99.03 RC-12: suppression window helpers (heartbeat flush + tests).
    "_null_stream_suppress_flush", "_null_stream_suppress_check",
    "_null_stream_suppress_record", "_null_stream_suppress_reset_for_tests",
]
