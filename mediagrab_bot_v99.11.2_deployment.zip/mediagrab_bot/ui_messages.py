"""UI messages — extracted from _bot_core.py.

All message text builders for the bot's menu system.
Pure presentation layer: depends only on config + md_escape.
"""

from __future__ import annotations

from mediagrab_bot.config import config
from mediagrab_bot.text_utils import md_escape
from mediagrab_bot.ai_modes import MODE_LABELS
from mediagrab_bot.utils_real import human_size

WELCOME = (
    "👋 *Welcome to MediaGrab AI Bot*\n\n"
    "Your all-in-one assistant for:\n"
    "📥 Downloading Telegram media\n"
    "🎬 AI-powered video recognition\n"
    "📜 History of your activity\n\n"
    "Tap a button below to begin — no commands needed."
)

MAIN_MENU_TEXT = (
    "*🏠 Main Menu*\n\n"
    "Choose what you'd like to do:"
)

DOWNLOAD_MENU_TEXT = (
    "*📥 Download Media*\n\n"
    "Two ways to download:\n\n"
    "• *↩️ Forward media to me* — forward any message with media\n"
    "• *🔗 Download by link or @username* — paste a t.me link or send "
    "a @channelusername\n\n"
    f"_ℹ️ Uses the official Bot API — files up to {config.max_file_size_mb} MB._"
)

ANALYZE_MENU_TEXT = (
    "*🎬 AI Analyze*\n\n"
    "Forward me a *video* and I'll:\n"
    "1️⃣ Extract several frames\n"
    "2️⃣ Send them to Google Gemini\n"
    "3️⃣ Return the detected title, season, episode, year & more\n\n"
    f"_ℹ️ Video file up to {config.max_file_size_mb} MB (Bot API limit)._"
)

HISTORY_MENU_TEXT = (
    "*📜 History*\n\n"
    "View or clear your recent activity."
)

SETTINGS_MENU_TEXT = (
    "*⚙️ Settings*\n\n"
    "Tap any option to cycle through its values."
)

HELP_MENU_TEXT = (
    "*ℹ️ Help*\n\n"
    "Pick a topic to learn more."
)

QUALITIES = ("Original", "1080p", "720p", "480p")
AI_MODELS = ("gemini-2.0-flash", "gemini-2.5-flash", "gemini-2.5-pro")
LANGUAGES = ("English", "हिन्दी", "Español", "français", "العربية", "中文", "português")


def settings_text(s: dict) -> str:
    def on_off(v) -> str:
        return "✅ On" if v else "⚪️ Off"

    ai_mode = s.get("ai_mode", "movie")
    has_key = "✅ Set" if s.get("gemini_api_key") else "⚪️ Using shared key"
    mode_label = MODE_LABELS.get(ai_mode, ai_mode)
    return (
        "*⚙️ Settings*\n\n"
        f"🎯 *Preferred Quality:* {s.get('preferred_quality')}\n"
        f"🧠 *AI Model:* `{s.get('ai_model')}`\n"
        f"🧠 *AI Mode:* {mode_label}\n"
        f"🌐 *Language:* {s.get('language')}\n"
        f"🗑️ *Auto Delete:* {on_off(s.get('auto_delete'))}\n"
        f"🔔 *Notifications:* {on_off(s.get('notifications'))}\n"
        f"🔑 *Gemini Key:* {has_key}\n\n"
        "_Tap an option to change it._"
    )


DOWNLOAD_FORWARD_PROMPT = (
    "📥 *Download mode active.*\n\n"
    "Forward me a Telegram message that contains media (video, document, audio, "
    "photo, voice, sticker, GIF, video note…).\n\n"
    "I'll download it and send the file back to you.\n\n"
    f"_Max {config.max_file_size_mb} MB per file (official Bot API limit)._"
)

DOWNLOAD_CANCEL_PROMPT = (
    "⏹️ Download cancelled. Returning you to the menu."
)

ANALYZE_FORWARD_PROMPT = (
    "🎬 *AI Analyze mode active.*\n\n"
    "Forward me media matching your selected AI mode:\n"
    "• *Movie ID* → a video\n"
    "• *Transcribe* → an audio file\n"
    "• *OCR / Describe / Translate* → an image or video\n\n"
    "Pick a different mode from *🧠 Choose AI Mode* first if needed.\n\n"
    f"_Max {config.max_file_size_mb} MB (official Bot API limit)._"
)

ANALYZE_CANCEL_PROMPT = "⏹️ Analysis cancelled. Returning you to the menu."


def progress_text(label: str, percent: float, current: int, total: int,
                  speed: str = "") -> str:
    bar_len = 18
    filled = int(bar_len * max(0.0, min(1.0, percent / 100)))
    bar = "█" * filled + "░" * (bar_len - filled)
    extra = f" • {speed}" if speed else ""
    return (
        f"*{label}*\n\n"
        f"`{bar}` {percent:5.1f}%\n"
        f"{human_size(current)} / {human_size(total)}{extra}"
    )


def download_done_text(file_name: str, size: int, media_type: str) -> str:
    return (
        "✅ *Download complete!*\n\n"
        f"📄 *File:* `{file_name}`\n"
        f"📦 *Size:* {human_size(size)}\n"
        f"🗂 *Type:* {media_type}\n\n"
        "Sending the file to you now…"
    )


def download_failed_text(reason: str) -> str:
    return (
        f"❌ *Download failed.*\n\n"
        f"Reason: `{reason}`\n\n"
        "You can try again from the Download menu."
    )


def file_too_big_text(limit_mb: int) -> str:
    return (
        f"⚠️ *File too large.*\n\n"
        f"The official Telegram Bot API can download files up to "
        f"*{limit_mb} MB*. Please forward a smaller file."
    )


def analyze_result_text(r: dict) -> str:
    confidence = r.get("confidence")
    if confidence is None:
        conf_str = "—"
    else:
        conf_str = f"{confidence * 100:.0f}%"

    def cell(label: str, val) -> str:
        return f"  • *{label}:* {val if val not in (None, '', 'Unknown') else '—'}"

    return (
        "🎬 *AI Analysis Result*\n\n"
        f"{cell('Category', r.get('category'))}\n"
        f"{cell('Title', r.get('title'))}\n"
        f"{cell('Season', r.get('season'))}\n"
        f"{cell('Episode', r.get('episode'))}\n"
        f"{cell('Year', r.get('year'))}\n"
        f"{cell('Language', r.get('language'))}\n"
        f"{cell('Quality', r.get('quality'))}\n"
        f"{cell('Confidence', conf_str)}\n"
    )


def analyze_failed_text(reason: str) -> str:
    return (
        f"❌ *Analysis failed.*\n\n"
        f"Reason: `{reason}`\n\n"
        "Make sure the file is a valid, non-corrupted video within the "
        "Bot API size limit."
    )


def render_history_rows(rows: list[dict], kind: str) -> str:
    if not rows:
        return (
            f"*{kind}*\n\n"
            "No entries yet. Once you start using the bot, your recent "
            "activity will appear here."
        )
    lines = [f"*{kind} — last {len(rows)} entries*", ""]
    for r in rows:
        date = (r.get("created_at") or "")[:16].replace("T", " ")
        if kind.startswith("📥"):
            name = r.get("file_name", "?")
            status_icon = "✅" if r.get("status") == "done" else "❌"
            lines.append(
                f"{status_icon} `{date}`\n"
                f"    📄 {name}\n"
                f"    📦 {human_size(r.get('file_size', 0))} · "
                f"{r.get('media_type', '—')} · {r.get('source', '—')}"
            )
        else:
            title = r.get("title") or r.get("file_name") or "?"
            cat = r.get("category") or "—"
            conf = r.get("confidence")
            conf_s = f"{conf * 100:.0f}%" if conf is not None else "—"
            status_icon = "✅" if r.get("status") == "done" else "❌"
            lines.append(
                f"{status_icon} `{date}`\n"
                f"    🎬 {title}\n"
                f"    🏷️ {cat} · conf {conf_s}"
            )
    return "\n".join(lines)


HELP_DOWNLOAD = (
    "📥 *How to Download Media*\n\n"
    "1. Tap *📥 Download Media* in the main menu.\n"
    "2. Tap *↩️ Forward media to me*.\n"
    "3. Forward a Telegram message that contains media.\n"
    "4. Watch the live progress bar.\n"
    "5. Receive the file back — ready to save or forward.\n\n"
    "Downloads are chunked, resumable and run concurrently, so you can "
    f"queue several at once.\n\n"
    f"_Limit: {config.max_file_size_mb} MB per file (official Bot API ceiling)."
    f" Files you receive back are sent as documents (up to 50 MB)._"
)

HELP_AI = (
    "🤖 *How AI Recognition Works*\n\n"
    "1. Tap *🎬 AI Analyze* and forward a video.\n"
    "2. The bot extracts {n} evenly-spaced frames using ffmpeg.\n"
    "3. Frames are sent to Google Gemini with a structured prompt.\n"
    "4. You receive: category, title, season, episode, year, language, "
    "quality and a confidence score.\n\n"
    "Only the extracted frames (PNG/JPEG) are sent — never your full video.\n\n"
    f"_Limit: {config.max_file_size_mb} MB video (official Bot API ceiling)._"
)

HELP_FORMATS = (
    "📄 *Supported Formats*\n\n"
    "Telegram-native: photo, voice, video note, sticker, GIF/animation, video, "
    "audio, document.\n\n"
    "Common file extensions handled:\n"
    "• Videos: mp4, mkv, avi, mov, webm, flv, wmv, m4v, ts, 3gp\n"
    "• Audio: mp3, m4a, aac, flac, ogg, opus, wav\n"
    "• Archives: zip, rar, 7z, tar, gz, bz2, xz\n"
    "• Documents: pdf, epub, txt, doc, docx, mobi, azw3\n"
    "• Apps: apk, xapk, ipa, deb, rpm, exe, msi\n"
    "• Images: jpg, png, webp, bmp, gif, heic\n"
    "• Disc images: iso, img, bin\n"
    "• Subtitles: srt, ass, ssa, vtt\n\n"
    f"_All downloads use the official Bot API ({config.max_file_size_mb} MB max)._"
)

HELP_FAQ = (
    "❓ *Frequently Asked Questions*\n\n"
    "Q: Do I need to type any commands?\n"
    "A: No — everything is done through inline buttons.\n\n"
    "Q: Why can't I download a file by pasting a link?\n"
    "A: This bot uses only the official Telegram Bot API, which cannot "
    "resolve arbitrary t.me message links. Forward the media directly to the "
    "bot instead.\n\n"
    f"Q: How big a file can I download?\n"
    f"A: Up to {config.max_file_size_mb} MB — the official Bot API getFile "
    f"ceiling. Received files are sent back as documents (up to 50 MB).\n\n"
    "Q: Where are my files stored?\n"
    "A: Temporarily on the server, then auto-deleted (see Settings).\n\n"
    "Q: Which Gemini model is used?\n"
    "A: Default is gemini-2.0-flash — change it in Settings."
)


# --- Inspector (chat / user finder) ---
INSPECTOR_MENU_TEXT = (
    "*🔍 Inspect Chat / User*\n\n"
    "Look up any *public* Telegram chat, channel or user by their "
    "@username or a t.me link — the bot fetches the title, type, member "
    "count and description via the official Bot API.\n\n"
    "_Note: the Bot API can only see public chats (or private ones the bot "
    "has joined). This is a Telegram limitation, not a bot limitation._"
)

INSPECTOR_PROMPT = (
    "🔍 *Inspector mode active.*\n\n"
    "Send me one of:\n"
    "• a @username (e.g. `@durov`)\n"
    "• a public t.me link (e.g. `https://t.me/telegram`)\n\n"
    "I'll fetch everything the Bot API exposes about that chat/user."
)

INSPECTOR_EMPTY = "⚠️ Please send a @username or a public t.me link."


def inspect_result_text(info: dict) -> str:
    kind = info.get("type") or "chat"
    title = info.get("title") or info.get("first_name") or "—"
    uname = info.get("username")
    uname_s = f"@{uname}" if uname else "—"
    members = info.get("members")
    members_s = f"{members:,}" if members else "—"
    desc = (info.get("description") or "").strip()
    bio = (info.get("bio") or "").strip()
    lines = [f"🔍 *Inspection Result*", "",
             f"🏷️ *Type:* {kind}",
             f"📛 *Name:* {title}",
             f"🔗 *Username:* {uname_s}"]
    if info.get("last_name"):
        lines.append(f"👤 *Last name:* {info['last_name']}")
    if members:
        lines.append(f"👥 *Members:* {members_s}")
    if info.get("is_bot") is not None:
        lines.append(f"🤖 *Bot:* {'Yes' if info['is_bot'] else 'No'}")
    if info.get("chat_id"):
        lines.append(f"🆔 *ID:* `{info['chat_id']}`")
    if desc:
        lines.append(f"\n📝 *Description:*\n{desc[:800]}")
    if bio:
        lines.append(f"\n💬 *Bio:*\n{bio[:800]}")
    return "\n".join(lines)


def inspect_failed_text(reason: str) -> str:
    return (
        f"❌ *Inspection failed.*\n\n"
        f"Reason: `{reason}`\n\n"
        "Common causes: the username doesn't exist, the chat is private and "
        "the bot hasn't joined it, or Telegram rate-limited the request."
    )


# --- Media Toolbox ---
TOOLBOX_MENU_TEXT = (
    "*🧰 Media Toolbox*\n\n"
    "Pick a tool, then forward the media it needs. All processing runs "
    "locally with ffmpeg / Pillow — your files never leave the server "
    "except to be sent back to you."
)

TOOLBOX_PROMPTS = {
    "audio": (
        "🎵 *Extract Audio mode.*\n\n"
        "Forward a *video* — I'll extract its audio track as an MP3."
    ),
    "thumb": (
        "🖼️ *Thumbnail mode.*\n\n"
        "Forward a *video or image* — I'll grab a representative frame / "
        "thumbnail and send it back."
    ),
    "info": (
        "📋 *Media Info mode.*\n\n"
        "Forward any media — I'll show its full technical metadata "
        "(codec, resolution, bitrate, duration…)."
    ),
    "compress": (
        "🎬 *Compress Video mode.*\n\n"
        "Forward a *video* — I'll re-encode it with H.264 + a fast preset "
        "to shrink the file size."
    ),
    "imgconv": (
        "🔄 *Convert Image mode.*\n\n"
        "Forward an *image* — reply with the target format "
        "(`png`, `jpg`, `webp`, `bmp`) and I'll convert it."
    ),
}

TOOLBOX_INVALID_MEDIA = "⚠️ That tool needs a different kind of media. Please forward the right type."


def media_info_text(info: dict) -> str:
    lines = ["📋 *Media Information*", ""]
    for k, v in info.items():
        if v in (None, "", []):
            continue
        lines.append(f"• *{k}:* `{v}`")
    return "\n".join(lines)


# --- Library ---
LIBRARY_MENU_TEXT = (
    "*⭐ Library*\n\n"
    "Your bookmarked media. After any download, tap *Save to Library* to "
    "keep a record (filename, type, size, note) you can browse & search later."
)

LIBRARY_EMPTY = (
    "⭐ *Your library is empty.*\n\n"
    "After downloading media, tap *Save to Library* to bookmark it here."
)


def library_entry_text(entry: dict) -> str:
    date = (entry.get("created_at") or "")[:16].replace("T", " ")
    note = entry.get("note") or ""
    tags = entry.get("tags") or ""
    lines = [
        "⭐ *Library Entry*", "",
        f"📄 *File:* `{entry.get('file_name','?')}`",
        f"🗂 *Type:* {entry.get('media_type','—')}",
        f"📦 *Size:* {human_size(entry.get('file_size',0))}",
        f"🕒 *Saved:* `{date}`",
    ]
    if tags:
        lines.append(f"🏷️ *Tags:* {tags}")
    if note:
        lines.append(f"\n📝 *Note:*\n{note}")
    return "\n".join(lines)


def library_list_text(rows: list[dict], title: str) -> str:
    if not rows:
        return f"*{title}*\n\n{LIBRARY_EMPTY.split(chr(10),1)[1]}"
    lines = [f"*{title} — {len(rows)} entries*", ""]
    for i, r in enumerate(rows, 1):
        date = (r.get("created_at") or "")[:10]
        lines.append(
            f"{i}. `{r.get('file_name','?')}`\n"
            f"    📦 {human_size(r.get('file_size',0))} · "
            f"{r.get('media_type','—')} · {date}"
        )
    return "\n".join(lines)


# --- Stats ---
STATS_MENU_TEXT = "*📊 Statistics*\n\nView your activity or global bot stats."


def user_stats_text(s: dict) -> str:
    by_type = s.get("by_type") or []
    type_lines = "\n".join(f"  • {t or '—'}: {n}" for t, n in by_type) or "  • —"
    return (
        "👤 *Your Stats*\n\n"
        f"📥 *Downloads:* {s.get('downloads',0)}\n"
        f"📦 *Downloaded:* {human_size(s.get('download_bytes',0))}\n"
        f"🤖 *AI Analyses:* {s.get('analyses',0)}\n"
        f"⭐ *Library entries:* {s.get('library',0)}\n"
        f"🔍 *Inspected chats:* {s.get('inspected',0)}\n\n"
        f"📊 *Top media types:*\n{type_lines}"
    )


def global_stats_text(s: dict) -> str:
    return (
        "🌍 *Global Stats*\n\n"
        f"👥 *Users:* {s.get('users',0)}\n"
        f"📥 *Downloads:* {s.get('downloads',0)}\n"
        f"📦 *Downloaded:* {human_size(s.get('download_bytes',0))}\n"
        f"🤖 *AI Analyses:* {s.get('analyses',0)}\n"
        f"⭐ *Library entries:* {s.get('library',0)}\n"
        f"🔍 *Inspected chats:* {s.get('inspected',0)}\n"
    )


# --- QR Code ---
QR_MENU_TEXT = (
    "*🔳 QR Code Generator*\n\n"
    "Turn any text or link into a scannable QR code — perfect for sharing "
    "URLs, Wi-Fi credentials, contacts or commands."
)

QR_PROMPT = (
    "🔳 *QR mode active.*\n\n"
    "Send me the text or link you want encoded into a QR code."
)


# --- Quota ---
def quota_exceeded_text(count_limit: int, bytes_limit_mb: int) -> str:
    return (
        f"⚠️ *Daily quota reached.*\n\n"
        f"You've hit your daily limit of *{count_limit} downloads* or "
        f"*{bytes_limit_mb} MB*. Please come back tomorrow."
    )


# --- New help section ---
HELP_FEATURES = (
    "🔍 *Inspect Chat / User*\n\n"
    "Tap *🔍 Inspect Chat*, then send a @username or public t.me link. The "
    "bot fetches the chat's title, type, member count and description via "
    "the official Bot API. Only *public* chats are visible (a Telegram "
    "limitation).\n\n"
    "🧰 *Media Toolbox*\n\n"
    "• *Extract Audio (MP3)* — pull the audio track out of a video.\n"
    "• *Extract Thumbnail* — grab a representative frame.\n"
    "• *Media Info* — full technical metadata (codec, resolution, bitrate…).\n"
    "• *Compress Video* — re-encode to shrink file size.\n"
    "• *Convert Image* — PNG ⇄ JPG ⇄ WEBP ⇄ BMP.\n\n"
    "⭐ *Library*\n\n"
    "Bookmark any download to your personal, searchable library.\n\n"
    "📊 *Stats* — your activity and global bot counters.\n\n"
    "🔳 *QR Code* — encode any text/link into a QR code."
)


# --- AI modes ---
AI_MODES_TEXT = (
    "*🧠 AI Mode*\n\n"
    "Pick what you want the AI to do. Each mode accepts different media:\n\n"
    "🎬 *Movie / Series ID* — identify a film/series/anime from video frames\n"
    "🎵 *Audio Transcription* — transcribe speech from an audio file\n"
    "🔤 *Text Extraction (OCR)* — pull all visible text from images/frames\n"
    "📝 *Scene Description* — describe what's in images/frames\n"
    "🌐 *Image Translation* — OCR + translate text to your language\n\n"
    "The selected mode is used when you tap *Forward media to analyze*."
)


def ai_mode_set_text(label: str) -> str:
    return f"✅ *AI mode set to:* {label}\n\nNow forward the matching media type."


# --- Batch / album ---
BATCH_MENU_TEXT = (
    "*📦 Batch / Album*\n\n"
    "Forward me a *media group* (Telegram album — up to 10 photos/videos sent "
    "together) or several media messages in a row.\n\n"
    "I'll download them all and send them back as a single album."
)

BATCH_PROMPT = (
    "📦 *Batch mode active.*\n\n"
    "Forward a media group (album) or several media messages now. "
    "Send them one after another within ~5 seconds."
)

BATCH_TIMEOUT = "⏱️ Batch window closed. Processing what was received…"
BATCH_EMPTY = "⚠️ No media received during the batch window. Try again."


def batch_summary_text(count: int, total_size: int) -> str:
    return (
        f"📦 *Batch complete!*\n\n"
        f"Files processed: *{count}*\n"
        f"Total size: *{human_size(total_size)}*\n\n"
        "Sending them as an album now…"
    )


def batch_failed_text(reason: str) -> str:
    return f"❌ *Batch failed.*\n\nReason: `{reason}`"


# --- Scheduled downloads ---
SCHEDULED_MENU_TEXT = (
    "*⏰ Scheduled Tasks*\n\n"
    "Queue a download or analysis to run later.\n\n"
    "How to schedule: open *📥 Download*, forward media, then tap "
    "*Schedule instead* to pick a time."
)


def scheduled_list_text(rows: list[dict]) -> str:
    if not rows:
        return "⏰ *Scheduled Tasks*\n\nNo scheduled tasks. Queue one from Download."
    lines = ["⏰ *Scheduled Tasks*", ""]
    for r in rows:
        run_at = (r.get("run_at") or "")[:16].replace("T", " ")
        kind = r.get("kind", "?")
        status = r.get("status", "?")
        icon = {"pending": "⏳", "done": "✅", "failed": "❌"}.get(status, "•")
        lines.append(f"{icon} #{r['id']} `{run_at}` — {kind} ({status})")
    return "\n".join(lines)


SCHEDULE_PROMPT = (
    "⏰ *Schedule mode.*\n\n"
    "Send a time in the format `YYYY-MM-DD HH:MM` (e.g. `2025-12-31 23:00`), "
    "then forward the media to queue."
)

SCHEDULE_INVALID = "⚠️ Invalid time. Use `YYYY-MM-DD HH:MM` (24h, e.g. 2025-12-31 23:00)."


# --- Backup / restore ---
BACKUP_MENU_TEXT = (
    "*💾 Backup & Restore*\n\n"
    "Export your settings, history, library and inspections as a JSON file. "
    "Import a previous backup to restore settings."
)

BACKUP_EXPORTING = "💾 Exporting your data…"
BACKUP_IMPORT_PROMPT = (
    "📥 Send me the backup JSON file to import your settings."
)


def backup_export_done_text(file_name: str, size: int, counts: dict) -> str:
    parts = []
    for k, v in counts.items():
        parts.append(f"  • {k}: {v}")
    return (
        f"✅ *Backup exported!*\n\n"
        f"📄 `{file_name}` ({human_size(size)})\n\n"
        f"Contents:\n" + "\n".join(parts)
    )


def backup_import_done_text(summary: dict) -> str:
    return (
        f"✅ *Import complete!*\n\n"
        f"Settings restored: {summary.get('settings', 0)} fields"
    )


def backup_failed_text(reason: str) -> str:
    return f"❌ *Backup failed:* `{reason}`"


# --- Admin ---
ADMIN_DENIED = (
    "🚫 *Admin only.*\n\nYou do not have permission to use this section."
)

ADMIN_MENU_TEXT = (
    "*🛡️ Admin Panel*\n\n"
    "Bot management tools (admin only)."
)

ADMIN_BCAST_PROMPT = (
    "📣 *Broadcast mode.*\n\n"
    "Send the message text you want to broadcast to all bot users."
)


def admin_users_text(users: list[dict], total: int) -> str:
    if not users:
        return "👥 *Users*\n\nNo users yet."
    lines = [f"👥 *Users ({total} total)*", ""]
    for u in users[:20]:
        name = u.get("first_name") or u.get("username") or str(u.get("tg_id"))
        uname = f"@{u['username']}" if u.get("username") else "—"
        admin = " 🛡️" if u.get("is_admin") else ""
        lines.append(f"• {name}{admin}\n   {uname} · `{u['tg_id']}`")
    if total > 20:
        lines.append(f"\n_…and {total - 20} more_")
    return "\n".join(lines)


def admin_bcast_done_text(sent: int, failed: int) -> str:
    return (
        f"📣 *Broadcast complete!*\n\n"
        f"✅ Sent: {sent}\n"
        f"❌ Failed: {failed}"
    )


# --- Inline mode ---
def inline_help_text() -> str:
    return (
        "🎬 *MediaGrab AI Bot*\n\n"
        "Available inline queries:\n"
        "• `@bot help` — this help\n"
        "• `@bot qr <text>` — generate a QR code\n"
        "• `@bot info` — your quick stats\n\n"
        "Add me to a chat and tap /start to use all features."
    )


def inline_stats_text(s: dict) -> str:
    return (
        f"📊 Your stats:\n"
        f"📥 Downloads: {s.get('downloads',0)}\n"
        f"🤖 Analyses: {s.get('analyses',0)}\n"
        f"⭐ Library: {s.get('library',0)}"
    )


# ===========================================================================
# Link / username download texts (Task ID 5)
# ===========================================================================

LINK_DOWNLOAD_PROMPT = (
    "🔗 *Download by link or @username*\n\n"
    "Send me any of:\n"
    "• A message link: `https://t.me/channel/123`\n"
    "• A private link: `https://t.me/c/1234567890/123`\n"
    "• A @username: `@channelusername`\n"
    "• A channel link: `https://t.me/channel`\n\n"
    "_For public channels I can fetch the message directly. For private "
    "links (t.me/c/…) the bot must be a member of that chat._"
)

LINK_DOWNLOAD_EMPTY = (
    "⚠️ Please send a Telegram message link or @username."
)


def link_parse_error_text(reason: str) -> str:
    return f"❌ *Could not parse that input.*\n\n`{reason}`"


def link_resolving_text(description: str) -> str:
    return f"📥 Resolving: {description}…"


def link_download_failed_text(reason: str) -> str:
    return (
        f"❌ *Download failed.*\n\n"
        f"Reason: `{reason}`\n\n"
        "Common causes:\n"
        "• The message was deleted or doesn't exist\n"
        "• The chat is private and the bot isn't a member\n"
        "• The message has no downloadable media"
    )


def link_resolved_ask_msgid(info: dict) -> str:
    """Show resolved chat info and ask for a message id."""
    title = info.get("title") or info.get("first_name") or "—"
    uname = info.get("username")
    uname_s = f"@{uname}" if uname else "—"
    kind = info.get("type") or "chat"
    members = info.get("members")
    members_s = f"{members:,}" if members else "—"
    desc = (info.get("description") or "").strip()

    lines = [
        "✅ *Chat resolved!*\n",
        f"📛 *Name:* {title}",
        f"🏷️ *Type:* {kind}",
        f"🔗 *Username:* {uname_s}",
    ]
    if members:
        lines.append(f"👥 *Members:* {members_s}")
    if desc:
        lines.append(f"\n📝 *Description:*\n{desc[:400]}")
    lines.append("")
    lines.append(
        "📝 *Now send me the message id* (a number, e.g. `123`).\n"
        "You can find it as the last part of a t.me link, or in the "
        "channel's message URL."
    )
    return "\n".join(lines)


