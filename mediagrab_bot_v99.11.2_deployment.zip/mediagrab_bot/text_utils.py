"""Text escaping utilities — extracted from _bot_core.py.

Provides Markdown v1 and HTML escaping for dynamic text inserted into
Telegram messages. These are pure functions with no dependencies.
"""

from __future__ import annotations

from typing import Any

_MD_V1_SPECIALS = ("\\", "`", "*", "_", "[")


def md_escape(text: Any) -> str:
    """Escape Markdown v1 special characters in *dynamic* text.

    Use this on ANY user-generated or variable text before inserting it into a
    Markdown-formatted message: usernames, filenames, captions, chat titles,
    error messages, descriptions, etc.

    Returns ``str(text)`` with ``\\``, ```` ` ````, ``*``, ``_``, ``[`` prefixed
    by a backslash. Static bot text with intentional formatting (``*bold*``)
    should NOT be escaped — only the dynamic insertions.
    """
    if text is None:
        return ""
    s = str(text)
    for ch in _MD_V1_SPECIALS:
        s = s.replace(ch, "\\" + ch)
    return s


def html_escape(text: Any) -> str:
    """Escape HTML special characters (for parse_mode='HTML')."""
    if text is None:
        return ""
    s = str(text)
    return (s.replace("&", "&amp;")
             .replace("<", "&lt;")
             .replace(">", "&gt;"))
