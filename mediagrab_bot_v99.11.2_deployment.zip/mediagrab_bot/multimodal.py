"""Multimodal subsystem — physically extracted from _bot_core.py.

Voice enrollment, multimodal message dispatch (STT/vision/document/TTS),
Wit.ai integration, and voice pipeline checks.

NOTE: 13 core symbols (WitaiService, MultimodalInput, MultimodalResponse,
_multimodal_route, _multimodal_classify_input, _multimodal_pick_*, etc.)
are pre-existing LOST CODE — referenced in the baseline but never defined.
They remain as undefined references (same baseline behavior).

Cross-subsystem dependencies resolved without importing _bot_core:
  - MTProto / VC / Talkative -> imported from respective modules.
  - v85_diag -> diag_hooks DI bridge.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import shutil
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import aiofiles
import httpx
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, filters, Application, ApplicationHandlerStop, MessageHandler

from .config import config
from .text_utils import md_escape
from .db_layer import repo, get_db, _db
from .utils_real import (
    get_bot, register_bot, safe_send_message, safe_send_document,
    safe_filename, safe_reply_text, unique_path, remove_path, human_size,
    telegram_media_type, extension_category, is_available,
)
from .states import set_state, get_state, reset
from .media_processor import download_slot, with_retries, safe_unlink
from .ai_modes import build_prompt, normalise, accepts, media_kind_for, render_result, MODE_ORDER
from .frame_extractor import extract_frames, FrameExtractionError
from .mtproto import mtproto_get_client, mtproto_is_available
from .voicechat import vc_talkative_start, vc_talkative_stop, _vc_is_admin
from .talkative_hooks import talkative_generate
from .diag_hooks import v85_diag

# ai_analyzer helpers (pre-existing lost code — same broken import as _bot_core baseline).
from .ai_analyzer import _get_client, _read_bytes, _run_in_thread, _extract_text, cleanup_frames

logger = logging.getLogger("mediagrab")

_MULTIMODAL_HANDLER_REGISTERED: bool = False


# ===========================================================================
# Multimodal data structures + routing (reconstructed from call-site contracts)
# ===========================================================================

@dataclass
class MultimodalInput:
    """Classified multimodal input from a Telegram message."""
    modality: str = "text"          # text|voice|audio|photo|image|video|video_note|gif|sticker|document|reaction
    file_id: str | None = None
    file_path: Path | None = None
    mime_type: str | None = None
    language: str = "auto"
    duration_seconds: float | None = None
    text: str = ""
    extra: dict[str, Any] = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.extra is None:
            self.extra = {}


@dataclass
class MultimodalResponse:
    """Routing decision + result accumulator for a multimodal request."""
    provider: str = "local"         # witai|gemini|groq|openrouter|local
    intent: str = ""                # voice_transcription|image_ocr|document_extract|reaction
    metadata: dict[str, Any] = None  # type: ignore[assignment]
    modality: str = ""              # echo of input modality (set for reactions)
    reaction_emoji: str | None = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


def _multimodal_pick_stt_provider() -> str:
    """Pick the best available STT provider (witai > groq > gemini > local)."""
    if getattr(config, "witai_enabled", False) and getattr(config, "witai_server_token", ""):
        return "witai"
    if getattr(config, "groq_api_key", ""):
        return "groq"
    if getattr(config, "gemini_api_key", ""):
        return "gemini"
    return "local"


def _multimodal_pick_vision_provider() -> str:
    """Pick the best available vision provider (gemini > local)."""
    if getattr(config, "gemini_api_key", ""):
        return "gemini"
    return "local"


def _multimodal_pick_text_provider() -> str:
    """Pick the best available text provider (groq > openrouter > gemini > local)."""
    if getattr(config, "groq_api_key", ""):
        return "groq"
    if getattr(config, "openrouter_api_key", "") and getattr(config, "openrouter_model", ""):
        return "openrouter"
    if getattr(config, "gemini_api_key", ""):
        return "gemini"
    return "local"


def _multimodal_classify_input(update: Update) -> MultimodalInput:
    """Classify a Telegram message into a MultimodalInput (synchronous)."""
    msg = update.message
    if msg is None:
        return MultimodalInput(modality="text")

    # Voice / audio
    if msg.voice:
        return MultimodalInput(
            modality="voice", file_id=msg.voice.file_id,
            mime_type="audio/ogg",
            duration_seconds=float(msg.voice.duration or 0),
            language="auto",
        )
    if msg.audio:
        return MultimodalInput(
            modality="audio", file_id=msg.audio.file_id,
            mime_type=msg.audio.mime_type or "audio/mpeg",
            duration_seconds=float(msg.audio.duration or 0),
            extra={"file_name": msg.audio.file_name, "caption": msg.caption or ""},
        )
    # Photo / image
    if msg.photo:
        best = max(msg.photo, key=lambda p: (p.width or 0) * (p.height or 0))
        return MultimodalInput(
            modality="photo", file_id=best.file_id,
            mime_type="image/jpeg",
            text=msg.caption or "",
        )
    # Video / video_note / animation (gif)
    if msg.video:
        return MultimodalInput(
            modality="video", file_id=msg.video.file_id,
            mime_type=msg.video.mime_type or "video/mp4",
            duration_seconds=float(msg.video.duration or 0),
            text=msg.caption or "",
        )
    if msg.video_note:
        return MultimodalInput(
            modality="video_note", file_id=msg.video_note.file_id,
            mime_type="video/mp4",
            duration_seconds=float(msg.video_note.duration or 0),
        )
    if msg.animation:
        return MultimodalInput(
            modality="gif", file_id=msg.animation.file_id,
            mime_type="video/mp4",
            duration_seconds=float(msg.animation.duration or 0),
            text=msg.caption or "",
        )
    # Sticker (reaction)
    if msg.sticker:
        emoji = getattr(msg.sticker, "emoji", None) or "👍"
        return MultimodalInput(
            modality="sticker", file_id=msg.sticker.file_id,
            mime_type="image/webp",
            extra={"emoji": emoji},
        )
    # Document
    if msg.document:
        return MultimodalInput(
            modality="document", file_id=msg.document.file_id,
            mime_type=msg.document.mime_type or "application/octet-stream",
            extra={"file_name": msg.document.file_name or "", "caption": msg.caption or ""},
        )
    # Pure text
    return MultimodalInput(modality="text", text=msg.text or "")


async def _multimodal_route(
    mm_input: MultimodalInput,
    *,
    chat_context: dict | None = None,
) -> MultimodalResponse:
    """Route a MultimodalInput to the appropriate provider pipeline.

    Sets response.metadata['needs_stt'/'needs_vision'/'needs_ocr'] flags
    and response.provider based on input modality + available providers.
    """
    resp = MultimodalResponse()
    modality = mm_input.modality

    if modality in ("voice", "audio"):
        resp.intent = "voice_transcription"
        resp.metadata["needs_stt"] = True
        resp.provider = _multimodal_pick_stt_provider()
    elif modality in ("photo", "image"):
        resp.intent = "image_ocr"
        resp.metadata["needs_vision"] = True
        resp.provider = _multimodal_pick_vision_provider()
    elif modality in ("video", "video_note", "gif"):
        resp.intent = "video_analysis"
        resp.metadata["needs_vision"] = True
        resp.provider = _multimodal_pick_vision_provider()
    elif modality == "sticker":
        resp.intent = "reaction"
        resp.modality = "reaction"
        resp.reaction_emoji = mm_input.extra.get("emoji", "👍")
        resp.provider = "local"
    elif modality == "document":
        resp.intent = "document_extract"
        resp.metadata["needs_ocr"] = True
        resp.provider = _multimodal_pick_vision_provider()
    else:
        resp.intent = "text"
        resp.provider = _multimodal_pick_text_provider()

    return resp


async def _multimodal_detect_intent(text: str) -> dict[str, Any]:
    """Detect the intent of a text message using Wit.ai (with local fallback).

    Returns ``{"intent": str, "confidence": float}``.
    """
    if not text:
        return {"intent": "", "confidence": 0.0}

    # Try Wit.ai message understanding if available.
    try:
        from .frame_extractor import witai_service
        if witai_service.available:
            result = await witai_service.message_understanding(text)
            intents = result.get("intents", [])
            if intents:
                best = max(intents, key=lambda i: i.get("confidence", 0))
                return {
                    "intent": best.get("name", ""),
                    "confidence": float(best.get("confidence", 0.0)),
                }
    except Exception as exc:
        logger.debug("WITAI_INTENT_FAILED: %s", exc)

    return {"intent": "", "confidence": 0.0}


_voice_enroll_state: dict[tuple[int, int], dict[str, Any]] = {}


_VOICE_ENROLL_TIMEOUT = 120.0  # seconds — pending state auto-expires


_VOICE_ENROLL_MIN_DURATION = 10.0  # seconds — minimum accepted sample length


_VOICE_ENROLL_MAX_DURATION = 30.0  # seconds — maximum accepted sample length


_VOICE_ENROLL_MAX_FILE_SIZE = 25 * 1024 * 1024  # 25 MB — reasonable ceiling


_VOICE_ENROLL_LOCK: asyncio.Lock | None = None  # lazily initialised


_voice_enroll_handler_registered: bool = False
# V85.5 FIX (ASYNC-G-001): strong-reference set for in-flight enrollment
# tasks so the asyncio scheduler doesn't garbage-collect them mid-flight.


_voice_enroll_tasks: set = set()


def _voice_enroll_lock() -> asyncio.Lock:
    """Lazy-init the asyncio.Lock so it binds to the running event loop."""
    global _VOICE_ENROLL_LOCK
    if _VOICE_ENROLL_LOCK is None:
        _VOICE_ENROLL_LOCK = asyncio.Lock()
    return _VOICE_ENROLL_LOCK


def _voice_enroll_start(admin_id: int, chat_id: int) -> None:
    """V60 Fix #1: create pending enrollment state bound to BOTH
    admin_user_id AND bot_chat_id. Records started_at, expires_at,
    workflow, status.

    V85.5 FIX (RELI-G-001): each enrollment session gets a unique 32-bit
    ``generation`` token so a stale cleanup call from a PREVIOUS enrollment
    can't accidentally clear the state of a NEW enrollment that started
    after the first one expired/errored. The token is captured by
    ``_voice_enroll_process_bot_api`` and threaded through every
    ``_voice_enroll_clear`` call.
    """
    now = time.monotonic()
    # RELI-G-001: 32-bit generation token (monotonic-clock based).
    generation = int(now * 1000) & 0xFFFFFFFF
    _voice_enroll_state[(admin_id, chat_id)] = {
        "admin_user_id": admin_id,
        "bot_chat_id": chat_id,
        "started_at": now,
        "expires_at": now + _VOICE_ENROLL_TIMEOUT,
        "workflow": "voice_enroll",
        "status": "awaiting_sample",
        "claimed": False,  # one-shot consumption flag
        "generation": generation,  # RELI-G-001
    }
    logger.info("VOICE_ENROLL_START admin=%s chat=%s expires_in=%ss gen=%d",
                admin_id, chat_id, _VOICE_ENROLL_TIMEOUT, generation)


def _voice_enroll_get(admin_id: int, chat_id: int) -> dict[str, Any] | None:
    """Return the pending state for (admin_id, chat_id) if non-expired, else None.
    Auto-evicts expired entries."""
    key = (admin_id, chat_id)
    st = _voice_enroll_state.get(key)
    if st is None:
        return None
    if time.monotonic() > st.get("expires_at", 0):
        _voice_enroll_state.pop(key, None)
        logger.info("VOICE_ENROLL_EXPIRED admin=%s chat=%s", admin_id, chat_id)
        return None
    return st


def _voice_enroll_active(admin_id: int, chat_id: int | None = None) -> bool:
    """Check whether (admin_id[, chat_id]) has a non-expired pending enrollment.
    If chat_id is None, returns True if ANY chat has a pending state for admin_id."""
    if chat_id is not None:
        return _voice_enroll_get(admin_id, chat_id) is not None
    now = time.monotonic()
    found = False
    for k in list(_voice_enroll_state.keys()):
        if k[0] != admin_id:
            continue
        st = _voice_enroll_state.get(k)
        if st is None:
            continue
        if now <= st.get("expires_at", 0):
            found = True
        else:
            _voice_enroll_state.pop(k, None)
            logger.info("VOICE_ENROLL_EXPIRED admin=%s chat=%s", k[0], k[1])
    return found


def _voice_enroll_clear(admin_id: int, chat_id: int | None = None,
                       expected_gen: int | None = None) -> None:
    """V60 Fix #8: clear pending state.
    If chat_id is provided, clears only that (admin, chat) entry.
    If chat_id is None, clears ALL pending states for admin_id.

    V85.5 FIX (RELI-G-001): if ``expected_gen`` is provided, the state is
    only popped if its stored ``generation`` matches — this prevents a
    stale cleanup from a previous enrollment run from clearing the state
    of a NEW enrollment that started after the old one expired/errored.
    If ``expected_gen`` is None, the previous behaviour (unconditional
    pop) is preserved for callers that don't have a generation token
    (e.g. admin-initiated cancel).
    """
    if chat_id is None:
        for k in list(_voice_enroll_state.keys()):
            if k[0] == admin_id:
                if expected_gen is not None:
                    st = _voice_enroll_state.get(k)
                    if st is None or st.get("generation") != expected_gen:
                        continue  # generation mismatch — don't clear
                _voice_enroll_state.pop(k, None)
        logger.info("VOICE_ENROLL_CLEAR admin=%s (all chats) gen=%s",
                    admin_id, expected_gen)
    else:
        key = (admin_id, chat_id)
        if expected_gen is not None:
            st = _voice_enroll_state.get(key)
            if st is not None and st.get("generation") != expected_gen:
                logger.info(
                    "VOICE_ENROLL_CLEAR_SKIP admin=%s chat=%s expected_gen=%s actual_gen=%s — generation mismatch",
                    admin_id, chat_id, expected_gen, st.get("generation"),
                )
                return  # don't clear — newer enrollment owns this slot
        if _voice_enroll_state.pop(key, None) is not None:
            logger.info("VOICE_ENROLL_CLEAR admin=%s chat=%s gen=%s",
                        admin_id, chat_id, expected_gen)


async def _voice_enroll_claim(admin_id: int, chat_id: int) -> dict[str, Any] | None:
    """V60 Fix #10: atomically claim the pending state so only ONE update
    is processed. Returns a copy of the claimed state, or None if not
    claimable (no state, already claimed, or expired)."""
    async with _voice_enroll_lock():
        st = _voice_enroll_get(admin_id, chat_id)
        if st is None:
            return None
        if st.get("claimed"):
            return None
        st["claimed"] = True
        st["status"] = "processing"
        return dict(st)


def _voice_enroll_diag(user_id: int, chat_id: int, stage: str,
                       detail: str = "") -> None:
    """V60 Fix #12: stage diagnostics. Logs every enrollment stage with a
    stable stage name and safe (redacted) detail. Never exposes secrets,
    API keys, file paths, or raw provider responses."""
    safe_detail = (detail or "").replace("\n", " ")[:140]
    # Redact anything that looks like an API key or long token.
    safe_detail = re.sub(r"(sk-|xi-|key-|Bearer\s)[A-Za-z0-9_\-]{6,}",
                         "[REDACTED]", safe_detail)
    # V85.5 FIX (SEC-G-004): also redact Gemini (AIza) and JWT tokens.
    safe_detail = re.sub(r"AIza[0-9A-Za-z_\-]{20,}", "[REDACTED]", safe_detail)
    safe_detail = re.sub(
        r"eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{6,}",
        "[REDACTED]", safe_detail,
    )
    logger.info("VOICE_ENROLL_DIAG user=%s chat=%s stage=%s detail=%s",
                user_id, chat_id, stage, safe_detail)


# V60 Fix #3: real audio validation via ffprobe.


async def _ffprobe_duration(path: str) -> float | None:
    """Return audio duration in seconds via ffprobe.

    Returns None if ffprobe is unavailable, the file is not decodable, or
    the probe times out. NEVER estimates duration from file size."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "ffprobe", "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError:
        logger.warning("FFPROBE_MISSING — ffprobe binary not on PATH")
        return None
    except OSError as exc:
        logger.warning("FFPROBE_LAUNCH_FAILED exc=%s", exc)
        return None
    try:
        stdout, _stderr = await asyncio.wait_for(proc.communicate(), timeout=15)
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        # V85.5 FIX (ERR-G-006): reap the zombie so we don't leak a
        # defunct ffprobe process on every timeout.
        try:
            await proc.wait()
        except Exception:  # noqa: BLE001
            pass
        logger.warning("FFPROBE_TIMEOUT path=%s", path)
        return None
    if proc.returncode != 0:
        logger.warning("FFPROBE_NONZERO rc=%s path=%s", proc.returncode, path)
        return None
    text = (stdout or b"").decode(errors="ignore").strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


async def _ffprobe_has_audio_stream(path: str) -> bool:
    """Verify that the file contains at least one decodable audio stream."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "ffprobe", "-v", "error",
            "-select_streams", "a",
            "-show_entries", "stream=codec_type",
            "-of", "default=noprint_wrappers=1:nokey=1",
            path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except (FileNotFoundError, OSError):
        return False
    try:
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=15)
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        # V85.5 FIX (ERR-G-006): reap the zombie so we don't leak a
        # defunct ffprobe process on every timeout.
        try:
            await proc.wait()
        except Exception:  # noqa: BLE001
            pass
        return False
    if proc.returncode != 0:
        return False
    return b"audio" in (stdout or b"")


# V60 Fix #5: real voice-clone provider adapters.


async def _voice_clone_enroll(provider: str, api_key: str, sample_path: str,
                              *, user_id: int, mime_type: str,
                              duration: float) -> dict[str, Any]:
    """V60 Fix #5: real voice clone provider adapter.

    Supported providers:
        - elevenlabs  → POST https://api.elevenlabs.io/v1/voices/add
          multipart form: name, files, description

    Returns {"profile_id": <voice_id>} on success,
            {"error": <reason>} on failure.

    No placeholder `pass` branches. If a provider is configured but not
    implemented, an explicit unsupported_provider error is returned.
    """
    provider = (provider or "").strip().lower()
    if provider == "elevenlabs":
        return await _elevenlabs_enroll(
            api_key, sample_path, user_id=user_id, mime_type=mime_type)
    # V60 Fix #5: explicit failure for unknown providers — no silent pass.
    return {"error": f"unsupported_provider:{provider or '(empty)'}"}


async def _elevenlabs_enroll(api_key: str, sample_path: str, *,
                             user_id: int, mime_type: str) -> dict[str, Any]:
    """Enroll a voice profile with ElevenLabs via the official REST API.

    Endpoint: POST https://api.elevenlabs.io/v1/voices/add
    Auth: xi-api-key header.
    Body: multipart/form-data with `name`, `files` (sample), `description`.

    Returns {"profile_id": <voice_id>} on success,
            {"error": <reason>} on failure.

    V85.5 FIX (SEC-G-005): ``user_id`` is NOT sent to ElevenLabs — the voice
    profile name is an opaque random ID and the description is a generic
    string. This prevents leaking Telegram user IDs to a third party.
    V85.5 FIX (RELI-G-004): the voice sample is read with ``aiofiles`` so the
    event loop is not blocked by the file read.
    V85.5 FIX (SEC-G-006): provider error response bodies are sanitized
    before being returned / logged.
    """
    import uuid as _uuid  # local import — Section A (top-level imports) is out of edit range
    url = "https://api.elevenlabs.io/v1/voices/add"
    headers = {"xi-api-key": api_key}
    # SEC-G-005: do NOT embed user_id in the provider-side name/description.
    name = f"voice_{_uuid.uuid4().hex[:12]}"
    description = "Voice profile for MediaGrab bot"
    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            # RELI-G-004: async file read so the event loop is not blocked.
            async with aiofiles.open(sample_path, "rb") as fh:
                content = await fh.read()
            files = {
                "files": (
                    os.path.basename(sample_path),
                    content,
                    mime_type or "audio/ogg",
                ),
            }
            data = {"name": name, "description": description}
            resp = await client.post(
                url, headers=headers, files=files, data=data)
    except (httpx.RequestError, OSError) as exc:
        return {"error": f"transport:{type(exc).__name__}"}
    if resp.status_code != 200:
        # SEC-G-006: sanitize the response body before exposing it.
        raw_body = (resp.text or "")[:200]
        sanitized_body = re.sub(
            r"(sk-|xi-|key-|Bearer\s|AIza)[A-Za-z0-9_\-]{6,}",
            "[REDACTED]", raw_body,
        )
        return {"error": f"http_{resp.status_code}:{sanitized_body[:120]}"}
    try:
        body = resp.json()
    except ValueError:
        return {"error": "invalid_json"}
    voice_id = body.get("voice_id")
    if not voice_id:
        return {"error": "no_voice_id_in_response"}
    return {"profile_id": str(voice_id)}


async def _voice_clone_delete_profile(provider: str, api_key: str,
                                      profile_id: str) -> bool:
    """Best-effort provider-side profile deletion (rollback on DB failure)."""
    provider = (provider or "").strip().lower()
    if provider == "elevenlabs":
        url = f"https://api.elevenlabs.io/v1/voices/{profile_id}"
        headers = {"xi-api-key": api_key}
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.delete(url, headers=headers)
            return resp.status_code in (200, 204)
        except (httpx.RequestError, OSError):
            return False
    return False


async def _voice_enroll_db_table_ready() -> bool:
    """V60 Fix #6: verify voice_profiles table exists before runtime use."""
    try:
        db = await get_db()
        async with db.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='voice_profiles'"
        ) as cur:
            row = await cur.fetchone()
        return row is not None
    except Exception as exc:  # noqa: BLE001
        logger.warning("VOICE_ENROLL_DB_CHECK_FAILED exc=%s", exc)
        return False


async def _voice_enroll_process_bot_api(update: Update,
                                        context: ContextTypes.DEFAULT_TYPE,
                                        user_id: int, chat_id: int,
                                        state: dict[str, Any]) -> None:
    """V60 Fix #1/#2/#3/#5/#6/#7/#8/#11/#12: process a voice/audio enrollment
    sample through the Bot API path.

    Stages (logged for diagnostics):
        sample_received → download_started → download_complete →
        validation_started → duration_detected → validation_passed →
        provider_request_started → provider_request_success →
        profile_persisted → cleanup_complete → enrollment_success

    Failure stages:
        download_failed, ffprobe_missing, invalid_audio, sample_too_short,
        sample_too_long, provider_not_configured, provider_failed,
        persistence_failed, enrollment_exception

    V85.5 FIX (RELI-G-001): captures the enrollment ``generation`` token
    from the claimed state and passes it as ``expected_gen`` to every
    ``_voice_enroll_clear`` call, so a stale cleanup from a previous run
    can't wipe the state of a newer enrollment.
    """
    msg = update.message
    bot = context.bot
    # RELI-G-001: capture the generation token from the claimed state.
    gen = state.get("generation") if isinstance(state, dict) else None

    # Determine file_id, mime, extension, declared duration.
    file_id: str | None = None
    file_ext = ".ogg"
    mime_type = ""
    declared_duration = 0.0
    if getattr(msg, "voice", None):
        file_id = msg.voice.file_id
        mime_type = (msg.voice.mime_type or "audio/ogg").lower()
        declared_duration = float(getattr(msg.voice, "duration", 0) or 0)
        file_ext = ".ogg"  # Telegram voice notes are OGG Opus
    elif getattr(msg, "audio", None):
        file_id = msg.audio.file_id
        mime_type = (msg.audio.mime_type or "audio/mpeg").lower()
        declared_duration = float(getattr(msg.audio, "duration", 0) or 0)
        if msg.audio.file_name and "." in msg.audio.file_name:
            file_ext = os.path.splitext(msg.audio.file_name)[1].lower()[:8] or ".mp3"
        elif "mpeg" in mime_type or "mp3" in mime_type:
            file_ext = ".mp3"
        elif "ogg" in mime_type:
            file_ext = ".ogg"
        elif "wav" in mime_type:
            file_ext = ".wav"
        elif "mp4" in mime_type or "m4a" in mime_type:
            file_ext = ".m4a"
    elif getattr(msg, "document", None) is not None:
        file_id = msg.document.file_id
        mime_type = (msg.document.mime_type or "audio/ogg").lower()
        if msg.document.file_name and "." in msg.document.file_name:
            file_ext = os.path.splitext(msg.document.file_name)[1].lower()[:8] or ".bin"

    if not file_id:
        _voice_enroll_diag(user_id, chat_id, "download_failed", "no_file_id")
        await safe_send_message(bot, chat_id,
            "❌ Couldn't read that media. Please try again.")
        _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
        return

    # V60 Fix #11: acknowledge sample receipt immediately.
    await safe_send_message(bot, chat_id,
        "🎙 Voice sample received.\n"
        "Checking audio quality and duration…")
    _voice_enroll_diag(user_id, chat_id, "sample_received",
                       f"mime={mime_type} dur_decl={declared_duration:.1f}")

    tmp_dir: str | None = None
    tmp_path: str | None = None
    try:
        # V60 Fix #2: secure temp directory + unique filename.
        tmp_dir = tempfile.mkdtemp(prefix=f"voice_enroll_{user_id}_")
        unique_name = f"sample_{user_id}_{int(time.time())}{file_ext}"
        tmp_path = os.path.join(tmp_dir, unique_name)

        # V60 Fix #2: download through the Bot API file flow.
        _voice_enroll_diag(user_id, chat_id, "download_started", "")
        try:
            tg_file = await bot.get_file(file_id)
            await tg_file.download_to_drive(custom_path=tmp_path)
        except Exception as exc:  # noqa: BLE001
            logger.error("VOICE_ENROLL_DOWNLOAD_FAILED user=%s exc=%s: %s",
                         user_id, type(exc).__name__, str(exc)[:200])
            _voice_enroll_diag(user_id, chat_id, "download_failed",
                               type(exc).__name__)
            await safe_send_message(bot, chat_id,
                "❌ Couldn't download the voice sample. Please try again.")
            _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
            return
        _voice_enroll_diag(user_id, chat_id, "download_complete",
                           f"size={os.path.getsize(tmp_path) if os.path.exists(tmp_path) else 0}")

        # V60 Fix #3: file exists + non-zero size + reasonable ceiling.
        if not os.path.exists(tmp_path) or os.path.getsize(tmp_path) < 100:
            _voice_enroll_diag(user_id, chat_id, "invalid_audio", "tiny_or_missing")
            await safe_send_message(bot, chat_id,
                "❌ The voice sample could not be downloaded. Please try again.")
            _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
            return
        file_size = os.path.getsize(tmp_path)
        if file_size > _VOICE_ENROLL_MAX_FILE_SIZE:
            _voice_enroll_diag(user_id, chat_id, "invalid_audio",
                               f"file_size={file_size}")
            await safe_send_message(bot, chat_id,
                "❌ The voice sample is too large (max 25 MB). "
                "Please send a shorter clip.")
            _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
            return

        # V60 Fix #3: real duration validation via ffprobe.
        _voice_enroll_diag(user_id, chat_id, "validation_started", "")
        duration = await _ffprobe_duration(tmp_path)
        if duration is None:
            # V60 Fix #3: explicit configuration error — no silent guess.
            _voice_enroll_diag(user_id, chat_id, "ffprobe_missing", "")
            await safe_send_message(bot, chat_id,
                "❌ Couldn't verify sample duration — `ffprobe` is unavailable "
                "on the server.\nAsk the administrator to install FFmpeg/ffprobe.")
            _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
            return
        _voice_enroll_diag(user_id, chat_id, "duration_detected",
                           f"{duration:.2f}s")

        # V60 Fix #3: enforce 10–30 second range. Do NOT reject a valid
        # 11s or 16s sample.
        if duration < _VOICE_ENROLL_MIN_DURATION:
            _voice_enroll_diag(user_id, chat_id, "sample_too_short",
                               f"{duration:.2f}s")
            await safe_send_message(bot, chat_id,
                f"⚠️ This sample is {duration:.1f} seconds long.\n"
                f"Please send at least {_VOICE_ENROLL_MIN_DURATION:.0f} seconds "
                f"of clear speech.")
            _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
            return
        if duration > _VOICE_ENROLL_MAX_DURATION:
            _voice_enroll_diag(user_id, chat_id, "sample_too_long",
                               f"{duration:.2f}s")
            await safe_send_message(bot, chat_id,
                f"⚠️ This sample is {duration:.1f} seconds long.\n"
                f"Please keep it under {_VOICE_ENROLL_MAX_DURATION:.0f} seconds.")
            _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
            return

        # V60 Fix #3: verify a decodable audio stream exists.
        if not await _ffprobe_has_audio_stream(tmp_path):
            _voice_enroll_diag(user_id, chat_id, "invalid_audio", "no_audio_stream")
            await safe_send_message(bot, chat_id,
                "❌ This file doesn't contain a decodable audio stream. "
                "Please send a standard voice note.")
            _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
            return
        _voice_enroll_diag(user_id, chat_id, "validation_passed", "")

        # V60 Fix #5: real provider check.
        provider_name = os.environ.get("VOICE_CLONE_PROVIDER", "").strip().lower()
        provider_api_key = os.environ.get("VOICE_CLONE_API_KEY", "").strip()
        if not provider_name or not provider_api_key:
            _voice_enroll_diag(user_id, chat_id, "provider_not_configured",
                               provider_name or "(empty)")
            await safe_send_message(bot, chat_id,
                "❌ Voice cloning is not configured on this server.\n\n"
                "Voice cloning requires a separate provider (e.g. ElevenLabs).\n"
                "Set these environment variables:\n"
                "• `VOICE_CLONE_PROVIDER` — e.g. `elevenlabs`\n"
                "• `VOICE_CLONE_API_KEY` — your provider API key\n\n"
                "_Note: Voice cloning is SEPARATE from Wit.ai STT and AI chat._\n"
                "_Wit.ai handles voice transcription; voice cloning is for TTS._")
            _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
            return

        # V60 Fix #6: verify voice_profiles table exists before provider call.
        if not await _voice_enroll_db_table_ready():
            _voice_enroll_diag(user_id, chat_id, "persistence_failed",
                               "voice_profiles_table_missing")
            logger.error("VOICE_ENROLL_DB_TABLE_MISSING — cannot persist profile")
            await safe_send_message(bot, chat_id,
                "❌ Voice enrollment is not ready — the database hasn't been "
                "initialised. Please contact the administrator.")
            _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
            return

        # V60 Fix #5: real provider enrollment request.
        _voice_enroll_diag(user_id, chat_id, "provider_request_started",
                           provider_name)
        result = await _voice_clone_enroll(
            provider_name, provider_api_key, tmp_path,
            user_id=user_id, mime_type=mime_type, duration=duration,
        )
        if not result or not result.get("profile_id"):
            reason = (result or {}).get("error", "unknown")
            _voice_enroll_diag(user_id, chat_id, "provider_failed", reason[:120])
            logger.error("VOICE_ENROLL_PROVIDER_FAILED user=%s provider=%s reason=%s",
                         user_id, provider_name, reason[:200])
            await safe_send_message(bot, chat_id,
                "❌ Voice enrollment could not be completed.\n"
                "Please try another clear voice sample.")
            _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
            return
        profile_id = result["profile_id"]
        _voice_enroll_diag(user_id, chat_id, "provider_request_success",
                           f"provider={provider_name} profile_id={str(profile_id)[:12]}")

        # V60 Fix #6: secure DB persistence via parameterized SQL.
        # V85.5 FIX (RELI-G-002): INSERT OR REPLACE clobbers created_at,
        # last_tested_at, and last_test_result on every re-enrollment. Use
        # ON CONFLICT DO UPDATE so only the mutable columns are touched,
        # and delete the previous provider-side profile if the provider or
        # profile_id changed (so we don't leak orphaned voices at the
        # provider). Wrap in try/except so a SQLite version without
        # UPSERT support degrades gracefully.
        try:
            db = await get_db()
            # RELI-G-002: SELECT existing row so we can clean up the old
            # provider-side profile if the provider / profile_id changed.
            old_prov: str | None = None
            old_pid: str | None = None
            try:
                async with db.execute(
                    "SELECT provider, provider_profile_id FROM voice_profiles "
                    "WHERE owner_user_id = ?",
                    (user_id,),
                ) as cur:
                    row = await cur.fetchone()
                if row is not None:
                    old_prov = row[0] if row[0] else None
                    old_pid = row[1] if row[1] else None
            except Exception:  # noqa: BLE001
                pass  # table may not have these columns — fall through
            if (old_prov is not None and old_pid is not None and
                    (old_prov != provider_name or old_pid != str(profile_id))):
                try:
                    await _voice_clone_delete_profile(
                        old_prov or "", provider_api_key, old_pid or "")
                    logger.info(
                        "VOICE_ENROLL_OLD_PROFILE_DELETED user=%s old_prov=%s old_pid=%s — replaced by new enrollment",
                        user_id, old_prov, str(old_pid)[:12],
                    )
                except Exception:  # noqa: BLE001
                    logger.warning(
                        "VOICE_ENROLL_OLD_PROFILE_DELETE_FAILED user=%s old_prov=%s old_pid=%s — continuing (orphan at provider)",
                        user_id, old_prov, str(old_pid)[:12],
                    )
            try:
                # RELI-G-002: ON CONFLICT preserves created_at,
                # last_tested_at, last_test_result.
                await db.execute(
                    "INSERT INTO voice_profiles "
                    "(owner_user_id, provider, provider_profile_id, status, updated_at) "
                    "VALUES (?, ?, ?, 'enrolled', datetime('now')) "
                    "ON CONFLICT(owner_user_id) DO UPDATE SET "
                    "provider=excluded.provider, "
                    "provider_profile_id=excluded.provider_profile_id, "
                    "status='enrolled', updated_at=datetime('now')",
                    (user_id, provider_name, str(profile_id)),
                )
            except Exception:  # noqa: BLE001
                # Fallback for SQLite < 3.24 (no UPSERT) — use a manual
                # UPDATE then INSERT-if-missing pattern. Preserves the
                # immutable columns in the UPDATE branch.
                logger.warning(
                    "VOICE_ENROLL_UPSERT_FALLBACK user=%s — SQLite ON CONFLICT not supported, using UPDATE/INSERT",
                    user_id,
                )
                cur = await db.execute(
                    "UPDATE voice_profiles "
                    "SET provider = ?, provider_profile_id = ?, status = 'enrolled', "
                    "updated_at = datetime('now') WHERE owner_user_id = ?",
                    (provider_name, str(profile_id), user_id),
                )
                if cur.rowcount == 0:
                    await db.execute(
                        "INSERT INTO voice_profiles "
                        "(owner_user_id, provider, provider_profile_id, status, updated_at) "
                        "VALUES (?, ?, ?, 'enrolled', datetime('now'))",
                        (user_id, provider_name, str(profile_id)),
                    )
            await db.commit()
        except Exception as exc:  # noqa: BLE001
            logger.error("VOICE_ENROLL_PERSIST_FAILED user=%s exc=%s: %s",
                         user_id, type(exc).__name__, str(exc)[:200])
            _voice_enroll_diag(user_id, chat_id, "persistence_failed",
                               type(exc).__name__)
            # V60 Fix #6: attempt provider-side rollback.
            try:
                await _voice_clone_delete_profile(
                    provider_name, provider_api_key, str(profile_id))
            except Exception:  # noqa: BLE001
                pass
            await safe_send_message(bot, chat_id,
                "❌ Voice enrollment failed at the last step "
                "(profile could not be saved).\nPlease try again or contact "
                "the administrator.")
            _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
            return
        _voice_enroll_diag(user_id, chat_id, "profile_persisted",
                           str(profile_id)[:12])

        # V60 Fix #11: exactly one user-friendly success message.
        await safe_send_message(bot, chat_id,
            "✅ Voice enrolled successfully.\n"
            "Your voice profile is ready to use.")
        _voice_enroll_diag(user_id, chat_id, "enrollment_success", "")
        _voice_enroll_clear(user_id, chat_id, expected_gen=gen)

    except asyncio.CancelledError:
        _voice_enroll_diag(user_id, chat_id, "enrollment_exception", "cancelled")
        _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
        raise
    except Exception as exc:  # noqa: BLE001
        logger.error("VOICE_ENROLL_EXCEPTION user=%s exc=%s: %s",
                     user_id, type(exc).__name__, str(exc)[:200])
        _voice_enroll_diag(user_id, chat_id, "enrollment_exception",
                           type(exc).__name__)
        try:
            await safe_send_message(bot, chat_id,
                "❌ Something went wrong during voice enrollment. Please try again.")
        except Exception:  # noqa: BLE001
            pass
        _voice_enroll_clear(user_id, chat_id, expected_gen=gen)
    finally:
        # V60 Fix #7: GUARANTEED cleanup — temp dir + all intermediate files.
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
        if tmp_dir and os.path.isdir(tmp_dir):
            try:
                shutil.rmtree(tmp_dir, ignore_errors=True)
            except OSError:
                pass
        _voice_enroll_diag(user_id, chat_id, "cleanup_complete", "")


async def _voice_enroll_bot_api_handler(update: Update,
                                        context: ContextTypes.DEFAULT_TYPE) -> None:
    """V60 Fix #1/#4/#10: high-priority private-chat Bot API voice/audio
    enrollment handler.

    Registered in group=-1 so it runs BEFORE:
        - the default-group route_message handler
        - the group=10 Talkative wrapper
        - any text processing, Talkative processing, generic media
          understanding, command fallback, AI response generation,
          duplicate suppression, engagement scoring

    Behaviour:
        - If no pending enrollment state matches → return (PTB proceeds to
          the next group; normal pipeline handles the update).
        - If a valid state exists → atomically claim it (one-shot), spawn
          background processing, and raise ApplicationHandlerStop so the
          normal pipeline never sees the sample.
        - If state exists but sender is not an admin → clear state, alert,
          and stop processing.
    """
    if update.message is None or update.effective_user is None or update.effective_chat is None:
        return  # let normal pipeline handle

    msg = update.message
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id

    # Only voice/audio notes (and audio-typed documents) are valid samples.
    is_voice = bool(getattr(msg, "voice", None))
    is_audio = bool(getattr(msg, "audio", None))
    audio_doc = None
    if not is_voice and not is_audio and getattr(msg, "document", None) is not None:
        mime = (msg.document.mime_type or "").lower()
        if mime.startswith("audio/"):
            audio_doc = msg.document
    if not is_voice and not is_audio and audio_doc is None:
        return  # not a voice/audio message — let normal pipeline handle

    # V60 Fix #1: check the authoritative state for (admin_user_id, bot_chat_id).
    st = _voice_enroll_get(user_id, chat_id)
    if st is None:
        # No pending enrollment for THIS (user, chat) — let normal pipeline
        # handle. (Wrong-user / wrong-chat samples are NOT consumed here.)
        return

    # V60 Fix #1: verify admin authorization (defence-in-depth).
    if not _vc_is_admin(user_id):
        _voice_enroll_clear(user_id, chat_id)
        logger.warning("VOICE_ENROLL_NON_ADMIN user=%s chat=%s — cleared state",
                       user_id, chat_id)
        try:
            await safe_send_message(context.bot, chat_id,
                "❌ Voice enrollment is admin-only. Pending state cleared.")
        except Exception:  # noqa: BLE001
            pass
        raise ApplicationHandlerStop

    # V60 Fix #10: one-shot claim — guarantees a sample is processed exactly once.
    claimed = await _voice_enroll_claim(user_id, chat_id)
    if claimed is None:
        # Already claimed by a parallel update — drop duplicate.
        logger.warning("VOICE_ENROLL_DUPLICATE_DROPPED user=%s chat=%s",
                       user_id, chat_id)
        raise ApplicationHandlerStop

    _voice_enroll_diag(user_id, chat_id, "state_matched",
                       f"admin={user_id} chat={chat_id}")

    # Consume exclusively. Process in background so the update loop is not
    # blocked and ApplicationHandlerStop can be raised immediately.
    # V85.5 FIX (ASYNC-G-001): strong-reference the task so the asyncio
    # scheduler doesn't garbage-collect it before it completes.
    try:
        _ve_task = asyncio.create_task(_voice_enroll_process_bot_api(
            update, context, user_id, chat_id, claimed))
        _voice_enroll_tasks.add(_ve_task)
        _ve_task.add_done_callback(_voice_enroll_tasks.discard)
    except RuntimeError:
        # No running loop — best-effort: process synchronously-ish by
        # clearing state and reporting the issue.
        _voice_enroll_clear(user_id, chat_id,
                            expected_gen=claimed.get("generation"))
    raise ApplicationHandlerStop


def _app_voice_enroll_register(app: Application) -> None:
    """V60 Fix #1: register the Bot API voice enrollment MessageHandler in
    group=-1 (HIGH PRIORITY). Idempotent."""
    global _voice_enroll_handler_registered
    if _voice_enroll_handler_registered:
        return
    # Filter: private-chat voice OR audio OR audio-typed documents.
    voice_audio_filter = (
        filters.VOICE
        | filters.AUDIO
        | filters.Document.MimeType("audio/ogg")
        | filters.Document.MimeType("audio/mpeg")
        | filters.Document.MimeType("audio/mp3")
        | filters.Document.MimeType("audio/wav")
        | filters.Document.MimeType("audio/x-wav")
        | filters.Document.MimeType("audio/mp4")
        | filters.Document.MimeType("audio/x-m4a")
        | filters.Document.MimeType("audio/aac")
        | filters.Document.MimeType("audio/flac")
        | filters.Document.MimeType("audio/ogg;codecs=opus")
    ) & filters.ChatType.PRIVATE
    app.add_handler(
        MessageHandler(voice_audio_filter, _voice_enroll_bot_api_handler),
        group=-1,
    )
    _voice_enroll_handler_registered = True
    logger.info("VOICE_ENROLL_HANDLER_REGISTERED group=-1 "
                "(Bot API private-chat voice/audio)")


def _voice_enroll_selfcheck() -> dict[str, Any]:
    """V60 Fix #13: startup self-check. Returns a dict of dependency states
    and a truthful overall status."""
    result: dict[str, Any] = {
        "handler_registered": _voice_enroll_handler_registered,
        "ffmpeg_available": shutil.which("ffmpeg") is not None,
        "ffprobe_available": shutil.which("ffprobe") is not None,
        "db_ready": _db is not None,
        "voice_profiles_table": None,  # filled asynchronously if possible
        "provider_configured": False,
        "provider_api_key_present": False,
        "provider_name": "",
        "missing": [],
        "status": "Ready",
    }
    p = os.environ.get("VOICE_CLONE_PROVIDER", "").strip().lower()
    k = os.environ.get("VOICE_CLONE_API_KEY", "").strip()
    result["provider_name"] = p
    if p:
        result["provider_configured"] = True
    if k:
        result["provider_api_key_present"] = True
    if not result["handler_registered"]:
        result["missing"].append("Handler Not Registered")
    if not result["ffmpeg_available"]:
        result["missing"].append("Missing FFmpeg")
    if not result["ffprobe_available"]:
        result["missing"].append("Missing ffprobe")
    if not result["db_ready"]:
        result["missing"].append("Database Not Ready")
    if not result["provider_configured"]:
        result["missing"].append("Missing Provider")
    elif not result["provider_api_key_present"]:
        result["missing"].append("Missing API Key")
    if result["missing"]:
        result["status"] = result["missing"][0]
    return result


async def _voice_enroll_selfcheck_async() -> dict[str, Any]:
    """Async wrapper that also probes the voice_profiles table existence."""
    result = _voice_enroll_selfcheck()
    try:
        result["voice_profiles_table"] = await _voice_enroll_db_table_ready()
        if not result["voice_profiles_table"]:
            if "Database Not Ready" not in result["missing"]:
                result["missing"].append("voice_profiles Table Missing")
            if result["status"] == "Ready":
                result["status"] = "voice_profiles Table Missing"
    except Exception as exc:  # noqa: BLE001
        result["voice_profiles_table"] = False
        result["missing"].append(f"DB Check Failed: {type(exc).__name__}")
        if result["status"] == "Ready":
            result["status"] = "DB Check Failed"
    return result


_multimodal_processing: set[int] = set()  # chat_id:user_id keys being processed, to prevent re-entry


def _multimodal_filter(update: Update) -> bool:
    """Return True if the update has a multimodal payload (non-text media)."""
    if not getattr(config, "multimodal_enabled", True):
        return False
    msg = update.message
    if msg is None:
        return False
    # Only fire for media types — let text go through normal routing.
    if msg.text and not msg.caption:
        return False  # pure text — handled by Talkative/commands
    # But DO fire for media-with-caption (the caption is text we want to process alongside the media).
    return any([
        msg.voice, msg.audio, msg.photo, msg.video, msg.video_note,
        msg.animation, msg.sticker, msg.document,
    ])


async def multimodal__handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Top-level multimodal handler. Classifies input, downloads media, routes to
    the appropriate AI provider, and sends a response.

    v97.11/v97.12 FIX: this handler is registered in group=-1 (runs BEFORE
    route_message in group=0).  It must NOT consume media messages when the
    user is in an awaiting-media state (Download, Analyze, Inspect, Toolbox,
    Batch, Link, MTProto, Backup) — otherwise those flows never receive the
    forwarded media and the user sees an AI reply instead of the expected
    action.
    """
    if not getattr(config, "multimodal_enabled", True):
        return
    msg = update.message
    if msg is None:
        return
    user = update.effective_user
    chat = update.effective_chat
    if user is None or chat is None:
        return

    # v97.11/v97.12 STATE GUARD: if the user is in an awaiting-media state,
    # let route_message (group=0) handle the forwarded media.  Without this,
    # this handler (group=-1) intercepts the message, raises
    # ApplicationHandlerStop, and the download/analyze/inspect/toolbox/batch/
    # link/mtproto/backup flows never run.
    try:
        from . import states as _states
        _st = await _states.get_state(user.id)
    except Exception:  # noqa: BLE001
        _st = None
    _AWAITING_MEDIA_STATES = frozenset({
        getattr(_states, "AWAIT_DOWNLOAD_FORWARD", ""),
        getattr(_states, "AWAIT_ANALYZE", ""),
        getattr(_states, "AWAIT_INSPECT", ""),
        getattr(_states, "AWAIT_TOOLBOX", ""),
        getattr(_states, "AWAIT_BATCH", ""),
        getattr(_states, "AWAIT_LINK_DOWNLOAD", ""),
        getattr(_states, "AWAIT_LINK_MESSAGE_ID", ""),
        getattr(_states, "AWAIT_MTPROTO_SCREENSHOT", ""),
        getattr(_states, "AWAIT_MTPROTO_DOWNLOAD", ""),
        getattr(_states, "AWAIT_MTPROTO_MSGID", ""),
        getattr(_states, "AWAIT_BACKUP_IMPORT", ""),
    })
    if _st and _st in _AWAITING_MEDIA_STATES:
        logger.debug("MULTIMODAL_SKIP_AWAITING_STATE user=%s state=%s", user.id, _st)
        return  # let route_message handle the media

    # Defensive guard: P2 router may not be fully wired in all builds.
    classify_fn = globals().get("_multimodal_classify_input")
    route_fn = globals().get("_multimodal_route")
    if not callable(classify_fn) or not callable(route_fn):
        logger.debug("MULTIMODAL_SKIP_NO_ROUTER classify=%s route=%s",
                     bool(callable(classify_fn)), bool(callable(route_fn)))
        return

    # V86 P8: Defence-in-depth — if a voice enrollment is pending for this
    # (user, chat), skip multimodal processing so the enrollment handler
    # (also group=-1, registered BEFORE this handler) gets the sample. Even
    # though the enrollment handler raises ApplicationHandlerStop on a
    # successful claim, this guard protects against any future ordering
    # change and avoids racing the enrollment state machine.
    try:
        if _voice_enroll_active(user.id, chat.id):
            logger.debug("MULTIMODAL_SKIP_VOICE_ENROLL_ACTIVE chat=%s user=%s",
                         chat.id, user.id)
            return
    except Exception:  # noqa: BLE001
        pass

    # Prevent re-entry (a single chat-user can only have one multimodal request in flight).
    reentry_key = (chat.id, user.id)
    if reentry_key in _multimodal_processing:
        logger.debug("MULTIMODAL_SKIP_IN_FLIGHT chat=%s user=%s", chat.id, user.id)
        return
    _multimodal_processing.add(reentry_key)

    try:
        # 1. Classify the input.
        mm_input = classify_fn(update)
        if mm_input.modality == "text":
            return  # pure text — let other handlers deal with it.

        # 2. Route.
        response = await route_fn(mm_input, chat_context={})
        logger.info(
            "MULTIMODAL_HANDLE chat=%s user=%s modality=%s provider=%s intent=%s",
            chat.id, user.id, mm_input.modality, response.provider, response.intent,
        )

        # 3. Download media if needed.
        file_path: Path | None = None
        if mm_input.file_id and (response.metadata.get("needs_stt") or response.metadata.get("needs_vision") or response.metadata.get("needs_ocr")):
            try:
                file_path = await _multimodal_download_file(msg, mm_input, context)
                mm_input.file_path = file_path
            except Exception as exc:
                logger.warning("MULTIMODAL_DOWNLOAD_FAILED exc=%s", exc)
                await safe_reply_text(msg, "⚠️ Could not download the media file. Please try again.")
                return  # download failed — let downstream handlers try

        # 4. Execute the response plan.
        result_text = ""
        if response.metadata.get("needs_stt") and file_path:
            # Transcribe audio/voice.
            result_text = await _multimodal_do_stt(file_path, mm_input, response)
        elif response.metadata.get("needs_vision") and file_path:
            # Analyze image/video.
            result_text = await _multimodal_do_vision(file_path, mm_input, response, msg)
        elif response.metadata.get("needs_ocr") and file_path:
            # OCR / document analysis.
            result_text = await _multimodal_do_document(file_path, mm_input, response)
        elif response.modality == "reaction" and response.reaction_emoji:
            # Sticker → emoji reaction.
            reaction_set = False
            try:
                await context.bot.set_message_reaction(
                    chat_id=chat.id, message_id=msg.message_id,
                    reaction=[{"type": "emoji", "emoji": response.reaction_emoji}],
                )
                reaction_set = True
            except Exception as exc:
                logger.debug("MULTIMODAL_REACTION_FAILED exc=%s", exc)
            # V86 P8: reaction successfully applied — stop downstream handlers
            # (download/analyze) from re-processing the same sticker.
            if reaction_set:
                raise ApplicationHandlerStop
            return  # reaction failed — let downstream try (no text reply)

        # 5. If we got a transcript, feed it into the Talkative pipeline for a conversational reply.
        _replied = False
        if result_text and response.intent == "voice_transcription":
            # The user spoke; the transcript is their message. Generate an AI reply.
            reply = await _multimodal_generate_reply(result_text, chat.id, user.id, mm_input.language)
            if reply:
                await safe_reply_text(msg, reply)
                _replied = True
                # Optionally send a voice reply back.
                if getattr(config, "voice_reply_enabled", False):
                    voice_path = await _multimodal_tts(reply, mm_input.language)
                    if voice_path:
                        try:
                            with voice_path.open("rb") as fh:
                                await context.bot.send_voice(chat_id=chat.id, voice=fh)
                        finally:
                            try: voice_path.unlink()
                            except OSError: pass
            else:
                await safe_reply_text(msg, f"🎧 I heard: *{result_text[:200]}*\n\n(But I couldn't generate a reply right now. Check that at least one AI provider key is configured.)")
                _replied = True
        elif result_text:
            # Vision/document analysis result — send directly.
            await safe_reply_text(msg, result_text[:4096])
            _replied = True
        
        # V86.5: If STT failed (empty transcript) for voice/audio, send a helpful error.
        if not _replied and not result_text and mm_input.modality in ("voice", "audio"):
            stt_provider = response.provider
            await safe_reply_text(msg,
                f"🎤 I received your voice message but couldn't transcribe it.\n\n"
                f"STT provider: `{stt_provider}`\n"
                f"Possible causes:\n"
                f"• Wit.ai token not set or invalid\n"
                f"• ffmpeg not installed (needed for OGG→WAV conversion)\n"
                f"• Audio too short or silent\n"
                f"• Provider API error\n\n"
                f"Use /talkative → 🧠 Wit.ai → 🎤 Voice Pipeline Check to diagnose.")
            _replied = True

        # 6. Cleanup downloaded file.
        if file_path and file_path.exists():
            try:
                await remove_path(file_path)
            except Exception:
                pass

        # V86 P8: If we successfully processed the media and sent a reply,
        # raise ApplicationHandlerStop to prevent the group-0 download/analyze
        # handlers from re-processing the same media (DOUBLE-PROCESSING fix).
        # Only raise when we ACTUALLY sent a reply — if result_text was empty
        # (e.g., no STT provider available), let the message fall through so
        # downstream handlers can attempt their own processing.
        if _replied:
            raise ApplicationHandlerStop

    except ApplicationHandlerStop:
        # V86 P8: Propagate the stop signal — do NOT let the generic
        # `except Exception` below swallow it. PTB's ApplicationHandlerStop
        # is a subclass of Exception, so it must be re-raised explicitly.
        raise
    except Exception as exc:
        logger.exception("MULTIMODAL_HANDLE_ERROR chat=%s user=%s exc=%s", chat.id, user.id, exc)
        try:
            await safe_reply_text(msg, "⚠️ Something went wrong processing that media. Please try again.")
        except Exception:
            pass
    finally:
        _multimodal_processing.discard(reentry_key)


async def _multimodal_download_file(msg, mm_input: MultimodalInput, context) -> Path:
    """Download the media file from Telegram to a temp path."""
    if not mm_input.file_id:
        raise ValueError("No file_id to download")
    tg_file = await context.bot.get_file(mm_input.file_id)
    # Pick extension based on modality.
    ext_map = {
        "voice": ".ogg", "audio": ".mp3", "photo": ".jpg",
        "video": ".mp4", "video_note": ".mp4", "gif": ".mp4",
        "sticker": ".webp", "document": "",
    }
    ext = ext_map.get(mm_input.modality, ".bin")
    if mm_input.modality == "document":
        # Use the original filename extension if available.
        fname = mm_input.extra.get("file_name", "")
        if "." in fname:
            ext = "." + fname.rsplit(".", 1)[-1].lower()
        else:
            ext = ".bin"
    safe_name = f"mm_{msg.message_id}_{int(time.time())}{ext}"
    target = config.downloads_dir / safe_name
    config.downloads_dir.mkdir(parents=True, exist_ok=True)
    await tg_file.download_to_drive(custom_path=str(target))
    return target


async def _multimodal_do_stt(file_path: Path, mm_input: MultimodalInput, response: MultimodalResponse) -> str:
    """Perform speech-to-text using the routed provider.

    V87: proper audio validation — uses multimodal_max_audio_bytes (NOT image
    bytes), enforces duration limit, validates MIME type, rejects unsupported
    providers.
    """
    provider = response.provider

    # V87: validate audio file before any provider call.
    try:
        st = file_path.stat()
        if st.st_size > config.multimodal_max_audio_bytes:
            logger.warning("MULTIMODAL_STT_SKIP audio_too_large size=%d limit=%d",
                           st.st_size, config.multimodal_max_audio_bytes)
            return ""
    except Exception:
        pass  # stat failed — let the provider handle it

    # V87: check duration if available from the Telegram metadata.
    if mm_input.duration_seconds and mm_input.duration_seconds > config.multimodal_max_audio_seconds:
        logger.warning("MULTIMODAL_STT_SKIP audio_too_long duration=%.0f limit=%d",
                       mm_input.duration_seconds, config.multimodal_max_audio_seconds)
        return ""

    # V87: OpenRouter does NOT support speech-to-text — reject explicitly.
    if provider == "openrouter":
        logger.warning("MULTIMODAL_STT_REJECT provider=openrouter reason=no_stt_support")
        return ""

    if provider == "witai":
        from .frame_extractor import witai_service
        result = await witai_service.speech_to_text(file_path, language=mm_input.language)
        return result.get("text", "")
    if provider == "gemini":
        # Use Gemini's audio analysis capability.
        try:
            # Reuse the existing ai_analyzer.analyze_audio function if it exists.
            from google.genai import types
            audio_bytes = await _read_bytes(file_path)
            client = _get_client()
            prompt = "Transcribe this audio accurately. If it's not speech, describe what you hear. Be concise."
            resp = await asyncio.wait_for(
                _run_in_thread(lambda: client.models.generate_content(
                    model="gemini-1.5-flash",
                    contents=[prompt, types.Part.from_bytes(data=audio_bytes, mime_type=mm_input.mime_type or "audio/mpeg")],
                )),
                timeout=getattr(config, "ai_request_timeout", 90),
            )
            return (resp.text or "").strip()
        except Exception as exc:
            logger.warning("MULTIMODAL_STT_GEMINI_ERROR exc=%s", exc)
            return ""
    if provider == "groq":
        # Groq has a Whisper API for transcription.
        try:
            groq_key = config.groq_api_key
            async with httpx.AsyncClient(timeout=120.0) as client:
                with open(file_path, "rb") as fh:
                    resp = await client.post(
                        "https://api.groq.com/openai/v1/audio/transcriptions",
                        headers={"Authorization": f"Bearer {groq_key}"},
                        files={"file": (file_path.name, fh, mm_input.mime_type or "audio/mpeg")},
                        data={"model": "whisper-large-v3", "response_format": "json"},
                    )
                if resp.status_code == 200:
                    return resp.json().get("text", "")
                logger.warning("MULTIMODAL_STT_GROQ_FAILED status=%s", resp.status_code)
                return ""
        except Exception as exc:
            logger.warning("MULTIMODAL_STT_GROQ_ERROR exc=%s", exc)
            return ""
    # Local fallback — no transcription possible.
    logger.warning("MULTIMODAL_STT_NO_PROVIDER available")
    return ""


async def _multimodal_do_vision(file_path: Path, mm_input: MultimodalInput, response: MultimodalResponse, msg) -> str:
    """Perform vision analysis (image/video understanding) using the routed provider."""
    provider = response.provider
    # Build the analysis prompt based on modality + caption.
    caption = mm_input.text or mm_input.extra.get("caption", "")
    if mm_input.modality == "video" or mm_input.modality == "video_note":
        prompt_base = "Analyze this video. Summarize what's happening, note key scenes, and describe the content."
    elif mm_input.modality == "gif":
        prompt_base = "Describe this GIF/animation. What's happening? What emotion or action does it convey?"
    else:
        prompt_base = "Analyze this image in detail. Describe what you see, including objects, text (OCR), context, and any notable details."
    if caption:
        prompt_base += f"\n\nThe user captioned this: \"{caption[:500]}\". Respond to their caption if it's a question or request."

    if provider == "gemini":
        try:
            from google.genai import types
            # For video, extract a few frames; for image, send directly.
            if mm_input.modality in ("video", "video_note", "gif"):
                # Extract up to 4 frames.
                frames = await extract_frames(file_path, num_frames=4, out_dir=config.frames_dir, fmt="jpg")
                if not frames:
                    return "⚠️ Could not extract frames from this video for analysis."
                try:
                    parts = [prompt_base]
                    for fp in frames:
                        data = await _read_bytes(fp)
                        parts.append(types.Part.from_bytes(data=data, mime_type="image/jpeg"))
                    client = _get_client()
                    resp = await asyncio.wait_for(
                        _run_in_thread(lambda: client.models.generate_content(
                            model="gemini-1.5-flash", contents=parts,
                        )),
                        timeout=getattr(config, "ai_request_timeout", 90),
                    )
                    return (resp.text or "I couldn't analyze this video.").strip()
                finally:
                    for fp in frames:
                        try: await remove_path(fp)
                        except Exception: pass
            else:
                # Image — send directly.
                data = await _read_bytes(file_path)
                client = _get_client()
                resp = await asyncio.wait_for(
                    _run_in_thread(lambda: client.models.generate_content(
                        model="gemini-1.5-flash",
                        contents=[prompt_base, types.Part.from_bytes(data=data, mime_type=mm_input.mime_type or "image/jpeg")],
                    )),
                    timeout=getattr(config, "ai_request_timeout", 90),
                )
                return (resp.text or "I couldn't analyze this image.").strip()
        except Exception as exc:
            logger.warning("MULTIMODAL_VISION_GEMINI_ERROR exc=%s", exc)
            return f"⚠️ Vision analysis failed: {str(exc)[:120]}"
    if provider == "openrouter":
        # OpenRouter vision via httpx (OpenAI-compatible).
        try:
            import base64
            data = await _read_bytes(file_path)
            b64 = base64.b64encode(data).decode()
            mime = mm_input.mime_type or "image/jpeg"
            async with httpx.AsyncClient(timeout=120.0) as client:
                resp = await client.post(
                    "https://openrouter.ai/api/v1/chat/completions",
                    headers={"Authorization": f"Bearer {config.openrouter_api_key}"},
                    json={
                        "model": config.openrouter_model or "google/gemini-1.5-flash",
                        "messages": [{"role": "user", "content": [
                            {"type": "text", "text": prompt_base},
                            {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}},
                        ]}],
                        "max_tokens": 1000,
                    },
                )
                if resp.status_code == 200:
                    return resp.json().get("choices", [{}])[0].get("message", {}).get("content", "").strip()
                return f"⚠️ Vision analysis failed (HTTP {resp.status_code})."
        except Exception as exc:
            logger.warning("MULTIMODAL_VISION_OPENROUTER_ERROR exc=%s", exc)
            return f"⚠️ Vision analysis failed: {str(exc)[:120]}"
    return "⚠️ No vision provider available. Set GEMINI_API_KEY or OPENROUTER_API_KEY to enable image/video analysis."


async def _multimodal_do_document(file_path: Path, mm_input: MultimodalInput, response: MultimodalResponse) -> str:
    """Analyze a document. If it's an image (PDF page / scanned), use vision; if text, read it."""
    mime = mm_input.mime_type.lower()
    if mime.startswith("image/"):
        return await _multimodal_do_vision(file_path, mm_input, response, None)
    # Text document — try to read it.
    try:
        if mime == "application/pdf":
            # Use vision to read the PDF (Gemini supports PDF input).
            return await _multimodal_do_vision(file_path, mm_input, response, None)
        # Plain text / code / etc.
        async with aiofiles.open(file_path, "r", errors="replace") as fh:
            content = await fh.read()
        if len(content) > 8000:
            content = content[:8000] + "\n\n[... truncated ...]"
        return f"📄 **Document contents** (`{mm_input.extra.get('file_name', 'document')}`):\n\n```\n{content}\n```"
    except Exception as exc:
        return f"⚠️ Could not read document: {str(exc)[:120]}"


async def _multimodal_generate_reply(transcript: str, chat_id: int, user_id: int, language: str) -> str:
    """Feed a voice transcript through the Talkative generation pipeline to get a conversational reply."""
    try:
        # Build a simple message list and call talkative_generate.
        messages = [{"role": "user", "content": transcript}]
        system_prompt = "You are a helpful Telegram assistant. The user sent a voice message that was transcribed. Reply naturally and concisely."
        if language and language != "auto":
            system_prompt += f" Reply in {language}."
        result = await talkative_generate(
            messages, system_prompt,
            {"provider": "auto", "max_reply_chars": 1000, "request_timeout": 30},
        )
        if result.success and result.text:
            return result.text
        # V86.4: if generation failed but we have fallback text, return it
        # so the user at least gets a response (better than silence).
        if result.text:
            return result.text
        return ""
    except Exception as exc:
        logger.warning("MULTIMODAL_REPLY_ERROR exc=%s", exc)
        return ""


async def _multimodal_tts(text: str, language: str) -> Path | None:
    """Synthesize a voice reply using Groq's TTS or a fallback."""
    if not text or len(text) > 4000:
        return None
    try:
        # Try Groq TTS (if available).
        if getattr(config, "groq_api_key", ""):
            async with httpx.AsyncClient(timeout=60.0) as client:
                resp = await client.post(
                    "https://api.groq.com/openai/v1/audio/speech",
                    headers={"Authorization": f"Bearer {config.groq_api_key}"},
                    json={"model": "playai-tts", "input": text[:4000], "voice": "alloy"},
                )
                if resp.status_code == 200:
                    target = config.frames_dir / f"tts_{int(time.time()*1000)}.mp3"
                    async with aiofiles.open(target, "wb") as fh:
                        await fh.write(resp.content)
                    return target
        return None
    except Exception as exc:
        logger.warning("MULTIMODAL_TTS_ERROR exc=%s", exc)
        return None


def register_multimodal_handler(app) -> None:
    """Register the multimodal MessageHandler on the Application."""
    global _MULTIMODAL_HANDLER_REGISTERED
    if _MULTIMODAL_HANDLER_REGISTERED:
        return
    from telegram.ext import MessageHandler, filters
    app.add_handler(
        MessageHandler(filters.ALL & ~filters.COMMAND, multimodal__handle_message),
        group=-1,  # highest priority — runs before Talkative and other handlers
    )
    _MULTIMODAL_HANDLER_REGISTERED = True
    logger.info("MULTIMODAL_HANDLER_REGISTERED group=-1 (priority capture for media messages)")


# ===========================================================================
# Handlers — inspector
# ===========================================================================
