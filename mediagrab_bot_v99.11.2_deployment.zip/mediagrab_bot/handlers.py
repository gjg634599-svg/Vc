"""Handlers subsystem — physically extracted from _bot_core.py.

Contains:
  - Central router (route_callback, route_message, start_command, help_command)
  - Download handlers (download__*)
  - Analyze handlers (analyze__*)
  - VC admin handlers (vc__*)
  - Talkative admin handlers (talk__*)
  - MTProto admin handlers (mtproto__*)
  - Inspector/Toolbox/Library/Stats/QR/Batch/Scheduled/Backup handlers
  - Link download handlers (link__*, _link_*)
  - Media browser handlers (mb_*)
  - Inline handler (inline__handle_inline)
  - Admin handlers (admin__*, _admin_*)
  - SimpleNamespace aliases (repo, kb, msg, states, downloader, etc.)
  - Logging infrastructure (setup_logging, _ErrorDedupFilter, etc.)
  - Dashboard/admin infrastructure (_dashboard_*, _gemini_key_*, etc.)

Cross-subsystem dependencies resolved by importing directly from extracted modules.
"""

from __future__ import annotations

import asyncio, os, re, json, time, signal, sys, shutil, functools, logging, tempfile, subprocess, inspect, hashlib, queue, warnings
import io
import wave
from pathlib import Path
from typing import Any, Awaitable, Callable, Optional, TypeVar, Sequence, Iterable, Mapping, AsyncGenerator
from datetime import datetime, timezone, timedelta
from collections import defaultdict
from dataclasses import dataclass, field
from logging.handlers import RotatingFileHandler
from types import SimpleNamespace

import httpx
import aiofiles
import aiosqlite
from dotenv import load_dotenv
from PIL import Image
import qrcode
from telegram import (Update, InlineKeyboardButton, InlineKeyboardMarkup,
                      InlineQueryResultArticle, InputTextMessageContent)
from telegram.ext import (Application, ApplicationBuilder, CallbackQueryHandler,
                          CommandHandler, InlineQueryHandler, MessageHandler,
                          ContextTypes, filters, ApplicationHandlerStop)
from telegram.error import BadRequest, Forbidden, NetworkError, TimedOut, RetryAfter

from .config import config, _env_int
from .text_utils import md_escape, html_escape
from .db_layer import (
    repo,
    MIGRATION_SQL, SCHEMA_SQL, _AI_EXECUTOR, _SCALE_RE, _TASK_COLUMNS,
    _column_exists, _index_exists, _run_migrations, _talkative_coerce,
    _talkative_row_to_dict, add_ai_history, add_download_history, add_inspected_chat,
    add_library_entry, add_scheduled_task, all_users, cancel_scheduled_task,
    clear_history, close_db, create_broadcast, create_task, ensure_settings,
    export_user_data, get_db, global_stats, init_db, library_clear, library_count,
    library_entries, library_remove, library_search, list_scheduled_tasks,
    pending_scheduled_tasks, recent_ai_analyses, recent_broadcasts, recent_downloads,
    recent_inspected, restore_user_settings, stats, talkative_add_memory,
    talkative_add_stat, talkative_add_wake_word, talkative_apply_effective_runtime,
    talkative_cleanup_expired_sessions, talkative_cleanup_old_memory,
    talkative_clear_memory, talkative_effective_enabled, talkative_effective_provider,
    talkative_effective_settings, talkative_end_session, talkative_get_active_session,
    talkative_get_chat_settings, talkative_get_global_settings, talkative_get_memory,
    talkative_get_wake_words, talkative_remove_wake_word, talkative_set_chat_setting,
    talkative_start_session, talkative_touch_session, talkative_trim_memory,
    talkative_update_global_settings, update_broadcast_counts, update_scheduled_task,
    update_setting, update_task, upsert_user, user_count, user_daily_download_usage,
    user_stats, vc_add_visit, vc_get_settings, vc_get_tour_state, vc_group_count,
    vc_groups_active, vc_groups_all, vc_groups_keyset, vc_groups_keyset_stream,
    vc_recent_visits, vc_save_tour_state, vc_update_settings, vc_update_visit,
    vc_upsert_group, vc_visit_count, vc_visited_group_ids_since,
)
from .utils_real import (
    extension_category, get_bot, human_size, is_available, periodic_cleanup,
    register_bot, remove_path, safe_edit_message_text, safe_filename,
    safe_reply_text, safe_send_document, safe_send_message, supervised_create_task,
    telegram_media_type, unique_path, _active_tasks, _ui_claim, _ui_invalidate,
    _ui_check, _ui_release, _ui_owners, _cache_userbot_identity, _userbot_id,
    setup_logging, _ErrorDedupFilter, _install_asyncio_handler,
    _sanitize_error,
)
from .states import (
    IDLE, set_state, get_state, reset, set_tool, get_tool,
    set_last_download, get_last_download, get_state_sync, set_state_sync,
    get_tool_sync, set_tool_sync, get_last_download_sync, set_last_download_sync,
)
from .media_processor import download_slot, with_retries, retrying, send_file_back, notify, safe_unlink
from .ai_modes import (
    ACCEPTS, MODE_LABELS, MODE_ORDER, PROMPTS, build_prompt,
    NORMALISERS, normalise, accepts, media_kind_for, render_result,
)
from .downloader import (
    ProgressCB, _FILE_URL_TEMPLATE, DownloadError, FileTooLarge,
    _ProgressThrottle, _fmt_speed, download_forwarded,
    _file_url, _copy_local, _stream_to_disk,
)
from .frame_extractor import (
    extract_frames, FrameExtractionError, _FFMPEG, _FFPROBE,
    _witai_diagnostics_text, _witai_test_connection, _witai_voice_check_handler,
)
from .media_tools import (
    _SCALE_RE as _MT_SCALE_RE, ToolError, extract_audio, extract_thumbnail,
    media_info, _normalise_info, _fmt_duration, _parse_fps,
    compress_video, _PILLOW_FORMATS, convert_image, _run_ffmpeg,
)
from .qr_generator import QRError, generate_qr
from .backup import (
    export_user_json, parse_backup_file, restore_from_dict, export_global_json,
)
from .link_parser import parse_input, ParsedInput, describe_input
from .ui_keyboards import *
from .ui_messages import *
from .i18n import t, has_language, supported_languages
from .mtproto import *
from .voicechat import *
from .talkative import *
from .multimodal import *
from .diag_hooks import v85_diag

# Explicit imports for underscore-prefixed names that star-import excludes.
# Python's `from module import *` does NOT export names starting with `_`.
# These are needed by handlers.py at runtime (would cause NameError otherwise).
import hmac as _hmac
from .mtproto import (
    _check_stories_api_available, _get_current_vc_account_id,
    _mtproto_client, _mtproto_extract_single_message, _mtproto_media_type,
    _mtproto_started, _status_icon, _status_label, _user_entity_cache,
    _vc_entity_cache, _vc_entity_cache_by_client,
)
from .voicechat import (
    _auto_discovery_state, _auto_discovery_task, _deferred_queue_task,
    _manual_discovery_states, _talkative_userbot_handler_registered,
    _vc_canonical_group_id, _vc_capacity_aware_join, _vc_deferred_queue,
    _vc_discovery_builtin_defaults, _vc_discovery_claim_id,
    _vc_discovery_classify, _vc_discovery_current_mode,
    _vc_discovery_get_semaphore, _vc_discovery_is_target_on_cooldown,
    _vc_discovery_public_search, _vc_discovery_release_claim,
    _vc_entity_cache_scoped, _vc_in_flight_joins, _vc_is_admin,
    _vc_known_call_ids, _vc_reconcile_task, _vc_talkative_capabilities,
    _vc_stress_test_runner,
    vc_knowledge_store_verified,  # v98.09-P3 §19: knowledge-cache write
)
from .talkative import (
    _atomic_write, _dm_pipeline_diag, _gemini_key_validate,
    _group_pipeline_diag, _provider_cooldown_remaining,
    _provider_current_generation, _provider_effective_state,
    _provider_get_state, _provider_in_cooldown, _provider_key_activate,
    _provider_lock, _provider_notify_admin_recovery,
    _provider_record_failure_async, _provider_record_success_async,
    _talk_clear_pending_input, _talk_is_admin, _talk_set_pending_input,
    _talkative_cleanup_task, _talkative_engine_metrics_snapshot,
    _userbot_username,
)
from .multimodal import (
    _voice_enroll_clear, _voice_enroll_selfcheck_async, _voice_enroll_start,
)
# bootstrap imports are lazy (inside functions) to avoid a circular import:
# bootstrap.py imports from handlers.py at module level.

# ai_analyzer helpers (pre-existing lost code — same broken import as _bot_core baseline).
from .ai_analyzer import (
    _CLIENT_CACHE_MAX, _CLIENT_ERROR_TTL, _client_cache_key, _lru_cap, _get_client,
    analyze_frames, analyze_audio, analyze_images, _build_parts, _build_audio_parts,
    _read_bytes, _run_in_thread, _extract_text, _find_first_json_object,
    _parse_json, _strip_codefences, cleanup_frames,
)

logger = logging.getLogger("mediagrab")


# CODE-A-001: now that the logger is configured, run config validation so
# its warnings are emitted through the proper sinks (and clamped values
# take effect before any service reads them).
config.validate_config()


# Utilities — extracted to mediagrab_bot/utils_real.py
from mediagrab_bot.utils_real import (
    _APP_EXTS,
    _ARCHIVE_EXTS,
    _AUDIO_EXTS,
    _DOC_EXTS,
    _FORBIDDEN_CHARS,
    _IMAGE_EXTS,
    _ISO_EXTS,
    _MAX_NAME_LEN,
    _RESERVED_NAMES,
    _SECRET_PATTERNS,
    _SUBTITLE_EXTS,
    _VIDEO_EXTS,
    _cache_userbot_identity,
    _is_parse_error,
    _redact_secrets,
    _remove_safe,
    _safe_remove,
    _supervised_task_counts,
    _ui_check,
    _ui_claim,
    _ui_invalidate,
    _ui_owners_sweep,
    _ui_release,
    cleanup_directory,
    cleanup_paths,
    extension_category,
    get_bot,
    human_size,
    is_available,
    periodic_cleanup,
    register_bot,
    remove_path,
    safe_edit_message_text,
    safe_filename,
    safe_reply_text,
    safe_send_document,
    safe_send_message,
    supervised_create_task,
    telegram_media_type,
    unique_path,
)
from mediagrab_bot.utils_real import _set_config as _utils_set_config
_utils_set_config(config)

# ===========================================================================
# Database — extracted to mediagrab_bot/db_layer.py
from mediagrab_bot.db_layer import (
    MIGRATION_SQL,
    SCHEMA_SQL,
    _AI_EXECUTOR,
    _SCALE_RE,
    _TASK_COLUMNS,
    _column_exists,
    _index_exists,
    _run_migrations,
    _talkative_coerce,
    _talkative_row_to_dict,
    add_ai_history,
    add_download_history,
    add_inspected_chat,
    add_library_entry,
    add_scheduled_task,
    all_users,
    cancel_scheduled_task,
    clear_history,
    close_db,
    create_broadcast,
    create_task,
    ensure_settings,
    export_user_data,
    get_db,
    global_stats,
    init_db,
    library_clear,
    library_count,
    library_entries,
    library_remove,
    library_search,
    list_scheduled_tasks,
    pending_scheduled_tasks,
    recent_ai_analyses,
    recent_broadcasts,
    recent_downloads,
    recent_inspected,
    restore_user_settings,
    stats,
    talkative_add_memory,
    talkative_add_stat,
    talkative_add_wake_word,
    talkative_apply_effective_runtime,
    talkative_cleanup_expired_sessions,
    talkative_cleanup_old_memory,
    talkative_clear_memory,
    talkative_effective_enabled,
    talkative_effective_provider,
    talkative_effective_settings,
    talkative_end_session,
    talkative_get_active_session,
    talkative_get_chat_settings,
    talkative_get_global_settings,
    talkative_get_memory,
    talkative_get_wake_words,
    talkative_remove_wake_word,
    talkative_set_chat_setting,
    talkative_start_session,
    talkative_touch_session,
    talkative_trim_memory,
    talkative_update_global_settings,
    update_broadcast_counts,
    update_scheduled_task,
    update_setting,
    update_task,
    upsert_user,
    user_count,
    user_daily_download_usage,
    user_stats,
    vc_add_visit,
    vc_get_settings,
    vc_get_tour_state,
    vc_group_count,
    vc_groups_active,
    vc_groups_all,
    vc_groups_keyset,
    vc_groups_keyset_stream,
    vc_recent_visits,
    vc_save_tour_state,
    vc_update_settings,
    vc_update_visit,
    vc_upsert_group,
    vc_visit_count,
    vc_visited_group_ids_since,
)
from mediagrab_bot.db_layer import _set_config as _db_set_config
_db_set_config(config)

# i18n — extracted to mediagrab_bot/i18n.py
from mediagrab_bot.i18n import (
    _EN, _HI, _ES, _FR, _AR, _ZH, _PT, _LANGS,
    supported_languages, t, has_language,
)



# AI modes — extracted to mediagrab_bot/ai_modes.py
from mediagrab_bot.ai_modes import (
    ACCEPTS, MODE_LABELS, MODE_ORDER,
    _MOVIE_PROMPT, _TRANSCRIBE_PROMPT, _OCR_PROMPT, _DESCRIBE_PROMPT, _TRANSLATE_PROMPT,
    PROMPTS, build_prompt, NORMALISERS, normalise,
    accepts, media_kind_for, render_result,
)

# Media processor — extracted to mediagrab_bot/media_processor.py
from mediagrab_bot.media_processor import (
    download_slot, with_retries, retrying, send_file_back, notify, safe_unlink,
)
from mediagrab_bot.media_processor import _set_dependencies as _mp_set_deps
_mp_set_deps(config, remove_path)

# Downloader — extracted to mediagrab_bot/downloader.py
from mediagrab_bot.downloader import (
    ProgressCB, _FILE_URL_TEMPLATE, DownloadError, FileTooLarge,
    _ProgressThrottle, _fmt_speed, download_forwarded,
    _file_url, _copy_local, _stream_to_disk,
)
from mediagrab_bot.downloader import _set_dependencies as _dl_set_deps
_dl_set_deps(config, with_retries, download_slot)

# Frame extractor — extracted to mediagrab_bot/frame_extractor.py
from mediagrab_bot.frame_extractor import (
    _FFMPEG, _FFPROBE, FrameExtractionError,
    extract_frames, _extract_at, _probe_duration, _duration_via_ffmpeg, _even_timestamps,
)

# AI analyzer — extracted to mediagrab_bot/ai_analyzer.py
from mediagrab_bot.ai_analyzer import (
    _CLIENT_CACHE_MAX, _CLIENT_ERROR_TTL,
    _client_cache_key, _lru_cap, _get_client,
    analyze_frames, analyze_audio, analyze_images,
    _build_parts, _build_audio_parts, _read_bytes,
    _run_in_thread, _extract_text, _find_first_json_object,
    _parse_json, _strip_codefences, cleanup_frames,
)

# Media tools — extracted to mediagrab_bot/media_tools.py
from mediagrab_bot.media_tools import (
    _SCALE_RE, ToolError, extract_audio, extract_thumbnail,
    media_info, _normalise_info, _fmt_duration, _parse_fps,
    compress_video, _PILLOW_FORMATS, convert_image, _run_ffmpeg,
)

# QR generator — extracted to mediagrab_bot/qr_generator.py
from mediagrab_bot.qr_generator import QRError, generate_qr
from mediagrab_bot.qr_generator import _set_unique_path as _qr_set_unique_path
_qr_set_unique_path(unique_path)

# Backup — extracted to mediagrab_bot/backup.py
from mediagrab_bot.backup import (
    export_user_json, parse_backup_file, restore_from_dict, export_global_json,
)
from mediagrab_bot.backup import _set_dependencies as _backup_set_deps
_backup_set_deps(repo, safe_filename, config)

# ===========================================================================
# Services — link_parser (Task ID 5)
# ===========================================================================

# Link parser — extracted to mediagrab_bot/link_parser.py
from mediagrab_bot.link_parser import (
    KIND_MESSAGE_LINK, KIND_CHANNEL_LINK, KIND_USERNAME, KIND_CHAT_ID,
    VIS_PUBLIC, VIS_PRIVATE,
    ParsedInput, parse_input, from_chat_reference, describe_input,
)

# ===========================================================================
# UI — keyboards + messages extracted to mediagrab_bot/ui_keyboards.py + ui_messages.py
# ===========================================================================
from mediagrab_bot.ui_keyboards import (
    MAIN, BACK_MAIN, _back,
    main_menu, admin_only_menu, download_menu, analyze_menu,
    ai_modes_menu, inspector_menu, toolbox_menu, library_menu,
    library_entry_keyboard, stats_menu, qr_menu, batch_menu,
    scheduled_menu, backup_menu, admin_menu, history_menu,
    settings_menu, help_menu, back_only, cancel_back,
    settings_back, help_back, history_back, library_back,
    inspector_back, toolbox_back, stats_back, qr_back,
    download_done_keyboard, batch_back, scheduled_back,
    backup_back, admin_back, ai_modes_back,
    vc_menu, vc_manual_menu, vc_settings_menu, vc_back,
    vcmanual_back, vc_stay_presets_menu, vc_cooldown_presets_menu,
    vc_dashboard_menu, vc_dashboard_back_menu,
    vc_dashboard_errors_menu, vc_dashboard_logs_menu,
    vc_dashboard_text,
    talkative_menu, talkative_back,
    witai_settings_menu, witai_settings_text,
    talkative_chat_controls_menu, talkative_vc_controls_menu,
    talkative_media_controls_menu, talkative_mm_voice_menu,
    talkative_mm_clone_menu, talkative_mm_stickers_menu,
    talkative_mm_gifs_menu, talkative_mm_reactions_menu,
    talkative_mm_vision_menu, talkative_mm_limits_menu,
    talkative_mm_diag_menu, talkative_memory_controls_menu,
    talkative_engagement_controls_menu, talkative_safety_controls_menu,
    talkative_diagnostics_menu, _talkative_audit_callbacks,
)
from mediagrab_bot.ui_messages import (
    WELCOME, MAIN_MENU_TEXT, DOWNLOAD_MENU_TEXT, ANALYZE_MENU_TEXT,
    INSPECTOR_MENU_TEXT, TOOLBOX_MENU_TEXT, LIBRARY_MENU_TEXT,
    STATS_MENU_TEXT, QR_MENU_TEXT, HISTORY_MENU_TEXT,
    SETTINGS_MENU_TEXT, HELP_MENU_TEXT,
    QUALITIES, AI_MODELS, LANGUAGES,
    DOWNLOAD_FORWARD_PROMPT, DOWNLOAD_CANCEL_PROMPT,
    ANALYZE_FORWARD_PROMPT, ANALYZE_CANCEL_PROMPT,
    INSPECTOR_PROMPT, INSPECTOR_EMPTY,
    TOOLBOX_PROMPTS, TOOLBOX_INVALID_MEDIA,
    LIBRARY_EMPTY, QR_PROMPT,
    BATCH_MENU_TEXT, BATCH_PROMPT, BATCH_TIMEOUT, BATCH_EMPTY,
    SCHEDULED_MENU_TEXT, SCHEDULE_PROMPT, SCHEDULE_INVALID,
    BACKUP_MENU_TEXT, BACKUP_EXPORTING, BACKUP_IMPORT_PROMPT,
    ADMIN_DENIED, ADMIN_MENU_TEXT, ADMIN_BCAST_PROMPT,
    HELP_DOWNLOAD, HELP_AI, HELP_FEATURES, HELP_FORMATS, HELP_FAQ,
    AI_MODES_TEXT,
    settings_text, progress_text, download_done_text,
    download_failed_text, file_too_big_text,
    analyze_result_text, analyze_failed_text,
    render_history_rows, inspect_result_text, inspect_failed_text,
    media_info_text, library_entry_text, library_list_text,
    user_stats_text, global_stats_text, quota_exceeded_text,
    ai_mode_set_text, batch_summary_text, batch_failed_text,
    scheduled_list_text, backup_export_done_text,
    backup_import_done_text, backup_failed_text,
    admin_users_text, admin_bcast_done_text,
    inline_help_text, inline_stats_text,
    LINK_DOWNLOAD_PROMPT, LINK_DOWNLOAD_EMPTY,
    link_parse_error_text, link_resolving_text,
    link_download_failed_text, link_resolved_ask_msgid,
)

# ===========================================================================
# States — extracted to mediagrab_bot/states.py
# ===========================================================================
from mediagrab_bot.states import (
    IDLE, AWAIT_DOWNLOAD_FORWARD, AWAIT_ANALYZE, AWAIT_INSPECT,
    AWAIT_TOOLBOX, AWAIT_LIBRARY_SEARCH, AWAIT_QR, AWAIT_BATCH,
    AWAIT_SCHEDULE, AWAIT_BACKUP_IMPORT, AWAIT_ADMIN_BCAST,
    AWAIT_LINK_DOWNLOAD, AWAIT_LINK_MESSAGE_ID,
    AWAIT_MTPROTO_SCREENSHOT, AWAIT_MTPROTO_DOWNLOAD,
    AWAIT_MTPROTO_MSGID, AWAIT_MEDIA_BROWSE,
    AWAIT_VC_JOIN_TARGET, AWAIT_VC_CHECK_TARGET,
    AWAIT_VC_STAY, AWAIT_VC_COOLDOWN,
    _states, _tool, _last_download, _user_last_activity,
    _STATE_TTL_SECONDS, _STATE_PRUNE_BATCH, _states_lock,
    _touch_user_activity, _ACTIVE_WORKFLOW_STATES,
    set_state, get_state, reset, set_tool, get_tool,
    set_last_download, get_last_download,
    set_state_sync, get_state_sync,
    set_tool_sync, get_tool_sync,
    set_last_download_sync, get_last_download_sync,
    prune_stale_user_states,
)

# ===========================================================================
# Services — MTProto backend (Telethon, optional)
# ===========================================================================
# All Telethon imports are done lazily inside functions so the bot boots even
# when Telethon isn't installed. Type hints work because of
# ``from __future__ import annotations``.
#
# This section consolidates:
#   * services/session_manager.py     — session file lifecycle
#   * services/mtproto_manager.py     — singleton TelegramClient + watchdog
#   * services/mtproto_service.py     — clean call interface (resolve / dl / shot)
#   * services/mtproto_capture.py     — self-destruct media capture handler
# ===========================================================================


# --- session_manager -------------------------------------------------------

# MTProto / Telethon layer — extracted to mediagrab_bot/mtproto.py



# Services — media_browser (channel category browsing + Download All)
# ===========================================================================
# Browse and bulk-download media by type via MTProto. When a user enters a
# @username or channel link (without a message id) in the Download menu and
# MTProto is available, the bot scans the channel's recent history and shows
# media categories (Photos/Videos/Documents/Audio/Voice/Stickers) with item
# counts. Tapping a category lists individual items + a "Download All" button.
#
# All MTProto operations go through ``mtproto_service`` / ``mtproto_manager``.
# The Bot API remains in charge of all user interaction.
# ===========================================================================

# Map from MTProto media kind -> UI category label.
MB_CATEGORIES: tuple[tuple[str, str, tuple[str, ...]], ...] = (
    # (key, label, telethon-media-kinds)
    ("photo",     "📷 Photos",        ("photo",)),
    ("video",     "🎬 Videos",        ("video", "gif", "video_note")),
    ("document",  "📄 Documents",     ("document",)),
    ("audio",     "🎵 Audio",         ("audio",)),
    ("voice",     "🎤 Voice",         ("voice",)),
    ("sticker",   "🏷️ Stickers",      ("sticker",)),
)

MB_CATEGORY_KEYS = tuple(c[0] for c in MB_CATEGORIES)


def mb_category_label(key: str) -> str:
    for k, label, _ in MB_CATEGORIES:
        if k == key:
            return label
    return key


def mb_kind_to_category(media_kind: str) -> Optional[str]:
    """Map a media kind (from mtproto_service._media_type) to a category key."""
    for cat_key, _, kinds in MB_CATEGORIES:
        if media_kind in kinds:
            return cat_key
    return None


async def mb_scan_channel_media(chat_ref: str | int,
                                limit: int = 100) -> dict[str, list[dict]]:
    """Scan a channel's recent messages and return media grouped by category.

    Returns ``{category_key: [{message_id, media_type, date, caption, size}, …]}``.
    Only messages with media are included. Text-only messages are skipped.
    """
    history = await mtproto_service.get_channel_history(chat_ref, limit=limit)
    by_cat: dict[str, list[dict]] = {k: [] for k in MB_CATEGORY_KEYS}

    for m in history:
        if not m.get("has_media"):
            continue
        media_kind = m.get("media_type", "")
        cat = mb_kind_to_category(media_kind)
        if cat is None:
            # Uncategorised media → put under 'document' as a fallback.
            cat = "document"
        by_cat[cat].append({
            "message_id": m.get("id"),
            "media_type": media_kind,
            "date": m.get("date"),
            "text": m.get("text", ""),
            "sender_id": m.get("sender_id"),
            # v97.24: retain the scan account/client identity so the
            # downloader can reuse the SAME account that scanned.
            "scan_account_id": m.get("scan_account_id"),
            "scan_client_id": m.get("scan_client_id"),
            "scan_entity_type": m.get("scan_entity_type"),
            "scan_entity_id": m.get("scan_entity_id"),
        })
    # Remove empty categories.
    return {k: v for k, v in by_cat.items() if v}


async def mb_download_one(chat_ref: str | int, message_id: int,
                          progress_cb=None,
                          preferred_account_id: str = "") -> dict[str, Any]:
    """Download a single media item. Returns a result dict.

    v97.24: accepts preferred_account_id — the account that scanned the source.
    This account is tried FIRST by mtproto_download_message_media.
    """
    logger.info(
        "MEDIA_DOWNLOAD_HANDLER_ENTERED source_chat_ref=%s source_message_id=%s "
        "handler=mb_download_one preferred_account=%s",
        chat_ref, message_id, preferred_account_id or "none",
    )
    try:
        logger.info(
            "DOWNLOAD_ACCOUNT_SELECTED source_chat_ref=%s source_message_id=%s "
            "entering=mtproto_download_message_media preferred_account=%s",
            chat_ref, message_id, preferred_account_id or "none",
        )
        path, name, mtype, size = await mtproto_service.download_message_media(
            chat_ref, message_id, progress_cb=progress_cb,
            preferred_account_id=preferred_account_id,
        )
        logger.info(
            "DOWNLOAD_MEDIA_COMPLETE source_chat_ref=%s source_message_id=%s "
            "file=%s size=%d media_type=%s",
            chat_ref, message_id, name, size, mtype,
        )
        return {
            "ok": True,
            "path": path,
            "filename": name,
            "media_type": mtype,
            "size": size,
            "message_id": message_id,
        }
    except mtproto_service.MTProtoError as exc:
        logger.error(
            "MEDIA_DOWNLOAD_ERROR source_chat_ref=%s source_message_id=%s "
            "error_type=MTProtoError error=%s",
            chat_ref, message_id, str(exc)[:200],
        )
        return {"ok": False, "error": str(exc), "message_id": message_id}
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "MEDIA_DOWNLOAD_ERROR source_chat_ref=%s source_message_id=%s "
            "error_type=%s error=%s",
            chat_ref, message_id, type(exc).__name__, str(exc)[:200],
        )
        return {"ok": False, "error": str(exc), "message_id": message_id}


async def mb_download_category(
    chat_ref: str | int,
    category: str,
    items: list[dict],
    *,
    progress_cb=None,
    item_done_cb=None,
    dedup: set[int] | None = None,
) -> dict[str, Any]:
    """Download all items in a category list.

    Continues on per-item failure (records the error). Deduplicates by
    message_id when a ``dedup`` set is provided (mutated in place).

    Returns ``{total, succeeded, failed, results: [...], skipped}``.
    """
    dedup = dedup if dedup is not None else set()
    results: list[dict] = []
    succeeded = 0
    failed = 0
    skipped = 0
    total = len(items)

    for i, item in enumerate(items, 1):
        msg_id = item.get("message_id")
        if msg_id is None:
            continue
        if msg_id in dedup:
            skipped += 1
            results.append({"ok": False, "skipped": True, "message_id": msg_id})
            continue
        dedup.add(msg_id)

        # v97.24: pass the scan account from the stored item metadata.
        _item_scan_account = item.get("scan_account_id") or ""
        result = await mb_download_one(chat_ref, msg_id, progress_cb=progress_cb,
                                       preferred_account_id=_item_scan_account)
        results.append(result)
        if result.get("ok"):
            succeeded += 1
        else:
            failed += 1
            # v97.23: log the per-item failure so it's visible in the terminal.
            logger.warning(
                "BULK_DOWNLOAD_ITEM_FAILED source_chat_ref=%s message_id=%s "
                "error=%s succeeded=%d failed=%d index=%d/%d",
                chat_ref, msg_id, result.get("error", "unknown")[:120],
                succeeded, failed, i, total,
            )

        if progress_cb:
            try:
                await progress_cb(i, total, msg_id, result.get("ok", False))
            except Exception:  # noqa: BLE001
                pass
        if item_done_cb:
            try:
                await item_done_cb(result)
            except Exception:  # noqa: BLE001
                pass

        # Small delay to be gentle on Telegram's rate limits.
        await asyncio.sleep(0.3)

    return {
        "total": total,
        "succeeded": succeeded,
        "failed": failed,
        "skipped": skipped,
        "results": results,
    }


def mb_scan_summary(by_cat: dict[str, list[dict]]) -> str:
    """Render a human-readable summary of found media."""
    if not by_cat:
        return "📂 No media found in the recent messages of that channel."
    total = sum(len(v) for v in by_cat.values())
    lines = [f"📂 *Found {total} media items in {len(by_cat)} categories:*\n"]
    for cat_key in MB_CATEGORY_KEYS:
        if cat_key in by_cat:
            lines.append(f"  • {mb_category_label(cat_key)}: {len(by_cat[cat_key])}")
    return "\n".join(lines)


def mb_bulk_summary(result: dict[str, Any], category: str) -> str:
    """Render a bulk-download completion summary."""
    label = mb_category_label(category)
    return (
        f"✅ *Bulk download complete — {label}*\n\n"
        f"📊 Total: {result.get('total', 0)}\n"
        f"✅ Succeeded: {result.get('succeeded', 0)}\n"
        f"❌ Failed: {result.get('failed', 0)}\n"
        f"⏭️ Skipped (duplicates): {result.get('skipped', 0)}"
    )


# ===========================================================================
# V64: Profile Media & Posts Downloader
# ===========================================================================
# Allows users to send @username, user ID, or t.me profile links to
# automatically retrieve profile info, profile photos, and stories that
# are accessible to the MTProto userbot account.
#
# Security: never exposes session info, access hashes, API credentials, or
# internal MTProto identifiers. All logs are sanitized.
#
# Privacy: respects Telegram permissions. If stories are not visible to
# the MTProto account, the bot reports "Stories are not visible" — never
# shows fake counts or bypasses privacy.


# Voice Chat (VC) subsystem — extracted to mediagrab_bot/voicechat.py

def detect_memory_leaks() -> dict[str, Any]:
    """V76 PART 23: Inspect all collections for unbounded growth.

    Checks: retry queues, coverage manager, entity cache, VC state,
    account registry.

    Returns: {ok, warnings: [...], sizes: {...}}
    """
    warnings: list[str] = []
    sizes: dict[str, int] = {}

    try:
        # Coverage manager collections.
        mgr = get_vc_coverage_manager()
        sizes["coverage_active_vcs"] = len(mgr._active_vcs)
        sizes["coverage_failed_vcs"] = len(mgr._failed_vcs)
        sizes["coverage_retry_queue"] = len(mgr._retry_queue)
        sizes["coverage_deferred_vcs"] = len(mgr._deferred_vcs)

        # Entity caches.
        sizes["vc_entity_cache"] = len(_vc_entity_cache)
        # INFO-E-002: the per-client scoped cache (keyed by (id(client),
        # chat_id)) grows linearly with (number of accounts × distinct chats).
        # Without this size being tracked, a multi-account deployment could
        # silently leak here even when vc_entity_cache stayed flat.
        sizes["vc_entity_cache_by_client"] = len(_vc_entity_cache_by_client)
        sizes["user_entity_cache"] = len(_user_entity_cache)

        # VC pool.
        pool = get_vc_pool()
        sizes["vc_pool_states"] = len(pool._states)

        # Account registry.
        cluster = get_userbot_cluster()
        sizes["account_registry"] = len(cluster.list_accounts())

        # Deferred queue.
        sizes["vc_deferred_queue"] = len(_vc_deferred_queue)

        # Check for unbounded growth (warning thresholds).
        if sizes["coverage_retry_queue"] > 1000:
            warnings.append(f"Retry queue large: {sizes['coverage_retry_queue']} items")
        if sizes["vc_entity_cache"] > 10000:
            warnings.append(f"VC entity cache large: {sizes['vc_entity_cache']} items")
        if sizes["vc_entity_cache_by_client"] > 50000:
            warnings.append(
                f"VC entity cache (by client) large: "
                f"{sizes['vc_entity_cache_by_client']} items"
            )
        if sizes["user_entity_cache"] > 10000:
            warnings.append(f"User entity cache large: {sizes['user_entity_cache']} items")
        if sizes["vc_deferred_queue"] > 500:
            warnings.append(f"Deferred queue large: {sizes['vc_deferred_queue']} items")

        logger.info("MEMORY_LEAK_CHECK sizes=%s warnings=%d", sizes, len(warnings))
    except Exception as exc:
        warnings.append(f"Memory leak check failed: {exc}")

    return {
        "ok": len(warnings) == 0,
        "warnings": warnings,
        "sizes": sizes,
    }


def get_vc_stress_test_runner() -> VCStressTestRunner:
    """Get the global VCStressTestRunner instance."""
    global _vc_stress_test_runner
    if _vc_stress_test_runner is None:
        _vc_stress_test_runner = VCStressTestRunner()
    return _vc_stress_test_runner


# ===========================================================================
# V77 PART 1: Message link profile resolution
# ===========================================================================

_user_entity_cache_scoped: dict[tuple[str, int], dict[str, Any]] = {}


async def rotation_audit() -> dict[str, Any]:
    """V84 ISSUE 7: Audit account rotation — verify all roles match.

    Checks:
      - primary_account
      - vc_worker_account
      - resolver_account
      - downloader_account
      - discovery_account

    All should match the current primary after rotation.

    Returns: {ok, primary, vc_worker, resolver, downloader, discovery, mismatches}
    """
    result: dict[str, Any] = {
        "ok": False, "primary": "", "vc_worker": "", "resolver": "",
        "downloader": "", "discovery": "", "mismatches": [],
    }
    logger.info("ROTATION_AUDIT_START")
    try:
        cluster = get_userbot_cluster()
        primary = cluster.get_primary_id()
        result["primary"] = primary

        # Check VC worker account.
        vc_account = _get_current_vc_account_id()
        result["vc_worker"] = vc_account
        if primary and vc_account and primary != vc_account:
            result["mismatches"].append(
                f"primary={primary} vs vc_worker={vc_account}")

        # Check resolver account (same as primary for now).
        result["resolver"] = primary or "(none)"
        result["downloader"] = primary or "(none)"
        result["discovery"] = primary or "(none)"

        result["ok"] = len(result["mismatches"]) == 0
        if result["ok"]:
            logger.info("ROTATION_AUDIT_SUCCESS primary=%s", primary)
        else:
            logger.warning("ROTATION_AUDIT_FAILED mismatches=%s",
                           result["mismatches"])
    except Exception as exc:
        logger.warning("ROTATION_AUDIT_ERROR exc=%s: %s",
                       type(exc).__name__, str(exc)[:120])
        result["error"] = str(exc)[:200]
    return result


# ===========================================================================
# V84 ISSUE 8: Runtime health dashboard
# ===========================================================================

async def runtime_audit() -> dict[str, Any]:
    """V84 ISSUE 8: Return a comprehensive runtime audit.

    Displays:
      - Current Primary
      - Current VC Worker
      - Healthy Accounts
      - Resolver Account
      - Downloader Account
      - Entity Cache Size
      - Per Account Cache Size
      - Failover Count
      - Join Success Rate
      - Resolution Success Rate
    """
    result: dict[str, Any] = {}
    try:
        cluster = get_userbot_cluster()
        primary = cluster.get_primary_id()
        vc_worker = _get_current_vc_account_id()
        healthy = cluster.get_healthy_accounts()
        stats = cluster.get_cluster_stats()

        # Entity cache sizes.
        global_cache_size = len(_vc_entity_cache)
        scoped_cache_size = len(_vc_entity_cache_scoped)
        user_cache_size = len(_user_entity_cache)

        # Per-account cache sizes.
        per_account_cache: dict[str, int] = {}
        for (aid, _) in _vc_entity_cache_scoped:
            per_account_cache[aid] = per_account_cache.get(aid, 0) + 1

        # Join records.
        join_records = get_vc_join_records()
        total_attempts = sum(r.get("attempted", 0) for r in join_records.values())
        total_joined = sum(r.get("joined", 0) for r in join_records.values())
        join_success_rate = (total_joined / total_attempts * 100) if total_attempts > 0 else 0.0

        # Resolution analytics.
        analytics = get_vc_coverage_manager().get_analytics()

        # Failure diagnostics.
        failure_diag = get_vc_failure_diagnostics()

        result = {
            "current_primary": primary or "(none)",
            "current_vc_worker": vc_worker,
            "healthy_accounts": len(healthy),
            "resolver_account": primary or "(none)",
            "downloader_account": primary or "(none)",
            "entity_cache_size": global_cache_size,
            "scoped_cache_size": scoped_cache_size,
            "user_entity_cache_size": user_cache_size,
            "per_account_cache": per_account_cache,
            "failover_count": sum(r.get("failed", 0) for r in join_records.values()),
            "join_success_rate": round(join_success_rate, 1),
            "resolution_success_rate": analytics.get("success_rate", 0.0),
            "failure_breakdown": failure_diag,
            "join_records": join_records,
            "cluster_stats": stats,
        }
        logger.info("RUNTIME_AUDIT primary=%s vc_worker=%s healthy=%d "
                    "cache=%d join_rate=%s%% resolve_rate=%s%%",
                    primary, vc_worker, len(healthy), global_cache_size,
                    join_success_rate, analytics.get("success_rate", 0.0))
    except Exception as exc:
        result["error"] = str(exc)[:200]
        logger.warning("RUNTIME_AUDIT_FAILED exc=%s: %s",
                       type(exc).__name__, str(exc)[:120])
    return result


# ===========================================================================
# V84 ISSUE 4: Real capacity test
# ===========================================================================

_manual_discovery_tasks: dict[tuple[int, int], asyncio.Task] = {}
_manual_discovery_lock = asyncio.Lock()  # protects the registries


def _md_key(admin_id: int, chat_id: int) -> tuple[int, int]:
    """V40 Fix #5: per-admin state key."""
    return (int(admin_id), int(chat_id))


def _md_get(admin_id: int, chat_id: int) -> dict[str, Any]:
    """V40 Fix #5: get (or create) the per-admin Manual Discovery state."""
    key = _md_key(admin_id, chat_id)
    st = _manual_discovery_states.get(key)
    if st is None:
        st = {
            "active": False,
            "keyword": "",
            "status": "idle",          # idle | searching | done | error | cancelled
            "results": [],             # list of result dicts
            "page": 0,
            "selected_ids": set(),     # canonical group IDs
            "ui_message_id": None,
            "ui_chat_id": None,
            "last_error": "",
            "started_at": 0.0,
            "raw_results": 0,
            "unique_results": 0,
            "searches_started": 0,     # cumulative counter
            "searches_completed": 0,   # cumulative counter
            "groups_joined": 0,
            "vcs_joined": 0,
            "failures": 0,
            "generation": 0,           # per-search generation ID
            # V40 Fix #5: per-admin cooperative cancel event (second safety layer).
            "cancel_event": asyncio.Event(),
        }
        _manual_discovery_states[key] = st
    return st


# --- Auto Discovery isolated state (#6, #7, #11) ---

async def manual_discovery_search(keyword: str, *, admin_id: int = 0,
                                   chat_id: int = 0,
                                   message_id: int = 0) -> dict[str, Any]:
    """#2/#14: Run a real public-group search for the exact admin-entered keyword.

    Fix 14: Exposes separate counters for raw_hits, entity_candidates,
    groups_accepted, channels_rejected, duplicates_skipped, inaccessible,
    metadata_failed, persisted, and search_failed.  Does NOT convert every
    empty final result list into "No accessible groups found." — instead
    reports accurate outcomes.

    Reuses _vc_discovery_public_search + _vc_discovery_classify +
    vc_upsert_group + vc_discovery_store_result.  Does NOT depend on the
    scheduled Discovery cycle or .env queries.
    """
    result: dict[str, Any] = {
        "keyword": keyword, "found": 0, "unique": 0, "new": 0,
        "refreshed": 0, "errors": 0, "groups": [],
        # Fix 14: detailed outcome counters.
        "raw_hits": 0, "entity_candidates": 0, "groups_accepted": 0,
        "channels_rejected": 0, "duplicates_skipped": 0,
        "inaccessible": 0, "metadata_failed": 0, "persisted": 0,
        "search_failed": 0, "outcome": "",
    }
    client = mtproto_get_client()
    if client is None:
        result["errors"] = 1
        result["error"] = "mtproto_not_started"
        result["outcome"] = "search_failed"
        return result
    logger.info("MANUAL_DISCOVERY_SEARCH_START admin=%s chat=%s keyword=%s", admin_id, chat_id, keyword[:60])
    # V40 Fix #5: use per-admin state.
    md = _md_get(admin_id, chat_id)
    cancel_ev = md["cancel_event"]
    # Set Manual state.
    async with _manual_discovery_lock:
        md["searches_started"] = int(md.get("searches_started", 0)) + 1
        md["generation"] = int(md.get("generation", 0)) + 1
        my_generation = md["generation"]
        md.update({
            "active": True, "keyword": keyword, "status": "searching",
            "started_at": time.monotonic(),
            "results": [], "raw_results": 0, "unique_results": 0,
            "last_error": "",
            "selected_ids": set(), "page": 0,
        })
        if chat_id and message_id:
            md["ui_chat_id"] = chat_id
            md["ui_message_id"] = message_id
    cancel_ev.clear()
    # Search using the 10-stage pipeline (D1).
    # V85.1/D1: route through DiscoveryManager.search_full — username +
    # invite-link resolution, exact + normalized + expanded + fuzzy search,
    # pagination, merge/dedup, validation, and metadata collection.
    # FloodWait is re-raised so the existing manual-discovery error
    # handling fires.
    from telethon.errors import FloodWaitError

    # Build a progress_cb that updates the per-admin manual-discovery state
    # so the admin UI can show live progress ("🔍 Searching usernames...",
    # "📤 Expanding search queries...", etc.).
    async def _md_progress_cb(msg: str) -> None:
        try:
            async with _manual_discovery_lock:
                if md.get("generation") == my_generation:
                    md["progress"] = msg[:120]
            logger.info("MANUAL_DISCOVERY_PROGRESS admin=%s msg=%s",
                        admin_id, msg[:80])
        except Exception:  # noqa: BLE001
            pass

    try:
        _full_report = await DiscoveryManager.search_full(
            keyword, admin_id=admin_id, max_results=50,
            progress_cb=_md_progress_cb, expand=True,
            include_broadcasts=False)
        # search_full returns dicts in `entities` and Telethon objects in
        # `_raw_entities`.  The downstream code (classify/upsert) expects
        # Telethon objects (it uses getattr + isinstance), so use
        # `_raw_entities`.
        entities = list(_full_report.get("_raw_entities", []) or [])
        # v98.09-P3 §9: Stage-10 metadata map (id → dict entity carrying
        # vc_active/vc_call_id/vc_access_hash from the SAME GetFullChannel/
        # GetFullChat RPCs the classify would re-issue) — passed as
        # ``prefetched`` below so the duplicate metadata probe is skipped.
        _md_stage10 = {}
        try:
            for _md_ent_d in _full_report.get("entities", []) or []:
                if isinstance(_md_ent_d, dict) and isinstance(_md_ent_d.get("id"), int):
                    _md_stage10[_md_ent_d["id"]] = _md_ent_d
        except Exception:  # noqa: BLE001
            _md_stage10 = {}
        # If a FloodWait was captured internally, honour the legacy contract
        # by re-raising it here.
        if not entities and _full_report.get("_floodwait") is not None:
            raise _full_report["_floodwait"]
    except FloodWaitError as exc:
        result["errors"] = 1
        result["error"] = f"FloodWait {exc.seconds}s"
        result["search_failed"] = 1
        result["outcome"] = "search_failed"
        async with _manual_discovery_lock:
            if md.get("generation") == my_generation:
                md["status"] = "error"
                md["active"] = False
                md["last_error"] = result["error"]
        logger.warning("MANUAL_DISCOVERY_SEARCH_FAILED keyword=%s error=FloodWait", keyword[:40])
        return result
    except asyncio.CancelledError:
        async with _manual_discovery_lock:
            if md.get("generation") == my_generation:
                md["status"] = "cancelled"
                md["active"] = False
        raise
    except Exception as exc:  # noqa: BLE001
        result["errors"] = 1
        result["error"] = str(exc)[:200]
        result["search_failed"] = 1
        result["outcome"] = "search_failed"
        async with _manual_discovery_lock:
            if md.get("generation") == my_generation:
                md["status"] = "error"
                md["active"] = False
                md["last_error"] = result["error"]
        logger.warning("MANUAL_DISCOVERY_SEARCH_FAILED keyword=%s error=%s", keyword[:40], str(exc)[:100])
        return result
    result["found"] = len(entities)
    result["raw_hits"] = len(entities)
    logger.info("MANUAL_DISCOVERY_RAW_RESULTS keyword=%s raw_hits=%d", keyword[:40], result["raw_hits"])
    # Process each entity: classify + upsert + store result.
    sem = _vc_discovery_get_semaphore()
    for ent in entities:
        if cancel_ev.is_set():
            break
        raw_gid = getattr(ent, "id", None)
        if raw_gid is None:
            continue
        result["entity_candidates"] += 1
        gid = _vc_canonical_group_id(raw_gid)
        # Cross-discovery dedup: use the shared claim system (#13).
        if not await _vc_discovery_claim_id(gid):
            result["duplicates_skipped"] += 1
            continue  # already being processed by another discovery mode
        try:
            on_tcd, _ = await _vc_discovery_is_target_on_cooldown(gid)
            if on_tcd:
                continue
            async with sem:
                # v98.09-P3 §9: prefetched Stage-10 metadata — no duplicate
                # GetFullChannel/GetFullChat RPC per entity.
                cls = await _vc_discovery_classify(
                    client, ent, prefetched=_md_stage10.get(int(raw_gid)))
            if cls["access_status"] != "accessible":
                result["inaccessible"] += 1
                logger.info("MANUAL_DISCOVERY_ENTITY_REJECTED gid=%s reason=%s",
                            gid, cls["access_status"])
                continue
            result["groups_accepted"] += 1
            result["unique"] += 1
            verified_username = cls["username"] if cls["username"] else None
            # Fix 14: persist the group even if metadata enrichment is partial.
            # Optional enrichment failure (VC detection, member count) must
            # NOT discard an otherwise valid search result.
            try:
                # v98.09-P3 §19: knowledge-cache write — manual discovery
                # results feed the Join-All fast path (call identity +
                # freshness stamp).
                try:
                    await vc_knowledge_store_verified(
                        gid, cls.get("vc_info"), source="manual_search")
                except Exception:  # noqa: BLE001
                    pass
                is_new = await vc_upsert_group(
                    group_id=gid, access_hash=cls["access_hash"],
                    title=cls["title"], username=verified_username,
                    public_link=cls["public_link"],
                    source="manual_search",
                    access_status="accessible",
                    active_vc=True if cls["active_vc"] else False,
                )
                result["persisted"] += 1
            except Exception as exc:  # noqa: BLE001
                result["metadata_failed"] += 1
                logger.warning("MANUAL_DISCOVERY_METADATA_FAILED gid=%s exc=%s", gid, str(exc)[:80])
                # Still include the group in results even if DB upsert failed.
                is_new = True  # assume new if we couldn't check
            try:
                await vc_discovery_store_result(
                    group_id=gid, title=cls["title"] or "",
                    username=verified_username,
                    discovery_query=keyword, discovery_source="manual",
                    active_vc=bool(cls["active_vc"]),
                    status="new" if is_new else "refreshed",
                )
            except Exception:  # noqa: BLE001
                pass  # non-fatal
            if is_new:
                result["new"] += 1
            else:
                result["refreshed"] += 1
            logger.info("MANUAL_DISCOVERY_ENTITY_ACCEPTED gid=%s title=%s accessible=%s active_vc=%s",
                        gid, (cls["title"] or "")[:40], True, bool(cls["active_vc"]))
            # Build the result dict for UI display.
            group_data: dict[str, Any] = {
                "group_id": gid,
                "title": cls["title"] or str(gid),
                "username": verified_username,
                "public_link": cls["public_link"],
                "access_status": cls["access_status"],
                "active_vc": bool(cls["active_vc"]),
                "vc_info": cls.get("vc_info"),
                "access_hash": cls["access_hash"],
                "members": cls.get("members"),
                "is_new": is_new,
                "keyword": keyword,
            }
            result["groups"].append(group_data)
            # Watcher handoff.
            if cls["active_vc"] and cls["vc_info"]:
                _vc_known_call_ids[gid] = int(cls["vc_info"]["call_id"])
            else:
                _vc_known_call_ids.setdefault(gid, 0)
        finally:
            _vc_discovery_release_claim(gid)
    # Fix 14: determine accurate outcome.
    if result["raw_hits"] == 0:
        result["outcome"] = "zero_raw_results"
    elif result["groups_accepted"] == 0 and result["inaccessible"] > 0:
        result["outcome"] = "all_inaccessible"
    elif result["groups_accepted"] == 0 and result["duplicates_skipped"] > 0:
        result["outcome"] = "all_duplicates"
    elif result["persisted"] == 0 and result["metadata_failed"] > 0:
        result["outcome"] = "metadata_failed"
    else:
        result["outcome"] = "success"
    # Update Manual state.
    async with _manual_discovery_lock:
        if md.get("generation") == my_generation:
            md["searches_completed"] = int(md.get("searches_completed", 0)) + 1
            md.update({
                "status": "done", "active": False,
                "results": result["groups"],
                "raw_results": result["found"],
                "unique_results": result["unique"],
            })
    logger.info("MANUAL_DISCOVERY_SEARCH_COMPLETE keyword=%s raw=%d candidates=%d accepted=%d inaccessible=%d duplicates=%d persisted=%d outcome=%s",
                keyword[:40], result["raw_hits"], result["entity_candidates"],
                result["groups_accepted"], result["inaccessible"],
                result["duplicates_skipped"], result["persisted"], result["outcome"])
    return result


def manual_discovery_is_searching(*, admin_id: int = 0, chat_id: int = 0) -> bool:
    """True iff a Manual Discovery search task is currently in flight for this admin."""
    task = _manual_discovery_tasks.get(_md_key(admin_id, chat_id))
    return bool(task is not None and not task.done())


async def manual_discovery_search_start(keyword: str, *, admin_id: int = 0,
                                        chat_id: int = 0,
                                        message_id: int = 0) -> asyncio.Task:
    """V40 Fix #3/#5: launch a Manual Discovery search as an OWNED per-admin Task.

    Stores the task handle in ``_manual_discovery_tasks[(admin_id, chat_id)]``
    so that :func:`manual_discovery_cancel` can call ``task.cancel()`` + await
    with a bounded timeout.  Per-admin: admin A's search is NOT cancelled when
    admin B starts one.

    Replacement semantics: if THIS ADMIN's previous search task is still in
    flight, it is cancelled (bounded 3s await) before the new one starts.
    Generation checks remain as a second safety layer.
    """
    key = _md_key(admin_id, chat_id)
    # Cancel any in-flight search first (replacement by a newer search).
    old_task = _manual_discovery_tasks.get(key)
    if old_task is not None and not old_task.done():
        logger.info("MANUAL_DISCOVERY_REPLACE admin=%s chat=%s cancelling previous task", admin_id, chat_id)
        try:
            old_task.cancel()
            await asyncio.wait_for(old_task, timeout=3)
        except asyncio.TimeoutError:
            logger.warning("Previous manual search did not stop in 3s — proceeding.")
        except asyncio.CancelledError:
            pass
        except Exception:  # noqa: BLE001
            pass
    # Cooperative cancel flag (per-admin, second safety layer).
    md = _md_get(admin_id, chat_id)
    md["cancel_event"].clear()
    # Create + store the owned per-admin task.
    task = supervised_create_task(
        manual_discovery_search(keyword, admin_id=admin_id, chat_id=chat_id,
                                message_id=message_id),
        name=f"manual_discovery_search_{admin_id}_{chat_id}",
    )
    _manual_discovery_tasks[key] = task
    return task


async def _disc_unified_search_flow(update: Update, context: ContextTypes.DEFAULT_TYPE, keyword: str) -> None:
    """V86.2: Run a unified discovery search with live progress updates."""
    chat_id = update.effective_chat.id
    status_msg = await safe_reply_text(update.message, f"🔍 Searching for `{md_escape(keyword[:80])}`...\n\n_Starting search..._")

    progress_state = {"msg_id": status_msg.message_id if status_msg else None, "last_text": ""}

    async def _progress_cb(msg: str) -> None:
        new_text = f"🔍 Searching for `{md_escape(keyword[:80])}`...\n\n_{md_escape(msg)}_"
        if new_text == progress_state["last_text"]:
            return
        progress_state["last_text"] = new_text
        if progress_state["msg_id"]:
            try:
                await context.bot.edit_message_text(chat_id=chat_id, message_id=progress_state["msg_id"], text=new_text, parse_mode="Markdown")
            except Exception:
                pass

    result = await DiscoveryManager.search_full(keyword, admin_id=update.effective_user.id, progress_cb=_progress_cb)

    entities = result.get("entities", [])
    if entities:
        lines = [f"✅ *Found {len(entities)} results for `{md_escape(keyword[:60])}`*\n"]
        for i, ent in enumerate(entities[:15], 1):
            title = md_escape(str(ent.get("title", "?"))[:40])
            uname = f" @{ent['username']}" if ent.get("username") else ""
            members = ent.get("members_count", 0)
            vc = " 🎙" if ent.get("vc_active") else ""
            mem_str = f" ({members:,} members)" if members else ""
            lines.append(f"{i}. {title}{uname}{mem_str}{vc}")
        if len(entities) > 15:
            lines.append(f"\n_...and {len(entities) - 15} more._")
        lines.append(f"\n_Runtime: {result.get('runtime_ms', 0)}ms · Queries: {len(result.get('queries_attempted', []))} · Pages: {result.get('pages_searched', 0)}_")
        summary = "\n".join(lines)
    else:
        reason = result.get("reason", "unknown")
        queries = len(result.get("queries_attempted", []))
        pages = result.get("pages_searched", 0)
        runtime = result.get("runtime_ms", 0)
        summary = (f"❌ *No results found for `{md_escape(keyword[:60])}`*\n\n"
                   f"_Tried {queries} queries across {pages} pages in {runtime}ms._\n"
                   f"_Reason: {md_escape(reason)}_")

    if progress_state["msg_id"]:
        try:
            await context.bot.edit_message_text(chat_id=chat_id, message_id=progress_state["msg_id"], text=summary[:4096], parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔍 New Search", callback_data="disc:search_prompt"), InlineKeyboardButton("🔙 Menu", callback_data="disc:main")]]))
        except Exception:
            await safe_reply_text(update.message, summary[:4096])


async def manual_discovery_cancel(*, admin_id: int = 0, chat_id: int = 0) -> str:
    """V40 Fix #3/#5: cancel THIS ADMIN's in-flight Manual Discovery search.

    Signals cooperative cancellation (per-admin event) AND calls
    ``task.cancel()`` on the owned per-admin task, then awaits with a bounded
    5s timeout.  Does NOT affect other admins' searches.

    Returns: ``cancelled`` | ``not_running`` | ``timeout``.
    """
    key = _md_key(admin_id, chat_id)
    md = _md_get(admin_id, chat_id)
    # Cooperative signal (per-admin, checked between entities).
    md["cancel_event"].set()
    task = _manual_discovery_tasks.get(key)
    if task is None or task.done():
        async with _manual_discovery_lock:
            md["status"] = "cancelled"
            md["active"] = False
        return "not_running"
    logger.info("MANUAL_DISCOVERY_CANCEL_REQUEST admin=%s chat=%s", admin_id, chat_id)
    try:
        task.cancel()
        await asyncio.wait_for(task, timeout=5)
    except asyncio.TimeoutError:
        logger.warning("Manual Discovery task did not stop in 5s — proceeding.")
        return "timeout"
    except asyncio.CancelledError:
        pass
    except Exception as exc:  # noqa: BLE001
        logger.warning("Manual Discovery cancel await error: %s", exc)
    async with _manual_discovery_lock:
        if md.get("status") not in ("cancelled", "done", "error"):
            md["status"] = "cancelled"
            md["active"] = False
    return "cancelled"


def manual_discovery_get_state(*, admin_id: int = 0, chat_id: int = 0) -> dict[str, Any]:
    """V40 Fix #5: get a snapshot of THIS ADMIN's Manual Discovery state."""
    md = _md_get(admin_id, chat_id)
    state = dict(md)
    state["selected_ids"] = set(md.get("selected_ids", set()))
    # Don't expose the raw asyncio.Event in the snapshot.
    state.pop("cancel_event", None)
    return state


def manual_discovery_toggle_select(gid: int, *, admin_id: int = 0,
                                   chat_id: int = 0) -> bool:
    """V40 Fix #5: toggle selection for THIS ADMIN. Returns True if now selected."""
    md = _md_get(admin_id, chat_id)
    selected = md.get("selected_ids", set())
    if gid in selected:
        selected.discard(gid)
        return False
    selected.add(gid)
    return True


def manual_discovery_select_all(results: list[dict[str, Any]], *,
                                admin_id: int = 0, chat_id: int = 0) -> int:
    """V40 Fix #5: select all groups for THIS ADMIN. Returns count selected."""
    md = _md_get(admin_id, chat_id)
    selected = md.get("selected_ids", set())
    for g in results:
        selected.add(int(g["group_id"]))
    return len(selected)


def manual_discovery_unselect_all(*, admin_id: int = 0, chat_id: int = 0) -> None:
    """V40 Fix #5: clear all selections for THIS ADMIN."""
    md = _md_get(admin_id, chat_id)
    md["selected_ids"] = set()


# --- Manual Discovery join actions (#4) ---

async def manual_discovery_join_group(gid: int) -> str:
    """#4: Join a Telegram group (not VC).  Reuses existing group-join path.

    Returns: joined | already_member | pending_approval | failed:<reason>
    """
    client = mtproto_get_client()
    if client is None:
        return "failed:mtproto_not_started"
    try:
        from telethon.tl.types import InputPeerChannel, Channel
        # Resolve the group.
        db = await get_db()
        async with db.execute(
            "SELECT access_hash, username FROM vc_groups WHERE group_id = ?",
            (gid,),
        ) as cur:
            row = await cur.fetchone()
        if row and row["access_hash"]:
            entity = await client.get_entity(
                InputPeerChannel(gid, int(row["access_hash"])))
        elif row and row["username"]:
            entity = await client.get_entity(row["username"])
        else:
            entity = await client.get_entity(gid)
        # Check if already a member.
        # V40 Fix #6: distinguish confirmed non-membership from FloodWait,
        # timeout, network failure, permission error, inaccessible entity,
        # invalid entity, and unknown failure.  Only confirmed non-membership
        # (UserNotParticipantError) or another explicitly safe condition may
        # proceed to JoinChannelRequest.  All other errors ABORT.
        try:
            from telethon.tl.functions.channels import GetParticipantRequest
            from telethon.errors import (
                UserNotParticipantError, FloodWaitError,
                ChatAdminRequiredError, ChannelPrivateError,
                UserBannedInChannelError, ChatWriteForbiddenError,
                PeerIdInvalidError, UsernameInvalidError,
                UsernameNotOccupiedError, InputUserDeactivatedError,
            )
            from telethon.errors import RPCError as _TelethonRPCError
            await mtproto_call_with_retry(
                client, GetParticipantRequest(channel=entity,
                                              participant="me"), retries=1)
            return "already_member"
        except UserNotParticipantError:
            pass  # V40 Fix #6: confirmed non-membership — proceed to join
        except FloodWaitError as exc:
            # Rate limit — must wait, must NOT join.
            logger.warning("MEMBERSHIP_CHECK gid=%s FloodWait=%ss", gid, exc.seconds)
            return f"failed:FloodWait:{exc.seconds}s"
        except (ChatAdminRequiredError, ChatWriteForbiddenError) as exc:
            # Permission error — the userbot lacks rights to check membership.
            # Must NOT assume "not a member" → abort.
            logger.warning("MEMBERSHIP_CHECK gid=%s permission_error=%s", gid, type(exc).__name__)
            return f"failed:permission_error:{type(exc).__name__}"
        except (ChannelPrivateError, UserBannedInChannelError) as exc:
            # Inaccessible entity — the group is private or the userbot is banned.
            # Must NOT join.
            logger.warning("MEMBERSHIP_CHECK gid=%s inaccessible=%s", gid, type(exc).__name__)
            return f"failed:inaccessible:{type(exc).__name__}"
        except (PeerIdInvalidError, UsernameInvalidError,
                UsernameNotOccupiedError, InputUserDeactivatedError) as exc:
            # Invalid entity — the group ID/username is stale or invalid.
            # Must NOT join.
            logger.warning("MEMBERSHIP_CHECK gid=%s invalid_entity=%s", gid, type(exc).__name__)
            return f"failed:invalid_entity:{type(exc).__name__}"
        except asyncio.TimeoutError:
            # Network timeout — membership is UNKNOWN, must NOT assume non-member.
            logger.warning("MEMBERSHIP_CHECK gid=%s timeout", gid)
            return "failed:membership_check:timeout"
        except (ConnectionError, OSError) as exc:
            # Network failure — membership is UNKNOWN, must NOT assume non-member.
            logger.warning("MEMBERSHIP_CHECK gid=%s network_error=%s", gid, type(exc).__name__)
            return f"failed:membership_check:network:{type(exc).__name__}"
        except _TelethonRPCError as exc:
            # Other Telegram RPC error — membership is UNKNOWN, must NOT assume non-member.
            logger.warning("MEMBERSHIP_CHECK gid=%s rpc_error=%s: %s", gid, type(exc).__name__, str(exc)[:100])
            return f"failed:membership_check:rpc:{type(exc).__name__}"
        except Exception as exc:  # noqa: BLE001
            # Unknown error — don't assume "not a member".
            logger.warning("MEMBERSHIP_CHECK gid=%s unknown_error=%s", gid, type(exc).__name__)
            return f"failed:membership_check:unknown:{type(exc).__name__}"
        # Join the public group.
        if isinstance(entity, Channel) and getattr(entity, "username", None):
            from telethon.tl.functions.channels import JoinChannelRequest
            await mtproto_call_with_retry(
                client, JoinChannelRequest(entity.username), retries=2)
            logger.info("MANUAL_JOIN_GROUP gid=%s joined", gid)
            return "joined"
        else:
            # Private group — can't join without invite link.
            return "failed:private_or_no_username"
    except Exception as exc:  # noqa: BLE001
        logger.warning("MANUAL_JOIN_GROUP failed gid=%s: %s", gid, exc)
        return f"failed:{type(exc).__name__}"


async def manual_discovery_join_vc(gid: int, title: str = "") -> str:
    """#4: Join a VC for a specific group.  Reuses _vc_capacity_aware_join.

    Returns: joined | deferred | failed:<reason> | no_active_vc | not_in_vc
    """
    client = mtproto_get_client()
    if client is None:
        return "failed:mtproto_not_started"
    try:
        from telethon.tl.types import InputPeerChannel
        db = await get_db()
        async with db.execute(
            "SELECT access_hash FROM vc_groups WHERE group_id = ?",
            (gid,),
        ) as cur:
            row = await cur.fetchone()
        if not row or not row["access_hash"]:
            return "failed:no_access_hash"
        entity = await client.get_entity(
            InputPeerChannel(gid, int(row["access_hash"])))
        # Re-detect active VC immediately before joining.
        info = await vc_detect_active_call(client, entity)
        if info is None:
            return "no_active_vc"
        # Use the shared capacity-aware join path.
        status = await _vc_capacity_aware_join(
            gid, title=title or str(gid),
            call_id=int(info["call_id"]),
            access_hash=int(info["access_hash"]),
            source="manual_discovery",
        )
        return status
    except VCTransportError as exc:
        return f"failed:{exc}"[:200]
    except Exception as exc:  # noqa: BLE001
        logger.warning("MANUAL_JOIN_VC failed gid=%s: %s", gid, exc)
        return f"failed:{type(exc).__name__}"


# --- Auto Discovery functions (#6, #7, #8, #9, #15) ---

def discovery_main_menu() -> InlineKeyboardMarkup:
    """V86 — the new top-level Discovery menu.

    This is the independent entry point for ALL discovery.  It is reachable
    from the admin menu (adm:disc) and replaces the Discovery buttons that
    used to live inside the VC dashboard.
    """
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔍 Public Groups", callback_data="disc:groups"),
         InlineKeyboardButton("📺 Public Channels", callback_data="disc:channels")],
        [InlineKeyboardButton("👤 Users", callback_data="disc:users"),
         InlineKeyboardButton("🎙 Voice Chats", callback_data="disc:vcs")],
        [InlineKeyboardButton("🔎 Advanced Search", callback_data="vc:disc_search_menu"),
         InlineKeyboardButton("🤖 Auto Discovery", callback_data="vc:dauto:menu")],
        [InlineKeyboardButton("💾 Saved Results", callback_data="disc:saved"),
         InlineKeyboardButton("📜 History", callback_data="disc:history")],
        [InlineKeyboardButton("📊 Statistics", callback_data="disc:stats"),
         InlineKeyboardButton("🔧 Diagnostics", callback_data="disc:diag")],
        [InlineKeyboardButton("🔄 Refresh Discovery", callback_data="disc:refresh"),
         InlineKeyboardButton("📋 Live Results", callback_data="vc:disc_results")],
        [InlineKeyboardButton("⬅ Back to Admin", callback_data="m:admin")],
    ])


def discovery_back_menu() -> InlineKeyboardMarkup:
    """Back button for Discovery sub-screens → returns to disc:main."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⬅ Back to Discovery", callback_data="disc:main")],
    ])


def discovery_unified_menu() -> InlineKeyboardMarkup:
    """V86.2: ONE unified Discovery menu — links to all discovery features."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔍 Manual Search", callback_data="disc:search_prompt")],
        [InlineKeyboardButton("📡 Background Discovery", callback_data="vc:dauto:menu"),
         InlineKeyboardButton("🎙 VC Discovery", callback_data="vc:dv2:active_vcs")],
        [InlineKeyboardButton("📜 History", callback_data="disc:history"),
         InlineKeyboardButton("⭐ Saved Results", callback_data="disc:saved")],
        [InlineKeyboardButton("📊 Statistics", callback_data="disc:stats"),
         InlineKeyboardButton("⚙️ Settings", callback_data="vc:disc_query_settings")],
        [InlineKeyboardButton("🔙 Back", callback_data="b:admin")],
    ])


async def discovery_main_text() -> str:
    """V86 — the text for the top-level Discovery menu."""
    try:
        health = await DiscoveryManager.get_health()
    except Exception:  # noqa: BLE001
        health = {}
    try:
        stats = await DiscoveryManager.get_statistics()
    except Exception:  # noqa: BLE001
        stats = {}
    lines = [
        "🔍 *Discovery Module*",
        "",
        f"• Health Score: `{health.get('health_score', 0)}/100`",
        f"• MTProto: `{'✅' if health.get('mtproto_started') else '❌'}`",
        f"• Healthy Accounts: `{health.get('accounts_healthy', 0)}/{health.get('accounts_total', 0)}`",
        f"• Searches Executed: `{stats.get('searches_executed', 0)}`",
        f"• Successful: `{stats.get('successful_searches', 0)}`",
        f"• Groups Found: `{stats.get('groups_found', 0)}`",
        f"• Channels Found: `{stats.get('channels_found', 0)}`",
        f"• Cache Entries: `{len(_vc_entity_cache) + len(_vc_entity_cache_by_client)}`",
        "",
        "Select a discovery type to begin:",
    ]
    return "\n".join(lines)


def discovery_unified_text() -> str:
    """D3 — text for the unified Discovery Hub menu.

    Pure (non-async) string builder so it can be called inline from
    ``route_callback`` without ``await`` — the unified menu does NOT need the
    health/stats pre-fetch that ``discovery_main_text`` performs, which keeps
    the menu render latency low (no Telegram RPC round-trips on every tap).
    """
    return (
        "🔍 *Discovery Hub*\n\n"
        "Search and discover Telegram groups, channels, and voice chats.\n\n"
        "• *Manual Search* — search by keyword, @username, or invite link\n"
        "• *Background Discovery* — auto-discovery running in the background\n"
        "• *VC Discovery* — find active voice chats\n"
        "• *History* — view past search results\n"
        "• *Saved Results* — bookmarked groups\n"
        "• *Statistics* — discovery performance metrics\n"
        "• *Settings* — configure discovery queries\n\n"
        "Select an option below."
    )


# --- Auto Discovery live UI (#8) ---

# Talkative subsystem — extracted to mediagrab_bot/talkative.py


kb = SimpleNamespace(
    main_menu=main_menu, download_menu=download_menu, analyze_menu=analyze_menu,
    ai_modes_menu=ai_modes_menu, inspector_menu=inspector_menu,
    toolbox_menu=toolbox_menu, library_menu=library_menu,
    library_entry_keyboard=library_entry_keyboard, stats_menu=stats_menu,
    qr_menu=qr_menu, batch_menu=batch_menu, scheduled_menu=scheduled_menu,
    backup_menu=backup_menu, admin_menu=admin_menu, history_menu=history_menu,
    settings_menu=settings_menu, help_menu=help_menu, back_only=back_only,
    cancel_back=cancel_back, settings_back=settings_back, help_back=help_back,
    history_back=history_back, library_back=library_back,
    inspector_back=inspector_back, toolbox_back=toolbox_back,
    stats_back=stats_back, qr_back=qr_back,
    download_done_keyboard=download_done_keyboard, batch_back=batch_back,
    scheduled_back=scheduled_back, backup_back=backup_back,
    admin_back=admin_back, ai_modes_back=ai_modes_back,
    admin_only_menu=admin_only_menu,
    mtproto_menu=mtproto_menu,  # V86/D6: mtproto_back removed — function was deleted in TLG-D-001; kwarg caused module-load NameError.
    vc_menu=vc_menu, vc_manual_menu=vc_manual_menu,
    vc_settings_menu=vc_settings_menu, vc_back=vc_back,
    vcmanual_back=vcmanual_back,
    vc_stay_presets_menu=vc_stay_presets_menu,
    vc_cooldown_presets_menu=vc_cooldown_presets_menu,
    # Task ID 16 — Talkative Mode UI.
    talkative_menu=talkative_menu, talkative_back=talkative_back,
)

msg = SimpleNamespace(
    WELCOME=WELCOME, MAIN_MENU_TEXT=MAIN_MENU_TEXT,
    DOWNLOAD_MENU_TEXT=DOWNLOAD_MENU_TEXT, ANALYZE_MENU_TEXT=ANALYZE_MENU_TEXT,
    INSPECTOR_MENU_TEXT=INSPECTOR_MENU_TEXT, TOOLBOX_MENU_TEXT=TOOLBOX_MENU_TEXT,
    LIBRARY_MENU_TEXT=LIBRARY_MENU_TEXT, STATS_MENU_TEXT=STATS_MENU_TEXT,
    QR_MENU_TEXT=QR_MENU_TEXT, HISTORY_MENU_TEXT=HISTORY_MENU_TEXT,
    SETTINGS_MENU_TEXT=SETTINGS_MENU_TEXT, HELP_MENU_TEXT=HELP_MENU_TEXT,
    QUALITIES=QUALITIES, AI_MODELS=AI_MODELS, LANGUAGES=LANGUAGES,
    DOWNLOAD_FORWARD_PROMPT=DOWNLOAD_FORWARD_PROMPT,
    DOWNLOAD_CANCEL_PROMPT=DOWNLOAD_CANCEL_PROMPT,
    ANALYZE_FORWARD_PROMPT=ANALYZE_FORWARD_PROMPT,
    ANALYZE_CANCEL_PROMPT=ANALYZE_CANCEL_PROMPT,
    INSPECTOR_PROMPT=INSPECTOR_PROMPT, INSPECTOR_EMPTY=INSPECTOR_EMPTY,
    TOOLBOX_PROMPTS=TOOLBOX_PROMPTS, TOOLBOX_INVALID_MEDIA=TOOLBOX_INVALID_MEDIA,
    LIBRARY_EMPTY=LIBRARY_EMPTY, QR_PROMPT=QR_PROMPT,
    BATCH_MENU_TEXT=BATCH_MENU_TEXT, BATCH_PROMPT=BATCH_PROMPT,
    BATCH_TIMEOUT=BATCH_TIMEOUT, BATCH_EMPTY=BATCH_EMPTY,
    SCHEDULED_MENU_TEXT=SCHEDULED_MENU_TEXT, SCHEDULE_PROMPT=SCHEDULE_PROMPT,
    SCHEDULE_INVALID=SCHEDULE_INVALID, BACKUP_MENU_TEXT=BACKUP_MENU_TEXT,
    BACKUP_EXPORTING=BACKUP_EXPORTING, BACKUP_IMPORT_PROMPT=BACKUP_IMPORT_PROMPT,
    ADMIN_DENIED=ADMIN_DENIED, ADMIN_MENU_TEXT=ADMIN_MENU_TEXT,
    ADMIN_BCAST_PROMPT=ADMIN_BCAST_PROMPT,
    HELP_DOWNLOAD=HELP_DOWNLOAD, HELP_AI=HELP_AI,
    HELP_FEATURES=HELP_FEATURES, HELP_FORMATS=HELP_FORMATS,
    HELP_FAQ=HELP_FAQ, AI_MODES_TEXT=AI_MODES_TEXT,
    settings_text=settings_text, progress_text=progress_text,
    download_done_text=download_done_text,
    download_failed_text=download_failed_text,
    file_too_big_text=file_too_big_text,
    analyze_result_text=analyze_result_text,
    analyze_failed_text=analyze_failed_text,
    render_history_rows=render_history_rows,
    inspect_result_text=inspect_result_text,
    inspect_failed_text=inspect_failed_text,
    media_info_text=media_info_text,
    library_entry_text=library_entry_text,
    library_list_text=library_list_text,
    user_stats_text=user_stats_text,
    global_stats_text=global_stats_text,
    quota_exceeded_text=quota_exceeded_text,
    ai_mode_set_text=ai_mode_set_text,
    batch_summary_text=batch_summary_text,
    batch_failed_text=batch_failed_text,
    scheduled_list_text=scheduled_list_text,
    backup_export_done_text=backup_export_done_text,
    backup_import_done_text=backup_import_done_text,
    backup_failed_text=backup_failed_text,
    admin_users_text=admin_users_text,
    admin_bcast_done_text=admin_bcast_done_text,
    inline_help_text=inline_help_text,
    inline_stats_text=inline_stats_text,
    LINK_DOWNLOAD_PROMPT=LINK_DOWNLOAD_PROMPT,
    LINK_DOWNLOAD_EMPTY=LINK_DOWNLOAD_EMPTY,
    link_parse_error_text=link_parse_error_text,
    link_resolving_text=link_resolving_text,
    link_download_failed_text=link_download_failed_text,
    link_resolved_ask_msgid=link_resolved_ask_msgid,
)

states = SimpleNamespace(
    IDLE=IDLE,
    AWAIT_DOWNLOAD_FORWARD=AWAIT_DOWNLOAD_FORWARD,
    AWAIT_ANALYZE=AWAIT_ANALYZE,
    AWAIT_INSPECT=AWAIT_INSPECT,
    AWAIT_TOOLBOX=AWAIT_TOOLBOX,
    AWAIT_LIBRARY_SEARCH=AWAIT_LIBRARY_SEARCH,
    AWAIT_QR=AWAIT_QR,
    AWAIT_BATCH=AWAIT_BATCH,
    AWAIT_SCHEDULE=AWAIT_SCHEDULE,
    AWAIT_BACKUP_IMPORT=AWAIT_BACKUP_IMPORT,
    AWAIT_ADMIN_BCAST=AWAIT_ADMIN_BCAST,
    AWAIT_LINK_DOWNLOAD=AWAIT_LINK_DOWNLOAD,
    AWAIT_LINK_MESSAGE_ID=AWAIT_LINK_MESSAGE_ID,
    AWAIT_MTPROTO_SCREENSHOT=AWAIT_MTPROTO_SCREENSHOT,
    AWAIT_MTPROTO_DOWNLOAD=AWAIT_MTPROTO_DOWNLOAD,
    AWAIT_MTPROTO_MSGID=AWAIT_MTPROTO_MSGID,
    AWAIT_MEDIA_BROWSE=AWAIT_MEDIA_BROWSE,
    AWAIT_VC_JOIN_TARGET=AWAIT_VC_JOIN_TARGET,
    AWAIT_VC_CHECK_TARGET=AWAIT_VC_CHECK_TARGET,
    AWAIT_VC_STAY=AWAIT_VC_STAY,
    AWAIT_VC_COOLDOWN=AWAIT_VC_COOLDOWN,
    set_state=set_state, get_state=get_state, reset=reset,
    set_tool=set_tool, get_tool=get_tool,
    set_last_download=set_last_download, get_last_download=get_last_download,
    set_state_sync=set_state_sync, get_state_sync=get_state_sync,
    set_tool_sync=set_tool_sync, get_tool_sync=get_tool_sync,
    set_last_download_sync=set_last_download_sync,
    get_last_download_sync=get_last_download_sync,
)

downloader = SimpleNamespace(
    download_forwarded=download_forwarded,
    DownloadError=DownloadError,
    FileTooLarge=FileTooLarge,
)

ai_analyzer = SimpleNamespace(
    analyze_frames=analyze_frames,
    analyze_audio=analyze_audio,
    analyze_images=analyze_images,
    cleanup_frames=cleanup_frames,
)

ai_modes = SimpleNamespace(
    ACCEPTS=ACCEPTS, MODE_LABELS=MODE_LABELS, MODE_ORDER=MODE_ORDER,
    PROMPTS=PROMPTS, build_prompt=build_prompt,
    NORMALISERS=NORMALISERS, normalise=normalise,
    accepts=accepts, media_kind_for=media_kind_for,
    render_result=render_result,
)

media_tools = SimpleNamespace(
    extract_audio=extract_audio, extract_thumbnail=extract_thumbnail,
    media_info=media_info, compress_video=compress_video,
    convert_image=convert_image, ToolError=ToolError,
)

qr_generator = SimpleNamespace(
    generate_qr=generate_qr, QRError=QRError,
)

backup = SimpleNamespace(
    export_user_json=export_user_json,
    parse_backup_file=parse_backup_file,
    restore_from_dict=restore_from_dict,
    export_global_json=export_global_json,
)

frame_extractor = SimpleNamespace(
    extract_frames=extract_frames,
    FrameExtractionError=FrameExtractionError,
)

media_processor = SimpleNamespace(
    download_slot=download_slot, with_retries=with_retries,
    retrying=retrying, send_file_back=send_file_back,
    notify=notify, safe_unlink=safe_unlink, human_size=human_size,
)

i18n = SimpleNamespace(
    supported_languages=supported_languages, t=t, has_language=has_language,
)

link_parser = SimpleNamespace(
    parse_input=parse_input, describe_input=describe_input,
    from_chat_reference=from_chat_reference, ParsedInput=ParsedInput,
    KIND_MESSAGE_LINK=KIND_MESSAGE_LINK, KIND_CHANNEL_LINK=KIND_CHANNEL_LINK,
    KIND_USERNAME=KIND_USERNAME, KIND_CHAT_ID=KIND_CHAT_ID,
    VIS_PUBLIC=VIS_PUBLIC, VIS_PRIVATE=VIS_PRIVATE,
)

session_manager = SimpleNamespace(
    session_path=session_path,
    session_file_exists=session_file_exists,
    validate_session=validate_session,
    interactive_login=interactive_login,
    session_info=session_info,
)

mtproto_manager = SimpleNamespace(
    is_available=mtproto_is_available,
    is_started=mtproto_is_started,
    start=mtproto_start,
    stop=mtproto_stop,
    restart=mtproto_restart,
    get_client=mtproto_get_client,
    get_status=mtproto_get_status,
    call_with_retry=mtproto_call_with_retry,
)

mtproto_service = SimpleNamespace(
    MTProtoError=MTProtoError,
    MTProtoNotAvailable=MTProtoNotAvailable,
    is_available=mtproto_service_is_available,
    resolve_entity=mtproto_resolve_entity,
    get_channel_history=mtproto_get_channel_history,
    download_message_media=mtproto_download_message_media,
    download_channel_media=mtproto_download_channel_media,
    screenshot=mtproto_screenshot,
)

media_browser = SimpleNamespace(
    CATEGORIES=MB_CATEGORIES,
    CATEGORY_KEYS=MB_CATEGORY_KEYS,
    category_label=mb_category_label,
    kind_to_category=mb_kind_to_category,
    scan_channel_media=mb_scan_channel_media,
    download_one=mb_download_one,
    download_category=mb_download_category,
    scan_summary=mb_scan_summary,
    bulk_summary=mb_bulk_summary,
)

_DASHBOARD_SNAPSHOT_DIR = Path(config.project_root) / "data"
_DASHBOARD_SNAPSHOT_INTERVAL = 15.0  # seconds
_dashboard_snapshot_task: asyncio.Task | None = None


def _dashboard_provider_snapshot() -> dict[str, Any]:
    """Build a JSON-safe snapshot of provider health for the dashboard."""
    snap: dict[str, Any] = {}
    for provider in ("groq", "openrouter", "gemini"):
        st = _provider_get_state(provider)
        snap[provider] = {
            "state": _provider_effective_state(provider),
            "generation": int(st.get("generation", 0)),
            "failure_class": st.get("failure_class", ""),
            "cooldown_remaining": _provider_cooldown_remaining(provider),
            "total_failures": int(st.get("total_failures", 0)),
            "total_successes": int(st.get("total_successes", 0)),
            "last_error": st.get("last_error", "")[:200],
            "consecutive_successes": int(st.get("consecutive_successes", 0)),
            "last_notification_type": st.get("last_notification_type", ""),
        }
    return snap


def _dashboard_talkative_snapshot() -> dict[str, Any]:
    """Build a JSON-safe snapshot of talkative engine metrics."""
    try:
        return _talkative_engine_metrics_snapshot()
    except Exception:  # noqa: BLE001
        return {}


def _dashboard_write_snapshots() -> None:
    """Write provider health + talkative metrics snapshots to data/.
    Best-effort; never raises.

    V85.5 FIX (RELI-G-005): uses ``_atomic_write`` so the dashboard never
    reads a half-written JSON file during a snapshot refresh.
    """
    try:
        _DASHBOARD_SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)
        prov = _dashboard_provider_snapshot()
        _atomic_write(
            _DASHBOARD_SNAPSHOT_DIR / "provider_health_snapshot.json",
            json.dumps(prov, default=str),
        )
        talk = _dashboard_talkative_snapshot()
        _atomic_write(
            _DASHBOARD_SNAPSHOT_DIR / "talkative_metrics_snapshot.json",
            json.dumps(talk, default=str),
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("DASHBOARD_SNAPSHOT_WRITE_FAILED exc=%s", exc)


# V64: Alerts log writer.
# Appends provider failure/recovery events (and other notable alerts) to
# data/alerts_log.json so the dashboard's Recent Alerts panel + WebSocket
# mini-service can surface them in real time. Capped at 200 entries.
_ADMIN_TRIGGER_SECRET: str = os.environ.get("ADMIN_TRIGGER_SECRET", "")
_admin_trigger_unauth_warned: bool = False


def _verify_sentinel(payload: dict, sig: str) -> bool:
    """SEC-G-001/002/003: verify an HMAC-SHA256 signature on an admin sentinel
    payload.

    The signature covers the canonical JSON encoding (sorted keys, no
    whitespace) of every payload field EXCEPT ``sig``. Uses
    ``hmac.compare_digest`` for constant-time comparison.

    Returns True iff a secret is configured AND the signature matches.
    Returns False (and logs a one-time warning) if the secret is unset.
    """
    global _admin_trigger_unauth_warned
    if not _ADMIN_TRIGGER_SECRET:
        if not _admin_trigger_unauth_warned:
            logger.warning(
                "ADMIN_TRIGGER_SECRET is empty — admin control channel is "
                "UNAUTHENTICATED. All sentinel requests will be rejected. "
                "Set ADMIN_TRIGGER_SECRET to enable HMAC verification."
            )
            _admin_trigger_unauth_warned = True
        return False
    if not isinstance(payload, dict) or not sig or not isinstance(sig, str):
        return False
    try:
        body = {k: payload[k] for k in sorted(payload) if k != "sig"}
        msg = json.dumps(body, sort_keys=True, separators=(",", ":")).encode("utf-8")
        expected = _hmac.new(
            _ADMIN_TRIGGER_SECRET.encode("utf-8"), msg, hashlib.sha256
        ).hexdigest()
        return _hmac.compare_digest(expected, str(sig))
    except Exception:  # noqa: BLE001 — never raise on verification
        return False


def _read_signed_sentinel(path: Path) -> dict | None:
    """SEC-G-001/002/003: read a sentinel file, unlink it, and verify its
    HMAC signature.

    Returns the parsed payload dict on success, or None if the file is
    missing, unparseable, unsigned, or fails verification. The file is
    ALWAYS unlinked (even on failure) so a poisoned request can't retry.
    """
    try:
        raw = path.read_text()
    except OSError:
        return None
    try:
        path.unlink()
    except OSError:
        pass
    req: dict = {}
    if raw and raw.strip():
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                req = parsed
        except json.JSONDecodeError:
            req = {}
    sig = req.get("sig", "") if isinstance(req, dict) else ""
    if not _verify_sentinel(req, sig):
        logger.warning(
            "ADMIN_TRIGGER_REJECTED file=%s reason=sig_invalid_or_missing",
            path.name,
        )
        return None
    return req


def _handle_admin_clear_cooldown(provider: str) -> None:
    """Clear a provider's cooldown immediately (admin request)."""
    try:
        async def _do():
            async with _provider_lock(provider):
                st = _provider_get_state(provider)
                if st["cooldown_until"] > 0:
                    st["cooldown_until"] = 0.0
                    st["cooldown_seconds"] = 0.0
                    logger.info("ADMIN_CLEAR_COOLDOWN provider=%s (admin-triggered)",
                                provider)
        # V85.5 FIX (ASYNC-G-003): use asyncio.create_task (which binds to
        # the running loop) instead of the deprecated get_event_loop(). The
        # try/except RuntimeError handles the no-running-loop edge case.
        # v97.44 FIX: use supervised_create_task (was bare create_task) so
        # exceptions are retrieved (no "Future exception was never retrieved").
        try:
            supervised_create_task(_do(), name="admin_clear_cooldown")
        except RuntimeError:
            pass
    except Exception as exc:  # noqa: BLE001
        logger.warning("ADMIN_CLEAR_COOLDOWN_FAILED provider=%s exc=%s", provider, exc)


def _process_admin_triggers() -> None:
    """Check for admin control-channel sentinel files and execute them.

    V85.5 FIX (SEC-G-001/002/003): every sentinel file MUST carry a valid
    HMAC signature (see ``_verify_sentinel``). Unsigned or invalid requests
    are rejected and the action is skipped.
    """
    data_dir = _DASHBOARD_SNAPSHOT_DIR
    # 1. Clear-cooldown requests.
    for provider in ("groq", "openrouter", "gemini"):
        p = data_dir / f"clear_cooldown_request_{provider}.json"
        if p.exists():
            req = _read_signed_sentinel(p)
            if req is None:
                continue  # signature invalid or file missing
            _handle_admin_clear_cooldown(provider)
    # 2. Provider test requests — these are best-effort; the bot's test
    #    path requires a running event loop + Telegram bot instance, so
    #    we delegate to a background task.
    for provider in ("groq", "openrouter", "gemini"):
        p = data_dir / f"provider_test_request_{provider}.json"
        if p.exists():
            req = _read_signed_sentinel(p)
            if req is None:
                continue
            try:
                supervised_create_task(
                    _admin_run_provider_test(provider),
                    name=f"admin_provider_test_{provider}",
                )
            except RuntimeError:
                pass
    # 3. V64: Feature flag toggle requests.
    p = data_dir / "feature_flag_toggle_request.json"
    if p.exists():
        req = _read_signed_sentinel(p)
        if req:
            _handle_admin_feature_flag_toggle(req.get("flag", ""), bool(req.get("value", False)))
    # 4. V64: Bot restart request.
    p = data_dir / "bot_restart_request.json"
    if p.exists():
        req = _read_signed_sentinel(p)
        if req is not None:
            _handle_admin_restart()
    # 5. V65: Provider key replacement requests.
    for provider in ("groq", "openrouter", "gemini"):
        p = data_dir / f"replace_key_request_{provider}.json"
        if p.exists():
            req = _read_signed_sentinel(p)
            if req:
                try:
                    supervised_create_task(
                        _admin_run_replace_key(provider, req.get("api_key", "")),
                        name=f"admin_replace_key_{provider}",
                    )
                except RuntimeError:
                    pass


def _handle_admin_feature_flag_toggle(flag: str, value: bool) -> None:
    """V64: toggle a talkative feature flag in the DB (admin request)."""
    if not flag:
        return
    # V85.3 FIX BUG DB-1 (SQL injection): allow-list the flag name before
    # interpolating it into SQL.  ``flag`` originates from a JSON request
    # file and was interpolated directly into the UPDATE statement, which
    # is a SQL-injection vector.  Only known boolean feature-flag columns
    # are permitted.
    _ALLOWED_FEATURE_FLAGS = frozenset({
        "enabled", "private_auto_reply", "group_auto_reply",
        "mention_trigger", "reply_trigger", "wake_words_enabled",
        "multimodal_enabled", "voice_enabled", "proactive_enabled",
        "memory_enabled", "media_library_enabled", "sticker_replies",
        "gif_replies", "animation_replies",
    })
    if flag not in _ALLOWED_FEATURE_FLAGS:
        logger.warning("ADMIN_FEATURE_FLAG_TOGGLE_REJECTED flag=%s (not in allow-list)", flag)
        return
    try:
        async def _do():
            try:
                db = await get_db()
                # Update the talkative_global_settings row (id=1 is the singleton).
                await db.execute(
                    f"UPDATE talkative_global_settings SET {flag} = ? WHERE id = 1",
                    (1 if value else 0,),
                )
                await db.commit()
                logger.info("ADMIN_FEATURE_FLAG_TOGGLE flag=%s value=%s", flag, value)
            except Exception as exc:  # noqa: BLE001
                logger.warning("ADMIN_FEATURE_FLAG_TOGGLE_FAILED flag=%s exc=%s", flag, exc)
        try:
            supervised_create_task(_do(), name="admin_feature_flag_toggle")
        except RuntimeError:
            pass
    except Exception as exc:  # noqa: BLE001
        logger.warning("ADMIN_FEATURE_FLAG_TOGGLE_DISPATCH_FAILED flag=%s exc=%s", flag, exc)


def _handle_admin_restart() -> None:
    """V64: gracefully restart the bot process (admin request).

    Writes a sentinel file that the bot's main loop checks, then exits.
    A process manager (systemd, pm2, etc.) restarts the bot automatically.
    """
    try:
        logger.info("ADMIN_RESTART_REQUESTED — exiting for graceful restart")
        # Schedule a delayed exit so the HTTP response can be sent first.
        def _exit():
            try:
                import signal as _sig
                os.kill(os.getpid(), _sig.SIGTERM)
            except Exception:  # noqa: BLE001
                sys.exit(0)
        import threading
        threading.Timer(2.0, _exit).start()
    except Exception as exc:  # noqa: BLE001
        logger.warning("ADMIN_RESTART_FAILED exc=%s", exc)


async def _admin_run_provider_test(provider: str) -> None:
    """Run a provider test and write the result to data/provider_test_result_<p>.json."""
    result_path = _DASHBOARD_SNAPSHOT_DIR / f"provider_test_result_{provider}.json"
    try:
        # Use the existing talkative_generate path with a minimal payload.
        result = await talkative_generate(
            [{"role": "user", "content": "Say 'OK' in one word."}],
            "You are a test. Reply with exactly: OK",
            {"provider": provider, "max_reply_chars": 50, "request_timeout": 10},
        )
        payload = {
            "provider": provider,
            "success": bool(result.success and result.text),
            "text": (result.text or "")[:100],
            "error": result.error or "",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as exc:  # noqa: BLE001
        payload = {
            "provider": provider,
            "success": False,
            "text": "",
            "error": f"{type(exc).__name__}: {str(exc)[:120]}",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    try:
        # v97.31: offload sync file I/O to a thread (was blocking the event loop).
        await asyncio.to_thread(result_path.write_text, json.dumps(payload, default=str))
    except OSError as exc:
        logger.warning("ADMIN_PROVIDER_TEST_RESULT_WRITE_FAILED provider=%s exc=%s",
                       provider, exc)


async def _admin_run_replace_key(provider: str, api_key: str) -> None:
    """V65: validate + atomically activate a new API key for a provider.

    Uses the existing _provider_key_activate path (which validates with a
    minimal bounded request, then atomically activates). The key is NEVER
    logged — it's in memory only for the duration of this call.
    """
    result_path = _DASHBOARD_SNAPSHOT_DIR / f"replace_key_result_{provider}.json"
    try:
        if not api_key or len(api_key) < 10:
            payload = {
                "provider": provider,
                "success": False,
                "error": "Key too short or empty",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        else:
            ok, reason = await _provider_key_activate(provider, api_key)
            payload = {
                "provider": provider,
                "success": ok,
                "error": "" if ok else (reason or "unknown"),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
    except Exception as exc:  # noqa: BLE001
        payload = {
            "provider": provider,
            "success": False,
            "error": f"{type(exc).__name__}: {str(exc)[:120]}",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    # Scrub the key from memory.
    del api_key
    try:
        # V85.5 FIX (RELI-G-005): atomic write so the dashboard never
        # reads a half-written result while the bot is mid-replace.
        _atomic_write(result_path, json.dumps(payload, default=str))
    except OSError as exc:
        logger.warning("ADMIN_REPLACE_KEY_RESULT_WRITE_FAILED provider=%s exc=%s",
                       provider, exc)


async def _dashboard_snapshot_loop() -> None:
    """Background loop: write dashboard snapshots every 15s + process admin triggers.

    v97.5 EVENT-LOOP FIX: ``_dashboard_write_snapshots`` + ``_process_admin_triggers``
    do synchronous file I/O (tmp write_text + os.replace + read_text/unlink).
    Running them directly in the async loop blocked the event loop for the
    duration of each I/O call every 15s — causing brief lag spikes for
    Telegram handlers + discovery cycles.  They are now offloaded to a thread
    via ``asyncio.to_thread`` so the event loop stays responsive.
    """
    logger.info("Dashboard snapshot loop started (interval=%.0fs).",
                _DASHBOARD_SNAPSHOT_INTERVAL)
    while True:
        try:
            await asyncio.sleep(_DASHBOARD_SNAPSHOT_INTERVAL)
            # v97.66: combine both sync calls into ONE to_thread to avoid
            # sequential executor contention (root cause of the 10.11s
            # EVENT_LOOP_LAG_CRITICAL — the second to_thread blocked waiting
            # for a free executor worker).
            def _snapshot_and_triggers():
                try:
                    _dashboard_write_snapshots()
                except Exception:  # noqa: BLE001
                    pass
                try:
                    _process_admin_triggers()
                except Exception:  # noqa: BLE001
                    pass
            await asyncio.to_thread(_snapshot_and_triggers)
        except asyncio.CancelledError:
            logger.info("Dashboard snapshot loop cancelled.")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.warning("Dashboard snapshot loop error: %s", exc)


def _dashboard_snapshot_start() -> None:
    """Start the dashboard snapshot background task (idempotent)."""
    global _dashboard_snapshot_task
    if _dashboard_snapshot_task is not None and not _dashboard_snapshot_task.done():
        return
    try:
        _dashboard_snapshot_task = asyncio.create_task(_dashboard_snapshot_loop())
    except RuntimeError:
        pass  # no event loop


# V63: Bot heartbeat + history archiver.
# Writes a heartbeat file every 5s so the dashboard can detect whether the
# bot process is actually running. Also archives a history snapshot every
# 60s so the dashboard can plot trends (replies/day, failures/day).
_BOT_START_TIME = time.time()
_BOT_HEARTBEAT_PATH = Path(config.project_root) / "data" / "bot_heartbeat.json"
_BOT_HEARTBEAT_INTERVAL = 5.0
_bot_heartbeat_task: asyncio.Task | None = None
_BOT_HISTORY_DIR = Path(config.project_root) / "data" / "history"
_BOT_HISTORY_INTERVAL = 60.0
_bot_history_task: asyncio.Task | None = None
_BOT_HISTORY_MAX_FILES = 1440  # 24h of 60s snapshots


def _bot_write_heartbeat() -> None:
    """Write a heartbeat file with the bot's real start time + uptime."""
    global _v9902_hb_fail_logged_at
    try:
        _BOT_HEARTBEAT_PATH.parent.mkdir(parents=True, exist_ok=True)
        now = time.time()
        payload = {
            "pid": os.getpid(),
            "started_at": _BOT_START_TIME,
            "uptime_seconds": int(now - _BOT_START_TIME),
            "last_beat": now,
            "last_beat_iso": datetime.now(timezone.utc).isoformat(),
        }
        _BOT_HEARTBEAT_PATH.write_text(json.dumps(payload, default=str))
    except Exception as exc:  # noqa: BLE001
        # v99.02 FIX-6 (RC-6, RUNTIME-PROVEN via v99.01 production logs
        # 2026-09-09 23:58 → 2026-09-10 03:20): heartbeat write failures
        # were logged at DEBUG — for the ENTIRE 3.2-hour FD-exhaustion
        # death spiral the operator saw NOTHING at INFO+ about the root
        # cause (4,811× "Too many open files", all at DEBUG). The
        # heartbeat IS the first casualty of FD exhaustion and is now
        # ERROR-visible, rate-limited to one line / 5 min (the write runs
        # every 5s — unthrottled ERROR spam would flood the log).
        _now_m = time.monotonic()
        if _now_m - _v9902_hb_fail_logged_at >= 300.0:
            _v9902_hb_fail_logged_at = _now_m
            logger.error(
                "BOT_HEARTBEAT_WRITE_FAILED exc=%s (v99.02 FIX-6: raised "
                "to ERROR — FD exhaustion kills the heartbeat FIRST; "
                "see the FD_CENSUS fields on the next BOT_HEARTBEAT line)",
                exc,
            )
        else:
            logger.debug("BOT_HEARTBEAT_WRITE_FAILED exc=%s", exc)


# v99.02 FIX-3 (RC-3): FD census + exhaustion guard.
#
# RUNTIME-PROVEN (v99.01 production logs 2026-09-09 17:55 → 2026-09-10
# 03:20): the process accumulated ~1024 open FDs over ~6 hours of
# "healthy-window" operation (first Errno 24 at 23:58) and then entered
# a 3.2-hour zombie death spiral (reconnect storm every ~19s, sqlite /
# heartbeat / snapshot writes all failing) from which it never
# recovered. An exhaustive source audit + an offline FD probe (300 REAL
# pipeline join cycles + 1000 atomic writes → ΔFD = 0) cleared the
# bot's own Python paths; the accumulation is in the native join-stack
# (ntgcalls/libdatachannel transports per dispatch) or another
# real-stack-only path. The census makes the NEXT production run
# self-diagnosing: every 60s the heartbeat reports the open-FD count
# BY CLASS (socket/pipe/file/anon), so the leaking resource type is
# directly readable from the log. The guard converts the slow zombie
# death into a clean supervisor restart while the process can still
# shut down gracefully (SIGTERM → PTB stop → supervisor respawn),
# instead of 3+ hours of a dead-but-running bot.
#
# The guard is a RESILIENCE measure, NOT a leak fix: the leak sources
# addressed elsewhere in v99.02 (FIX-1 kills the null-stream join churn
# that correlates with the accumulation; FIX-7 closes the deterministic
# leaks). VC_FD_GUARD_RESTART=0 disables the restart (census still
# logs).
_v9902_hb_fail_logged_at = 0.0
_v9902_fd_guard_confirmed = 0
_v9902_fd_guard_last_error = 0.0


def _fd_census() -> dict:
    """v99.02 FIX-3: classify this process's open file descriptors.

    Reads /proc/self/fd (Linux only; returns {"available": False} on
    other platforms / failures — best-effort, never raises)."""
    out: dict = {"available": False, "total": 0, "soft": 0, "hard": 0,
                 "sockets": 0, "pipes": 0, "files": 0, "anon": 0, "other": 0}
    try:
        import resource as _resource
        _soft, _hard = _resource.getrlimit(_resource.RLIMIT_NOFILE)
        out["soft"], out["hard"] = int(_soft), int(_hard)
    except Exception:  # noqa: BLE001
        pass
    try:
        names = os.listdir("/proc/self/fd")
    except Exception:  # noqa: BLE001
        return out
    out["available"] = True
    out["total"] = len(names)
    for _name in names:
        try:
            _tgt = os.readlink(f"/proc/self/fd/{_name}")
        except Exception:  # noqa: BLE001
            out["other"] += 1
            continue
        if _tgt.startswith("socket:"):
            out["sockets"] += 1
        elif _tgt.startswith("pipe:"):
            out["pipes"] += 1
        elif _tgt.startswith("anon_inode:"):
            out["anon"] += 1
        elif _tgt.startswith("/"):
            out["files"] += 1
        else:
            out["other"] += 1
    return out


def _fd_guard_evaluate(census: dict) -> None:
    """v99.02 FIX-3: threshold check + (config-gated) graceful restart.

    Restarts only when the census stays ≥ _FD_GUARD_RATIO of the soft
    limit across TWO consecutive 60s heartbeats (a transient spike from
    a large media download must not restart the bot). The restart uses
    the same mechanism as the admin /restart button (SIGTERM to self →
    PTB graceful stop → supervisor respawn)."""
    global _v9902_fd_guard_confirmed, _v9902_fd_guard_last_error
    if not census.get("available"):
        return
    _soft = int(census.get("soft", 0) or 0)
    _total = int(census.get("total", 0) or 0)
    if _soft <= 0 or _total <= 0:
        return
    _ratio = _total / float(_soft)
    if _ratio < 0.85:
        _v9902_fd_guard_confirmed = 0
        return
    # At/above 85% of the soft limit.
    _now_m = time.monotonic()
    if _now_m - _v9902_fd_guard_last_error >= 300.0:
        _v9902_fd_guard_last_error = _now_m
        logger.error(
            "VC_FD_GUARD_CRITICAL open_fds=%d soft_limit=%d ratio=%.2f "
            "sockets=%d pipes=%d files=%d anon=%d other=%d — ≥85%% of the "
            "FD budget is consumed (v99.02 FIX-3 census; the class counts "
            "identify the leaking resource)",
            _total, _soft, _ratio, census.get("sockets", 0),
            census.get("pipes", 0), census.get("files", 0),
            census.get("anon", 0), census.get("other", 0),
        )
    _v9902_fd_guard_confirmed += 1
    if _v9902_fd_guard_confirmed < 2:
        return
    _restart = True
    try:
        _restart = str(os.environ.get("VC_FD_GUARD_RESTART", "1")
                       ).strip().lower() not in ("0", "false", "no", "off")
    except Exception:  # noqa: BLE001
        pass
    if not _restart:
        return
    logger.critical(
        "VC_FD_GUARD_RESTART open_fds=%d soft_limit=%d confirmed=%d — "
        "requesting graceful self-restart (SIGTERM → supervisor respawn) "
        "BEFORE hard FD exhaustion turns into the v99.01-style 3-hour "
        "zombie death spiral. The census history above identifies the "
        "leaking resource class. VC_FD_GUARD_RESTART=0 disables "
        "(v99.02 FIX-3).",
        _total, _soft, _v9902_fd_guard_confirmed,
    )
    import threading
    def _fd_guard_restart():
        import signal as _signal
        try:
            os.kill(os.getpid(), _signal.SIGTERM)
        except Exception:  # noqa: BLE001
            pass
    threading.Timer(2.0, _fd_guard_restart).start()


def _v9911_hb_field(name: str, value: Any, fmt: str = "d") -> str:
    """v99.11 P0-1: one heartbeat field, degraded to ``unknown`` safely."""
    try:
        if value is None:
            return f"{name}=unknown"
        if isinstance(value, str):
            return f"{name}={value}" if value else f"{name}=unknown"
        if fmt == "s":
            return f"{name}={value!s}"
        if fmt == "f":
            return f"{name}={float(value):.0f}"
        return f"{name}={int(value):d}"
    except Exception:  # noqa: BLE001
        return f"{name}=unknown"


def _bot_heartbeat_census_line(
    *,
    uptime: Any,
    snapshot: Any = None,
    joined_transports: Any = None,
    active_joins: Any = None,
    join_queue: Any = None,
    population_txt: str = "",
    fd_txt: str = "",
    mem_txt: str = "",
    acct_txt: str = "",
) -> str:
    """v99.11 P0-1 (the RC-2 fix): assemble the BOT_HEARTBEAT payload.

    Replaces the v99.10 emission that carried FIVE ``%`` placeholders
    against FOUR arguments (handlers.py:2615-2628 in v99.10) — Python
    logging dropped the record AT HANDLER level ("--- Logging error ---"
    to stderr only), which is why the 2026-09-21 production logs show
    ZERO ``BOT_HEARTBEAT``/``MEM_CENSUS``/``FD_CENSUS`` lines for 2.5
    hours while the bot walked into the OOM kill.

    This pure helper PRE-FORMATS the entire payload field by field; the
    loop then emits it through exactly ``logger.info("BOT_HEARTBEAT %s",
    line)`` — one placeholder, one argument, structurally impossible to
    mismatch.  Every metric is individually guarded: a broken source
    degrades that field to ``unknown``; the helper NEVER raises and
    NEVER returns an empty string, so telemetry failure can neither
    kill nor disable the heartbeat task.

    Required head fields (stable, grep-able order):
      pid= uptime=<n>s rss_mb= threads= fd=<n>/<n> joined_transports=
      join_queue= active_joins= memory_limit_mb= resource_headroom_mb=
    followed by the historical census sections (TASK_POPULATION /
    FD_CENSUS / MEM_CENSUS / per-account joins) and a short provenance
    suffix.
    """
    try:
        parts: list[str] = []
        try:
            parts.append(_v9911_hb_field("pid", os.getpid()))
        except Exception:  # noqa: BLE001
            parts.append("pid=unknown")
        # uptime in the epoch clock domain (v98.06 FIX-OO preserved).
        try:
            parts.append(f"uptime={float(uptime):.0f}s")
        except Exception:  # noqa: BLE001
            parts.append("uptime=unknown")
        # Resource fields from the v99.11 ResourceSnapshot (unknown-safe).
        snap = snapshot
        try:
            if snap is None:
                from .vc_resources import collect_resource_snapshot as _crs
                snap = _crs()
        except Exception:  # noqa: BLE001
            snap = None

        def _snap_f(attr: str, fmt: str = "f"):
            try:
                return _v9911_hb_field(attr, getattr(snap, attr, None), fmt)
            except Exception:  # noqa: BLE001
                return f"{attr}=unknown"

        parts.append(_snap_f("rss_mb"))
        parts.append(_snap_f("threads", "d"))
        # fd=<count>/<limit>
        try:
            _fd_c = getattr(snap, "fd_count", None)
            _fd_l = getattr(snap, "fd_limit", None)
            parts.append("fd=%s/%s" % (
                f"{int(_fd_c):d}" if isinstance(_fd_c, (int, float)) else "unknown",
                f"{int(_fd_l):d}" if isinstance(_fd_l, (int, float)) else "unknown"))
        except Exception:  # noqa: BLE001
            parts.append("fd=unknown/unknown")
        parts.append(_v9911_hb_field("joined_transports", joined_transports))
        parts.append(_v9911_hb_field("join_queue", join_queue))
        parts.append(_v9911_hb_field("active_joins", active_joins))
        parts.append(_snap_f("memory_limit_mb"))
        # resource_headroom_mb (computed property; unknown-safe)
        try:
            _hr = getattr(snap, "resource_headroom_mb", None)
            parts.append(_v9911_hb_field(
                "resource_headroom_mb",
                float(_hr) if isinstance(_hr, (int, float)) else None,
                "f"))
        except Exception:  # noqa: BLE001
            parts.append("resource_headroom_mb=unknown")
        # Historical census sections (v98.07/v98.08/v99.02/v99.10).
        for _sec in (population_txt, fd_txt, mem_txt, acct_txt):
            try:
                if _sec and str(_sec).strip():
                    parts.append(" ".join(str(_sec).split()))
            except Exception:  # noqa: BLE001
                pass
        line = " ".join(p for p in parts if p)
        line += (" (v98.05 FIX-FF liveness; v98.06 FIX-OO uptime epoch "
                 "domain; v99.02 FIX-3 FD_CENSUS; v99.10 FIX-D MEM_CENSUS; "
                 "v99.11 P0-1 single-%s safe emission + resource fields)")
        return line or "BOT_HEARTBEAT pid=unknown uptime=unknown"
    except Exception:  # noqa: BLE001
        # Absolute last resort: a complete, honest, all-unknown line —
        # the heartbeat marker must NEVER disappear from the log stream.
        return ("pid=unknown uptime=unknown rss_mb=unknown "
                "threads=unknown fd=unknown/unknown "
                "joined_transports=unknown join_queue=unknown "
                "active_joins=unknown memory_limit_mb=unknown "
                "resource_headroom_mb=unknown (v99.11 P0-1 degraded)")


async def _bot_heartbeat_loop() -> None:
    """Background loop: write heartbeat every 5s.

    v97.5 EVENT-LOOP FIX: ``_bot_write_heartbeat`` does synchronous file I/O
    (mkdir + write_text).  Running it directly in the async loop blocked the
    event loop every 5s.  Offloaded to a thread via ``asyncio.to_thread``.

    v98.05 FIX-FF: emit an explicit BOT_HEARTBEAT log marker every
    _BOT_HEARTBEAT_LOG_INTERVAL seconds (60s default). This complements the
    heartbeat file writer with a clear liveness signal in the diagnostic log.

    v99.11 P0-1: the emission is now a pre-formatted single-``%s``
    ``logger.info("BOT_HEARTBEAT %s", line)`` — the v99.10 call had five
    placeholders against four arguments, so Python logging silently
    dropped EVERY heartbeat record at handler level (production proof:
    zero BOT_HEARTBEAT lines 2026-09-21 10:16→12:50).
    """
    logger.info("Bot heartbeat loop started (interval=%.0fs).",
                _BOT_HEARTBEAT_INTERVAL)
    # v98.05 FIX-FF: track last BOT_HEARTBEAT log emission (independent of
    # the file-write cadence, which is every 5s — too noisy for a log line).
    _last_hb_log = 0.0
    # v98.08 FIX-WW: every 10th logged heartbeat also reports the task
    # population (F2': total_tasks=540 at the CRITICAL lag with 528/540
    # anonymous dispatch coroutines; TASK_POPULATION makes growth vs
    # stable cycles measurable from the heartbeat stream alone).
    _v808_hb_count = 0
    # v99.07 FIX-12 (P0): heartbeat with the v98.05 FIX-KK worker watchdog
    # (lazy import — breaks the handlers -> bootstrap cycle at import time).
    _v9907_hb = None
    try:
        from .bootstrap import bot_worker_register as _v9907_reg, \
            bot_worker_heartbeat as _v9907_hb
        _v9907_reg("bot_heartbeat_loop", expected_duration=15.0)
    except Exception:  # noqa: BLE001
        _v9907_hb = None
    while True:
        try:
            await asyncio.sleep(_BOT_HEARTBEAT_INTERVAL)
            if _v9907_hb is not None:
                _v9907_hb("bot_heartbeat_loop")  # v99.07 FIX-12
            await asyncio.to_thread(_bot_write_heartbeat)
            # v98.05 FIX-FF: emit BOT_HEARTBEAT log marker every 60s.
            _now_mono = time.monotonic()
            if _now_mono - _last_hb_log >= 60.0:
                _last_hb_log = _now_mono
                # v98.06 FIX-OO (BUG-VC-BOT-UPTIME-CLOCK-DOMAIN-MIXUP,
                # RUNTIME-PROVEN via bot-diagnostic (18+).log: every
                # BOT_HEARTBEAT line showed uptime=-1787480363s (≈ −56.7
                # years — the DELTA was correct but the BASE was insane):
                #   handlers.py:2256 ``_BOT_START_TIME = time.time()``
                #   (epoch ≈ 1.787e9) vs the OLD line 2307 which computed
                #   ``_now_mono`` (a time.monotonic() value) minus
                #   ``_BOT_START_TIME`` (an epoch value) → a small
                #   process-relative number minus ≈1.787e9 → ≈ −1.787e9.
                # FIX: use ONE clock domain — _BOT_START_TIME is epoch, so
                # uptime = time.time() - _BOT_START_TIME (both epoch).
                # The 60s log-gating above correctly keeps monotonic()
                # (interval measurement must never use the wall clock).
                # Sibling audit: _bot_write_heartbeat (line ~2274) already
                # uses ``now - _BOT_START_TIME`` with now=time.time()
                # (correct); line ~4818's epoch usage is unchanged (correct).
                _uptime = time.time() - _BOT_START_TIME
                # v98.07 FIX-VV (F5): per-account join counters inside the
                # heartbeat — makes "two accounts, one joins, the other does
                # not" verifiable from ANY 60s heartbeat line (the v98.06 log
                # needed VC_ACTIVE_JOIN_BACKEND_SET correlation to prove the
                # 40/0 skew).
                _v807_acct_txt = ""
                try:
                    from . import voicechat as _vc_mod
                    _v807_stats = getattr(_vc_mod, "_vc_account_join_stats", {})
                    if _v807_stats:
                        _v807_acct_txt = " joins=" + " ".join(
                            f"{_aid}:J={_rec.get('joins_made', 0)}"
                            f"/F={_rec.get('joins_failed', 0)}"
                            for _aid, _rec in sorted(_v807_stats.items())
                        )
                except Exception:  # noqa: BLE001
                    pass
                # v98.08 FIX-WW: TASK_POPULATION every 10th logged beat.
                _v808_hb_count += 1
                _v808_pop_txt = ""
                if _v808_hb_count % 10 == 0:
                    try:
                        _v808_tasks = asyncio.all_tasks()
                        _v808_pop_txt = (" TASK_POPULATION total=%d" %
                                         len(_v808_tasks))
                    except Exception:  # noqa: BLE001
                        pass
                # v99.02 FIX-3 (RC-3): FD census on every logged beat
                # (60s) + the exhaustion guard. Offloaded to a thread —
                # up to `soft` readlink() syscalls must never block the
                # event loop. See the FIX-3 block comment above for the
                # runtime evidence and the guard's design.
                _v9902_fd_txt = ""
                try:
                    _census = await asyncio.to_thread(_fd_census)
                    if _census.get("available"):
                        _v9902_fd_txt = (
                            " FD_CENSUS total=%d soft=%d sockets=%d "
                            "pipes=%d files=%d anon=%d other=%d" % (
                                _census["total"], _census["soft"],
                                _census["sockets"], _census["pipes"],
                                _census["files"], _census["anon"],
                                _census["other"]))
                        await asyncio.to_thread(_fd_guard_evaluate, _census)
                        # v99.11.1 FIX-1: FD-drift leak detection + the
                        # transport-lifecycle leak sweep on EVERY logged
                        # beat (v99.11 only swept at join-dispatch time —
                        # during the measured 2026-09-22/23 production
                        # drift phase, with NO joins in flight, the
                        # sweep NEVER ran and VC_TRANSPORT_RESOURCE_LEAK_
                        # SUSPECTED could never fire).  Pure observability
                        # — no destructive action, no new restarts; the
                        # v99.02 FD guard remains the last-resort backstop.
                        try:
                            from .vc_resources import (
                                fd_drift_evaluate as _v9911_drift,
                                transport_lifecycle as _v9911_tl_hb,
                            )
                            _v9911_hb_joined = 0
                            try:
                                from .voicechat import (
                                    _vc_active_join_backends_by_chat as _am)
                                _v9911_hb_joined = len(_am)
                            except Exception:  # noqa: BLE001
                                pass
                            await asyncio.to_thread(
                                _v9911_drift,
                                int(_census.get("total", 0) or 0),
                                int(_v9911_hb_joined),
                                sockets=int(_census.get("sockets", -1)),
                            )
                            await asyncio.to_thread(
                                _v9911_tl_hb.sweep_for_leaks)
                            await asyncio.to_thread(_v9911_tl_hb.prune)
                        except Exception:  # noqa: BLE001
                            pass
                except Exception:  # noqa: BLE001
                    pass
                # v99.10 FIX-D (MEM_CENSUS — the 2026-09-20 production run
                # was OOM-SIGKILLed twice mid-join with the fd census
                # plateaued at 409/1024: the exhausted resource was MEMORY/
                # THREADS, not fds, and the old heartbeat could not see it).
                # One /proc/self/status read per logged beat (60s): RSS,
                # thread count, + the live joined-transport count (the
                # per-chat owner map = live native ntgcalls pipelines).
                # Cheap + thread-offloaded so the loop never blocks.
                _v9910_mem_txt = ""
                try:
                    from .voicechat import _vc_resource_pressure_state
                    _v9910_st = await asyncio.to_thread(
                        _vc_resource_pressure_state, force=True)
                    if _v9910_st.get("available"):
                        _v9910_mem_txt = (
                            " MEM_CENSUS rss_mb=%.0f threads=%d "
                            "fd=%d/%d joined_transports=%d" % (
                                float(_v9910_st.get("rss_kb", 0) or 0) / 1024.0,
                                int(_v9910_st.get("threads", 0) or 0),
                                int(_v9910_st.get("fd_total", 0) or 0),
                                int(_v9910_st.get("fd_soft", 0) or 0),
                                int(_v9910_st.get("joined_transports", 0) or 0),
                            ))
                except Exception:  # noqa: BLE001
                    pass
                # v99.03 RC-10: every 5th logged beat (300s) also reports
                # the ACCOUNT_HEALTH summary — live cluster accounts vs
                # registered vs dead .session files, so drift ("two
                # accounts but showing one") is visible from the
                # heartbeat stream alone.  v99.03 RC-12: flush expired
                # null-stream suppression windows on the same cadence so
                # the SUPPRESSED summaries appear even when no further
                # join arrives for that chat.
                if _v808_hb_count % 5 == 0:
                    try:
                        from .mtproto import account_session_health  # noqa: PLC0415
                        _v9903_h = account_session_health()
                        logger.info(
                            "ACCOUNT_HEALTH live_clients=%d "
                            "cluster_accounts=%d dead_sessions=%d "
                            "unregistered=%d expected_cluster=%d "
                            "total_files=%d — live_clients counts "
                            "primary_global + registered cluster sessions; "
                            "dead files need delete + re-login "
                            "(SESSION_REMEDIATION); expected_cluster is "
                            "accounts.json's registry size (v99.03 RC-10)",
                            _v9903_h["live"], _v9903_h["cluster_accounts"],
                            _v9903_h["dead"], _v9903_h["unregistered"],
                            _v9903_h["expected_cluster"],
                            _v9903_h["total_files"],
                        )
                    except Exception:  # noqa: BLE001
                        pass
                    try:
                        from .vc_pipeline import _null_stream_suppress_flush  # noqa: PLC0415
                        _null_stream_suppress_flush()
                    except Exception:  # noqa: BLE001
                        pass
                # v99.11 P0-1: guarded live counters for the heartbeat
                # head fields (each its own try/except — a broken metric
                # degrades to ``unknown`` and can never kill the beat).
                _v9911_hb_mod = None
                try:
                    from . import voicechat as _v9911_hb_mod
                except Exception:  # noqa: BLE001
                    _v9911_hb_mod = None
                _v9911_joined: Any = "unknown"
                try:
                    _v9911_joined = len(getattr(
                        _v9911_hb_mod, "_vc_active_join_backends_by_chat", {})
                        or {})
                except Exception:  # noqa: BLE001
                    _v9911_joined = "unknown"
                _v9911_active: Any = "unknown"
                try:
                    _v9911_active = len(getattr(
                        _v9911_hb_mod, "_vc_in_flight_joins", set()) or set())
                except Exception:  # noqa: BLE001
                    _v9911_active = "unknown"
                _v9911_queue: Any = "unknown"
                try:
                    _v9911_st = getattr(
                        _v9911_hb_mod, "_vc_join_all_state", {}) or {}
                    _v9911_prog = _v9911_st.get("progress") or {}
                    _v9911_tot = int(_v9911_prog.get("total") or 0)
                    _v9911_done = int(_v9911_prog.get("processed") or 0)
                    _v9911_queue = max(0, _v9911_tot - _v9911_done) \
                        if _v9911_tot else 0
                except Exception:  # noqa: BLE001
                    _v9911_queue = "unknown"
                # v99.11 P0-1: the ResourceSnapshot (cgroup-aware memory
                # boundary) — thread-offloaded, guarded.
                _v9911_snap = None
                try:
                    from .vc_resources import collect_resource_snapshot \
                        as _v9911_crs
                    _v9911_snap = await asyncio.to_thread(
                        _v9911_crs,
                        joined_transports=(
                            _v9911_joined
                            if isinstance(_v9911_joined, int) else 0),
                        active_joins=(
                            _v9911_active
                            if isinstance(_v9911_active, int) else 0),
                        queued_joins=(
                            _v9911_queue
                            if isinstance(_v9911_queue, int) else 0),
                    )
                except Exception:  # noqa: BLE001
                    _v9911_snap = None
                # v99.11 P0-1 (THE FIX): pre-formatted payload + ONE
                # placeholder, ONE argument — the v99.10 call had five
                # placeholders against four arguments and every record
                # was silently dropped at handler level.
                _v9911_line = _bot_heartbeat_census_line(
                    uptime=_uptime, snapshot=_v9911_snap,
                    joined_transports=_v9911_joined,
                    active_joins=_v9911_active, join_queue=_v9911_queue,
                    population_txt=_v808_pop_txt, fd_txt=_v9902_fd_txt,
                    mem_txt=_v9910_mem_txt, acct_txt=_v807_acct_txt,
                )
                logger.info("BOT_HEARTBEAT %s", _v9911_line)
        except asyncio.CancelledError:
            logger.info("Bot heartbeat loop cancelled.")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.warning("Bot heartbeat loop error: %s", exc)


def _bot_heartbeat_start() -> None:
    """Start the heartbeat background task (idempotent)."""
    global _bot_heartbeat_task
    if _bot_heartbeat_task is not None and not _bot_heartbeat_task.done():
        return
    try:
        _bot_heartbeat_task = asyncio.create_task(_bot_heartbeat_loop())
    except RuntimeError:
        pass


def _bot_write_history_snapshot() -> None:
    """Archive a single history snapshot (provider health + talkative metrics).

    Files are named history_YYYYMMDD_HHMMSS.json and capped at
    _BOT_HISTORY_MAX_FILES (oldest deleted first).
    """
    try:
        _BOT_HISTORY_DIR.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        payload = {
            "timestamp": ts,
            "epoch": int(time.time()),
            "providers": _dashboard_provider_snapshot(),
            "talkative": _dashboard_talkative_snapshot(),
        }
        path = _BOT_HISTORY_DIR / f"history_{ts}.json"
        path.write_text(json.dumps(payload, default=str))
        # Prune old files.
        files = sorted(_BOT_HISTORY_DIR.glob("history_*.json"))
        if len(files) > _BOT_HISTORY_MAX_FILES:
            for old in files[: len(files) - _BOT_HISTORY_MAX_FILES]:
                try:
                    old.unlink()
                except OSError:
                    pass
    except Exception as exc:  # noqa: BLE001
        logger.debug("BOT_HISTORY_WRITE_FAILED exc=%s", exc)


async def _bot_history_loop() -> None:
    """Background loop: archive a history snapshot every 60s."""
    logger.info("Bot history loop started (interval=%.0fs).",
                _BOT_HISTORY_INTERVAL)
    # v99.08 sustainability item 3: heartbeat with the worker watchdog
    # (lazy import — same pattern as _bot_heartbeat_loop).
    _v9908_hhb = None
    try:
        from .bootstrap import (
            bot_worker_register as _v9908_hreg,
            bot_worker_heartbeat as _v9908_hhb,
        )
        _v9908_hreg("bot_history_loop",
                    expected_duration=float(_BOT_HISTORY_INTERVAL) * 1.5)
    except Exception:  # noqa: BLE001
        _v9908_hhb = None
    while True:
        try:
            if _v9908_hhb is not None:
                try:
                    _v9908_hhb("bot_history_loop")  # v99.08 item 3
                except Exception:  # noqa: BLE001
                    pass
            await asyncio.sleep(_BOT_HISTORY_INTERVAL)
            # v97.30: offload the sync file I/O (mkdir, write_text, glob,
            # unlink) to a thread so it doesn't block the event loop.  This
            # was a contributor to EVENT_LOOP_LAG_MODERATE on slow filesystems.
            await asyncio.to_thread(_bot_write_history_snapshot)
        except asyncio.CancelledError:
            logger.info("Bot history loop cancelled.")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.warning("Bot history loop error: %s", exc)


def _bot_history_start() -> None:
    """Start the history archiver background task (idempotent)."""
    global _bot_history_task
    if _bot_history_task is not None and not _bot_history_task.done():
        return
    try:
        _bot_history_task = asyncio.create_task(_bot_history_loop())
    except RuntimeError:
        pass


# V65: Auto-start the dashboard-live WebSocket mini-service.
# Spawns mini-services/dashboard-live/ as a subprocess so it's always running
# when the bot is running. The subprocess is tracked + terminated on shutdown.
_dashboard_live_proc: subprocess.Popen | None = None
_DASHBOARD_LIVE_DIR = Path(config.project_root) / "mini-services" / "dashboard-live"
_DASHBOARD_LIVE_PORT = 3003


# v97.27 FIX: common bun install locations used as fallback when `bun` is
# not on the bot's PATH. The bot frequently runs inside a sanitised venv
# (e.g. /root/gr/venv) whose PATH excludes /usr/local/bin where bun is
# installed, so `shutil.which("bun")` returns None and the dashboard-live
# WebSocket service never starts (DASHBOARD_LIVE_SPAWN_FAILED — bun not on
# PATH). These candidates are probed in order; the first existing executable
# wins. The list is deliberately conservative and platform-portable.
_DASHBOARD_LIVE_BUN_CANDIDATES: tuple[str, ...] = (
    "/usr/local/bin/bun",
    "/usr/bin/bun",
    "/opt/bun/bin/bun",
    "/snap/bin/bun",
    os.path.expanduser("~/.bun/bin/bun"),
    os.path.expanduser("~/.local/bin/bun"),
    "/home/z/.bun/bin/bun",
)


def _resolve_bun_binary() -> str | None:
    """Locate the bun executable for spawning the dashboard-live service.

    Resolution order (first hit wins):
      1. ``DASHBOARD_LIVE_BUN`` env var — explicit absolute override.
      2. ``BUN_BIN`` env var — generic override (mirrors Node's NODE_BIN).
      3. ``shutil.which("bun")`` — whatever is on the bot's PATH.
      4. A small set of well-known install locations (see
         ``_DASHBOARD_LIVE_BUN_CANDIDATES``).

    Returns the absolute path to the bun binary, or ``None`` if none could be
    found. All candidates are verified with :func:`os.access(X_OK)` so a
    non-executable file is never returned.
    """
    # 1. Explicit overrides.
    for env_name in ("DASHBOARD_LIVE_BUN", "BUN_BIN"):
        candidate = os.environ.get(env_name, "").strip()
        if candidate and os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
        if candidate:
            logger.warning(
                "DASHBOARD_LIVE_BUN_OVERRIDE_INVALID env=%s value=%s — not an "
                "executable file, falling through to PATH/candidates.",
                env_name, candidate,
            )
    # 2. PATH lookup.
    found = shutil.which("bun")
    if found:
        return found
    # 3. Well-known locations.
    for candidate in _DASHBOARD_LIVE_BUN_CANDIDATES:
        try:
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                return candidate
        except OSError:
            continue
    # 4. v97.33/v97.34: auto-install bun if not found. Download the official
    #    bun binary to ~/.bun/bin/bun. This is a one-time cost (~90MB download);
    #    subsequent starts use the cached binary. The download uses curl/wget
    #    (available on virtually all Linux systems). If the download fails,
    #    return None and the caller logs the error.
    #    v97.34 FIX: detect architecture (x64 vs arm64) instead of hard-coding
    #    linux-x64. Also, this function is called from _dashboard_live_start
    #    which is SYNC but called from async _post_init — the subprocess.run
    #    calls here block the event loop. The caller (_dashboard_live_start)
    #    is now wrapped in asyncio.to_thread by _post_init to avoid blocking.
    try:
        bun_dir = os.path.expanduser("~/.bun/bin")
        bun_path = os.path.join(bun_dir, "bun")
        if os.path.isfile(bun_path) and os.access(bun_path, os.X_OK):
            return bun_path
        # v97.34: detect architecture + platform.
        import platform as _plat
        _machine = _plat.machine().lower()
        _system = _plat.system().lower()
        if _system == "linux":
            if _machine in ("aarch64", "arm64"):
                _arch = "linux-arm64"
            elif _machine in ("x86_64", "amd64", "x64"):
                _arch = "linux-x64"
            else:
                logger.warning("DASHBOARD_LIVE_BUN_AUTO_INSTALL_SKIP — unsupported arch: %s", _machine)
                return None
        elif _system == "darwin":
            if _machine in ("aarch64", "arm64"):
                _arch = "darwin-arm64"
            elif _machine in ("x86_64", "amd64", "x64"):
                _arch = "darwin-x64"
            else:
                return None
        else:
            logger.warning("DASHBOARD_LIVE_BUN_AUTO_INSTALL_SKIP — unsupported OS: %s", _system)
            return None
        # Auto-install
        logger.info("DASHBOARD_LIVE_BUN_AUTO_INSTALL — bun not found, downloading %s to %s", _arch, bun_path)
        os.makedirs(bun_dir, exist_ok=True)
        import subprocess as _sp
        _url = f"https://github.com/oven-sh/bun/releases/latest/download/bun-{_arch}.zip"
        _zip_path = os.path.join(bun_dir, "bun.zip")
        _downloaded = False
        # v97.35: use Python urllib FIRST (always available, no external deps),
        # then fall back to curl/wget if urllib fails (e.g. SSL issues on old
        # Python builds). This fixes "no curl/wget" failures on minimal systems.
        try:
            import urllib.request as _ur
            import urllib.error as _ue
            logger.debug("BUN_AUTO_INSTALL downloading via Python urllib: %s", _url)
            _req = _ur.Request(_url, headers={"User-Agent": "mediagrab-bot/97.35"})
            # v98.07 FIX-SS sync-hazard sweep: this urlopen is a SYNC network
            # call (bun auto-installer — dashboard-live feature, install-time
            # only, NOT reachable from any VC path; grep-audited). Bounded
            # 120s → 30s so a stalled download cannot block the event loop
            # for two minutes if it ever runs while the loop is up.
            with _ur.urlopen(_req, timeout=30) as _resp:
                with open(_zip_path, "wb") as _f:
                    while True:
                        _chunk = _resp.read(65536)
                        if not _chunk:
                            break
                        _f.write(_chunk)
            _downloaded = os.path.isfile(_zip_path) and os.path.getsize(_zip_path) > 1000
        except Exception as exc:  # noqa: BLE001
            logger.debug("BUN_AUTO_INSTALL urllib failed: %s", exc)
        if not _downloaded and shutil.which("curl"):
            try:
                _sp.run(["curl", "-fsSL", "-o", _zip_path, _url],
                        check=True, timeout=120, capture_output=True)
                _downloaded = True
            except Exception as exc:  # noqa: BLE001
                logger.debug("BUN_AUTO_INSTALL curl failed: %s", exc)
        if not _downloaded and shutil.which("wget"):
            try:
                _sp.run(["wget", "-q", "-O", _zip_path, _url],
                        check=True, timeout=120, capture_output=True)
                _downloaded = True
            except Exception as exc:  # noqa: BLE001
                logger.debug("BUN_AUTO_INSTALL wget failed: %s", exc)
        if not _downloaded:
            logger.warning("DASHBOARD_LIVE_BUN_AUTO_INSTALL_FAILED — urllib+curl+wget all failed")
            return None
        # Unzip — try system unzip, then Python zipfile
        _extracted = None
        if shutil.which("unzip"):
            try:
                _sp.run(["unzip", "-o", _zip_path, "-d", bun_dir],
                        check=True, timeout=30, capture_output=True)
                _extracted = os.path.join(bun_dir, "bun")
            except Exception as exc:  # noqa: BLE001
                logger.debug("BUN_AUTO_INSTALL unzip failed: %s", exc)
        if _extracted is None or not os.path.isfile(_extracted):
            # Fallback: Python zipfile (always available)
            try:
                import zipfile as _zf
                with _zf.ZipFile(_zip_path) as zf:
                    zf.extractall(bun_dir)
                _extracted = os.path.join(bun_dir, "bun")
            except Exception as exc:  # noqa: BLE001
                logger.debug("BUN_AUTO_INSTALL python zipfile failed: %s", exc)
        # Cleanup zip
        try:
            os.unlink(_zip_path)
        except OSError:
            pass
        if _extracted and os.path.isfile(_extracted):
            os.chmod(_extracted, 0o755)
            logger.info("DASHBOARD_LIVE_BUN_AUTO_INSTALL_SUCCESS path=%s arch=%s", _extracted, _arch)
            return _extracted
        logger.warning("DASHBOARD_LIVE_BUN_AUTO_INSTALL_FAILED — could not extract bun")
    except Exception as exc:  # noqa: BLE001
        logger.warning("DASHBOARD_LIVE_BUN_AUTO_INSTALL_ERROR: %s", exc)
    return None


def _build_dashboard_live_env(bun_path: str) -> dict[str, str]:
    """Build the environment for the dashboard-live subprocess.

    The bot often runs with a sanitised PATH (venv-only); the spawned ``bun``
    process and its children (Next.js, node tooling) need a broader PATH that
    includes the directory containing bun plus standard system bins. We never
    shrink PATH — only prepend missing entries — so user configuration is
    preserved.
    """
    env = os.environ.copy()
    bun_dir = os.path.dirname(bun_path)
    extra_dirs = [
        bun_dir,
        "/usr/local/bin",
        "/usr/bin",
        "/bin",
        os.path.expanduser("~/.bun/bin"),
        os.path.expanduser("~/.local/bin"),
    ]
    current_path = env.get("PATH", os.defpath)
    parts = current_path.split(os.pathsep) if current_path else []
    seen = {p for p in parts if p}
    merged: list[str] = []
    for d in extra_dirs:
        if d and d not in seen:
            merged.append(d)
            seen.add(d)
    merged.extend(parts)
    env["PATH"] = os.pathsep.join(merged)
    return env


def _dashboard_live_start() -> None:
    """Spawn the dashboard-live WebSocket mini-service as a subprocess.

    v97.59 REWRITE: delegates to the DashboardLifecycleManager (single-flight,
    bounded auto-install, isolated, idempotent, configurable). The old
    implementation re-attempted urllib/curl/wget on EVERY startup when bun
    wasn't found, hammering the network. The new manager attempts auto-install
    AT MOST ONCE per process and persists a DISABLED state on failure.

    Per §1: dashboard failure must NOT destabilize the Telegram/VC runtime.
    This function NEVER raises — all failures are logged + persisted.
    """
    # v97.59: use the authoritative lifecycle manager.
    from .dashboard_lifecycle import get_dashboard_manager
    mgr = get_dashboard_manager(live_dir=_DASHBOARD_LIVE_DIR, port=_DASHBOARD_LIVE_PORT)
    # start() is async; _dashboard_live_start is sync (called from _post_init
    # via asyncio.to_thread). We can't await here, so schedule it as a task
    # if there's a running loop, else run synchronously.
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # Schedule as a task (fire-and-forget — failures are non-fatal).
            asyncio.create_task(mgr.start())
        else:
            asyncio.run(mgr.start())
    except RuntimeError:
        # No event loop — run synchronously.
        asyncio.run(mgr.start())
    # Mirror the proc into the legacy global for backward-compat inspection.
    global _dashboard_live_proc
    _dashboard_live_proc = mgr.proc


def _dashboard_live_stop() -> None:
    """Terminate the dashboard-live subprocess (on bot shutdown)."""
    # v97.59: delegate to the lifecycle manager (idempotent, bounded).
    from .dashboard_lifecycle import get_dashboard_manager
    mgr = get_dashboard_manager(live_dir=_DASHBOARD_LIVE_DIR, port=_DASHBOARD_LIVE_PORT)
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            asyncio.create_task(mgr.stop())
        else:
            asyncio.run(mgr.stop())
    except RuntimeError:
        try:
            asyncio.run(mgr.stop())
        except Exception:  # noqa: BLE001
            pass
    global _dashboard_live_proc
    _dashboard_live_proc = None


# ===========================================================================
# V43 Fix #6 — Secure Runtime Gemini Key Replacement
# ===========================================================================
# When an admin taps "🔑 Add New Gemini API Key", a private pending-input
# workflow starts. The admin sends the new key in a private chat; the bot
# validates it with a minimal bounded Gemini request, and if valid, atomically
# activates it at runtime. The key is NEVER logged, echoed, placed in callback
# data, exposed in diagnostics, or persisted to SQLite/JSON/YAML/.env.
#
# Security requirements:
# - private admin chat only (reject groups)
# - never log/echo the key
# - delete the submitted Telegram message where possible
# - validate with a minimal bounded Gemini request
# - invalid key must NOT replace the active key
# - valid key atomically activates + clears exhaustion state
# - support Cancel + timeout
# - securely discard pending state after success/failure/cancel/timeout
# - prevent the key message from reaching Talkative or other workflows
# - isolate concurrent admins

_gemini_key_pending: dict[int, dict[str, Any]] = {}
"""Per-admin pending Gemini key replacement state. Keys: admin_id. Values:
  chat_id: the private chat where the workflow started
  started_at: monotonic timestamp
  timeout_seconds: bounded workflow timeout (default 120s)
"""
_GEMINI_KEY_TIMEOUT = 120.0  # 2 minutes


def _gemini_key_pending_start(admin_id: int, chat_id: int) -> None:
    """Start a pending Gemini key replacement workflow for an admin."""
    _gemini_key_pending[admin_id] = {
        "chat_id": chat_id,
        "started_at": time.monotonic(),
        "timeout_seconds": _GEMINI_KEY_TIMEOUT,
    }


def _gemini_key_pending_active(admin_id: int) -> bool:
    """Check if an admin has a pending Gemini key replacement."""
    st = _gemini_key_pending.get(admin_id)
    if st is None:
        return False
    # Check timeout.
    if time.monotonic() - st["started_at"] > st["timeout_seconds"]:
        _gemini_key_pending.pop(admin_id, None)
        return False
    return True


def _gemini_key_pending_clear(admin_id: int) -> None:
    """Clear the pending Gemini key replacement state for an admin."""
    _gemini_key_pending.pop(admin_id, None)


_gemini_key_lock = asyncio.Lock()


async def _gemini_key_activate(candidate_key: str) -> tuple[bool, str]:
    """V45 Fix #1: truly atomic Gemini key activation with rollback.

    V85.5 FIX (RELI-G-009): the validation probe and post-activation health
    check both make outbound HTTP requests and can take 15-20s each. They are
    now performed OUTSIDE ``_gemini_key_lock`` so concurrent key-activation
    requests don't serialize behind each other. The lock is only held for
    the brief config-swap + cache-clear + state-update section, and is
    re-acquired if a rollback is needed after the health check fails.
    """
    global _gemini_client_cache
    # RELI-G-009: validate OUTSIDE the lock.
    valid, reason = await _gemini_key_validate(candidate_key)
    if not valid:
        return False, reason
    # RELI-G-009: capture previous state under the lock, swap the key,
    # and clear the client cache — this section is fast (no I/O).
    prev_key: str | None = None
    prev_client_cache = None
    prev_state: dict[str, Any] = {}
    key = candidate_key.strip()
    try:
        import google.genai  # noqa: F401
    except ImportError:
        pass
    async with _gemini_key_lock:
        prev_key = config.gemini_api_key
        try:
            prev_client_cache = _gemini_client_cache
        except NameError:
            prev_client_cache = None
        st = _provider_get_state("gemini")
        prev_state = dict(st)
        try:
            object.__setattr__(config, "gemini_api_key", key)
        except Exception as exc:
            del key
            return False, f"Runtime activation failed: {type(exc).__name__}"
        try:
            _gemini_client_cache = None
        except Exception:  # noqa: BLE001
            pass
    # RELI-G-009: post-activation health check OUTSIDE the lock.
    health_ok, health_reason = await _gemini_post_activation_health_check()
    if not health_ok:
        logger.error(
            "TALKATIVE_GEMINI_KEY_ACTIVATED_HEALTH_CHECK_FAILED (key redacted) reason=%s — rolling back",
            health_reason,
        )
        # Re-acquire the lock to roll back.
        async with _gemini_key_lock:
            try:
                object.__setattr__(config, "gemini_api_key", prev_key)
                _gemini_client_cache = prev_client_cache
            except Exception as rb_exc:
                logger.error("TALKATIVE_GEMINI_KEY_ROLLBACK_FAILED exc=%s", type(rb_exc).__name__)
            st = _provider_get_state("gemini")
            st.update(prev_state)
        del key
        return False, f"Post-activation health check failed: {health_reason}"
    # V61: clear exhaustion/cooldown state via the atomic success recorder.
    # Key activation + post-activation health check both succeeded, so
    # this is a genuine recovery signal. Record it as a real success.
    gen_before = _provider_current_generation("gemini")
    try:
        await _provider_record_success_async("gemini", gen_at_start=gen_before)
    except Exception:  # noqa: BLE001
        st = _provider_get_state("gemini")
        st["state"] = "healthy"
        st["failure_class"] = ""
        st["cooldown_until"] = 0.0
        st["cooldown_seconds"] = 0.0
        st["last_error"] = ""
    was_exhausted = (prev_state.get("state") == "resource_exhausted"
                     or prev_state.get("cooldown_until", 0) > 0)
    logger.info("TALKATIVE_GEMINI_KEY_ACTIVATED (key redacted) was_exhausted=%s", was_exhausted)
    del key
    return True, "ok"


# V45 Fix #2: supervised recovery notification with strong ref + dedup.
# V61: this legacy helper is retained as a backward-compat shim. The new
# V61 provider health subsystem uses generation-guarded notifications
# scheduled directly from _provider_record_success_async(). This shim is
# kept only so any external/dynamic caller still gets a safe no-op-ish
# behavior (it delegates to the generation-guarded notification, which
# will skip if the state is not healthy / not in a recovery notification).
_recovery_notify_tasks: set[asyncio.Task] = set()
_recovery_notify_dedup: dict[str, float] = {}
_RECOVERY_NOTIFY_DEDUP_WINDOW = 300.0


def _recovery_notify_supervised(provider: str) -> None:
    """V45 Fix #2 / V62 Fix #15: schedule a supervised recovery notification.

    V62: the authoritative recovery path is _provider_record_success_async →
    _provider_notify_admin_recovery (reservation + delivery). This shim
    cannot bypass that path — it must reserve a notification under lock
    first. If the provider is not healthy or no delivered failure alert
    exists for the current generation, the reservation is refused and no
    recovery DM is sent. There is exactly one authoritative recovery path.
    """
    now = time.monotonic()
    last = _recovery_notify_dedup.get(provider, 0.0)
    if now - last < _RECOVERY_NOTIFY_DEDUP_WINDOW:
        logger.debug("TALKATIVE_PROVIDER_RECOVERY_DEDUP provider=%s — suppressed", provider)
        return
    _recovery_notify_dedup[provider] = now
    try:
        async def _reserve_and_notify():
            token = None
            gen = 0
            async with _provider_lock(provider):
                st = _provider_get_state(provider)
                if st.get("state") != "healthy":
                    logger.info(
                        "RECOVERY_SHIM_SKIP provider=%s — state not healthy (state=%s)",
                        provider, st.get("state"),
                    )
                    return
                current_gen = int(st.get("generation", 0))
                delivered_type = st.get("last_delivered_notification_type", "")
                delivered_gen = int(st.get("last_delivered_notification_generation", -1))
                if delivered_type != "failure" or delivered_gen != current_gen:
                    logger.info(
                        "RECOVERY_SHIM_SKIP provider=%s — no delivered failure alert for gen=%d (delivered=%s gen=%d)",
                        provider, current_gen, delivered_type, delivered_gen,
                    )
                    return
                token = f"{provider}_shim_recv_{current_gen}_{int(time.monotonic() * 1000)}"
                gen = current_gen
                st["pending_notification_type"] = "recovery"
                st["pending_notification_generation"] = current_gen
                st["pending_notification_token"] = token
            if token:
                await _provider_notify_admin_recovery(provider, gen, token)

        task = supervised_create_task(
            _reserve_and_notify(),
            name=f"recovery_notify_{provider}",
        )
        _recovery_notify_tasks.add(task)

        def _on_done(t: asyncio.Task) -> None:
            _recovery_notify_tasks.discard(t)
            if t.cancelled():
                logger.info("TALKATIVE_PROVIDER_RECOVERY_CANCELLED provider=%s", provider)
                return
            exc = t.exception()
            if exc is not None:
                logger.error("TALKATIVE_PROVIDER_RECOVERY_TASK_FAILED provider=%s exc=%s: %s",
                             provider, type(exc).__name__, _sanitize_error(str(exc))[:100])

        task.add_done_callback(_on_done)
    except RuntimeError:
        pass


async def _gemini_post_activation_health_check() -> tuple[bool, str]:
    """V44 Fix #3: distinct bounded post-activation health check.

    Makes a real Gemini generation request with the activated key to confirm
    it works end-to-end (not just auth validation). Uses a bounded timeout.

    Returns (success, sanitized_reason). Never logs the key.
    """
    try:
        import httpx
        key = config.gemini_api_key
        if not key:
            return False, "No Gemini API key configured after activation"
        model = config.default_ai_model or "gemini-2.5-flash"  # v97.48: gemini-2.0-flash deprecated
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
        # Use a slightly larger payload than validation to confirm real generation.
        payload = {
            "contents": [{"parts": [{"text": "Say OK"}]}],
            "generationConfig": {"maxOutputTokens": 5},
        }
        async with httpx.AsyncClient(timeout=httpx.Timeout(20.0)) as client:
            resp = await client.post(url, json=payload)
        if resp.status_code == 200:
            return True, "ok"
        elif resp.status_code == 429:
            return False, "Post-activation request rate-limited (429)"
        elif resp.status_code == 403:
            return False, "Post-activation request forbidden (403)"
        else:
            return False, f"Post-activation request failed (HTTP {resp.status_code})"
    except Exception as exc:  # noqa: BLE001
        return False, f"Post-activation health check error: {type(exc).__name__}"


def _gemini_key_secure_delete(bot, chat_id: int, message_id: int) -> Any:
    """V43 Fix #6: attempt to delete the message containing the key.

    Returns a coroutine. Handle deletion failure safely (the message may
    already be deleted, or the bot may lack delete permission).
    """
    async def _do_delete():
        try:
            await bot.delete_message(chat_id=chat_id, message_id=message_id)
            return True
        except Exception:  # noqa: BLE001
            return False
    return _do_delete()


def _dm_diag_get(peer_id: int) -> dict[str, Any]:
    """Get the diagnostic state for a peer."""
    return dict(_dm_pipeline_diag.get(peer_id, {}))


def _dm_diag_snapshot() -> list[dict[str, Any]]:
    """Get a snapshot of all peer diagnostic states (sorted by recency)."""
    entries = list(_dm_pipeline_diag.values())
    entries.sort(key=lambda e: e.get("_ts", 0), reverse=True)
    return [dict(e) for e in entries[:10]]  # cap at 10 most recent


# V46 Fix: Group pipeline event-correlated diagnostic.
# Mirrors _dm_pipeline_diag but keyed by group chat_id.
# Stores bounded per-group stage state including trigger type + rejection reason.
# NEVER stores message content.
def _group_diag_snapshot() -> list[dict[str, Any]]:
    """Get a snapshot of all group diagnostic states (sorted by recency)."""
    entries = list(_group_pipeline_diag.values())
    entries.sort(key=lambda e: e.get("_ts", 0), reverse=True)
    return [dict(e) for e in entries[:10]]


# V58 Fix: human-readable diagnostic formatting.
_TERMINAL_HUMAN = {
    "send_success": "✅ Reply sent successfully",
    "send_failed": "❌ Failed to send reply",
    "send_forbidden": "🔒 Bot doesn't have permission to send in this chat",
    "send_admin_required": "🔒 Admin privileges required to send in this chat",
    "send_banned": "🚫 Bot is banned in this chat",
    "engagement_rejected": "⏭ Skipped: message didn't meet the reply threshold",
    "engagement_scoring_error": "⚠️ Error calculating engagement score",
    "cooldown": "⏳ On cooldown — please wait",
    "global_rpm": "⏳ Rate limit reached — please wait",
    "spam_budget": "⏭ Skipped: anti-spam limit reached",
    "consecutive_bot_limit": "⏭ Skipped: too many consecutive bot replies",
    "duplicate_claim": "⏭ Skipped: already processing this message",
    "duplicate_reply": "⏭ Skipped: duplicate reply",
    "stale_cancelled": "⏭ Cancelled: a newer message arrived",
    "provider_unavailable": "⚠️ AI provider temporarily unavailable",
    "generation_failed": "⚠️ AI generation failed",
    "empty_transcript": "⚠️ AI returned an empty response",
    "global_disabled": "⏭ Talkative is globally disabled",
    "workflow_pending": "⏭ Skipped: pending workflow in progress",
    "chat_mode_off": "⏭ Talkative is off in this chat",
    "chat_disabled": "⏭ Talkative is disabled in this chat",
    "settings_error": "⚠️ Error loading chat settings",
    "group_trigger_rejected": "⏭ Skipped: no trigger (mention/reply/wake word)",
    "no_trigger_dm": "⚠️ Unexpected: no trigger in DM",
    "voice_enrollment_consumed": "🗣 Voice enrollment sample processed",
}


def _format_terminal_human(terminal: str) -> str:
    """Convert internal terminal reason to human-readable text."""
    return _TERMINAL_HUMAN.get(terminal, f"⚠️ {terminal}")


def _format_engagement_human(eng_data: Any) -> str:
    """Format engagement diagnostic for human display."""
    if not isinstance(eng_data, dict):
        return str(eng_data)
    score = eng_data.get("score", "?")
    threshold = eng_data.get("threshold", 0.5)
    rejected = eng_data.get("rejected", False)
    reason = eng_data.get("reason", "")
    pct = int(score * 100) if isinstance(score, (int, float)) else "?"
    thr_pct = int(threshold * 100) if isinstance(threshold, (int, float)) else 50
    if rejected:
        return f"Engagement: {pct}% — needs {thr_pct}% to reply ({reason})"
    return f"Engagement: {pct}% (threshold: {thr_pct}%)"


def _format_provider_human(prov_data: Any) -> str:
    """Format provider diagnostic for human display."""
    if not isinstance(prov_data, dict):
        return str(prov_data)
    ready = prov_data.get("ready", False)
    name = prov_data.get("name", "?")
    if ready:
        return f"Provider: {name} ✅"
    reason = prov_data.get("reason", "")
    return f"Provider: {name} ❌ {reason}"


def _format_gen_human(gen_data: Any) -> str:
    """Format generation result for human display."""
    if not isinstance(gen_data, dict):
        return str(gen_data)
    success = gen_data.get("success", False)
    if success:
        return "AI response generated ✅"
    error = gen_data.get("error", "unknown")
    return f"AI generation failed ❌ ({error})"


def _format_send_human(send_data: Any) -> str:
    """Format send result for human display."""
    if not isinstance(send_data, dict):
        if send_data == "—" or not send_data:
            return "Not sent"
        return str(send_data)
    success = send_data.get("success", False)
    if success:
        return "Reply sent ✅"
    error = send_data.get("error", "unknown")
    return f"Send failed ❌ ({error})"


def _format_diag_entry_human(entry: dict, is_private: bool = True) -> list[str]:
    """Format a complete diagnostic entry as human-readable lines."""
    peer = entry.get("peer_id" if is_private else "chat_id", "?")
    seen = "✅" if entry.get("private_event_seen" if is_private else "event_seen") else "❌"
    media = entry.get("media_type", "")
    mode = entry.get("effective_chat_mode", "—")
    trigger = entry.get("trigger", {})
    if isinstance(trigger, dict):
        trig_type = trigger.get("type", "—")
    else:
        trig_type = str(trigger)
    cd = entry.get("cooldown", {})
    if isinstance(cd, dict):
        cd_str = f"{cd.get('remaining', 0)}s" if not cd.get("allowed", True) else "ok"
    else:
        cd_str = str(cd)
    eng = _format_engagement_human(entry.get("engagement", "—"))
    prov = _format_provider_human(entry.get("provider", "—"))
    gen = _format_gen_human(entry.get("generation_result", "—"))
    stale = entry.get("stale_check", {})
    if isinstance(stale, dict):
        stale_str = "cancelled (newer message)" if stale.get("stale") else "ok"
    else:
        stale_str = str(stale)
    send = _format_send_human(entry.get("send_result", "—"))
    terminal = _format_terminal_human(entry.get("terminal_reason", "—"))

    label = "DM" if is_private else "Group"
    lines = [
        f"\n{label} `{peer}` (seen={seen}){' [' + media + ']' if media else ''}",
        f"  Mode: {mode} | Trigger: {trig_type} | Cooldown: {cd_str}",
        f"  {eng}",
        f"  {prov}",
        f"  {gen}",
        f"  Stale: {stale_str}",
        f"  {send}",
        f"  → {terminal}",
    ]
    return lines


async def download__enter_forward_mode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await states.set_state(update.effective_user.id, states.AWAIT_DOWNLOAD_FORWARD)
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.DOWNLOAD_FORWARD_PROMPT,
        reply_markup=kb.cancel_back("dl"),
        parse_mode="Markdown",
    )


async def download__handle_forwarded_media(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.message
    user_id = update.effective_user.id
    media_type = telegram_media_type(message)

    if media_type is None:
        await message.reply_text(
            "⚠️ That message has no downloadable media.\n"
            "Please forward a message containing a video, document, photo, "
            "audio, voice, sticker, GIF or video note.",
        )
        return

    approx = download__approx_size(message)
    if approx and approx > config.download_limit_bytes:
        await message.reply_text(
            msg.file_too_big_text(config.max_file_size_mb),
            parse_mode="Markdown",
            reply_markup=kb.download_menu(),
        )
        return

    count_used, bytes_used = await repo.user_daily_download_usage(user_id)
    if (count_used >= config.user_daily_download_limit
            or bytes_used + approx > config.user_daily_download_bytes):
        await message.reply_text(
            msg.quota_exceeded_text(config.user_daily_download_limit,
                                    config.user_daily_download_bytes_mb),
            parse_mode="Markdown",
            reply_markup=kb.main_menu(),
        )
        return

    status = await message.reply_text(
        msg.progress_text("📥 Downloading", 0.0, 0, 1),
        reply_markup=kb.cancel_back("dl"),
        parse_mode="Markdown",
    )
    editor = _DownloadProgressEditor(context, status.chat_id, status.message_id, "📥 Downloading")

    task_id = await repo.create_task(user_id, "download", "running")
    supervised_create_task(
        download__run_forward_download(user_id, task_id, message, context, editor, media_type),
        name="download_forward",
    )


async def download__run_forward_download(
    user_id: int, task_id: int, message, context, editor, media_type: str,
) -> None:
    path: Path | None = None
    file_unique_id = download__file_unique_id(message)
    try:
        async with download_slot():
            path, name, mtype, size = await downloader.download_forwarded(
                message,
                progress=editor.callback,
                bot=context.bot,
            )
        await editor.finish()
        await repo.update_task(task_id, status="done", progress=100)

        upload_editor = _DownloadProgressEditor(
            context, editor.chat_id, None, "📤 Uploading", new_message=True
        )
        caption = msg.download_done_text(name, size, mtype)
        result = await send_file_back(
            editor.chat_id, path, caption, context,
            progress_cb=upload_editor.callback,
        )
        await upload_editor.finish()

        if result == "too_large":
            await context.bot.send_message(
                chat_id=editor.chat_id,
                text=(
                    "ℹ️ The downloaded file is larger than 50 MB, which is the "
                    "maximum a bot can send back through the official Bot API."
                ),
                reply_markup=kb.main_menu(),
            )
        elif result.startswith("error"):
            await context.bot.send_message(
                chat_id=editor.chat_id,
                text=f"⚠️ Could not send the file back: `{result[6:]}`",
                parse_mode="Markdown",
                reply_markup=kb.main_menu(),
            )

        await repo.add_download_history(
            user_id, file_name=name, file_size=size,
            mime_type=None, media_type=mtype, source="forward",
            status="done", task_id=task_id, file_unique_id=file_unique_id,
        )

        await states.set_last_download(user_id, {
            "file_name": name,
            "media_type": mtype,
            "file_size": size,
            "file_id": download__file_id(message),
        })

        if result == "ok":
            try:
                await context.bot.send_message(
                    chat_id=editor.chat_id,
                    text="💾 *Tip:* tap below to bookmark this file to your Library.",
                    parse_mode="Markdown",
                    reply_markup=kb.download_done_keyboard(),
                )
            except Exception:  # noqa: BLE001
                pass

        settings = await repo.ensure_settings(user_id)
        if settings.get("auto_delete"):
            await remove_path(path)

    except downloader.FileTooLarge as exc:
        await editor.error(msg.file_too_big_text(config.max_file_size_mb))
        await repo.update_task(task_id, status="failed", error=str(exc))
        await repo.add_download_history(
            user_id, file_name="(too large)", file_size=0,
            mime_type=None, media_type=media_type, source="forward",
            status="failed", task_id=task_id, file_unique_id=file_unique_id,
        )
    except Exception as exc:  # noqa: BLE001
        logger.exception("forward download failed: %s", exc)
        await editor.error(msg.download_failed_text(str(exc)))
        await repo.update_task(task_id, status="failed", error=str(exc))
        await repo.add_download_history(
            user_id, file_name="(failed)", file_size=0,
            mime_type=None, media_type=media_type, source="forward",
            status="failed", task_id=task_id, file_unique_id=file_unique_id,
        )
    finally:
        if path and path.exists():
            try:
                await remove_path(path)
            except Exception:  # noqa: BLE001
                pass


class _DownloadProgressEditor:
    """Throttled editor for a status message showing a progress bar."""

    def __init__(self, context, chat_id: int, message_id: int | None,
                 label: str, *, new_message: bool = False):
        self.context = context
        self.chat_id = chat_id
        self.message_id = message_id
        self.label = label
        self.new_message = new_message
        self._last_ts = 0.0
        self._last_pct = -100.0
        self._finished = False

    async def callback(self, percent: float, received: int, total: int,
                       speed: str = "") -> None:
        if self._finished:
            return
        now = time.monotonic()
        if (now - self._last_ts) < 1.0 and (percent - self._last_pct) < 5.0 \
                and percent < 99.0:
            return
        self._last_ts = now
        self._last_pct = percent
        text = msg.progress_text(self.label, percent, received, total, speed)
        try:
            if self.new_message or self.message_id is None:
                sent = await self.context.bot.send_message(
                    chat_id=self.chat_id, text=text, parse_mode="Markdown"
                )
                self.message_id = sent.message_id
                self.new_message = False
            else:
                await self.context.bot.edit_message_text(
                    chat_id=self.chat_id, message_id=self.message_id,
                    text=text, parse_mode="Markdown",
                )
        except RetryAfter as exc:  # TG-H-003: respect server wait, capped.
            await asyncio.sleep(min(exc.retry_after + 1, 30))
        except Exception as exc:  # noqa: BLE001 — "not modified", rate limits
            logger.debug("progress edit skipped: %s", exc)

    async def finish(self) -> None:
        self._finished = True

    async def error(self, text: str) -> None:
        self._finished = True
        try:
            if self.message_id is not None:
                await self.context.bot.edit_message_text(
                    chat_id=self.chat_id, message_id=self.message_id,
                    text=text, parse_mode="Markdown",
                    reply_markup=kb.download_menu(),
                )
            else:
                await self.context.bot.send_message(
                    chat_id=self.chat_id, text=text, parse_mode="Markdown",
                    reply_markup=kb.download_menu(),
                )
        except Exception as exc:  # noqa: BLE001
            logger.debug("error edit failed: %s", exc)


def download__approx_size(message) -> int:
    for cand in (message.document, message.video, message.audio,
                 message.animation, message.voice, message.video_note):
        if cand is not None and getattr(cand, "file_size", None):
            return int(cand.file_size)
    if message.photo:
        return int(message.photo[-1].file_size or 0)
    return 0


def download__file_unique_id(message) -> str | None:
    for cand in (message.document, message.video, message.audio,
                 message.animation, message.voice, message.video_note):
        if cand is not None and getattr(cand, "file_unique_id", None):
            return cand.file_unique_id
    if message.photo:
        return message.photo[-1].file_unique_id
    return None


def download__file_id(message) -> str | None:
    """The Bot API file_id of the forwarded media (for Library bookmarks)."""
    for cand in (message.document, message.video, message.audio,
                 message.animation, message.voice, message.video_note):
        if cand is not None and getattr(cand, "file_id", None):
            return cand.file_id
    if message.photo:
        return message.photo[-1].file_id
    return None


# ===========================================================================
# Handlers — analyze
# ===========================================================================


def analyze__approx_video_size(message) -> int:
    for cand in (message.video, message.animation, message.video_note,
                 message.document, message.audio, message.voice):
        if cand is not None and getattr(cand, "file_size", None):
            return int(cand.file_size)
    if message.photo:
        return int(message.photo[-1].file_size or 0)
    return 0


async def analyze__enter_analyze_mode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await states.set_state(update.effective_user.id, states.AWAIT_ANALYZE)
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.ANALYZE_FORWARD_PROMPT,
        reply_markup=kb.cancel_back("ai"),
        parse_mode="Markdown",
    )


async def analyze__show_modes(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    s = await repo.ensure_settings(update.effective_user.id)
    current = s.get("ai_mode", "movie")
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.AI_MODES_TEXT,
        reply_markup=kb.ai_modes_menu(current),
        parse_mode="Markdown",
    )


async def analyze__set_mode(update: Update, context: ContextTypes.DEFAULT_TYPE,
                            mode: str) -> None:
    if mode not in ai_modes.MODE_ORDER:
        await update.callback_query.answer("Unknown mode.")
        return
    await repo.update_setting(update.effective_user.id, "ai_mode", mode)
    await update.callback_query.answer(f"Mode: {MODE_LABELS.get(mode, mode)}")
    await update.callback_query.edit_message_text(
        text=msg.ai_mode_set_text(MODE_LABELS.get(mode, mode)),
        reply_markup=kb.ai_modes_menu(mode),
        parse_mode="Markdown",
    )


async def analyze__handle_forwarded_video(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.message
    user_id = update.effective_user.id
    settings = await repo.ensure_settings(user_id)
    mode = settings.get("ai_mode", "movie")
    media_type = telegram_media_type(message)

    ptb_kind = analyze__ptb_kind(media_type)
    if ptb_kind is None or not ai_modes.accepts(mode, ptb_kind):
        await message.reply_text(
            f"⚠️ The *{MODE_LABELS.get(mode, mode)}* mode needs "
            f"{analyze__accepted_kinds_text(mode)}. You sent a *{media_type}*.",
            parse_mode="Markdown",
            reply_markup=kb.analyze_menu(),
        )
        return

    approx = analyze__approx_video_size(message)
    if approx and approx > config.download_limit_bytes:
        await message.reply_text(
            msg.file_too_big_text(config.max_file_size_mb),
            parse_mode="Markdown",
            reply_markup=kb.analyze_menu(),
        )
        return

    status = await message.reply_text(
        f"🎬 Starting *{mode}* analysis…",
        reply_markup=kb.cancel_back("ai"),
        parse_mode="Markdown",
    )
    task_id = await repo.create_task(user_id, "analyze", "running")
    supervised_create_task(
        analyze__run_analysis(user_id, task_id, message, context,
                              status.chat_id, status.message_id, media_type, mode, settings),
        name="analyze_run",
    )


async def analyze__run_analysis(
    user_id: int, task_id: int, message, context,
    chat_id: int, status_msg_id: int, media_type: str, mode: str,
    settings: dict,
) -> None:
    src_path: Path | None = None
    frames: list[Path] = []
    try:
        ai_model = settings.get("ai_model", config.default_ai_model)
        user_key = settings.get("gemini_api_key") or None
        lang = settings.get("language")

        await analyze__edit_status(context, chat_id, status_msg_id,
                                   "📥 Downloading media for analysis…")
        async with download_slot():
            src_path, name, mtype, size = await downloader.download_forwarded(
                message, progress=None, bot=context.bot
            )

        kind = ai_modes.media_kind_for(src_path)
        await analyze__edit_status(context, chat_id, status_msg_id,
                                   f"🧠 Running *{mode}* with `{ai_model}`…")

        if mode == "transcribe" and kind == "audio":
            result = await ai_analyzer.analyze_audio(
                src_path, model=ai_model, mode=mode,
                user_api_key=user_key, target_language=lang,
            )
        elif mode == "movie" and kind == "video":
            await analyze__edit_status(context, chat_id, status_msg_id,
                                       f"🎞️ Extracting {config.num_frames} frames…")
            frames = await frame_extractor.extract_frames(src_path)
            result = await ai_analyzer.analyze_frames(
                frames, model=ai_model, mode=mode,
                user_api_key=user_key, target_language=lang,
            )
        elif mode in ("ocr", "describe", "translate") and kind == "image":
            result = await ai_analyzer.analyze_images(
                [src_path], model=ai_model, mode=mode,
                user_api_key=user_key, target_language=lang,
            )
        elif mode in ("ocr", "describe", "translate", "movie") and kind == "video":
            await analyze__edit_status(context, chat_id, status_msg_id,
                                       f"🎞️ Extracting {config.num_frames} frames…")
            frames = await frame_extractor.extract_frames(src_path)
            result = await ai_analyzer.analyze_frames(
                frames, model=ai_model, mode=mode,
                user_api_key=user_key, target_language=lang,
            )
        else:
            raise RuntimeError(
                f"Mode {mode} cannot process media kind {kind}."
            )

        text = ai_modes.render_result(mode, result)
        await analyze__edit_status(context, chat_id, status_msg_id, text,
                                   reply_markup=kb.main_menu())
        await repo.update_task(task_id, status="done", progress=100)
        await repo.add_ai_history(
            user_id, file_name=name, media_type=mtype,
            result=analyze__to_history(result, mode), status="done", task_id=task_id,
        )

    except downloader.FileTooLarge as exc:
        await analyze__edit_status(context, chat_id, status_msg_id,
                                   msg.file_too_big_text(config.max_file_size_mb),
                                   reply_markup=kb.analyze_menu())
        await repo.update_task(task_id, status="failed", error=str(exc))
        await repo.add_ai_history(
            user_id, file_name="(too large)", media_type=media_type,
            result=None, status="failed", task_id=task_id,
        )
    except Exception as exc:  # noqa: BLE001
        logger.exception("analysis failed: %s", exc)
        await analyze__edit_status(context, chat_id, status_msg_id,
                                   msg.analyze_failed_text(str(exc)),
                                   reply_markup=kb.analyze_menu())
        await repo.update_task(task_id, status="failed", error=str(exc))
        await repo.add_ai_history(
            user_id, file_name="(failed)", media_type=media_type,
            result=None, status="failed", task_id=task_id,
        )
    finally:
        for f in frames:
            await remove_path(f)
        if src_path and src_path.exists():
            await remove_path(src_path)


def analyze__ptb_kind(media_type: str | None) -> str | None:
    """Map PTB media type to the ai_modes media kind."""
    if media_type in ("video", "gif", "video_note"):
        return "video"
    if media_type in ("audio", "voice"):
        return "audio"
    if media_type in ("photo", "sticker"):
        return "image"
    if media_type == "document":
        return "other"
    return None


def analyze__accepted_kinds_text(mode: str) -> str:
    kinds = ai_modes.ACCEPTS.get(mode, set())
    return " or ".join(kinds) or "media"


def analyze__to_history(result: dict, mode: str) -> dict:
    """Adapt a mode result to the ai_history schema (category/title/etc)."""
    if mode == "movie":
        return result
    return {
        "category": mode.title(),
        "title": (result.get("summary") or result.get("text")
                  or result.get("details") or result.get("translated_text")
                  or "")[:200],
        "confidence": result.get("confidence", 0.0),
    }


async def analyze__edit_status(context, chat_id: int, message_id: int, text: str,
                               reply_markup=None) -> None:
    try:
        await context.bot.edit_message_text(
            chat_id=chat_id, message_id=message_id,
            text=text, parse_mode="Markdown", reply_markup=reply_markup,
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("status edit skipped: %s", exc)


# ===========================================================================
# Handlers — history
# ===========================================================================


async def history__show_downloads(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.callback_query.answer()
    rows = await repo.recent_downloads(update.effective_user.id, limit=10)
    text = msg.render_history_rows(rows, "📥 Recent Downloads")
    await update.callback_query.edit_message_text(
        text=text, reply_markup=kb.history_back(), parse_mode="Markdown",
    )


async def history__show_ai(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.callback_query.answer()
    rows = await repo.recent_ai_analyses(update.effective_user.id, limit=10)
    text = msg.render_history_rows(rows, "🤖 Recent AI Analyses")
    await update.callback_query.edit_message_text(
        text=text, reply_markup=kb.history_back(), parse_mode="Markdown",
    )


async def history__clear(update: Update, context: ContextTypes.DEFAULT_TYPE,
                         data: str) -> None:
    await update.callback_query.answer()
    kind = data.split(":")[-1] if ":" in data else None  # dl|ai|all
    if kind == "dl":
        await repo.clear_history(update.effective_user.id, "download")
        text = "🧹 *Download history cleared.*"
    elif kind == "ai":
        await repo.clear_history(update.effective_user.id, "ai")
        text = "🧹 *AI analysis history cleared.*"
    elif kind == "all":  # TG-H-004: only clear everything on explicit "all".
        await repo.clear_history(update.effective_user.id, None)
        text = "🧹 *All history cleared.*"
    else:
        # Unknown kind — don't wipe the user's history.
        await update.callback_query.answer(
            "⚠️ Unknown clear action — history not modified.",
            show_alert=True,
        )
        return
    logger.info("history cleared for %s (kind=%s)", update.effective_user.id, kind)
    await update.callback_query.edit_message_text(
        text=text, reply_markup=kb.history_menu(), parse_mode="Markdown",
    )


# ===========================================================================
# Handlers — settings
# ===========================================================================

_SETTINGS_QUALITIES = QUALITIES
_SETTINGS_MODELS = AI_MODELS
_SETTINGS_LANGUAGES = LANGUAGES


def _settings_cycle(current, options):
    try:
        idx = options.index(current)
    except ValueError:
        idx = -1
    return options[(idx + 1) % len(options)]


async def settings__handle_setting(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                   data: str) -> None:
    key = data.split(":", 1)[1]
    user_id = update.effective_user.id
    settings = await repo.ensure_settings(user_id)

    if key == "q":
        new_val = _settings_cycle(settings.get("preferred_quality"), _SETTINGS_QUALITIES)
        settings = await repo.update_setting(user_id, "preferred_quality", new_val)
        toast = f"Quality → {new_val}"
    elif key == "m":
        new_val = _settings_cycle(settings.get("ai_model"), _SETTINGS_MODELS)
        settings = await repo.update_setting(user_id, "ai_model", new_val)
        toast = f"AI Model → {new_val}"
    elif key == "l":
        new_val = _settings_cycle(settings.get("language"), _SETTINGS_LANGUAGES)
        settings = await repo.update_setting(user_id, "language", new_val)
        toast = f"Language → {new_val}"
    elif key == "ad":
        new_val = 0 if settings.get("auto_delete") else 1
        settings = await repo.update_setting(user_id, "auto_delete", new_val)
        toast = f"Auto Delete → {'On' if new_val else 'Off'}"
    elif key == "n":
        new_val = 0 if settings.get("notifications") else 1
        settings = await repo.update_setting(user_id, "notifications", new_val)
        toast = f"Notifications → {'On' if new_val else 'Off'}"
    elif key == "am":
        current = settings.get("ai_mode", "movie")
        new_val = _settings_cycle(current, ai_modes.MODE_ORDER)
        settings = await repo.update_setting(user_id, "ai_mode", new_val)
        toast = f"AI Mode → {ai_modes.MODE_LABELS.get(new_val, new_val)}"
    elif key == "key":
        await states.set_state(user_id, "await_gemini_key")
        await update.callback_query.answer("Send your Gemini API key now.")
        await update.callback_query.edit_message_text(
            text=(
                "🔑 *Set your Gemini API key*\n\n"
                "Send your key as the next message. Get one at "
                "https://aistudio.google.com/app/apikey\n\n"
                "Your key is stored locally and used only for your AI requests. "
                "Send `clear` to remove it and use the shared key."
            ),
            reply_markup=kb.cancel_back("set"),
            parse_mode="Markdown",
        )
        return
    else:
        toast = "Unknown setting"

    try:
        await update.callback_query.answer(toast)
    except Exception:  # noqa: BLE001
        pass
    try:
        await update.callback_query.edit_message_text(
            text=msg.settings_text(settings),
            reply_markup=kb.settings_menu(),
            parse_mode="Markdown",
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("settings edit skipped: %s", exc)


async def settings__handle_gemini_key_input(update: Update,
                                            context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    text = (update.message.text or "").strip()
    if not text:
        await update.message.reply_text("⚠️ Please send your API key.")
        return
    await states.reset(user_id)
    if text.lower() == "clear":
        await repo.update_setting(user_id, "gemini_api_key", None)
        await update.message.reply_text(
            "✅ Your personal Gemini key was removed. The bot will use the "
            "shared key (if configured).",
            reply_markup=kb.settings_back(),
        )
        return
    # V85.3 FIX BUG A2: do NOT reject based on the "AIza" prefix — Google
    # has rotated Gemini key formats and a valid key may use a different
    # prefix.  Run the authoritative bounded API probe instead; accept the
    # key only if the probe confirms it works.
    valid, reason = await _gemini_key_validate(text)
    if not valid:
        await update.message.reply_text(
            f"⚠️ That Gemini API key could not be validated ({reason}). "
            "Try again or send `clear`.",
            parse_mode="Markdown",
            reply_markup=kb.settings_back(),
        )
        return
    await repo.update_setting(user_id, "gemini_api_key", text)
    await update.message.reply_text(
        "✅ Your Gemini API key has been validated and saved. Future AI requests will use it.",
        reply_markup=kb.settings_back(),
    )


# ===========================================================================
# Handlers — help
# ===========================================================================

_HELP_SECTIONS = {
    "hp:dl": HELP_DOWNLOAD,
    "hp:ai": HELP_AI.format(n=config.num_frames),
    "hp:feat": HELP_FEATURES,
    "hp:fmt": HELP_FORMATS,
    "hp:faq": HELP_FAQ,
}


async def help__show_section(update: Update, context: ContextTypes.DEFAULT_TYPE,
                             data: str) -> None:
    await update.callback_query.answer()
    text = _HELP_SECTIONS.get(data, HELP_MENU_TEXT)
    await update.callback_query.edit_message_text(
        text=text, reply_markup=kb.help_back(), parse_mode="Markdown",
    )


# ════════════════════════════════════════════════════════════════════════════
# Handlers — multimodal (V86 upgrade)
# ════════════════════════════════════════════════════════════════════════════
"""Multimodal message handler: processes voice, photo, video, audio, document,
sticker, gif, and animation messages through the unified routing pipeline.

Registered at group=-1 (highest priority, before Talkative and other handlers)
so multimodal inputs are captured before falling through to text-only handlers.
Only activates when config.multimodal_enabled is True.
"""

_MULTIMODAL_HANDLER_REGISTERED: bool = False
_USERNAME_RE = re.compile(r"@([A-Za-z0-9_]{5,})")
_LINK_RE = re.compile(
    r"https?://t(?:elegram)?\.me/([A-Za-z0-9_]{5,})(?:/\d+)?", re.IGNORECASE
)

# SEC-H-003: per-user inspector rate-limit window (monotonic timestamps).
_inspector_rate: dict[int, list[float]] = {}


async def inspector__enter_inspect_mode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await states.set_state(update.effective_user.id, states.AWAIT_INSPECT)
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.INSPECTOR_PROMPT,
        reply_markup=kb.cancel_back("ins"),
        parse_mode="Markdown",
    )


async def inspector__show_recent(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.callback_query.answer()
    rows = await repo.recent_inspected(update.effective_user.id, limit=10)
    if not rows:
        text = "🕘 *Recent Inspections*\n\nNo inspections yet."
    else:
        lines = ["🕘 *Recent Inspections*", ""]
        for r in rows:
            date = (r.get("created_at") or "")[:16].replace("T", " ")
            name = r.get("title") or r.get("first_name") or "—"
            uname = f"@{r['username']}" if r.get("username") else "—"
            kind = r.get("chat_type") or "—"
            members = r.get("members")
            ms = f"{members:,}" if members else "—"
            lines.append(f"• `{date}` {name}\n   {uname} · {kind} · 👥 {ms}")
        text = "\n".join(lines)
    await update.callback_query.edit_message_text(
        text=text, reply_markup=kb.inspector_back(), parse_mode="Markdown",
    )


async def inspector__handle_inspect_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    raw = (update.message.text or update.message.caption or "").strip()
    user_id = update.effective_user.id
    if not raw:
        await safe_reply_text(update.message, msg.INSPECTOR_EMPTY)
        return

    # SEC-H-003: per-user rate limit — max 5 inspector lookups per 60s.
    now = time.monotonic()
    window = _inspector_rate.setdefault(user_id, [])
    # Drop entries older than 60s.
    window[:] = [ts for ts in window if now - ts < 60.0]
    # V95 FIX: prune empty lists so the dict doesn't grow unbounded.
    if not window:
        _inspector_rate.pop(user_id, None)
    if len(window) >= 5:
        await safe_reply_text(
            update.message,
            "⏳ Too many lookups — please wait a minute and try again.",
        )
        return
    window.append(now)

    username = inspector__extract_username(raw)
    if not username:
        await safe_reply_text(update.message, msg.INSPECTOR_EMPTY)
        return

    status = await safe_reply_text(
        update.message, f"\U0001f50d Looking up @{md_escape(username)}\u2026"
    )
    if status is None:
        return

    # Try getChat with smart retries (no retry on permanent errors).
    chat, error_reason = await _inspector_get_chat_smart(context, f"@{username}")
    if chat is None:
        await safe_edit_message_text(
            context.bot, status.chat_id, status.message_id,
            msg.inspect_failed_text(md_escape(error_reason)),
            reply_markup=kb.inspector_back(),
        )
        return

    info = inspector__chat_to_info(chat)
    # Escape all dynamic string values before rendering as Markdown.
    info = _inspector_escape_info(info)
    await repo.add_inspected_chat(
        user_id,
        chat_id=info.get("chat_id"),
        username=info.get("username"),
        title=info.get("title"),
        chat_type=info.get("type"),
        members=info.get("members"),
        description=info.get("description"),
        first_name=info.get("first_name"),
        last_name=info.get("last_name"),
        bio=info.get("bio"),
        is_bot=info.get("is_bot"),
    )
    await safe_edit_message_text(
        context.bot, status.chat_id, status.message_id,
        msg.inspect_result_text(info),
        reply_markup=kb.inspector_back(),
    )


async def _inspector_get_chat_smart(context, chat_ref) -> tuple[object | None, str]:
    """Resolve a chat via getChat with smart retries.

    Retries ONLY on transient errors (RetryAfter, NetworkError, TimedOut).
    Permanent errors (BadRequest \"not found\", Forbidden) fail immediately.
    Returns ``(chat, error_reason)`` — on success error_reason is \"\".
    """
    max_retries = 3
    base_delay = 2.0
    last_exc: Exception | None = None
    retry_after_seen = False  # TG-H-013: only retry once on RetryAfter.

    for attempt in range(1, max_retries + 1):
        try:
            chat = await context.bot.get_chat(chat_ref)
            return chat, ""
        except RetryAfter as exc:
            wait = min(exc.retry_after + 1, 60)  # TG-H-002: cap wait at 60s.
            logger.info("Rate limited on getChat: %ss (attempt %d/%d)",
                        exc.retry_after, attempt, max_retries)
            if retry_after_seen:
                # TG-H-013: don't retry more than once on RetryAfter.
                return None, f"Rate limited after retry: {exc}"
            retry_after_seen = True
            await asyncio.sleep(wait)
            last_exc = exc
            continue
        except BadRequest as exc:
            # Permanent — don't retry.
            msg_text = str(exc).lower()
            logger.info("get_chat failed for %s: %s", chat_ref, exc)
            if "chat not found" in msg_text:
                return None, (
                    f"Chat {chat_ref} was not found.\n\n"
                    "Possible reasons:\n"
                    "\u2022 The username doesn't exist or was changed\n"
                    "\u2022 The chat is private and not accessible to bots\n"
                    "\u2022 The username belongs to a deleted account\n"
                    "\u2022 You typed the username incorrectly"
                )
            return None, f"Telegram rejected the lookup: {exc}"
        except Forbidden as exc:
            logger.info("get_chat forbidden for %s: %s", chat_ref, exc)
            return None, (
                f"The bot doesn't have permission to access {chat_ref}. "
                "Private chats require the bot to be a member."
            )
        except (NetworkError, TimedOut) as exc:
            last_exc = exc
            if attempt < max_retries:
                delay = min(base_delay * (2 ** (attempt - 1)), 30.0)
                logger.info("Network error on getChat (attempt %d/%d), "
                            "retrying in %.1fs: %s", attempt, max_retries, delay, exc)
                await asyncio.sleep(delay)
                continue
            return None, f"Network error after {max_retries} retries: {exc}"
        except Exception as exc:  # noqa: BLE001
            logger.exception("get_chat unexpected error for %s: %s", chat_ref, exc)
            return None, f"Unexpected error: {exc}"

    return None, f"Request failed after {max_retries} retries: {last_exc}"


def inspector__extract_username(text: str) -> str | None:
    m = _USERNAME_RE.search(text)
    if m:
        return m.group(1)
    m = _LINK_RE.search(text)
    if m:
        return m.group(1)
    bare = text.strip().lstrip("@")
    if re.fullmatch(r"[A-Za-z0-9_]{5,}", bare):
        return bare
    return None


def inspector__chat_to_info(chat) -> dict[str, Any]:
    info: dict[str, Any] = {}
    info["chat_id"] = getattr(chat, "id", None)
    info["type"] = inspector__chat_type(chat)
    info["username"] = getattr(chat, "username", None)
    info["title"] = getattr(chat, "title", None)
    info["first_name"] = getattr(chat, "first_name", None)
    info["last_name"] = getattr(chat, "last_name", None)
    info["description"] = getattr(chat, "description", None)
    info["bio"] = getattr(chat, "bio", None)
    info["is_bot"] = getattr(chat, "is_bot", None)
    info["members"] = getattr(chat, "member_count", None)
    return info


def inspector__chat_type(chat) -> str:
    t = getattr(chat, "type", None)
    mapping = {
        "private": "Private user",
        "group": "Group",
        "supergroup": "Supergroup",
        "channel": "Channel",
    }
    return mapping.get(t, t or "Chat")


def _inspector_escape_info(info: dict) -> dict:
    """Return a copy of *info* with all string values Markdown-escaped."""
    out = {}
    for k, v in info.items():
        if isinstance(v, str):
            out[k] = md_escape(v)
        else:
            out[k] = v
    return out


# ===========================================================================
# Handlers — toolbox
# ===========================================================================

_TOOL_MEDIA = {
    "audio": {"video", "gif", "video_note"},
    "thumb": {"video", "gif", "video_note", "photo", "document"},
    "info": {"video", "audio", "gif", "video_note", "photo",
             "document", "voice", "sticker"},
    "compress": {"video", "gif", "video_note"},
    "imgconv": {"photo", "document"},
}


async def toolbox__handle_tool_selection(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                         tool: str) -> None:
    """Called from the menu router when a tb:<tool> button is pressed."""
    if tool not in _TOOL_MEDIA:
        await update.callback_query.answer("Unknown tool.")
        return
    await states.set_state(update.effective_user.id, states.AWAIT_TOOLBOX)
    await states.set_tool(update.effective_user.id, tool)
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.TOOLBOX_PROMPTS[tool],
        reply_markup=kb.cancel_back("tb"),
        parse_mode="Markdown",
    )


async def toolbox__handle_forwarded_media(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    message = update.message
    tool = await states.get_tool(user_id)
    if not tool:
        await message.reply_text(
            "⚠️ No tool selected. Pick one from the Media Toolbox menu.",
            reply_markup=kb.toolbox_menu(),
        )
        return

    media_type = telegram_media_type(message)
    if media_type is None or media_type not in _TOOL_MEDIA.get(tool, set()):
        await message.reply_text(msg.TOOLBOX_INVALID_MEDIA, parse_mode="Markdown")
        return

    if tool == "imgconv":
        await states.set_state(user_id, states.AWAIT_TOOLBOX)
        await states.set_tool(user_id, "imgconv:msg:" + str(message.message_id))
        await message.reply_text(
            "🔄 Send the target format as a message "
            "(`png`, `jpg`, `webp`, or `bmp`):",
            parse_mode="Markdown",
            reply_markup=kb.cancel_back("tb"),
        )
        context.user_data["imgconv_msg_id"] = message.message_id
        context.user_data["imgconv_chat_id"] = message.chat_id
        return

    status = await message.reply_text(
        f"🧰 *{tool.title()}* — downloading your media…",
        parse_mode="Markdown",
        reply_markup=kb.cancel_back("tb"),
    )
    supervised_create_task(
        toolbox__run_tool(user_id, tool, message, context,
                          status.chat_id, status.message_id, media_type),
        name=f"toolbox_{tool}",
    )


async def toolbox__handle_imgconv_format(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Second step of image conversion: user sent the target format."""
    user_id = update.effective_user.id
    fmt = (update.message.text or "").strip().lower().lstrip(".")
    if fmt not in ("png", "jpg", "jpeg", "webp", "bmp"):
        await update.message.reply_text(
            "⚠️ Unsupported format. Send one of: `png`, `jpg`, `webp`, `bmp`.",
            parse_mode="Markdown",
        )
        return

    src_msg_id = context.user_data.get("imgconv_msg_id")
    src_chat_id = context.user_data.get("imgconv_chat_id")
    if not src_msg_id or not src_chat_id:
        await update.message.reply_text(
            "⚠️ Session expired. Please restart image conversion from the menu.",
            reply_markup=kb.toolbox_menu(),
        )
        await states.reset(user_id)
        return

    try:
        src_message = await context.bot.forward_message(
            chat_id=update.effective_chat.id,
            from_chat_id=src_chat_id,
            message_id=src_msg_id,
        )
    except Exception as exc:  # noqa: BLE001
        await update.message.reply_text(f"⚠️ Could not retrieve source media: {exc}")
        return

    status = await update.message.reply_text(
        "🔄 Converting image…",
        reply_markup=kb.cancel_back("tb"),
    )
    await states.set_tool(user_id, "imgconv")
    supervised_create_task(
        toolbox__run_tool(user_id, "imgconv", src_message, context,
                          status.chat_id, status.message_id, "photo",
                          extra={"fmt": fmt}),
        name="toolbox_imgconv",
    )


async def toolbox__run_tool(
    user_id: int, tool: str, message, context,
    chat_id: int, status_msg_id: int, media_type: str,
    *, extra: dict | None = None,
) -> None:
    src_path: Path | None = None
    out_path: Path | None = None
    try:
        await toolbox__edit(context, chat_id, status_msg_id, "📥 Downloading source media…")
        async with download_slot():
            src_path, name, mtype, size = await downloader.download_forwarded(
                message, progress=None, bot=context.bot
            )

        await toolbox__edit(context, chat_id, status_msg_id, f"🧰 Running {tool}…")
        out_path = await toolbox__dispatch_tool(tool, src_path, extra)

        await toolbox__edit(context, chat_id, status_msg_id, "📤 Sending result…")
        ok = await toolbox__send_result(context, chat_id, tool, out_path, src_path, name)
        if not ok:
            await toolbox__edit(context, chat_id, status_msg_id,
                                "⚠️ Could not send the result (size limit).",
                                reply_markup=kb.toolbox_menu())

        await repo.create_task(user_id, f"toolbox:{tool}", "done")
        await states.reset(user_id)

    except media_tools.ToolError as exc:
        logger.warning("tool %s failed: %s", tool, exc)
        await toolbox__edit(context, chat_id, status_msg_id,
                            f"❌ *Tool failed:* `{exc}`",
                            reply_markup=kb.toolbox_menu())
        await repo.create_task(user_id, f"toolbox:{tool}", "failed")
    except downloader.FileTooLarge as exc:
        await toolbox__edit(context, chat_id, status_msg_id,
                            msg.file_too_big_text(config.max_file_size_mb),
                            reply_markup=kb.toolbox_menu())
    except Exception as exc:  # noqa: BLE001
        logger.exception("toolbox %s error: %s", tool, exc)
        await toolbox__edit(context, chat_id, status_msg_id,
                            f"❌ *Error:* `{exc}`",
                            reply_markup=kb.toolbox_menu())
    finally:
        if out_path:
            await remove_path(out_path)
        if src_path:
            await remove_path(src_path)


async def toolbox__dispatch_tool(tool: str, src: Path, extra: dict | None) -> Path:
    if tool == "audio":
        return await media_tools.extract_audio(src, config.frames_dir)
    if tool == "thumb":
        return await media_tools.extract_thumbnail(src, config.frames_dir)
    if tool == "info":
        return src  # placeholder; caller checks tool == "info"
    if tool == "compress":
        return await media_tools.compress_video(src, config.frames_dir)
    if tool == "imgconv":
        fmt = (extra or {}).get("fmt", "png")
        return await media_tools.convert_image(src, config.frames_dir, fmt)
    raise media_tools.ToolError(f"Unknown tool: {tool}")


async def toolbox__send_result(context, chat_id: int, tool: str, out_path: Path,
                               src_path: Path, src_name: str) -> bool:
    if tool == "info":
        info = await media_tools.media_info(src_path)
        await context.bot.send_message(
            chat_id=chat_id,
            text=msg.media_info_text(info),
            parse_mode="Markdown",
            reply_markup=kb.toolbox_back(),
        )
        return True

    caption = f"🧰 {tool.title()} result for `{src_name}`"
    result = await send_file_back(
        chat_id, out_path, caption, context, progress_cb=None
    )
    if result == "ok":
        try:
            await context.bot.send_message(
                chat_id=chat_id, text="✅ Done.",
                reply_markup=kb.toolbox_back(),
            )
        except Exception:  # noqa: BLE001
            pass
        return True
    return False


async def toolbox__edit(context, chat_id: int, message_id: int, text: str,
                        reply_markup=None) -> None:
    try:
        await context.bot.edit_message_text(
            chat_id=chat_id, message_id=message_id,
            text=text, parse_mode="Markdown", reply_markup=reply_markup,
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("toolbox edit skipped: %s", exc)


# ===========================================================================
# Handlers — library
# ===========================================================================


async def library__show_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.LIBRARY_MENU_TEXT,
        reply_markup=kb.library_menu(),
        parse_mode="Markdown",
    )


async def library__handle_action(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                 data: str) -> None:
    """Dispatch lib:<action> callbacks."""
    q = update.callback_query
    user_id = update.effective_user.id
    action = data.split(":", 1)[1]

    if action == "browse":
        await library__browse(update, context, None)
    elif action == "search":
        await states.set_state(user_id, states.AWAIT_LIBRARY_SEARCH)
        await q.answer()
        await q.edit_message_text(
            text="🔍 *Library search*\n\nSend me a keyword to search your "
                 "library (filename, note or tags).",
            reply_markup=kb.cancel_back("lib"),
            parse_mode="Markdown",
        )
    elif action == "clear":
        n = await repo.library_clear(user_id)
        await q.answer(f"Cleared {n} entries.")
        await q.edit_message_text(
            text=f"🧹 *Library cleared* ({n} entries removed).",
            reply_markup=kb.library_menu(),
            parse_mode="Markdown",
        )
    elif action.startswith("t:"):
        media_type = action.split(":", 1)[1]
        # TG-H-006: whitelist media_type to prevent injection / surprises.
        if media_type not in {"video", "audio", "document", "photo", "gif",
                              "voice", "sticker", "video_note"}:
            await q.answer("⚠️ Unknown media type.", show_alert=True)
            return
        await library__browse(update, context, media_type)
    elif action.startswith("del:"):
        # TG-H-005: validate entry_id before parsing.
        try:
            entry_id = int(action.split(":", 1)[1])
        except (ValueError, IndexError):
            await q.answer("Invalid entry id.", show_alert=True)
            return
        ok = await repo.library_remove(user_id, entry_id)
        await q.answer("Removed." if ok else "Not found.")
        await library__browse(update, context, None)
    elif action == "savelast":
        await library__save_last(update, context)
    else:
        await q.answer("Unknown action.")


async def library__browse(update: Update, context: ContextTypes.DEFAULT_TYPE,
                          media_type: str | None) -> None:
    user_id = update.effective_user.id
    rows = await repo.library_entries(user_id, limit=15, media_type=media_type)
    title = "📚 Library" + (f" · {media_type}" if media_type else "")
    text = msg.library_list_text(rows, title)
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=text, reply_markup=kb.library_back(), parse_mode="Markdown",
    )


async def library__handle_search_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    query = (update.message.text or "").strip()
    if not query:
        await update.message.reply_text("⚠️ Please send a search keyword.")
        return
    rows = await repo.library_search(user_id, query, limit=20)
    text = msg.library_list_text(rows, f"🔍 Search: {query}")
    await update.message.reply_text(
        text=text, reply_markup=kb.library_back(), parse_mode="Markdown",
    )


async def library__save_last(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    meta = await states.get_last_download(user_id)
    if not meta:
        await update.callback_query.answer(
            "No recent download to save.", show_alert=True
        )
        return
    entry_id = await repo.add_library_entry(
        user_id,
        file_name=meta.get("file_name", "media"),
        media_type=meta.get("media_type"),
        file_size=meta.get("file_size", 0),
        file_id=meta.get("file_id"),
    )
    await update.callback_query.answer(f"Saved as #{entry_id} ⭐")
    try:
        await update.callback_query.edit_message_text(
            text=(
                f"⭐ *Saved to Library* (#{entry_id})\n\n"
                f"📄 `{meta.get('file_name','?')}`\n"
                f"🗂 {meta.get('media_type','—')} · "
                f"{human_size(meta.get('file_size',0))}"
            ),
            reply_markup=kb.library_back(),
            parse_mode="Markdown",
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("library save edit skipped: %s", exc)


# ===========================================================================
# Handlers — stats
# ===========================================================================


async def stats__show_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.STATS_MENU_TEXT,
        reply_markup=kb.stats_menu(),
        parse_mode="Markdown",
    )


async def stats__show_user(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.callback_query.answer()
    s = await repo.user_stats(update.effective_user.id)
    try:
        await update.callback_query.edit_message_text(
            text=msg.user_stats_text(s),
            reply_markup=kb.stats_back(),
            parse_mode="Markdown",
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("stats user edit skipped: %s", exc)


async def stats__show_global(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.callback_query.answer()
    s = await repo.global_stats()
    try:
        await update.callback_query.edit_message_text(
            text=msg.global_stats_text(s),
            reply_markup=kb.stats_back(),
            parse_mode="Markdown",
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("stats global edit skipped: %s", exc)


# ===========================================================================
# Handlers — qr
# ===========================================================================


async def qr__show_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.QR_MENU_TEXT,
        reply_markup=kb.qr_menu(),
        parse_mode="Markdown",
    )


async def qr__enter_make_mode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await states.set_state(update.effective_user.id, states.AWAIT_QR)
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.QR_PROMPT,
        reply_markup=kb.cancel_back("qr"),
        parse_mode="Markdown",
    )


async def qr__handle_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = (update.message.text or update.message.caption or "").strip()
    if not text:
        await update.message.reply_text("⚠️ Please send some text or a link.")
        return

    status = await update.message.reply_text("🔳 Generating QR code…")
    out_path: Path | None = None
    try:
        out_path = await qr_generator.generate_qr(text, config.frames_dir)
        with out_path.open("rb") as fh:
            await context.bot.send_photo(
                chat_id=update.effective_chat.id,
                photo=fh,
                caption=f"🔳 QR code for:\n`{md_escape(text[:200])}`",
                parse_mode="Markdown",
                reply_markup=kb.qr_back(),
            )
        await states.reset(update.effective_user.id)
    except qr_generator.QRError as exc:
        await qr__edit(context, status.chat_id, status.message_id,
                       f"❌ *QR error:* `{exc}`",
                       reply_markup=kb.qr_back())
    except Exception as exc:  # noqa: BLE001
        logger.exception("qr generation failed: %s", exc)
        await qr__edit(context, status.chat_id, status.message_id,
                       f"❌ *Error:* `{exc}`",
                       reply_markup=kb.qr_back())
    finally:
        if out_path:
            await remove_path(out_path)


async def qr__edit(context, chat_id: int, message_id: int, text: str,
                   reply_markup=None) -> None:
    try:
        await context.bot.edit_message_text(
            chat_id=chat_id, message_id=message_id,
            text=text, parse_mode="Markdown", reply_markup=reply_markup,
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("qr edit skipped: %s", exc)


# ===========================================================================
# Handlers — batch
# ===========================================================================

_BATCH_WINDOW_SECONDS = 6.0
# ASYNC-H-003: key by (user_id, chat_id) so the same user in two different
# chats gets two independent collectors (previously the second chat would
# hijack / merge into the first chat's album).
_batch_collectors: dict[tuple[int, int], "_AlbumCollector"] = {}


class _AlbumCollector:
    """Accumulates messages belonging to one media group for a user."""

    def __init__(self, user_id: int, chat_id: int, status_msg_id: int, bot):
        self.user_id = user_id
        self.chat_id = chat_id
        self.status_msg_id = status_msg_id
        self.bot = bot
        self.messages: list = []
        self.timer: asyncio.Task | None = None
        self.lock = asyncio.Lock()
        # ASYNC-H-002: while we're processing an album, do NOT cancel the timer
        # — a late-arriving message would otherwise interrupt batch__process_album
        # mid-download and leak temp files / partial state.
        self._processing = False

    async def add(self, message) -> None:
        async with self.lock:
            self.messages.append(message)
            count = len(self.messages)
        # Only reset the timer if we're not already processing the album.
        if self._processing:
            return
        if self.timer and not self.timer.done():
            self.timer.cancel()
        self.timer = asyncio.create_task(self._close_after_window(count))

    async def _close_after_window(self, last_count: int) -> None:
        try:
            await asyncio.sleep(_BATCH_WINDOW_SECONDS)
        except asyncio.CancelledError:
            return
        async with self.lock:
            if len(self.messages) != last_count:
                return  # more arrived; a newer timer will handle it
            msgs = list(self.messages)
            self.messages.clear()
        # ASYNC-H-002: mark as processing so add() won't cancel this task.
        self._processing = True
        try:
            await batch__process_album(self, msgs)
        finally:
            self._processing = False


async def batch__enter_batch_mode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await states.set_state(update.effective_user.id, states.AWAIT_BATCH)
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.BATCH_PROMPT,
        reply_markup=kb.cancel_back("batch"),
        parse_mode="Markdown",
    )


async def batch__handle_batch_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.message
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    media_type = telegram_media_type(message)
    if media_type is None:
        await message.reply_text(
            "⚠️ That message has no media. Forward an album or several media messages."
        )
        return

    key = (user_id, chat_id)  # ASYNC-H-003: per-chat isolation.
    collector = _batch_collectors.get(key)
    if collector is None:
        status = await message.reply_text(
            "📦 Collecting album… send more items, or wait ~6s to finish.",
            reply_markup=kb.cancel_back("batch"),
        )
        collector = _AlbumCollector(user_id, status.chat_id, status.message_id,
                                    context.bot)
        _batch_collectors[key] = collector
    await collector.add(message)


async def batch__process_album(collector: _AlbumCollector, messages: list) -> None:
    user_id = collector.user_id
    _batch_collectors.pop((user_id, collector.chat_id), None)  # ASYNC-H-003
    await states.reset(user_id)

    bot = collector.bot

    paths: list[Path] = []
    total_size = 0
    try:
        await batch__edit(bot, collector.chat_id, collector.status_msg_id,
                          f"📥 Downloading {len(messages)} items…")
        for i, m in enumerate(messages, 1):
            await batch__edit(bot, collector.chat_id, collector.status_msg_id,
                              f"📥 Downloading item {i}/{len(messages)}…")
            async with download_slot():
                path, name, mtype, size = await downloader.download_forwarded(
                    m, progress=None, bot=bot
                )
            paths.append(path)
            total_size += size
            await repo.add_download_history(
                user_id, file_name=name, file_size=size, mime_type=None,
                media_type=mtype, source="batch", status="done",
                file_unique_id=getattr(m.document, "file_unique_id", None)
                if m.document else None,
            )

        await batch__edit(bot, collector.chat_id, collector.status_msg_id,
                          msg.batch_summary_text(len(paths), total_size))

        await batch__send_back(bot, collector.chat_id, paths)

        settings = await repo.ensure_settings(user_id)
        if settings.get("auto_delete"):
            for p in paths:
                await remove_path(p)

    except downloader.FileTooLarge as exc:
        await batch__edit(bot, collector.chat_id, collector.status_msg_id,
                          msg.file_too_big_text(config.max_file_size_mb),
                          reply_markup=kb.batch_back())
    except Exception as exc:  # noqa: BLE001
        logger.exception("album processing failed: %s", exc)
        await batch__edit(bot, collector.chat_id, collector.status_msg_id,
                          msg.batch_failed_text(str(exc)),
                          reply_markup=kb.batch_back())
    finally:
        for p in paths:
            try:
                if p.exists():
                    await remove_path(p)
            except Exception:  # noqa: BLE001
                pass


async def batch__send_back(bot, chat_id: int, paths: list[Path]) -> None:
    """Send the downloaded files back — as an album when possible."""
    if not paths:
        return
    if len(paths) == 1:
        p = paths[0]
        if p.stat().st_size <= config.upload_limit_bytes:
            try:
                # v97.12 FIX: use aiofiles.open (async context manager).
                with p.open("rb") as fh:
                    await bot.send_document(chat_id=chat_id, document=fh,
                                            filename=p.name)
            except Exception as exc:  # noqa: BLE001
                logger.warning("album single send failed: %s", exc)
        return
    for p in paths:
        if p.stat().st_size > config.upload_limit_bytes:
            await bot.send_message(
                chat_id=chat_id,
                text=f"ℹ️ `{p.name}` is too large to send back via the Bot API.",
                parse_mode="Markdown",
            )
            continue
        try:
            # v97.12 FIX: use aiofiles.open (async context manager).
            with p.open("rb") as fh:
                await bot.send_document(chat_id=chat_id, document=fh,
                                        filename=p.name)
        except Exception as exc:  # noqa: BLE001
            logger.warning("album item send failed: %s", exc)


async def batch__edit(bot, chat_id: int, message_id: int, text: str,
                      reply_markup=None) -> None:
    try:
        await bot.edit_message_text(
            chat_id=chat_id, message_id=message_id,
            text=text, parse_mode="Markdown", reply_markup=reply_markup,
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("album edit skipped: %s", exc)


# ===========================================================================
# Handlers — scheduled
# ===========================================================================


async def scheduled__show_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.SCHEDULED_MENU_TEXT,
        reply_markup=kb.scheduled_menu(),
        parse_mode="Markdown",
    )


async def scheduled__show_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.callback_query.answer()
    rows = await repo.list_scheduled_tasks(update.effective_user.id, limit=15)
    await update.callback_query.edit_message_text(
        text=msg.scheduled_list_text(rows),
        reply_markup=kb.scheduled_back(),
        parse_mode="Markdown",
    )


async def scheduled__handle_schedule_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """User sent a time string; validate and ask for media."""
    text = (update.message.text or "").strip()
    run_at = scheduled__parse_time(text)
    if not run_at:
        await update.message.reply_text(
            msg.SCHEDULE_INVALID, parse_mode="Markdown",
            reply_markup=kb.cancel_back("sched"),
        )
        return
    context.user_data["sched_run_at"] = run_at
    await states.set_state(update.effective_user.id, states.AWAIT_DOWNLOAD_FORWARD)
    context.user_data["sched_mode"] = True
    await update.message.reply_text(
        f"⏰ Scheduled for *{run_at}*. Now forward the media to queue.",
        parse_mode="Markdown",
        reply_markup=kb.cancel_back("sched"),
    )


def scheduled__parse_time(text: str) -> str | None:
    """Parse 'YYYY-MM-DD HH:MM' into an ISO datetime string, or None."""
    text = text.strip()
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S"):
        try:
            dt = datetime.strptime(text, fmt)
            return dt.strftime("%Y-%m-%d %H:%M")
        except ValueError:
            continue
    return None


async def scheduled__queue_scheduled(
    user_id: int, run_at: str, kind: str, payload: dict,
) -> int:
    """Persist a scheduled task."""
    return await repo.add_scheduled_task(
        user_id, kind, json.dumps(payload, default=str), run_at
    )


async def scheduled__run_due_tasks(app) -> int:
    """Background loop tick: run any pending scheduled downloads that are due."""
    now_iso = datetime.now().strftime("%Y-%m-%d %H:%M")
    due = await repo.pending_scheduled_tasks(now_iso, limit=20)
    for task in due:
        # TG-H-011: send the notification FIRST, then mark done. On failure,
        # mark "failed" so the user sees the task didn't complete cleanly.
        try:
            await app.bot.send_message(
                chat_id=task["user_id"],
                text=(
                    f"⏰ *Scheduled task #{task['id']} was due.*\n\n"
                    f"Kind: `{task['kind']}`\n"
                    f"Scheduled for: `{task['run_at']}`\n\n"
                    "_Note: deferred media redownload isn't possible via the "
                    "Bot API without the original message — re-forward the "
                    "media to run it now._"
                ),
                parse_mode="Markdown",
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("scheduled notify failed for task %s: %s", task.get("id"), exc)
            try:
                await repo.update_scheduled_task(task["id"], "failed")
            except Exception:  # noqa: BLE001
                logger.exception("failed to mark scheduled task %s as failed", task.get("id"))
            continue
        try:
            await repo.update_scheduled_task(task["id"], "done")
        except Exception:  # noqa: BLE001
            logger.exception("failed to mark scheduled task %s as done", task.get("id"))
    return len(due)


# ===========================================================================
# Handlers — backup_restore
# ===========================================================================


async def backup__show_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.BACKUP_MENU_TEXT,
        reply_markup=kb.backup_menu(),
        parse_mode="Markdown",
    )


async def backup__do_export(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    await update.callback_query.answer("Exporting…")
    await update.callback_query.edit_message_text(
        text=msg.BACKUP_EXPORTING, reply_markup=kb.backup_back(),
        parse_mode="Markdown",
    )
    try:
        data = await repo.export_user_data(user_id)
        path = await backup.export_user_json(user_id)
        with path.open("rb") as fh:
            await context.bot.send_document(
                chat_id=user_id, document=fh, filename=path.name,
                caption=msg.backup_export_done_text(
                    path.name, path.stat().st_size,
                    {k: len(v) if isinstance(v, list) else 1
                     for k, v in data.items()
                     if k != "exported_at"},
                ),
                parse_mode="Markdown",
            )
        await remove_path(path)
    except Exception as exc:  # noqa: BLE001
        logger.exception("backup export failed: %s", exc)
        await context.bot.send_message(
            chat_id=user_id, text=msg.backup_failed_text(str(exc)),
            parse_mode="Markdown", reply_markup=kb.backup_back(),
        )


async def backup__enter_import(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await states.set_state(update.effective_user.id, states.AWAIT_BACKUP_IMPORT)
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.BACKUP_IMPORT_PROMPT,
        reply_markup=kb.cancel_back("bk"),
        parse_mode="Markdown",
    )


async def backup__handle_import_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    doc = update.message.document
    if doc is None:
        await update.message.reply_text("⚠️ Please send a JSON backup file.")
        return

    try:
        path, _, _, _ = await downloader.download_forwarded(
            update.message, progress=None, bot=context.bot
        )
    except Exception as exc:  # noqa: BLE001
        await update.message.reply_text(f"⚠️ Could not download the file: `{exc}`",
                                        parse_mode="Markdown")
        return

    try:
        data = await backup.parse_backup_file(path)
        summary = await backup.restore_from_dict(user_id, data)
        await update.message.reply_text(
            msg.backup_import_done_text(summary),
            reply_markup=kb.backup_back(),
            parse_mode="Markdown",
        )
    except json.JSONDecodeError as exc:
        await update.message.reply_text(
            f"⚠️ Invalid JSON file: `{exc}`", parse_mode="Markdown")
    except Exception as exc:  # noqa: BLE001
        logger.exception("backup import failed: %s", exc)
        await update.message.reply_text(
            msg.backup_failed_text(str(exc)),
            parse_mode="Markdown", reply_markup=kb.backup_back(),
        )
    finally:
        await remove_path(path)
        await states.reset(user_id)


# ===========================================================================
# Handlers — admin
# ===========================================================================


def admin__is_admin(user_id: int) -> bool:
    return user_id in config.admin_ids


async def admin__show_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # P0 fix #2: support BOTH slash-command and inline-callback invocations.
    # Previously crashed /admin with AttributeError on update.callback_query.
    q = update.callback_query
    if not admin__is_admin(update.effective_user.id):
        if q is not None:
            await q.answer()
            await safe_edit_message_text(
                context.bot, update.effective_chat.id, q.message.message_id,
                msg.ADMIN_DENIED, reply_markup=kb.back_only("main"),
            )
        else:
            await safe_send_message(
                context.bot, update.effective_chat.id,
                msg.ADMIN_DENIED, reply_markup=kb.back_only("main"),
            )
        return
    if q is not None:
        await q.answer()
        await safe_edit_message_text(
            context.bot, update.effective_chat.id, q.message.message_id,
            msg.ADMIN_MENU_TEXT, reply_markup=kb.admin_menu(),
        )
    else:
        await safe_send_message(
            context.bot, update.effective_chat.id,
            msg.ADMIN_MENU_TEXT, reply_markup=kb.admin_menu(),
        )


async def _admin_health_dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """V87: Admin health dashboard — shows uptime, provider status, multimodal status, task counts."""
    await update.callback_query.answer()
    try:
        uptime = int(time.time() - _BOT_START_TIME)
        uptime_str = f"{uptime // 3600}h {(uptime % 3600) // 60}m {uptime % 60}s"

        # Provider status.
        prov_lines = []
        for p in ("groq", "openrouter", "gemini"):
            st = _provider_get_state(p) if '_provider_get_state' in globals() else None
            if st is None:
                key_set = bool(getattr(config, f"{p}_api_key", ""))
                prov_lines.append(f"  {p}: {'✅' if key_set else '❌'} (key={'set' if key_set else 'missing'})")
            else:
                in_cd = _provider_in_cooldown(p) if '_provider_in_cooldown' in globals() else False
                key_set = bool(getattr(config, f"{p}_api_key", ""))
                status = "🔴 cooldown" if in_cd else ("✅ ready" if key_set else "❌ no key")
                prov_lines.append(f"  {p}: {status}")

        # Multimodal status.
        mm_enabled = getattr(config, "multimodal_enabled", True)
        witai_on = getattr(config, "witai_enabled", False)
        witai_token = bool((getattr(config, "witai_server_token", "") or "").strip())

        # MTProto status.
        mtp_on = bool(_mtproto_started and _mtproto_client and _mtproto_client.is_connected())

        # Task counts.
        import mediagrab_bot.bootstrap as _bs_mod
        bg_count = len(_bs_mod._app_bg_tasks) if _bs_mod._app_bg_tasks else 0
        active_count = len(_active_tasks) if '_active_tasks' in globals() else 0

        # User count.
        try:
            user_count = await repo.user_count()
        except Exception:
            user_count = -1

        lines = [
            "📊 *Bot Health Dashboard*",
            "",
            f"*Uptime:* `{uptime_str}`",
            f"*Users:* `{user_count}`",
            f"*MTProto:* `{'✅ Connected' if mtp_on else '❌ Disconnected'}`",
            f"*Multimodal:* `{'✅ Enabled' if mm_enabled else '❌ Disabled'}`",
            f"*Wit.ai:* `{'✅ ' if witai_on and witai_token else '❌'} (enabled={witai_on}, token={('set' if witai_token else 'missing')})`",
            f"*Talkative userbot:* `{'✅ Registered' if _talkative_userbot_handler_registered else '❌ Not registered (Bot API fallback active)'}`",
            "",
            "*AI Providers:*",
            "\n".join(prov_lines),
            "",
            f"*Background tasks:* `{bg_count}`",
            f"*Active tasks:* `{active_count}`",
        ]
        await safe_edit_message_text(
            context.bot, update.effective_chat.id,
            update.callback_query.message.message_id,
            "\n".join(lines),
            reply_markup=admin_menu(),
            parse_mode="Markdown",
        )
    except Exception as exc:
        logger.warning("ADMIN_HEALTH_DASHBOARD_ERROR exc=%s", exc)
        await safe_edit_message_text(
            context.bot, update.effective_chat.id,
            update.callback_query.message.message_id,
            f"❌ Error loading health dashboard: `{type(exc).__name__}: {str(exc)[:100]}`",
            reply_markup=admin_menu(),
            parse_mode="Markdown",
        )


async def _admin_active_tasks_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """V87: Show active background tasks and their status."""
    await update.callback_query.answer()
    try:
        lines = ["⚙️ *Active Background Tasks*", ""]

        # Check each named task.
        # NOTE: voicechat/talkative reassign their task globals via `global`,
        # so star-imported references snapshot a stale None. Use module attr.
        import mediagrab_bot.voicechat as _vc_h
        import mediagrab_bot.talkative as _tk_h
        import mediagrab_bot.bootstrap as _bs_h
        tasks_to_check = [
            ("periodic_cleanup", _bs_h._app_bg_tasks[0] if _bs_h._app_bg_tasks else None),
            ("scheduled_loop", _bs_h._app_bg_tasks[1] if len(_bs_h._app_bg_tasks) > 1 else None),
            ("talkative_cleanup", getattr(_tk_h, "_talkative_cleanup_task", None)),
            ("vc_reconcile", getattr(_vc_h, "_vc_reconcile_task", None)),
            ("dashboard_snapshot", getattr(_bs_h, "_dashboard_snapshot_task", None)),
            ("bot_heartbeat", getattr(_bs_h, "_bot_heartbeat_task", None)),
            ("bot_history", getattr(_bs_h, "_bot_history_task", None)),
            ("auto_discovery", getattr(_vc_h, "_auto_discovery_task", None)),
            ("deferred_queue", getattr(_vc_h, "_deferred_queue_task", None)),
            ("watchdog", getattr(_bs_h, "_watchdog_task", None)),
            ("cluster_reconnect", getattr(_bs_h, "_cluster_reconnect_task", None)),
        ]

        for name, task in tasks_to_check:
            if task is None:
                lines.append(f"  ⚪ `{name}`: not started")
            elif task.done():
                lines.append(f"  ❌ `{name}`: DONE (should be running!)")
            elif task.cancelled():
                lines.append(f"  🚫 `{name}`: CANCELLED")
            else:
                lines.append(f"  ✅ `{name}`: running")

        # Count supervised tasks.
        active_count = len(_active_tasks) if '_active_tasks' in globals() else 0
        lines.append("")
        lines.append(f"*Supervised fire-and-forget tasks:* `{active_count}`")

        await safe_edit_message_text(
            context.bot, update.effective_chat.id,
            update.callback_query.message.message_id,
            "\n".join(lines),
            reply_markup=admin_menu(),
            parse_mode="Markdown",
        )
    except Exception as exc:
        logger.warning("ADMIN_TASKS_VIEW_ERROR exc=%s", exc)
        await safe_edit_message_text(
            context.bot, update.effective_chat.id,
            update.callback_query.message.message_id,
            f"❌ Error loading tasks: `{type(exc).__name__}`",
            reply_markup=admin_menu(),
            parse_mode="Markdown",
        )


async def admin__list_users(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not admin__is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    await update.callback_query.answer()
    users = await repo.all_users(limit=20)
    total = await repo.user_count()
    await update.callback_query.edit_message_text(
        text=msg.admin_users_text(users, total),
        reply_markup=kb.admin_back(),
        parse_mode="Markdown",
    )


async def admin__global_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not admin__is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    await update.callback_query.answer()
    s = await repo.global_stats()
    await update.callback_query.edit_message_text(
        text=msg.global_stats_text(s),
        reply_markup=kb.admin_back(),
        parse_mode="Markdown",
    )


async def admin__export_global(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not admin__is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    await update.callback_query.answer("Exporting…")
    try:
        path = await backup.export_global_json()
        with path.open("rb") as fh:
            await context.bot.send_document(
                chat_id=update.effective_user.id, document=fh,
                filename=path.name,
                caption="💾 Global stats export",
            )
        await remove_path(path)
    except Exception as exc:  # noqa: BLE001
        logger.exception("global export failed: %s", exc)
        await update.callback_query.answer(f"Failed: {exc}")


async def admin__enter_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not admin__is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    await states.set_state(update.effective_user.id, states.AWAIT_ADMIN_BCAST)
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.ADMIN_BCAST_PROMPT,
        reply_markup=kb.cancel_back("admin"),
        parse_mode="Markdown",
    )


async def admin__handle_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    admin_id = update.effective_user.id
    if not admin__is_admin(admin_id):
        await update.message.reply_text("🚫 Not authorised.")
        return
    text = (update.message.text or "").strip()
    if not text:
        await update.message.reply_text("⚠️ Send the broadcast text.")
        return
    await states.reset(admin_id)

    status = await update.message.reply_text("📣 Broadcasting…")
    users = await repo.all_users(limit=10000)
    bid = await repo.create_broadcast(admin_id, text)
    sent = failed = 0
    sem = asyncio.Semaphore(25)

    async def _send_one(u: dict) -> tuple[bool, bool]:
        # Returns (sent, retried_after_already_handled)
        async with sem:
            try:
                await context.bot.send_message(
                    chat_id=u["tg_id"],
                    text=f"📣 *Broadcast:*\n\n{text}",
                    parse_mode="Markdown",
                )
                return True, False
            except RetryAfter as exc:
                wait = min(exc.retry_after + 1, 60)
                logger.info("broadcast RetryAfter chat=%s wait=%.1fs", u.get("tg_id"), wait)
                await asyncio.sleep(wait)
                try:
                    await context.bot.send_message(
                        chat_id=u["tg_id"],
                        text=f"📣 *Broadcast:*\n\n{text}",
                        parse_mode="Markdown",
                    )
                    return True, True
                except Exception:  # noqa: BLE001
                    return False, True
            except Exception:  # noqa: BLE001
                return False, False

    for u in users:
        ok, _ = await _send_one(u)
        if ok:
            sent += 1
        else:
            failed += 1
        await asyncio.sleep(0.05)
    await repo.update_broadcast_counts(bid, sent, failed)
    try:
        await context.bot.edit_message_text(
            chat_id=status.chat_id, message_id=status.message_id,
            text=msg.admin_bcast_done_text(sent, failed),
            parse_mode="Markdown", reply_markup=kb.admin_back(),
        )
    except Exception:  # noqa: BLE001
        pass


# ===========================================================================
# Handlers — mtproto_admin (Task ID 8)
# ===========================================================================
# Admin-only controls for the MTProto (Telethon) backend:
#   * Status view (uptime + stats)
#   * Start / stop / restart
#   * Screenshot a chat by @username / id
#   * Download restricted content via MTProto
#
# All Telethon access goes through the ``mtproto_manager`` / ``mtproto_service``
# SimpleNamespaces defined above. Telethon itself is lazy-imported inside those
# modules, so these handlers are safe to load even when Telethon is absent.


def mtproto__is_admin(user_id: int) -> bool:
    return user_id in config.admin_ids


def _mtproto_status_text(status: dict) -> str:
    s = status
    uptime = s.get("uptime_seconds", 0)
    h, rem = divmod(int(uptime), 3600)
    m, sec = divmod(rem, 60)
    stats = s.get("stats", {})
    sess = s.get("session", {})
    started = "✅ Running" if s.get("started") else "⚪️ Stopped"
    return (
        f"*🛰️ MTProto Backend*\n\n"
        f"Status: {started}\n"
        f"Uptime: `{h}:{m:02d}:{sec:02d}`\n"
        f"Telethon installed: {'✅' if s.get('available') else '❌'}\n"
        f"Configured: {'✅' if s.get('configured') else '❌'}\n\n"
        f"*Session:*\n"
        f"  Name: `{md_escape(sess.get('session_name','—'))}`\n"
        f"  File exists: {'✅' if sess.get('session_exists') else '❌'}\n"
        f"  API ID set: {'✅' if sess.get('api_id_set') else '❌'}\n\n"
        f"*Stats:*\n"
        f"  Requests: {stats.get('requests',0)}\n"
        f"  Successes: {stats.get('successes',0)}\n"
        f"  Failures: {stats.get('failures',0)}\n"
        f"  FloodWaits: {stats.get('flood_waits',0)}\n"
        f"  Reconnects: {stats.get('reconnects',0)}\n"
    )


async def mtproto__show_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # P0 fix #3: support BOTH slash-command and inline-callback invocations.
    q = update.callback_query
    if not mtproto__is_admin(update.effective_user.id):
        if q is not None:
            await q.answer()
            await safe_edit_message_text(
                context.bot, update.effective_chat.id, q.message.message_id,
                msg.ADMIN_DENIED, reply_markup=kb.back_only("main"),
            )
        else:
            await safe_send_message(
                context.bot, update.effective_chat.id,
                msg.ADMIN_DENIED, reply_markup=kb.back_only("main"),
            )
        return
    status = mtproto_manager.get_status()
    if q is not None:
        await q.answer()
        await safe_edit_message_text(
            context.bot, update.effective_chat.id, q.message.message_id,
            _mtproto_status_text(status),
            reply_markup=kb.mtproto_menu(),
        )
    else:
        await safe_send_message(
            context.bot, update.effective_chat.id,
            _mtproto_status_text(status),
            reply_markup=kb.mtproto_menu(),
        )


async def mtproto__start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not mtproto__is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    await update.callback_query.answer("Starting MTProto…")
    # v97.92: bound the call so a hung Telethon connect can't block the
    # admin route_callback future indefinitely (BUG-H1 from Task 1-c).
    try:
        result = await asyncio.wait_for(mtproto_manager.start(), timeout=60)
    except asyncio.TimeoutError:
        result = "timeout: start took > 60s"
        logger.warning("MTPROTO_ADMIN_START_TIMEOUT — 60s budget exceeded")
    except Exception as exc:  # noqa: BLE001
        result = f"error: {type(exc).__name__}: {exc}"
        logger.warning("MTPROTO_ADMIN_START_ERROR exc=%s", str(exc)[:120])
    status = mtproto_manager.get_status()
    text = (f"*🛰️ MTProto Start*\n\n"
            f"Result: `{md_escape(result)}`\n\n" + _mtproto_status_text(status))
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        text, reply_markup=kb.mtproto_menu(),
    )


async def mtproto__stop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not mtproto__is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    await update.callback_query.answer("Stopping MTProto…")
    # v99.11 P0 (leave audit): an admin MTProto stop is a LEAVE-CLASS
    # action — every client disconnect destroys that account's native
    # VC transports WITHOUT Telegram leave RPCs (server-side ghost
    # participations until Telegram times them out).  The v99.10 audit
    # found this was silent; the v99.11 leave policy requires it to be
    # EXPLICIT and observable: the deliberate reason code is logged (an
    # admin asked for it), the ghost-acceptance is stated, and the
    # registry/coordinator reconcile will converge the residual state.
    logger.warning(
        "VC_LEAVE_REQUESTED account_id=(all) chat_id=(all) reason=%s "
        "source=mtproto__stop evidence=admin dashboard button — admin "
        "MTProto stop DESTROYS all native transports without per-VC "
        "leave RPCs (ghost participations accepted deliberately; "
        "reconcile converges the registry; v99.11 leave policy)",
        "MTPROTO_ADMIN_STOP",
    )
    # v97.92: bound the call so a hung disconnect can't block the route.
    try:
        result = await asyncio.wait_for(mtproto_manager.stop(), timeout=30)
    except asyncio.TimeoutError:
        result = "timeout: stop took > 30s"
        logger.warning("MTPROTO_ADMIN_STOP_TIMEOUT — 30s budget exceeded")
    except Exception as exc:  # noqa: BLE001
        result = f"error: {type(exc).__name__}: {exc}"
        logger.warning("MTPROTO_ADMIN_STOP_ERROR exc=%s", str(exc)[:120])
    status = mtproto_manager.get_status()
    text = (f"*🛰️ MTProto Stop*\n\n"
            f"Result: `{md_escape(result)}`\n\n" + _mtproto_status_text(status))
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        text, reply_markup=kb.mtproto_menu(),
    )


async def mtproto__restart(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not mtproto__is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    await update.callback_query.answer("Restarting MTProto…")
    # v99.11 P0 (leave audit): restart = stop + start — same leave-class
    # ghost-acceptance as mtproto__stop (transports die with the clients).
    logger.warning(
        "VC_LEAVE_REQUESTED account_id=(all) chat_id=(all) reason=%s "
        "source=mtproto__restart evidence=admin dashboard button — "
        "transient transport destruction accepted (ghost participations "
        "until the restart completes; v99.11 leave policy)",
        "MTPROTO_ADMIN_STOP",
    )
    # v97.92: bound the call so a hung stop→sleep→start cycle can't block.
    try:
        result = await asyncio.wait_for(mtproto_manager.restart(), timeout=90)
    except asyncio.TimeoutError:
        result = "timeout: restart took > 90s"
        logger.warning("MTPROTO_ADMIN_RESTART_TIMEOUT — 90s budget exceeded")
    except Exception as exc:  # noqa: BLE001
        result = f"error: {type(exc).__name__}: {exc}"
        logger.warning("MTPROTO_ADMIN_RESTART_ERROR exc=%s", str(exc)[:120])
    status = mtproto_manager.get_status()
    text = (f"*🛰️ MTProto Restart*\n\n"
            f"Result: `{md_escape(result)}`\n\n" + _mtproto_status_text(status))
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        text, reply_markup=kb.mtproto_menu(),
    )


async def mtproto__refresh_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not mtproto__is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    await update.callback_query.answer()
    status = mtproto_manager.get_status()
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        _mtproto_status_text(status), reply_markup=kb.mtproto_menu(),
    )


async def mtproto__enter_screenshot_mode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not mtproto__is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    await states.set_state(update.effective_user.id, states.AWAIT_MTPROTO_SCREENSHOT)
    await update.callback_query.answer()
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        "📸 *Screenshot mode*\n\n"
        "Send me a @username or chat id to capture a text-rendered screenshot "
        "of its recent messages (via MTProto).",
        reply_markup=kb.cancel_back("mtproto"),
    )


async def mtproto__handle_screenshot_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not mtproto__is_admin(user_id):
        await safe_reply_text(update.message, "🚫 Not authorised.")
        return
    chat_ref = (update.message.text or "").strip()
    if not chat_ref:
        await safe_reply_text(update.message, "⚠️ Send a @username or chat id.")
        return
    # SEC-H-005: audit-log every admin screenshot request.
    logger.info("ADMIN_SCREENSHOT admin=%s chat_ref=%s", user_id, chat_ref)
    await states.reset(user_id)

    status_msg = await safe_reply_text(update.message, "📸 Capturing screenshot…")
    if status_msg is None:
        return

    path: Path | None = None
    try:
        path = await mtproto_service.screenshot(chat_ref)
        if path and path.exists():
            with path.open("rb") as fh:
                await context.bot.send_photo(
                    chat_id=update.effective_chat.id,
                    photo=fh,
                    caption=f"📸 Screenshot of `{md_escape(chat_ref)}`",
                    parse_mode="Markdown",
                )
            await safe_edit_message_text(
                context.bot, status_msg.chat_id, status_msg.message_id,
                "✅ Screenshot sent.", reply_markup=kb.mtproto_menu(),
            )
        else:
            await safe_edit_message_text(
                context.bot, status_msg.chat_id, status_msg.message_id,
                "❌ Screenshot failed. Is MTProto running and the chat accessible?",
                reply_markup=kb.mtproto_menu(),
            )
    except mtproto_service.MTProtoError as exc:
        await safe_edit_message_text(
            context.bot, status_msg.chat_id, status_msg.message_id,
            f"❌ `{md_escape(str(exc))}`",
            reply_markup=kb.mtproto_menu(),
        )
    except Exception as exc:  # noqa: BLE001
        logger.exception("screenshot failed: %s", exc)
        await safe_edit_message_text(
            context.bot, status_msg.chat_id, status_msg.message_id,
            f"❌ Error: `{md_escape(str(exc))}`",
            reply_markup=kb.mtproto_menu(),
        )
    finally:
        # ERR-H-005: always clean up the temp screenshot, even on error.
        if path is not None:
            try:
                await remove_path(path)
            except Exception:  # noqa: BLE001
                pass


async def mtproto__enter_download_mode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not mtproto__is_admin(update.effective_user.id):
        await update.callback_query.answer("Not authorised.", show_alert=True)
        return
    await states.set_state(update.effective_user.id, states.AWAIT_MTPROTO_DOWNLOAD)
    await update.callback_query.answer()
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        "📥 *MTProto download mode*\n\n"
        "Send me any of:\n"
        "• A message link: `https://t.me/channel/123`\n"
        "• `@username message_id` (e.g. `@channel 123`)\n"
        "• Just `@username` — I'll show recent messages so you can pick an id\n"
        "• A private link: `https://t.me/c/1234567890/123`\n\n"
        "_Downloads via MTProto can access restricted content the userbot "
        "can see._",
        reply_markup=kb.cancel_back("mtproto"),
    )


async def mtproto__handle_download_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not mtproto__is_admin(user_id):
        await safe_reply_text(update.message, "🚫 Not authorised.")
        return
    raw = (update.message.text or "").strip()
    if not raw:
        await safe_reply_text(update.message, "⚠️ Send a link or @username.")
        return

    # Case 1: input includes a message id → download directly.
    try:
        chat_ref, msg_id = _mtproto_parse_input(raw)
    except mtproto_service.MTProtoError:
        # Case 2: input is just a @username / link without msg id → show history.
        await _mtproto_show_history_and_ask_msgid(update, context, raw)
        return

    await states.reset(user_id)
    await _mtproto_do_download(update, context, chat_ref, msg_id)


async def mtproto__handle_msgid_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Admin sent a message id after we showed the channel history."""
    user_id = update.effective_user.id
    if not mtproto__is_admin(user_id):
        await safe_reply_text(update.message, "🚫 Not authorised.")
        return
    text = (update.message.text or "").strip()
    try:
        msg_id = int(text)
    except ValueError:
        await safe_reply_text(
            update.message,
            "⚠️ Send a numeric message id (e.g. `123`).",
            reply_markup=kb.cancel_back("mtproto"),
        )
        return
    if msg_id <= 0:
        await safe_reply_text(update.message, "⚠️ Message id must be positive.")
        return

    chat_ref = context.user_data.get("mtproto_chat_ref")
    if not chat_ref:
        await safe_reply_text(
            update.message,
            "⚠️ Session expired. Send the @username again.",
            reply_markup=kb.mtproto_menu(),
        )
        await states.reset(user_id)
        return

    await states.reset(user_id)
    await _mtproto_do_download(update, context, chat_ref, msg_id)


async def _mtproto_show_history_and_ask_msgid(update: Update,
                                              context: ContextTypes.DEFAULT_TYPE,
                                              raw: str) -> None:
    """Resolve a @username/link via MTProto, show recent messages, ask for id."""
    status_msg = await safe_reply_text(
        update.message, "📥 Resolving chat via MTProto…"
    )
    if status_msg is None:
        return

    try:
        # Normalize the input to a chat reference.
        chat_ref = _mtproto_normalize_chat_ref(raw)
        if not chat_ref:
            await safe_edit_message_text(
                context.bot, status_msg.chat_id, status_msg.message_id,
                "❌ Could not parse that. Send a @username or t.me link.",
                reply_markup=kb.mtproto_menu(),
            )
            return

        # Resolve + fetch history via MTProto.
        info = await mtproto_service.resolve_entity(chat_ref)
        history = await mtproto_service.get_channel_history(chat_ref, limit=15)

        # Stash for the message-id step.
        context.user_data["mtproto_chat_ref"] = chat_ref
        await states.set_state(update.effective_user.id, states.AWAIT_MTPROTO_MSGID)

        title = md_escape(info.get("title") or info.get("first_name")
                          or str(info.get("id", chat_ref)))
        uname = info.get("username")
        uname_s = f"@{md_escape(uname)}" if uname else "—"
        members = info.get("participants_count")
        members_s = f"{members:,}" if members else "—"

        lines = [
            "✅ *Chat resolved via MTProto*\n",
            f"📛 *Name:* {title}",
            f"🔗 *Username:* {uname_s}",
            f"👥 *Members:* {members_s}",
            f"🆔 *ID:* `{info.get('id', '—')}`",
            "",
            "*Recent messages (newest first):*",
            "",
        ]
        media_count = 0
        for m in history:
            mid = m.get("id", "?")
            has_media = m.get("has_media")
            mtype = m.get("media_type", "")
            date_s = (m.get("date") or "")[:16].replace("T", " ")
            text_preview = (m.get("text") or "").replace("\n", " ")[:60]
            icon = "📎" if has_media else "💬"
            if has_media:
                media_count += 1
                text_preview = f"[{mtype}] {text_preview}".strip()
            lines.append(f"`{mid}` {icon} {date_s}\n    {text_preview}")

        lines.append("")
        lines.append(
            f"_Found {media_count} media messages out of {len(history)}._\n"
            "📝 *Send me the message id* of the media you want to download."
        )
        await safe_edit_message_text(
            context.bot, status_msg.chat_id, status_msg.message_id,
            "\n".join(lines),
            reply_markup=kb.cancel_back("mtproto"),
        )
    except mtproto_service.MTProtoError as exc:
        await safe_edit_message_text(
            context.bot, status_msg.chat_id, status_msg.message_id,
            f"❌ `{md_escape(str(exc))}`",
            reply_markup=kb.mtproto_menu(),
        )
    except Exception as exc:  # noqa: BLE001
        logger.exception("mtproto history failed: %s", exc)
        await safe_edit_message_text(
            context.bot, status_msg.chat_id, status_msg.message_id,
            f"❌ Error: `{md_escape(str(exc))}`",
            reply_markup=kb.mtproto_menu(),
        )


async def _mtproto_do_download(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              chat_ref, msg_id: int) -> None:
    """Perform the actual MTProto download and send the file back."""
    # SEC-H-005: audit-log every admin MTProto download.
    logger.info("ADMIN_MTPROTO_DOWNLOAD admin=%s chat_ref=%s msg_id=%s",
                update.effective_user.id, chat_ref, msg_id)
    status_msg = await safe_reply_text(
        update.message, "📥 Downloading via MTProto…"
    )
    if status_msg is None:
        return

    path: Path | None = None
    try:
        path, name, mtype, size = await mtproto_service.download_message_media(
            chat_ref, msg_id,
        )
        caption = (
            f"✅ *Downloaded via MTProto*\n\n"
            f"📄 `{md_escape(name)}`\n"
            f"📦 {human_size(size)}\n"
            f"🗂 {mtype}\n"
            f"🆔 Message: `{msg_id}`"
        )
        if size <= config.upload_limit_bytes:
            with path.open("rb") as fh:
                await safe_send_document(
                    context.bot, update.effective_chat.id, fh,
                    filename=name, caption=caption,
                )
        else:
            await safe_send_message(
                context.bot, update.effective_chat.id,
                caption + "\n\n_ℹ️ Too large to send via Bot API — saved on server._",
            )
        await safe_edit_message_text(
            context.bot, status_msg.chat_id, status_msg.message_id,
            "✅ Done.", reply_markup=kb.mtproto_menu(),
        )
    except mtproto_service.MTProtoError as exc:
        await safe_edit_message_text(
            context.bot, status_msg.chat_id, status_msg.message_id,
            f"❌ `{md_escape(str(exc))}`",
            reply_markup=kb.mtproto_menu(),
        )
    except Exception as exc:  # noqa: BLE001
        logger.exception("mtproto download failed: %s", exc)
        await safe_edit_message_text(
            context.bot, status_msg.chat_id, status_msg.message_id,
            f"❌ Error: `{md_escape(str(exc))}`",
            reply_markup=kb.mtproto_menu(),
        )
    finally:
        # ERR-H-006: always clean up the temp file, even on error.
        if path is not None:
            try:
                await remove_path(path)
            except Exception:  # noqa: BLE001
                pass


def _mtproto_normalize_chat_ref(raw: str) -> str | int | None:
    """Normalize any chat input to a @username string or int chat id."""
    parsed = link_parser.parse_input(raw)
    if not parsed.ok:
        return None
    if parsed.username:
        return f"@{parsed.username}"
    if parsed.chat_id is not None:
        return parsed.chat_id
    return None


def _mtproto_parse_input(raw: str) -> tuple[str | int, int]:
    """Parse inputs that include a message id.

    Supports:
      - https://t.me/channel/123
      - https://t.me/c/1234567890/123
      - @channel 123
      - channel 123

    Raises ``MTProtoError(\"no_message_id\")`` if no message id is present
    (the caller should then show channel history instead).
    """
    parsed = link_parser.parse_input(raw)
    if (parsed.ok and parsed.kind == link_parser.KIND_MESSAGE_LINK
            and parsed.message_id):
        ref = (f"@{parsed.username}" if parsed.username
               else parsed.chat_id)
        return ref, parsed.message_id
    parts = raw.split()
    if len(parts) >= 2:
        ref = parts[0].lstrip("@")
        try:
            return ref, int(parts[-1])
        except ValueError:
            pass
    raise mtproto_service.MTProtoError("no_message_id")


# ===========================================================================
# Handlers — inline
# ===========================================================================


async def inline__handle_inline(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not config.inline_enabled:
        return
    q = update.inline_query
    if q is None:
        return
    user_id = q.from_user.id
    query = (q.query or "").strip()
    is_admin = user_id in config.admin_ids
    await repo.upsert_user(user_id, q.from_user.username, q.from_user.first_name,
                           is_admin)

    parts = query.split(maxsplit=1)
    cmd = parts[0].lower() if parts else ""
    rest = parts[1] if len(parts) > 1 else ""

    results = []

    if cmd in ("", "help", "start"):
        results.append(inline__article(
            "help",
            "ℹ️ MediaGrab AI — Help",
            msg.inline_help_text(),
        ))

    if cmd == "info":
        s = await repo.user_stats(user_id)
        results.append(inline__article(
            "info",
            "📊 Your stats",
            msg.inline_stats_text(s),
        ))

    if cmd == "qr" and rest:
        # TG-H-009: removed dead QR generation — inline mode can't return local
        # files. Just show a text article pointing the user to the bot.
        results.append(inline__article(
            "qr",
            f"🔳 QR for: {rest[:40]}",
            f"Open the bot and use the QR feature to generate this:\n\n`{rest}`",
        ))

    if cmd == "menu":
        results.append(inline__article(
            "menu",
            "🏠 Open MediaGrab AI",
            "Tap to open the bot and use all features.",
            button_text="Open bot",
        ))

    if not results:
        results.append(inline__article(
            "default",
            "🎬 MediaGrab AI Bot",
            msg.inline_help_text(),
        ))

    try:
        # TG-H-008: most inline results are static help text; only `info` is
        # personal. PTB doesn't support per-result flags, so use is_personal=False
        # to let Telegram cache static results across users.
        await q.answer(results, cache_time=30, is_personal=False)
    except Exception as exc:  # noqa: BLE001
        logger.debug("inline answer failed: %s", exc)


def inline__article(_id: str, title: str, description: str,
                    button_text: str | None = None) -> InlineQueryResultArticle:
    content = InputTextMessageContent(message_text=description, parse_mode="Markdown")
    kwargs: dict = {
        "id": _id,
        "title": title,
        "description": description[:200],
        "input_message_content": content,
    }
    if button_text:
        kwargs["reply_markup"] = InlineKeyboardMarkup([[
            InlineKeyboardButton(button_text,
                                 url=f"https://t.me/{config.bot_token.split(':')[0]}")
        ]])
    return InlineQueryResultArticle(**kwargs)


async def inline__make_qr(text: str) -> Path | None:
    try:
        return await qr_generator.generate_qr(text, config.frames_dir)
    except Exception as exc:  # noqa: BLE001
        logger.debug("inline qr failed: %s", exc)
        return None


# ===========================================================================
# Handlers — link_download (Task ID 5)
# ===========================================================================

# Download by Telegram message link or @username — Bot API only.
#
# How it works:
# 1. The user sends a message link, @username, or channel link.
# 2. ``link_parser.parse_input`` classifies the input.
# 3. If a message id is present -> ``copyMessage`` brings the media into the
#    user's chat with the bot and returns a Message with ``file_id``.
# 4. If no message id (channel link / @username) -> ``getChat`` resolves the
#    chat metadata (public only), then we ask the user for a message id.
# 5. The returned ``file_id`` is downloaded via the existing chunked/resumable
#    downloader and sent back as a document with the original filename.
#
# Bot API limitations (surfaced clearly, never silently failing):
#   * Private chats (t.me/c/…) require the bot to be a member.
#   * Public channels can be read via @username + message id.
#   * Bots cannot list messages in a chat — the user must supply the id.
#
# Task ID 6: All user-facing send/edit/reply calls now go through the
# ``safe_*`` wrappers (``safe_reply_text``, ``safe_send_message``,
# ``safe_edit_message_text``) so a Markdown parse error in user-generated text
# (usernames, filenames, captions, chat titles) never raises a
# ``BadRequest: Can't parse entities`` again. Dynamic insertions are escaped
# with ``md_escape``.


class _LinkDownloadError(Exception):
    """Raised when copyMessage/getChat fails with a clear user-facing reason."""


async def link__enter_link_mode(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Called when the user taps '🔗 Download by link or @username'."""
    await states.set_state(update.effective_user.id, states.AWAIT_LINK_DOWNLOAD)
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        text=msg.LINK_DOWNLOAD_PROMPT,
        reply_markup=kb.cancel_back("dl"),
        parse_mode="Markdown",
    )


async def link__handle_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    raw = (update.message.text or update.message.caption or "").strip()
    if not raw:
        await safe_reply_text(update.message, msg.LINK_DOWNLOAD_EMPTY)
        return

    parsed = link_parser.parse_input(raw)

    if not parsed.ok:
        await safe_reply_text(
            update.message,
            msg.link_parse_error_text(md_escape(parsed.error)),
            reply_markup=kb.cancel_back("dl"),
        )
        return

    # Route by kind.
    if parsed.kind == link_parser.KIND_MESSAGE_LINK:
        await _link_download_message_link(update, context, parsed)
    elif parsed.kind in (link_parser.KIND_CHANNEL_LINK,
                         link_parser.KIND_USERNAME,
                         link_parser.KIND_CHAT_ID):
        await _link_resolve_and_ask_message_id(update, context, parsed)
    else:
        await safe_reply_text(
            update.message,
            msg.link_parse_error_text("Unrecognised input."),
            reply_markup=kb.cancel_back("dl"),
        )


async def _link_download_message_link(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                      parsed: link_parser.ParsedInput) -> None:
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    from_chat = link_parser.from_chat_reference(parsed)
    msg_id = parsed.message_id

    # Escape the dynamic description so usernames/chat-ids with _ or * don't
    # break Markdown entity parsing.
    description = md_escape(link_parser.describe_input(parsed))
    status = await safe_reply_text(
        update.message,
        msg.link_resolving_text(description),
        reply_markup=kb.cancel_back("dl"),
    )
    if status is None:
        return
    task_id = await repo.create_task(user_id, "download", "running")
    supervised_create_task(
        _link_run_download(user_id, task_id, chat_id, status.message_id,
                           from_chat, msg_id, parsed, context),
        name="link_download",
    )


async def _link_run_download(
    user_id: int, task_id: int, chat_id: int, status_msg_id: int,
    from_chat, msg_id: int, parsed: link_parser.ParsedInput,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    path: Path | None = None
    _t_start = time.monotonic()

    # v97.19: MEDIA CACHE — check if we already have a cached file_id for this
    # source. If so, deliver instantly via sendDocument(file_id) — no download,
    # no upload, near-zero latency. This is the biggest speed improvement for
    # repeat requests.
    _cache_source = str(from_chat)
    try:
        _cached = await repo.media_cache_lookup(_cache_source, msg_id)
    except Exception:  # noqa: BLE001
        _cached = None
    if _cached and _cached.get("file_id"):
        _cache_t = time.monotonic() - _t_start
        logger.info("MEDIA_CACHE_HIT source=%s msg_id=%s file_id=%s cache_lookup=%.3fs",
                    _cache_source, msg_id, _cached["file_id"][:20] + "...", _cache_t)
        try:
            await _link_edit(context, chat_id, status_msg_id,
                             "⚡ Delivering from cache…")
            _caption = _cached.get("caption") or ""
            if _cached.get("file_name"):
                _caption = f"📄 `{_cached['file_name']}`\n" + _caption
            await context.bot.send_document(
                chat_id=chat_id,
                document=_cached["file_id"],
                caption=_caption[:1024] if _caption else None,
                parse_mode="Markdown" if _caption else None,
            )
            await repo.update_task(task_id, status="done", progress=100)
            await repo.add_download_history(
                user_id, file_name=_cached.get("file_name", "cached"),
                file_size=_cached.get("file_size", 0), mime_type=None,
                media_type=_cached.get("media_type"), source="link_cache",
                status="done", task_id=task_id, message_link=parsed.raw,
            )
            # Clean up status message.
            try:
                await context.bot.delete_message(chat_id=chat_id, message_id=status_msg_id)
            except Exception:  # noqa: BLE001
                pass
            logger.info("MEDIA_CACHE_DELIVERED source=%s msg_id=%s total=%.3fs",
                        _cache_source, msg_id, time.monotonic() - _t_start)
            return
        except Exception as exc:  # noqa: BLE001
            logger.info("MEDIA_CACHE_MISS_FALLBACK source=%s msg_id=%s exc=%s — "
                        "cached file_id expired, falling through to download",
                        _cache_source, msg_id, type(exc).__name__)

    # Cache miss — proceed with the normal pipeline.
    try:
        # 1) copyMessage — brings the media into the bot's accessible scope.
        # v97.13: copyMessage is the FASTEST native method — it delivers the
        # media directly to the user's chat without a download→upload cycle.
        # If copyMessage succeeds, the media is already delivered — we only
        # need to download+reupload if the user explicitly wants a file
        # (document) copy, or if copyMessage failed with a non-protected error.
        await _link_edit(context, chat_id, status_msg_id,
                         "📥 Fetching message via copyMessage…")
        copied = await _link_copy_with_retries(context, chat_id, from_chat, msg_id)

        media_type = telegram_media_type(copied)
        if media_type is None:
            raise downloader.DownloadError(
                "That message has no downloadable media."
            )

        # v97.13: copyMessage succeeded — the media is already in the user's
        # chat.  Update the task as done and clean up the status message.
        # No download→upload cycle needed (fastest path).
        await repo.update_task(task_id, status="done", progress=100)
        await repo.add_download_history(
            user_id, file_name=_link_extract_filename(copied, media_type) or media_type,
            file_size=0, mime_type=None, media_type=media_type,
            source="link_native_copy", status="done",
            task_id=task_id, message_link=parsed.raw,
        )
        await states.set_last_download(user_id, {
            "file_name": _link_extract_filename(copied, media_type),
            "media_type": media_type, "file_size": 0,
            "file_id": _link_extract_file_id(copied),
        })
        # Clean up the status message.
        try:
            await context.bot.delete_message(chat_id=chat_id, message_id=status_msg_id)
        except Exception:  # noqa: BLE001
            pass
        logger.info("LINK_DOWNLOAD_NATIVE_COPY_OK user=%s msg_id=%s — copyMessage delivered",
                    user_id, msg_id)
        return

    except _LinkDownloadError as exc:
        # copyMessage failed — if it's a protected-content error, show the
        # clear restriction message.  Otherwise, fall through to the
        # download→upload path below.
        _err_str = str(exc).lower()
        if any(_kw in _err_str for _kw in (
            "forwarding restricted", "content protected",
            "message to copy not found", "message to forward not found",
            "not a member", "doesn't have permission",
        )):
            await _link_edit(context, chat_id, status_msg_id,
                             msg.link_download_failed_text(md_escape(str(exc))),
                             reply_markup=kb.download_menu())
            await repo.update_task(task_id, status="failed", progress=0)
            return
        # Other errors (network, flood) → fall through to download→upload
        logger.info("LINK_DOWNLOAD_COPY_FAILED_FALLBACK user=%s exc=%s — trying download→upload",
                    user_id, type(exc).__name__)

    # 2) Fallback: download via MTProto (if available) or Bot API getFile.
    # This path is only reached when copyMessage failed with a transient error.
    try:
        await _link_edit(context, chat_id, status_msg_id,
                         "📥 Downloading media…")
        # v97.13: use MTProto download if available (handles restricted content
        # the Bot API can't access).  Otherwise, try Bot API getFile.
        if mtproto_manager.is_started() and (parsed.username or parsed.chat_id):
            _chat_ref = (f"@{parsed.username}" if parsed.username
                         else parsed.chat_id)
            path, name, mtype, size = await mtproto_service.download_message_media(
                _chat_ref, msg_id,
            )
        else:
            # Bot API getFile fallback (requires a copied message).
            # Re-try copy_message first to get a fresh copy.
            copied = await _link_copy_with_retries(context, chat_id, from_chat, msg_id)
            async with media_processor.download_slot():
                path, name, mtype, size = await downloader.download_forwarded(
                    copied, progress=None, bot=context.bot,
                )

        await repo.update_task(task_id, status="done", progress=100)

        # 3) Send the file back as a document (preserves original filename).
        send_caption = msg.download_done_text(md_escape(name), size, mtype)
        result = await media_processor.send_file_back(chat_id, path, send_caption, context)

        if result == "too_large":
            await safe_send_message(
                context.bot, chat_id,
                text="ℹ️ The file is too large to send back via the Bot API.",
                reply_markup=kb.main_menu(),
            )
        elif result.startswith("error"):
            await safe_send_message(
                context.bot, chat_id,
                text=(f"⚠️ Could not send the file: "
                      f"`{md_escape(result[6:])}`"),
                reply_markup=kb.main_menu(),
            )

        # 4) Persist to download history.
        await repo.add_download_history(
            user_id, file_name=name, file_size=size, mime_type=None,
            media_type=mtype, source="link_fallback", status="done",
            task_id=task_id, message_link=parsed.raw,
        )

        # v97.19: Store the file_id in the media cache for instant resend
        # on repeat requests.  send_file_back now returns "ok|file_id|file_unique_id".
        if result.startswith("ok"):
            _parts = result.split("|", 2)
            _cache_file_id = _parts[1] if len(_parts) > 1 else None
            _cache_file_unique_id = _parts[2] if len(_parts) > 2 else None
            if _cache_file_id:
                try:
                    await repo.media_cache_store(
                        _cache_source, msg_id,
                        file_id=_cache_file_id,
                        file_unique_id=_cache_file_unique_id,
                        file_name=name, file_size=size,
                        media_type=mtype,
                        caption=(caption if 'caption' in dir() else None),
                    )
                    logger.info("MEDIA_CACHE_STORED source=%s msg_id=%s file=%s "
                                "size=%d file_id=%s...",
                                _cache_source, msg_id, name, size,
                                _cache_file_id[:20])
                except Exception:  # noqa: BLE001
                    pass

            # Log download+upload metrics.
            _total_t = time.monotonic() - _t_start
            _mbps = (size / (1024 * 1024)) / _total_t if _total_t > 0 else 0
            logger.info("DOWNLOAD_METRICS source=%s msg_id=%s file=%s size=%d "
                        "total_duration=%.2fs avg_mbps=%.1f result=ok",
                        _cache_source, msg_id, name, size, _total_t, _mbps)

        # Stash for Library bookmark + auto-delete.
        await states.set_last_download(user_id, {
            "file_name": name, "media_type": mtype, "file_size": size,
            "file_id": None,
        })

        # Auto-delete the temp file if configured.
        settings = await repo.ensure_settings(user_id)
        if settings.get("auto_delete"):
            await remove_path(path)

    except downloader.FileTooLarge as exc:
        await _link_edit(context, chat_id, status_msg_id,
                         msg.file_too_big_text(config.max_file_size_mb),
                         reply_markup=kb.download_menu())
        await repo.update_task(task_id, status="failed", error=str(exc))
        await repo.add_download_history(
            user_id, file_name=parsed.raw, file_size=0, mime_type=None,
            media_type="link", source="link", status="failed",
            task_id=task_id, message_link=parsed.raw,
        )
    except _LinkDownloadError as exc:
        await _link_edit(context, chat_id, status_msg_id,
                         msg.link_download_failed_text(md_escape(str(exc))),
                         reply_markup=kb.download_menu())
        await repo.update_task(task_id, status="failed", error=str(exc))
        await repo.add_download_history(
            user_id, file_name=parsed.raw, file_size=0, mime_type=None,
            media_type="link", source="link", status="failed",
            task_id=task_id, message_link=parsed.raw,
        )
    except Exception as exc:  # noqa: BLE001
        logger.exception("link download failed: %s", exc)
        await _link_edit(context, chat_id, status_msg_id,
                         msg.link_download_failed_text(md_escape(str(exc))),
                         reply_markup=kb.download_menu())
        await repo.update_task(task_id, status="failed", error=str(exc))
        await repo.add_download_history(
            user_id, file_name=parsed.raw, file_size=0, mime_type=None,
            media_type="link", source="link", status="failed",
            task_id=task_id, message_link=parsed.raw,
        )
    finally:
        # TG-H-010: always reset the FSM state so the user isn't stuck.
        try:
            await states.reset(user_id)
        except Exception:  # noqa: BLE001
            logger.debug("states.reset failed in _link_run_download finally", exc_info=True)
        if path and path.exists():
            try:
                await remove_path(path)
            except Exception:  # noqa: BLE001
                pass


async def _link_copy_with_retries(context, chat_id, from_chat, msg_id):
    """Call copyMessage with smart retries.

    Retries ONLY on transient errors (RetryAfter, NetworkError, TimedOut).
    Permanent errors (BadRequest \"not found\", Forbidden, content-protected)
    fail immediately with a clear, specific user-facing message — no retry.
    """
    max_retries = config.max_retries
    base_delay = 2.0
    last_exc: Exception | None = None

    for attempt in range(1, max_retries + 1):
        try:
            return await context.bot.copy_message(
                chat_id=chat_id,
                from_chat_id=from_chat,
                message_id=msg_id,
            )
        except RetryAfter as exc:
            # Rate-limited — sleep and retry (this IS retriable).
            wait = min(exc.retry_after + 1, 60)  # TG-H-002: cap wait at 60s.
            logger.info("Rate limited on copyMessage: %ss (attempt %d/%d)",
                        exc.retry_after, attempt, max_retries)
            await asyncio.sleep(wait)
            last_exc = exc
            continue
        except BadRequest as exc:
            # BadRequest is PERMANENT — never retry. Map to a clear message.
            raise _link_map_copy_bad_request(exc, from_chat, msg_id) from exc
        except Forbidden as exc:
            # Forbidden is PERMANENT — never retry.
            exc_text = str(exc).lower()
            if "not a member" in exc_text or "bot is not a member" in exc_text:
                raise _LinkDownloadError(
                    "The bot is not a member of that chat. For private "
                    "channels or groups, you must add the bot as a member "
                    "first (or make it an admin)."
                ) from exc
            raise _LinkDownloadError(
                "The bot doesn't have permission to read that chat."
            ) from exc
        except (NetworkError, TimedOut) as exc:
            # Transient — retry with back-off.
            last_exc = exc
            if attempt < max_retries:
                delay = min(base_delay * (2 ** (attempt - 1)), 30.0)
                logger.info("Network error on copyMessage (attempt %d/%d), "
                            "retrying in %.1fs: %s", attempt, max_retries, delay, exc)
                await asyncio.sleep(delay)
                continue
            raise _LinkDownloadError(
                f"Network error after {max_retries} retries: {exc}"
            ) from exc
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            # Unknown error — don't retry, surface it.
            raise _LinkDownloadError(f"Unexpected error: {exc}") from exc

    # Exhausted retries on a transient error.
    raise _LinkDownloadError(
        f"Request failed after {max_retries} retries: {last_exc}"
    )


def _link_map_copy_bad_request(exc: BadRequest, from_chat, msg_id: int) -> _LinkDownloadError:
    """Map a copyMessage BadRequest to the most helpful user-facing message."""
    msg_text = str(exc).lower()

    # Content-protected channel (restricted content).
    # Telegram blocks copying/saving from protected channels. The error
    # message is often "message to copy not found" even though the message
    # exists — this is intentional obfuscation by Telegram.
    if ("message to copy not found" in msg_text
            or "message not found" in msg_text
            or "message to forward not found" in msg_text):
        return _LinkDownloadError(
            f"❌ Cannot download message #{msg_id}.\n\n"
            "This is usually one of:\n"
            "• The channel has *content protection* enabled (restricted "
            "content) — Telegram blocks bots from copying/saving these.\n"
            "• The message was deleted or doesn't exist.\n"
            "• The message id is wrong.\n\n"
            "_Content-protected channels cannot be downloaded by any bot — "
            "this is a Telegram platform limitation._"
        )

    # Chat not accessible.
    if "chat not found" in msg_text:
        return _LinkDownloadError(
            "The bot cannot access that chat. This means either:\n"
            "• The chat doesn't exist or the username is wrong\n"
            "• It's a private chat and the bot hasn't been added as a member\n"
            "• The channel has restricted who can view its content"
        )

    # Bot blocked by user.
    if "bot was blocked by the user" in msg_text:
        return _LinkDownloadError(
            "The bot was blocked by the user. Please /start the bot first."
        )

    # Content forwarding restricted.
    if "forwarding" in msg_text and "restrict" in msg_text:
        return _LinkDownloadError(
            "This channel has *restricted forwarding* — Telegram prevents "
            "bots from copying or downloading its content."
        )

    # Generic fallback.
    return _LinkDownloadError(f"Telegram rejected the request: {exc}")


async def _link_resolve_and_ask_message_id(update: Update,
                                           context: ContextTypes.DEFAULT_TYPE,
                                           parsed: link_parser.ParsedInput) -> None:
    user_id = update.effective_user.id
    status = await safe_reply_text(update.message, "🔍 Resolving chat…")
    if status is None:
        return

    # If MTProto is available and the input is a @username or channel link,
    # route to the media browser (category browsing + Download All).
    if mtproto_manager.is_started() and (parsed.username or parsed.chat_id):
        chat_ref = (f"@{parsed.username}" if parsed.username
                    else parsed.chat_id)
        # Delete the "Resolving…" status and hand off to the media browser.
        try:
            await context.bot.delete_message(chat_id=status.chat_id,
                                             message_id=status.message_id)
        except Exception:  # noqa: BLE001
            pass
        await media_browser_handler.show_categories(update, context, chat_ref)
        return

    # For public usernames, resolve via getChat to confirm + show info.
    if parsed.username:
        try:
            chat = await _link_get_chat_with_retries(context, f"@{parsed.username}")
        except _LinkDownloadError as exc:
            await _link_edit(context, status.chat_id, status.message_id,
                             msg.link_download_failed_text(md_escape(str(exc))),
                             reply_markup=kb.download_menu())
            return
        info = _link_chat_info_dict(chat)
        # Stash the resolved reference for the message-id step.
        context.user_data["link_from_chat"] = f"@{parsed.username}"
        context.user_data["link_chat_info"] = info
        await _link_edit(context, status.chat_id, status.message_id,
                         msg.link_resolved_ask_msgid(_link_escape_info(info)),
                         reply_markup=kb.cancel_back("dl"))
    elif parsed.chat_id is not None:
        # Raw chat id or private channel link — try getChat.
        try:
            chat = await _link_get_chat_with_retries(context, parsed.chat_id)
            info = _link_chat_info_dict(chat)
        except _LinkDownloadError as exc:
            # Even if getChat fails, we can still try copyMessage with the id.
            info = {"title": str(parsed.chat_id), "type": "chat",
                    "chat_id": parsed.chat_id}
        context.user_data["link_from_chat"] = parsed.chat_id
        context.user_data["link_chat_info"] = info
        await _link_edit(context, status.chat_id, status.message_id,
                         msg.link_resolved_ask_msgid(_link_escape_info(info)),
                         reply_markup=kb.cancel_back("dl"))
    else:
        await _link_edit(context, status.chat_id, status.message_id,
                         msg.link_parse_error_text("Cannot resolve that input."),
                         reply_markup=kb.download_menu())

    # Switch to the message-id-awaiting state.
    await states.set_state(user_id, states.AWAIT_LINK_MESSAGE_ID)


async def link__handle_message_id_input(update: Update,
                                        context: ContextTypes.DEFAULT_TYPE) -> None:
    """User sent a message id after we resolved a channel/username."""
    user_id = update.effective_user.id
    text = (update.message.text or "").strip()
    try:
        msg_id = int(text)
    except ValueError:
        await safe_reply_text(
            update.message,
            "⚠️ Please send a numeric message id (e.g. `123`). "
            "You can find it in the original t.me link.",
            reply_markup=kb.cancel_back("dl"),
        )
        return
    if msg_id <= 0:
        await safe_reply_text(
            update.message,
            "⚠️ Message id must be a positive number.",
            reply_markup=kb.cancel_back("dl"),
        )
        return

    from_chat = context.user_data.get("link_from_chat")
    if not from_chat:
        await safe_reply_text(
            update.message,
            "⚠️ Session expired. Please send the link or @username again.",
            reply_markup=kb.download_menu(),
        )
        await states.reset(user_id)
        return

    # Build a synthetic ParsedInput and reuse the message-link path.
    parsed = link_parser.ParsedInput(
        kind=link_parser.KIND_MESSAGE_LINK,
        visibility=link_parser.VIS_PUBLIC if isinstance(from_chat, str) else link_parser.VIS_PRIVATE,
        username=from_chat.lstrip("@") if isinstance(from_chat, str) else None,
        chat_id=from_chat if isinstance(from_chat, int) else None,
        message_id=msg_id,
        raw=f"{from_chat}/{msg_id}",
    )
    # TG-H-010: ensure the FSM is always released, even if the downstream
    # download path raises an unhandled exception.
    try:
        await _link_download_message_link(update, context, parsed)
    finally:
        try:
            await states.reset(user_id)
        except Exception:  # noqa: BLE001
            logger.debug("states.reset failed in link__handle_message_id_input finally",
                         exc_info=True)


async def _link_get_chat_with_retries(context, chat_ref):
    """Resolve a chat via getChat with SMART retries.

    Retries ONLY on transient errors (RetryAfter, NetworkError, TimedOut).
    Permanent errors (BadRequest \"not found\", Forbidden) fail immediately —
    no wasted retries.
    """
    max_retries = min(config.max_retries, 3)
    base_delay = 2.0
    last_exc: Exception | None = None

    for attempt in range(1, max_retries + 1):
        try:
            return await context.bot.get_chat(chat_ref)
        except RetryAfter as exc:
            wait = min(exc.retry_after + 1, 60)  # TG-H-002: cap wait at 60s.
            logger.info("Rate limited on getChat: %ss (attempt %d/%d)",
                        exc.retry_after, attempt, max_retries)
            await asyncio.sleep(wait)
            last_exc = exc
            continue
        except BadRequest as exc:
            # Permanent — don't retry.
            msg_text = str(exc).lower()
            logger.info("get_chat failed for %s: %s", chat_ref, exc)
            if "chat not found" in msg_text:
                raise _LinkDownloadError(
                    f"Chat {chat_ref} was not found. It may not exist, is "
                    "private, or the bot cannot access it."
                ) from exc
            raise _LinkDownloadError(f"Telegram rejected getChat: {exc}") from exc
        except Forbidden as exc:
            raise _LinkDownloadError(
                "The bot doesn't have permission to access that chat. "
                "Private chats require the bot to be a member."
            ) from exc
        except (NetworkError, TimedOut) as exc:
            last_exc = exc
            if attempt < max_retries:
                delay = min(base_delay * (2 ** (attempt - 1)), 30.0)
                logger.info("Network error on getChat (attempt %d/%d), "
                            "retrying in %.1fs", attempt, max_retries, delay)
                await asyncio.sleep(delay)
                continue
            raise _LinkDownloadError(
                f"Network error after {max_retries} retries: {exc}"
            ) from exc
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise _LinkDownloadError(f"Failed to resolve chat: {exc}") from exc

    raise _LinkDownloadError(
        f"Request failed after {max_retries} retries: {last_exc}"
    )


def _link_chat_info_dict(chat) -> dict:
    return {
        "title": getattr(chat, "title", None),
        "type": getattr(chat, "type", None),
        "username": getattr(chat, "username", None),
        "first_name": getattr(chat, "first_name", None),
        "last_name": getattr(chat, "last_name", None),
        "chat_id": getattr(chat, "id", None),
        "members": getattr(chat, "member_count", None),
        "description": getattr(chat, "description", None),
        "bio": getattr(chat, "bio", None),
    }


def _link_escape_info(info: dict) -> dict:
    """Return a copy of *info* with all string values Markdown-escaped."""
    out = {}
    for k, v in info.items():
        if isinstance(v, str):
            out[k] = md_escape(v)
        else:
            out[k] = v
    return out


def _link_extract_filename(message, media_type: str) -> str | None:
    """Pull the original filename from a PTB message, if available."""
    for attr in ("document", "video", "audio", "animation",
                 "voice", "video_note"):
        cand = getattr(message, attr, None)
        if cand is not None and getattr(cand, "file_name", None):
            return cand.file_name
    if message.photo:
        return None  # photos have no filename
    return None


def _link_extract_file_id(message) -> str | None:
    for attr in ("document", "video", "audio", "animation",
                 "voice", "video_note"):
        cand = getattr(message, attr, None)
        if cand is not None and getattr(cand, "file_id", None):
            return cand.file_id
    if message.photo:
        return message.photo[-1].file_id
    return None


async def _link_edit(context, chat_id: int, message_id: int, text: str,
                     reply_markup=None) -> None:
    """Safe edit — tries Markdown, falls back to plain text on parse error."""
    await safe_edit_message_text(
        context.bot, chat_id, message_id, text,
        reply_markup=reply_markup,
    )


# ===========================================================================
# Handlers — media_browser (channel category browsing + Download All)
# ===========================================================================
# Activated when a user enters a @username or channel link (without a message
# id) in the Download menu and MTProto is available. Flow:
#
#   1. User sends `@channel` in link-download mode
#   2. Bot resolves via MTProto, scans recent history, shows media categories
#   3. User taps a category (e.g. "🎬 Videos (12)")
#   4. Bot shows the list of items + a "Download All" button
#   5. User taps "Download All" or taps an individual item id
#   6. Bot downloads via MTProto with progress, sends files back
#
# This runs on top of the existing MTProto backend; the Bot API handles all UX.
# ===========================================================================


async def mb__show_categories(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              chat_ref) -> None:
    """Resolve a channel via MTProto, scan history, show media categories."""
    chat_id = update.effective_chat.id

    status_msg = await safe_reply_text(
        update.message, "📂 Scanning channel media via MTProto…"
    )
    if status_msg is None:
        return

    try:
        # Resolve + scan.
        info = await mtproto_service.resolve_entity(chat_ref)
        by_cat = await media_browser.scan_channel_media(chat_ref, limit=100)
    except mtproto_service.MTProtoError as exc:
        await safe_edit_message_text(
            context.bot, status_msg.chat_id, status_msg.message_id,
            f"❌ `{md_escape(str(exc))}`",
            reply_markup=kb.download_menu(),
        )
        return
    except Exception as exc:  # noqa: BLE001
        logger.exception("media scan failed: %s", exc)
        await safe_edit_message_text(
            context.bot, status_msg.chat_id, status_msg.message_id,
            f"❌ Error: `{md_escape(str(exc))}`",
            reply_markup=kb.download_menu(),
        )
        return

    # Stash for the category/menu steps.
    context.user_data["mb_chat_ref"] = chat_ref
    context.user_data["mb_by_cat"] = by_cat
    context.user_data["mb_chat_info"] = info

    title = md_escape(info.get("title") or info.get("first_name")
                      or str(info.get("id", chat_ref)))
    uname = info.get("username")
    uname_s = f"@{md_escape(uname)}" if uname else "—"
    summary = media_browser.scan_summary(by_cat)

    # Build a keyboard with one button per non-empty category.
    rows: list[list[InlineKeyboardButton]] = []
    for cat_key in media_browser.CATEGORY_KEYS:
        if cat_key in by_cat:
            count = len(by_cat[cat_key])
            label = f"{media_browser.category_label(cat_key)} ({count})"
            rows.append([InlineKeyboardButton(label, callback_data=f"mb:cat:{cat_key}")])
    rows.append([InlineKeyboardButton("🔙 Back to Download", callback_data="b:dl")])
    markup = InlineKeyboardMarkup(rows)

    text = (
        f"📂 *Channel media browser*\n\n"
        f"📛 *Name:* {title}\n"
        f"🔗 *Username:* {uname_s}\n\n"
        f"{summary}\n\n"
        f"_Tap a category to browse and download._"
    )
    await safe_edit_message_text(
        context.bot, status_msg.chat_id, status_msg.message_id,
        text, reply_markup=markup,
    )


async def mb__show_category_items(update: Update,
                                  context: ContextTypes.DEFAULT_TYPE,
                                  category: str) -> None:
    """Show the list of media items in a category with a Download All button."""
    by_cat = context.user_data.get("mb_by_cat") or {}
    items = by_cat.get(category, [])
    if not items:
        await update.callback_query.answer("No items in this category.")
        return

    await update.callback_query.answer()
    label = media_browser.category_label(category)
    lines = [f"{label} — *{len(items)} items*", ""]
    for i, item in enumerate(items[:20], 1):  # show first 20
        mid = item.get("message_id", "?")
        date_s = (item.get("date") or "")[:10]
        text_prev = (item.get("text") or "").replace("\n", " ")[:40]
        lines.append(f"`{mid}` · {date_s} · {text_prev}")
    if len(items) > 20:
        lines.append(f"\n_…and {len(items) - 20} more. Use Download All._")

    rows: list[list[InlineKeyboardButton]] = []
    # Individual item buttons (first 10 for quick access).
    for item in items[:10]:
        mid = item.get("message_id")
        rows.append([InlineKeyboardButton(
            f"#{mid}", callback_data=f"mb:one:{mid}"
        )])
    rows.append([InlineKeyboardButton(
        f"⬇️ Download All ({len(items)})", callback_data=f"mb:all:{category}"
    )])
    rows.append([InlineKeyboardButton("🔙 Back", callback_data="mb:back")])
    markup = InlineKeyboardMarkup(rows)

    # v97.25 FIX: use safe_edit_message_text (Markdown + plain-text fallback)
    # instead of raw edit_message_text.  The old code raised
    # "Can't parse entities: can't find end of the entity starting at byte
    # offset 88" when message text contained unescaped Markdown special
    # characters (underscores, asterisks, etc.).
    await safe_edit_message_text(
        context.bot, update.effective_chat.id,
        update.callback_query.message.message_id,
        "\n".join(lines),
        reply_markup=markup,
    )


async def mb__download_single(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              message_id: int) -> None:
    chat_ref = context.user_data.get("mb_chat_ref")
    if not chat_ref:
        await update.callback_query.answer("Session expired. Restart.")
        return
    # v97.23: diagnostic logging — trace the exact source chat + message ID
    # from the media browser selection to the MTProto download pipeline.
    logger.info(
        "MEDIA_ITEM_SELECTED user=%s source_chat_ref=%s source_message_id=%s "
        "media_browser=mb__download_single",
        update.effective_user.id, chat_ref, message_id,
    )
    await update.callback_query.answer("Downloading…")
    status_msg_id = update.callback_query.message.message_id
    chat_id = update.effective_chat.id

    await safe_edit_message_text(
        context.bot, chat_id, status_msg_id,
        f"📥 Downloading message #{message_id} via MTProto…",
    )
    logger.info(
        "MEDIA_DOWNLOAD_REQUEST_CREATED source_chat_ref=%s source_message_id=%s "
        "user=%s chat_id=%s",
        chat_ref, message_id, update.effective_user.id, chat_id,
    )
    # v97.24: get the scan account from user_data (stored during scan).
    _by_cat = context.user_data.get("mb_by_cat") or {}
    _scan_account = ""
    for _cat_items in _by_cat.values():
        for _item in _cat_items:
            if _item.get("message_id") == message_id:
                _scan_account = _item.get("scan_account_id") or ""
                break
        if _scan_account:
            break

    result = await media_browser.download_one(
        chat_ref, message_id, preferred_account_id=_scan_account,
    )
    if result.get("ok"):
        path = result["path"]
        name = result["filename"]
        size = result["size"]
        mtype = result["media_type"]
        caption = (
            f"✅ *Downloaded via MTProto*\n\n"
            f"📄 `{md_escape(name)}`\n"
            f"📦 {human_size(size)}\n"
            f"🗂 {mtype}\n"
            f"🆔 Message: `{message_id}`"
        )
        if size <= config.upload_limit_bytes:
            with path.open("rb") as fh:
                await safe_send_document(
                    context.bot, chat_id, fh,
                    filename=name, caption=caption,
                )
        else:
            await safe_send_message(
                context.bot, chat_id,
                caption + "\n\n_ℹ️ Too large for Bot API — saved on server._",
            )
        # Auto-delete if configured.
        settings = await repo.ensure_settings(update.effective_user.id)
        if settings.get("auto_delete"):
            await remove_path(path)
        await safe_edit_message_text(
            context.bot, chat_id, status_msg_id,
            "✅ Done.", reply_markup=kb.mtproto_menu(),
        )
    else:
        await safe_edit_message_text(
            context.bot, chat_id, status_msg_id,
            f"❌ `{md_escape(result.get('error', 'unknown'))}`",
            reply_markup=kb.mtproto_menu(),
        )


async def mb__download_all(update: Update, context: ContextTypes.DEFAULT_TYPE,
                           category: str) -> None:
    chat_ref = context.user_data.get("mb_chat_ref")
    by_cat = context.user_data.get("mb_by_cat") or {}
    items = by_cat.get(category, [])
    if not chat_ref or not items:
        await update.callback_query.answer("Session expired or no items.")
        return

    await update.callback_query.answer(f"Downloading {len(items)} items…")
    chat_id = update.effective_chat.id
    status_msg_id = update.callback_query.message.message_id

    label = media_browser.category_label(category)
    dedup: set[int] = set()

    # RELI-I-006: fetch the user's settings ONCE up-front (the auto_delete
    # preference does not change mid-bulk-download) and pass the resolved
    # boolean into the per-item callback. Previously this called
    # ensure_settings() per-item inside item_done_cb, which added a DB
    # round-trip per downloaded file and could cause a thundering-herd of
    # concurrent SQLite reads for large bulk downloads.
    cached_settings = await repo.ensure_settings(update.effective_user.id)
    auto_delete_enabled = bool(cached_settings.get("auto_delete"))

    async def progress_cb(done, total, msg_id, ok):
        pct = done / total * 100 if total else 0
        await safe_edit_message_text(
            context.bot, chat_id, status_msg_id,
            f"⬇️ *{label} bulk download*\n\n"
            f"Progress: {done}/{total} ({pct:.0f}%)\n"
            f"✅ Sending files as they complete…",
        )

    async def item_done_cb(result):
        if result.get("ok"):
            path = result["path"]
            name = result["filename"]
            size = result["size"]
            if size <= config.upload_limit_bytes:
                caption = (
                    f"✅ `{md_escape(name)}`\n"
                    f"📦 {human_size(size)} · 🆔 `{result['message_id']}`"
                )
                try:
                    with path.open("rb") as fh:
                        await safe_send_document(
                            context.bot, chat_id, fh,
                            filename=name, caption=caption,
                        )
                except Exception as exc:  # noqa: BLE001
                    logger.warning("send failed for #%s: %s",
                                   result["message_id"], exc)
            # Auto-delete if configured (uses the cached up-front value).
            if auto_delete_enabled:
                await remove_path(path)

    bulk_result = await media_browser.download_category(
        chat_ref, category, items,
        progress_cb=progress_cb,
        item_done_cb=item_done_cb,
        dedup=dedup,
    )
    await safe_edit_message_text(
        context.bot, chat_id, status_msg_id,
        media_browser.bulk_summary(bulk_result, category),
        reply_markup=kb.mtproto_menu(),
    )


async def mb__back_to_categories(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE) -> None:
    by_cat = context.user_data.get("mb_by_cat") or {}
    info = context.user_data.get("mb_chat_info") or {}
    chat_ref = context.user_data.get("mb_chat_ref", "channel")
    await update.callback_query.answer()
    title = md_escape(info.get("title") or info.get("first_name")
                      or str(info.get("id", chat_ref)))
    uname = info.get("username")
    uname_s = f"@{md_escape(uname)}" if uname else "—"
    summary = media_browser.scan_summary(by_cat)

    rows: list[list[InlineKeyboardButton]] = []
    for cat_key in media_browser.CATEGORY_KEYS:
        if cat_key in by_cat:
            count = len(by_cat[cat_key])
            label = f"{media_browser.category_label(cat_key)} ({count})"
            rows.append([InlineKeyboardButton(label, callback_data=f"mb:cat:{cat_key}")])
    rows.append([InlineKeyboardButton("🔙 Back to Download", callback_data="b:dl")])
    markup = InlineKeyboardMarkup(rows)

    await update.callback_query.edit_message_text(
        text=(f"📂 *Channel media browser*\n\n"
              f"📛 *Name:* {title}\n"
              f"🔗 *Username:* {uname_s}\n\n"
              f"{summary}\n\n_Tap a category to browse and download._"),
        reply_markup=markup,
        parse_mode="Markdown",
    )


# ===========================================================================
# Handlers — vc_admin (Task ID 12)
# ===========================================================================
# Admin-only controls for the VC tour subsystem. Accessible from the existing
# admin menu via a new "🎙 VC Control" button. All actions delegate to the
# ``vc_tour`` namespace defined in the Services section above.
# ===========================================================================


download_handler = SimpleNamespace(
    enter_forward_mode=download__enter_forward_mode,
    handle_forwarded_media=download__handle_forwarded_media,
)

analyze_handler = SimpleNamespace(
    enter_analyze_mode=analyze__enter_analyze_mode,
    show_modes=analyze__show_modes,
    set_mode=analyze__set_mode,
    handle_forwarded_video=analyze__handle_forwarded_video,
)

history_handler = SimpleNamespace(
    show_downloads=history__show_downloads,
    show_ai=history__show_ai,
    clear=history__clear,
)

settings_handler = SimpleNamespace(
    handle_setting=settings__handle_setting,
    handle_gemini_key_input=settings__handle_gemini_key_input,
)

help_handler = SimpleNamespace(
    show_section=help__show_section,
)

inspector_handler = SimpleNamespace(
    enter_inspect_mode=inspector__enter_inspect_mode,
    show_recent=inspector__show_recent,
    handle_inspect_input=inspector__handle_inspect_input,
)

toolbox_handler = SimpleNamespace(
    handle_tool_selection=toolbox__handle_tool_selection,
    handle_forwarded_media=toolbox__handle_forwarded_media,
    handle_imgconv_format=toolbox__handle_imgconv_format,
)

library_handler = SimpleNamespace(
    show_menu=library__show_menu,
    handle_action=library__handle_action,
    handle_search_input=library__handle_search_input,
)

stats_handler = SimpleNamespace(
    show_menu=stats__show_menu,
    show_user=stats__show_user,
    show_global=stats__show_global,
)

qr_handler = SimpleNamespace(
    show_menu=qr__show_menu,
    enter_make_mode=qr__enter_make_mode,
    handle_input=qr__handle_input,
)

batch_handler = SimpleNamespace(
    enter_batch_mode=batch__enter_batch_mode,
    handle_batch_message=batch__handle_batch_message,
)

scheduled_handler = SimpleNamespace(
    show_menu=scheduled__show_menu,
    show_list=scheduled__show_list,
    handle_schedule_input=scheduled__handle_schedule_input,
    queue_scheduled=scheduled__queue_scheduled,
    run_due_tasks=scheduled__run_due_tasks,
)

backup_handler = SimpleNamespace(
    show_menu=backup__show_menu,
    do_export=backup__do_export,
    enter_import=backup__enter_import,
    handle_import_file=backup__handle_import_file,
)

admin_handler = SimpleNamespace(
    show_menu=admin__show_menu,
    list_users=admin__list_users,
    global_stats=admin__global_stats,
    export_global=admin__export_global,
    enter_broadcast=admin__enter_broadcast,
    handle_broadcast=admin__handle_broadcast,
)

inline_handler = SimpleNamespace(
    handle_inline=inline__handle_inline,
)

link_handler = SimpleNamespace(
    enter_link_mode=link__enter_link_mode,
    handle_input=link__handle_input,
    handle_message_id_input=link__handle_message_id_input,
)

mtproto_handler = SimpleNamespace(
    show_menu=mtproto__show_menu,
    start=mtproto__start,
    stop=mtproto__stop,
    restart=mtproto__restart,
    refresh_status=mtproto__refresh_status,
    enter_screenshot_mode=mtproto__enter_screenshot_mode,
    handle_screenshot_input=mtproto__handle_screenshot_input,
    enter_download_mode=mtproto__enter_download_mode,
    handle_download_input=mtproto__handle_download_input,
    handle_msgid_input=mtproto__handle_msgid_input,
)

media_browser_handler = SimpleNamespace(
    show_categories=mb__show_categories,
    show_category_items=mb__show_category_items,
    download_single=mb__download_single,
    download_all=mb__download_all,
    back_to_categories=mb__back_to_categories,
)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # RUNTIME_DEBUG: trace update receipt → handler start → reply
    from .runtime_debug import is_debug_enabled, log_handler_start, log_handler_end
    _dbg_id = getattr(update, 'update_id', 0)
    if is_debug_enabled():
        log_handler_start(_dbg_id, "start_command")
    user = update.effective_user
    if user is None:
        if is_debug_enabled():
            log_handler_end(_dbg_id, "start_command", success=False)
        return
    is_admin = user.id in config.admin_ids
    try:
        _dbg_t2 = time.monotonic() if is_debug_enabled() else 0
        await repo.upsert_user(user.id, user.username, user.first_name, is_admin)
        if is_debug_enabled() and _dbg_t2:
            _dbg_dur2 = time.monotonic() - _dbg_t2
            if _dbg_dur2 > 0.1:
                logger.warning("RUNTIME_DEBUG: start_command upsert_user SLOW duration=%.3fs", _dbg_dur2)
    except Exception as exc:
        logger.warning("start_command: upsert_user failed (non-fatal): %s", exc)
    try:
        await repo.ensure_settings(user.id)
    except Exception as exc:
        logger.warning("start_command: ensure_settings failed (non-fatal): %s", exc)
    try:
        await states.reset(user.id)
    except Exception as exc:
        logger.warning("start_command: states.reset failed (non-fatal): %s", exc)

    text = msg.WELCOME if not update.callback_query else msg.MAIN_MENU_TEXT
    try:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=text,
            reply_markup=kb.main_menu(),
            parse_mode="Markdown",
        )
    except Exception as exc:
        # If Markdown fails, retry as plain text.
        logger.warning("start_command: send_message failed (Markdown): %s — retrying plain text", exc)
        try:
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=text,
                reply_markup=kb.main_menu(),
            )
        except Exception as exc2:
            logger.error("start_command: plain text send also failed: %s", exc2)
    if is_debug_enabled():
        log_handler_end(_dbg_id, "start_command")


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text=msg.HELP_MENU_TEXT,
        reply_markup=kb.help_menu(),
        parse_mode="Markdown",
    )


async def _menu_edit(update: Update, text: str, markup: InlineKeyboardMarkup) -> None:
    q = update.callback_query
    # V40 Fix #1: bump the UI view-token so any stale background refresher
    # for this message stops itself before overwriting the new view.
    try:
        if q is not None and q.message is not None and update.effective_chat is not None:
            _ui_invalidate(update.effective_chat.id, q.message.message_id)
    except Exception:  # noqa: BLE001
        pass
    try:
        await q.edit_message_text(text=text, reply_markup=markup, parse_mode="Markdown")
    except Exception as exc:  # noqa: BLE001
        logger.debug("edit_message_text failed: %s", exc)


async def _menu_answer(update: Update, text: str | None = None) -> None:
    try:
        await update.callback_query.answer(text)
    except Exception:  # noqa: BLE001
        pass


async def route_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # RUNTIME_DEBUG: trace callback receipt → handler start → end
    from .runtime_debug import is_debug_enabled, log_handler_start, log_handler_end
    _dbg_id = getattr(update, 'update_id', 0)
    if is_debug_enabled():
        log_handler_start(_dbg_id, "route_callback")
    q = update.callback_query
    if q is None or q.data is None:
        if is_debug_enabled():
            log_handler_end(_dbg_id, "route_callback", success=False)
        return
    data: str = q.data
    user = update.effective_user
    if user:
        is_admin = user.id in config.admin_ids
        # RUNTIME_DEBUG: trace DB call
        _dbg_t = time.monotonic() if is_debug_enabled() else 0
        await repo.upsert_user(user.id, user.username, user.first_name, is_admin)
        if is_debug_enabled() and _dbg_t:
            _dbg_dur = time.monotonic() - _dbg_t
            if _dbg_dur > 0.1:
                logger.warning("RUNTIME_DEBUG: route_callback upsert_user SLOW duration=%.3fs", _dbg_dur)

    # V64 Fix: log callback receipt for debugging "buttons do nothing".
    logger.debug("CALLBACK_RECEIVED data=%s user=%s", data[:60],
                 getattr(user, "id", "?"))

    try:
        # Phase 19 (Task ID 13) — clear stale Talkative pending-input marker
        # on ANY menu navigation (m:* or b:* or talk:*) so the admin is never
        # "stuck" in a silent wake-word/personality input mode after navigating
        # away.  This is the fix for the P1 pending-input leak.  The marker is
        # also cleared explicitly in the talk:back / talk:menu handlers.
        # V85.3 FIX BUG 2: extend the cleanup to talk:* callbacks too (except
        # talk:wake / talk:personality which intentionally SET the marker).
        if (data.startswith("m:") or data.startswith("b:")) and data not in (
            "m:admin", "b:admin", "adm:talk", "b:talk",
        ):
            if context.user_data:
                context.user_data.pop("talkative_pending_input", None)
                # RELI-I-004: also clear discovery pending-input state so the
                # admin is not stuck in an "Add Query"/"Remove Query"/
                # "gemini_key_replace" prompt after navigating away.
                context.user_data.pop("vc_disc_awaiting_query", None)
                context.user_data.pop("disc_search_type", None)
        elif data.startswith("talk:") and data not in (
            "talk:wake", "talk:personality",
        ):
            if context.user_data:
                context.user_data.pop("talkative_pending_input", None)
                # RELI-I-004: same cleanup for talk:* navigation away from
                # discovery/key-replacement pending prompts.
                context.user_data.pop("vc_disc_awaiting_query", None)
                context.user_data.pop("disc_search_type", None)

        # ---- Menu navigation: m:<menu> ----
        if data == "m:main":
            await states.reset(user.id)
            await _menu_edit(update, msg.MAIN_MENU_TEXT, kb.main_menu())
        elif data == "m:dl":
            await states.reset(user.id)
            await _menu_edit(update, msg.DOWNLOAD_MENU_TEXT, kb.download_menu())
        elif data == "m:ai":
            await states.reset(user.id)
            await _menu_edit(update, msg.ANALYZE_MENU_TEXT, kb.analyze_menu())
        elif data == "m:ins":
            await states.reset(user.id)
            await _menu_edit(update, msg.INSPECTOR_MENU_TEXT, kb.inspector_menu())
        elif data == "m:tb":
            await states.reset(user.id)
            await _menu_edit(update, msg.TOOLBOX_MENU_TEXT, kb.toolbox_menu())
        elif data == "m:lib":
            await states.reset(user.id)
            await _menu_edit(update, msg.LIBRARY_MENU_TEXT, kb.library_menu())
        elif data == "m:st":
            await states.reset(user.id)
            await stats_handler.show_menu(update, context)
        elif data == "m:qr":
            await states.reset(user.id)
            await _menu_edit(update, msg.QR_MENU_TEXT, kb.qr_menu())
        elif data == "m:batch":
            await states.reset(user.id)
            await _menu_edit(update, msg.BATCH_MENU_TEXT, kb.batch_menu())
        elif data == "m:sched":
            await states.reset(user.id)
            await _menu_edit(update, msg.SCHEDULED_MENU_TEXT, kb.scheduled_menu())
        elif data == "m:bk":
            await states.reset(user.id)
            await _menu_edit(update, msg.BACKUP_MENU_TEXT, kb.backup_menu())
        elif data == "m:admin":
            await admin_handler.show_menu(update, context)
        # V67: Userbot Cluster Manager.
        elif data == "cluster:menu":
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # Cancel any pending login.
                if user:
                    cluster_cancel_login(user.id)
                    context.user_data.pop("cluster_awaiting", None)
                await update.callback_query.answer()
                cluster = get_userbot_cluster()
                stats = cluster.get_cluster_stats()
                primary_id = stats.get("primary_id", "")
                primary_line = f"Primary: `{primary_id or '(none)'}`\n" if primary_id else "Primary: _(not set)_\n"
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    f"🤖 *Userbot Manager*\n\n"
                    f"{primary_line}"
                    f"Total accounts: `{stats['total_accounts']}`\n"
                    f"Healthy: `{stats['healthy']}`\n"
                    f"FloodWait: `{stats['floodwait']}`\n"
                    f"Disconnected: `{stats['disconnected']}`\n"
                    f"Disabled: `{stats.get('disabled', 0)}`\n"
                    f"Missing session: `{stats.get('missing_session', 0)}`\n"
                    f"Unauthorized: `{stats.get('unauthorized', 0)}`\n",
                    reply_markup=cluster_menu_kb(),
                )
        elif data == "cluster:cancel_login":
            if user:
                cluster_cancel_login(user.id)
                context.user_data.pop("cluster_awaiting", None)
            await update.callback_query.answer("❌ Login cancelled")
            await safe_edit_message_text(
                context.bot, update.effective_chat.id,
                update.callback_query.message.message_id,
                "❌ Login cancelled.",
                reply_markup=cluster_menu_kb(),
            )
        elif data == "cluster:add":
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                context.user_data["cluster_awaiting"] = "phone"
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "📱 *Add Account*\n\nSend the phone number (with country code, e.g. `+1234567890`):",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("❌ Cancel", callback_data="cluster:menu")],
                    ]),
                )
        elif data == "cluster:import":
            # V69.1: Import existing sessions (scans BOTH data/ and data/sessions/).
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("Scanning data/ + data/sessions/…")
                cluster = get_userbot_cluster()
                report = await cluster.import_existing_sessions()
                reused = report.get("reused_legacy", 0)
                lines = [
                    "📥 *Import Sessions*\n",
                    f"Scanned: `{report['scanned']}`",
                    f"Imported: `{report['imported']}`"
                    + (f" _(incl. {reused} legacy reuse)_" if reused else ""),
                    f"Duplicate: `{report['duplicate']}`",
                    f"Failed: `{report['failed']}`",
                    "",
                ]
                for d in report["details"][:10]:
                    name = d.get("name", d.get("file", ""))
                    st = d.get("status", "?")
                    icon = {"imported": "✅", "duplicate": "⏭️",
                            "unauthorized": "⚠️", "error": "❌",
                            "locked": "🔒", "invalid": "❌"}.get(st, "❓")
                    strategy = d.get("strategy", "")
                    strat_tag = f" ({strategy})" if strategy else ""
                    lines.append(f"{icon} `{name}` — {st}{strat_tag}")
                    if d.get("account_id"):
                        lines.append(f"   → `{d['account_id']}`")
                    if d.get("error"):
                        lines.append(f"   _{d['error'][:80]}_")
                    if d.get("reason"):
                        lines.append(f"   _{d['reason'][:80]}_")
                if len(report["details"]) > 10:
                    lines.append(f"_…and {len(report['details']) - 10} more_")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "\n".join(lines),
                    reply_markup=cluster_menu_kb(),
                )
        elif data == "cluster:list":
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                cluster = get_userbot_cluster()
                accounts = cluster.list_accounts()
                primary_id = cluster.get_primary_id()
                if not accounts:
                    text = "📋 *Accounts*\n\n_No accounts registered._"
                else:
                    lines = ["📋 *Accounts*\n"]
                    # v98.07 FIX-UU: per-account join accounting in the
                    # panel (joins_made / last_floodwait from FIX-RR stats).
                    _v807_stats: dict = {}
                    try:
                        from . import voicechat as _vc_mod
                        _v807_stats = getattr(_vc_mod, "_vc_account_join_stats", {}) or {}
                    except Exception:  # noqa: BLE001
                        pass
                    for acc in accounts:
                        aid = acc["account_id"]
                        icon = _status_icon(acc.get("status", ""))
                        crown = "👑" if aid == primary_id else ""
                        disabled_tag = " ⚫disabled" if acc.get("disabled") else ""
                        lines.append(f"{icon}{crown} `{aid}`{disabled_tag}")
                        lines.append(f"   Phone: `{acc.get('phone', '—')}`")
                        if acc.get("username"):
                            lines.append(f"   Username: @{acc['username']}")
                        lines.append(f"   Role: `{acc.get('role', '—')}`")
                        lines.append(f"   Status: `{_status_label(acc.get('status', ''))}`")
                        # v98.07 FIX-UU: the join-distribution facts.
                        _rec = _v807_stats.get(aid)
                        if isinstance(_rec, dict):
                            _fw = float(_rec.get("last_floodwait", 0.0) or 0.0)
                            lines.append(
                                f"   Joins: `{_rec.get('joins_made', 0)}`"
                                f" (failed `{_rec.get('joins_failed', 0)}`)"
                                + (f" · last FloodWait `{_fw:.0f}s`" if _fw else "")
                            )
                        lines.append("")
                    text = "\n".join(lines)
                    # v98.07 FIX-UU: ACCOUNTS_REPORT — one log line so the
                    # per-account state is ALSO greppable from diagnostics
                    # (file, phone/id, connected, joins_made, last_floodwait,
                    # state — the mandate's /accounts visibility contract).
                    try:
                        import logging as _logging
                        _lg = _logging.getLogger("mediagrab")
                        _parts = []
                        for acc in accounts:
                            _aid = acc.get("account_id", "?")
                            _rec = _v807_stats.get(_aid, {})
                            _parts.append(
                                f"{_aid}:file={acc.get('session_file', '?')}"
                                f":phone={acc.get('phone', '?')}"
                                f":connected={str(acc.get('status', '') in ('healthy', 'connected')).lower()}"
                                f":joins_made={_rec.get('joins_made', 0)}"
                                f":last_floodwait={float(_rec.get('last_floodwait', 0.0) or 0.0):.0f}s"
                                f":state={acc.get('status', '?')}"
                            )
                        _lg.info(
                            "ACCOUNTS_REPORT total=%d primary=%s %s",
                            len(accounts), primary_id or "(none)",
                            " ".join(_parts),
                        )
                    except Exception:  # noqa: BLE001
                        pass
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    text, reply_markup=cluster_menu_kb(),
                )
        elif data == "cluster:stats":
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                cluster = get_userbot_cluster()
                stats = cluster.get_cluster_stats()
                primary_id = stats.get("primary_id", "")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    f"📊 *Cluster Stats*\n\n"
                    f"Primary: `{primary_id or '(none)'}`\n"
                    f"Total accounts: `{stats['total_accounts']}`\n"
                    f"Healthy: `{stats['healthy']}`\n"
                    f"FloodWait: `{stats['floodwait']}`\n"
                    f"Disconnected: `{stats['disconnected']}`\n"
                    f"Disabled: `{stats.get('disabled', 0)}`\n"
                    f"Missing session: `{stats.get('missing_session', 0)}`\n"
                    f"Unauthorized: `{stats.get('unauthorized', 0)}`\n"
                    f"Downloads today: `{stats['downloads_today']}`\n"
                    f"Discovery today: `{stats['discovery_today']}`",
                    reply_markup=cluster_menu_kb(),
                )
        elif data == "cluster:health":
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("Running health check…")
                cluster = get_userbot_cluster()
                accounts = cluster.list_accounts()
                if not accounts:
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        "🩺 *Health Check*\n\n_No accounts to check._",
                        reply_markup=cluster_menu_kb(),
                    )
                else:
                    lines = ["🩺 *Health Check*\n"]
                    for acc in accounts:
                        aid = acc["account_id"]
                        # V67.4: Use the cluster's session resolver.
                        sess = cluster.get_session_info(aid)
                        if not sess["exists"]:
                            lines.append(f"🔴 `{aid}` — missing_session")
                            lines.append(f"   _{sess.get('error', 'file not found')}_")
                            continue
                        # If status is missing_session/invalid, mark and skip reconnect.
                        st = acc.get("status", "")
                        if st in (STATUS_MISSING_SESSION, STATUS_INVALID_SESSION,
                                  STATUS_UNAUTHORIZED, STATUS_BANNED,
                                  STATUS_RESTRICTED, STATUS_DISABLED):
                            lines.append(f"{_status_icon(st)} `{aid}` — {_status_label(st)}")
                            continue
                        # Try to connect if not healthy.
                        if st not in (STATUS_HEALTHY, STATUS_CONNECTED):
                            result = await cluster.connect_account(aid)
                            if result.startswith("connected"):
                                lines.append(f"🟢 `{aid}` — reconnected")
                            elif result == "no_session_file":
                                lines.append(f"🔴 `{aid}` — missing_session")
                            elif result == "not_authorized":
                                lines.append(f"🔴 `{aid}` — unauthorized")
                            elif result == "invalid_session":
                                lines.append(f"🔴 `{aid}` — invalid_session")
                            elif result.startswith("connection_failed"):
                                lines.append(f"🔴 `{aid}` — connection_failed")
                            elif result == "disabled":
                                lines.append(f"⚫ `{aid}` — disabled")
                            else:
                                lines.append(f"🔴 `{aid}` — {result}")
                        else:
                            lines.append(f"🟢 `{aid}` — healthy")
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        "\n".join(lines),
                        reply_markup=cluster_menu_kb(),
                    )
        elif data == "cluster:rotate":
            # V67.4 Part 8: Real account rotation — promote the next healthy account.
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("Rotating primary…")
                cluster = get_userbot_cluster()
                old = cluster.get_primary_id() or "(none)"
                new = cluster.rotate_primary()
                if new:
                    text = (f"🔄 *Primary Rotated*\n\n"
                            f"Old primary: `{old}`\n"
                            f"New primary: `{new}`\n\n"
                            f"_All MTProto operations now route to `{new}`._")
                else:
                    text = ("🔄 *Primary Rotation*\n\n"
                            "❌ No healthy accounts available to rotate to.")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    text, reply_markup=cluster_menu_kb(),
                )
        elif data == "cluster:active":
            # V70.1 §4: Active Account View — shows Primary Registered vs
            # Primary Active so the admin can see the mismatch when an
            # account is registered but connection_failed.
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                cluster = get_userbot_cluster()
                router = get_cluster_router()
                routing = router.get_active_routing()
                # V70.1 §4: Distinguish "registered" primary (persisted in
                # accounts.json) from "active" primary (actually healthy +
                # connected). This is the key fix for the reported bug:
                #   List Accounts: acc_xxx — connection_failed
                #   Active Accounts: Current Primary: (none)
                registered_primary = ""
                try:
                    # Read the raw persisted primary WITHOUT triggering the
                    # auto-assign in get_primary_id().
                    raw = cluster._accounts.get("__primary__", "")
                    # v99.05 RC-F5: the persisted entry is a DICT
                    # ({"account_id": ...}); the legacy bare-string form is
                    # still accepted.
                    if isinstance(raw, str):
                        registered_primary = raw
                    elif isinstance(raw, dict):
                        registered_primary = str(
                            raw.get("account_id", "") or "")
                except Exception:
                    pass
                # Active primary = a registered primary that is actually healthy.
                active_primary = ""
                if registered_primary:
                    acc = cluster.get_account(registered_primary)
                    if acc and not acc.get("disabled") \
                            and acc.get("status") in (STATUS_HEALTHY, STATUS_CONNECTED):
                        active_primary = registered_primary
                # If no active primary, find the first healthy account.
                if not active_primary:
                    healthy = cluster.get_healthy_accounts()
                    if healthy:
                        healthy.sort(key=lambda a: float(a.get("created_at", 0)))
                        active_primary = healthy[0]["account_id"]

                def _name(aid: str) -> str:
                    if not aid:
                        return "_(none)_"
                    acc = cluster.get_account(aid) or {}
                    un = acc.get("username", "") or ""
                    if un:
                        return f"`{aid}` @{un}"
                    return f"`{aid}`"

                lines = ["🎯 *Active Accounts*\n"]
                lines.append(f"Primary Registered: {_name(registered_primary)}")
                lines.append(f"Primary Active: {_name(active_primary)}")
                if registered_primary and not active_primary:
                    acc = cluster.get_account(registered_primary) or {}
                    st = acc.get("status", "—")
                    lines.append("")
                    lines.append(f"⚠️ _Registered primary is `{st}` — not active._")
                    lines.append(f"_Use Health Check → Reconnect to retry._")
                lines.append("")
                lines.append(f"Last Downloader: {_name(routing.get(ROLE_DOWNLOADER, ''))}")
                lines.append(f"Last Discovery: {_name(routing.get(ROLE_DISCOVERY, ''))}")
                lines.append(f"Last Voice Chat: {_name(routing.get(ROLE_VOICE_CHAT, ''))}")
                lines.append(f"Last Backup: {_name(routing.get(ROLE_BACKUP, ''))}")
                lines.append("")
                lines.append("_Updates live as operations route through the cluster._")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "\n".join(lines),
                    reply_markup=cluster_menu_kb(),
                )
        elif data == "cluster:test":
            # V68.2 §14: Test Current Account routing — show Account ID, Phone,
            # Username, Role, AND Session Path for the actual account selected
            # by the router for each role.
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("Testing routing…")
                cluster = get_userbot_cluster()
                router = get_cluster_router()
                lines = ["🧪 *Routing Test*\n"]
                for role in (ROLE_PRIMARY, ROLE_DOWNLOADER, ROLE_DISCOVERY,
                             ROLE_VOICE_CHAT, ROLE_BACKUP):
                    client = router.get_client_for_role(role)
                    aid = router.get_active_routing().get(role, "")
                    if client is None:
                        lines.append(f"{role}: ❌ no client")
                    elif not aid:
                        lines.append(f"{role}: 🟡 legacy mtproto (no cluster account)")
                    else:
                        acc = cluster.get_account(aid) or {}
                        un = acc.get("username", "") or "(none)"
                        ph = acc.get("phone", "") or "(none)"
                        sess = cluster.get_session_info(aid)
                        sp = sess.get("path", "") or acc.get("session_file", "") or "(none)"
                        # Shorten the path for readability.
                        if len(sp) > 48:
                            sp = "…" + sp[-47:]
                        lines.append(f"{role}: ✅ `{aid}`")
                        lines.append(f"   Phone: `{ph}`")
                        lines.append(f"   Username: @{un}")
                        lines.append(f"   Role: `{acc.get('role', '—')}`")
                        lines.append(f"   Session: `{sp}`")
                        lines.append(f"   Size: `{sess.get('size', 0)} bytes`")
                lines.append("")
                lines.append("_If a role shows 'legacy mtproto', the cluster has "
                             "no healthy account for it._")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "\n".join(lines),
                    reply_markup=cluster_menu_kb(),
                )
        elif data == "cluster:details":
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                cluster = get_userbot_cluster()
                accounts = cluster.list_accounts()
                primary_id = cluster.get_primary_id()
                if not accounts:
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        "🔍 *Account Details*\n\n_No accounts registered._",
                        reply_markup=cluster_menu_kb(),
                    )
                else:
                    rows = []
                    for acc in accounts:
                        aid = acc["account_id"]
                        icon = _status_icon(acc.get("status", ""))
                        crown = "👑" if aid == primary_id else ""
                        dis = " ⚫" if acc.get("disabled") else ""
                        rows.append([InlineKeyboardButton(
                            f"{icon}{crown} {aid} — {acc.get('role', '—')}{dis}",
                            callback_data=f"cluster:detail:{aid}",
                        )])
                    rows.append([InlineKeyboardButton("⬅ Back", callback_data="cluster:menu")])
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        "🔍 *Account Details*\n\nSelect an account to view details:",
                        reply_markup=InlineKeyboardMarkup(rows),
                    )
        elif data.startswith("cluster:detail:"):
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                aid = data.split("cluster:detail:")[1]
                cluster = get_userbot_cluster()
                diag = cluster.get_account_diagnostics(aid)
                if not diag.get("found"):
                    await update.callback_query.answer("Account not found", show_alert=True)
                    return
                await update.callback_query.answer()
                lines = [
                    f"🔍 *Account Details*\n",
                    f"Account ID: `{aid}`",
                    f"Phone: `{diag.get('phone', '—')}`",
                    f"Username: @{diag.get('username', '(none)')}",
                    f"User ID: `{diag.get('user_id', 0)}`",
                    f"Role: `{diag.get('role', '—')}`",
                    f"Status: `{_status_label(diag.get('status', ''))}`",
                    f"Authorized: `{'✅' if diag.get('authorized') else '❌'}`",
                    f"Connected: `{'✅' if diag.get('connected') else '❌'}`",
                    f"Disabled: `{'⚫ yes' if diag.get('disabled') else '✅ no'}`",
                    f"Legacy reuse: `{'📦 yes' if diag.get('legacy') else 'no'}`",
                    f"Is Primary: `{'👑 yes' if diag.get('is_primary') else 'no'}`",
                    f"Imported: `{'📥 yes' if diag.get('imported') else 'no'}`",
                    "",
                    f"Session path: `{diag.get('session_path', '—')}`",
                    f"Session exists: `{'✅' if diag.get('session_exists') else '❌ Missing'}`",
                    f"Session size: `{diag.get('session_size', 0)} bytes`",
                    "",
                    f"Last connect attempt: `{diag.get('last_connect_attempt_iso', '(never)')}`",
                ]
                if diag.get("last_exception_type"):
                    lines.append(f"Last exception type: `{diag['last_exception_type']}`")
                if diag.get("last_exception"):
                    lines.append(f"Last exception: `{diag['last_exception'][:120]}`")
                lines += [
                    "",
                    f"Fail count: `{diag.get('fail_count', 0)}`",
                    f"Success count: `{diag.get('success_count', 0)}`",
                    f"Downloads: `{diag.get('downloads_count', 0)}`",
                    f"Discovery: `{diag.get('discovery_count', 0)}`",
                    f"Joined VCs: `{diag.get('joined_vcs', 0)}`",
                ]
                if diag.get("last_error"):
                    lines.append(f"Last error: `{diag['last_error'][:100]}`")
                if diag.get("floodwait_remaining", 0) > 0:
                    lines.append(f"FloodWait remaining: `{diag['floodwait_remaining']}s`")
                # Action buttons.
                buttons = [
                    [InlineKeyboardButton("🔄 Force Reconnect", callback_data=f"cluster:reconnect:{aid}"),
                     InlineKeyboardButton("👑 Promote Primary", callback_data=f"cluster:promote:{aid}")],
                    [InlineKeyboardButton("🔎 Set Discovery", callback_data=f"cluster:setrole:{aid}:DISCOVERY"),
                     InlineKeyboardButton("📥 Set Downloader", callback_data=f"cluster:setrole:{aid}:DOWNLOADER")],
                    [InlineKeyboardButton("🎙 Set Voice", callback_data=f"cluster:setrole:{aid}:VOICE_CHAT"),
                     InlineKeyboardButton("📦 Set Backup", callback_data=f"cluster:setrole:{aid}:BACKUP")],
                    [InlineKeyboardButton("⚫ Disable" if not diag.get('disabled') else "✅ Enable",
                          callback_data=f"cluster:toggle_disable:{aid}"),
                     InlineKeyboardButton("🧪 Test This", callback_data=f"cluster:test_one:{aid}")],
                    [InlineKeyboardButton("⬅ Back", callback_data="cluster:details")],
                ]
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "\n".join(lines),
                    reply_markup=InlineKeyboardMarkup(buttons),
                )
        elif data.startswith("cluster:reconnect:"):
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                aid = data.split("cluster:reconnect:")[1]
                await update.callback_query.answer("Reconnecting…")
                cluster = get_userbot_cluster()
                await cluster.disconnect_account(aid)
                result = await cluster.connect_account(aid)
                success = result.startswith("connected")
                if success:
                    logger.info("ACCOUNT_RECONNECTED account_id=%s", aid)
                else:
                    logger.warning("ACCOUNT_RECONNECT_FAILED account_id=%s result=%s",
                                   aid, result)
                await update.callback_query.answer(
                    "✅ Reconnected" if success else f"❌ {result}", show_alert=True)
        elif data.startswith("cluster:setrole:"):
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                parts = data.split("cluster:setrole:")[1].split(":")
                if len(parts) == 2:
                    aid, role = parts[0], parts[1]
                    cluster = get_userbot_cluster()
                    success = cluster.set_role(aid, role)
                    await update.callback_query.answer(
                        f"✅ Role set to {role}" if success else "❌ Failed",
                        show_alert=True)
        elif data.startswith("cluster:promote:"):
            # V67.4 Part 8: Promote to primary (persisted).
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                aid = data.split("cluster:promote:")[1]
                cluster = get_userbot_cluster()
                # Also set the role to PRIMARY for clarity.
                cluster.set_role(aid, ROLE_PRIMARY)
                ok = cluster.set_primary_id(aid)
                await update.callback_query.answer(
                    f"👑 Promoted {aid} to primary" if ok else "❌ Failed",
                    show_alert=True)
        elif data.startswith("cluster:toggle_disable:"):
            # V67.4 Part 14: Disable / enable account.
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                aid = data.split("cluster:toggle_disable:")[1]
                cluster = get_userbot_cluster()
                acc = cluster.get_account(aid)
                if not acc:
                    await update.callback_query.answer("❌ Not found", show_alert=True)
                else:
                    new_state = not acc.get("disabled", False)
                    cluster.set_disabled(aid, new_state)
                    await update.callback_query.answer(
                        f"⚫ Disabled {aid}" if new_state else f"✅ Enabled {aid}",
                        show_alert=True)
        elif data.startswith("cluster:test_one:"):
            # V67.4 Part 10: Test a specific account's connectivity.
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                aid = data.split("cluster:test_one:")[1]
                cluster = get_userbot_cluster()
                diag = cluster.get_account_diagnostics(aid)
                if not diag.get("found"):
                    await update.callback_query.answer("❌ Not found", show_alert=True)
                else:
                    await update.callback_query.answer(
                        f"🧪 {aid}: {diag.get('status_label', '?')} "
                        f"{'✅ connected' if diag.get('connected') else '❌ not connected'}",
                        show_alert=True)
        elif data == "cluster:vc_distribution":
            # V77 PART 18: VC Distribution panel.
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                cluster = get_userbot_cluster()
                pool = get_vc_pool()
                cov = get_vc_coverage_manager().get_stats()
                accounts = cluster.list_accounts()
                lines = ["📊 *VC Distribution*\n"]
                lines.append(f"Coverage: `{cov['coverage_percent']}%` "
                             f"({cov['joined_vcs']}/{cov['active_vcs']})")
                lines.append(f"Missing: `{cov['missing_vcs']}`  Failed: `{cov['failed_vcs']}`")
                lines.append("")
                for acc in accounts:
                    aid = acc["account_id"]
                    in_vc = pool.get_state(aid)
                    vc_count = 1 if in_vc else 0
                    joined_vcs = int(acc.get("joined_vcs", 0))
                    failed_vcs = int(acc.get("fail_count", 0))
                    role = acc.get("role", "—")
                    status_icon = _status_icon(acc.get("status", ""))
                    lines.append(f"{status_icon} `{aid}`")
                    lines.append(f"   Role: `{role}`  Active VCs: `{vc_count}`")
                    lines.append(f"   Joined: `{joined_vcs}`  Failed: `{failed_vcs}`")
                logger.info("UI_BUTTON_VERIFIED button=cluster:vc_distribution")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "\n".join(lines),
                    reply_markup=cluster_menu_kb(),
                )
        elif data == "cluster:capacity_test":
            # V77 PART 25: VC Capacity Test.
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("Running capacity test…")
                result = await vc_capacity_test()
                lines = ["🧪 *VC Capacity Test*\n"]
                lines.append(f"Healthy Accounts: `{result['healthy_accounts']}`")
                lines.append(f"Available VC Workers: `{result['available_vc_workers']}`")
                lines.append(f"Current VC Usage: `{result['current_vc_usage']}`")
                lines.append(f"Estimated Capacity: `{result['estimated_capacity']}`")
                lines.append(f"Memory Usage: `{result['memory_usage_mb']} MB`")
                lines.append(f"CPU Usage: `{result['cpu_percent']}%`")
                lines.append(f"Join Rate: `{result['join_rate']}`")
                lines.append(f"Cap: `{result['cap_value']}` ({result['cap_source']})")
                logger.info("UI_BUTTON_VERIFIED button=cluster:capacity_test")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "\n".join(lines),
                    reply_markup=cluster_menu_kb(),
                )
        elif data == "cluster:session_test":
            # V77 PART 4: Session Survival Test.
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("Running session survival test…")
                result = await session_survival_test()
                lines = ["🧪 *Session Survival Test*\n"]
                lines.append(f"Accounts Tested: `{result['accounts_tested']}`")
                lines.append(f"Passed: `{result['accounts_passed']}` ✅")
                lines.append(f"Failed: `{result['accounts_failed']}` ❌")
                lines.append(f"Overall: `{'✅ PASS' if result['ok'] else '❌ FAIL'}`")
                if result.get("details"):
                    lines.append("")
                    for d in result["details"][:10]:
                        icon = "✅" if d.get("passed") else "❌"
                        lines.append(f"{icon} `{d['account_id']}`")
                        if d.get("error"):
                            lines.append(f"   _{d['error'][:80]}_")
                logger.info("UI_BUTTON_VERIFIED button=cluster:session_test")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "\n".join(lines),
                    reply_markup=cluster_menu_kb(),
                )
        elif data == "cluster:remove":
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                accounts = get_userbot_cluster().list_accounts()
                if not accounts:
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        "❌ No accounts to remove.",
                        reply_markup=cluster_menu_kb(),
                    )
                else:
                    rows = []
                    for acc in accounts:
                        rows.append([InlineKeyboardButton(
                            f"❌ {acc['account_id']} ({acc.get('phone', '—')})",
                            callback_data=f"cluster:rm:{acc['account_id']}",
                        )])
                    rows.append([InlineKeyboardButton("⬅ Back", callback_data="cluster:menu")])
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        "❌ *Remove Account*\n\nSelect an account to remove:",
                        reply_markup=InlineKeyboardMarkup(rows),
                    )
        elif data.startswith("cluster:rm:"):
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                aid = data.split("cluster:rm:")[1]
                cluster = get_userbot_cluster()
                success = cluster.remove_account(aid)
                await update.callback_query.answer(
                    "✅ Removed" if success else "❌ Not found", show_alert=True)
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    f"{'✅' if success else '❌'} Account `{aid}` "
                    f"{'removed' if success else 'not found'}.",
                    reply_markup=cluster_menu_kb(),
                )
        elif data == "m:hist":
            await states.reset(user.id)
            await _menu_edit(update, msg.HISTORY_MENU_TEXT, kb.history_menu())
        elif data == "m:set":
            await states.reset(user.id)
            s = await repo.ensure_settings(user.id)
            await _menu_edit(update, msg.settings_text(s), kb.settings_menu())
        elif data == "m:help":
            await states.reset(user.id)
            await _menu_edit(update, msg.HELP_MENU_TEXT, kb.help_menu())

        # ---- Back buttons: b:<menu> ----
        elif data == "b:main":
            await states.reset(user.id)
            await _menu_edit(update, msg.MAIN_MENU_TEXT, kb.main_menu())
        elif data == "b:dl":
            await states.reset(user.id)
            await _menu_edit(update, msg.DOWNLOAD_MENU_TEXT, kb.download_menu())
        elif data == "b:ai":
            await states.reset(user.id)
            await _menu_edit(update, msg.ANALYZE_MENU_TEXT, kb.analyze_menu())
        elif data == "b:ins":
            await states.reset(user.id)
            await _menu_edit(update, msg.INSPECTOR_MENU_TEXT, kb.inspector_menu())
        elif data == "b:tb":
            await states.reset(user.id)
            await _menu_edit(update, msg.TOOLBOX_MENU_TEXT, kb.toolbox_menu())
        elif data == "b:lib":
            await states.reset(user.id)
            await _menu_edit(update, msg.LIBRARY_MENU_TEXT, kb.library_menu())
        elif data == "b:st":
            await states.reset(user.id)
            await _menu_edit(update, msg.STATS_MENU_TEXT, kb.stats_menu())
        elif data == "b:qr":
            await states.reset(user.id)
            await _menu_edit(update, msg.QR_MENU_TEXT, kb.qr_menu())
        elif data == "b:batch":
            await states.reset(user.id)
            await _menu_edit(update, msg.BATCH_MENU_TEXT, kb.batch_menu())
        elif data == "b:sched":
            await states.reset(user.id)
            await _menu_edit(update, msg.SCHEDULED_MENU_TEXT, kb.scheduled_menu())
        elif data == "b:bk":
            await states.reset(user.id)
            await _menu_edit(update, msg.BACKUP_MENU_TEXT, kb.backup_menu())
        elif data == "b:admin":
            await admin_handler.show_menu(update, context)
        elif data == "b:hist":
            await _menu_edit(update, msg.HISTORY_MENU_TEXT, kb.history_menu())
        elif data == "b:set":
            s = await repo.ensure_settings(user.id)
            await _menu_edit(update, msg.settings_text(s), kb.settings_menu())
        elif data == "b:help":
            await _menu_edit(update, msg.HELP_MENU_TEXT, kb.help_menu())

        # ---- Download flow ----
        elif data == "dl:fwd":
            await download_handler.enter_forward_mode(update, context)
        elif data == "dl:link":
            await link_handler.enter_link_mode(update, context)
        elif data == "dl:cancel":
            await states.reset(user.id)
            await _menu_edit(update, msg.DOWNLOAD_CANCEL_PROMPT, kb.download_menu())

        # ---- Media browser (channel category browsing + Download All) ----
        elif data.startswith("mb:cat:"):
            category = data.split(":", 2)[2]
            await media_browser_handler.show_category_items(update, context, category)
        elif data.startswith("mb:one:"):
            try:
                mid = int(data.split(":", 2)[2])
            except (ValueError, IndexError):
                await update.callback_query.answer("Invalid id.")
            else:
                await media_browser_handler.download_single(update, context, mid)
        elif data.startswith("mb:all:"):
            category = data.split(":", 2)[2]
            await media_browser_handler.download_all(update, context, category)
        elif data == "mb:back":
            await media_browser_handler.back_to_categories(update, context)

        # ---- Analyze flow ----
        elif data == "ai:fwd":
            await analyze_handler.enter_analyze_mode(update, context)
        elif data == "ai:modes":
            await analyze_handler.show_modes(update, context)
        elif data.startswith("ai:mode:"):
            mode = data.split(":", 2)[2]
            await analyze_handler.set_mode(update, context, mode)
        elif data == "ai:cancel":
            await states.reset(user.id)
            await _menu_edit(update, msg.ANALYZE_CANCEL_PROMPT, kb.analyze_menu())

        # ---- Inspector ----
        elif data == "ins:fwd":
            await inspector_handler.enter_inspect_mode(update, context)
        elif data == "ins:recent":
            await inspector_handler.show_recent(update, context)

        # ---- Toolbox ----
        elif data.startswith("tb:"):
            tool = data.split(":", 1)[1]
            if tool == "cancel":
                await states.reset(user.id)
                await _menu_edit(update, msg.TOOLBOX_MENU_TEXT, kb.toolbox_menu())
            else:
                await toolbox_handler.handle_tool_selection(update, context, tool)

        # ---- Library ----
        elif data.startswith("lib:"):
            await library_handler.handle_action(update, context, data)

        # ---- Stats ----
        elif data == "st:me":
            await stats_handler.show_user(update, context)
        elif data == "st:global":
            await stats_handler.show_global(update, context)

        # ---- QR ----
        elif data == "qr:make":
            await qr_handler.enter_make_mode(update, context)
        elif data == "qr:cancel":
            await states.reset(user.id)
            await _menu_edit(update, msg.QR_MENU_TEXT, kb.qr_menu())

        # ---- Batch / album ----
        elif data == "batch:fwd":
            await batch_handler.enter_batch_mode(update, context)

        # ---- Scheduled ----
        elif data == "sched:list":
            await scheduled_handler.show_list(update, context)

        # ---- Backup ----
        elif data == "bk:export":
            await backup_handler.do_export(update, context)
        elif data == "bk:import":
            await backup_handler.enter_import(update, context)

        # ---- Admin ----
        elif data == "adm:users":
            await admin_handler.list_users(update, context)
        elif data == "adm:stats":
            await admin_handler.global_stats(update, context)
        elif data == "adm:export":
            await admin_handler.export_global(update, context)
        elif data == "adm:bcast":
            await admin_handler.enter_broadcast(update, context)
        elif data == "adm:mtp":
            await mtproto_handler.show_menu(update, context)
        elif data == "adm:health":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await _admin_health_dashboard(update, context)
        elif data == "adm:tasks":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await _admin_active_tasks_view(update, context)
        elif data == "adm:restart":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "⚠️ *Restart Bot?*\n\n"
                    "This will restart the bot process. All active operations will be interrupted.\n\n"
                    "_The bot will be unavailable for ~10-30 seconds._",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("✅ Confirm Restart", callback_data="adm:restart_confirm")],
                        [InlineKeyboardButton("❌ Cancel", callback_data="b:admin")],
                    ]),
                    parse_mode="Markdown",
                )
        elif data == "adm:restart_confirm":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("Restarting...")
                logger.info("ADMIN_RESTART_REQUESTED admin=%s", update.effective_user.id)
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🔄 *Restarting bot...*\n\n_The bot will be back in ~10-30 seconds._",
                    parse_mode="Markdown",
                )
                # Schedule the restart after a short delay so the message can be sent.
                import threading
                def _do_restart():
                    import os, signal
                    try:
                        os.kill(os.getpid(), signal.SIGTERM)
                    except Exception:
                        import sys
                        sys.exit(0)
                threading.Timer(2.0, _do_restart).start()

        # ---- MTProto backend (admin) ----
        elif data == "mtp:start":
            await mtproto_handler.start(update, context)
        elif data == "mtp:stop":
            await mtproto_handler.stop(update, context)
        elif data == "mtp:restart":
            await mtproto_handler.restart(update, context)
        elif data == "mtp:status":
            await mtproto_handler.refresh_status(update, context)
        elif data == "mtp:screenshot":
            await mtproto_handler.enter_screenshot_mode(update, context)
        elif data == "mtp:download":
            await mtproto_handler.enter_download_mode(update, context)

        # ---- VC Tour (admin) ----
        elif data == "adm:vc":
            await vc_handler.show_menu(update, context)
        elif data == "adm:disc":
            # V86 — top-level Discovery entry point from the admin menu.
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                await _menu_edit(update, await discovery_main_text(),
                                 discovery_main_menu())
        elif data == "adm:talk":
            await talkative_handler.show_menu(update, context)
        elif data == "b:talk":
            await talkative_handler.show_menu(update, context)
        # ---- Talkative Mode (admin) ----
        elif data == "talk:menu":
            await talkative_handler.show_menu(update, context)
        # --- Talkative V2 submenu routes (#1-#13) ---
        elif data == "talk:chat_ctrl":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "💬 *Chat Controls*\n\nConfigure text chat behavior:",
                    reply_markup=talkative_chat_controls_menu())
        elif data == "talk:vc_ctrl":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                caps = await vc_talkative_get_capabilities()
                vc_state = "Degraded" if caps.get("degraded") else "Ready" if caps.get("ready") else "Off"
                # V41 Fix #5: show exact reasons for each missing stage.
                ai_reason = caps.get("audio_capture_reason", "") if not caps.get("audio_capture") else ""
                vad_reason = caps.get("vad_reason", "") if not caps.get("vad") else ""
                stt_reason = caps.get("stt_reason", "") if not caps.get("stt") else ""
                tts_reason = caps.get("tts_reason", "") if not caps.get("tts") else ""
                pb_reason = caps.get("playback_reason", "") if not caps.get("playback") else ""
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    f"🎙 *VC Controls*\n\n"
                    f"State: `{vc_state}`\n"
                    f"Audio input: `{'Ready' if caps.get('audio_capture') else 'Missing — ' + ai_reason}`\n"
                    f"VAD: `{'Ready' if caps.get('vad') else 'Missing — ' + vad_reason}`\n"
                    f"STT: `{'Ready' if caps.get('stt') else 'Missing — ' + stt_reason}`\n"
                    f"TTS: `{'Ready' if caps.get('tts') else 'Missing'}`\n"
                    f"Playback: `{'Ready' if caps.get('playback') else 'Missing'}`",
                    reply_markup=talkative_vc_controls_menu())
        elif data == "talk:media_ctrl":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                g = await talkative_get_global_settings()
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    f"🎭 *Multimodal & Voice*\n\n"
                    f"Master: {'✅ ON' if g.get('multimodal_enabled') else '⏹ OFF'}",
                    reply_markup=talkative_media_controls_menu(g))
        # V52 Multimodal submenu routes
        elif data == "talk:mm_voice":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                g = await talkative_get_global_settings()
                await safe_edit_message_text(context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🎙 *Voice & Audio*", reply_markup=talkative_mm_voice_menu(g))
        elif data == "talk:mm_clone":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                g = await talkative_get_global_settings()
                await safe_edit_message_text(context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🗣 *Voice Clone*", reply_markup=talkative_mm_clone_menu(g))
        elif data == "talk:mm_stickers":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                g = await talkative_get_global_settings()
                await safe_edit_message_text(context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🧩 *Stickers*", reply_markup=talkative_mm_stickers_menu(g))
        elif data == "talk:mm_gifs":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                g = await talkative_get_global_settings()
                await safe_edit_message_text(context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🎞 *GIFs*", reply_markup=talkative_mm_gifs_menu(g))
        elif data == "talk:mm_reactions":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                g = await talkative_get_global_settings()
                await safe_edit_message_text(context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "❤️ *Reactions*", reply_markup=talkative_mm_reactions_menu(g))
        elif data == "talk:mm_vision":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                g = await talkative_get_global_settings()
                await safe_edit_message_text(context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🖼 *Vision*", reply_markup=talkative_mm_vision_menu(g))
        elif data == "talk:mm_limits":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                g = await talkative_get_global_settings()
                await safe_edit_message_text(context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "⚙️ *Limits*", reply_markup=talkative_mm_limits_menu(g))
        elif data == "talk:mm_diag":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                await safe_edit_message_text(context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🧪 *Multimodal Diagnostics*", reply_markup=talkative_mm_diag_menu())
        elif data == "talk:mm_diag_run":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("🧪 Running diagnostic...")
                g = await talkative_get_global_settings()
                caps = await vc_talkative_get_capabilities()
                lines = [
                    "🧪 *Multimodal Pipeline Diagnostic*\n",
                    f"*Voice*",
                    f"  Understand: {'✅' if g.get('voice_understand') else '⏹'}",
                    f"  Replies: {'✅' if g.get('voice_replies') else '⏹'}",
                    f"  Match Type: {'✅' if g.get('match_reply_type') else '⏹'}",
                    f"  Policy: `{g.get('voice_reply_policy', 'voice_only')}`",
                    f"  TTS Fallback: {'✅' if g.get('standard_tts_fallback') else '⏹'}",
                    f"  STT: {'Ready' if caps.get('stt') else 'Missing'}",
                    f"  TTS: {'Ready' if caps.get('tts') else 'Missing'}",
                    f"\n*Voice Clone*",
                    f"  Enabled: {'✅' if g.get('voice_clone_enabled') else '⏹'}",
                    f"  For Msgs: {'✅' if g.get('clone_for_voice_msgs') else '⏹'}",
                    f"  In VC: {'✅' if g.get('clone_voice_in_vc') else '⏹'}",
                    f"  Everywhere: {'✅' if g.get('use_voice_everywhere') else '⏹'}",
                    f"\n*Media*",
                    f"  Sticker Replies: {'✅' if g.get('sticker_replies') else '⏹'}",
                    f"  GIF Replies: {'✅' if g.get('gif_replies') else '⏹'}",
                    f"  Native Reactions: {'✅' if g.get('native_reactions') else '⏹'}",
                    f"  Image Understanding: {'✅' if g.get('image_understanding') else '⏹'}",
                    f"  Dedup: {'✅' if g.get('media_dedup') else '⏹'}",
                    f"\n*VC Pipeline*",
                    f"  Audio Input: {'Ready' if caps.get('audio_capture') else 'Missing'}",
                    f"  VAD: {'Ready' if caps.get('vad') else 'Missing'}",
                    f"  Playback: {'Ready' if caps.get('playback') else 'Missing'}",
                ]
                await safe_send_message(context.bot, update.effective_chat.id,
                    "\n".join(lines), reply_markup=talkative_mm_diag_menu())
        # V52 Multimodal toggle handler (generic)
        elif data.startswith("talk:toggle:"):
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                field = data.split(":", 2)[2]
                g = await talkative_get_global_settings()
                current = bool(g.get(field, False))
                await talkative_update_global_settings(**{field: not current})
                await update.callback_query.answer(f"{field} → {'ON' if not current else 'OFF'}")
                g = await talkative_get_global_settings()
                # Determine which submenu to refresh
                voice_fields = {"voice_understand", "voice_replies", "match_reply_type", "standard_tts_fallback"}
                clone_fields = {"voice_clone_enabled", "clone_for_voice_msgs", "clone_voice_in_vc", "use_voice_everywhere"}
                sticker_fields = {"sticker_replies", "sticker_understanding", "context_stickers"}
                gif_fields = {"gif_replies", "gif_understanding"}
                reaction_fields = {"native_reactions"}
                vision_fields = {"image_understanding"}
                limit_fields = {"media_dedup"}
                if field in voice_fields:
                    menu = talkative_mm_voice_menu(g)
                    title = "🎙 *Voice & Audio*"
                elif field in clone_fields:
                    menu = talkative_mm_clone_menu(g)
                    title = "🗣 *Voice Clone*"
                elif field in sticker_fields:
                    menu = talkative_mm_stickers_menu(g)
                    title = "🧩 *Stickers*"
                elif field in gif_fields:
                    menu = talkative_mm_gifs_menu(g)
                    title = "🎞 *GIFs*"
                elif field in reaction_fields:
                    menu = talkative_mm_reactions_menu(g)
                    title = "❤️ *Reactions*"
                elif field in vision_fields:
                    menu = talkative_mm_vision_menu(g)
                    title = "🖼 *Vision*"
                elif field in limit_fields:
                    menu = talkative_mm_limits_menu(g)
                    title = "⚙️ *Limits*"
                else:
                    menu = talkative_media_controls_menu(g)
                    title = "🎭 *Multimodal & Voice*"
                await safe_edit_message_text(context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id, title, reply_markup=menu)
        # V52 Multimodal cycle handler (generic)
        elif data.startswith("talk:cycle:"):
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                field = data.split(":", 2)[2]
                g = await talkative_get_global_settings()
                if field == "voice_reply_policy":
                    policies = ["voice_only", "voice_and_audio", "when_requested", "always", "never"]
                    cur = g.get("voice_reply_policy", "voice_only")
                    try:
                        idx = policies.index(cur)
                    except ValueError:
                        idx = 0
                    new_val = policies[(idx + 1) % len(policies)]
                    await talkative_update_global_settings(voice_reply_policy=new_val)
                    await update.callback_query.answer(f"Policy → {new_val}")
                elif field == "media_prob":
                    probs = [0.0, 0.05, 0.15, 0.3, 1.0]
                    labels = ["Off", "Low", "Medium", "High", "Always"]
                    cur = config.talkative_media_probability
                    try:
                        idx = min(range(len(probs)), key=lambda i: abs(probs[i] - cur))
                    except ValueError:
                        idx = 2
                    new_idx = (idx + 1) % len(probs)
                    # V53 Fix #17: persist via runtime config (media_probability is Config-only, not DB).
                    # These values are env-config defaults; runtime changes are intentionally ephemeral.
                    object.__setattr__(config, "talkative_media_probability", probs[new_idx])
                    await update.callback_query.answer(f"Probability → {labels[new_idx]}")
                elif field == "media_cooldown":
                    cds = [5, 10, 30, 60]
                    cur = config.talkative_media_cooldown
                    try:
                        idx = cds.index(cur)
                    except ValueError:
                        idx = 1
                    new_val = cds[(idx + 1) % len(cds)]
                    # V53 Fix #17: persist via runtime config (media_cooldown is a Config field, not in DB whitelist).
                    object.__setattr__(config, "talkative_media_cooldown", new_val)
                    await update.callback_query.answer(f"Cooldown → {new_val}s")
                elif field == "media_max_consec":
                    maxes = [1, 2, 3, 5]
                    cur = config.talkative_media_max_consecutive
                    try:
                        idx = maxes.index(cur)
                    except ValueError:
                        idx = 1
                    new_val = maxes[(idx + 1) % len(maxes)]
                    # V53 Fix #17: persist via runtime config.
                    object.__setattr__(config, "talkative_media_max_consecutive", new_val)
                    await update.callback_query.answer(f"Max Consecutive → {new_val}")
                g = await talkative_get_global_settings()
                await safe_edit_message_text(context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "⚙️ *Limits*", reply_markup=talkative_mm_limits_menu(g))
        # V52 Voice Clone workflow routes
        elif data == "talk:clone:enroll":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            elif update.effective_chat.type != "private":
                await update.callback_query.answer("🔒 Voice enrollment requires private chat.", show_alert=True)
            else:
                admin_id = update.effective_user.id
                await update.callback_query.answer("🗣 Send a reference voice sample")
                # V54 Fix #2: use the Telethon-side pending state (not Bot API user_data).
                _voice_enroll_start(admin_id, update.effective_chat.id)
                cancel_kb = InlineKeyboardMarkup([[
                    InlineKeyboardButton("❌ Cancel", callback_data="talk:clone:cancel")]])
                await safe_send_message(context.bot, update.effective_chat.id,
                    "🗣 *Voice Enrollment*\n\n"
                    "Send a voice/audio message as a reference sample.\n\n"
                    "_You must have permission to use this voice._\n\n"
                    "⚠️ The sample will be deleted after processing.\n"
                    "_Send the sample now, or tap ❌ Cancel._",
                    reply_markup=cancel_kb)
        elif data == "talk:clone:cancel":
            admin_id = update.effective_user.id
            chat_id = update.effective_chat.id if update.effective_chat else None
            # V60 Fix #9: clear the SAME authoritative state used by the
            # Bot API voice/audio handler. Late-arriving samples will NOT
            # be enrolled after this.
            if chat_id is not None:
                _voice_enroll_clear(admin_id, chat_id)
            else:
                _voice_enroll_clear(admin_id)
            context.user_data.pop("vc_disc_awaiting_query", None)  # type: ignore[index]
            await update.callback_query.answer("❌ Voice enrollment cancelled")
            g = await talkative_get_global_settings()
            await safe_edit_message_text(context.bot, update.effective_chat.id,
                update.callback_query.message.message_id,
                "❌ *Voice enrollment cancelled.*",
                reply_markup=talkative_mm_clone_menu(g))
        elif data == "talk:clone:status":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("ℹ️ Voice status")
                g = await talkative_get_global_settings()
                caps = await vc_talkative_get_capabilities()
                # V59 Fix #8: truthful status from DB + env.
                import os as _os
                clone_provider = _os.environ.get("VOICE_CLONE_PROVIDER", "").strip()
                clone_key = _os.environ.get("VOICE_CLONE_API_KEY", "").strip()
                # Check DB for existing profile.
                profile_exists = False
                profile_provider = "—"
                try:
                    db = await get_db()
                    async with db.execute(
                        "SELECT provider FROM voice_profiles WHERE owner_user_id = ?",
                        (update.effective_user.id,),
                    ) as cur:
                        row = await cur.fetchone()
                    if row:
                        profile_exists = True
                        profile_provider = row["provider"]
                except Exception:
                    pass

                lines = ["ℹ️ *Voice Profile Status*\n"]
                if not clone_provider or not clone_key:
                    lines.append("🔴 Voice cloning unavailable — provider not configured")
                elif not profile_exists:
                    lines.append("🟡 Voice cloning ready for enrollment")
                    lines.append(f"   Provider: {clone_provider}")
                else:
                    lines.append(f"🟢 Voice profile enrolled — provider: {profile_provider}")
                    lines.append("   Synthesis not yet verified" if True else "   ✅ Tested")
                # V60 Fix #13: include the startup self-check result so the
                # admin sees the truthful end-to-end dependency status.
                try:
                    sc = await _voice_enroll_selfcheck_async()
                    lines.append("")
                    lines.append(f"🔧 *Enrollment subsystem*: `{sc.get('status', '?')}`")
                    if sc.get("missing"):
                        lines.append("   Missing: " + ", ".join(sc["missing"]))
                    else:
                        lines.append("   ffmpeg: ✅ | ffprobe: ✅ | handler: ✅ | DB: ✅")
                except Exception:  # noqa: BLE001
                    pass
                lines.append(f"\nSTT: {'Available' if caps.get('stt') else 'Not configured'}")
                lines.append(f"TTS: {'Available' if caps.get('tts') else 'Not configured'}")
                lines.append(f"VC Input: {'Available' if caps.get('audio_capture') else 'Not available'}")
                lines.append(f"VC Playback: {'Available' if caps.get('playback') else 'Not available'}")
                await safe_send_message(context.bot, update.effective_chat.id,
                    "\n".join(lines), reply_markup=talkative_mm_clone_menu(g))
        elif data == "talk:clone:replace":
            # V59 Fix #5: Replace Voice — starts new enrollment (preserves old until success).
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            elif update.effective_chat.type != "private":
                await update.callback_query.answer("🔒 Voice enrollment requires private chat.", show_alert=True)
            else:
                admin_id = update.effective_user.id
                await update.callback_query.answer("🔄 Send a new voice sample to replace")
                _voice_enroll_start(admin_id, update.effective_chat.id)
                cancel_kb = InlineKeyboardMarkup([[
                    InlineKeyboardButton("❌ Cancel", callback_data="talk:clone:cancel")]])
                await safe_send_message(context.bot, update.effective_chat.id,
                    "🔄 *Replace Voice*\n\n"
                    "Send a new voice/audio sample (10–30 seconds) to replace your current voice.\n\n"
                    "_Your existing voice profile will remain active until the new one is successfully created._\n\n"
                    "_Send the sample now, or tap ❌ Cancel._",
                    reply_markup=cancel_kb)
        elif data == "talk:clone:test":
            # V59 Fix #6: Test Voice — requires real provider + profile.
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                import os as _os
                clone_provider = _os.environ.get("VOICE_CLONE_PROVIDER", "").strip()
                g = await talkative_get_global_settings()
                # Check if profile exists in DB.
                profile_exists = False
                try:
                    db = await get_db()
                    async with db.execute(
                        "SELECT id FROM voice_profiles WHERE owner_user_id = ?",
                        (update.effective_user.id,),
                    ) as cur:
                        row = await cur.fetchone()
                    if row:
                        profile_exists = True
                except Exception:
                    pass
                if not clone_provider:
                    await update.callback_query.answer("⚠️ No provider configured")
                    await safe_send_message(context.bot, update.effective_chat.id,
                        "⚠️ **Voice test unavailable**\n\n"
                        "No voice clone provider is configured.\n"
                        "_Configure a provider first, then enroll your voice._",
                        reply_markup=talkative_mm_clone_menu(g))
                elif not profile_exists:
                    await update.callback_query.answer("⚠️ No voice profile enrolled")
                    await safe_send_message(context.bot, update.effective_chat.id,
                        "⚠️ **Voice test unavailable**\n\n"
                        "No voice profile is enrolled yet.\n"
                        "_Use 'Enroll Voice' first to create a profile._",
                        reply_markup=talkative_mm_clone_menu(g))
                else:
                    await update.callback_query.answer("⚠️ Test requires provider SDK")
                    await safe_send_message(context.bot, update.effective_chat.id,
                        "⚠️ **Voice test not available**\n\n"
                        f"Provider '{clone_provider}' is configured and a profile exists,\n"
                        "but the provider SDK is not installed in this environment.\n"
                        "_Install the required provider package to enable voice testing._",
                        reply_markup=talkative_mm_clone_menu(g))
        elif data == "talk:clone:delete":
            # V59 Fix #7: Delete Voice — removes local profile reference.
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                g = await talkative_get_global_settings()
                # Check if profile exists.
                profile_exists = False
                try:
                    db = await get_db()
                    async with db.execute(
                        "SELECT id FROM voice_profiles WHERE owner_user_id = ?",
                        (update.effective_user.id,),
                    ) as cur:
                        row = await cur.fetchone()
                    if row:
                        profile_exists = True
                        # Delete from DB.
                        await db.execute(
                            "DELETE FROM voice_profiles WHERE owner_user_id = ?",
                            (update.effective_user.id,),
                        )
                        await db.commit()
                except Exception as exc:
                    logger.error("VOICE_PROFILE_DELETE_FAILED user=%s exc=%s", update.effective_user.id, exc)
                if profile_exists:
                    await update.callback_query.answer("🗑 Voice profile deleted")
                    await safe_send_message(context.bot, update.effective_chat.id,
                        "🗑 *Voice profile deleted.*\n\n"
                        "_The local profile reference has been removed._\n"
                        "_Voice cloning is now disabled until you enroll again._",
                        reply_markup=talkative_mm_clone_menu(g))
                else:
                    await update.callback_query.answer("ℹ️ No profile to delete")
                    await safe_send_message(context.bot, update.effective_chat.id,
                        "ℹ️ No voice profile was found to delete.",
                        reply_markup=talkative_mm_clone_menu(g))
        elif data == "talk:mem_ctrl":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🧠 *Memory & Context Controls*\n\n"
                    f"Memory TTL: `{config.talkative_memory_ttl_seconds}s`\n"
                    f"Summarize threshold: `{config.talkative_memory_summarize_threshold}`",
                    reply_markup=talkative_memory_controls_menu())
        elif data == "talk:engage_ctrl":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "⚡ *Engagement Controls*\n\n"
                    f"Threshold: `{config.talkative_engagement_threshold}`\n"
                    f"Ambient probability: `{config.talkative_ambient_probability}`\n"
                    f"Max replies/min: `{config.talkative_max_replies_per_minute}`\n"
                    f"Max consecutive: `{config.talkative_max_consecutive_bot}`",
                    reply_markup=talkative_engagement_controls_menu())
        elif data == "talk:safety_ctrl":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🛡 *Safety & Limits*\n\nWorkflow priority guard is mandatory in production.",
                    reply_markup=talkative_safety_controls_menu())
        elif data == "talk:diag":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                m = _talkative_engine_metrics_snapshot()
                # V42 Fix #2/#15: include provider health in diagnostics.
                health = talkative_get_provider_health()
                # V42 Fix #7: include effective provider + source.
                try:
                    eff_p, eff_s, eff_m, eff_r, eff_reason = await talkative_effective_provider()
                except Exception:  # noqa: BLE001
                    eff_p, eff_s, eff_m, eff_r, eff_reason = "Unknown", "error", "unknown", False, "talkative_effective_provider raised an exception"
                # V42 Fix #6: include effective enabled state.
                try:
                    eff_en, eff_src = await talkative_effective_enabled()
                except Exception:  # noqa: BLE001
                    eff_en, eff_src = False, "error"
                # Build provider health lines.
                health_lines = []
                for prov in ("groq", "openrouter", "gemini"):
                    h = health.get(prov, {})
                    state = h.get("state", "?")
                    cd = h.get("cooldown_remaining", 0)
                    tf = h.get("total_failures", 0)
                    ts = h.get("total_successes", 0)
                    state_icon = "✅" if state == "healthy" else "❌"
                    cd_str = f" (cooldown {cd:.0f}s)" if cd > 0 else ""
                    health_lines.append(
                        f"  {state_icon} {prov}: `{state}`{cd_str} fail={tf} ok={ts}")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    f"🔧 *Diagnostics*\n\n"
                    f"*Runtime*\n"
                    f"Enabled: `{eff_en}` (source={eff_src})\n"
                    f"Provider: `{eff_p}` (source={eff_s})\n"
                    f"Model: `{eff_m}`\n"
                    f"Ready: `{'✅' if eff_r else '❌'}` {eff_reason or ''}\n\n"
                    f"*Provider Health*\n" + "\n".join(health_lines) + "\n\n"
                    f"*Engine Metrics*\n"
                    f"Replies generated: `{m.get('replies_generated',0)}`\n"
                    f"Replies sent: `{m.get('replies_sent',0)}`\n"
                    f"Suppressed: `{m.get('replies_suppressed',0)}`\n"
                    f"Duplicates blocked: `{m.get('duplicate_blocked',0)}`\n"
                    f"Stale cancelled: `{m.get('stale_cancelled',0)}`\n"
                    f"LLM failures: `{m.get('llm_failures',0)}`\n"
                    f"Media sent: `{m.get('media_sent',0)}`\n"
                    f"Active chat sessions: `{m.get('active_chat_sessions',0)}`\n"
                    f"Tracked groups: `{m.get('tracked_groups',0)}`",
                    reply_markup=talkative_diagnostics_menu())
        elif data == "talk:provider_health":
            # V42 Fix #19: provider health screen — canonical control hierarchy.
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                health = talkative_get_provider_health()
                try:
                    eff_p, eff_s, eff_m, eff_r, eff_reason = await talkative_effective_provider()
                except Exception:  # noqa: BLE001
                    eff_p, eff_s, eff_m, eff_r, eff_reason = "Unknown", "error", "unknown", False, "talkative_effective_provider raised an exception"
                lines = [f"📊 *Provider Health*\n",
                         f"Effective: `{eff_p}` (source={eff_s})",
                         f"Model: `{eff_m}`",
                         f"Ready: `{'✅' if eff_r else '❌'}` {eff_reason or ''}\n"]
                for prov in ("groq", "openrouter", "gemini"):
                    h = health.get(prov, {})
                    state = h.get("state", "?")
                    cd = h.get("cooldown_remaining", 0)
                    tf = h.get("total_failures", 0)
                    ts = h.get("total_successes", 0)
                    le = h.get("last_error", "")[:80]
                    icon = "✅" if state == "healthy" else "❌"
                    lines.append(f"{icon} *{prov}*")
                    lines.append(f"  State: `{state}`" +
                                 (f" (cooldown {cd:.0f}s)" if cd > 0 else ""))
                    lines.append(f"  Failures: `{tf}` · Successes: `{ts}`")
                    if le:
                        lines.append(f"  Last error: `{le}`")
                menu_kb = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🧪 Test Provider", callback_data="talk:test_provider")],
                    [InlineKeyboardButton("⬅ Back to Diagnostics", callback_data="talk:diag")],
                ])
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "\n".join(lines),
                    reply_markup=menu_kb,
                )
        elif data == "talk:provider_key:add" or data == "talk:gemini_key:add":
            # V57 Fix #10: provider-aware key replacement workflow.
            admin_id = update.effective_user.id
            if not _talk_is_admin(admin_id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            elif update.effective_chat.type != "private":
                await update.callback_query.answer(
                    "🔒 Key replacement only works in private chat.", show_alert=True)
            else:
                # V57 Fix #10: resolve the effective provider for provider-aware messaging.
                try:
                    eff_p, _, _, _, _ = await talkative_effective_provider()
                except Exception:
                    eff_p = config.talkative_provider or "gemini"
                # Start the pending-input workflow.
                _gemini_key_pending_start(admin_id, update.effective_chat.id)
                context.user_data["vc_disc_awaiting_query"] = "gemini_key_replace"  # type: ignore[index]
                await update.callback_query.answer(f"🔑 Send the new {eff_p.title()} API key")
                cancel_menu_kb = InlineKeyboardMarkup([[
                    InlineKeyboardButton("❌ Cancel", callback_data="talk:gemini_key:cancel"),
                ]])
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"🔑 *{eff_p.title()} API Key Replacement*\n\n"
                    f"Send the new {eff_p.title()} API key as a plain text message.\n\n"
                    "_The key will be validated with a minimal test request. "
                    "If valid, it will be activated at runtime._\n\n"
                    "⚠️ The key is NEVER logged, echoed, or persisted to disk. "
                    "It will be lost after restart.\n\n"
                    "_Send the key now, or tap ❌ Cancel._",
                    reply_markup=cancel_menu_kb,
                )
        elif data == "talk:gemini_key:cancel" or data == "talk:provider_key:cancel":
            # V43 Fix #6: cancel the pending Gemini key replacement.
            admin_id = update.effective_user.id
            _gemini_key_pending_clear(admin_id)
            context.user_data.pop("vc_disc_awaiting_query", None)  # type: ignore[index]
            await update.callback_query.answer("❌ Key replacement cancelled")
            await safe_edit_message_text(
                context.bot, update.effective_chat.id,
                update.callback_query.message.message_id,
                "❌ *Gemini key replacement cancelled.*\n\n"
                "_No changes were made. The active key is unchanged._",
                reply_markup=talkative_diagnostics_menu(),
            )
        elif data == "talk:test_dm_pipeline":
            # V46 Fix: Talkative pipeline diagnostics — DM + group event-correlated.
            admin_id = update.effective_user.id
            if not _talk_is_admin(admin_id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("🧪 Pipeline diagnostic")
                # Gather global pipeline status.
                handler_registered = _talkative_userbot_handler_registered
                try:
                    eff_en, eff_src = await talkative_effective_enabled()
                except Exception:  # noqa: BLE001
                    eff_en, eff_src = False, "error"
                try:
                    eff_p, eff_s, eff_m, eff_r, eff_reason = await talkative_effective_provider()
                except Exception:  # noqa: BLE001
                    eff_p, eff_s, eff_r, eff_reason = "Unknown", "error", False, "talkative_effective_provider raised an exception"
                health = talkative_get_provider_health()
                # V46 Fix: use the EFFECTIVE provider's health, not hardcoded gemini.
                eff_h = health.get(eff_p, health.get("gemini", {}))
                diag_lines = [
                    "🧪 *Talkative Pipeline Diagnostic*\n",
                    "*Global State*",
                    f"Handler registered: `{'✅' if handler_registered else '❌'}`",
                    f"Global enabled: `{'✅' if eff_en else '❌'}` (source={eff_src})",
                    f"Provider: `{eff_p}` (source={eff_s})",
                    f"Provider ready: `{'✅' if eff_r else '❌'}` {eff_reason or ''}",
                    f"Provider health: `{eff_h.get('state', '?')}`",
                    f"Private auto-reply: `{'✅' if config.talkative_private_auto_reply else '❌'}`",
                    f"Userbot ID: `{_userbot_id or '—'}`",
                    f"Userbot username: `@{_userbot_username or '—'}`",
                ]
                # V58 Fix: human-readable diagnostic events (no raw Python dicts).
                recent_dm = _dm_diag_snapshot()
                if recent_dm:
                    diag_lines.append("\n*Recent DM Events*")
                    for entry in recent_dm[:5]:
                        diag_lines.extend(_format_diag_entry_human(entry, is_private=True))
                else:
                    diag_lines.append("\n_No recent DM events._")
                recent_group = _group_diag_snapshot()
                if recent_group:
                    diag_lines.append("\n*Recent Group Events*")
                    for entry in recent_group[:5]:
                        diag_lines.extend(_format_diag_entry_human(entry, is_private=False))
                else:
                    diag_lines.append("\n_No recent group events._")
                diag_lines.append("\n_Send a DM or @mention the userbot to test the pipeline._")
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "\n".join(diag_lines),
                    reply_markup=talkative_diagnostics_menu(),
                )
        elif data == "talk:vc_cap_test":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                caps = await vc_talkative_get_capabilities()
                await update.callback_query.answer(
                    f"VC Caps: capture={caps.get('audio_capture')} vad={caps.get('vad')} "
                    f"stt={caps.get('stt')} tts={caps.get('tts')} playback={caps.get('playback')} "
                    f"ready={caps.get('ready')}",
                    show_alert=True)
        elif data == "talk:test_provider":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("Testing provider...")
                try:
                    eff_prov, eff_src, eff_model, eff_ready, eff_reason = (
                        await talkative_effective_provider())
                    logger.info(
                        "TALKATIVE_PROVIDER_TEST effective=%s source=%s ready=%s reason=%s",
                        eff_prov, eff_src, eff_ready, eff_reason or "ok")
                    # V61 Fix #5: capture generation at test start so the
                    # external record (if reached) passes a valid generation.
                    # NOTE: talkative_generate() already records success/failure
                    # internally with the correct generation. The external
                    # record below is kept only for the non-fallback genuine
                    # success path; it's a no-op for recovery when the
                    # internal record already handled it.
                    gen_at_test_start = _provider_current_generation(eff_prov)
                    result = await talkative_generate(
                        [{"role": "user", "content": "Say 'OK' in one word."}],
                        "You are a test. Reply with exactly: OK",
                        {"provider": eff_prov,
                         "max_reply_chars": 50, "request_timeout": 10})
                    # V61: talkative_generate already recorded success/failure
                    # internally (with generation). The external record here
                    # is only needed when result.provider differs from the
                    # chain's providers (local fallback). Guard accordingly.
                    if result.success and result.text and result.provider == eff_prov:
                        # Internal record already handled this; skip external
                        # double-record to avoid inflating total_successes.
                        pass
                    elif not result.success:
                        # Failure was already recorded internally for the
                        # real provider(s). Only record here if the failure
                        # is for a provider not in the chain (defensive).
                        pass
                    # V47 Fix: get fresh health for display.
                    health = talkative_get_provider_health()
                    eff_h = health.get(result.provider, {})
                    await safe_send_message(
                        context.bot, update.effective_chat.id,
                        f"Provider test: {result.provider} (source={eff_src}) -> {result.text[:50]}\n"
                        f"Health: `{eff_h.get('state', '?')}` fail={eff_h.get('total_failures', 0)} ok={eff_h.get('total_successes', 0)}",
                        reply_markup=talkative_diagnostics_menu())
                except Exception as exc:  # noqa: BLE001
                    # V47 Fix: record failure for the effective provider.
                    try:
                        eff_prov, _, _, _, _ = await talkative_effective_provider()
                        await _provider_record_failure_async(eff_prov, str(exc),
                                                              _provider_current_generation(eff_prov))
                    except Exception:
                        pass
                    await safe_send_message(
                        context.bot, update.effective_chat.id,
                        f"Provider test failed: {exc}",
                        reply_markup=talkative_diagnostics_menu())
        elif data == "talk:enable_g":
            await talkative_handler.enable_global(update, context)
        elif data == "talk:disable_g":
            await talkative_handler.disable_global(update, context)
        elif data == "talk:enable_c":
            await talkative_handler.enable_chat(update, context)
        elif data == "talk:disable_c":
            await talkative_handler.disable_chat(update, context)
        elif data == "talk:provider":
            await talkative_handler.cycle_provider(update, context)
        elif data == "talk:witai:menu":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    witai_settings_text(),
                    reply_markup=witai_settings_menu(),
                    parse_mode="Markdown",
                )
        elif data == "talk:witai:toggle":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                new_val = not getattr(config, "witai_enabled", False)
                object.__setattr__(config, "witai_enabled", new_val)
                logger.info("WITAI_TOGGLE admin=%s new_val=%s", update.effective_user.id, new_val)
                await update.callback_query.answer(f"Wit.ai {'enabled' if new_val else 'disabled'}")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    witai_settings_text(),
                    reply_markup=witai_settings_menu(),
                    parse_mode="Markdown",
                )
        elif data == "talk:witai:token_prompt":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                _talk_set_pending_input(context, "witai_token")
                await update.callback_query.answer()
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🔑 *Set Wit.ai Server Token*\n\n"
                    "Send your Wit.ai server token now.\n\n"
                    "_Get it from https://wit.ai/ → Settings → Server Access Token_",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("❌ Cancel", callback_data="talk:witai:menu"),
                    ]]),
                    parse_mode="Markdown",
                )
        elif data == "talk:witai:token_remove":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                object.__setattr__(config, "witai_server_token", "")
                object.__setattr__(config, "witai_enabled", False)
                # V87: invalidate the Wit.ai HTTP client so no old-token requests leak.
                await witai_service.invalidate_client()
                logger.info("WITAI_TOKEN_REMOVED admin=%s (client invalidated)", update.effective_user.id)
                await update.callback_query.answer("Token removed. Wit.ai disabled.")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    witai_settings_text(),
                    reply_markup=witai_settings_menu(),
                    parse_mode="Markdown",
                )
        elif data == "talk:witai:test":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("Testing...")
                # v97.92: use supervised_create_task (was bare asyncio.create_task) —
                # retains a strong ref in _active_tasks + logs exceptions via done-callback.
                supervised_create_task(
                    _witai_test_connection(update, context),
                    name="witai_test_connection",
                )
        elif data == "talk:witai:cycle_voice":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                current = getattr(config, "voice_provider", "auto")
                cycle = ["auto", "witai", "gemini", "groq"]  # V87: openrouter removed — no STT support
                try:
                    idx = cycle.index(current)
                except ValueError:
                    idx = -1
                nxt = cycle[(idx + 1) % len(cycle)]
                object.__setattr__(config, "voice_provider", nxt)
                logger.info("WITAI_VOICE_PROVIDER_CYCLE admin=%s new=%s", update.effective_user.id, nxt)
                await update.callback_query.answer(f"Voice Provider → {nxt}")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    witai_settings_text(),
                    reply_markup=witai_settings_menu(),
                    parse_mode="Markdown",
                )
        elif data == "talk:witai:cycle_intent":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                current = getattr(config, "intent_provider", "auto")
                cycle = ["auto", "witai", "gemini", "groq"]
                try:
                    idx = cycle.index(current)
                except ValueError:
                    idx = -1
                nxt = cycle[(idx + 1) % len(cycle)]
                object.__setattr__(config, "intent_provider", nxt)
                logger.info("WITAI_INTENT_PROVIDER_CYCLE admin=%s new=%s", update.effective_user.id, nxt)
                await update.callback_query.answer(f"Intent Provider → {nxt}")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    witai_settings_text(),
                    reply_markup=witai_settings_menu(),
                    parse_mode="Markdown",
                )
        elif data == "talk:witai:diag":
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                diag_text = _witai_diagnostics_text()
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    diag_text,
                    reply_markup=witai_settings_menu(),
                    parse_mode="Markdown",
                )
        elif data == "talk:witai:voice_check":
            # V86.4: Voice Pipeline Check — runs full end-to-end diagnostics.
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("Running voice pipeline check...")
                # v97.92: use supervised_create_task (was bare asyncio.create_task).
                supervised_create_task(
                    _witai_voice_check_handler(update, context),
                    name="witai_voice_check_handler",
                )
        elif data == "talk:personality":
            # Prompt the admin to send `personality: <text>`.
            if not _talk_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # Set the pending-input marker so route_message knows to
                # route the next text message to the personality handler.
                # Uses the helper for an atomic replace of any previous
                # marker (e.g. if the admin navigated here from the wake
                # words screen).
                _talk_set_pending_input(context, "personality_select")
                await update.callback_query.answer()
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🎭 *Personality*\n\nSend a message in the format:\n"
                    "`personality: <your personality description>`\n\n"
                    "Use `personality: clear` to remove it.",
                    reply_markup=talkative_back(),
                )
        elif data == "talk:memory":
            await talkative_handler.cycle_memory(update, context)
        elif data == "talk:timeout":
            await talkative_handler.cycle_timeout(update, context)
        elif data == "talk:cooldown":
            await talkative_handler.cycle_cooldown(update, context)
        elif data == "talk:group_ctx":
            await talkative_handler.toggle_group_ctx(update, context)
        elif data == "talk:group_ctx_msgs":
            await talkative_handler.cycle_group_ctx_msgs(update, context)
        elif data == "talk:lang":
            await talkative_handler.cycle_language(update, context)
        elif data == "talk:typing":
            await talkative_handler.toggle_typing(update, context)
        elif data == "talk:private_auto":
            await talkative_handler.toggle_private_auto(update, context)
        elif data == "talk:wake":
            await talkative_handler.show_wake_words(update, context)
        elif data == "talk:status":
            await talkative_handler.show_menu(update, context)
        elif data == "talk:clear_mem":
            await talkative_handler.clear_memory(update, context)
        elif data == "talk:back":
            await talkative_handler.show_menu(update, context)
        elif data.startswith("talk:wakedel:"):
            try:
                word_id = int(data.split(":")[2])
            except (ValueError, IndexError):
                await update.callback_query.answer("Invalid id.")
            else:
                await talkative_handler.delete_wake_word(update, context, word_id)
        elif data == "vc:start":
            await vc_handler.start_tour(update, context)
        elif data == "vc:pause":
            await vc_handler.pause_tour(update, context)
        elif data == "vc:resume":
            await vc_handler.resume_tour(update, context)
        elif data == "vc:stop":
            await vc_handler.stop_tour(update, context)
        elif data == "vc:current":
            await vc_handler.show_current(update, context)
        elif data == "vc:status":
            await vc_handler.refresh_status(update, context)
        elif data.startswith("vc:hist:"):
            try:
                page = int(data.split(":")[2])
            except (ValueError, IndexError):
                page = 0
            await vc_handler.show_history(update, context, page)
        elif data == "vc:refresh":
            await vc_handler.refresh_groups(update, context)
        elif data == "vc:manual":
            await vc_handler.show_manual_menu(update, context)
        elif data == "vc:settings":
            await vc_handler.show_settings(update, context)
        elif data == "vc:jointarget":
            await vc_handler.enter_join_target(update, context)
        elif data == "vc:leave":
            await vc_handler.leave_current(update, context)
        elif data == "vc:stay5":
            await vc_handler.stay_5min(update, context)
        elif data == "vc:staycustom":
            await vc_handler.enter_custom_stay(update, context)
        elif data == "vc:checktarget":
            await vc_handler.check_target(update, context)
        # --- Live VC Dashboard (admin) ---
        elif data == "vc:dash":
            await vc_handler.show_dashboard(update, context)
        elif data == "vc:dash_refresh":
            await vc_handler.refresh_dashboard(update, context)
        elif data == "vc:close_dash":
            await vc_handler.close_dashboard(update, context)
        elif data == "vc:backend_test":
            await vc_handler.backend_test(update, context)
        elif data == "vc:queue_view":
            await vc_handler.queue_view(update, context)
        elif data == "vc:multi_probe":
            await vc_handler.multi_probe(update, context)
        elif data == "vc:participations":
            await vc_handler.participations(update, context)
        elif data == "vc:cleanup_req":
            await vc_handler.cleanup_required(update, context)
        elif data == "vc:leave_all":
            await vc_handler.leave_all(update, context)
        elif data == "vc:leave_all_confirm":
            await vc_handler.leave_all(update, context)
        # --- Phase 9/10/17 (Task ID 11) — new dashboard V3 routes ---
        elif data == "vc:rebuild_queue":
            await vc_handler.rebuild_queue(update, context)
        elif data == "vc:join_multi":
            await vc_handler.join_multi(update, context)
        elif data.startswith("vc:joinpick:"):
            await vc_handler.join_multi(update, context)
        elif data == "vc:joinmulti_go":
            await vc_handler.join_multi(update, context)
        elif data == "vc:joinmulti_clear":
            await vc_handler.join_multi(update, context)
        elif data == "vc:two_target_probe":
            await vc_handler.two_target_probe(update, context)
        elif data == "vc:two_target_confirm":
            await vc_handler.two_target_probe(update, context)
        elif data == "vc:leave_selected":
            await vc_handler.leave_selected(update, context)
        elif data.startswith("vc:leaveone:"):
            await vc_handler.leave_selected(update, context)
        elif data == "vc:export_logs":
            await vc_handler.export_logs(update, context)
        # --- Join All Active VCs (one-click admin feature) ---
        elif data == "vc:join_all_active":
            await vc_handler.join_all_active(update, context)
        elif data == "vc:join_all_stop":
            await vc_handler.join_all_stop(update, context)
        elif data == "vc:join_all_progress":
            await vc_handler.join_all_progress(update, context)
        # --- VC Watcher routes (#18) ---
        elif data == "vc:watcher_start":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                result = await vc_watcher_start()
                if result == "started":
                    await update.callback_query.answer("👁 VC Watcher started")
                else:
                    await update.callback_query.answer(f"Watcher: {result}", show_alert=True)
        elif data == "vc:watcher_stop":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                result = await vc_watcher_stop()
                await update.callback_query.answer(f"Watcher: {result}")
        # --- VC Group Discovery routes (#29, #30) ---
        # --- Dual-Mode Discovery Search Menu (#1) ---

        # ===================================================================
        # V86 — Independent Discovery Module callbacks (disc:*)
        # These are the new top-level Discovery entry points, accessible
        # from the admin menu.  They delegate to DiscoveryManager.
        # ===================================================================
        elif data == "disc:main" or data == "disc:menu":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                await _menu_edit(update, "🔍 *Discovery Hub*\n\nSearch and discover Telegram groups, channels, and voice chats.\n\nSelect an option below.", discovery_unified_menu())

        elif data == "disc:search_prompt":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                if context.user_data is not None:
                    context.user_data["vc_disc_awaiting_query"] = "unified_search"
                    context.user_data["disc_search_type"] = "unified"
                await _menu_edit(update,
                    "🔍 *Discovery Search*\n\nSend me a keyword, @username, or invite link to search.\n\n_Examples: `english`, `@python`, `https://t.me/gaming`_",
                    InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data="disc:main")]]))

        elif data == "disc:groups":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("🔍 Send a keyword to search groups.", show_alert=False)
                if context.user_data is not None:
                    context.user_data["vc_disc_awaiting_query"] = "manual_search"
                    context.user_data["disc_search_type"] = "groups"
                await _menu_edit(update,
                    "🔍 *Public Group Search*\n\nSend a keyword (e.g. `english`, `music`, `gaming`) to search for public Telegram groups.",
                    discovery_back_menu())

        elif data == "disc:channels":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("📺 Send a keyword to search channels.", show_alert=False)
                if context.user_data is not None:
                    context.user_data["vc_disc_awaiting_query"] = "manual_search"
                    context.user_data["disc_search_type"] = "channels"
                await _menu_edit(update,
                    "📺 *Public Channel Search*\n\nSend a keyword to search for public Telegram channels (broadcast channels included).",
                    discovery_back_menu())

        elif data == "disc:users":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("👤 Send a @username to search.", show_alert=False)
                if context.user_data is not None:
                    context.user_data["vc_disc_awaiting_query"] = "manual_search"
                    context.user_data["disc_search_type"] = "users"
                await _menu_edit(update,
                    "👤 *User Search*\n\nSend a @username to resolve a public Telegram user.",
                    discovery_back_menu())

        elif data == "disc:vcs":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer("🎙 Send a keyword to find active VCs.", show_alert=False)
                if context.user_data is not None:
                    context.user_data["vc_disc_awaiting_query"] = "manual_search"
                    context.user_data["disc_search_type"] = "voice_chats"
                await _menu_edit(update,
                    "🎙 *Voice Chat Discovery*\n\nSend a keyword to search for groups with active voice chats.",
                    discovery_back_menu())

        elif data == "disc:saved":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                saved = await DiscoveryManager.load_saved()
                if not saved:
                    text = "💾 *Saved Results*\n\nNo saved entities yet."
                else:
                    lines = ["💾 *Saved Results*", ""]
                    for s in saved[:20]:
                        lines.append(f"• {s['entity_type']}: {s.get('title') or s.get('username') or s['entity_id']}")
                    text = "\n".join(lines)
                await _menu_edit(update, text, discovery_back_menu())

        elif data == "disc:history":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                history = await DiscoveryManager.load_history(limit=20)
                if not history:
                    text = "📜 *Discovery History*\n\nNo searches yet."
                else:
                    lines = ["📜 *Discovery History*", ""]
                    for h in history:
                        ok = "✅" if h["success"] else "❌"
                        lines.append(f"{ok} `{h['search_type']}` `{h['query'][:30]}` → {h['results_found']} results ({h['duration_ms']}ms)")
                    text = "\n".join(lines)
                await _menu_edit(update, text, discovery_back_menu())

        elif data == "disc:stats":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                stats = await DiscoveryManager.get_statistics()
                lines = [
                    "📊 *Discovery Statistics*",
                    "",
                    f"• Searches Executed: `{stats.get('searches_executed', 0)}`",
                    f"• Successful: `{stats.get('successful_searches', 0)}`",
                    f"• Failed: `{stats.get('failed_searches', 0)}`",
                    f"• Groups Found: `{stats.get('groups_found', 0)}`",
                    f"• Channels Found: `{stats.get('channels_found', 0)}`",
                    f"• Telegram Requests: `{stats.get('telegram_requests', 0)}`",
                    f"• Avg Runtime: `{stats.get('average_runtime_ms', 0)}ms`",
                    f"• History Total: `{stats.get('history_total', 0)}`",
                    f"• History Success Rate: `{stats.get('history_success_rate', 0):.1f}%`",
                    f"• Saved: `{stats.get('saved', {})}`",
                ]
                await _menu_edit(update, "\n".join(lines), discovery_back_menu())

        elif data == "disc:diag":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                diag = await DiscoveryManager.get_diagnostics()
                health = diag.get("health", {})
                rpt = diag.get("last_report", {})
                lines = [
                    "🔧 *Discovery Diagnostics*",
                    "",
                    f"• Health Score: `{health.get('health_score', 0)}/100`",
                    f"• MTProto: `{'✅' if health.get('mtproto_started') else '❌'}`",
                    f"• Healthy Accounts: `{health.get('accounts_healthy', 0)}/{health.get('accounts_total', 0)}`",
                    f"• Last Query: `{rpt.get('query', '')[:40]}`",
                    f"• Last Reason: `{rpt.get('reason', 'none')}`",
                    f"• Last Results: `{rpt.get('raw_results', 0)}`",
                    f"• Last Runtime: `{rpt.get('runtime_ms', 0)}ms`",
                    f"• Last Account: `{rpt.get('selected_account', '')}`",
                ]
                await _menu_edit(update, "\n".join(lines), discovery_back_menu())

        elif data == "disc:refresh":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                result = await DiscoveryManager.refresh()
                await update.callback_query.answer(
                    f"Cache cleared: {result.get('cache_cleared', 0)} entries", show_alert=False)
                await _menu_edit(update, await discovery_main_text(),
                                 discovery_main_menu())

        # ===================================================================
        # End V86 Discovery Module callbacks
        # ===================================================================

        elif data == "vc:disc_search_menu":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🔍 *Discovery Search*\n\nChoose a discovery mode:",
                    reply_markup=discovery_search_menu(),
                )
        # --- Manual Discovery (#2, #3) ---
        elif data == "vc:dman:menu":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer()
                menu_kb = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔎 Enter Keyword", callback_data="vc:dman:prompt")],
                    [InlineKeyboardButton("📋 Recent Results", callback_data="vc:disc_results")],
                    [InlineKeyboardButton("⬅ Back", callback_data="vc:disc_search_menu")],
                ])
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🔎 *Manual Discovery*\n\n"
                    "Search public Telegram groups by keyword.\n"
                    "The userbot will immediately search for your exact keyword.\n\n"
                    "_Click 'Enter Keyword' to start._",
                    reply_markup=menu_kb,
                )
        elif data == "vc:dman:prompt":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                context.user_data["vc_disc_awaiting_query"] = "manual_search"  # type: ignore[index]
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "🔎 *Manual Discovery*\n\n"
                    "Send a keyword to search public groups.\n\n"
                    "Examples: `music`, `english speaking`, `study`, `gaming`, `anime`\n\n"
                    "_Send the keyword now, or /cancel to abort._",
                    reply_markup=vc_dashboard_back_menu(),
                )
        elif data == "vc:dman:cancel":
            # V40 Fix #3/#5: real cancellation of the owned per-admin Manual Discovery task.
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                result = await manual_discovery_cancel(
                    admin_id=update.effective_user.id,
                    chat_id=update.effective_chat.id)
                await update.callback_query.answer(f"🛑 {result}")
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"⏹ *Manual Discovery cancelled*\n"
                    f"Status: `{result}`\n\n"
                    f"_The search task was interrupted._",
                    reply_markup=vc_dashboard_back_menu(),
                )
        elif data.startswith("vc:dman:select:"):
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                try:
                    gid = int(data.split(":")[2])
                except (ValueError, IndexError):
                    await update.callback_query.answer("Invalid ID.")
                    return
                selected = manual_discovery_toggle_select(
                    gid, admin_id=update.effective_user.id,
                    chat_id=update.effective_chat.id)
                await update.callback_query.answer(
                    f"{'✅ Selected' if selected else '⬜ Unselected'} {gid}")
        elif data.startswith("vc:dman:join_vc:"):
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                try:
                    gid = int(data.split(":")[2])
                except (ValueError, IndexError):
                    await update.callback_query.answer("Invalid ID.")
                    return
                await update.callback_query.answer("🎙 Joining VC...")
                result = await manual_discovery_join_vc(gid)
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"🎙 Join VC result for `{gid}`: `{result}`",
                    reply_markup=vc_dashboard_back_menu(),
                )
        elif data.startswith("vc:dman:join_grp:"):
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                try:
                    gid = int(data.split(":")[2])
                except (ValueError, IndexError):
                    await update.callback_query.answer("Invalid ID.")
                    return
                await update.callback_query.answer("👥 Joining group...")
                result = await manual_discovery_join_group(gid)
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"👥 Join group result for `{gid}`: `{result}`",
                    reply_markup=vc_dashboard_back_menu(),
                )
        elif data.startswith("vc:dman:leave_vc:"):
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
                return
            gid_str = data.split("vc:dman:leave_vc:")[1]
            try:
                gid = int(gid_str)
            except ValueError:
                await update.callback_query.answer("Invalid group ID.", show_alert=True)
                return
            try:
                await vc_leave_target(gid)
                await update.callback_query.answer("✅ Left the voice chat.")
            except Exception as exc:
                await update.callback_query.answer(f"❌ Failed: {str(exc)[:80]}", show_alert=True)
        # --- Auto Discovery (#6, #7, #8) ---
        elif data == "vc:dauto:menu":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                auto_state = auto_discovery_get_state()
                status = auto_state.get("status", "idle")
                menu_kb = InlineKeyboardMarkup([
                    [
                        InlineKeyboardButton("▶ Start" if status != "running" else "✅ Running",
                                             callback_data="vc:dauto:start"),
                        InlineKeyboardButton("⏹ Stop", callback_data="vc:dauto:stop"),
                    ],
                    [
                        InlineKeyboardButton("⏸ Pause" if status == "running" else "▶ Resume",
                                             callback_data="vc:dauto:pause" if status == "running" else "vc:dauto:resume"),
                    ],
                    [
                        InlineKeyboardButton("📋 Live Results", callback_data="vc:disc_results"),
                        InlineKeyboardButton("🎙 Active VCs", callback_data="vc:dauto:active_vcs"),
                    ],
                    [InlineKeyboardButton("⬅ Back", callback_data="vc:disc_search_menu")],
                ])
                await update.callback_query.answer()
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    f"🤖 *Auto Discovery*\n\n"
                    f"Status: `{status}`\n"
                    f"Cycle: `{auto_state.get('cycle', 0)}`\n"
                    f"Queries executed: `{auto_state.get('queries_executed', 0)}`\n"
                    f"Unique groups: `{auto_state.get('unique_groups', 0)}`\n"
                    f"Active VCs: `{auto_state.get('active_vcs', 0)}`\n\n"
                    f"_Auto Search is independent of Multi-VC mode._\n"
                    f"_Auto VC join requires Multi-VC mode ON._",
                    reply_markup=menu_kb,
                )
        elif data == "vc:dauto:start":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # v97.5 RACE FIX: pass ui_bot + ui_chat_id so
                # auto_discovery_start sends "Starting..." + stores the IDs
                # BEFORE creating the task.  This eliminates the race where
                # the task started before the IDs were stored, leaving the
                # UI at "Starting..." for the entire first cycle.
                result = await auto_discovery_start(
                    admin_requested=True,
                    ui_bot=context.bot,
                    ui_chat_id=update.effective_chat.id,
                )
                if result == "started":
                    await update.callback_query.answer("🤖 Auto Discovery started")
                else:
                    await update.callback_query.answer(f"Auto: {result}", show_alert=True)
        elif data == "vc:dauto:stop":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # v97 PART P FIX: persist=True writes discovery_enabled=0 so
                # the admin's disable choice survives restarts and the
                # watchdog will NOT restart discovery.
                result = await auto_discovery_stop(persist=True)
                await update.callback_query.answer(f"Auto: {result}")
        elif data == "vc:dauto:pause":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                result = auto_discovery_pause()
                await update.callback_query.answer(f"Auto: {result}")
        elif data == "vc:dauto:resume":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                result = auto_discovery_resume()
                await update.callback_query.answer(f"Auto: {result}")
        elif data == "vc:dauto:active_vcs":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # Show discovered groups with active VCs.
                results, total = await vc_discovery_results_page(page=0, per_page=15, active_only=True)
                lines = [f"🎙 *Active VCs from Discovery* ({total} total)\n"]
                for r in results[:15]:
                    title = (r.get("title") or str(r.get("group_id","?")))[:30]
                    link = r.get("public_link") or "Link unavailable"
                    if link != "Link unavailable" and r.get("username"):
                        link_display = f"[🔗 @{r['username']}]({link})"
                    else:
                        link_display = "_Link unavailable_"
                    gid = r.get("group_id", 0)
                    lines.append(f"🎙 `{gid}` {title}\n   {link_display}")
                    lines.append(f"   [🎙 Join VC](callback:vc:dman:join_vc:{gid})")
                if not results:
                    lines.append("_No active VCs discovered yet._")
                lines.append("")
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "\n".join(lines),
                    reply_markup=vc_dashboard_back_menu(),
                )
        # --- Discovery V2 new menu items (#1, #9, #11, #12, #13, #23, #24) ---
        elif data == "vc:dv2:active_vcs":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # #9: Active VC Finder — show discovered groups with active VCs.
                results, total = await vc_discovery_results_page(page=0, per_page=15, active_only=True)
                lines = [f"🎙 *Active VC Finder* ({total} total)\n"]
                for r in results[:15]:
                    title = (r.get("title") or str(r.get("group_id","?")))[:30]
                    link = r.get("public_link") or "Link unavailable"
                    if link != "Link unavailable" and r.get("username"):
                        link_display = f"[🔗 @{r['username']}]({link})"
                    else:
                        link_display = "_Link unavailable_"
                    gid = r.get("group_id", 0)
                    lines.append(f"🎙 `{gid}` {title}\n   {link_display}")
                    # Check participation state.
                    rec = await vc_registry_get(int(gid)) if gid else None
                    if rec and rec.state == "joined":
                        lines.append(f"   ✅ Joined · [🚪 Leave](callback:vc:dman:leave_vc:{gid})")
                    else:
                        lines.append(f"   [🎙 Join VC](callback:vc:dman:join_vc:{gid})")
                if not results:
                    lines.append("_No active VCs discovered yet._")
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "\n".join(lines),
                    reply_markup=discovery_search_menu(),
                )
        elif data == "vc:dv2:recent":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # #11: Recent Results with filters.
                results, total = await vc_discovery_results_page(page=0, per_page=20)
                lines = [f"🕘 *Recent Results* ({total} total)\n"]
                for r in results[:20]:
                    title = (r.get("title") or str(r.get("group_id","?")))[:30]
                    active = "🎙" if r.get("active_vc") else "—"
                    status = r.get("status", "?")
                    gid = r.get("group_id", 0)
                    ts = str(r.get("discovered_at", ""))[:19]
                    lines.append(f"{active} `{gid}` {title} ({status}) `{ts}`")
                if not results:
                    lines.append("_No results yet._")
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "\n".join(lines),
                    reply_markup=discovery_search_menu(),
                )
        elif data == "vc:dv2:saved":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # #12: Saved Searches (framework — stored in DB).
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "💾 *Saved Searches*\n\n"
                    "Saved search profiles are stored in the database.\n"
                    "Use Manual Search to find groups, then save the profile.\n\n"
                    "_Feature framework ready — admin can add saved searches via commands._",
                    reply_markup=discovery_search_menu(),
                )
        elif data == "vc:dv2:brain":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # #13: Query Brain — show autonomous learning state.
                top = await vc_discovery_autonomous_get_top(15)
                counts = await vc_discovery_autonomous_count()
                lines = [
                    f"🧠 *Query Brain*\n\n"
                    f"Active: `{counts.get('active',0)}` · Retired: `{counts.get('retired',0)}`\n",
                ]
                if top:
                    lines.append("*Top queries by score:*")
                    for q in top[:10]:
                        ret = "💀" if q.get("retired") else "✅"
                        lines.append(
                            f"  {ret} `{str(q.get('query',''))[:30]}` "
                            f"score={q.get('score',0):.1f} "
                            f"runs={q.get('runs',0)} "
                            f"unique={q.get('unique_groups',0)}"
                        )
                else:
                    lines.append("_No autonomous queries yet._")
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "\n".join(lines),
                    reply_markup=discovery_search_menu(),
                )
        elif data == "vc:dv2:settings":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # #23: Discovery Settings.
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"⚙ *Discovery V2 Settings*\n\n"
                    f"Autonomous: {'✅' if config.vc_discovery_autonomous else '⏹'}\n"
                    f"Search interval: `{config.vc_discovery_interval}s`\n"
                    f"Max queries/cycle: `{config.vc_discovery_max_queries_per_cycle}`\n"
                    f"Results/query: `{config.vc_discovery_results_per_query}`\n"
                    f"Pages/query: `{config.vc_discovery_pagination_pages}`\n"
                    f"Learning: {'✅' if config.vc_discovery_autonomous else '⏹'}\n"
                    f"Pool size: `{config.vc_discovery_autonomous_pool_size}`\n"
                    f"Min score: `{config.vc_discovery_autonomous_min_score}`\n"
                    f"Retire after zeros: `{config.vc_discovery_autonomous_retire_after_zeros}`\n"
                    f"Auto-join: {'✅' if config.vc_discovery_auto_join else '⏹'}\n"
                    f"Auto-join requires Multi-VC: `ON`\n"
                    f"Max runtime: `{config.vc_discovery_max_runtime_seconds}s`\n"
                    f"FloodWait retries: `{config.vc_discovery_floodwait_max_retries}`\n\n"
                    f"_Settings are configured via environment variables._",
                    reply_markup=discovery_search_menu(),
                )
        elif data == "vc:dv2:diag":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # #24: Diagnostics.
                m_proto = mtproto_is_started()
                auto_state = auto_discovery_get_state()
                manual_state = manual_discovery_get_state(
                    admin_id=update.effective_user.id,
                    chat_id=update.effective_chat.id)
                caps = _vc_talkative_capabilities if _vc_talkative_capabilities is not None else {"degraded": True, "ready": False}
                await update.callback_query.answer()
                # V63 Fix #3: show real runtime state, not placeholders.
                # Distinguish Disabled / Idle / Running / Waiting / FloodWait / Error.
                auto_status = auto_state.get('status', 'idle')
                if not config.mtproto_configured:
                    auto_status_display = "Disabled by configuration"
                elif auto_status == "idle" and not auto_state.get("active"):
                    auto_status_display = "Idle (not started)"
                elif auto_status == "running":
                    auto_status_display = "Running"
                elif auto_status == "waiting":
                    auto_status_display = "Waiting for MTProto"
                elif auto_status == "floodwait":
                    auto_status_display = "FloodWait (paused)"
                elif auto_status == "error":
                    auto_status_display = f"Error: {auto_state.get('last_error', 'unknown')[:60]}"
                elif auto_status == "stopped":
                    auto_status_display = "Stopped"
                else:
                    auto_status_display = auto_status.title()
                # V63 Fix #2: scheduler heartbeat diagnostics.
                last_cycle_ago = ""
                if auto_state.get("last_cycle_at", 0) > 0:
                    secs_ago = int(time.monotonic() - auto_state["last_cycle_at"])
                    last_cycle_ago = f" ({secs_ago}s ago)"
                last_search_ago = ""
                if auto_state.get("last_search_at", 0) > 0:
                    secs_ago = int(time.monotonic() - auto_state["last_search_at"])
                    last_search_ago = f" ({secs_ago}s ago)"
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"🔧 *Discovery V2 Diagnostics*\n\n"
                    f"MTProto connected: `{'✅' if m_proto else '❌'}`\n"
                    f"Old scheduler: `disabled_v2`\n"
                    f"Auto discovery: `{auto_status_display}`\n"
                    f"Scheduler running: `{'✅' if auto_state.get('scheduler_running') else '❌'}`\n"
                    f"Queue worker running: `{'✅' if auto_state.get('queue_worker_running') else '❌'}`\n"
                    f"Last cycle: `{auto_state.get('last_cycle_at', 0) and 'yes' or 'never'}{last_cycle_ago}`\n"
                    f"Last search: `{auto_state.get('last_search_at', 0) and 'yes' or 'never'}{last_search_ago}`\n"
                    f"Last queue activity: `{auto_state.get('last_queue_activity', 0) and 'yes' or 'never'}`\n"
                    f"Queue processed: `{auto_state.get('queue_processed', 0)}`\n"
                    f"Queue failures: `{auto_state.get('queue_failures', 0)}`\n"
                    f"Restart count: `{auto_state.get('restart_count', 0)}`\n"
                    f"Manual search: `{manual_state.get('status', 'idle')}`\n"
                    f"Auto cycle: `{auto_state.get('cycle', 0)}`\n"
                    f"Auto queries: `{auto_state.get('queries_executed', 0)}`\n"
                    f"Auto unique: `{auto_state.get('unique_groups', 0)}`\n"
                    f"Auto active VCs: `{auto_state.get('active_vcs', 0)}`\n"
                    f"Auto joined VCs: `{auto_state.get('joined_vcs', 0)}`\n"
                    f"Auto deferred: `{auto_state.get('deferred', 0)}`\n"
                    f"Auto FloodWaits: `{auto_state.get('floodwaits', 0)}`\n"
                    f"Auto errors: `{auto_state.get('search_failures', 0)}`\n"
                    f"Manual results: `{manual_state.get('unique_results', 0)}`\n"
                    f"VC backend: `{'✅' if vc_get_backend() else '❌'}`\n"
                    f"In-flight claims: `{len(_vc_in_flight_joins)}`\n"
                    f"Deferred queue: `{len(_vc_deferred_queue)}`",
                    reply_markup=discovery_search_menu(),
                )
        elif data == "vc:disc_start":
            # V40 Fix #4: old scheduled Discovery is disabled (disabled_v2).
            # Redirect to the Discovery V2 Control Center with a notice.
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                await update.callback_query.answer(
                    "Old Discovery is disabled_v2 — use Discovery V2", show_alert=True)
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🔍 *Discovery V2*\n\n"
                    "_The old scheduled Discovery engine is disabled "
                    "(disabled_v2) and replaced by Discovery V2._\n\n"
                    "Choose a discovery mode:",
                    reply_markup=discovery_search_menu(),
                )
        elif data == "vc:disc_stop":
            # V40 Fix #4: old scheduled Discovery is disabled — nothing to stop.
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # If Auto Discovery is running, stop it (that's the real engine).
                if _auto_discovery_state.get("active"):
                    # v97 PART P FIX: persist=True (admin stop action).
                    result = await auto_discovery_stop(persist=True)
                    await update.callback_query.answer(f"Auto Discovery: {result}")
                else:
                    await update.callback_query.answer(
                        "Old Discovery is disabled_v2 — nothing to stop", show_alert=True)
        elif data == "vc:disc_status":
            # V40 Fix #4: unified truthful status — reports ONE model:
            # old scheduled engine (disabled_v2), Manual Discovery, Auto Discovery.
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                _st_old = vc_discovery_get_state()
                _m_old = vc_discovery_get_metrics()
                _man = manual_discovery_get_state(
                    admin_id=update.effective_user.id,
                    chat_id=update.effective_chat.id)
                _auto_st = _auto_discovery_state
                _man_icon = {"idle": "⏸", "searching": "🔎", "done": "✅",
                             "error": "❌", "cancelled": "⏹"}.get(
                    _man.get("status", "idle"), "❓")
                _auto_icon = {"idle": "⏸", "running": "🟢", "paused": "🟡",
                              "stopped": "🔴"}.get(
                    _auto_st.get("status", "idle"), "❓")
                _txt = (
                    f"🔍 *Discovery — Unified Status*\n\n"
                    f"*Old scheduled engine*\n"
                    f"Status: `disabled_v2` (replaced by Discovery V2)\n"
                    f"Running: `⏹ False` (cannot start)\n\n"
                    f"*Manual Discovery* {_man_icon}\n"
                    f"Status: `{_man.get('status', 'idle')}`\n"
                    f"Keyword: `{(_man.get('keyword') or '—')[:40]}`\n"
                    f"Results: `{len(_man.get('results', []))}` · "
                    f"Selected: `{len(_man.get('selected_ids', set()))}`\n"
                    f"Searches started: `{_man.get('searches_started', 0)}` · "
                    f"Completed: `{_man.get('searches_completed', 0)}`\n"
                    f"Generation: `{_man.get('generation', 0)}`"
                    f"{(' · Searching…' if _man.get('active') else '')}\n\n"
                    f"*Auto Discovery* {_auto_icon}\n"
                    f"Status: `{_auto_st.get('status', 'idle')}`"
                    f"{(' · Paused' if _auto_st.get('paused') else '')}\n"
                    f"Cycle: `{_auto_st.get('cycle', 0)}` · "
                    f"Phase: `{_auto_st.get('current_phase', 'idle')}`\n"
                    f"Current: `{(_auto_st.get('current_query') or '—')[:40]}`\n"
                    f"Queries: `{_auto_st.get('queries_executed', 0)}` · "
                    f"Raw: `{_auto_st.get('raw_results', 0)}`\n"
                    f"Unique: `{_auto_st.get('unique_groups', 0)}` · "
                    f"New: `{_auto_st.get('new_groups', 0)}` · "
                    f"Refreshed: `{_auto_st.get('refreshed_groups', 0)}`\n"
                    f"Active VCs: `{_auto_st.get('active_vcs', 0)}` · "
                    f"Joined: `{_auto_st.get('joined_vcs', 0)}`\n"
                    f"Failed: `{_auto_st.get('failed', 0)}` · "
                    f"Deferred: `{_auto_st.get('deferred', 0)}`\n"
                    f"FloodWaits: `{_auto_st.get('floodwaits', 0)}`\n"
                    f"Runtime: `{int(_auto_st.get('runtime_seconds', 0))}s`\n\n"
                    f"*Historical (old engine, disabled)*\n"
                    f"Cycles: `{_m_old.get('total_cycles', 0)}` · "
                    f"New groups: `{_m_old.get('total_new_groups', 0)}`\n"
                    f"Last error: `{(_st_old.get('last_error') or '—')[:80]}`"
                )
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id, _txt,
                    reply_markup=vc_dashboard_back_menu(),
                )
        # --- Feature B #37/#38: Search Now (V40 Fix #4: redirect to V2) ---
        elif data == "vc:disc_search_now":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # V40 Fix #4: old scheduled cycle is disabled. Redirect to V2.
                await update.callback_query.answer(
                    "Old Search Now is disabled_v2 — use Discovery V2", show_alert=True)
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "🔍 *Discovery V2*\n\n"
                    "_The old 'Search Now' cycle is disabled (disabled_v2)._\n"
                    "_Use Manual Search or Autonomous Discovery instead._\n\n"
                    "Choose a discovery mode:",
                    reply_markup=discovery_search_menu(),
                )
        # --- Feature B #31: Add Query (prompts for text input) ---
        elif data == "vc:disc_add_query":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                from telegram.ext import ConversationHandler  # noqa: F401
                # Set a user_data flag so the next text message is treated
                # as a query-add input.
                context.user_data["vc_disc_awaiting_query"] = "add"  # type: ignore[index]
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "➕ *Add Discovery Query*\n\n"
                    "Send the search term to add as a persistent discovery query.\n"
                    "It will be searched on future discovery cycles.\n\n"
                    "_Send the query text now, or /cancel to abort._",
                    reply_markup=vc_dashboard_back_menu(),
                )
        # --- Feature B #32: Remove Query ---
        elif data == "vc:disc_remove_query":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                context.user_data["vc_disc_awaiting_query"] = "remove"  # type: ignore[index]
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "➖ *Remove Discovery Query*\n\n"
                    "Send the search term to remove from persistent queries.\n\n"
                    "_Send the query text now, or /cancel to abort._",
                    reply_markup=vc_dashboard_back_menu(),
                )
        # --- Feature B #33: List Queries ---
        elif data == "vc:disc_list_queries":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                queries = await vc_discovery_list_queries()
                builtin = _vc_discovery_builtin_defaults()
                env_raw = (config.vc_discovery_queries or "").strip()
                env_list = [t.strip() for t in env_raw.split(",") if t.strip()] if env_raw else []
                lines = [f"📋 *Discovery Queries* (mode=`{_vc_discovery_current_mode()}`)\n"]
                lines.append(f"*Manual persistent* (`{len(queries)}`):")
                if queries:
                    for q in queries[:20]:
                        en = "✅" if q.get("enabled") else "⏹"
                        lines.append(
                            f"  {en} `{str(q.get('query',''))[:40]}` "
                            f"prio={q.get('priority',0)} src={q.get('source','?')[:15]} "
                            f"runs={q.get('total_runs',0)} new={q.get('new_groups',0)}"
                        )
                else:
                    lines.append("  _(none)_")
                lines.append(f"\n*Environment* (`{len(env_list)}`): {', '.join(env_list[:10]) or '_(none)_'}")
                lines.append(f"\n*Built-in defaults* (`{len(builtin)}`): {', '.join(builtin[:10]) or '_(none)_'}")
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id, "\n".join(lines),
                    reply_markup=vc_dashboard_back_menu(),
                )
        # --- Feature B #77: Query Settings (enable/disable/clear) ---
        elif data == "vc:disc_query_settings":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                kb2 = InlineKeyboardMarkup([
                    [InlineKeyboardButton("🗑 Clear All Manual Queries",
                                          callback_data="vc:disc_clear_queries")],
                    [InlineKeyboardButton("🔙 Back to Dashboard", callback_data="vc:dash")],
                ])
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "⚙️ *Query Settings*\n\n"
                    "Use the buttons below to manage persistent queries.\n"
                    "For enable/disable of individual queries, use:\n"
                    "`/discoverquery enable <term>`\n"
                    "`/discoverquery disable <term>`",
                    reply_markup=kb2,
                )
        elif data == "vc:disc_clear_queries":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # Feature B #36: confirmation step.
                kb3 = InlineKeyboardMarkup([
                    [InlineKeyboardButton("✅ Confirm Clear",
                                          callback_data="vc:disc_clear_confirm")],
                    [InlineKeyboardButton("❌ Cancel", callback_data="vc:disc_query_settings")],
                ])
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "⚠️ *Clear ALL manual persistent queries?*\n\n"
                    "This cannot be undone. Environment and built-in queries "
                    "are NOT affected.",
                    reply_markup=kb3,
                )
        elif data == "vc:disc_clear_confirm":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                res = await vc_discovery_clear_queries()
                await update.callback_query.answer(f"Cleared {res.get('removed',0)} queries")
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"🗑 Cleared `{res.get('removed',0)}` manual persistent queries.",
                    reply_markup=vc_dashboard_back_menu(),
                )
        # --- Feature B #77: Discovery Mode cycle ---
        elif data == "vc:disc_mode":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                # Cycle through modes: fallback → mixed → custom_only → fallback
                cur = _vc_discovery_current_mode()
                order = ["fallback", "mixed", "custom_only"]
                idx = order.index(cur) if cur in order else 0
                new_mode = order[(idx + 1) % len(order)]
                # Update config at runtime (frozen dataclass — use object.__setattr__)
                try:
                    object.__setattr__(config, "vc_discovery_mode", new_mode)
                except Exception:  # noqa: BLE001
                    pass
                logger.info("VC_DISCOVERY_MODE_CHANGED mode=%s", new_mode)
                await update.callback_query.answer(f"Mode → {new_mode}")
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"🔀 *Discovery mode changed*\n\n"
                    f"New mode: `{new_mode}`\n"
                    f"• `fallback`: custom first, builtin only if no custom\n"
                    f"• `mixed`: custom + builtin merged\n"
                    f"• `custom_only`: never use builtin",
                    reply_markup=vc_dashboard_back_menu(),
                )
        # --- Recent Discovery Results view ---
        elif data == "vc:disc_results" or data.startswith("vc:disc_results:"):
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                try:
                    page = int(data.split(":")[2]) if ":" in data and data.split(":")[2] else 0
                except (ValueError, IndexError):
                    page = 0
                results, total = await vc_discovery_results_page(page=page, per_page=15)
                total_pages = max(1, (total + 14) // 15)
                lines = [f"📍 *Recent Discovery Results* (page {page+1}/{total_pages}, {total} total)\n"]
                for r in results:
                    title = (r.get("title") or str(r.get("group_id","?")))[:30]
                    link = r.get("public_link") or "Link unavailable"
                    active = "🎙" if r.get("active_vc") else "—"
                    src = (r.get("discovery_source") or "?")[:12]
                    status = r.get("status", "?")
                    # Make verified links clickable; unverified show "Link unavailable".
                    if link != "Link unavailable" and r.get("username"):
                        link_display = f"[🔗 @{r['username']}]({link})"
                    else:
                        link_display = "_Link unavailable_"
                    lines.append(f"{active} `{r.get('group_id','?')}` {title}\n   {link_display} · `{src}` · {status}")
                if not results:
                    lines.append("_No results yet. Run a discovery cycle first._")
                nav_buttons = []
                if page > 0:
                    nav_buttons.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"vc:disc_results:{page-1}"))
                if page + 1 < total_pages:
                    nav_buttons.append(InlineKeyboardButton("Next ➡️", callback_data=f"vc:disc_results:{page+1}"))
                kb_disc = InlineKeyboardMarkup([
                    nav_buttons,
                    [InlineKeyboardButton("🔙 Back to Dashboard", callback_data="vc:dash")],
                ] if nav_buttons else [
                    [InlineKeyboardButton("🔙 Back to Dashboard", callback_data="vc:dash")],
                ])
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "\n".join(lines), reply_markup=kb_disc,
                )
        # --- Autonomous queries view ---
        elif data == "vc:disc_autonomous":
            if not _vc_is_admin(update.effective_user.id):
                await update.callback_query.answer("Not authorised.", show_alert=True)
            else:
                top = await vc_discovery_autonomous_get_top(15)
                counts = await vc_discovery_autonomous_count()
                lines = [
                    f"🤖 *Autonomous Queries* (active={counts['active']} retired={counts['retired']})\n",
                    f"Autonomous engine: {'✅ ON' if config.vc_discovery_autonomous else '⏹ OFF'}\n",
                ]
                if top:
                    lines.append("*Top queries by score:*")
                    for q in top:
                        ret = "💀" if q.get("retired") else "✅"
                        lines.append(
                            f"  {ret} `{str(q.get('query',''))[:30]}` "
                            f"score={q.get('score',0):.1f} "
                            f"runs={q.get('runs',0)} "
                            f"unique={q.get('unique_groups',0)}"
                        )
                else:
                    lines.append("_No autonomous queries yet. Discovery will generate them from group metadata._")
                await update.callback_query.answer()
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "\n".join(lines),
                    reply_markup=vc_dashboard_back_menu(),
                )
        elif data == "vc:errors_view":
            await vc_handler.show_errors(update, context, 0)
        elif data.startswith("vc:errors_view:"):
            try:
                page = int(data.split(":")[2])
            except (ValueError, IndexError):
                page = 0
            await vc_handler.show_errors(update, context, page)
        elif data == "vc:logs_view":
            await vc_handler.show_live_logs(update, context, 0)
        elif data.startswith("vc:logs_view:"):
            try:
                page = int(data.split(":")[2])
            except (ValueError, IndexError):
                page = 0
            await vc_handler.show_live_logs(update, context, page)
        elif data == "vc:skip":
            await vc_handler.skip_current(update, context)
        elif data == "b:vc":
            await vc_handler.show_menu(update, context)
        elif data == "b:vcmanual":
            await vc_handler.show_manual_menu(update, context)
        elif data == "b:vcs":
            await vc_handler.show_settings(update, context)

        # ---- VC Settings sub-menu ----
        elif data == "vcs:stay":
            await vc_handler.show_stay_presets(update, context)
        elif data.startswith("vcs:stayset:"):
            try:
                minutes = int(data.split(":")[2])
            except (ValueError, IndexError):
                minutes = 5
            await vc_handler.set_stay(update, context, minutes)
        elif data == "vcs:staycustom":
            await vc_handler.enter_custom_stay_setting(update, context)
        elif data == "vcs:cd":
            await vc_handler.show_cooldown_presets(update, context)
        elif data.startswith("vcs:cdset:"):
            try:
                seconds = int(data.split(":")[2])
            except (ValueError, IndexError):
                seconds = 30
            await vc_handler.set_cooldown(update, context, seconds)
        elif data == "vcs:cdcustom":
            await vc_handler.enter_custom_cooldown(update, context)
        elif data.startswith("vcs:t:"):
            key = data.split(":", 2)[2]
            await vc_handler.toggle_setting(update, context, key)
        elif data == "vcs:join_mode":
            # v97.1 MULTI-ACCOUNT: toggle VC Join Mode (primary <-> distributed).
            await vc_handler.toggle_join_mode(update, context)
        elif data == "vcs:refresh":
            await vc_handler.show_settings(update, context)

        # ---- History ----
        elif data == "h:dl":
            await history_handler.show_downloads(update, context)
        elif data == "h:ai":
            await history_handler.show_ai(update, context)
        elif data.startswith("h:clr"):
            await history_handler.clear(update, context, data)

        # ---- Settings cycling ----
        elif data.startswith("s:"):
            await settings_handler.handle_setting(update, context, data)

        # ---- Help sections ----
        elif data.startswith("hp:"):
            await help_handler.show_section(update, context, data)

        # V64 Fix: profile & stories callbacks.
        elif data.startswith("prof:"):
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
                return
            # V64: prof:menu is the entry point — shows the menu + prompts for input.
            if data == "prof:menu":
                await update.callback_query.answer()
                # Set state to await profile input.
                context.user_data["awaiting_profile_input"] = True
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "👤 *Profile Media & Posts Downloader*\n\n"
                    "Supported inputs:\n"
                    "• `@username`\n"
                    "• User ID (e.g. `123456789`)\n"
                    "• Profile link: `https://t.me/username`\n"
                    "• Message link: `https://t.me/username/123`\n"
                    "• Private link: `https://t.me/c/123456789/123`\n"
                    "• Forward a message from the user\n"
                    "• Common-group lookup (button below)\n\n"
                    "_Send any of the above to automatically resolve "
                    "profile info, photos, and posts._",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("👥 Search User In Common Groups",
                                              callback_data="prof:common_group_search")],
                        [InlineKeyboardButton("⬅ Back to Downloader", callback_data="m:dl")],
                    ]),
                )
                return
            # V80 ISSUE 3: Common-group search button handler.
            if data == "prof:common_group_search":
                await update.callback_query.answer()
                context.user_data["awaiting_common_group_search"] = True
                context.user_data.pop("awaiting_profile_input", None)
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "👥 *Search User In Common Groups*\n\n"
                    "Send the numeric user ID of the person you want to find.\n\n"
                    "The bot will scan all groups the MTProto account is a member of, "
                    "find the target user as a participant, extract their access_hash, "
                    "and automatically open their profile.\n\n"
                    "_Send a user ID (e.g. `123456789`)_",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("⬅ Back to Profile Menu", callback_data="prof:menu")],
                    ]),
                )
                return
            user_ref = context.user_data.get("profile_user_ref")
            if not user_ref:
                await update.callback_query.answer("Session expired. Send the @username again.", show_alert=True)
                return
            if data == "prof:info":
                await update.callback_query.answer("Fetching profile info…")
                info = await profile_resolve_entity(user_ref)
                if info.get("ok"):
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        profile_format_info(info),
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("⬅ Back", callback_data="prof:back")],
                            [InlineKeyboardButton("⬅ Main Menu", callback_data="menu:main")],
                        ]),
                    )
                else:
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        f"❌ Could not fetch profile info: `{md_escape(info.get('error', 'unknown')[:100])}`",
                        reply_markup=kb.main_menu(),
                    )
            elif data.startswith("prof:photo:"):
                which = "all" if "all" in data else "latest"
                await update.callback_query.answer(f"Downloading {which} photo(s)…")
                result = await profile_download_photo(user_ref, all_photos=(which == "all"))
                if result.get("ok"):
                    # Send each photo.
                    for path in result["paths"]:
                        try:
                            with path.open("rb") as fh:
                                await safe_send_document(
                                    context.bot, update.effective_chat.id, fh,
                                    filename=path.name,
                                    caption=f"📷 Profile photo ({which})")
                        except Exception:  # noqa: BLE001
                            pass
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        f"✅ Downloaded {result['count']} profile photo(s).",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("⬅ Back", callback_data="prof:back")],
                        ]),
                    )
                else:
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        f"❌ {result.get('error', 'Download failed')}",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("⬅ Back", callback_data="prof:back")],
                        ]),
                    )
            elif data.startswith("prof:post:"):
                # V65: Profile post download.
                which = "all" if "all" in data else "latest"
                await update.callback_query.answer(f"Downloading {which} post(s)…")
                post_result = await profile_download_posts(
                    user_ref, latest_only=(which == "latest"))
                if post_result.get("ok"):
                    # Send each post.
                    for i, post in enumerate(post_result.get("posts", [])):
                        try:
                            cap = f"📝 Post ({i+1}/{post_result['count']})"
                            if post.get("text"):
                                cap += f"\n{post['text'][:200]}"
                            if post.get("caption"):
                                cap += f"\n{post['caption'][:200]}"
                            if post.get("media_path"):
                                with post["media_path"].open("rb") as fh:
                                    await safe_send_document(
                                        context.bot, update.effective_chat.id, fh,
                                        filename=post["media_path"].name, caption=cap)
                            else:
                                # Text-only post.
                                await safe_send_message(
                                    context.bot, update.effective_chat.id,
                                    f"📝 Post #{post.get('message_id', '?')}\n\n{post.get('text', '')[:500]}")
                        except Exception:  # noqa: BLE001
                            pass
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        f"✅ Downloaded {post_result['count']} post(s).",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("⬅ Back", callback_data="prof:back")],
                        ]),
                    )
                else:
                    reason = post_result.get("reason", "")
                    err_msg = post_result.get("error", "Download failed")
                    if reason:
                        err_msg += f"\n\nReason: {reason}"
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        f"❌ {err_msg}",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("⬅ Back", callback_data="prof:back")],
                        ]),
                    )
            elif data.startswith("prof:story:"):
                which = "all" if "all" in data else "latest"
                await update.callback_query.answer(f"Downloading {which} story/stories…")
                result = await profile_download_stories(user_ref, all_stories=(which == "all"))
                if result.get("ok"):
                    # Send each story.
                    for i, path in enumerate(result["paths"]):
                        try:
                            caption = f"📸 Story ({i+1}/{result['count']})"
                            if i < len(result.get("captions", [])) and result["captions"][i]:
                                cap_text = result["captions"][i][:200]; caption += "\n" + cap_text
                            with path.open("rb") as fh:
                                await safe_send_document(
                                    context.bot, update.effective_chat.id, fh,
                                    filename=path.name, caption=caption)
                        except Exception:  # noqa: BLE001
                            pass
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        f"✅ Downloaded {result['count']} story/stories.",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("⬅ Back", callback_data="prof:back")],
                        ]),
                    )
                elif not result.get("accessible"):
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        "❌ Stories are not visible to this account.",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("⬅ Back", callback_data="prof:back")],
                        ]),
                    )
                else:
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        f"❌ {result.get('error', 'Download failed')}",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("⬅ Back", callback_data="prof:back")],
                        ]),
                    )
            elif data == "prof:diag":
                # V64/V65 Fix: show detailed profile/photo/story/post diagnostics.
                await update.callback_query.answer("Fetching diagnostics…")
                # Re-resolve to get fresh diagnostics.
                diag_info = await profile_resolve_entity(user_ref)
                diag_lines = [
                    "🔍 *Profile Media & Posts Diagnostics*\n",
                    f"User ID: `{diag_info.get('user_id', '—')}`",
                    f"Username: `@{md_escape(diag_info.get('username', '—'))}`" if diag_info.get("username") else "Username: —",
                    f"Entity resolved: {'✅' if diag_info.get('ok') else '❌'}",
                    f"Input type: `{diag_info.get('input_type', '—')}`",
                    f"Resolution method: `{diag_info.get('resolution_method', '—')}`",
                    f"Profile photos: `{diag_info.get('photo_count', 0)}`",
                    f"Stories returned: `{diag_info.get('total_stories', diag_info.get('stories_count', 0))}`",
                    f"Pinned stories: `{diag_info.get('pinned_count', 0)}`",
                    f"Public stories: `{diag_info.get('public_count', 0)}`",
                    f"Profile posts count: `{diag_info.get('posts_count', 0)}`",
                    f"Posts visible: {'✅ YES' if diag_info.get('has_posts') else '❌ NO'}",
                    f"Latest post ID: `{diag_info.get('latest_post_id', 0)}`",
                    f"Media posts: `{diag_info.get('media_posts', 0)}`",
                    f"Text posts: `{diag_info.get('text_posts', 0)}`",
                    f"Stories visible: {'✅ YES' if diag_info.get('has_stories') else '❌ NO'}",
                    f"Stories count: `{diag_info.get('stories_count', 0)}`",
                    f"Response type: `{diag_info.get('stories_response_type', 'N/A')}`",
                    f"Failure stage: `{diag_info.get('failure_stage', '—') or '—'}`",
                    f"Posts failure stage: `{diag_info.get('posts_failure_stage', '—') or '—'}`",
                    f"Stories failure stage: `{diag_info.get('stories_failure_stage', '—') or '—'}`",
                ]
                reason = diag_info.get("posts_reason", "") or diag_info.get("stories_reason", "")
                if reason:
                    diag_lines.append(f"Failure reason: `{md_escape(reason[:150])}`")
                else:
                    diag_lines.append("Failure reason: — (none)")
                diag_lines.append(f"\nMTProto started: {'✅' if mtproto_is_started() else '❌'}")
                diag_lines.append(f"Telethon stories API: {'✅' if _check_stories_api_available() else '❌'}")
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "\n".join(diag_lines),
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("⬅ Back to Profile", callback_data="prof:back")],
                        [InlineKeyboardButton("⬅ Main Menu", callback_data="menu:main")],
                    ]),
                )
            elif data == "prof:back":
                # Re-show the profile preview.
                await update.callback_query.answer()
                info = context.user_data.get("profile_info", {})
                if info:
                    name = info.get("first_name", "—")
                    uname = info.get("username", "—")
                    uid = info.get("user_id", "—")
                    lines = [
                        "👤 *Profile Found*\n",
                        f"Name: `{md_escape(name)}`",
                        f"Username: `@{md_escape(uname)}`" if uname and uname != "—" else "Username: —",
                        f"User ID: `{uid}`",
                        "\n*Available:*",
                        f"• Profile Photos: `{info.get('photo_count', 0)}`",
                    ]
                    # V66: Show posts instead of stories in prof:back.
                    if info.get("has_posts"):
                        lines.append(f"• Profile Posts: `{info.get('posts_count', 0)}`")
                    else:
                        lines.append("• Profile Posts: — (none found)")
                    buttons = [
                        [InlineKeyboardButton("📋 Profile Info", callback_data="prof:info")],
                    ]
                    if info.get("photo_count", 0) > 0:
                        buttons.append([
                            InlineKeyboardButton("📷 Latest Photo", callback_data="prof:photo:latest"),
                            InlineKeyboardButton("📷📷 All Photos", callback_data="prof:photo:all"),
                        ])
                    # V66: Post buttons (replaces story buttons).
                    if info.get("has_posts"):
                        buttons.append([
                            InlineKeyboardButton("📝 Latest Post", callback_data="prof:post:latest"),
                            InlineKeyboardButton("📝 All Posts", callback_data="prof:post:all"),
                        ])
                    buttons.append([InlineKeyboardButton("🔍 Diagnostics", callback_data="prof:diag")])
                    buttons.append([InlineKeyboardButton("⬅ Main Menu", callback_data="menu:main")])
                    await safe_edit_message_text(
                        context.bot, update.effective_chat.id,
                        update.callback_query.message.message_id,
                        "\n".join(lines),
                        reply_markup=InlineKeyboardMarkup(buttons),
                    )

        # V64 Fix: auto-preview download callbacks.
        elif data.startswith("dl:mtproto:") or data.startswith("dl:restricted:") or data.startswith("dl:details:"):
            if not (user and user.id in config.admin_ids):
                await update.callback_query.answer("Not authorised.", show_alert=True)
                return
            # Extract message ID from callback data.
            parts = data.split(":")
            if len(parts) < 3:
                await update.callback_query.answer("Invalid callback.", show_alert=True)
                return
            msg_id_str = parts[2]
            try:
                msg_id = int(msg_id_str)
            except ValueError:
                await update.callback_query.answer("Invalid message ID.", show_alert=True)
                return
            chat_ref = context.user_data.get("auto_preview_chat_ref")
            if not chat_ref:
                await update.callback_query.answer("Session expired. Send the link again.", show_alert=True)
                return
            await update.callback_query.answer()
            if data.startswith("dl:details:"):
                # Show diagnostic details.
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"📋 *Download Diagnostics*\n\n"
                    f"Link parsed: ✅\n"
                    f"Chat ref: `{chat_ref}`\n"
                    f"Message ID: `{msg_id}`\n"
                    f"MTProto available: `{'✅' if mtproto_is_started() else '❌'}`\n"
                    f"Mode: `{'Restricted (MTProto)' if data.startswith('dl:restricted') else 'MTProto'}`",
                    reply_markup=kb.mtproto_menu(),
                )
            else:
                # Perform the download.
                await update.callback_query.answer("Starting download…")
                # Create a synthetic update-like wrapper for _mtproto_do_download.
                await _mtproto_do_download(update, context, chat_ref, msg_id)

        elif data == "mtproto:download":
            # Redirect to MTProto download mode.
            if user and user.id in config.admin_ids:
                await states.set_state(user.id, states.AWAIT_MTPROTO_DOWNLOAD)
                await update.callback_query.answer()
                await safe_edit_message_text(
                    context.bot, update.effective_chat.id,
                    update.callback_query.message.message_id,
                    "📥 *MTProto download mode*\n\n"
                    "Send me the message link again.\n\n"
                    "_Downloads via MTProto can access restricted content the "
                    "userbot can see._",
                    reply_markup=kb.cancel_back("mtproto"),
                )

        elif data == "menu:main":
            # V64: handle menu:main callback (used by auto-preview buttons).
            if user:
                await states.reset(user.id)
            await _menu_edit(update, msg.MAIN_MENU_TEXT, kb.main_menu())

        else:
            await _menu_answer(update, "Unknown action.")
    except Exception as exc:  # noqa: BLE001
        # P2 #11: handle expected callback expiry/routing failures cleanly.
        # These are benign conditions that don't need full tracebacks:
        # - MessageNotModified / message to edit not found (dashboard
        #   auto-refresh races with user clicks)
        # - CallbackQueryExpired / query is too old (user clicked a stale
        #   button)
        # - BadRequest with "query is too old" or "message to edit not found"
        exc_name = type(exc).__name__
        exc_msg = str(exc).lower()
        is_benign = (
            exc_name == "MessageNotModified"
            or "message to edit not found" in exc_msg
            or "message is not modified" in exc_msg
            or "query is too old" in exc_msg
            or "query_expired" in exc_name.lower()
            or "callback_query_expired" in exc_name.lower()
        )
        if is_benign:
            logger.debug("route_callback benign error for data=%s: %s: %s",
                         data, exc_name, str(exc)[:120])
        else:
            logger.exception("route_callback error for data=%s: %s", data, exc)
        try:
            await q.answer("⚠️ Something went wrong. Please try again.")
        except Exception:  # noqa: BLE001
            pass


async def _auto_preview_profile(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE,
                                 text: str) -> None:
    """V64: Auto-detect a profile link (@username, user ID, t.me/username)
    and generate a profile preview with action buttons.

    Shows:
      👤 Profile Found
      Name, Username, User ID
      Available: Profile Photos, Stories
      [Profile Info] [Photos] [Stories]
    """
    # Normalize the input to a chat reference.
    parsed = link_parser.parse_input(text)
    if not parsed.ok:
        return
    # Only handle usernames and channel links (not message links).
    if parsed.kind == link_parser.KIND_MESSAGE_LINK:
        return  # message links go to _auto_preview_telegram_link
    if parsed.username:
        user_ref = f"@{parsed.username}"
    elif parsed.chat_id is not None:
        user_ref = str(parsed.chat_id)
    else:
        return

    status_msg = await safe_reply_text(
        update.message, "👤 Resolving profile…")
    if status_msg is None:
        return

    # Resolve profile via MTProto.
    if not mtproto_is_started():
        await safe_edit_message_text(
            context.bot, status_msg.chat_id, status_msg.message_id,
            "❌ MTProto is not available. Profile features require the userbot account.",
            reply_markup=kb.main_menu(),
        )
        return

    info = await profile_resolve_entity(user_ref)
    if not info.get("ok"):
        await safe_edit_message_text(
            context.bot, status_msg.chat_id, status_msg.message_id,
            f"❌ Could not resolve profile.\n\n"
            f"_Diagnostics:_\n"
            f"Entity resolved: ❌\n"
            f"Failure stage: `{info.get('failure_stage', 'unknown')}`\n"
            f"Error: `{md_escape(info.get('error', 'unknown')[:100])}`",
            reply_markup=kb.main_menu(),
        )
        return

    # Store user_ref for callback handlers.
    context.user_data["profile_user_ref"] = user_ref
    context.user_data["profile_info"] = {
        "user_id": info["user_id"],
        "username": info["username"],
        "first_name": info["first_name"],
        "photo_count": info["photo_count"],
        "has_stories": info["has_stories"],
        "stories_count": info["stories_count"],
        "stories_reason": info.get("stories_reason", ""),
        # V65 Fix: store post fields so prof:back can rebuild buttons correctly.
        "has_posts": info.get("has_posts", False),
        "posts_count": info.get("posts_count", 0),
    }

    # Build the preview.
    name_parts = []
    if info.get("first_name"):
        name_parts.append(info["first_name"])
    if info.get("last_name"):
        name_parts.append(info["last_name"])
    display_name = " ".join(name_parts) or "—"

    lines = [
        "👤 *Profile Found*\n",
        f"Name: `{md_escape(display_name)}`",
        f"Username: `@{md_escape(info.get('username', '—'))}`" if info.get("username") else "Username: —",
        f"User ID: `{info.get('user_id', '—')}`",
        "\n*Available:*",
        f"• Profile Photos: `{info.get('photo_count', 0)}`",
    ]
    # V66: Show posts instead of stories in the profile card.
    if info.get("has_posts"):
        lines.append(f"• Profile Posts: `{info.get('posts_count', 0)}`")
    else:
        reason = info.get("posts_reason", "")
        if reason:
            lines.append(f"• Profile Posts: — ({reason})")
        else:
            lines.append("• Profile Posts: — (none found)")

    # Build buttons.
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
    buttons = [
        [InlineKeyboardButton("📋 Profile Info", callback_data="prof:info")],
    ]
    if info.get("photo_count", 0) > 0:
        buttons.append([
            InlineKeyboardButton("📷 Latest Photo", callback_data="prof:photo:latest"),
            InlineKeyboardButton("📷📷 All Photos", callback_data="prof:photo:all"),
        ])
    # V66: Post buttons (replaces story buttons in the UI).
    if info.get("has_posts"):
        buttons.append([
            InlineKeyboardButton("📝 Latest Post", callback_data="prof:post:latest"),
            InlineKeyboardButton("📝 All Posts", callback_data="prof:post:all"),
        ])
    # V66: Story buttons removed from UI — stories are rarely available and
    # caused user confusion. Story download functions remain for API compat.
    buttons.append([InlineKeyboardButton("🔍 Diagnostics", callback_data="prof:diag")])
    buttons.append([InlineKeyboardButton("⬅ Main Menu", callback_data="menu:main")])

    await safe_edit_message_text(
        context.bot, status_msg.chat_id, status_msg.message_id,
        "\n".join(lines),
        reply_markup=InlineKeyboardMarkup(buttons),
    )
    logger.info("PROFILE_PREVIEW success user_ref=%s user_id=%s photos=%d stories=%d",
                user_ref, info.get("user_id"), info.get("photo_count", 0),
                info.get("stories_count", 0))


async def _auto_preview_telegram_link(update: Update,
                                       context: ContextTypes.DEFAULT_TYPE,
                                       text: str) -> None:
    """V64: Auto-detect a Telegram message link and generate a preview.

    When an admin pastes a t.me link in a private chat with no active
    state workflow, this function:
      1. Parses the link (public, private t.me/c/, channel link).
      2. If it's a message link, fetches the message via MTProto (if available)
         or Bot API.
      3. Shows a preview with channel name, message ID, type, size, and
         Download buttons.

    For private/restricted content, uses MTProto (the userbot account) which
    can access content the Bot API bot cannot see. If the userbot is a member
    of the channel, the download succeeds — no false "Access denied" errors.
    """
    parsed = link_parser.parse_input(text)
    if not parsed.ok:
        # Not a valid link — let it fall through silently.
        return
    # Only handle message links (with a message_id) — channel links without
    # a message_id should go through the normal inspect/link flow.
    if parsed.kind != link_parser.KIND_MESSAGE_LINK or not parsed.message_id:
        return
    msg_id = parsed.message_id
    # Determine the chat reference.
    if parsed.username:
        chat_ref = f"@{parsed.username}"
        vis_display = "Public"
    elif parsed.chat_id is not None:
        chat_ref = parsed.chat_id
        vis_display = "Private"
    else:
        return

    status_msg = await safe_reply_text(
        update.message, "📨 Resolving message…")
    if status_msg is None:
        return

    # V64 Fix: try MTProto first (can access restricted content), then
    # fall back to Bot API. The MTProto userbot account may have access
    # to channels that the Bot API bot doesn't.
    diag = {
        "link_parsed": True,
        "entity_resolved": False,
        "membership": False,
        "message_fetched": False,
        "media_detected": False,
    }

    # Try MTProto if available.
    if mtproto_is_started():
        try:
            client = mtproto_get_client()
            if client is not None:
                # Resolve entity.
                try:
                    entity = await mtproto_call_with_retry(client.get_entity, chat_ref)
                    diag["entity_resolved"] = True
                except Exception as ent_exc:  # noqa: BLE001
                    logger.warning("AUTO_PREVIEW entity resolve failed: %s: %s",
                                   type(ent_exc).__name__, str(ent_exc)[:120])
                    entity = None

                if entity is not None:
                    # Fetch the message.
                    try:
                        messages = await mtproto_call_with_retry(
                            client.get_messages, entity, ids=msg_id)
                        message = _mtproto_extract_single_message(messages)
                        diag["message_fetched"] = message is not None
                    except Exception as msg_exc:  # noqa: BLE001
                        logger.warning("AUTO_PREVIEW message fetch failed: %s: %s",
                                       type(msg_exc).__name__, str(msg_exc)[:120])
                        message = None

                    if message is not None:
                        # Extract metadata.
                        msg_text = (message.text or message.message or "")[:500]
                        caption = ""
                        if hasattr(message, "media") and message.media:
                            diag["media_detected"] = True
                            media_type = _mtproto_media_type(message.media) or "media"
                            # Get file size if available.
                            file_size = 0
                            doc = getattr(message.media, "document", None)
                            if doc:
                                file_size = getattr(doc, "size", 0) or 0
                            elif hasattr(message.media, "photo") and message.media.photo:
                                # Photos don't have a size attribute; estimate.
                                file_size = getattr(message.media.photo, "access_hash", 0) or 0
                            size_str = human_size(file_size) if file_size else "—"
                        else:
                            media_type = "text"
                            size_str = "—"

                        # Get channel name.
                        chan_name = getattr(entity, "title", None) or getattr(entity, "username", None) or str(chat_ref)

                        # Build preview message.
                        preview_lines = [
                            "📨 *Message Found*\n",
                            f"Channel: `{md_escape(str(chan_name))}`",
                            f"Message ID: `{msg_id}`",
                            f"Type: `{media_type}`",
                            f"Size: `{size_str}`",
                            f"Visibility: `{vis_display}`",
                        ]
                        if msg_text:
                            preview_lines.append(f"\nText:\n```\n{md_escape(msg_text[:300])}\n```")

                        # Build download buttons.
                        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
                        buttons = [
                            [InlineKeyboardButton(
                                "📥 Download",
                                callback_data=f"dl:mtproto:{msg_id}")],
                        ]
                        if vis_display == "Private":
                            buttons.append([InlineKeyboardButton(
                                "📥 Download Restricted",
                                callback_data=f"dl:restricted:{msg_id}")])
                        buttons.append([InlineKeyboardButton(
                            "📋 View Details",
                            callback_data=f"dl:details:{msg_id}")])

                        # Store chat_ref in user_data for the callback handler.
                        context.user_data["auto_preview_chat_ref"] = chat_ref
                        context.user_data["auto_preview_msg_id"] = msg_id

                        await safe_edit_message_text(
                            context.bot, status_msg.chat_id, status_msg.message_id,
                            "\n".join(preview_lines),
                            reply_markup=InlineKeyboardMarkup(buttons),
                        )
                        logger.info("AUTO_PREVIEW success chat_ref=%s msg_id=%d media=%s",
                                    chat_ref, msg_id, media_type)
                        return
                    else:
                        # Message not found via MTProto — could be deleted,
                        # or the userbot isn't a member.
                        await safe_edit_message_text(
                            context.bot, status_msg.chat_id, status_msg.message_id,
                            f"❌ Message `{msg_id}` not found.\n\n"
                            f"_Diagnostics:_ Link parsed: ✅ | Entity resolved: "
                            f"{'✅' if diag['entity_resolved'] else '❌'} | "
                            f"Message fetched: ❌\n"
                            f"_The userbot account may not be a member of this channel._",
                            reply_markup=kb.main_menu(),
                        )
                        return
        except Exception as exc:  # noqa: BLE001
            logger.exception("AUTO_PREVIEW MTProto error: %s", exc)

    # MTProto not available or failed — try Bot API (public links only).
    if parsed.username and config.bot_token:
        try:
            # Bot API can fetch public channel messages via forwardMessage or copyMessage.
            # But we can't easily get a message by ID from a public channel without
            # the bot being a member. Show a helpful message.
            await safe_edit_message_text(
                context.bot, status_msg.chat_id, status_msg.message_id,
                f"📨 *Link Detected*\n\n"
                f"Channel: `@{parsed.username}`\n"
                f"Message ID: `{msg_id}`\n"
                f"Visibility: `{vis_display}`\n\n"
                f"_MTProto not available. Use the MTProto download mode for "
                f"restricted content._\n\n"
                f"_Diagnostics:_ Link parsed: ✅ | MTProto: ❌",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("📥 MTProto Download", callback_data="mtproto:download")],
                    [InlineKeyboardButton("⬅ Main Menu", callback_data="menu:main")],
                ]),
            )
            return
        except Exception:  # noqa: BLE001
            pass

    # All methods failed.
    await safe_edit_message_text(
        context.bot, status_msg.chat_id, status_msg.message_id,
        f"❌ Could not fetch message `{msg_id}`.\n\n"
        f"_Diagnostics:_ Link parsed: ✅ | Entity resolved: "
        f"{'✅' if diag['entity_resolved'] else '❌'} | "
        f"Message fetched: {'✅' if diag['message_fetched'] else '❌'}",
        reply_markup=kb.main_menu(),
    )


async def route_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.effective_user is None or update.message is None:
        return
    user_id = update.effective_user.id
    is_admin = user_id in config.admin_ids
    await repo.upsert_user(user_id, update.effective_user.username,
                           update.effective_user.first_name, is_admin)

    # Clear any stale one-shot suppressor from a previous update.  This flag
    # is set ONLY when route_message consumes a valid ``wake:``/``personality:``
    # input, and is consumed by talkative_handle_message (group=10) for the
    # SAME update.  If the previous update set it but group=10 never fired
    # (e.g. Talkative disabled), we clear it here so it cannot suppress a
    # legitimate Talkative response on a later update.
    if context.user_data:
        context.user_data.pop("_talkative_just_handled", None)

    state = await states.get_state(user_id)
    tool = await states.get_tool(user_id)

    # Talkative Mode admin text inputs (`wake:` / `personality:`) — ONLY when
    # the admin is explicitly in a Talkative configuration pending state.
    # This prevents intercepting text during other workflows (downloads, VC,
    # broadcasts, etc.).
    #
    # P0 FIX — double-response prevention: after consuming a valid input,
    # set the transient ``_talkative_just_handled`` flag so the group=10
    # Talkative chatbot handler does NOT also reply to the same message.
    # Without this, an admin in a private chat with private_auto_reply on
    # would get TWO replies: the config confirmation AND a chatbot reply.
    talkative_pending = context.user_data.get("talkative_pending_input", "")
    if is_admin and talkative_pending:
        # Wit.ai token input (no prefix required — admin pastes the raw token).
        # Must be handled BEFORE the generic wake:/personality: blocks because
        # a Wit.ai server token would never start with "wake:" or "personality:".
        if talkative_pending == "witai_token" and update.message.text:
            token = update.message.text.strip()
            if token and len(token) > 10:
                object.__setattr__(config, "witai_server_token", token)
                if not getattr(config, "witai_enabled", False):
                    object.__setattr__(config, "witai_enabled", True)
                # V87: invalidate the Wit.ai HTTP client so it rebuilds with the new token.
                await witai_service.invalidate_client()
                logger.info("WITAI_TOKEN_SET admin=%s (token redacted, client invalidated)", update.effective_user.id)
                _talk_clear_pending_input(context)
                await update.message.reply_text(
                    "✅ Wit.ai server token set. Wit.ai enabled.\n\n"
                    "Use /talkative → 🧠 Wit.ai → 🧪 Test Connection to verify.",
                )
            else:
                _talk_clear_pending_input(context)
                await update.message.reply_text("❌ Invalid token. Too short.")
            return
        if update.message.text:
            text = update.message.text.strip()
            if talkative_pending == "wake_add" and text.lower().startswith("wake:"):
                await talkative_handler.handle_wake_word_input(update, context)
                # Signal group=10 to skip this update (config reply already sent).
                if context.user_data is not None:
                    context.user_data["_talkative_just_handled"] = True
                return
            if talkative_pending == "personality_select" and text.lower().startswith("personality:"):
                await talkative_handler.handle_personality_input(update, context)
                if context.user_data is not None:
                    context.user_data["_talkative_just_handled"] = True
                return
            # V85.3 FIX BUG 1: the admin sent non-matching text while a pending
            # Talkative input marker was set.  Previously the marker was never
            # cleared here, so it persisted indefinitely and could misroute
            # future messages.  Consume the marker on ANY text input so the
            # admin is not stuck in a config mode they did not complete.
            _talk_clear_pending_input(context)
        else:
            # RELI-I-010: the admin sent a NON-text message (photo, voice,
            # sticker, etc.) while a pending Talkative input marker was set.
            # The pending flow expects text (wake:/personality:) — a non-text
            # message can never satisfy it, so clear the marker to avoid
            # leaving the admin stuck in a config mode they cannot complete.
            _talk_clear_pending_input(context)

    # Feature B #31/#32/#44: Add/Remove query text-input handler.  When the
    # admin clicked "Add Query" or "Remove Query" on the dashboard, a
    # user_data flag is set; the next text message is consumed here as the
    # query term.  No state-machine change needed — this is a lightweight
    # one-shot flag.
    disc_pending = context.user_data.get("vc_disc_awaiting_query", "") if context.user_data else ""
    if is_admin and disc_pending and update.message.text:
        text = update.message.text.strip()
        context.user_data["vc_disc_awaiting_query"] = ""  # type: ignore[index]
        if text.lower() == "/cancel":
            await safe_send_message(
                context.bot, update.effective_chat.id, "❌ Cancelled.",
                reply_markup=vc_dashboard_back_menu())
            return
        if disc_pending == "unified_search":
            # V86.2/D6: unified Discovery search flow with live progress updates.
            # v97.92: use supervised_create_task (was bare asyncio.create_task) —
            # retains a strong ref + logs exceptions via done-callback.
            supervised_create_task(
                _disc_unified_search_flow(update, context, text),
                name="disc_unified_search_flow",
            )
            return
        if disc_pending == "add":
            res = await vc_discovery_add_query(text, source="dashboard_manual")
            if res.get("ok"):
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"✅ Query added: `{text[:60]}`\n"
                    f"It will be searched on future discovery cycles.",
                    reply_markup=vc_dashboard_back_menu())
            else:
                err = res.get("error", "unknown")
                msg_map = {
                    "empty_query": "❌ Query is empty.",
                    "too_long": f"❌ Query too long (max {config.vc_discovery_query_max_length}).",
                    "duplicate": f"❌ Query already exists (case-insensitive).",
                }
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    msg_map.get(err, f"❌ Error: {err}"),
                    reply_markup=vc_dashboard_back_menu())
            return
        elif disc_pending == "remove":
            res = await vc_discovery_remove_query(text)
            if res.get("ok"):
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"✅ Query removed: `{text[:60]}`",
                    reply_markup=vc_dashboard_back_menu())
            else:
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"❌ Query not found: `{text[:60]}`",
                    reply_markup=vc_dashboard_back_menu())
            return
        elif disc_pending == "manual_search":
            # V86: check if this search came from the new top-level Discovery
            # menu (disc:*).  If so, route through DiscoveryManager with the
            # correct search type.  Otherwise, fall through to the legacy
            # manual_discovery_search_start path (preserving backward compat
            # for the vc:dman:prompt entry point).
            disc_search_type = context.user_data.get("disc_search_type", "") if context.user_data else ""
            if disc_search_type:
                # Clear the pending flags.
                context.user_data["vc_disc_awaiting_query"] = ""  # type: ignore[index]
                context.user_data["disc_search_type"] = ""  # type: ignore[index]
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"🔎 Searching {disc_search_type} for: `{text[:60]}`...")
                try:
                    if disc_search_type == "groups":
                        report = await DiscoveryManager.search_groups(text)
                    elif disc_search_type == "channels":
                        report = await DiscoveryManager.search_channels(text)
                    elif disc_search_type == "users":
                        report = await DiscoveryManager.search_users(text)
                    elif disc_search_type == "voice_chats":
                        report = await DiscoveryManager.search_voice_chats(text)
                    else:
                        report = await DiscoveryManager.search_global(text)
                except Exception as exc:  # noqa: BLE001
                    await safe_send_message(
                        context.bot, update.effective_chat.id,
                        f"❌ Search failed: {type(exc).__name__}: {str(exc)[:120]}",
                        reply_markup=discovery_back_menu())
                    return
                entities = report.get("entities", [])
                raw = report.get("raw_results", 0)
                reason = report.get("reason", "")
                if not entities:
                    if reason:
                        msg = (f"❌ No results for `{text[:60]}`.\n\n"
                               f"Reason: `{reason}`")
                    else:
                        msg = (f"📋 No results for `{text[:60]}`.\n\n"
                               f"Telegram returned 0 matches for this query.")
                    await safe_send_message(
                        context.bot, update.effective_chat.id, msg,
                        reply_markup=discovery_back_menu())
                else:
                    lines = [f"📋 *{disc_search_type.title()} Search Results*", ""]
                    for i, ent in enumerate(entities[:20], 1):
                        title = getattr(ent, "title", "") or str(getattr(ent, "id", "?"))
                        uname = getattr(ent, "username", "") or ""
                        link = f" (@{uname})" if uname else ""
                        lines.append(f"{i}. {title[:40]}{link}")
                    if raw > 20:
                        lines.append(f"\n_...and {raw - 20} more_")
                    lines.append(f"\n_Total: {raw} results_")
                    await safe_send_message(
                        context.bot, update.effective_chat.id, "\n".join(lines),
                        reply_markup=discovery_back_menu())
                return
            # #2: Manual Discovery keyword search (legacy path).
            # V40 Fix #3: launch as an OWNED asyncio.Task so Cancel can
            # genuinely interrupt a slow Telegram RPC via task.cancel().
            cancel_kb = InlineKeyboardMarkup([[
                InlineKeyboardButton("🛑 Cancel Search", callback_data="vc:dman:cancel"),
            ]])
            await safe_send_message(
                context.bot, update.effective_chat.id,
                f"🔎 Searching for: `{text[:60]}`...\n\n"
                f"_Tap 🛑 Cancel Search to interrupt._",
                reply_markup=cancel_kb)
            try:
                task = await manual_discovery_search_start(
                    text, admin_id=update.effective_user.id,
                    chat_id=update.effective_chat.id,
                    message_id=update.message.message_id)
                res = await task
            except asyncio.CancelledError:
                # V40 Fix #3: the search was cancelled (user tapped Cancel
                # or a newer search replaced this one).  Show the cancelled
                # state — never show results for a cancelled search.
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"⏹ Search cancelled for `{text[:60]}`.",
                    reply_markup=vc_dashboard_back_menu())
                return
            if res.get("errors") and res.get("error"):
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"❌ Search failed: {res['error']}",
                    reply_markup=vc_dashboard_back_menu())
                return
            # Build paginated results display.
            groups = res.get("groups", [])
            if not groups:
                # Fix 14: show accurate outcome instead of generic "No accessible groups found".
                outcome = res.get("outcome", "")
                raw_hits = res.get("raw_hits", 0)
                inaccessible = res.get("inaccessible", 0)
                duplicates = res.get("duplicates_skipped", 0)
                if outcome == "search_failed":
                    msg = (f"❌ Search failed for `{text[:60]}`.\n"
                           f"Error: {res.get('error', 'unknown')}")
                elif outcome == "zero_raw_results":
                    msg = (f"🔎 0 raw Telegram results for `{text[:60]}`.\n"
                           f"Telegram returned no matching groups for this keyword.")
                elif outcome == "all_inaccessible":
                    msg = (f"🔎 `{raw_hits}` results found for `{text[:60]}` but all "
                           f"were inaccessible ({inaccessible} private/restricted).\n"
                           f"No accessible groups to display.")
                elif outcome == "all_duplicates":
                    msg = (f"🔎 `{raw_hits}` results found for `{text[:60]}` but all "
                           f"were duplicates ({duplicates} already known).\n"
                           f"No new unique groups to display.")
                elif outcome == "metadata_failed":
                    msg = (f"🔎 `{raw_hits}` results found for `{text[:60]}` but "
                           f"metadata enrichment failed for all.\n"
                           f"Groups may exist but couldn't be persisted.")
                else:
                    msg = (f"🔎 No accessible groups found for `{text[:60]}`.\n"
                           f"Raw: {raw_hits} · Inaccessible: {inaccessible} · Duplicates: {duplicates}")
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    msg, reply_markup=vc_dashboard_back_menu())
                return
            lines = [f"🔎 *Manual Discovery Results* for `{text[:40]}`\n"
                     f"Found: `{res.get('found',0)}` · Unique: `{res.get('unique',0)}` · "
                     f"New: `{res.get('new',0)}` · Refreshed: `{res.get('refreshed',0)}`\n"]
            for g in groups[:15]:
                title = (g.get("title") or str(g.get("group_id","?")))[:30]
                link = g.get("public_link") or "Link unavailable"
                if link != "Link unavailable" and g.get("username"):
                    link_display = f"[🔗 @{g['username']}]({link})"
                else:
                    link_display = "_Link unavailable_"
                gid = g.get("group_id", 0)
                active = "🎙" if g.get("active_vc") else "—"
                new_tag = "🆕" if g.get("is_new") else "🔄"
                lines.append(f"{active} {new_tag} `{gid}` {title}\n   {link_display}")
            # Build result buttons.
            rows: list[list["InlineKeyboardButton"]] = []
            for g in groups[:10]:
                gid = g["group_id"]
                title = (g.get("title") or str(gid))[:20]
                active = "🎙" if g.get("active_vc") else ""
                rows.append([
                    InlineKeyboardButton(f"☑ {title}", callback_data=f"vc:dman:select:{gid}"),
                    InlineKeyboardButton("👥", callback_data=f"vc:dman:join_grp:{gid}"),
                    InlineKeyboardButton(f"🎙{active}", callback_data=f"vc:dman:join_vc:{gid}"),
                ])
            rows.append([InlineKeyboardButton("⬅ Back", callback_data="vc:disc_search_menu")])
            await safe_send_message(
                context.bot, update.effective_chat.id,
                "\n".join(lines),
                reply_markup=InlineKeyboardMarkup(rows),
            )
            return
        elif disc_pending == "gemini_key_replace":
            # V58 Fix: provider-aware key replacement message handler.
            admin_id = update.effective_user.id
            if not _vc_is_admin(admin_id):
                context.user_data.pop("vc_disc_awaiting_query", None)  # type: ignore[index]
                _gemini_key_pending_clear(admin_id)
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "❌ Not authorised.",
                    reply_markup=talkative_diagnostics_menu())
                return
            if update.effective_chat.type != "private":
                context.user_data.pop("vc_disc_awaiting_query", None)  # type: ignore[index]
                _gemini_key_pending_clear(admin_id)
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "🔒 Key replacement only works in private chat.",
                    reply_markup=talkative_diagnostics_menu())
                return
            if not _gemini_key_pending_active(admin_id):
                context.user_data.pop("vc_disc_awaiting_query", None)  # type: ignore[index]
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "⏰ Key replacement timed out. Please try again.",
                    reply_markup=talkative_diagnostics_menu())
                return
            candidate_key = (update.message.text or "").strip()
            try:
                await context.bot.delete_message(
                    chat_id=update.effective_chat.id,
                    message_id=update.message.message_id,
                )
            except Exception:  # noqa: BLE001
                pass
            # V58 Fix: resolve effective provider and use provider-aware validation.
            try:
                eff_p, _, _, _, _ = await talkative_effective_provider()
            except Exception:
                eff_p = config.talkative_provider or "gemini"
            valid, reason = await _provider_key_activate(eff_p, candidate_key)
            _gemini_key_pending_clear(admin_id)
            context.user_data.pop("vc_disc_awaiting_query", None)  # type: ignore[index]
            if valid:
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"✅ *{eff_p.title()} API key activated successfully.*\n\n"
                    "_The key is now active at runtime. Provider cooldown cleared._\n"
                    "_The key will be lost after restart (runtime-only)._",
                    reply_markup=talkative_diagnostics_menu())
            else:
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"❌ *Key validation failed: {reason}*\n\n"
                    "_The active key is unchanged. Provider cooldown is unchanged._",
                    reply_markup=talkative_diagnostics_menu())
            return
    # V67: Handle cluster login input (phone, OTP, 2FA password).
    cluster_awaiting = context.user_data.get("cluster_awaiting", "")
    if is_admin and update.message.text and cluster_awaiting:
        text = update.message.text.strip()
        admin_id = update.effective_user.id
        if cluster_awaiting == "phone":
            context.user_data.pop("cluster_awaiting", None)
            # Delete the user's message (contains phone number).
            try:
                await context.bot.delete_message(
                    chat_id=update.effective_chat.id,
                    message_id=update.message.message_id)
            except Exception:
                pass
            result = await cluster_start_login(admin_id, text)
            if result == "code_sent":
                context.user_data["cluster_awaiting"] = "otp"
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "📨 Login code sent. Enter the OTP code:",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("❌ Cancel", callback_data="cluster:cancel_login")],
                    ]),
                )
            elif result.startswith("registered:"):
                # v99.04 RC-16: the phone's session was ALREADY
                # live-authorized (e.g. the global primary's own phone);
                # it has now been REGISTERED as a cluster account reusing
                # the live client — the "add my second account" flow
                # completes WITHOUT a login code.
                aid = result.split("registered:")[1]
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "✅ *Account added — existing session reused!*\n\n"
                    f"Account ID: `{aid}`\n\n"
                    "_No login code was needed: the session on disk is "
                    "already authorized, so it was registered directly as a "
                    "cluster account (v99.04 RC-16)._",
                    reply_markup=cluster_menu_kb(),
                )
            elif result.startswith("already_connected:"):
                # v99.04 RC-16: informational (previously rendered as
                # "❌ Failed to send code: already_connected:<who>" — the
                # operator dead-end that led to deleting a healthy
                # session file in production).
                who = result.split("already_connected:")[1]
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"ℹ️ *Already connected and registered:* `{who}`\n\n"
                    "_This phone is already a live cluster account — "
                    "nothing to add. Use /v85accounts to inspect all "
                    "sessions._",
                    reply_markup=cluster_menu_kb(),
                )
            else:
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"❌ Failed to send code: `{result}`",
                    reply_markup=cluster_menu_kb(),
                )
            return
        elif cluster_awaiting == "otp":
            context.user_data.pop("cluster_awaiting", None)
            # Delete the user's message (contains OTP).
            try:
                await context.bot.delete_message(
                    chat_id=update.effective_chat.id,
                    message_id=update.message.message_id)
            except Exception:
                pass
            result = await cluster_submit_otp(admin_id, text)
            if result.startswith("success:"):
                aid = result.split("success:")[1]
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"✅ Account added successfully!\n\nAccount ID: `{aid}`",
                    reply_markup=cluster_menu_kb(),
                )
            elif result == "2fa_required":
                context.user_data["cluster_awaiting"] = "password"
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    "🔐 2FA enabled. Enter your Telegram password:",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("❌ Cancel", callback_data="cluster:cancel_login")],
                    ]),
                )
            else:
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"❌ Login failed: `{result}`",
                    reply_markup=cluster_menu_kb(),
                )
            return
        elif cluster_awaiting == "password":
            context.user_data.pop("cluster_awaiting", None)
            # Delete the user's message (contains password).
            try:
                await context.bot.delete_message(
                    chat_id=update.effective_chat.id,
                    message_id=update.message.message_id)
            except Exception:
                pass
            result = await cluster_submit_password(admin_id, text)
            if result.startswith("success:"):
                aid = result.split("success:")[1]
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"✅ Account added successfully (2FA)!\n\nAccount ID: `{aid}`",
                    reply_markup=cluster_menu_kb(),
                )
            else:
                await safe_send_message(
                    context.bot, update.effective_chat.id,
                    f"❌ 2FA failed: `{result}`",
                    reply_markup=cluster_menu_kb(),
                )
            return

    # V80 ISSUE 3+4: Handle common-group search input.
    if (is_admin
            and context.user_data.get("awaiting_common_group_search")
            and update.effective_chat.type == "private"):
        msg = update.message
        # V81 ISSUE 1: Check for forwarded messages BEFORE parsing text as user ID.
        # If the user sent a forwarded message while in common-group search mode,
        # route it to the forward resolver instead of trying to parse it as a user ID.
        has_forward = (
            getattr(msg, "forward", None) is not None
            or getattr(msg, "fwd_from", None) is not None
            or getattr(msg, "forward_origin", None) is not None
        )
        if has_forward:
            logger.info("FORWARD_ROUTER_HIT source=common_group_search_mode")
            context.user_data.pop("awaiting_common_group_search", None)
            context.user_data["awaiting_profile_input"] = True
            # Fall through to the profile input handler below which handles forwards.
        else:
            text = (msg.text or "").strip()
            if not text:
                await safe_reply_text(
                    update.message,
                    "⚠️ Please send a numeric user ID (e.g. `123456789`).")
                return
            context.user_data.pop("awaiting_common_group_search", None)
            # Parse the user ID.
            try:
                user_id = int(text.lstrip("+"))
            except ValueError:
                await safe_reply_text(
                    update.message,
                    "⚠️ Please send a numeric user ID (e.g. `123456789`).")
                return
            logger.info("COMMON_GROUP_PROFILE_SEARCH user_id=%s", user_id)
            client = mtproto_get_client()
            if client is None:
                await safe_reply_text(
                    update.message,
                    "⚠️ MTProto backend is not running. Enable MTPROTO_ENABLED.")
                return
            status_msg = await safe_reply_text(
                update.message,
                f"👥 Searching for user `{user_id}` in common groups…")
            try:
                found = await find_user_in_common_groups(client, user_id)
                if found:
                    access_hash = found.get("access_hash")
                    group_name = found.get("group_name", "unknown")
                    logger.info("COMMON_GROUP_PROFILE_OPENED user_id=%s group=%s",
                                user_id, group_name)
                    # V80 ISSUE 4: Auto-open the profile after common-group resolution.
                    await _auto_preview_profile(update, context, str(user_id))
                    return
                else:
                    await safe_reply_text(
                        update.message,
                        f"⚠️ User `{user_id}` was not found in any common group.\n\n"
                        "The MTProto account may not share any groups with this user, "
                        "or the user may not be a participant in any accessible group.\n\n"
                        "Try:\n"
                        "• Forward a message from the user\n"
                        "• Send a message link (t.me/username/123)\n"
                        "• Use @username")
            except Exception as exc:
                logger.warning("COMMON_GROUP_PROFILE_SEARCH_FAILED user_id=%s exc=%s: %s",
                               user_id, type(exc).__name__, str(exc)[:100])
                await safe_reply_text(
                    update.message,
                    f"⚠️ Common-group search failed: `{type(exc).__name__}: {str(exc)[:80]}`")
            return

    # V64: Handle profile input when awaiting_profile_input is set.
    if (is_admin
            and context.user_data.get("awaiting_profile_input")
            and update.effective_chat.type == "private"):
        msg = update.message
        text = (msg.text or msg.caption or "").strip()

        # V80 ISSUE 1+2: Try forwarded-message sender extraction FIRST, but
        # if it fails, FALL THROUGH to text/link handling instead of returning.
        # This fixes the case where a forwarded message contains a t.me link
        # in its text — the old code intercepted on has_forward and returned
        # "Could not extract sender" without checking the text for links.
        has_forward = (
            getattr(msg, "forward", None) is not None
            or getattr(msg, "fwd_from", None) is not None
            or getattr(msg, "forward_origin", None) is not None
        )
        if has_forward:
            logger.info("FORWARD_MESSAGE_RECEIVED for profile resolution")
            try:
                client = mtproto_get_client()
                if client is not None:
                    fwd_result = await resolve_forwarded_sender(client, msg)
                    if fwd_result.get("ok"):
                        user_id = fwd_result["user_id"]
                        logger.info("FORWARD_PROFILE_OPENED user_id=%s", user_id)
                        context.user_data.pop("awaiting_profile_input", None)
                        await _auto_preview_profile(update, context, str(user_id))
                        return
                    # V80 FIX: Don't return on failure — fall through to check
                    # if the message text contains a link or username.
                    logger.info("FORWARD_SENDER_EXTRACTION_FAILED — falling through "
                                "to text/link handling. error=%s",
                                fwd_result.get("error", "unknown"))
            except Exception as exc:
                logger.warning("FORWARD_PROFILE_OPEN_FAILED exc=%s: %s — falling through",
                               type(exc).__name__, str(exc)[:100])

        # V80 ISSUE 2: Check for message links (t.me/username/123, t.me/c/.../123,
        # telegram.me/...). This runs for both plain text AND forwarded messages
        # whose sender extraction failed (fall-through from above).
        if text:
            import re as _re_msg_link
            is_message_link = bool(
                _re_msg_link.search(r"t(?:elegram)?\.me/[^/]+/\d+", text, re.IGNORECASE) or
                _re_msg_link.search(r"t(?:elegram)?\.me/c/\d+/\d+", text, re.IGNORECASE)
            )
            if is_message_link:
                context.user_data.pop("awaiting_profile_input", None)
                logger.info("MESSAGE_LINK_RECEIVED link=%s", text[:120])
                try:
                    link_result = await resolve_message_link_sender(text)
                    if link_result.get("ok"):
                        user_id = link_result["user_id"]
                        logger.info("MESSAGE_LINK_RESOLVED link=%s user_id=%s",
                                    text[:80], user_id)
                        logger.info("MESSAGE_PROFILE_OPENED user_id=%s source=message_link",
                                    user_id)
                        await _auto_preview_profile(update, context, str(user_id))
                    else:
                        await safe_reply_text(
                            update.message,
                            f"⚠️ Could not resolve message link: "
                            f"`{link_result.get('error', 'unknown')}`")
                except Exception as exc:
                    logger.warning("MESSAGE_LINK_RESOLVE_FAILED link=%s exc=%s: %s",
                                   text[:80], type(exc).__name__, str(exc)[:100])
                    await safe_reply_text(
                        update.message,
                        f"⚠️ Message link resolution failed: "
                        f"`{type(exc).__name__}: {str(exc)[:80]}`")
                return

            # Check for profile links (@username, user ID, t.me/username).
            if profile_is_profile_link(text):
                context.user_data.pop("awaiting_profile_input", None)
                await _auto_preview_profile(update, context, text)
                return

        # V80 ISSUE 3+4: Common-group search button is handled via callback.
        # If we get here with no valid input, show helpful guidance.
        if not text and not has_forward:
            await safe_reply_text(
                update.message,
                "⚠️ Please send one of the following:\n\n"
                "• `@username`\n"
                "• User ID (e.g. `123456789`)\n"
                "• `https://t.me/username` (profile link)\n"
                "• `https://t.me/username/123` (message link)\n"
                "• `https://t.me/c/123456789/123` (private link)\n"
                "• Forward a message from the user\n"
                "• Use the 👥 Search User In Common Groups button")
            return
        elif has_forward and not text:
            # Forwarded message with no text and sender extraction failed.
            await safe_reply_text(
                update.message,
                "⚠️ Could not extract the sender from this forwarded message.\n\n"
                "The sender's privacy settings may prevent extraction.\n"
                "Try one of these alternatives:\n"
                "• Send a message link (t.me/username/123)\n"
                "• Use @username\n"
                "• Use the 👥 Search User In Common Groups button")
            return
        else:
            # Text was provided but didn't match any known format.
            await safe_reply_text(
                update.message,
                "⚠️ Telegram does not expose enough information to resolve this input.\n\n"
                "Try:\n"
                "• Forward a message from the user\n"
                "• Send a message link (t.me/username/123)\n"
                "• Use @username\n"
                "• Use a numeric user ID\n"
                "• Use the 👥 Search User In Common Groups button")
            return
    if state == states.AWAIT_DOWNLOAD_FORWARD:
        await download_handler.handle_forwarded_media(update, context)
    elif state == states.AWAIT_ANALYZE:
        await analyze_handler.handle_forwarded_video(update, context)
    elif state == states.AWAIT_INSPECT:
        await inspector_handler.handle_inspect_input(update, context)
    elif state == states.AWAIT_TOOLBOX:
        if tool == "imgconv" and update.message.text and not _has_media(update):
            await toolbox_handler.handle_imgconv_format(update, context)
        else:
            await toolbox_handler.handle_forwarded_media(update, context)
    elif state == states.AWAIT_LIBRARY_SEARCH:
        await library_handler.handle_search_input(update, context)
    elif state == states.AWAIT_QR:
        await qr_handler.handle_input(update, context)
    elif state == states.AWAIT_BATCH:
        await batch_handler.handle_batch_message(update, context)
    elif state == states.AWAIT_BACKUP_IMPORT:
        await backup_handler.handle_import_file(update, context)
    elif state == states.AWAIT_ADMIN_BCAST:
        await admin_handler.handle_broadcast(update, context)
    elif state == "await_gemini_key":
        await settings_handler.handle_gemini_key_input(update, context)
    elif state == states.AWAIT_SCHEDULE:
        await scheduled_handler.handle_schedule_input(update, context)
    elif state == states.AWAIT_LINK_DOWNLOAD:
        await link_handler.handle_input(update, context)
    elif state == states.AWAIT_LINK_MESSAGE_ID:
        await link_handler.handle_message_id_input(update, context)
    elif state == states.AWAIT_MTPROTO_SCREENSHOT:
        await mtproto_handler.handle_screenshot_input(update, context)
    elif state == states.AWAIT_MTPROTO_DOWNLOAD:
        await mtproto_handler.handle_download_input(update, context)
    elif state == states.AWAIT_MTPROTO_MSGID:
        await mtproto_handler.handle_msgid_input(update, context)
    elif state == states.AWAIT_VC_JOIN_TARGET:
        await vc_handler.handle_join_target(update, context)
    elif state == states.AWAIT_VC_CHECK_TARGET:
        await vc_handler.handle_check_target(update, context)
    elif state == states.AWAIT_VC_STAY:
        await vc_handler.handle_custom_stay(update, context)
    elif state == states.AWAIT_VC_COOLDOWN:
        # V40 Fix #8: use the correct attribute name. V39 removed the buggy
        # `handle_custom_cooldown` alias from the namespace but this call site
        # still used the old name → AttributeError on every custom-cooldown
        # input.  Now points to the real implementation.
        await vc_handler.handle_custom_cooldown_input(update, context)
    else:
        # No state-based workflow matched. Do NOT send the Main Menu
        # fallback here — that would cause a double-response with the
        # Talkative handler (group=10). Instead, silently return and let
        # the Talkative handler decide whether to respond. If Talkative
        # is disabled or doesn't trigger, the user gets no response
        # (which is correct — they can always /start or tap a button).

        # V64 Fix: Auto-detect Telegram message links and generate a preview.
        # This handles the case where an admin pastes a t.me link without
        # entering a specific download mode first. The bot automatically
        # resolves the message and shows a preview with Download buttons.

        # V66: Auto-detect forwarded messages from users → open profile.
        if (is_admin and update.effective_chat.type == "private"
                and _has_media(update) and update.message.forward_origin):
            # Extract the original sender from the forwarded message.
            forward_origin = update.message.forward_origin
            sender_id = None
            sender_username = None
            # PTB v20+ uses ForwardOrigin types.
            if hasattr(forward_origin, "sender_user"):
                sender_id = forward_origin.sender_user.id
                sender_username = forward_origin.sender_user.username
            elif hasattr(forward_origin, "sender_user_id"):
                sender_id = forward_origin.sender_user_id
            if sender_id or sender_username:
                ref = f"@{sender_username}" if sender_username else str(sender_id)
                await _auto_preview_profile(update, context, ref)
                return

        if (is_admin and update.message.text
                and update.effective_chat.type == "private"
                and not _has_media(update)):
            text = update.message.text.strip()
            # V64: Check for profile links (@username, user ID, t.me/username).
            if profile_is_profile_link(text):
                await _auto_preview_profile(update, context, text)
                return
            # V64: Check for message links (t.me/username/123, t.me/c/...).
            if "t.me/" in text.lower() or "telegram.me/" in text.lower():
                await _auto_preview_telegram_link(update, context, text)
                return
        return


def _has_media(update: Update) -> bool:
    m = update.message
    return any(getattr(m, attr, None) for attr in (
        "video", "document", "audio", "photo", "voice", "video_note",
        "animation", "sticker",
    ))
