"""v97.1 MULTI-ACCOUNT — Distributed VC load distribution.

This module implements the *distributed* Join All mode: active VC targets
are distributed across ALL healthy linked userbot accounts for load
balancing, instead of one primary account doing all the work.

Design goals (from the v97.1 spec):
  - DO NOT rewrite UserbotCluster / VoiceChat / existing rotation.
  - Reuse: ``get_userbot_cluster().get_healthy_accounts()``,
    ``cluster.connect_account(account_id)``, ``vc_get_backend(account_id=...)``.
  - Exactly one TelegramClient per account/session (the cluster's
    ``connect_account`` already guarantees this via the session-ownership
    registry — we never construct ``TelegramClient(...)`` here).
  - Duplicate-join protection via an asyncio.Lock-guarded assignment
    registry ``vc_id -> account_id``.
  - Failure handling: a failed assignment is released so a reassignment
    can pick another healthy account; already-successful joins are NEVER
    restarted.
  - No uncontrolled tasks: the distributor itself is invoked synchronously
    from the Join All worker loop (it does not spawn background tasks).

PRIMARY mode (the existing behaviour) is the default and does NOT use
this module at all — ``vc_join_mode == "primary"`` short-circuits in the
worker.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Optional

logger = logging.getLogger("mediagrab")

# --- Assignment registry ---------------------------------------------------
# Maps chat_id (vc target) -> account_id that owns the join.  Protected by
# ``_assignment_lock`` so two concurrent Join All workers (or a worker + the
# deferred queue / auto discovery) cannot assign the same VC to two accounts
# simultaneously.

_vc_assignments: dict[int, str] = {}
_assignment_lock: asyncio.Lock | None = None


def _get_assignment_lock() -> asyncio.Lock:
    """Lazily create the assignment lock (event-loop-safe)."""
    global _assignment_lock
    if _assignment_lock is None:
        _assignment_lock = asyncio.Lock()
    return _assignment_lock


async def vc_assignment_get(chat_id: int) -> Optional[str]:
    """Return the account_id that owns the VC join for ``chat_id``, or None."""
    async with _get_assignment_lock():
        return _vc_assignments.get(chat_id)


async def vc_assignment_set(chat_id: int, account_id: str) -> None:
    """Claim ``chat_id`` for ``account_id``.  Idempotent if same owner."""
    async with _get_assignment_lock():
        _vc_assignments[chat_id] = account_id


async def vc_assignment_release(chat_id: int) -> None:
    """Release the assignment for ``chat_id`` (after failure or leave).

    Safe to call even if no assignment exists.
    """
    async with _get_assignment_lock():
        _vc_assignments.pop(chat_id, None)


async def vc_assignment_release_account(account_id: str) -> list[int]:
    """Release ALL assignments owned by ``account_id`` (e.g. the account
    disconnected).  Returns the list of released chat_ids so the caller can
    requeue them for reassignment.
    """
    async with _get_assignment_lock():
        released = [cid for cid, aid in _vc_assignments.items() if aid == account_id]
        for cid in released:
            _vc_assignments.pop(cid, None)
    return released


async def vc_assignment_snapshot() -> dict[int, str]:
    """Return a copy of the full assignment map (for diagnostics/tests)."""
    async with _get_assignment_lock():
        return dict(_vc_assignments)


async def vc_assignment_clear() -> None:
    """Clear all assignments (used on shutdown / Join All reset)."""
    async with _get_assignment_lock():
        _vc_assignments.clear()


# --- Account load tracking -------------------------------------------------
# Per-account current join count, used by the distributor to pick the
# least-loaded healthy account.  Mirrors the participation registry but is
# kept separate so a transient reassignment does not flicker the registry.

_account_load: dict[str, int] = {}
_load_lock: asyncio.Lock | None = None


def _get_load_lock() -> asyncio.Lock:
    global _load_lock
    if _load_lock is None:
        _load_lock = asyncio.Lock()
    return _load_lock


async def _account_load_get(account_id: str) -> int:
    # v97.9 FIX: use _assignment_lock (not _load_lock) for ALL _account_load
    # mutations.  distributed_assign_target writes _account_load directly
    # under _assignment_lock; _account_load_dec used _load_lock — a DIFFERENT
    # lock — causing concurrent assign+release races (over-counting).
    async with _get_assignment_lock():
        return _account_load.get(account_id, 0)


async def _account_load_inc(account_id: str) -> int:
    # v97.9: same — use _assignment_lock for consistency.
    async with _get_assignment_lock():
        _account_load[account_id] = _account_load.get(account_id, 0) + 1
        return _account_load[account_id]


async def _account_load_dec(account_id: str) -> int:
    # v97.9: same — use _assignment_lock for consistency.
    async with _get_assignment_lock():
        cur = max(0, _account_load.get(account_id, 0) - 1)
        _account_load[account_id] = cur
        return cur


async def _account_load_clear() -> None:
    # v97.9: same — use _assignment_lock for consistency.
    async with _get_assignment_lock():
        _account_load.clear()


# --- Distributed distributor ----------------------------------------------


async def distributed_get_healthy_accounts() -> list[dict[str, Any]]:
    """Return the list of healthy linked accounts usable for distribution.

    Wraps ``UserbotCluster.get_healthy_accounts()`` and additionally
    verifies each account has a live TelegramClient in the cluster client
    registry (``cluster.get_client(aid)``).  Accounts without a connected
    client are excluded — they would cause ``vc_get_backend(account_id=...)``
    to raise ``VCTransportError``.
    """
    try:
        from .mtproto import get_userbot_cluster
        cluster = get_userbot_cluster()
    except Exception as exc:  # noqa: BLE001
        logger.warning("DISTRIBUTED_GET_HEALTHY cluster unavailable: %s", exc)
        return []
    healthy = cluster.get_healthy_accounts()
    usable: list[dict[str, Any]] = []
    for acc in healthy:
        aid = acc.get("account_id")
        if not aid:
            continue
        client = cluster.get_client(aid)
        if client is None:
            # Try to connect it on-demand (idempotent — reuses existing).
            try:
                result = await asyncio.wait_for(
                    cluster.connect_account(aid), timeout=30,
                )
                if not (result.startswith("connected") or result == "already_connected"):
                    logger.info(
                        "DISTRIBUTED_ACCOUNT_SKIP account_id=%s connect_result=%s",
                        aid, result,
                    )
                    continue
                client = cluster.get_client(aid)
            except asyncio.TimeoutError:
                logger.warning(
                    "DISTRIBUTED_ACCOUNT_SKIP account_id=%s reason=connect_timeout", aid,
                )
                continue
            except Exception as exc:  # noqa: BLE001
                logger.info(
                    "DISTRIBUTED_ACCOUNT_SKIP account_id=%s reason=%s: %s",
                    aid, type(exc).__name__, str(exc)[:120],
                )
                continue
        if client is None:
            continue
        # Verify the client is actually connected.
        try:
            if not client.is_connected():
                logger.info(
                    "DISTRIBUTED_ACCOUNT_SKIP account_id=%s reason=not_connected", aid,
                )
                continue
        except Exception:  # noqa: BLE001
            continue
        usable.append(acc)
    return usable


async def distributed_pick_account(
    per_account_cap: int,
    exclude: Optional[set[str]] = None,
) -> Optional[str]:
    """Pick the least-loaded healthy account with remaining capacity.

    v97.3 ISSUE 1 FIX: this function reads the load dict DIRECTLY (not via
    ``_account_load_get`` which takes the load lock).  It is intended to be
    called WHILE HOLDING ``_assignment_lock`` so that the pick + the
    subsequent load increment in ``distributed_assign_target`` are atomic.
    The health check (``distributed_get_healthy_accounts``) is still done
    outside the assignment lock by the caller to avoid blocking, but the
    final capacity decision + increment happen under the assignment lock.

    Args:
        per_account_cap: max VCs per account (``config.vc_multi_max_targets``).
        exclude: set of account_ids to skip (e.g. failed for this target).

    Returns:
        account_id, or None if no healthy account has capacity.
    """
    exclude = exclude or set()
    healthy = await distributed_get_healthy_accounts()
    if not healthy:
        return None
    # Build the candidate list with current load — read the dict directly
    # (the caller holds _assignment_lock, so no concurrent mutation).
    candidates: list[tuple[int, str]] = []
    for acc in healthy:
        aid = acc.get("account_id")
        if not aid or aid in exclude:
            continue
        load = _account_load.get(aid, 0)
        if load >= per_account_cap:
            continue
        candidates.append((load, aid))
    if not candidates:
        return None
    # Pick the least-loaded (ties broken by account_id for determinism).
    candidates.sort(key=lambda x: (x[0], x[1]))
    return candidates[0][1]


async def distributed_assign_target(
    chat_id: int,
    per_account_cap: int,
    exclude: Optional[set[str]] = None,
) -> Optional[str]:
    """Assign ``chat_id`` to a healthy account (least-loaded).

    v97.3 ISSUE 1 FIX: the assignment + the load increment are now BOTH
    performed atomically under ``_assignment_lock``.  Previously the load
    was incremented AFTER the lock was released, so two concurrent workers
    could observe the same load and select the same account before its
    counter was updated.  Now the invariant holds:

        assignment_lock
            ↓
        inspect account loads (direct dict read)
            ↓
        choose account
            ↓
        reserve/increment account load
            ↓
        record VC assignment
            ↓
        release lock

    Returns the chosen account_id, or None if no healthy account has
    capacity.

    v97.9 FIX: the health check (distributed_get_healthy_accounts, which
    may do network calls via cluster.connect_account) is now done OUTSIDE
    the assignment lock.  Only the final pick + load increment + assignment
    record happen under the lock.  This prevents all workers from
    serializing on the assignment lock during on-demand connect (which
    could block for up to 30×N seconds).
    """
    # v97.9: check idempotent existing assignment OUTSIDE the lock first
    # (fast path — no network calls needed).
    existing = _vc_assignments.get(chat_id)
    if existing:
        return existing
    # v97.9: do the health check (network calls) OUTSIDE the assignment lock.
    healthy = await distributed_get_healthy_accounts()
    if not healthy:
        return None
    # Now acquire the lock for the atomic pick + increment + record.
    async with _get_assignment_lock():
        # Re-check idempotent assignment (another worker may have assigned
        # while we were doing the health check).
        existing = _vc_assignments.get(chat_id)
        if existing:
            return existing
        # Pick the least-loaded healthy account from the pre-fetched list.
        # Read _account_load directly (we hold the lock).
        _exclude = exclude or set()
        _candidates: list[tuple[int, str]] = []
        for acc in healthy:
            aid = acc.get("account_id")
            if not aid or aid in _exclude:
                continue
            load = _account_load.get(aid, 0)
            if load >= per_account_cap:
                continue
            _candidates.append((load, aid))
        if not _candidates:
            return None
        _candidates.sort(key=lambda x: (x[0], x[1]))
        aid = _candidates[0][1]
        # Reserve capacity + record assignment — BOTH under the lock.
        _account_load[aid] = _account_load.get(aid, 0) + 1
        _vc_assignments[chat_id] = aid
    logger.info(
        "DISTRIBUTED_ASSIGN chat_id=%s account_id=%s load=%d",
        chat_id, aid, _account_load.get(aid, 0),
    )
    return aid


async def distributed_mark_failure(chat_id: int, account_id: str) -> None:
    """Record that ``account_id`` failed on ``chat_id``.

    Releases the assignment + decrements the load so a reassignment can
    pick a different account.  The participation registry state for an
    already-SUCCESSFUL join is NOT touched — only the in-flight assignment
    is released.
    """
    await vc_assignment_release(chat_id)
    await _account_load_dec(account_id)
    logger.info(
        "DISTRIBUTED_FAILURE chat_id=%s account_id=%s — released for reassignment",
        chat_id, account_id,
    )


async def distributed_mark_success(chat_id: int, account_id: str) -> None:
    """Record that ``account_id`` successfully joined ``chat_id``.

    The assignment stays in place (the account owns the join until leave).
    The load counter stays (the account is still participating).
    """
    await vc_assignment_set(chat_id, account_id)
    logger.info(
        "DISTRIBUTED_SUCCESS chat_id=%s account_id=%s", chat_id, account_id,
    )


async def distributed_account_loads() -> dict[str, int]:
    """Snapshot of per-account current join counts (for UI/tests)."""
    async with _get_load_lock():
        return dict(_account_load)


async def distributed_reset() -> None:
    """Clear all assignments + load counters (Join All reset / shutdown)."""
    await vc_assignment_clear()
    await _account_load_clear()


async def distributed_plan(
    targets: list[dict[str, Any]],
    per_account_cap: int,
) -> dict[str, Any]:
    """Compute a distribution plan without executing it.

    Used for the "preview" / test path.  Returns a dict:
      {
        "accounts": [{"account_id": ..., "assigned": [chat_id, ...]}, ...],
        "unassigned": [chat_id, ...],  # targets with no healthy account
        "healthy_count": N,
      }
    """
    healthy = await distributed_get_healthy_accounts()
    healthy_ids = [a.get("account_id") for a in healthy if a.get("account_id")]
    plan: dict[str, list[int]] = {aid: [] for aid in healthy_ids}
    unassigned: list[int] = []
    # Round-robin by least-load (simulated, no mutation of real counters).
    sim_load: dict[str, int] = {aid: 0 for aid in healthy_ids}
    for t in targets:
        gid = t.get("group_id") or t.get("gid")
        if gid is None:
            continue
        gid = int(gid)
        # Pick least-loaded with capacity.
        candidates = [
            (sim_load[aid], aid) for aid in healthy_ids
            if sim_load[aid] < per_account_cap
        ]
        if not candidates:
            unassigned.append(gid)
            continue
        candidates.sort(key=lambda x: (x[0], x[1]))
        _, aid = candidates[0]
        plan[aid].append(gid)
        sim_load[aid] += 1
    return {
        "accounts": [{"account_id": aid, "assigned": gids} for aid, gids in plan.items()],
        "unassigned": unassigned,
        "healthy_count": len(healthy_ids),
    }
