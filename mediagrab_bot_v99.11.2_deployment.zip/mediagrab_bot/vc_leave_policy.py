"""v99.11 — Explicit VC leave policy: one chokepoint, every leave reasoned.

WHY THIS MODULE EXISTS (the P0 post-join persistence requirement)
-----------------------------------------------------------------
The v99.10 leave audit (see PATCH_MANIFEST_v99.11.txt §leave-audit)
found SIX distinct code paths that can leave a Telegram voice chat,
implemented under three different names (``leave``, ``_leave_target``,
``_cleanup_stale_backend_call``).  The "cleanup" one is a REAL Telegram
leave — ``backend._leave_target`` → ``pytgcalls.leave_call`` sends
LeaveGroupCallRequest AND destroys the native transport.  Two of those
paths could fire on an ACTIVE, HEALTHY transport with only weak
evidence (registry=UNKNOWN), and none of them required a reason code.

THE INVARIANT (mission §post-join-persistence):

    JOIN SUCCESS → ACTIVE → REMAIN IN VC

An active transport may only be left for a deliberate, VALIDATED
reason.  Uncertainty (verification UNKNOWN / transient error / stale
call identity / resource pressure / another target processing) is
NEVER sufficient evidence to destroy a healthy transport.

REASON CODES (stable, machine-searchable)
-----------------------------------------
Deliberate (always authorized — a human asked for it):
  USER_REQUESTED       — a user command (/leave, dashboard button)
  ADMIN_REQUESTED      — an admin command (leave-all, dashboard admin)
  TARGET_REMOVED       — the target was removed from tracking
  EXPLICIT_STOP        — explicit stop of the VC/tour subsystem
  SHUTDOWN             — graceful process shutdown sequence
  TOUR_CYCLE           — tour visit rotation (by design)
  MANUAL_OVERRIDE      — manual join replaces the current call
  MTPROTO_ADMIN_STOP   — admin MTProto stop (accepts ghost participations
                          explicitly — logged loudly, never silent)

Validated-automatic (authorized ONLY with the stated positive evidence):
  RECONCILE_CONFIRMED_ABSENT     — 3× consecutive targeted-query negative
                                    with stable call_id (v98.02 FIX-L
                                    authoritative absence)
  STALE_CONTAINER_VERIFIED_ABSENT— positive Telegram recheck says absent
  FAILED_JOIN_CLEANUP            — the join's OWN target failed; its
                                    just-allocated transport is released
  CALL_ENDED_DURING_JOIN         — authoritative re-detect says the call
                                    object no longer exists
  VC_TERMINATED                  — the voice chat itself ended
  ACCOUNT_LOGGED_OUT             — owning account session is gone
  RESOURCE_EMERGENCY             — OPT-IN ONLY (env
                                    VC_RESOURCE_EMERGENCY_LEAVE=1); a
                                    deliberate, observable policy decision

NEVER sufficient (the deny list — do not add these as reasons):
  verification UNKNOWN / transient Telegram error / STALE_CALL_IDENTITY
  / Join-All processing a later target / resource telemetry running /
  database checkpoint / heartbeat / queue idle.  These map to PRESERVE
  + reverify-with-backoff, never to a leave.

LOG CONTRACT (mission §logging)
-------------------------------
  VC_LEAVE_REQUESTED  account_id=… chat_id=… call_id=… reason=… source=…
  VC_LEAVE_COMPLETED  account_id=… chat_id=… reason=…
  VC_LEAVE_FAILED     account_id=… chat_id=… reason=… error=…
  VC_LEAVE_DENIED_UNAUTHORIZED  chat_id=… reason=… source=… cause=…

This module is stdlib-only and MUST NOT import voicechat at module
level (voicechat imports this module; the join-all leave-block state is
read lazily inside functions).
"""

from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable, Optional, Tuple

logger = logging.getLogger("mediagrab")


class LeaveReason:
    """Stable reason codes (plain strings — log-friendly, JSON-friendly)."""
    # deliberate (human-initiated)
    USER_REQUESTED = "USER_REQUESTED"
    ADMIN_REQUESTED = "ADMIN_REQUESTED"
    TARGET_REMOVED = "TARGET_REMOVED"
    EXPLICIT_STOP = "EXPLICIT_STOP"
    SHUTDOWN = "SHUTDOWN"
    TOUR_CYCLE = "TOUR_CYCLE"
    MANUAL_OVERRIDE = "MANUAL_OVERRIDE"
    MTPROTO_ADMIN_STOP = "MTPROTO_ADMIN_STOP"
    # validated-automatic (positive evidence required from the caller)
    RECONCILE_CONFIRMED_ABSENT = "RECONCILE_CONFIRMED_ABSENT"
    STALE_CONTAINER_VERIFIED_ABSENT = "STALE_CONTAINER_VERIFIED_ABSENT"
    FAILED_JOIN_CLEANUP = "FAILED_JOIN_CLEANUP"
    CALL_ENDED_DURING_JOIN = "CALL_ENDED_DURING_JOIN"
    VC_TERMINATED = "VC_TERMINATED"
    ACCOUNT_LOGGED_OUT = "ACCOUNT_LOGGED_OUT"
    RESOURCE_EMERGENCY = "RESOURCE_EMERGENCY"


# Reason sets consulted by vc_leave_authorize().
DELIBERATE_REASONS = frozenset({
    LeaveReason.USER_REQUESTED,
    LeaveReason.ADMIN_REQUESTED,
    LeaveReason.TARGET_REMOVED,
    LeaveReason.EXPLICIT_STOP,
    LeaveReason.SHUTDOWN,
    LeaveReason.TOUR_CYCLE,
    LeaveReason.MANUAL_OVERRIDE,
    LeaveReason.MTPROTO_ADMIN_STOP,
})

VALIDATED_AUTOMATIC_REASONS = frozenset({
    LeaveReason.RECONCILE_CONFIRMED_ABSENT,
    LeaveReason.STALE_CONTAINER_VERIFIED_ABSENT,
    LeaveReason.FAILED_JOIN_CLEANUP,
    LeaveReason.CALL_ENDED_DURING_JOIN,
    LeaveReason.VC_TERMINATED,
    LeaveReason.ACCOUNT_LOGGED_OUT,
})

ALL_KNOWN_REASONS = DELIBERATE_REASONS | VALIDATED_AUTOMATIC_REASONS | {
    LeaveReason.RESOURCE_EMERGENCY,
}


def _resource_emergency_leave_enabled() -> bool:
    """RESOURCE_EMERGENCY is opt-in: it must be a deliberate deployment
    policy decision, never an accidental cleanup side effect."""
    import os
    raw = str(os.environ.get("VC_RESOURCE_EMERGENCY_LEAVE", "") or "").strip().lower()
    return raw in ("1", "true", "yes", "on")


def _join_all_leave_block_active() -> bool:
    """Lazy read of the v97.83 Join-All leave-block (cycle-safe)."""
    try:
        from . import voicechat as _vc  # noqa: PLC0415
        return bool(getattr(_vc, "_vc_join_all_leave_block_active", False))
    except Exception:  # noqa: BLE001
        return False


def vc_leave_authorize(
    reason: str,
    source: str,
    chat_id: int,
    *,
    evidence: Optional[str] = None,
) -> Tuple[bool, str]:
    """Decide whether a leave with this reason may proceed.

    Returns ``(authorized, denial_cause)``.  Rules:
      1. A reason is MANDATORY (unknown/empty → denied).
      2. Deliberate reasons always pass (user/admin intent).
      3. RESOURCE_EMERGENCY only with the explicit env opt-in.
      4. Validated-automatic reasons require the caller to supply the
         positive evidence string that justified them.
      5. While the Join-All leave-block is active, validated-automatic
         reasons are DENIED (an in-flight Join-All must not destroy
         targets it or a previous run joined) — except the join's own
         failed-target cleanup, which the pipeline needs to release a
         just-failed NEW join (never an ACTIVE transport).
    """
    reason = (reason or "").strip()
    if not reason:
        return False, "no_reason"
    if reason in DELIBERATE_REASONS:
        return True, ""
    if reason == LeaveReason.RESOURCE_EMERGENCY:
        if _resource_emergency_leave_enabled():
            return True, ""
        return False, "resource_emergency_not_enabled"
    if reason in VALIDATED_AUTOMATIC_REASONS:
        if reason == LeaveReason.FAILED_JOIN_CLEANUP:
            # The pipeline's own failed NEW join — never touches an
            # ACTIVE transport (the pipeline only holds the chat while
            # the join is in flight).
            return True, ""
        if not evidence:
            return False, "validated_reason_requires_evidence"
        if _join_all_leave_block_active():
            return False, "blocked_during_join_all"
        return True, ""
    return False, f"unknown_reason:{reason}"


async def vc_leave_execute(
    chat_id: int,
    reason: str,
    source: str,
    leave_factory: Callable[[], Awaitable[Any]],
    *,
    account_id: str = "",
    call_id: Optional[int] = None,
    evidence: Optional[str] = None,
) -> bool:
    """THE controlled leave chokepoint.

    Every Telegram VC leave in v99.11 routes through here:
      1. log VC_LEAVE_REQUESTED (before)
      2. authorize (reason policy above); denied →
         VC_LEAVE_DENIED_UNAUTHORIZED, transport PRESERVED, return False
      3. execute the leave via ``leave_factory`` (awaitable)
      4. log VC_LEAVE_COMPLETED or VC_LEAVE_FAILED (after)

    The factory pattern keeps this module free of backend imports (no
    cycles) while guaranteeing no caller can bypass the policy —
    ``backend._leave_target`` call sites are replaced by a factory that
    calls it, so the leave physically cannot happen without a reason.
    """
    authorized, denial = vc_leave_authorize(
        reason, source, chat_id, evidence=evidence)
    if not authorized:
        logger.warning(
            "VC_LEAVE_DENIED_UNAUTHORIZED chat_id=%s reason=%s source=%s "
            "cause=%s — leave REFUSED; active transport PRESERVED "
            "(v99.11 leave policy: every leave needs a validated reason)",
            chat_id, reason or "(none)", source or "(unknown)", denial,
        )
        return False
    logger.info(
        "VC_LEAVE_REQUESTED account_id=%s chat_id=%s call_id=%s reason=%s "
        "source=%s evidence=%s",
        account_id or "(global)", chat_id,
        call_id if call_id is not None else "unknown", reason, source,
        evidence or "-",
    )
    try:
        result = await leave_factory()
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "VC_LEAVE_FAILED account_id=%s chat_id=%s reason=%s error=%s: %s",
            account_id or "(global)", chat_id, reason,
            type(exc).__name__, str(exc)[:160],
        )
        return False
    logger.info(
        "VC_LEAVE_COMPLETED account_id=%s chat_id=%s reason=%s result=%s",
        account_id or "(global)", chat_id, reason, result,
    )
    return True


__all__ = [
    "LeaveReason", "DELIBERATE_REASONS", "VALIDATED_AUTOMATIC_REASONS",
    "ALL_KNOWN_REASONS", "vc_leave_authorize", "vc_leave_execute",
]
