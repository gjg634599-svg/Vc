#!/usr/bin/env python3
"""v99.03 RC-11 — the dead-session re-login helper (operator tool).

WHY THIS EXISTS (RUNTIME-PROVEN, the 2026-09-11 02:45:10 v99.02 production
log, line 131):
    SESSION_UNAUTHORIZED file=cluster_916397080450.session
    reason=not_authorized
That session is DEAD — the auth key was revoked (logged out elsewhere) or
the login never completed — and it will NEVER recover.  The correct repair
is exactly the runbook every SESSION_REMEDIATION line now carries:

    1. Stop the bot.
    2. Delete the dead .session file.
    3. Re-authorize:  python -m mediagrab_bot.tools.login --phone +<digits>
    4. Restart the bot — the session hot-reload (v98.07 FIX-UU) imports the
       fresh .session within 60s, no restart ordering tricks needed.

This module IS step 3.  It is deliberately MINIMAL and standalone:
  * one argument: --phone (E.164 digits, with or without the leading +);
  * writes data/sessions/cluster_<digits>.session (the exact naming the
    importer scans — mtproto.py _find_all_session_files / the RC-10 health
    registry);
  * refuses to run while the bot is alive (checks the V85 instance PID
    file) — two processes on one SQLite session file = "database is
    locked", the exact failure mode the v97 era fixed;
  * supports the two-step Telegram flow (code → optional 2FA password);
  * NEVER reads or prints the session secret; prints the account identity
    (@username, id) on success so the operator can confirm it is the right
    account before restarting the bot.

Exit codes: 0 success, 2 argument/config error, 3 bot-still-running, 4
login failed.
"""
from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path


def _project_root() -> Path:
    """The package's project root (two levels above this file)."""
    return Path(__file__).resolve().parent.parent.parent


def _digits_of(phone: str) -> str:
    digits = re.sub(r"\D", "", str(phone or ""))
    return digits


def _bot_running(root: Path) -> int:
    """Return the live bot PID from the V85 instance guard file, else 0."""
    pid_file = root / "data" / ".v85_instance.pid"
    try:
        if not pid_file.exists():
            return 0
        pid = int(pid_file.read_text().strip() or 0)
        if pid <= 0:
            return 0
        os.kill(pid, 0)  # signal 0 = existence probe
        # v97.92-style PID-reuse check: the PID must actually be the bot.
        cmdline = ""
        try:
            with open(f"/proc/{pid}/cmdline", "r", encoding="utf-8",
                      errors="replace") as f:
                cmdline = f.read()
        except OSError:
            cmdline = ""
        if cmdline and "mediagrab" not in cmdline.replace("\x00", " "):
            return 0  # PID reused by an unrelated process
        return pid
    except (ValueError, OSError):
        return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m mediagrab_bot.tools.login",
        description="Re-authorize a dead cluster session "
                    "(v99.03 RC-11 remediation step 3).",
    )
    parser.add_argument(
        "--phone", required=True,
        help="The account's phone number (E.164 digits, e.g. +916397080450).")
    parser.add_argument(
        "--session-dir", default="",
        help="Optional session directory override "
             "(default: <project_root>/data/sessions).")
    parser.add_argument(
        "--force", action="store_true",
        help="Skip the bot-running guard (NOT recommended: two processes "
             "on one SQLite session file cause 'database is locked').")
    args = parser.parse_args(argv)

    digits = _digits_of(args.phone)
    if not digits or len(digits) < 7:
        print("ERROR: --phone must contain a real phone number "
              f"(got: {args.phone!r})", file=sys.stderr)
        return 2

    root = _project_root()
    # Import the package config (reads .env / TG_API_ID / TG_API_HASH the
    # same way the bot itself does — the helper and the bot MUST agree on
    # the API credentials or the session file is useless).
    try:
        sys.path.insert(0, str(root)) if str(root) not in sys.path else None
        from mediagrab_bot.config import config  # noqa: PLC0415
    except Exception as exc:  # noqa: BLE001
        print(f"ERROR: could not import mediagrab_bot.config "
              f"({type(exc).__name__}: {exc}). Run from the deployment "
              f"tree root: {root}", file=sys.stderr)
        return 2
    if not config.tg_api_id or not config.tg_api_hash:
        print("ERROR: TG_API_ID / TG_API_HASH are not configured "
              "(check .env).", file=sys.stderr)
        return 2

    session_dir = Path(args.session_dir) if args.session_dir \
        else root / "data" / "sessions"
    session_dir.mkdir(parents=True, exist_ok=True)
    session_base = str(session_dir / f"cluster_{digits}")

    # The bot-running guard (step 1 of the runbook enforced mechanically).
    if not args.force:
        bot_pid = _bot_running(root)
        if bot_pid:
            print(f"ERROR: the bot appears to be RUNNING (pid={bot_pid}) — "
                  "STOP IT FIRST (runbook step 1); two processes on one "
                  "session file cause 'database is locked'. Use --force to "
                  "override.", file=sys.stderr)
            return 3

    try:
        from telethon import TelegramClient
    except ImportError:
        print("ERROR: telethon is not installed in this environment.",
              file=sys.stderr)
        return 2

    print(f"LOGIN_START phone=+{digits} session={session_base}.session "
          f"(v99.03 RC-11 helper)")
    client = TelegramClient(
        session_base, config.tg_api_id, config.tg_api_hash,
        connection_retries=3, retry_delay=2, auto_reconnect=False,
    )

    async def _flow() -> int:
        import asyncio
        await client.connect()
        try:
            if await client.is_user_authorized():
                me = await client.get_me()
                print(f"LOGIN_ALREADY_AUTHORIZED username=@"
                      f"{getattr(me, 'username', '') or '(none)'} "
                      f"id={getattr(me, 'id', '?')} — the session file is "
                      f"already valid; no re-login was needed.")
                return 0
            sent = await client.send_code_request(args.phone)
            code = input("Enter the login code Telegram sent to this "
                         "phone: ").strip()
            try:
                await client.sign_in(phone=args.phone,
                                     code=code,
                                     password=None,
                                     sms_code=None)
            except Exception as exc:  # noqa: BLE001
                name = type(exc).__name__
                if "SessionPasswordNeeded" in name or "password" in \
                        str(exc).lower():
                    import getpass
                    pwd = getpass.getpass(
                        "2FA is enabled — enter the account password: ")
                    await client.sign_in(phone=args.phone,
                                         password=pwd)
                else:
                    raise
            me = await client.get_me()
            if not await client.is_user_authorized():
                print("ERROR: login did not complete — the session is still "
                      "unauthorized. Check the code/password and retry.",
                      file=sys.stderr)
                return 4
            print(f"LOGIN_SUCCESS username=@"
                  f"{getattr(me, 'username', '') or '(none)'} "
                  f"id={getattr(me, 'id', '?')} session={session_base}"
                  f".session — delete any OTHER stale copies of this "
                  f"account's session, then RESTART THE BOT (the session "
                  f"hot-reload imports the fresh .session within 60s).")
            return 0
        finally:
            await client.disconnect()

    import asyncio
    try:
        return asyncio.run(_flow())
    except Exception as exc:  # noqa: BLE001
        print(f"ERROR: login failed — {type(exc).__name__}: "
              f"{str(exc)[:200]}", file=sys.stderr)
        return 4


if __name__ == "__main__":
    raise SystemExit(main())
