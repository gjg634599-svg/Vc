"""v99.03 RC-11 — operator tools subpackage.

``python -m mediagrab_bot.tools.login --phone +<digits>`` is the dead-session
remediation helper referenced by every SESSION_REMEDIATION log line (see
mtproto.py RC-11): it (re)authorizes a cluster account session file that the
importer reported as ``SESSION_UNAUTHORIZED``.
"""
__all__ = ["login"]
