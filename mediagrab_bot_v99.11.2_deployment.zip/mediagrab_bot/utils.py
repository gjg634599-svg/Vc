"""Utility module — imports from real extracted modules."""

from __future__ import annotations

from .utils_real import (
    safe_reply_text, safe_edit_message_text, safe_send_message,
    safe_send_document, safe_filename, unique_path, remove_path,
    cleanup_paths, cleanup_directory, periodic_cleanup, human_size,
    _ui_claim, _ui_invalidate, _ui_check, _ui_release,
    _redact_secrets, _sanitize_error, register_bot, get_bot,
    is_available, _cache_userbot_identity,
    telegram_media_type, extension_category,
    setup_logging, _ErrorDedupFilter, _install_asyncio_handler,
    supervised_create_task, _active_tasks, _supervised_task_counts,
)
from .states import (
    IDLE, set_state, get_state, reset, set_tool, get_tool,
    set_last_download, get_last_download,
    set_state_sync, get_state_sync,
    set_tool_sync, get_tool_sync,
    set_last_download_sync, get_last_download_sync,
)
from .link_parser import parse_input, ParsedInput, describe_input
from .qr_generator import generate_qr, QRError
from .text_utils import md_escape, html_escape
from types import SimpleNamespace

# Backward-compat namespace
states = SimpleNamespace(
    IDLE=IDLE,
    set_state=set_state, get_state=get_state, reset=reset,
    set_tool=set_tool, get_tool=get_tool,
    set_last_download=set_last_download, get_last_download=get_last_download,
    set_state_sync=set_state_sync, get_state_sync=get_state_sync,
    set_tool_sync=set_tool_sync, get_tool_sync=get_tool_sync,
    set_last_download_sync=set_last_download_sync,
    get_last_download_sync=get_last_download_sync,
)

__all__ = [
    "safe_reply_text", "safe_edit_message_text", "safe_send_message",
    "safe_send_document", "safe_filename", "unique_path", "remove_path",
    "cleanup_paths", "cleanup_directory", "periodic_cleanup", "human_size",
    "_ui_claim", "_ui_invalidate", "_ui_check", "_ui_release",
    "_redact_secrets", "_sanitize_error", "md_escape", "html_escape",
    "register_bot", "get_bot", "is_available", "_cache_userbot_identity",
    "telegram_media_type", "extension_category",
    "setup_logging", "_ErrorDedupFilter", "_install_asyncio_handler",
    "states", "parse_input", "ParsedInput", "describe_input", "generate_qr",
    "supervised_create_task", "_active_tasks", "_supervised_task_counts",
]
