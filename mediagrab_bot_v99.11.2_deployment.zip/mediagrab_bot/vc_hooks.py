"""VC hooks — dependency-injection bridge between MTProto and the VC subsystem.

The MTProto ``UserbotCluster`` triggers two VC-side operations on primary
account rotation:

  - ``clear_account_cache(account_id)`` — drop stale account-bound entity
    handles from the scoped VC entity cache.
  - ``vc_reset_backend()`` — drop the cached VC backend so it rebinds to the
    new primary account.

Both implementations live in the VC subsystem (currently inside
``_bot_core.py``, later ``voicechat.py``) because they depend on VC-internal
state (``_vc_entity_cache_scoped``, ``_vc_backend``, ``vc_get_backend``).
Importing the VC subsystem from ``mtproto`` would create a cycle
(``mtproto`` ← ``_bot_core`` ← ``mtproto``).

This module breaks the cycle with a registration pattern: the VC subsystem
registers its real implementations at import time, and ``mtproto`` calls the
hooks through this module. Until registration happens the hooks are no-ops
(logging a warning), which is safe because primary rotation only ever occurs
at runtime — long after both modules have finished importing.
"""

from __future__ import annotations

import logging
from typing import Callable, Optional

logger = logging.getLogger("mediagrab")

# Registered callbacks (set by the VC subsystem at import time).
_clear_account_cache_fn: Optional[Callable[[str], None]] = None
_reset_vc_backend_fn: Optional[Callable[[], str]] = None
# v97.30: global FloodWait gate — exposed so mtproto_call_with_retry can
# set/check it without importing voicechat.py (avoids a circular import).
_set_global_floodwait_fn: Optional[Callable] = None
_is_global_floodwait_active_fn: Optional[Callable[[], bool]] = None
# v98.08 FIX-AAA: rotation settle window — set by voicechat, called by
# mtproto.set_primary_id after a primary rotation.
_rotation_settle_begin_fn: Optional[Callable[[str, str], None]] = None
# v98.08 FIX-ZZ: notify the VC subsystem that a NEW session was imported
# (hot-reload) so per-scope caches (incl. the entity negative cache) can
# be wiped.
_session_import_notify_fn: Optional[Callable[[str, int], None]] = None


def register_vc_hooks(
    clear_account_cache: Callable[[str], None],
    reset_vc_backend: Callable[[], str],
) -> None:
    """Register the real VC implementations.

    Called once by ``_bot_core.py`` (later ``voicechat.py``) at import time,
    after ``clear_account_cache`` and ``vc_reset_backend`` are defined.
    v98.08 FIX-AAA: reset_vc_backend now RETURNS its decision
    ("preserved" | "reset") so rotation logs ONE authoritative line.
    """
    global _clear_account_cache_fn, _reset_vc_backend_fn
    _clear_account_cache_fn = clear_account_cache
    _reset_vc_backend_fn = reset_vc_backend
    logger.debug(
        "VC hooks registered: clear_account_cache=%r vc_reset_backend=%r",
        clear_account_cache, reset_vc_backend,
    )


def register_v9808_hooks(
    rotation_settle_begin: Callable[[str, str], None],
    session_import_notify: Callable[[str, int], None],
) -> None:
    """v98.08: register the rotation-settle + session-import-notify hooks.

    Called by voicechat.py at import time (after the settle-window and
    negative-cache helpers are defined). Lets mtproto trigger them
    without importing voicechat (circular-import free).
    """
    global _rotation_settle_begin_fn, _session_import_notify_fn
    _rotation_settle_begin_fn = rotation_settle_begin
    _session_import_notify_fn = session_import_notify
    logger.debug("v98.08 hooks registered: rotation_settle, session_import.")


def register_floodwait_hooks(
    set_global_floodwait: Callable,
    is_global_floodwait_active: Callable[[], bool],
) -> None:
    """v97.30: Register the global FloodWait gate functions.

    Called by voicechat.py at import time. Lets mtproto_call_with_retry
    set the gate on FloodWaitError and check it before each attempt,
    so a FloodWait on ANY subsystem pauses ALL VC/MTProto workers.
    """
    global _set_global_floodwait_fn, _is_global_floodwait_active_fn
    _set_global_floodwait_fn = set_global_floodwait
    _is_global_floodwait_active_fn = is_global_floodwait_active
    logger.debug("FloodWait hooks registered.")


def clear_account_cache(account_id: str) -> None:
    """Clear cached entities for a specific account (VC subsystem hook)."""
    if _clear_account_cache_fn is not None:
        _clear_account_cache_fn(account_id)
    else:  # pragma: no cover — only before VC subsystem registers
        logger.warning(
            "clear_account_cache called before VC hooks registered "
            "(account=%s); no-op", account_id,
        )


def vc_reset_backend() -> str:
    """Drop the cached VC backend (VC subsystem hook).

    v98.08 FIX-AAA: returns the backend decision — "preserved" when the
    started backend was kept (the common production case), "reset" when
    the backend reference was dropped. Callers log ONE line with this.
    """
    if _reset_vc_backend_fn is not None:
        try:
            return str(_reset_vc_backend_fn() or "reset")
        except Exception as exc:  # noqa: BLE001
            logger.warning("vc_reset_backend hook error: %s", exc)
            return "reset-error"
    else:  # pragma: no cover — only before VC subsystem registers
        logger.warning(
            "vc_reset_backend called before VC hooks registered; no-op"
        )
        return "reset-unregistered"


def vc_rotation_settle_begin(old_primary: str = "", new_primary: str = "") -> None:
    """v98.08 FIX-AAA: start the post-rotation settle window.

    Routes to voicechat._vc_rotation_settle_begin (sets the settle
    deadline + wipes the entity negative cache). No-op if unregistered.
    """
    if _rotation_settle_begin_fn is not None:
        try:
            _rotation_settle_begin_fn(old_primary, new_primary)
        except Exception as exc:  # noqa: BLE001
            logger.debug("vc_rotation_settle_begin hook error: %s", exc)


def vc_notify_session_import(session_path: str = "", count: int = 0) -> None:
    """v98.08 FIX-ZZ: notify the VC subsystem of a hot-imported session.

    Routes to voicechat._vc_session_import_notify (wipes per-scope
    caches incl. the entity negative cache so the fresh account's
    scopes start clean). No-op if unregistered.
    """
    if _session_import_notify_fn is not None:
        try:
            _session_import_notify_fn(session_path, count)
        except Exception as exc:  # noqa: BLE001
            logger.debug("vc_notify_session_import hook error: %s", exc)


async def vc_set_global_floodwait(seconds: float, source: str = "") -> None:
    """v97.30: Set the global FloodWait gate (all VC/MTProto workers pause).

    Routes to voicechat.vc_set_global_floodwait via the DI bridge.
    No-op if the VC subsystem hasn't registered yet (early startup).
    """
    if _set_global_floodwait_fn is not None:
        try:
            await _set_global_floodwait_fn(seconds, source)
        except Exception as exc:  # noqa: BLE001
            logger.debug("vc_set_global_floodwait hook error: %s", exc)
    # else: no-op (VC subsystem not yet registered)


def vc_is_global_floodwait_active() -> bool:
    """v97.30: Check if the global FloodWait gate is active.

    Routes to voicechat.vc_is_global_floodwait_active via the DI bridge.
    Returns False if the VC subsystem hasn't registered yet (early startup).
    """
    if _is_global_floodwait_active_fn is not None:
        try:
            return bool(_is_global_floodwait_active_fn())
        except Exception:  # noqa: BLE001
            return False
    return False


__all__ = [
    "register_vc_hooks",
    "register_floodwait_hooks",
    "register_v9808_hooks",
    "clear_account_cache",
    "vc_reset_backend",
    "vc_set_global_floodwait",
    "vc_is_global_floodwait_active",
    "vc_rotation_settle_begin",
    "vc_notify_session_import",
]
