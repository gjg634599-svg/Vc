"""Talkative hooks — DI bridge for Talkative functions called by the VC subsystem.

The VC subsystem (``voicechat.py``) calls these Talkative functions during
voice-chat audio processing:

  - ``_adaptive_check_stale(chat_id)``
  - ``_adaptive_claim_response(chat_id)``
  - ``_adaptive_release_response(chat_id)``
  - ``_adaptive_detect_language(text)``
  - ``_adaptive_response_length_guidance(ctx)``
  - ``_adaptive_route_model(ctx)``
  - ``_talkative_mode_allows_vc(mode)``

These live in the Talkative subsystem (currently in ``_bot_core.py``, later
``talkative.py``). Importing Talkative from ``voicechat`` would create a cycle
(``voicechat`` ← ``talkative`` ← ``voicechat`` for ``vc_talkative_*``).

This module breaks the cycle with a registration pattern: the Talkative
subsystem registers its real implementations at import time, and ``voicechat``
calls the hooks through this module.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Optional

logger = logging.getLogger("mediagrab")

# Registered callbacks (set by the Talkative subsystem at import time).
_fns: dict[str, Callable[..., Any]] = {}


def register_talkative_hooks(hooks: dict[str, Callable[..., Any]]) -> None:
    """Register real Talkative implementations.

    Called once by ``_bot_core.py`` (later ``talkative.py``) at import time.
    ``hooks`` maps hook names to callables.
    """
    _fns.update(hooks)
    logger.debug("Talkative hooks registered: %s", list(hooks))


def _call(name: str, *args, **kwargs):
    fn = _fns.get(name)
    if fn is not None:
        return fn(*args, **kwargs)
    logger.warning("Talkative hook %r called before registration; no-op", name)
    return None


def _adaptive_check_stale(chat_id: int) -> None:
    _call("_adaptive_check_stale", chat_id)


def _adaptive_claim_response(chat_id: int) -> bool:
    return _call("_adaptive_claim_response", chat_id) or False


def _adaptive_release_response(chat_id: int) -> None:
    _call("_adaptive_release_response", chat_id)


def _adaptive_detect_language(text: str) -> str:
    return _call("_adaptive_detect_language", text) or "en"


def _adaptive_response_length_guidance(ctx: Any) -> int:
    return _call("_adaptive_response_length_guidance", ctx) or 400


def _adaptive_route_model(ctx: Any) -> str:
    return _call("_adaptive_route_model", ctx) or "gemini"


def _talkative_mode_allows_vc(mode: str) -> bool:
    return _call("_talkative_mode_allows_vc", mode) or False


# --- Additional hooks used by the VC subsystem ---

async def _adaptive_get_context(chat_id: int):
    return await _call("_adaptive_get_context", chat_id)


async def _adaptive_engagement_score(*args, **kwargs):
    return await _call("_adaptive_engagement_score", *args, **kwargs)


def _talkative_build_system_prompt(*args, **kwargs):
    return _call("_talkative_build_system_prompt", *args, **kwargs)


async def talkative_generate(*args, **kwargs):
    return await _call("talkative_generate", *args, **kwargs)


def talkative_get_mode(chat_id: int) -> str:
    return _call("talkative_get_mode", chat_id) or "off"


async def talkative_add_memory(*args, **kwargs):
    return await _call("talkative_add_memory", *args, **kwargs)


def talkative_effective_provider(*args, **kwargs):
    return _call("talkative_effective_provider", *args, **kwargs)


def talkative_effective_settings(*args, **kwargs):
    return _call("talkative_effective_settings", *args, **kwargs) or {}


__all__ = [
    "register_talkative_hooks",
    "_adaptive_check_stale",
    "_adaptive_claim_response",
    "_adaptive_release_response",
    "_adaptive_detect_language",
    "_adaptive_response_length_guidance",
    "_adaptive_route_model",
    "_talkative_mode_allows_vc",
    "_adaptive_get_context",
    "_adaptive_engagement_score",
    "_talkative_build_system_prompt",
    "talkative_generate",
    "talkative_get_mode",
    "talkative_add_memory",
    "talkative_effective_provider",
    "talkative_effective_settings",
]
