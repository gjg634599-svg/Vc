"""Join All Active VC — production-grade resilient worker subsystem.

This module implements a complete redesign of the "Join All Active VC" feature
with the following architecture:

    Join All
      ↓
    Create work queue (from discovery snapshot)
      ↓
    Process one target at a time
      ↓
    Save checkpoint to DB after each target
      ↓
    Circuit breaker opens?
      ↓ yes
    Pause worker (state = WAITING_FOR_BREAKER)
      ↓
    Wait for breaker cooldown
      ↓
    Half-open probe (single target)
      ↓ success
    Resume automatically from exact checkpoint
      ↓
    Continue remaining targets
      ↓
    COMPLETED

Key guarantees:
  * Never restart from the beginning.
  * Never lose progress (DB-backed checkpoint after every target).
  * Never lose completed joins (participation registry is separate + DB-backed).
  * Resume automatically after circuit-breaker recovery.
  * Resume optionally after bot restart (startup recovery).

Components:
  * ``JoinAllWorkerState`` — Enum of all worker states.
  * ``WorkerStateMachine`` — validated state-transition engine.
  * ``CircuitBreaker`` — CLOSED / OPEN / HALF_OPEN with auto-recovery.
  * ``CancellationToken`` — cooperative cancellation flag.
  * ``RetryPolicy`` — exponential backoff config.
  * ``CheckpointManager`` — DB persistence of run progress.
  * ``JoinAllWorker`` — the async worker that ties it all together.

Backward compatibility:
  The module-level ``_vc_join_all_state`` dict and the public functions
  ``vc_join_all_active_start()`` / ``vc_join_all_active_stop()`` remain the
  public API.  The new worker writes to the same dict so existing UI/refresh
  code continues to work unchanged.
"""

from __future__ import annotations

import asyncio
import enum
import json
import logging
import os
import re
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

# Python 3.12 dataclass + importlib quirk workaround (same as _bot_core.py).
# When loaded via importlib.util.spec_from_file_location without
# pre-registering in sys.modules, @dataclass(frozen=True) combined with
# from __future__ import annotations fails because dataclasses internal
# _is_type() does sys.modules.get(cls.__module__).__dict__ and gets None.
if __name__ not in sys.modules:
    sys.modules[__name__] = type(sys)(__name__)

logger = logging.getLogger(__name__)


# ===========================================================================
# Enums
# ===========================================================================

class JoinAllWorkerState(enum.Enum):
    """Formal state machine for the Join-All worker.

    Allowed transitions (validated by ``WorkerStateMachine``):

        IDLE → DISCOVERING
        DISCOVERING → JOINING
        DISCOVERING → COMPLETED          # no eligible targets
        DISCOVERING → FAILED
        DISCOVERING → CANCELLED
        JOINING → PAUSED                 # cooperative stop requested
        JOINING → WAITING_FOR_BREAKER    # circuit breaker opened
        JOINING → RETRYING               # transient per-target error
        JOINING → COMPLETED
        JOINING → CANCELLED
        JOINING → FAILED
        PAUSED → CANCELLED
        PAUSED → JOINING                 # resume
        WAITING_FOR_BREAKER → JOINING    # breaker recovered (HALF_OPEN success)
        WAITING_FOR_BREAKER → FAILED     # breaker max-retries exhausted
        WAITING_FOR_BREAKER → CANCELLED
        RETRYING → JOINING
        RETRYING → FAILED
        RETRYING → CANCELLED
        COMPLETED → IDLE                 # reset for next run
        CANCELLED → IDLE
        FAILED → IDLE
        # Any non-terminal state → CANCELLED (forced cancel)
    """

    IDLE = "idle"
    DISCOVERING = "discovering"
    JOINING = "joining"
    PAUSED = "paused"
    WAITING_FOR_BREAKER = "waiting_for_breaker"
    RETRYING = "retrying"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    FAILED = "failed"
    STOPPED = "stopped"


# Terminal states — once entered, the only valid transition is → IDLE (reset).
TERMINAL_STATES = frozenset({
    JoinAllWorkerState.COMPLETED,
    JoinAllWorkerState.CANCELLED,
    JoinAllWorkerState.FAILED,
    JoinAllWorkerState.STOPPED,
})


# ===========================================================================
# State Machine
# ===========================================================================

_ALLOWED_TRANSITIONS: dict[JoinAllWorkerState, frozenset[JoinAllWorkerState]] = {
    JoinAllWorkerState.IDLE: frozenset({
        JoinAllWorkerState.DISCOVERING,
        JoinAllWorkerState.FAILED,
    }),
    JoinAllWorkerState.DISCOVERING: frozenset({
        JoinAllWorkerState.JOINING,
        JoinAllWorkerState.COMPLETED,
        JoinAllWorkerState.FAILED,
        JoinAllWorkerState.CANCELLED,
    }),
    JoinAllWorkerState.JOINING: frozenset({
        JoinAllWorkerState.PAUSED,
        JoinAllWorkerState.WAITING_FOR_BREAKER,
        JoinAllWorkerState.RETRYING,
        JoinAllWorkerState.COMPLETED,
        JoinAllWorkerState.CANCELLED,
        JoinAllWorkerState.FAILED,
        JoinAllWorkerState.STOPPED,
    }),
    JoinAllWorkerState.PAUSED: frozenset({
        JoinAllWorkerState.JOINING,
        JoinAllWorkerState.CANCELLED,
        JoinAllWorkerState.STOPPED,
    }),
    JoinAllWorkerState.WAITING_FOR_BREAKER: frozenset({
        JoinAllWorkerState.JOINING,
        JoinAllWorkerState.FAILED,
        JoinAllWorkerState.CANCELLED,
        JoinAllWorkerState.STOPPED,
    }),
    JoinAllWorkerState.RETRYING: frozenset({
        JoinAllWorkerState.JOINING,
        JoinAllWorkerState.FAILED,
        JoinAllWorkerState.CANCELLED,
        JoinAllWorkerState.STOPPED,
    }),
    # Terminal → IDLE only (reset).
    JoinAllWorkerState.COMPLETED: frozenset({JoinAllWorkerState.IDLE}),
    JoinAllWorkerState.CANCELLED: frozenset({JoinAllWorkerState.IDLE}),
    JoinAllWorkerState.FAILED: frozenset({JoinAllWorkerState.IDLE}),
    JoinAllWorkerState.STOPPED: frozenset({JoinAllWorkerState.IDLE}),
}


class IllegalStateTransitionError(RuntimeError):
    """Raised when a state transition is not in the allowed set."""


class WorkerStateMachine:
    """Validated state-transition engine for the Join-All worker.

    Thread-safety: the internal ``_state`` is protected by an ``asyncio.Lock``
    so the worker, the auto-refresh UI loop, and admin commands can all query
    the state concurrently.
    """

    def __init__(self, initial: JoinAllWorkerState = JoinAllWorkerState.IDLE) -> None:
        self._state: JoinAllWorkerState = initial
        self._lock = asyncio.Lock()
        self._previous: JoinAllWorkerState = initial
        self._transition_log: list[tuple[float, JoinAllWorkerState, JoinAllWorkerState]] = []

    @property
    def state(self) -> JoinAllWorkerState:
        """Current state (lock-free read — enum assignment is atomic in CPython)."""
        return self._state

    @property
    def previous(self) -> JoinAllWorkerState:
        return self._previous

    @property
    def is_terminal(self) -> bool:
        return self._state in TERMINAL_STATES

    @property
    def is_running(self) -> bool:
        """True if the worker is actively processing (not idle/terminal/paused)."""
        return self._state in (
            JoinAllWorkerState.DISCOVERING,
            JoinAllWorkerState.JOINING,
            JoinAllWorkerState.RETRYING,
            JoinAllWorkerState.WAITING_FOR_BREAKER,
        )

    async def transition_to(self, new_state: JoinAllWorkerState) -> None:
        """Validate and apply a state transition.

        Raises ``IllegalStateTransitionError`` if the transition is not allowed.
        """
        async with self._lock:
            old = self._state
            allowed = _ALLOWED_TRANSITIONS.get(old, frozenset())
            if new_state not in allowed:
                raise IllegalStateTransitionError(
                    f"Illegal transition: {old.value} → {new_state.value} "
                    f"(allowed: {sorted(s.value for s in allowed)})"
                )
            self._previous = old
            self._state = new_state
            self._transition_log.append((time.monotonic(), old, new_state))
            if len(self._transition_log) > 200:
                # Opportunistic trim — keep last 200 transitions.
                self._transition_log = self._transition_log[-100:]
            logger.debug("JOIN_ALL_STATE %s → %s", old.value, new_state.value)

    async def force_cancel(self) -> None:
        """Force the state machine to CANCELLED from any non-terminal state.

        Used by the shutdown handler — bypasses the transition validator
        because cancellation must always succeed.
        """
        async with self._lock:
            old = self._state
            if old in TERMINAL_STATES:
                return
            self._previous = old
            self._state = JoinAllWorkerState.CANCELLED
            self._transition_log.append((time.monotonic(), old, JoinAllWorkerState.CANCELLED))
            logger.info("JOIN_ALL_FORCE_CANCEL %s → cancelled", old.value)

    async def reset(self) -> None:
        """Reset to IDLE unconditionally (bypasses the transition validator).

        v97 SR-1 FIX: previously this called ``transition_to(IDLE)`` which
        validates against ``_ALLOWED_TRANSITIONS``.  But:
          * On the very first run, the state machine starts at IDLE, and
            IDLE → IDLE is not in the allowed set → ``IllegalStateTransitionError``.
          * After a cooperative stop, the state is left at PAUSED/STOPPED, and
            PAUSED → IDLE / STOPPED → IDLE are not allowed either.

        ``reset()`` is a *new-run* primitive and must always succeed, so it
        bypasses the validator (like ``force_cancel``).
        """
        async with self._lock:
            old = self._state
            self._previous = old
            self._state = JoinAllWorkerState.IDLE
            self._transition_log.append((time.monotonic(), old, JoinAllWorkerState.IDLE))

    def snapshot(self) -> dict[str, Any]:
        """Return a read-only snapshot of the state machine."""
        return {
            "state": self._state.value,
            "previous": self._previous.value,
            "is_terminal": self._state in TERMINAL_STATES,
            "is_running": self.is_running,
            "transitions": len(self._transition_log),
        }


# ===========================================================================
# Circuit Breaker
# ===========================================================================

class CircuitBreakerState(enum.Enum):
    """Three-state circuit breaker."""

    CLOSED = "closed"        # normal operation — calls proceed
    OPEN = "open"            # tripped — calls blocked, worker should pause
    HALF_OPEN = "half_open"  # cooldown expired — probing with a single call


class CircuitBreaker:
    """Production-grade circuit breaker with auto-recovery.

    States:
        CLOSED  →  failure threshold reached  →  OPEN
        OPEN    →  cooldown expires           →  HALF_OPEN
        HALF_OPEN →  success                  →  CLOSED (reset)
        HALF_OPEN →  failure                  →  OPEN (extend cooldown)

    The breaker tracks failures *per error class* so that a FloodWait
    (systemic rate-limit) and a ``GroupcallForbiddenError`` (per-target
    permission) are counted independently.

    Configuration:
        failure_threshold: number of same-class failures to open the breaker.
        cooldown_seconds:  how long OPEN persists before transitioning to HALF_OPEN.
        max_half_open_failures: consecutive HALF_OPEN failures before the
                                breaker is declared permanently OPEN (→ FAILED).
        half_open_max_concurrent: probes allowed in HALF_OPEN (default 1).
    """

    def __init__(
        self,
        *,
        failure_threshold: int = 3,
        cooldown_seconds: float = 60.0,
        max_half_open_failures: int = 5,
        half_open_max_concurrent: int = 1,
    ) -> None:
        self.failure_threshold = max(1, failure_threshold)
        self.cooldown_seconds = max(1.0, cooldown_seconds)
        # v97.9 FIX: save the initial cooldown so reset() can restore it.
        # The v97.8 FloodWait fix mutates cooldown_seconds to match the
        # FloodWait duration (e.g. 200s for a 195s FloodWait).  Without
        # restoring it in reset(), the cooldown grows monotonically across
        # runs — every subsequent run waits 200s even for a 5s FloodWait.
        self._initial_cooldown_seconds = self.cooldown_seconds
        self.max_half_open_failures = max(1, max_half_open_failures)
        self.half_open_max_concurrent = max(1, half_open_max_concurrent)

        self._state = CircuitBreakerState.CLOSED
        self._failures: dict[str, int] = {}          # error_class → count (aggregate)
        # v97.5 ACCOUNT-SCOPED BREAKER: track failures per (account_id,
        # error_class) so one account's timeout does NOT open the breaker
        # for healthy accounts.  The global breaker opens only when an
        # INDIVIDUAL account reaches the threshold — not when the aggregate
        # does.  This fixes the root cause of "one timeout blocks all
        # accounts" (PART 6).
        self._account_failures: dict[tuple[str, str], int] = {}
        self._account_open: set[str] = set()         # accounts currently blocked
        # v97.9: per-account opened-at timestamps for cooldown recovery.
        # Without this, an account blocked by 3 failures stays blocked for
        # the entire run (no HALF_OPEN recovery like the global breaker).
        self._account_opened_at: dict[str, float] = {}
        self._opened_at: float = 0.0                 # monotonic timestamp
        self._open_reason: str = ""
        self._half_open_failures = 0
        self._lock = asyncio.Lock()

    @property
    def state(self) -> CircuitBreakerState:
        return self._state

    @property
    def is_open(self) -> bool:
        """True if the breaker is OPEN (calls should be blocked)."""
        return self._state == CircuitBreakerState.OPEN

    @property
    def is_closed(self) -> bool:
        return self._state == CircuitBreakerState.CLOSED

    @property
    def is_half_open(self) -> bool:
        return self._state == CircuitBreakerState.HALF_OPEN

    @property
    def open_reason(self) -> str:
        return self._open_reason

    @property
    def seconds_since_opened(self) -> float:
        if self._opened_at == 0.0:
            return 0.0
        return time.monotonic() - self._opened_at

    @property
    def cooldown_remaining(self) -> float:
        """Seconds until the breaker should transition OPEN → HALF_OPEN.

        Returns 0.0 if not OPEN or if cooldown has elapsed.
        """
        if self._state != CircuitBreakerState.OPEN:
            return 0.0
        elapsed = self.seconds_since_opened
        remaining = self.cooldown_seconds - elapsed
        return max(0.0, remaining)

    def is_account_open(self, account_id: str) -> bool:
        """v97.5: True if a SPECIFIC account is currently breaker-blocked.

        Healthy accounts are NOT blocked by another account's failures.
        Systemic failures (FloodWait, backend-down) still open the GLOBAL
        breaker via ``is_open``.

        v97.9: per-account cooldown recovery.  If the account has been
        blocked for longer than ``cooldown_seconds``, auto-recover (remove
        from _account_open + clear failure counts) so the account gets
        another chance — mirroring the global breaker's OPEN→HALF_OPEN→CLOSED
        recovery.  Without this, a 3x FloodWait burst permanently blocks
        the account for the entire run.
        """
        if not account_id:
            return self.is_open
        if account_id not in self._account_open:
            return False
        # v97.9: check per-account cooldown.
        opened_at = self._account_opened_at.get(account_id, 0.0)
        if opened_at > 0.0:
            elapsed = time.monotonic() - opened_at
            if elapsed >= self.cooldown_seconds:
                # Cooldown elapsed — auto-recover the account.
                self._account_open.discard(account_id)
                self._account_opened_at.pop(account_id, None)
                _to_remove = [k for k in self._account_failures if k[0] == account_id]
                for k in _to_remove:
                    self._account_failures.pop(k, None)
                logger.info(
                    "JOIN_ALL_BREAKER ACCOUNT_RECOVERED account_id=%s "
                    "(cooldown elapsed after %.1fs)",
                    account_id, elapsed,
                )
                return False
        return True

    async def before_call(self, account_id: str = "") -> bool:
        """Check whether a call is allowed.

        v97.5: when ``account_id`` is provided, the check is account-scoped:
        a healthy account is allowed even if another account's failures
        opened the global breaker.  Systemic failures (is_systemic=True)
        still block all accounts.

        Returns:
            True if the call may proceed (CLOSED or HALF_OPEN or healthy account).
            False if the call is blocked (OPEN and cooldown not elapsed and
            the account is the one that failed, or the failure is systemic).
        """
        async with self._lock:
            # v97.5: account-scoped check — healthy accounts proceed.
            if account_id and account_id not in self._account_open:
                # The specific account is healthy.  But if the GLOBAL breaker
                # is OPEN due to a SYSTEMIC failure (FloodWait, backend-down),
                # we must still block.  We approximate "systemic" by checking
                # the global open_reason — if it contains "systemic" or
                # "FloodWait", block all accounts.
                if self._state == CircuitBreakerState.OPEN:
                    _reason_l = (self._open_reason or "").lower()
                    if "systemic" in _reason_l or "floodwait" in _reason_l:
                        return False  # systemic — block all
                    if self.cooldown_remaining <= 0.0:
                        # Global cooldown elapsed — transition to HALF_OPEN.
                        self._state = CircuitBreakerState.HALF_OPEN
                        return True
                    return False  # global open, non-systemic, account healthy → allow
                return True
            if self._state == CircuitBreakerState.CLOSED:
                return True
            if self._state == CircuitBreakerState.HALF_OPEN:
                return True
            # OPEN — check if cooldown has elapsed.
            if self.cooldown_remaining <= 0.0:
                self._state = CircuitBreakerState.HALF_OPEN
                # v97 PA-1 FIX: do NOT reset _half_open_failures here.
                logger.info(
                    "JOIN_ALL_BREAKER OPEN → HALF_OPEN (cooldown elapsed after %.1fs, "
                    "half_open_failures=%d/%d)",
                    self.seconds_since_opened,
                    self._half_open_failures, self.max_half_open_failures,
                )
                return True
            return False

    async def record_success(self, error_class: str = "", account_id: str = "") -> None:
        """Record a successful call.

        In HALF_OPEN, a success transitions the breaker back to CLOSED
        (full reset) and resumes the worker.

        v97.5: when ``account_id`` is provided, also clears that account's
        per-account failure state (so it becomes eligible again).
        """
        async with self._lock:
            if error_class:
                self._failures.pop(error_class, None)
            if account_id:
                self._account_open.discard(account_id)
                # v97.9: clear the per-account opened-at timestamp.
                self._account_opened_at.pop(account_id, None)
                # Clear per-account failure counts for this account.
                _to_remove = [k for k in self._account_failures if k[0] == account_id]
                for k in _to_remove:
                    self._account_failures.pop(k, None)
            if self._state == CircuitBreakerState.HALF_OPEN:
                logger.info(
                    "JOIN_ALL_BREAKER HALF_OPEN → CLOSED (probe succeeded)"
                )
                self._state = CircuitBreakerState.CLOSED
                self._failures.clear()
                self._account_failures.clear()
                self._account_open.clear()
                self._half_open_failures = 0
                self._opened_at = 0.0
                self._open_reason = ""

    async def record_failure(
        self,
        error_class: str,
        *,
        reason: str = "",
        is_systemic: bool = False,
        account_id: str = "",
    ) -> bool:
        """Record a failed call.

        v97.5: when ``account_id`` is provided, the failure is tracked
        per-account.  The GLOBAL breaker opens only when the SAME account
        reaches the threshold — not when different accounts each fail once.
        This means: account A timing out does NOT block account B.
        Systemic failures (is_systemic=True) still open the global breaker.

        Args:
            error_class: short identifier (e.g. ``"FloodWait"``,
                         ``"VCTransportError"``, ``"TimeoutError"``).
            reason: human-readable detail.
            is_systemic: if True, the failure is treated as systemic (rate-limit,
                         backend-down) and the threshold is lowered to 1.
            account_id: the account that failed (for per-account tracking).

        Returns:
            True if the breaker transitioned to OPEN (caller should pause),
            False otherwise.
        """
        async with self._lock:
            # HALF_OPEN failure → back to OPEN (with extended cooldown).
            if self._state == CircuitBreakerState.HALF_OPEN:
                self._half_open_failures += 1
                if self._half_open_failures >= self.max_half_open_failures:
                    logger.error(
                        "JOIN_ALL_BREAKER HALF_OPEN → OPEN (max half-open "
                        "failures %d reached) — declaring FAILED",
                        self._half_open_failures,
                    )
                    self._state = CircuitBreakerState.OPEN
                    self._opened_at = time.monotonic()
                    self._open_reason = (
                        f"Half-open probe failed {self._half_open_failures}x "
                        f"({error_class}): {reason}"
                    )
                    return True
                # Extend cooldown and go back to OPEN.
                logger.warning(
                    "JOIN_ALL_BREAKER HALF_OPEN → OPEN (probe failed, "
                    "attempt %d/%d): %s",
                    self._half_open_failures, self.max_half_open_failures,
                    reason[:120],
                )
                self._state = CircuitBreakerState.OPEN
                self._opened_at = time.monotonic()
                self._open_reason = f"Half-open probe failed: {reason}"
                return True

            # CLOSED — accumulate failures.
            # v97.5: track per-account if account_id is given.
            if account_id and not is_systemic:
                ak = (account_id, error_class)
                acct_count = self._account_failures.get(ak, 0) + 1
                self._account_failures[ak] = acct_count
                # Also track aggregate (for diagnostics).
                count = self._failures.get(error_class, 0) + 1
                self._failures[error_class] = count
                threshold = self.failure_threshold
                if acct_count >= threshold:
                    # This SPECIFIC account reached the threshold — block it,
                    # but do NOT block healthy accounts.
                    self._account_open.add(account_id)
                    # v97.9: record the opened-at timestamp for cooldown recovery.
                    self._account_opened_at[account_id] = time.monotonic()
                    logger.error(
                        "JOIN_ALL_BREAKER ACCOUNT_OPEN account_id=%s (%s x%d/%d): %s "
                        "— healthy accounts NOT blocked",
                        account_id, error_class, acct_count, threshold, reason[:120],
                    )
                    # Do NOT transition the global breaker to OPEN unless ALL
                    # healthy accounts are exhausted (caller checks separately).
                    return True
                logger.warning(
                    "JOIN_ALL_BREAKER account failure: account=%s %s x%d/%d",
                    account_id, error_class, acct_count, threshold,
                )
                return False
            # No account_id or systemic — original aggregate behaviour.
            count = self._failures.get(error_class, 0) + 1
            self._failures[error_class] = count
            threshold = 1 if is_systemic else self.failure_threshold
            if count >= threshold:
                self._state = CircuitBreakerState.OPEN
                self._opened_at = time.monotonic()
                self._open_reason = (
                    f"{error_class} x{count} (threshold={threshold}"
                    f"{', systemic' if is_systemic else ''}): {reason}"
                )
                logger.error(
                    "JOIN_ALL_BREAKER CLOSED → OPEN (%s)", self._open_reason[:160]
                )
                return True
            logger.warning(
                "JOIN_ALL_BREAKER failure recorded: %s x%d/%d%s",
                error_class, count, threshold,
                " (systemic)" if is_systemic else "",
            )
            return False

    async def reset(self) -> None:
        """Reset the breaker to CLOSED (e.g. on new run)."""
        async with self._lock:
            self._state = CircuitBreakerState.CLOSED
            self._failures.clear()
            self._account_failures.clear()
            self._account_open.clear()
            self._account_opened_at.clear()
            self._opened_at = 0.0
            self._open_reason = ""
            self._half_open_failures = 0
            # v97.9 FIX: restore the initial cooldown (the v97.8 FloodWait
            # fix may have raised it to match a FloodWait duration; without
            # this, the elevated cooldown persists across runs).
            self.cooldown_seconds = self._initial_cooldown_seconds

    def snapshot(self) -> dict[str, Any]:
        return {
            "state": self._state.value,
            "failures": dict(self._failures),
            "account_open": sorted(self._account_open),
            "account_failures": {f"{a}:{e}": c for (a, e), c in self._account_failures.items()},
            "opened_at": self._opened_at,
            "open_reason": self._open_reason,
            "cooldown_remaining": self.cooldown_remaining,
            "half_open_failures": self._half_open_failures,
        }


# ===========================================================================
# Cancellation Token
# ===========================================================================

class CancellationToken:
    """Cooperative cancellation flag with an asyncio.Event.

    The worker checks ``is_cancelled`` at every checkpoint (between targets).
    Admin stop sets the flag; the worker exits gracefully at the next
    checkpoint.  For hard cancellation (timeout), the caller can also
    cancel the underlying asyncio.Task.
    """

    def __init__(self) -> None:
        self._event = asyncio.Event()
        self._reason: str = ""

    @property
    def is_cancelled(self) -> bool:
        return self._event.is_set()

    @property
    def reason(self) -> str:
        return self._reason

    def cancel(self, reason: str = "cancelled") -> None:
        """Request cooperative cancellation."""
        if not self._event.is_set():
            self._reason = reason
            self._event.set()
            logger.info("JOIN_ALL_CANCEL_REQUEST reason=%s", reason)

    async def wait(self, timeout: Optional[float] = None) -> None:
        """Wait until cancelled (or timeout)."""
        if timeout is None:
            await self._event.wait()
        else:
            try:
                await asyncio.wait_for(self._event.wait(), timeout=timeout)
            except asyncio.TimeoutError:
                pass

    def reset(self) -> None:
        self._event.clear()
        self._reason = ""


# ===========================================================================
# Retry Policy
# ===========================================================================

@dataclass(frozen=True)
class RetryPolicy:
    """Exponential backoff retry policy for transient failures.

    Attributes:
        max_attempts: maximum number of attempts per target (including the first).
        base_delay: initial backoff delay in seconds.
        max_delay: cap on the backoff delay.
        multiplier: backoff multiplier (e.g. 2.0 = double each attempt).
        jitter: fraction of jitter to add (0.0 = none, 0.25 = ±25%).
    """

    max_attempts: int = 3
    base_delay: float = 2.0
    max_delay: float = 60.0
    multiplier: float = 2.0
    jitter: float = 0.25

    def delay_for(self, attempt: int) -> float:
        """Compute the backoff delay for the given attempt (1-indexed)."""
        if attempt <= 1:
            return 0.0
        delay = self.base_delay * (self.multiplier ** (attempt - 2))
        delay = min(delay, self.max_delay)
        if self.jitter > 0:
            import random
            jitter_amount = delay * self.jitter
            delay += random.uniform(-jitter_amount, jitter_amount)
        return max(0.1, delay)


# ===========================================================================
# Checkpoint Manager
# ===========================================================================

# Module-level DB functions — injected lazily to avoid circular imports.
_db_layer: Any = None


def _get_db_layer() -> Any:
    """Lazily import the db_layer module (avoids circular import at module load)."""
    global _db_layer
    if _db_layer is None:
        from . import db_layer
        _db_layer = db_layer
    return _db_layer


class CheckpointManager:
    """Persists Join-All run progress to the ``vc_join_all_runs`` table.

    Schema (created by db_layer migration):

        CREATE TABLE IF NOT EXISTS vc_join_all_runs (
            run_id          TEXT PRIMARY KEY,        -- UUID-like
            started_at      TEXT NOT NULL,
            updated_at      TEXT NOT NULL,
            completed_at    TEXT,
            state           TEXT NOT NULL,           -- worker state
            terminal_status TEXT NOT NULL DEFAULT '',-- "" | completed | cancelled | failed | stopped
            cancel_reason   TEXT NOT NULL DEFAULT '',
            last_error      TEXT NOT NULL DEFAULT '',
            -- progress
            total_targets   INTEGER NOT NULL DEFAULT 0,
            processed       INTEGER NOT NULL DEFAULT 0,
            current_index   INTEGER NOT NULL DEFAULT 0,  -- checkpoint: next target to process
            joined_confirmed INTEGER NOT NULL DEFAULT 0,
            already_joined  INTEGER NOT NULL DEFAULT 0,
            confirmation_unknown INTEGER NOT NULL DEFAULT 0,
            confirmed_not_joined INTEGER NOT NULL DEFAULT 0,
            skipped_call_ended INTEGER NOT NULL DEFAULT 0,
            skipped_in_flight INTEGER NOT NULL DEFAULT 0,
            failed          INTEGER NOT NULL DEFAULT 0,
            deferred        INTEGER NOT NULL DEFAULT 0,
            floodwait_count INTEGER NOT NULL DEFAULT 0,
            -- serialized target list + results
            targets_json    TEXT NOT NULL DEFAULT '[]',
            results_json    TEXT NOT NULL DEFAULT '{}',
            discovery_json  TEXT NOT NULL DEFAULT '{}',
            breaker_json    TEXT NOT NULL DEFAULT '{}',
            -- v99.11 durability: crash-loop forensics + admission coupling
            pid             INTEGER NOT NULL DEFAULT 0,
            resume_attempts INTEGER NOT NULL DEFAULT 0,
            resource_json   TEXT NOT NULL DEFAULT '{}',
            last_successful_target TEXT NOT NULL DEFAULT '',
            last_failed_target     TEXT NOT NULL DEFAULT ''
        );

    The checkpoint is written after every target is processed, so a crash
    or restart never loses more than the in-flight target.

    v99.11 P1 (durable checkpointing + crash-loop guard):
      * every checkpoint persists the process PID + a resource snapshot
        (rss/threads/fd/joined/limit) — post-mortem proof of the OOM
        approach even before the heartbeat line lands;
      * ``resume_attempts`` counts auto-resume attempts per run — the
        startup crash-loop guard couples backoff + admission reduction
        to it (VC_CRASH_LOOP_MAX_FAILURES trips → no auto-resume,
        high-severity VC_JOIN_ALL_CRASH_GUARD marker, manual resume
        required);
      * saves are serialized under an asyncio lock (the v99.10
        fire-and-forget distributed-progress checkpoints could
        interleave UPDATE+commit pairs with the worker's own saves).
    """

    def __init__(self) -> None:
        self._v9911_save_lock: Any = None  # lazy asyncio.Lock (loop-safe)

    def _save_lock(self) -> Any:
        if self._v9911_save_lock is None:
            self._v9911_save_lock = asyncio.Lock()
        return self._v9911_save_lock

    async def create_run(
        self,
        run_id: str,
        targets: list[dict],
        *,
        discovery: dict[str, Any] | None = None,
    ) -> None:
        """Create a new run record."""
        db_layer = _get_db_layer()
        db = await db_layer.get_db()
        now = _now_iso()
        await db.execute(
            """INSERT OR REPLACE INTO vc_join_all_runs
               (run_id, started_at, updated_at, state, terminal_status,
                cancel_reason, last_error, total_targets, processed,
                current_index, joined_confirmed, already_joined,
                confirmation_unknown, confirmed_not_joined,
                skipped_call_ended, skipped_in_flight, failed, deferred,
                floodwait_count, targets_json, results_json,
                discovery_json, breaker_json)
               VALUES (?, ?, ?, ?, '', '', '', ?, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ?, '{}', ?, '{}')""",
            (
                run_id, now, now, JoinAllWorkerState.DISCOVERING.value,
                len(targets), json.dumps(targets, ensure_ascii=False),
                json.dumps(discovery or {}, ensure_ascii=False),
            ),
        )
        await db.commit()

    async def save_checkpoint(
        self,
        run_id: str,
        *,
        state: JoinAllWorkerState,
        terminal_status: str = "",
        cancel_reason: str = "",
        last_error: str = "",
        progress: dict[str, int] | None = None,
        current_index: int = 0,
        results: dict[int, dict] | None = None,
        targets: list[dict] | None = None,
        discovery: dict[str, Any] | None = None,
        floodwait_count: int = 0,
        breaker_snapshot: dict[str, Any] | None = None,
        resource_snapshot: dict[str, Any] | None = None,
        last_successful_target: str = "",
        last_failed_target: str = "",
    ) -> None:
        """Persist the current progress (called after each target).

        v99.11: the save is serialized under the manager's asyncio lock
        (concurrent fire-and-forget distributed-progress saves can no
        longer interleave UPDATE/commit pairs), and the row gains the
        PID + resource snapshot + last-successful/failed target fields
        for crash-loop forensics.
        """
        async with self._save_lock():
            db_layer = _get_db_layer()
            db = await db_layer.get_db()
            now = _now_iso()
            prog = progress or {}
            # v97.5 CHECKPOINT-RACE FIX: a mid-run checkpoint (terminal_status="")
            # must NEVER overwrite an already-terminal run (completed/cancelled/
            # failed/stopped).  Previously, the fire-and-forget progress checkpoint
            # scheduled by ``_on_dist_progress`` could execute AFTER the worker's
            # finally block saved terminal_status="completed" — clobbering it back
            # to "".  The next Join-All then saw the completed run as "incomplete"
            # and incorrectly resumed it (IllegalStateTransition idle→joining).
            # ``COALESCE(NULLIF(?, ''), terminal_status)`` keeps the existing
            # terminal value when the new value is empty.
            #
            # v99.11: last_successful/last_failed target use the same
            # COALESCE pattern so a mid-run save with '' never erases
            # the forensic trail.
            await db.execute(
                """UPDATE vc_join_all_runs SET
                     updated_at = ?, state = ?,
                     terminal_status = COALESCE(NULLIF(?, ''), terminal_status),
                     cancel_reason = ?, last_error = ?,
                     processed = ?, current_index = ?,
                     joined_confirmed = ?, already_joined = ?,
                     confirmation_unknown = ?, confirmed_not_joined = ?,
                     skipped_call_ended = ?, skipped_in_flight = ?,
                     failed = ?, deferred = ?, floodwait_count = ?,
                     results_json = ?, targets_json = ?, discovery_json = ?,
                     breaker_json = ?,
                     pid = ?,
                     resource_json = ?,
                     last_successful_target = COALESCE(NULLIF(?, ''), last_successful_target),
                     last_failed_target = COALESCE(NULLIF(?, ''), last_failed_target),
                     completed_at = CASE WHEN ? != '' THEN ? ELSE completed_at END
                   WHERE run_id = ?""",
                (
                    now, state.value, terminal_status,
                    cancel_reason, last_error,
                    prog.get("processed", 0), current_index,
                    prog.get("joined_confirmed", 0), prog.get("already_joined", 0),
                    prog.get("confirmation_unknown", 0), prog.get("confirmed_not_joined", 0),
                    prog.get("skipped_call_ended", 0), prog.get("skipped_in_flight", 0),
                    prog.get("failed", 0), prog.get("deferred", 0), floodwait_count,
                    json.dumps(
                        {str(k): v for k, v in (results or {}).items()},
                        ensure_ascii=False, default=str,
                    ),
                    json.dumps(targets or [], ensure_ascii=False, default=str),
                    json.dumps(discovery or {}, ensure_ascii=False, default=str),
                    json.dumps(breaker_snapshot or {}, ensure_ascii=False, default=str),
                    os.getpid(),
                    json.dumps(resource_snapshot or {}, ensure_ascii=False, default=str),
                    last_successful_target, last_failed_target,
                    terminal_status, now,
                    run_id,
                ),
            )
            await db.commit()

    async def load_run(self, run_id: str) -> dict[str, Any] | None:
        """Load a run by ID (for resume)."""
        db_layer = _get_db_layer()
        db = await db_layer.get_db()
        async with db.execute(
            "SELECT * FROM vc_join_all_runs WHERE run_id = ?",
            (run_id,),
        ) as cur:
            row = await cur.fetchone()
        if row is None:
            return None
        return _row_to_dict(row)

    async def load_latest_incomplete_run(self) -> dict[str, Any] | None:
        """Load the most recent resumable run (for startup recovery + /joinallresume).

        v97 CHAOS-1 FIX: previously only found runs with terminal_status=''.
        But ``vc_join_all_startup_recovery`` marks interrupted runs as
        terminal_status='stopped' — which made them invisible to resume.
        Now also finds 'stopped' runs (interrupted by bot restart) so the
        admin can actually resume them via /joinallresume.
        """
        db_layer = _get_db_layer()
        db = await db_layer.get_db()
        async with db.execute(
            """SELECT * FROM vc_join_all_runs
               WHERE terminal_status = '' OR terminal_status IS NULL
                  OR terminal_status = 'stopped'
               ORDER BY started_at DESC LIMIT 1""",
        ) as cur:
            row = await cur.fetchone()
        if row is None:
            return None
        return _row_to_dict(row)

    async def mark_interrupted(self, run_id: str, reason: str = "interrupted") -> None:
        """Mark a run as interrupted (bot restarted mid-run)."""
        db_layer = _get_db_layer()
        db = await db_layer.get_db()
        now = _now_iso()
        await db.execute(
            """UPDATE vc_join_all_runs SET
                 updated_at = ?, completed_at = ?, terminal_status = 'stopped',
                 cancel_reason = ?, state = 'stopped'
               WHERE run_id = ? AND (terminal_status = '' OR terminal_status IS NULL)""",
            (now, now, reason, run_id),
        )
        await db.commit()

    # ------------------------------------------------------------------
    # v99.11 P1 — durable crash-loop forensics + resume-attempt tracking
    # ------------------------------------------------------------------

    async def record_resume_attempt(self, run_id: str) -> int:
        """v99.11: increment + return the run's auto-resume attempt count.

        The startup crash-loop guard couples backoff and admission
        reduction to this counter (VC_CRASH_LOOP_MAX_FAILURES trips →
        auto-resume disabled for the run; manual /joinallresume stays
        available — Join-All is never permanently disabled).
        """
        async with self._save_lock():
            db_layer = _get_db_layer()
            db = await db_layer.get_db()
            await db.execute(
                """UPDATE vc_join_all_runs SET
                     resume_attempts = resume_attempts + 1,
                     updated_at = ?
                   WHERE run_id = ?""",
                (_now_iso(), run_id),
            )
            await db.commit()
            row = await self.load_run(run_id)
            return int((row or {}).get("resume_attempts", 0) or 0)

    async def count_recent_crash_loops(
        self, *, window_seconds: float = 3600.0,
    ) -> int:
        """v99.11: how many runs were crash-interrupted inside the window.

        Counts rows whose cancel_reason carries the durable crash
        signature ('bot_restart_interrupted') and whose last update is
        within ``window_seconds`` — the tripwire for the crash→resume→
        crash loop (the 2026-09-21 production pattern: die at the ~47th
        transport → systemd restart in 10s → auto-resume at +75s →
        re-climb to the same boundary → die again).
        """
        try:
            db_layer = _get_db_layer()
            db = await db_layer.get_db()
            cutoff = datetime.now(timezone.utc).timestamp() - float(window_seconds)
            async with db.execute(
                """SELECT COUNT(*) AS n FROM vc_join_all_runs
                   WHERE cancel_reason LIKE '%bot_restart_interrupted%'
                     AND updated_at >= datetime(?, 'unixepoch')""",
                (int(cutoff),),
            ) as cur:
                row = await cur.fetchone()
            return int(row[0] if row else 0)
        except Exception:  # noqa: BLE001
            return 0

    async def list_recent_runs(self, limit: int = 20) -> list[dict[str, Any]]:
        """List recent runs (for history UI)."""
        db_layer = _get_db_layer()
        db = await db_layer.get_db()
        async with db.execute(
            """SELECT run_id, started_at, completed_at, state, terminal_status,
                      cancel_reason, total_targets, processed, joined_confirmed,
                      failed, current_index
               FROM vc_join_all_runs
               ORDER BY started_at DESC LIMIT ?""",
            (limit,),
        ) as cur:
            rows = await cur.fetchall()
        return [_row_to_dict(r) for r in rows]

    async def cleanup_old_runs(self, days: int = 30) -> int:
        """Delete runs older than N days. Returns count deleted."""
        db_layer = _get_db_layer()
        db = await db_layer.get_db()
        cursor = await db.execute(
            """DELETE FROM vc_join_all_runs
               WHERE started_at < datetime('now', ?)""",
            (f"-{days} days",),
        )
        await db.commit()
        return cursor.rowcount or 0


def _row_to_dict(row: Any) -> dict[str, Any]:
    """Convert an aiosqlite.Row to a plain dict (handles JSON columns)."""
    d = dict(row)
    for key in ("targets_json", "results_json", "discovery_json", "breaker_json"):
        if key in d and isinstance(d[key], str):
            try:
                d[key] = json.loads(d[key])
            except (json.JSONDecodeError, TypeError):
                d[key] = {} if key != "targets_json" else []
    # Normalize results_json keys back to int (JSON serializes dict keys as strings).
    if isinstance(d.get("results_json"), dict):
        d["results_json"] = {
            int(k) if str(k).lstrip("-").isdigit() else k: v
            for k, v in d["results_json"].items()
        }
    return d


# ===========================================================================
# FloodWait parsing
# ===========================================================================

# Pre-compiled at module level (perf: avoid re.compile per call).
_FLOODWAIT_SIGNATURES = (
    "floodwait",
    "a wait of",
    "is required",
    "too many requests",
)
_FLOODWAIT_SECONDS_RE = re.compile(r"(\d+)\s*seconds?\s+is\s+required", re.IGNORECASE)
_FLOODWAIT_GENERIC_RE = re.compile(r"(\d+)\s*second", re.IGNORECASE)


def parse_floodwait_seconds(exc: BaseException) -> int | None:
    """Extract the FloodWait duration from an exception message.

    Returns the wait seconds, or None if the exception is not a FloodWait.
    Uses a strict pattern first (``A wait of N seconds is required``),
    then falls back to the generic ``N second`` pattern.
    """
    msg = str(exc).lower()
    if not any(sig in msg for sig in _FLOODWAIT_SIGNATURES):
        return None
    m = _FLOODWAIT_SECONDS_RE.search(str(exc))
    if m:
        return int(m.group(1))
    m = _FLOODWAIT_GENERIC_RE.search(str(exc))
    if m:
        return int(m.group(1))
    return 60  # fallback default if it IS a floodwait but we can't parse


def is_backend_wide_error(exc: BaseException) -> bool:
    """Check whether an error indicates a backend-wide (deterministic) failure."""
    msg = str(exc).lower()
    return any(sig in msg for sig in (
        "backend not started",
        "backend unavailable",
        "incompatible",
        "no supported join api",
        "vcbackend not started",
    ))


def is_interdc_error(exc: BaseException) -> bool:
    """v97.59 §12: detect InterdcCallErrorError (Telegram-side DC routing failure).

    Per §12: these must be classified SEPARATELY from FloodWait / network /
    auth failures. They indicate Telegram's internal DC routing failed — the
    chat is NOT permanently failed; retry with backoff (UNKNOWN/DEFERRED).
    """
    exc_name = type(exc).__name__.lower()
    msg = str(exc).lower()
    return "interdc" in exc_name or "interdc" in msg or "dc迁移" in msg


def is_transport_dc_timeout(exc: BaseException) -> bool:
    """v97.59 §12: detect a transport/DC timeout caused by JoinGroupCallRequest.

    Per §12: DO NOT declare the chat permanently failed. Use UNKNOWN/DEFERRED
    then reconcile.
    """
    exc_name = type(exc).__name__.lower()
    return exc_name in ("timeouterror", "asynciotimeouterror") or "timeout" in str(exc).lower()


# ===========================================================================
# Helpers
# ===========================================================================

def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def generate_run_id() -> str:
    """Generate a unique run ID (timestamp-based, sortable)."""
    import uuid
    return f"{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:8]}"
