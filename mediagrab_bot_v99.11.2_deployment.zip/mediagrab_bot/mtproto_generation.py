"""
v97.59: MTProto generation manager + single-flight reconnect coordinator.

ARCHITECTURE (master prompt §2/§3/§5/§7):

ONE authoritative MTProto lifecycle state machine per account/session.
No independent health loop + watchdog + cluster reconnect loop may create
competing reconnect attempts.

This module provides:

  MTProtoGeneration  — a generation record (id, owner_token, state, tasks)
  MTProtoGenerationManager — per-session generation registry + retirement
  ReconnectCoordinator — single-flight reconnect with owner-token + backoff

States (per §5):
  CREATED → CONNECTING → CONNECTED → DISCONNECTED → RECONNECTING → CONNECTED
                                                       ↘ RETIRING → RETIRED
                                                       ↘ POISONED (terminal)
                                                       ↘ FAILED (terminal)

Network classification (per §2 — these are DISTINCT, not all "failures"):
  NETWORK_UNREACHABLE   — Errno 101 (do NOT rotate sessions; backoff longer)
  CONNECTION_RESET      — Errno 104 (transient; reconnect after short backoff)
  CONNECTION_ABORTED    — Errno 103 (transient; reconnect after short backoff)
  REMOTE_CLOSE          — "Server closed the connection" (transient)
  TIMEOUT               — RPC timeout (transient; retry with backoff)
  TELEGRAM_DC_ERROR     — InterdcCallErrorError (DC-specific; backoff)
  DISCONNECTED          — generic (reconnect)
  AUTH_FAILURE          — AuthKeyUnregistered/USER_DEACTIVATED (session invalid)
  SESSION_INVALID       — AuthKeyDuplicated (session reused elsewhere)
  NO_AUTHORIZED_SESSION — no candidate session authorized (NOT same as AUTH_FAILURE)

Key rules enforced:
  - Reconnect is SINGLE-FLIGHT: only one in-flight reconnect per session at a time.
  - Old-generation tasks never operate on the new client (owner-token check).
  - A POISONED generation is never reused.
  - Network-unreachable does NOT invalidate sessions (session candidates preserved
    across transient network failure).
  - Backoff is bounded + jittered.
  - Reconnect resumes automatically when the network returns.
"""
from __future__ import annotations

import asyncio
import logging
import random
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger("mediagrab")


class GenState(Enum):
    """MTProto client generation state."""
    CREATED = "created"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    RECONNECTING = "reconnecting"
    RETIRING = "retiring"
    RETIRED = "retired"           # terminal — safe
    POISONED = "poisoned"         # terminal — unsafe, never reuse
    FAILED = "failed"             # terminal — auth/session failure


class NetworkFailureClass(Enum):
    """Classification of a network/transport failure (per §2/§6/§12)."""
    NETWORK_UNREACHABLE = "network_unreachable"
    CONNECTION_RESET = "connection_reset"
    CONNECTION_ABORTED = "connection_aborted"
    REMOTE_CLOSE = "remote_close"
    TIMEOUT = "timeout"
    TELEGRAM_DC_ERROR = "telegram_dc_error"      # InterdcCallError
    DISCONNECTED = "disconnected"
    AUTH_FAILURE = "auth_failure"                # session-invalidating
    SESSION_INVALID = "session_invalid"          # session-invalidating
    FLOOD_WAIT = "flood_wait"                     # per-account rate limit
    PERMISSION_FAILURE = "permission_failure"    # ChatAdminRequired/ChannelPrivate
    ENTITY_FAILURE = "entity_failure"             # "Could not find input entity"
    UNKNOWN = "unknown"


# ─────────────────────────────────────────────────────────────────────────────
# Failure classification — distinguishes network errors from auth errors
# ─────────────────────────────────────────────────────────────────────────────

def classify_failure(exc: Optional[BaseException], exc_str: str = "") -> NetworkFailureClass:
    """Classify a network/transport failure into a distinct category.

    This is the SINGLE source of truth for error classification. All reconnect
    paths + session-rotation decisions must use this.

    Per §2: network-unreachable must NOT cause destructive session rotation.
    Only AUTH_FAILURE / SESSION_INVALID may invalidate a session.
    """
    if exc is None and not exc_str:
        return NetworkFailureClass.UNKNOWN
    s = (exc_str or str(exc)).lower()
    exc_name = type(exc).__name__.lower() if exc else ""

    # Auth failures (session-invalidating — ONLY these may rotate sessions).
    if any(k in s for k in ("authkeyunregistered", "auth_key_unregistered",
                             "user_deactivated", "userdeactivated",
                             "SESSION_REVOKED", "session_revoked")):
        return NetworkFailureClass.AUTH_FAILURE
    if "authkeyduplicated" in s or "auth_key_duplicated" in s:
        return NetworkFailureClass.SESSION_INVALID

    # FloodWait (per-account rate limit — not a network failure).
    if "floodwait" in exc_name or "flood_wait" in s or "a wait of" in s:
        return NetworkFailureClass.FLOOD_WAIT

    # Inter-DC errors (Telegram-side DC routing failure — §12).
    if "interdc" in exc_name or "interdc" in s:
        return NetworkFailureClass.TELEGRAM_DC_ERROR

    # v97.60 §6: permission failures (ChatAdminRequired/ChannelPrivate/Forbidden).
    # These are target-specific, NOT session-invalidating. The session is fine;
    # the bot just can't access THIS particular chat/VC.
    if any(k in exc_name or k in s for k in (
        "chatadminrequired", "channelprivate", "chatprivate",
        "privacyprestricted", "userrestricted",
    )) or any(k in s for k in (
        "chat admin required", "channel private", "chat private",
        "not enough rights", "permission denied", "forbidden",
    )):
        return NetworkFailureClass.PERMISSION_FAILURE

    # v97.60 §6: entity failures (cannot resolve input entity / access_hash missing).
    # Target-specific — the bot can't resolve THIS entity. NOT session-invalidating.
    if any(k in s for k in (
        "could not find the input entity", "cannot find input entity",
        "peer channel not found", "input entity not found",
        "access_hash", "cannot resolve input entity",
        "no access to this group", "entity not found",
    )):
        return NetworkFailureClass.ENTITY_FAILURE

    # Network-level errors (transient — do NOT invalidate sessions).
    if "errno 101" in s or "network is unreachable" in s:
        return NetworkFailureClass.NETWORK_UNREACHABLE
    if "errno 104" in s or "connection reset by peer" in s:
        return NetworkFailureClass.CONNECTION_RESET
    if "errno 103" in s or "software caused connection abort" in s:
        return NetworkFailureClass.CONNECTION_ABORTED
    if "server closed the connection" in s:
        return NetworkFailureClass.REMOTE_CLOSE
    if "0 bytes read" in s or "bytes read on a total of" in s:
        return NetworkFailureClass.REMOTE_CLOSE
    # v99.02 FIX-4a (RC-4a, RUNTIME-PROVEN via v99.01 production logs
    # 2026-09-10 01:00–03:20): 345 consecutive reconnect failures —
    # EVERY one classified UNKNOWN because none of the patterns above
    # matched Telethon's retry-exhausted message
    # "Connection to Telegram failed 3 time(s)" (a ConnectionError from
    # mtprotosender._try_connect) or the FD-exhaustion OSError — so the
    # coordinator stayed on the SHORT backoff ladder (16s cap;
    # failures=103 still waited only 8.5s) and retried every ~19s for
    # 2.3 hours. Both are network-reachability failures for backoff
    # purposes → NETWORK_UNREACHABLE (the long ladder 5→60s).
    if ("too many open files" in s or "errno 24" in s
            or "connection to telegram failed" in s
            or exc_name in ("connectionerror", "oserror")):
        return NetworkFailureClass.NETWORK_UNREACHABLE
    if exc_name in ("timeouterror", "asyncio.timeouterror") or "timeout" in s:
        return NetworkFailureClass.TIMEOUT
    if "disconnected" in s or "connectionclosed" in exc_name:
        return NetworkFailureClass.DISCONNECTED

    return NetworkFailureClass.UNKNOWN


def is_session_invalidating(cls: NetworkFailureClass) -> bool:
    """Only AUTH_FAILURE / SESSION_INVALID may invalidate a session.

    Per §2.3: a session candidate must only be rejected as unauthorized/invalid
    when authorization was actually proven false. Network failures do NOT
    invalidate sessions.
    """
    return cls in (NetworkFailureClass.AUTH_FAILURE, NetworkFailureClass.SESSION_INVALID)


def is_transient_network_failure(cls: NetworkFailureClass) -> bool:
    """Whether this failure is a transient network/transport issue
    (reconnect with backoff, do NOT rotate sessions)."""
    return cls in (
        NetworkFailureClass.NETWORK_UNREACHABLE,
        NetworkFailureClass.CONNECTION_RESET,
        NetworkFailureClass.CONNECTION_ABORTED,
        NetworkFailureClass.REMOTE_CLOSE,
        NetworkFailureClass.TIMEOUT,
        NetworkFailureClass.TELEGRAM_DC_ERROR,
        NetworkFailureClass.DISCONNECTED,
        NetworkFailureClass.UNKNOWN,  # unknown → treat as transient (safer)
    )


# ─────────────────────────────────────────────────────────────────────────────
# Generation record
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class MTProtoGeneration:
    """A single MTProto client generation (master prompt §3)."""
    generation_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    session_path: str = ""
    account_id: str = ""
    state: GenState = GenState.CREATED
    created_at: float = field(default_factory=time.monotonic)
    connected_at: float = 0.0
    retiring_at: float = 0.0
    retired_at: float = 0.0
    owner_token: str = field(default_factory=lambda: uuid.uuid4().hex)
    task_set: set[asyncio.Task] = field(default_factory=set)
    backend_generation: int = 0
    poisoned: bool = False
    poisoned_reason: str = ""
    authorized: bool = False      # proven by a successful get_me() or similar
    client: Any = None            # the Telethon TelegramClient (weak ref semantics)

    def is_active(self) -> bool:
        """Whether this generation may receive new work."""
        return self.state in (GenState.CONNECTING, GenState.CONNECTED,
                              GenState.RECONNECTING) and not self.poisoned

    def is_terminal(self) -> bool:
        return self.state in (GenState.RETIRED, GenState.POISONED, GenState.FAILED)

    def mark_retiring(self) -> None:
        if self.state not in (GenState.RETIRED, GenState.POISONED, GenState.FAILED):
            self.state = GenState.RETIRING
            self.retiring_at = time.monotonic()

    def mark_retired(self) -> None:
        self.state = GenState.RETIRED
        self.retired_at = time.monotonic()

    def mark_poisoned(self, reason: str = "") -> None:
        self.poisoned = True
        self.poisoned_reason = reason or "unknown"
        self.state = GenState.POISONED
        logger.error(
            "MTPROTO_GENERATION_POISONED gen=%s session=%s reason=%s — "
            "never reuse this generation",
            self.generation_id, self.session_path, self.poisoned_reason,
        )

    def mark_failed(self) -> None:
        self.state = GenState.FAILED

    def to_dict(self) -> dict[str, Any]:
        return {
            "generation_id": self.generation_id,
            "session_path": self.session_path,
            "account_id": self.account_id,
            "state": self.state.value,
            "poisoned": self.poisoned,
            "poisoned_reason": self.poisoned_reason,
            "authorized": self.authorized,
            "owner_token": self.owner_token[:8] + "...",  # never expose full token
            "backend_generation": self.backend_generation,
            "age_seconds": round(time.monotonic() - self.created_at, 1),
            "tasks": len(self.task_set),
        }


# ─────────────────────────────────────────────────────────────────────────────
# Per-session generation manager
# ─────────────────────────────────────────────────────────────────────────────

class MTProtoGenerationManager:
    """Per-session generation registry + safe retirement (master prompt §3/§7).

    Rules:
      - ONLY ONE ACTIVE generation may own a given session/account.
      - Before creating a replacement:
        1. mark old generation RETIRING
        2. stop new work entering old generation (is_active() returns False)
        3. drain safe tasks (caller does this)
        4. cancel only safe transport tasks (caller does this)
        5. verify termination (caller does this)
        6. mark POISONED if update loop cannot be safely retired
        7. never reuse a poisoned generation
        8. only then promote the replacement
    """

    def __init__(self):
        # session_key -> list of generations (newest last)
        self._generations: dict[str, list[MTProtoGeneration]] = {}
        self._lock = asyncio.Lock()

    def _key(self, session_path: str, account_id: str = "") -> str:
        return f"{account_id}:{session_path}"

    async def get_active(self, session_path: str, account_id: str = "") -> Optional[MTProtoGeneration]:
        """Get the currently-active generation for a session, if any."""
        key = self._key(session_path, account_id)
        async with self._lock:
            gens = self._generations.get(key, [])
            for g in reversed(gens):
                if g.is_active():
                    return g
            return None

    async def get_latest(self, session_path: str, account_id: str = "") -> Optional[MTProtoGeneration]:
        """Get the newest generation (active or not) for a session."""
        key = self._key(session_path, account_id)
        async with self._lock:
            gens = self._generations.get(key, [])
            return gens[-1] if gens else None

    async def create_generation(self, session_path: str, account_id: str = "",
                                 client: Any = None) -> MTProtoGeneration:
        """Create a new generation for a session. Marks any existing active
        generation RETIRING (caller must drain it before calling this).

        Returns the new generation. The new generation is in CREATED state —
        the caller must transition it to CONNECTING/CONNECTED.
        """
        key = self._key(session_path, account_id)
        async with self._lock:
            # Mark any existing active generation RETIRING.
            gens = self._generations.setdefault(key, [])
            for g in gens:
                if g.is_active():
                    g.mark_retiring()
                    logger.info(
                        "MTPROTO_GEN_RETIRING_OLD gen=%s session=%s — replaced by new generation",
                        g.generation_id, session_path,
                    )
            # v99.02 FIX-4d (RC-4c, RUNTIME-PROVEN via v99.01 production
            # logs 2026-09-10 01:00–03:20): 344× MTPROTO_GEN_CREATED with
            # ZERO MTPROTO_GEN_RETIRED — terminal (RETIRED/POISONED/FAILED)
            # generation objects accumulate in this list forever (each
            # holds client refs + task snapshots). Prune the OLDEST
            # terminal generations beyond _MAX_TERMINAL_GENS so the
            # registry stays bounded during reconnect storms; the newest
            # _MAX_TERMINAL_GENS terminal entries remain for observability.
            _terminal = [g for g in gens
                         if g.state in (GenState.RETIRED, GenState.POISONED,
                                        GenState.FAILED)]
            _pruned = 0
            if len(_terminal) > self._MAX_TERMINAL_GENS:
                for _old_g in _terminal[:-self._MAX_TERMINAL_GENS]:
                    try:
                        gens.remove(_old_g)
                        _pruned += 1
                    except ValueError:
                        pass
            if _pruned:
                logger.info(
                    "MTPROTO_GEN_PRUNED session=%s pruned=%d kept_terminal=%d "
                    "total_after=%d (v99.02 FIX-4d: bounded generation "
                    "registry — 344 never-retired gens accumulated in the "
                    "v99.01 production storm)",
                    session_path, _pruned, self._MAX_TERMINAL_GENS, len(gens),
                )
            gen = MTProtoGeneration(
                session_path=session_path,
                account_id=account_id,
                client=client,
                backend_generation=len(gens) + 1,
            )
            gens.append(gen)
            logger.info(
                "MTPROTO_GEN_CREATED gen=%s session=%s backend_gen=%d",
                gen.generation_id, session_path, gen.backend_generation,
            )
            return gen

    # v99.02 FIX-4d: per-session cap on retained terminal generations.
    _MAX_TERMINAL_GENS = 8

    async def retire_generation(self, gen: MTProtoGeneration,
                                 verify_terminated: bool = True) -> bool:
        """Retire a generation safely. Returns True if safely retired.

        If verify_terminated=True and the generation's update loop hasn't
        terminated, marks it POISONED instead of RETIRED.
        """
        async with self._lock:
            if gen.poisoned:
                return False  # already terminal
            if gen.state == GenState.RETIRED:
                return True
            gen.mark_retiring()
            if verify_terminated and gen.client is not None:
                # v97.79: use the CLIENT-SPECIFIC task snapshot (stored on
                # gen.client._mediagrab_bg_tasks by _snapshot_telethon_bg_tasks)
                # instead of the v97.77 global asyncio.all_tasks() approach.
                # The global approach could observe ANOTHER client's update loop
                # and mark the wrong generation as POISONED.
                _snapshot = getattr(gen.client, "_mediagrab_bg_tasks", None)
                if _snapshot is not None:
                    # Client-specific: only check THIS generation's tasks
                    _ult_tasks = [(t, h) for t, h in _snapshot
                                  if "update_loop" in h and not t.done()]
                    if _ult_tasks:
                        try:
                            import asyncio as _asyncio
                            await _asyncio.wait_for(
                                _asyncio.gather(*[t for t, _ in _ult_tasks],
                                                return_exceptions=True),
                                timeout=3.0,
                            )
                        except (_asyncio.TimeoutError, _asyncio.CancelledError, Exception):
                            pass
                        _surviving = [(t, h) for t, h in _ult_tasks if not t.done()]
                        if _surviving:
                            gen.mark_poisoned(
                                f"update_loop_survived_retirement:count={len(_surviving)}"
                            )
                            return False
                else:
                    # Fallback: no snapshot — use global approach (unsafe for multi-account)
                    import asyncio as _asyncio
                    try:
                        _loop = _asyncio.get_running_loop()
                        _bg_tasks = []
                        for _t in _asyncio.all_tasks(_loop):
                            _coro = _t.get_coro()
                            if _coro is None:
                                continue
                            _qn = getattr(_coro, "__qualname__", "") or ""
                            if _qn.endswith("._update_loop") or _qn == "_update_loop":
                                _bg_tasks.append(_t)
                        if _bg_tasks:
                            try:
                                await _asyncio.wait_for(
                                    _asyncio.gather(*_bg_tasks, return_exceptions=True),
                                    timeout=3.0,
                                )
                            except (_asyncio.TimeoutError, _asyncio.CancelledError, Exception):
                                pass
                            _surviving = [t for t in _bg_tasks if not t.done()]
                            if _surviving:
                                gen.mark_poisoned(f"update_loop_survived_retirement:count={len(_surviving)}")
                                return False
                    except RuntimeError:
                        pass  # no running loop — skip verification
            gen.mark_retired()
            logger.info(
                "MTPROTO_GEN_RETIRED gen=%s session=%s age=%.1fs",
                gen.generation_id, gen.session_path,
                time.monotonic() - gen.created_at,
            )
            return True

    async def is_authorized(self, session_path: str, account_id: str = "") -> bool:
        """Whether the session is proven authorized.

        Per §2.3: a session candidate is only unauthorized when authorization
        was actually proven false (AUTH_FAILURE/SESSION_INVALID). Network
        failures do NOT invalidate authorization.

        v97.60: checks the LATEST generation (not just active ones). A
        DISCONNECTED generation that was previously authorized is still
        considered authorized — the session is valid, just temporarily
        disconnected. Only FAILED/POISONED generations (auth failure) clear
        authorization.
        """
        gen = await self.get_latest(session_path, account_id)
        if gen is None:
            return False
        # A POISONED or FAILED generation is NOT authorized (auth failure).
        if gen.state in (GenState.POISONED, GenState.FAILED):
            return False
        # A RETIRED generation's authorization is preserved (it was retired
        # for replacement, not for auth failure).
        return gen.authorized

    def get_stats(self) -> dict[str, Any]:
        stats = {}
        for key, gens in self._generations.items():
            stats[key] = [g.to_dict() for g in gens[-5:]]  # last 5
        return stats


# ─────────────────────────────────────────────────────────────────────────────
# Single-flight reconnect coordinator
# ─────────────────────────────────────────────────────────────────────────────

class ReconnectCoordinator:
    """Single-flight reconnect coordinator (master prompt §2/§5/§25).

    Ensures only ONE in-flight reconnect per session at a time. Multiple
    watchdog/health/cluster/manual paths may call request_reconnect() — they
    all converge on the same in-flight future. The first caller owns the
    reconnect; subsequent callers await the same future.

    Backoff is bounded + jittered. Network-unreachable uses a longer backoff
    (per §2.14). Reconnect resumes automatically when the network returns.
    """

    def __init__(self):
        # session_key -> in-flight reconnect future (None if not reconnecting)
        self._in_flight: dict[str, asyncio.Future[bool]] = {}
        # session_key -> last completed reconnect result (for caching)
        self._last_result: dict[str, bool] = {}
        # session_key -> last completed reconnect timestamp
        self._last_completed_at: dict[str, float] = {}
        # session_key -> last reconnect attempt time
        self._last_attempt: dict[str, float] = {}
        # session_key -> consecutive failure count (for backoff)
        self._fail_count: dict[str, int] = {}
        # v98.12 §11 (RUNTIME-CORRELATED via bot-diagnostic (6).log — the
        # 25-min outage 12:59-13:25: 39 reconnect attempts, EVERY one ending
        # asyncio.TimeoutError from the 15s connect budget, but the failure
        # class stayed DISCONNECTED (computed BEFORE the attempt, never from
        # the exception) → backoff capped at the 16s SHORT ladder →
        # generation churn 1/attempt + 37 MTPROTO_RECONNECT_EXHAUSTED):
        # session_key -> failure class RECORDED FROM THE LAST FAILURE. A
        # connect timeout means the network is UNREACHABLE — the next
        # attempt must use the LONG ladder (5→10→20→40→60s) so a sustained
        # outage produces ~1 attempt/minute instead of ~2.6/minute.
        self._last_failure_class: dict[str, NetworkFailureClass] = {}
        self._lock = asyncio.Lock()
        self._gen_manager = MTProtoGenerationManager()

    def _key(self, session_path: str, account_id: str = "") -> str:
        return f"{account_id}:{session_path}"

    # How long a successful reconnect result is cached (callers within this
    # window get the cached result without starting a new reconnect).
    _RESULT_CACHE_TTL = 30.0

    def _compute_backoff(self, session_key: str, failure_class: NetworkFailureClass) -> float:
        """Bounded + jittered backoff.

        NETWORK_UNREACHABLE → longer backoff (per §2.14).
        Other transient failures → shorter backoff.
        Bounded to max 300s (5 min) to ensure reconnect resumes when network returns.

        v99.02 FIX-4b (RC-4b, RUNTIME-PROVEN): a SUSTAINED outage must
        escalate to the long ladder regardless of the failure class.
        The v99.01 production storm showed failures=103 with class=unknown
        → short ladder forever (16s cap) → a reconnect every ~19s for
        2.3 hours. After _SUSTAINED_FAILURES consecutive failures the long
        ladder applies unconditionally (still bounded at the 60s cap —
        the coordinator NEVER gives up permanently; only the pacing
        changes). Exponents are clamped (2**count overflows at large
        counts; min(base, cap) already bounded it but the clamp makes it
        explicit and float-safe).
        """
        count = self._fail_count.get(session_key, 0)
        _long_ladder = (failure_class == NetworkFailureClass.NETWORK_UNREACHABLE
                        or count >= self._SUSTAINED_FAILURES)
        if _long_ladder:
            # Longer backoff: 5s, 10s, 20s, 40s, 60s (cap)
            base = min(5.0 * (2 ** min(count, 6)), 60.0)
        else:
            # Shorter backoff: 1s, 2s, 4s, 8s, 16s (cap)
            base = min(1.0 * (2 ** min(count, 4)), 16.0)
        # Jitter ±25% to avoid thundering herd.
        jitter = base * 0.25 * (random.random() * 2 - 1)
        return max(0.5, base + jitter)

    # v99.02 FIX-4b: consecutive-failure threshold at which the long
    # ladder applies regardless of failure class (sustained outage).
    _SUSTAINED_FAILURES = 8

    async def request_reconnect(
        self,
        session_path: str,
        account_id: str,
        reconnect_fn: Any,  # async callable (gen: MTProtoGeneration) -> bool
        failure_class: NetworkFailureClass = NetworkFailureClass.UNKNOWN,
        owner_token: str = "",
    ) -> bool:
        """Request a single-flight reconnect for a session.

        v97.59 SINGLE-FLIGHT: if a reconnect is already in-flight for this
        session, awaits it and returns its result. If a reconnect SUCCEEDED
        within the last _RESULT_CACHE_TTL seconds, returns the cached result
        without starting a new one (prevents concurrent callers from each
        starting their own reconnect). Otherwise, performs the reconnect with
        bounded backoff.

        ``reconnect_fn`` receives the NEW generation (created by this coordinator)
        and must transition it CONNECTING → CONNECTED (or FAILED). It must verify
        authorization (get_me) and set gen.authorized=True on success.

        Returns True if the reconnect succeeded + authorized.
        """
        key = self._key(session_path, account_id)

        # Step 1: check for in-flight reconnect → await it (OUTSIDE the lock).
        # We read the future under the lock but await it AFTER releasing the lock,
        # otherwise the lock holder blocks the reconnect from setting its result.
        existing = None
        async with self._lock:
            existing = self._in_flight.get(key)
            if existing is not None and not existing.done():
                logger.info(
                    "MTPROTO_RECONNECT_SINGLE_FLIGHT key=%s — awaiting in-flight reconnect",
                    key,
                )
                # Fall through to await OUTSIDE the lock.
            else:
                existing = None  # not in-flight; proceed to start a new one
                # Step 2: check for recently-completed SUCCESSFUL reconnect → return cached.
                last_result = self._last_result.get(key)
                last_completed = self._last_completed_at.get(key, 0)
                if last_result is True and (time.monotonic() - last_completed) < self._RESULT_CACHE_TTL:
                    logger.info(
                        "MTPROTO_RECONNECT_CACHED key=%s — recent success (%.1fs ago), skipping new reconnect",
                        key, time.monotonic() - last_completed,
                    )
                    return True

        # If we found an in-flight future, await it OUTSIDE the lock.
        if existing is not None:
            try:
                return await existing
            except Exception:
                return False

        # Step 3: compute backoff (only if previous attempt failed).
        if self._fail_count.get(key, 0) > 0:
            # v98.12 §11: prefer the failure class RECORDED from the LAST
            # failure's exception (a connect TimeoutError is NETWORK_UNREACHABLE
            # semantics — long backoff ladder) over the caller's pre-attempt
            # guess (DISCONNECTED — short ladder).
            _v9812_cls = self._last_failure_class.get(key)
            if _v9812_cls is not None:
                failure_class = _v9812_cls
            backoff = self._compute_backoff(key, failure_class)
            now = time.monotonic()
            last = self._last_attempt.get(key, 0)
            elapsed = now - last
            if elapsed < backoff:
                wait = backoff - elapsed
                logger.info(
                    "MTPROTO_RECONNECT_BACKOFF key=%s cls=%s wait=%.1fs (failures=%d)",
                    key, failure_class.value, wait, self._fail_count.get(key, 0),
                )
                await asyncio.sleep(wait)

        # Step 4: create the in-flight future (single-flight gate).
        # Re-check for in-flight (another caller may have started while we slept).
        # Again, if we find an in-flight future, await it OUTSIDE the lock.
        existing = None
        async with self._lock:
            existing = self._in_flight.get(key)
            if existing is not None and not existing.done():
                logger.info(
                    "MTPROTO_RECONNECT_SINGLE_FLIGHT key=%s — found in-flight after backoff",
                    key,
                )
                # Fall through to await OUTSIDE the lock.
            else:
                existing = None
                # Re-check cached success.
                last_result = self._last_result.get(key)
                last_completed = self._last_completed_at.get(key, 0)
                if last_result is True and (time.monotonic() - last_completed) < self._RESULT_CACHE_TTL:
                    return True
                # v98.02 FIX-R (BUG-A5-5a): asyncio.get_event_loop() is
                # deprecated since Python 3.10 — use get_running_loop().
                # When called outside a running loop, get_event_loop() emits
                # a DeprecationWarning AND may create a new loop (silently).
                # get_running_loop() raises RuntimeError if no loop is running,
                # which is the correct behavior here (this coroutine MUST run
                # inside a loop).
                fut: asyncio.Future[bool] = asyncio.get_running_loop().create_future()
                self._in_flight[key] = fut
                self._last_attempt[key] = time.monotonic()

        # If we found an in-flight future (after backoff), await it OUTSIDE the lock.
        if existing is not None:
            try:
                return await existing
            except Exception:
                return False

        # Create the new generation (marks old RETIRING).
        gen = await self._gen_manager.create_generation(
            session_path=session_path, account_id=account_id,
        )
        if owner_token:
            gen.owner_token = owner_token

        # v98.02 FIX-N (ISSUE 4 — retire stuck RETIRING generations,
        # RUNTIME-CORRELATED via bot-diagnostic (15).log):
        #   The v98.01 code marked old generations RETIRING (via
        #   create_generation at mtproto_generation.py:313-319) but NEVER
        #   called retire_generation() (defined at line 333) — generations
        #   accumulated in RETIRING state forever. bot-diagnostic (15).log
        #   showed 4 gens stuck in RETIRING (946531b955b8, ffb9f35d6867,
        #   5db77573ab94, 281eb5731a3b) — MTPROTO_GEN_RETIRING_STUCK warnings
        #   fired every 30s. FIX-N: after the new gen is created, find any
        #   OLD RETIRING gens (excluding the just-created new gen) and retire
        #   them. The drain should have already terminated their update
        #   loops; this just transitions them RETIRING→RETIRED so the
        #   observability counters are correct and memory is reclaimed.
        _gens_key = self._gen_manager._key(session_path, account_id)
        try:
            _old_retiring_gens = []
            async with self._gen_manager._lock:
                _all_gens = self._gen_manager._generations.get(_gens_key, [])
                for _g in _all_gens:
                    if _g is gen:
                        continue  # the new gen we just created
                    if (_g.state is not None
                            and _g.state == GenState.RETIRING):
                        _old_retiring_gens.append(_g)
            # Retire each old RETIRING gen OUTSIDE the lock (retire_generation
            # acquires the lock internally). verify_terminated=True is SAFE
            # here because the drain in _telethon_drain_and_reconnect_raw
            # (mtproto.py:5176 await client.disconnected) already terminated
            # the old update loops before we got here. If a gen's update loop
            # is somehow still alive, retire_generation will mark it POISONED
            # (not RETIRED) — also correct.
            for _old_gen in _old_retiring_gens:
                try:
                    _retired = await self._gen_manager.retire_generation(
                        _old_gen, verify_terminated=True)
                    if _retired:
                        logger.info(
                            "MTPROTO_GEN_RETIRED gen=%s session=%s — old "
                            "RETIRING gen retired after new gen connected "
                            "(v98.02 FIX-N: prevents RETIRING accumulation)",
                            getattr(_old_gen, "generation_id", "?"),
                            session_path,
                        )
                    else:
                        logger.warning(
                            "MTPROTO_GEN_RETIRE_POISONED gen=%s session=%s — "
                            "old RETIRING gen update loop survived retirement "
                            "(v98.02 FIX-N: marked POISONED, not RETIRED)",
                            getattr(_old_gen, "generation_id", "?"),
                            session_path,
                        )
                except Exception as _retire_exc:  # noqa: BLE001
                    logger.debug(
                        "MTPROTO_GEN_RETIRE_FAILED gen=%s exc=%s: %s",
                        getattr(_old_gen, "generation_id", "?"),
                        type(_retire_exc).__name__,
                        str(_retire_exc)[:120],
                    )
        except Exception as _retire_outer_exc:  # noqa: BLE001
            logger.debug(
                "MTPROTO_GEN_RETIRE_SWEEP_ERROR exc=%s: %s",
                type(_retire_outer_exc).__name__,
                str(_retire_outer_exc)[:120],
            )

        success = False
        try:
            gen.state = GenState.CONNECTING
            success = await reconnect_fn(gen)
            if success:
                gen.state = GenState.CONNECTED
                gen.connected_at = time.monotonic()
                gen.authorized = True
                self._fail_count[key] = 0
                # v98.12 §11: success clears the recorded failure class (the
                # next transient failure starts fresh at the short ladder).
                self._last_failure_class.pop(key, None)
                logger.info(
                    "MTPROTO_RECONNECT_SUCCESS key=%s gen=%s backend_gen=%d",
                    key, gen.generation_id, gen.backend_generation,
                )
            else:
                gen.mark_failed()
                self._fail_count[key] = self._fail_count.get(key, 0) + 1
                logger.warning(
                    "MTPROTO_RECONNECT_FAILED key=%s gen=%s failures=%d",
                    key, gen.generation_id, self._fail_count[key],
                )
        except Exception as exc:  # noqa: BLE001
            gen.mark_failed()
            self._fail_count[key] = self._fail_count.get(key, 0) + 1
            # v98.12 §11 (THE (6).log reconnect-storm root cause): classify
            # the failure FROM the exception. asyncio.TimeoutError from the
            # 15s connect budget = the Telegram DC is unreachable from this
            # host — record NETWORK_UNREACHABLE so the NEXT attempt uses the
            # long backoff ladder (5→10→20→40→60s). A TimeoutError is NOT
            # evidence about authorization or session state — only reachability.
            try:
                _v9812_is_timeout = (
                    isinstance(exc, asyncio.TimeoutError)
                    or type(exc).__name__ in ("TimeoutError", "ConnectTimeoutError")
                )
                if _v9812_is_timeout:
                    self._last_failure_class[key] = NetworkFailureClass.NETWORK_UNREACHABLE
                else:
                    self._last_failure_class[key] = (
                        classify_failure(exc) if callable(classify_failure) else NetworkFailureClass.UNKNOWN
                    )
            except Exception:  # noqa: BLE001
                pass
            logger.error(
                "MTPROTO_RECONNECT_ERROR key=%s gen=%s exc=%s failure_class=%s: %s",
                key, gen.generation_id, type(exc).__name__,
                self._last_failure_class.get(key, NetworkFailureClass.UNKNOWN).value,
                str(exc)[:160],
            )
            # v97.82 instrumentation: log when reconnect is exhausted (failed
            # all attempts). This helps distinguish a single transient failure
            # from a sustained outage. The next health-loop cycle will retry.
            if self._fail_count.get(key, 0) >= 3:
                logger.error(
                    "MTPROTO_RECONNECT_EXHAUSTED key=%s gen=%s failures=%d — "
                    "reconnect exhausted all attempts; health loop will retry. "
                    "VC state preserved (targets remain tracked, not dead-lettered).",
                    key, gen.generation_id, self._fail_count[key],
                )
            success = False
        finally:
            async with self._lock:
                self._in_flight.pop(key, None)
                self._last_result[key] = success
                self._last_completed_at[key] = time.monotonic()
                if not fut.done():
                    fut.set_result(success)

        return success

    async def is_reconnecting(self, session_path: str, account_id: str = "") -> bool:
        key = self._key(session_path, account_id)
        async with self._lock:
            fut = self._in_flight.get(key)
            return fut is not None and not fut.done()

    def get_generation_manager(self) -> MTProtoGenerationManager:
        return self._gen_manager


# Global singletons (per-process; one coordinator for ALL sessions)
_reconnect_coordinator: ReconnectCoordinator | None = None


def get_reconnect_coordinator() -> ReconnectCoordinator:
    global _reconnect_coordinator
    if _reconnect_coordinator is None:
        _reconnect_coordinator = ReconnectCoordinator()
    return _reconnect_coordinator


def reset_reconnect_coordinator() -> None:
    """Reset the global coordinator (testing / clean shutdown)."""
    global _reconnect_coordinator
    _reconnect_coordinator = None
