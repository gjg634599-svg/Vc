"""Entry point for python -m mediagrab_bot."""

from __future__ import annotations

from .bootstrap import main

if __name__ == "__main__":
    main()
