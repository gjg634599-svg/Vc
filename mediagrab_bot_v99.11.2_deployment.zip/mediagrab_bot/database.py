"""Database module — backwards-compatibility shim re-exporting db_layer.

v99.07 FIX-43: this module predates the db_layer extraction and is kept
deliberately as the compatibility surface for external tooling that
imports ``mediagrab_bot.database``; the canonical implementation (and the
complete ``repo`` namespace, v99.07 FIX-27) lives in ``db_layer``.
"""
from __future__ import annotations

from .db_layer import (
    get_db, init_db, close_db, SCHEMA_SQL, repo,
    _run_migrations, _column_exists, _index_exists,
)

__all__ = ["get_db", "init_db", "close_db", "SCHEMA_SQL", "repo"]
