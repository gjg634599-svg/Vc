"""Link parser — extracted from _bot_core.py.

Parses Telegram message links, usernames, and chat IDs into structured
ParsedInput objects. Pure regex-based parsing, zero external dependencies.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

# Input kind constants.
KIND_MESSAGE_LINK = "message_link"        # link with a message id
KIND_CHANNEL_LINK = "channel_link"        # link without a message id
KIND_USERNAME = "username"                # @username or bare username
KIND_CHAT_ID = "chat_id"                  # raw numeric id

# Source visibility (affects which Bot API calls can succeed).
VIS_PUBLIC = "public"      # resolvable by anyone via @username
VIS_PRIVATE = "private"    # /c/<internal_id>/ form; bot must be a member


@dataclass
class ParsedInput:
    """Structured result of parsing a user's download input."""

    kind: str = "unknown"                 # one of KIND_*
    visibility: str = ""                  # VIS_PUBLIC | VIS_PRIVATE | ""
    username: Optional[str] = None        # without leading @
    chat_id: Optional[int] = None         # resolved numeric id (private links)
    message_id: Optional[int] = None      # when present
    thread_id: Optional[int] = None       # topic thread id, if any
    raw: str = ""                         # original input
    error: str = ""                       # populated when unusable

    @property
    def ok(self) -> bool:
        return self.kind != "unknown" and not self.error

    def summary(self) -> str:
        parts = [f"kind={self.kind}"]
        if self.visibility:
            parts.append(f"vis={self.visibility}")
        if self.username:
            parts.append(f"user=@{self.username}")
        if self.chat_id is not None:
            parts.append(f"chat_id={self.chat_id}")
        if self.message_id is not None:
            parts.append(f"msg_id={self.message_id}")
        if self.thread_id is not None:
            parts.append(f"thread={self.thread_id}")
        if self.error:
            parts.append(f"error={self.error}")
        return " | ".join(parts)


# Regex patterns ----------------------------------------------------------

# Username rules: 5+ chars, alnum + underscore, must start with a letter.
_USERNAME_PATTERN = r"([A-Za-z][A-Za-z0-9_]{4,})"
_MSGID_PATTERN = r"(\d+)"

# Match t.me/c/<internal_id>/<msgid>  (private supergroup/channel)
_PRIVATE_LINK_RE = re.compile(
    r"https?://t(?:elegram)?\.me/c/(\d+)/(\d+)(?:/(\d+))?",
    re.IGNORECASE,
)
# Match t.me/<username>/<msgid>[/thread]  (public)
_PUBLIC_MSG_LINK_RE = re.compile(
    r"https?://t(?:elegram)?\.me/" + _USERNAME_PATTERN + r"/" + _MSGID_PATTERN + r"(?:/" + _MSGID_PATTERN + r")?",
    re.IGNORECASE,
)
# Match t.me/<username>  (channel link, no message id)
_PUBLIC_CHANNEL_LINK_RE = re.compile(
    r"https?://t(?:elegram)?\.me/" + _USERNAME_PATTERN + r"/?$",
    re.IGNORECASE,
)
# Match t.me/c/<internal_id>  (private channel link, no message id)
_PRIVATE_CHANNEL_LINK_RE = re.compile(
    r"https?://t(?:elegram)?\.me/c/(\d+)/?$",
    re.IGNORECASE,
)
# Match t.me/joinchat/<hash> (invite link — not a message link)
_INVITE_LINK_RE = re.compile(
    r"https?://t(?:elegram)?\.me/(?:joinchat/|\+)([A-Za-z0-9_-]+)",
    re.IGNORECASE,
)
# Bare @username
_AT_USERNAME_RE = re.compile(r"^@([A-Za-z][A-Za-z0-9_]{4,})$")
# Bare username (no @)
_BARE_USERNAME_RE = re.compile(r"^([A-Za-z][A-Za-z0-9_]{4,})$")
# Raw chat id (-100... or plain number)
_CHAT_ID_RE = re.compile(r"^(-?\d{6,})$")


def parse_input(raw: str) -> ParsedInput:
    """Parse arbitrary user input into a structured :class:`ParsedInput`.

    Never raises — returns a ParsedInput with ``error`` set on failure.
    """
    if not raw:
        return ParsedInput(error="Empty input.", raw=raw or "")
    text = raw.strip()
    if not text:
        return ParsedInput(error="Empty input.", raw=raw)

    # Strip surrounding markdown/whitespace artefacts users sometimes paste.
    text = text.strip("`<>()")

    # 1) Private message link: t.me/c/<id>/<msgid>
    m = _parse_private_link(text)
    if m:
        return m

    # 2) Public message link: t.me/<username>/<msgid>
    m = _PUBLIC_MSG_LINK_RE.search(text)
    if m:
        username = m.group(1)
        msg_id = int(m.group(2))
        thread = int(m.group(3)) if m.group(3) else None
        return ParsedInput(
            kind=KIND_MESSAGE_LINK,
            visibility=VIS_PUBLIC,
            username=username,
            message_id=msg_id,
            thread_id=thread,
            raw=text,
        )

    # 3) Private channel link (no msg id): t.me/c/<id>
    m = _PRIVATE_CHANNEL_LINK_RE.search(text)
    if m:
        internal_id = int(m.group(1))
        return ParsedInput(
            kind=KIND_CHANNEL_LINK,
            visibility=VIS_PRIVATE,
            chat_id=_to_supergroup_id(internal_id),
            raw=text,
        )

    # 4) Public channel link (no msg id): t.me/<username>
    m = _PUBLIC_CHANNEL_LINK_RE.search(text)
    if m:
        return ParsedInput(
            kind=KIND_CHANNEL_LINK,
            visibility=VIS_PUBLIC,
            username=m.group(1),
            raw=text,
        )

    # 5) Invite link — cannot download from these.
    if _INVITE_LINK_RE.search(text):
        return ParsedInput(
            error="Invite links (t.me/+… or t.me/joinchat/…) can't be used to "
                  "download media. Send a message link or a public @username.",
            raw=text,
        )

    # 6) Bare @username
    m = _AT_USERNAME_RE.match(text)
    if m:
        return ParsedInput(
            kind=KIND_USERNAME,
            visibility=VIS_PUBLIC,
            username=m.group(1),
            raw=text,
        )

    # 7) Bare username (no @) — be lenient but validate length/charset.
    m = _BARE_USERNAME_RE.match(text)
    if m:
        return ParsedInput(
            kind=KIND_USERNAME,
            visibility=VIS_PUBLIC,
            username=m.group(1),
            raw=text,
        )

    # 8) Raw chat id
    m = _CHAT_ID_RE.match(text)
    if m:
        cid = int(m.group(1))
        return ParsedInput(
            kind=KIND_CHAT_ID,
            chat_id=cid,
            raw=text,
        )

    # 9) Anything else — try to salvage a t.me link with weird extra path.
    if "t.me/" in text.lower() or "telegram.me/" in text.lower():
        return ParsedInput(
            error="That looks like a Telegram link, but I couldn't parse it. "
                  "Supported: t.me/<username>/<msgid>, t.me/c/<id>/<msgid>, "
                  "or @username.",
            raw=text,
        )

    return ParsedInput(
        error="Unrecognised input. Send a Telegram message link "
              "(https://t.me/…), a @username, or a channel link.",
        raw=text,
    )


def _parse_private_link(text: str) -> Optional[ParsedInput]:
    """Handle t.me/c/<id>/<msgid> (private message link)."""
    m = _PRIVATE_LINK_RE.search(text)
    if not m:
        return None
    internal_id = int(m.group(1))
    msg_id = int(m.group(2))
    thread = int(m.group(3)) if m.group(3) else None
    return ParsedInput(
        kind=KIND_MESSAGE_LINK,
        visibility=VIS_PRIVATE,
        chat_id=_to_supergroup_id(internal_id),
        message_id=msg_id,
        thread_id=thread,
        raw=text,
    )


def _to_supergroup_id(internal_id: int) -> int:
    """Convert the internal id from t.me/c/<id> into a Bot API chat id.

    Telegram's Bot API uses -100 prefixed to the internal id for supergroups
    and channels. ``t.me/c/1234567890`` corresponds to chat id
    ``-1001234567890``.
    """
    return -1000000000000 - internal_id


def from_chat_reference(parsed: ParsedInput) -> str | int | None:
    """Return the value to pass as ``from_chat_id`` to copyMessage/forwardMessage.

    For public inputs this is the ``@username`` string; for private inputs
    it's the numeric ``-100…`` chat id. Returns None if not resolvable.
    """
    if parsed.username:
        return f"@{parsed.username}"
    if parsed.chat_id is not None:
        return parsed.chat_id
    return None


def describe_input(parsed: ParsedInput) -> str:
    """Human-friendly one-line description for status messages."""
    if not parsed.ok:
        return f"invalid input ({parsed.error})"
    if parsed.kind == KIND_MESSAGE_LINK:
        loc = (f"@{parsed.username}" if parsed.username
               else str(parsed.chat_id))
        return f"message #{parsed.message_id} from {loc}"
    if parsed.kind == KIND_CHANNEL_LINK:
        loc = (f"@{parsed.username}" if parsed.username
               else f"private chat {parsed.chat_id}")
        return f"channel {loc} (no message id yet)"
    if parsed.kind == KIND_USERNAME:
        return f"public chat @{parsed.username}"
    if parsed.kind == KIND_CHAT_ID:
        return f"chat id {parsed.chat_id}"
    return "unknown input"
